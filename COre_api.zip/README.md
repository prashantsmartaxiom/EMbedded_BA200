# 🔐 MPS Authentication API

A secure and scalable authentication API built with Node.js, Express, and MongoDB, featuring comprehensive password management capabilities.

## 🚀 Features

### 🔑 **Authentication**
- User registration and login
- JWT-based authentication
- Role-based access control (admin, manager, user, viewer)
- Secure password hashing with bcryptjs

### 🔄 **Password Management**
- Forgot password with email OTP
- OTP verification
- Secure password reset
- Protected password change for authenticated users

### 🛡️ **Security**
- Rate limiting and request throttling
- Input validation and sanitization
- AES-256-GCM encryption/decryption middleware
- MongoDB injection protection
- XSS protection
- Helmet security headers

### 📧 **Email Integration**
- Password reset email notifications
- OTP delivery via email
- Password change confirmations

## 📁 Project Structure

```
src/
├── app.js                     # Express app configuration
├── server.js                  # Server entry point
├── config/                    # Configuration files
│   ├── crypto.js             # Encryption utilities
│   ├── db.js                 # Database connection
│   └── env.js                # Environment variables
├── controllers/               # Route controllers
│   └── auth.controller.js    # Authentication controllers
├── middleware/                # Express middleware
│   ├── auth.js               # JWT authentication
│   ├── decryptPayload.js     # Request decryption
│   ├── encryptResponse.js    # Response encryption
│   ├── errorHandler.js       # Error handling
│   ├── rateLimiter.js        # Rate limiting
│   ├── validate.js           # Request validation
│   └── validateParams.js     # Parameter validation
├── models/                    # Database models
│   └── User.js               # User model
├── routes/                    # API routes
│   └── auth.routes.js        # Authentication routes
├── services/                  # Business logic
│   ├── auth.service.js       # Authentication service
│   ├── emailService.js       # Email service
│   ├── resetService.js       # Password reset service
│   └── scheduleService.js    # Scheduled tasks
├── utils/                     # Utility functions
│   ├── ApiResponse.js        # API response wrapper
│   ├── catchAsync.js         # Async error handling
│   └── userAuth.js           # User authentication utilities
└── validators/                # Input validators
    └── auth.validator.js     # Authentication validators
```

## 🛠️ Installation

### Prerequisites
- Node.js (v16+ recommended)
- MongoDB
- npm or yarn

### Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/smartaxiom-inc/203-mps-api.git
   cd 203-mps-api
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment variables**
   
   Update `.env` with your configuration:
   ```env
   NODE_ENV=development
   PORT=4000
   MONGO_URI=mongodb://127.0.0.1:27017/mps_auth
   
   # JWT Configuration
   JWT_SECRET=your_super_secret_jwt_key_here
   JWT_EXPIRES_IN=1d
   
   # AES Encryption (32-byte key, base64)
   AES_KEY_BASE64=H3cQ2Rz6Zk1Kj6J4x3+Wq1J2j3J4l5m6n7o8p9q0r1s=
   
   # Password Reset Settings
   RESET_TOKEN_EXPIRES_IN=15m
   OTP_EXPIRES_IN=10m
   APP_URL=http://localhost:3000
   
   # Email Configuration
   EMAIL_FROM=noreply@smartaxiom.com
   EMAIL_HOST=smtp.gmail.com
   EMAIL_PORT=587
   EMAIL_SECURE=false
   EMAIL_USER=your-email@gmail.com
   EMAIL_PASS=your-app-password
   ```

4. **Start MongoDB**
   ```bash
   mongod
   ```

5. **Run the application**
   ```bash
   # Development mode
   npm run dev
   
   # Production mode
   npm start
   ```

The API will be available at `http://localhost:4000`

## 📚 API Documentation

### 🔗 **Base URL**
```
http://localhost:4000/api/auth
```

### 🔑 **Authentication Endpoints**

| Endpoint | Method | Description | Auth Required |
|----------|--------|-------------|---------------|
| `/signup` | POST | Register new user | ❌ |
| `/login` | POST | User login | ❌ |
| `/logout` | POST | User logout | ✅ |
| `/profile` | GET | Get user profile | ✅ |

### 🔄 **Password Management Endpoints**

| Endpoint | Method | Description | Auth Required |
|----------|--------|-------------|---------------|
| `/forgot-password` | POST | Request password reset | ❌ |
| `/verify-code` | POST | Verify OTP | ❌ |
| `/reset-password` | POST | Reset password | ❌ |
| `/change-password` | POST | Change password | ✅ |

### 👥 **User Management Endpoints**

| Endpoint | Method | Description | Auth Required |
|----------|--------|-------------|---------------|
| `/users` | GET | Get all users | ✅ (Admin) |
| `/user/:id` | GET | Get user by ID | ✅ |
| `/user/:id` | PUT | Update user | ✅ |

For detailed API documentation with request/response examples, see [API_DOCUMENTATION.md](./API_DOCUMENTATION.md)

## 🧪 Testing

### Using Postman
1. Import the collection: `postman_collection_password_management.json`
2. Set the `baseUrl` environment variable to `http://localhost:4000/api/auth`
3. Follow the testing guide: [PASSWORD_TESTING_GUIDE.md](./PASSWORD_TESTING_GUIDE.md)

### Manual Testing
Follow the comprehensive testing guide in [PASSWORD_TESTING_GUIDE.md](./PASSWORD_TESTING_GUIDE.md) for step-by-step instructions.

## 🔒 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: bcryptjs with 12 salt rounds
- **Rate Limiting**: Protection against brute force attacks
- **Input Validation**: Comprehensive Joi validation schemas
- **Data Sanitization**: MongoDB injection and XSS protection
- **CORS Configuration**: Cross-origin request handling
- **Helmet Security**: Security headers for Express.js
- **AES Encryption**: Optional payload encryption/decryption

## 🌐 Environment Configuration

### Development
```bash
NODE_ENV=development
npm run dev
```

### Production
```bash
NODE_ENV=production
npm start
```

## 📋 Scripts

```bash
# Start development server with auto-reload
npm run dev

# Start production server
npm start

# Run ESLint
npm run lint
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the ISC License.

## 🏢 SmartAxiom Inc.

Built with ❤️ by the SmartAxiom team.

---

For more information, check out our additional documentation:
- [API Documentation](./API_DOCUMENTATION.md)
- [Testing Guide](./PASSWORD_TESTING_GUIDE.md)
- [Implementation Summary](./IMPLEMENTATION_SUMMARY.md)
- [Cleanup Summary](./CLEANUP_SUMMARY.md)

added for testing
