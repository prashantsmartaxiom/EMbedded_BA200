import mongoose from "mongoose";
import { MasterTimezone } from "../src/models/MasterTimezone.js";
import * as dotenv from "dotenv";
dotenv.config();

const data = [
    { timeZoneName: "UTC (UTC +00:00)", timeZoneValue: "UTC" },
    { timeZoneName: "GMT (GMT +00:00)", timeZoneValue: "GMT" },
    { timeZoneName: "EST (EST -05:00)", timeZoneValue: "America/New_York" },
    { timeZoneName: "CST (CST -06:00)", timeZoneValue: "America/Chicago" },
    { timeZoneName: "MST (MST -07:00)", timeZoneValue: "America/Denver" },
    { timeZoneName: "PST (PST -08:00)", timeZoneValue: "America/Los_Angeles" },
    { timeZoneName: "IST (IST +05:30)", timeZoneValue: "Asia/Kolkata" },
    { timeZoneName: "JST (JST +09:00)", timeZoneValue: "Asia/Tokyo" },
    { timeZoneName: "CET (CET +01:00)", timeZoneValue: "Europe/Paris" },
    { timeZoneName: "EET (EET +02:00)", timeZoneValue: "Europe/Athens" },
    { timeZoneName: "BST (BST +01:00)", timeZoneValue: "Europe/London" },
    { timeZoneName: "AEST (AEST +10:00)", timeZoneValue: "Australia/Sydney" },
    { timeZoneName: "NZST (NZST +12:00)", timeZoneValue: "Pacific/Auckland" },
    { timeZoneName: "SGT (SGT +08:00)", timeZoneValue: "Asia/Singapore" },
    { timeZoneName: "HKT (HKT +08:00)", timeZoneValue: "Asia/Hong_Kong" },
    { timeZoneName: "KST (KST +09:00)", timeZoneValue: "Asia/Seoul" },
    { timeZoneName: "CST (CST +08:00)", timeZoneValue: "Asia/Shanghai" },
    { timeZoneName: "MSK (MSK +03:00)", timeZoneValue: "Europe/Moscow" },
    { timeZoneName: "SAST (SAST +02:00)", timeZoneValue: "Africa/Johannesburg" },
    { timeZoneName: "BRT (BRT -03:00)", timeZoneValue: "America/Sao_Paulo" },
    { timeZoneName: "ART (ART -03:00)", timeZoneValue: "America/Argentina/Buenos_Aires" },
    { timeZoneName: "CLT (CLT -03:00)", timeZoneValue: "America/Santiago" },
    { timeZoneName: "PET (PET -05:00)", timeZoneValue: "America/Lima" },
    { timeZoneName: "VET (VET -04:00)", timeZoneValue: "America/Caracas" },
    { timeZoneName: "UYT (UYT -03:00)", timeZoneValue: "America/Montevideo" },
    { timeZoneName: "PYT (PYT -04:00)", timeZoneValue: "America/Asuncion" },
    { timeZoneName: "BOT (BOT -04:00)", timeZoneValue: "America/La_Paz" },
    { timeZoneName: "GYT (GYT -04:00)", timeZoneValue: "America/Guyana" },
    { timeZoneName: "COT (COT -05:00)", timeZoneValue: "America/Bogota" },
    { timeZoneName: "ECT (ECT -05:00)", timeZoneValue: "America/Guayaquil" },
    { timeZoneName: "GFT (GFT -03:00)", timeZoneValue: "America/Cayenne" },
    { timeZoneName: "WGT (WGT -03:00)", timeZoneValue: "America/Godthab" },
    { timeZoneName: "FKT (FKT -04:00)", timeZoneValue: "Atlantic/Stanley" },
    { timeZoneName: "BRST (BRST -02:00)", timeZoneValue: "America/Sao_Paulo" },
    { timeZoneName: "NDT (NDT -02:30)", timeZoneValue: "America/St_Johns" },
    { timeZoneName: "ADT (ADT -03:00)", timeZoneValue: "America/Halifax" },
    { timeZoneName: "EDT (EDT -04:00)", timeZoneValue: "America/New_York" },
    { timeZoneName: "CDT (CDT -05:00)", timeZoneValue: "America/Chicago" },
    { timeZoneName: "MDT (MDT -06:00)", timeZoneValue: "America/Denver" },
    { timeZoneName: "PDT (PDT -07:00)", timeZoneValue: "America/Los_Angeles" },
    { timeZoneName: "AKDT (AKDT -08:00)", timeZoneValue: "America/Anchorage" },
    { timeZoneName: "HADT (HADT -09:00)", timeZoneValue: "Pacific/Honolulu" },
    { timeZoneName: "WET (WET +00:00)", timeZoneValue: "Europe/London" },
    { timeZoneName: "WEST (WEST +01:00)", timeZoneValue: "Europe/London" },
    { timeZoneName: "CEST (CEST +02:00)", timeZoneValue: "Europe/Paris" },
    { timeZoneName: "EEST (EEST +03:00)", timeZoneValue: "Europe/Athens" },
    { timeZoneName: "MSD (MSD +04:00)", timeZoneValue: "Europe/Moscow" },
    { timeZoneName: "GST (GST +04:00)", timeZoneValue: "Asia/Dubai" },
    { timeZoneName: "PKT (PKT +05:00)", timeZoneValue: "Asia/Karachi" },
    { timeZoneName: "BDT (BDT +06:00)", timeZoneValue: "Asia/Dhaka" },
    { timeZoneName: "ICT (ICT +07:00)", timeZoneValue: "Asia/Bangkok" },
    { timeZoneName: "WIT (WIT +07:00)", timeZoneValue: "Asia/Jakarta" },
    { timeZoneName: "PHT (PHT +08:00)", timeZoneValue: "Asia/Manila" },
    { timeZoneName: "AWST (AWST +08:00)", timeZoneValue: "Australia/Perth" },
    { timeZoneName: "ACST (ACST +09:30)", timeZoneValue: "Australia/Adelaide" },
    { timeZoneName: "AEST (AEST +10:00)", timeZoneValue: "Australia/Brisbane" },
    { timeZoneName: "ACDT (ACDT +10:30)", timeZoneValue: "Australia/Adelaide" },
    { timeZoneName: "AEDT (AEDT +11:00)", timeZoneValue: "Australia/Sydney" },
    { timeZoneName: "NZDT (NZDT +13:00)", timeZoneValue: "Pacific/Auckland" },
    { timeZoneName: "FJT (FJT +12:00)", timeZoneValue: "Pacific/Fiji" },
    { timeZoneName: "TVT (TVT +12:00)", timeZoneValue: "Pacific/Funafuti" },
    { timeZoneName: "GILT (GILT +12:00)", timeZoneValue: "Pacific/Tarawa" },
    { timeZoneName: "WST (WST +13:00)", timeZoneValue: "Pacific/Apia" },
    { timeZoneName: "CHAST (CHAST +12:45)", timeZoneValue: "Pacific/Chatham" },
    { timeZoneName: "CHADT (CHADT +13:45)", timeZoneValue: "Pacific/Chatham" },
    { timeZoneName: "LINT (LINT +14:00)", timeZoneValue: "Pacific/Kiritimati" },
    { timeZoneName: "TOT (TOT +13:00)", timeZoneValue: "Pacific/Tongatapu" },
    { timeZoneName: "CHUT (CHUT +10:00)", timeZoneValue: "Pacific/Chuuk" },
    { timeZoneName: "PONT (PONT +11:00)", timeZoneValue: "Pacific/Pohnpei" },
    { timeZoneName: "KOST (KOST +11:00)", timeZoneValue: "Pacific/Kosrae" },
    { timeZoneName: "MHT (MHT +12:00)", timeZoneValue: "Pacific/Majuro" },
    { timeZoneName: "NRT (NRT +12:00)", timeZoneValue: "Pacific/Nauru" },
    { timeZoneName: "PWT (PWT +09:00)", timeZoneValue: "Pacific/Palau" },
    { timeZoneName: "CHST (CHST +10:00)", timeZoneValue: "Pacific/Guam" }
];

const createTimezones = async () => {
    try {
        await mongoose.connect(
            process.env.MONGODB_URI, // e.g., "mongodb://localhost:27017"
            { dbName: process.env.MASTER_DB || "AdminDB" }, // Make DB name configurable
        );

        console.log("Connected to MongoDB");

        let createdCount = 0;
        let existingCount = 0;

        for (let i in data) {
            // Check if timezone already exists
            const existing = await MasterTimezone.findOne({ 
                timeZoneName: data[i].timeZoneName 
            });
            
            if (!existing) {
                // Create timezone
                const masterTimezoneData = new MasterTimezone({
                    ...data[i],
                    createdDate: new Date().toISOString(),
                    isActive: true,
                    isDeleted: false
                });
                await masterTimezoneData.save();
                console.log(`✅ Created: ${data[i].timeZoneName}`);
                createdCount++;
            } else {
                console.log(`⏭️  Already exists: ${data[i].timeZoneName}`);
                existingCount++;
            }
        }

        console.log(`\n🎉 Timezone seeding completed!`);
        console.log(`📊 Summary:`);
        console.log(`   - Created: ${createdCount} new timezones`);
        console.log(`   - Already existed: ${existingCount} timezones`);
        console.log(`   - Total processed: ${data.length} timezones`);

        process.exit(0);

    } catch (error) {
        console.error("❌ Error seeding timezones:", error);
        process.exit(1);
    }
};

createTimezones();