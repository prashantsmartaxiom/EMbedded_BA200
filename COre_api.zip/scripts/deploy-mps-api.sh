#!/bin/bash
# Install Node.js if not present
# curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
# sudo apt-get install -y nodejs
# Navigate to API directory
cd ~/mps-api
# Install dependencies
npm install
# Install PM2 globally
# sudo npm install -g pm2
# Stop existing API process
pm2 stop mps-api || true
pm2 delete mps-api || true
# Start API with PM2
pm2 start npm --name "mps-api" -- start
# Save PM2 configuration
pm2 save
pm2 startup
echo "MPS API deployed successfully"
