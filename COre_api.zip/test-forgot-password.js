import fetch from 'node-fetch';

const API_BASE = 'http://localhost:4000';
const TEST_EMAIL = 's.patel@thesynapses.com';

async function testForgotPassword() {
  console.log('🧪 Testing forgot password rate limiting behavior...\n');

  try {
    // First request - should work normally
    console.log('📧 Making first forgot password request...');
    const response1 = await fetch(`${API_BASE}/auth/forgot-password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email: TEST_EMAIL })
    });

    const result1 = await response1.json();
    console.log('Status:', response1.status);
    console.log('Response:', JSON.stringify(result1, null, 2));

    // Wait a moment before second request
    console.log('\n⏳ Waiting 2 seconds...\n');
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Second request - should return "OTP already sent" instead of error
    console.log('📧 Making second forgot password request (should get "OTP already sent")...');
    const response2 = await fetch(`${API_BASE}/auth/forgot-password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email: TEST_EMAIL })
    });

    const result2 = await response2.json();
    console.log('Status:', response2.status);
    console.log('Response:', JSON.stringify(result2, null, 2));

    // Verify the behavior
    if (response2.status === 200 && result2.message === 'OTP already sent') {
      console.log('\n✅ SUCCESS: Rate limiting now returns "OTP already sent" instead of error!');
    } else {
      console.log('\n❌ FAILED: Expected "OTP already sent" message with 200 status');
    }

  } catch (error) {
    console.error('❌ Test failed with error:', error.message);
  }
}

testForgotPassword();