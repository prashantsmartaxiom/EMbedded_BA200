import mongoose from 'mongoose';

/**
 * Build MongoDB filter query based on user permissions for efficient database-level filtering
 * @param {Object} user - User object with campusData and allowedResources
 * @param {string} resourceKey - Resource type ('campuses', 'buildings', 'floors', 'zones')
 * @param {string} [contextCampusId] - Optional campus ID to filter within specific campus context
 * @returns {Object} MongoDB filter object
 */
export function buildUserFilter(user, resourceKey, contextCampusId = null) {
  // Base filter for active, non-deleted records
  let filter = {
    $and: [
      { $or: [{ isDelete: { $exists: false } }, { isDelete: { $ne: true } }] }
    ]
  };

  // Security-first approach: if user is not properly authenticated, return restrictive filter
  if (!user) {
    filter.$and.push({ _id: { $in: [] } }); // Empty array - no results
    return filter;
  }

  // Priority 0: Check if user is superadmin - show all data only if they have no restrictions
  // Only treat as superadmin if role is 'superadmin' AND no campusData restrictions
  if (user.role_id && user.role_id.roleName && user.role_id.roleName.toLowerCase() === 'superadmin') {
    // Even superadmins should respect campusData if it exists
    if (!user.campusData || !Array.isArray(user.campusData) || user.campusData.length === 0) {
      return filter; // Return base filter (all non-deleted records) only if no campusData
    }
  }

  // Priority 1: If campusData exists and has content, filter by campusData only
  if (user.campusData && Array.isArray(user.campusData) && user.campusData.length > 0) {
    return buildCampusDataFilter(filter, user.campusData, resourceKey, contextCampusId);
  }

  // Priority 2: Superadmin/Admin access - if user doesn't have allowedResources (null or undefined)
  if (user.allowedResources === null || user.allowedResources === undefined) {
    // For superadmin/admin users, just return the base filter (all non-deleted records)
    return filter;
  }

  // Priority 3: If allowedResources exists, restrict by allowedResources
  if (
    user.allowedResources &&
    user.allowedResources.campusManagement
  ) {
    const allowedArr = user.allowedResources.campusManagement[resourceKey];
    if (Array.isArray(allowedArr) && allowedArr.length > 0) {
      filter.$and.push({ _id: { $in: allowedArr.map(id => new mongoose.Types.ObjectId(id)) } });
      return filter;
    }
  }

  // If allowedResources doesn't have the specific resourceKey, no access
  filter.$and.push({ _id: { $in: [] } }); // Empty array - no results
  return filter;
}

/**
 * Build filter based only on campusData (when allowedResources is null)
 */
function buildCampusDataFilter(filter, campusData, resourceKey, contextCampusId = null) {
  const campusIds = campusData.map(campus => new mongoose.Types.ObjectId(campus.campus_id));

  switch (resourceKey) {
    case 'campuses':
      filter.$and.push({ _id: { $in: campusIds } });
      break;

    case 'buildings':
      // For buildings, we can filter by campus IDs to show all buildings from allowed campuses
      // OR by specific building IDs if campusData contains specific building permissions
      const buildingIds = [];
      const allowedCampusIds = [];
      
      campusData.forEach(campus => {
        // If contextCampusId is provided, only process that specific campus
        if (contextCampusId && String(campus.campus_id) !== String(contextCampusId)) {
          return; // Skip this campus
        }
        
        // Always allow campus-level access
        allowedCampusIds.push(new mongoose.Types.ObjectId(campus.campus_id));
        
        // Also collect specific building IDs if they exist in campusData
        campus.buildings?.forEach(building => {
          if (building.building_id) {
            buildingIds.push(new mongoose.Types.ObjectId(building.building_id));
          }
        });
      });
      
      // Filter by either campus IDs (show all buildings from allowed campuses) 
      // OR specific building IDs if they are defined in campusData
      if (buildingIds.length > 0) {
        // If specific building IDs are defined, use them
        filter.$and.push({ _id: { $in: buildingIds } });
      } else if (allowedCampusIds.length > 0) {
        // Otherwise, show all buildings from allowed campuses
        filter.$and.push({ campusId: { $in: allowedCampusIds } });
      }
      break;

    case 'floors':
      const floorIds = [];
      const allowedBuildingIds = [];
      
      campusData.forEach(campus => {
        // If contextCampusId is provided, only process that specific campus
        if (contextCampusId && String(campus.campus_id) !== String(contextCampusId)) {
          return; // Skip this campus
        }
        
        campus.buildings?.forEach(building => {
          // Always allow building-level access for floors
          if (building.building_id) {
            allowedBuildingIds.push(new mongoose.Types.ObjectId(building.building_id));
          }
          
          // Also collect specific floor IDs if they exist in campusData
          building.floors?.forEach(floor => {
            if (floor.floor_id) {
              floorIds.push(new mongoose.Types.ObjectId(floor.floor_id));
            }
          });
        });
      });
      
      // Filter by either building IDs (show all floors from allowed buildings)
      // OR specific floor IDs if they are defined in campusData
      if (floorIds.length > 0) {
        // If specific floor IDs are defined, use them
        filter.$and.push({ _id: { $in: floorIds } });
      } else if (allowedBuildingIds.length > 0) {
        // Otherwise, show all floors from allowed buildings
        filter.$and.push({ buildingId: { $in: allowedBuildingIds } });
      }
      break;

    case 'zones':
      const zoneIds = [];
      const allowedFloorIds = [];
      
      campusData.forEach(campus => {
        // If contextCampusId is provided, only process that specific campus
        if (contextCampusId && String(campus.campus_id) !== String(contextCampusId)) {
          return; // Skip this campus
        }
        
        campus.buildings?.forEach(building => {
          building.floors?.forEach(floor => {
            // Always allow floor-level access for zones
            if (floor.floor_id) {
              allowedFloorIds.push(new mongoose.Types.ObjectId(floor.floor_id));
            }
            
            // Also collect specific zone IDs if they exist in campusData
            floor.zones?.forEach(zone => {
              if (zone.zone_id) {
                zoneIds.push(new mongoose.Types.ObjectId(zone.zone_id));
              }
            });
          });
        });
      });
      
      // Filter by either floor IDs (show all zones from allowed floors)
      // OR specific zone IDs if they are defined in campusData
      if (zoneIds.length > 0) {
        // If specific zone IDs are defined, use them
        filter.$and.push({ _id: { $in: zoneIds } });
      } else if (allowedFloorIds.length > 0) {
        // Otherwise, show all zones from allowed floors
        filter.$and.push({ floorId: { $in: allowedFloorIds } });
      }
      break;

    default:
      filter.$and.push({ _id: { $in: [] } }); // Empty array - no results
  }

  return filter;
}

/**
 * Build filter based on intersection of campusData and allowedResources
 */
function buildIntersectionFilter(filter, user, resourceKey) {
  const campusDataIds = user.campusData.map(campus => String(campus.campus_id));
  const allowedResourceIds = user.allowedResources.campusManagement[resourceKey].map(id => String(id));
  
  // Get allowed campus IDs (intersection of campusData and allowedResources.campuses)
  const allowedCampusIds = user.allowedResources.campusManagement.campuses ? 
    user.allowedResources.campusManagement.campuses
      .filter(id => campusDataIds.includes(String(id)))
      .map(id => new mongoose.Types.ObjectId(id)) : 
    [];

  switch (resourceKey) {
    case 'campuses':
      filter.$and.push({ _id: { $in: allowedCampusIds } });
      break;

    case 'buildings':
      // Get building IDs from campusData
      const campusDataBuildingIds = new Set();
      user.campusData.forEach(campus => {
        campus.buildings?.forEach(building => {
          if (building.building_id) {
            campusDataBuildingIds.add(String(building.building_id));
          }
        });
      });

      // Get intersection of allowedResources.buildings and campusData buildings
      const allowedBuildingIds = allowedResourceIds
        .filter(id => campusDataBuildingIds.has(String(id)))
        .map(id => new mongoose.Types.ObjectId(id));

      filter.$and.push({ _id: { $in: allowedBuildingIds } });
      break;

    case 'floors':
      // Get floor IDs from campusData
      const campusDataFloorIds = new Set();
      user.campusData.forEach(campus => {
        campus.buildings?.forEach(building => {
          building.floors?.forEach(floor => {
            if (floor.floor_id) {
              campusDataFloorIds.add(String(floor.floor_id));
            }
          });
        });
      });

      // Get intersection of allowedResources.floors and campusData floors
      const allowedFloorIds = allowedResourceIds
        .filter(id => campusDataFloorIds.has(String(id)))
        .map(id => new mongoose.Types.ObjectId(id));

      filter.$and.push({ _id: { $in: allowedFloorIds } });
      break;

    case 'zones':
      // Get zone IDs from campusData
      const campusDataZoneIds = new Set();
      user.campusData.forEach(campus => {
        campus.buildings?.forEach(building => {
          building.floors?.forEach(floor => {
            floor.zones?.forEach(zone => {
              if (zone.zone_id) {
                campusDataZoneIds.add(String(zone.zone_id));
              }
            });
          });
        });
      });

      // Get intersection of allowedResources.zones and campusData zones
      const allowedZoneIds = allowedResourceIds
        .filter(id => campusDataZoneIds.has(String(id)))
        .map(id => new mongoose.Types.ObjectId(id));

      filter.$and.push({ _id: { $in: allowedZoneIds } });
      break;

    default:
      filter.$and.push({ _id: { $in: [] } }); // Empty array - no results
  }

  return filter;
}
