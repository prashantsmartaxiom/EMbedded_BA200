/**
 * Utility Functions - Async error handling and image processing
 * 
 * Provides essential application utilities:
 * - catchAsync: Express async error handler wrapper for clean error propagation
 * - saveImage: Base64 image processing with file system management
 * - Directory management with configurable paths and subdirectories
 * - MIME type detection and file extension handling
 * - Atomic file operations with cleanup on failure
 */

import fs from 'fs';
import path from 'path';

/**
 * Async error wrapper for Express route handlers
 * Automatically catches Promise rejections and forwards to Express error middleware
 */
export const catchAsync = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

/**
 * Save base64 image with comprehensive file management
 * 
 * Handles image processing pipeline:
 * - Data URL parsing with MIME type detection (data:image/...;base64,AAAA...)
 * - Plain base64 string support with PNG fallback
 * - Configurable directory structure with subdirectory support
 * - Safe filename generation with sanitization
 * - Atomic file operations with automatic cleanup on failure
 * - Cross-platform path handling for deployment flexibility
 *
 * @param {string} base64Image - data:image/...;base64,AAAA... OR plain base64 string
 * @param {string} filenamePrefix - prefix or filename (without extension) to use for the saved file
 * @returns {Promise<string>} - relative public path to save in DB (e.g. "images/abc.png")
 *
 * Throws on invalid input or write failure.
 */
export const saveImage = async (base64Image, filenamePrefix = '', subDir = '') => {
  if (!base64Image || typeof base64Image !== 'string') {
    throw new Error('No image data provided');
  }

  const imagesRoot = process.env.IMAGES_DIR || path.join(process.cwd(), 'public', 'images');
  const publicPathBase = process.env.IMAGES_PUBLIC_PATH || 'images';

  // build target directory with optional subDir (e.g. "campus")
  const targetDir = subDir ? path.join(imagesRoot, subDir) : imagesRoot;
  const publicDir = subDir ? path.join(publicPathBase, subDir) : publicPathBase;

  let matches = base64Image.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
  let mimeType;
  let base64Data;

  if (matches) {
    mimeType = matches[1];
    base64Data = matches[2];
  } else {
    base64Data = base64Image;
    mimeType = 'image/png';
  }

  const mimeToExt = {
    'image/png': 'png',
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/webp': 'webp',
    'image/gif': 'gif',
  };
  const ext = mimeToExt[mimeType] || 'png';

  const safePrefix = String(filenamePrefix || '').replace(/[^a-zA-Z0-9-_]/g, '') || `${Date.now()}`;
  const fileName = `${safePrefix}.${ext}`;
  const filePath = path.join(targetDir, fileName);

  try {
    await fs.promises.mkdir(targetDir, { recursive: true });
    const buffer = Buffer.from(base64Data, 'base64');
    await fs.promises.writeFile(filePath, buffer);

    // return `images/campus/<fileName>` style path
    return path.join(publicDir, fileName).replace(/\\/g, '/');
  } catch (err) {
    try {
      if (fs.existsSync(filePath)) {
        await fs.promises.unlink(filePath);
      }
    } catch (unlinkErr) {
      console.error('saveImage cleanup failed:', unlinkErr.message);
    }
    throw new Error(`Failed to save image: ${err.message}`);
  }
};
