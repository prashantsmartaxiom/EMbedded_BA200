/**
 * Device Configuration - IoT device command constants
 * 
 * Defines standardized command codes for device communication:
 * - LED control commands (status, brightness, color, on/off, configuration)
 * - Shade control commands (movement, positioning, limits, configuration)
 * - Sensor commands (PIR state, temperature/humidity monitoring)
 * - Scene and group management commands
 * - Immutable configuration to prevent runtime modification
 */

const DeviceConfig = Object.freeze({
  LED_STATUS: 101,
  LED_BRIGHTNESS: 102,
  LED_COLOR: 103,
  LED_ON_OFF: 104,
  LED_MAX_CUR: 105,
  LED_CONFIG: 106,
  LED_CONFIG_CH: 107,
  SHADE_CONTROL: 108,
  SHADE_DOWN: 109,
  SHADE_CONFIG: 110,
  SHADE_SET_CONF: 111,
  SHADE_STATUS: 112,
  SHADE_OPEN: 113,
  SHADE_CLOSE: 114,
  PIR_STATE: 115,
  TEMP_HUM: 116,
  SCENE_CMD: 117,
  PIR_CONFIG: 118,
  SHADE_LIMIT: 119,
  SHADE_MOVE: 120,
  GRP_PIR_TIMER: 121
});

export default DeviceConfig;
