/**
 * Socket Manager - Real-time communication orchestration
 * 
 * Manages user socket sessions and event broadcasting:
 * - User-to-socket mapping with multi-device support
 * - Targeted messaging to specific users or user groups
 * - Global event broadcasting for system-wide notifications
 * - Session lifecycle management (register/unregister)
 * - Real-time updates for dashboard, device status, and system events
 */

import { getIO } from "./socket.js";

class SocketManager {
    constructor() {
        // Map of userId -> Set of socketIds for multi-device support
        this.userSockets = new Map();
    }

    /**
     * Register socket for user session tracking
     * Supports multiple devices per user with Set-based socket management
     */
    registerSocket(userId, socketId) {
        if (!this.userSockets.has(userId)) {
        this.userSockets.set(userId, new Set());
        }
        this.userSockets.get(userId).add(socketId);
        console.log(`🔹 Registered socket ${socketId} for user ${userId}`);
    }

    // Unregister socket on disconnect
    unregisterSocket(socketId) {
        for (const [userId, sockets] of this.userSockets.entries()) {
        if (sockets.has(socketId)) {
            sockets.delete(socketId);
            console.log(`🔸 Unregistered socket ${socketId} for user ${userId}`);
            if (sockets.size === 0) this.userSockets.delete(userId);
            break;
        }
        }
    }

    /**
     * Broadcast event to all connected clients
     * Used for system-wide notifications and global updates
     */
    emitEvent(event, data) {
        const io = getIO();
        console.log("--Emit event", event, data);
        io.emit(event, data);
    }

    /**
     * Send targeted event to specific user across all their devices
     * Enables personalized notifications and user-specific updates
     */
    emitToUser(userId, event, data) {
        const io = getIO();
        const sockets = this.userSockets.get(userId);
        if (sockets) {
            for (const socketId of sockets) {
                io.to(socketId).emit(event, data);
            }
        }
    }

    // Emit to multiple users
    emitToUsers(userIds, event, data) {
        userIds.forEach((userId) => this.emitToUser(userId, event, data));
    }
}

export const socketManager = new SocketManager();
