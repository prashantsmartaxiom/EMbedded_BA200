/**
 * ApiResponse - Standardized API response structure
 * 
 * Provides consistent response format across all API endpoints:
 * - Uniform success/error indication with boolean flag
 * - Standardized message field for client communication
 * - Optional data payload for response content
 * - Ensures predictable response structure for frontend consumption
 */

export class ApiResponse {
  constructor(success, message, data = null) {
    this.success = success;
    this.message = message;
    this.data = data;
  }
}
