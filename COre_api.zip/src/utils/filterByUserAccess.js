
/**
 export const filterByUserResourceAccess = (items, user, resourceKey) => {
  // Security-first approach: if user is not properly authenticated, return empty array
  if (!user) {
    return [];
  }lter for user resource access.
 * @param {Array} items - Array of resource objects (campus, building, floor, zone).
 * @param {Object} user - User object containing campusData and allowedResources.
 * @param {string} resourceKey - Key in allowedResources.campusManagement (e.g., 'campuses', 'buildings', 'floors', 'zones').
 * @returns {Array} - Filtered array of resources.
 */
export function filterByUserResourceAccess(items, user, resourceKey) {
  // Security-first approach: if user is not properly authenticated, return empty array
  if (!user) {
    return [];
  }

  // Case 1: No campusData - admin access (show all items)
  if (!user.campusData || !Array.isArray(user.campusData) || user.campusData.length === 0) {
    return items;
  }

  // Case 2: allowedResources is null but campusData exists - show all data from campusData hierarchy
  if (user.allowedResources === null || user.allowedResources === undefined) {
    return filterByCampusDataOnly(items, user, resourceKey);
  }

  // Case 3: allowedResources exists but campusManagement is missing - admin access
  if (!user.allowedResources.campusManagement) {
    return items;
  }

  // Case 4: allowedResources exists but specific resourceKey is missing - return empty
  if (!Array.isArray(user.allowedResources.campusManagement[resourceKey])) {
    return [];
  }

  // Case 5: Both allowedResources and campusData exist - use intersection filtering
  return filterByIntersection(items, user, resourceKey);
}

// Helper function to filter by campusData only (when allowedResources is null)
function filterByCampusDataOnly(items, user, resourceKey) {
  const campusDataIds = user.campusData.map(campus => String(campus.campus_id));

  if (resourceKey === 'campuses') {
    return items.filter(item => campusDataIds.includes(String(item._id)));
  }

  if (resourceKey === 'buildings') {
    const campusDataBuildingIds = new Set();
    user.campusData.forEach(campus => {
      campus.buildings?.forEach(building => {
        if (building.building_id) {
          campusDataBuildingIds.add(String(building.building_id));
        }
      });
    });
    return items.filter(item => campusDataBuildingIds.has(String(item._id)));
  }

  if (resourceKey === 'floors') {
    const campusDataFloorIds = new Set();
    user.campusData.forEach(campus => {
      campus.buildings?.forEach(building => {
        building.floors?.forEach(floor => {
          if (floor.floor_id) {
            campusDataFloorIds.add(String(floor.floor_id));
          }
        });
      });
    });
    return items.filter(item => campusDataFloorIds.has(String(item._id)));
  }

  if (resourceKey === 'zones') {
    const campusDataZoneIds = new Set();
    user.campusData.forEach(campus => {
      campus.buildings?.forEach(building => {
        building.floors?.forEach(floor => {
          floor.zones?.forEach(zone => {
            if (zone.zone_id) {
              campusDataZoneIds.add(String(zone.zone_id));
            }
          });
        });
      });
    });
    return items.filter(item => campusDataZoneIds.has(String(item._id)));
  }

  return items;
}

// Helper function to filter by intersection of campusData and allowedResources
function filterByIntersection(items, user, resourceKey) {

  // Get campus IDs from campusData
  const campusDataIds = user.campusData.map(campus => String(campus.campus_id));
  // Get allowed resource IDs from allowedResources
  const allowedResourceIds = user.allowedResources.campusManagement[resourceKey].map(id => String(id));
  
  // Get allowed campus IDs (intersection of campusData and allowedResources.campuses)
  const allowedCampusIds = user.allowedResources.campusManagement.campuses ? 
    new Set(user.allowedResources.campusManagement.campuses.filter(id => campusDataIds.includes(String(id))).map(id => String(id))) : 
    new Set();
  
  // For campuses: filter by intersection of campusData campus_ids and allowedResources.campuses
  if (resourceKey === 'campuses') {
    return items.filter(item => allowedCampusIds.has(String(item._id)));
  }
  
  // For buildings: filter by building ID that exists in BOTH campusData AND allowedResources.buildings
  if (resourceKey === 'buildings') {
    const allowedBuildingIds = new Set(allowedResourceIds);
    
    // Get all building IDs from campusData
    const campusDataBuildingIds = new Set();
    user.campusData.forEach(campus => {
      campus.buildings?.forEach(building => {
        if (building.building_id) {
          campusDataBuildingIds.add(String(building.building_id));
        }
      });
    });
    
    return items.filter(item => {
      const buildingId = String(item._id);
      // Building must exist in BOTH campusData AND allowedResources.buildings
      return allowedBuildingIds.has(buildingId) && campusDataBuildingIds.has(buildingId);
    });
  }
  
  // For floors: filter by floor ID that exists in BOTH campusData AND allowedResources.floors
  if (resourceKey === 'floors') {
    const allowedFloorIds = new Set(allowedResourceIds);
    
    // Get all floor IDs from campusData
    const campusDataFloorIds = new Set();
    user.campusData.forEach(campus => {
      campus.buildings?.forEach(building => {
        building.floors?.forEach(floor => {
          if (floor.floor_id) {
            campusDataFloorIds.add(String(floor.floor_id));
          }
        });
      });
    });
    
    return items.filter(item => {
      const floorId = String(item._id);
      // Floor must exist in BOTH campusData AND allowedResources.floors
      return allowedFloorIds.has(floorId) && campusDataFloorIds.has(floorId);
    });
  }
  
  // For zones: filter by zone ID that exists in BOTH campusData AND allowedResources.zones
  if (resourceKey === 'zones') {
    const allowedZoneIds = new Set(allowedResourceIds);
    
    // Get all zone IDs from campusData
    const campusDataZoneIds = new Set();
    user.campusData.forEach(campus => {
      campus.buildings?.forEach(building => {
        building.floors?.forEach(floor => {
          floor.zones?.forEach(zone => {
            if (zone.zone_id) {
              campusDataZoneIds.add(String(zone.zone_id));
            }
          });
        });
      });
    });
    
    return items.filter(item => {
      const zoneId = String(item._id);
      // Zone must exist in BOTH campusData AND allowedResources.zones
      return allowedZoneIds.has(zoneId) && campusDataZoneIds.has(zoneId);
    });
  }
  
  // For other resources: filter by allowedResources only
  const allowedIdsSet = new Set(allowedResourceIds);
  return items.filter(item => allowedIdsSet.has(String(item._id)));
}

/**
 * Filter devices by allowedResources.deviceManagement.devices and campusData zones
 * @param {Array} devices - Array of device objects
 * @param {Object} user - User object containing campusData and allowedResources
 * @returns {Array} - Filtered array of devices
 */
export function filterConfiguredDevicesByUser(devices, user) {
  if (!user || !user.allowedResources || !user.allowedResources.deviceManagement || !Array.isArray(user.allowedResources.deviceManagement.devices) || !Array.isArray(user.campusData)) {
    return devices;
  }
  // Get allowed device IDs
  const allowedDeviceIds = new Set(user.allowedResources.deviceManagement.devices.map(id => String(id)));

  // Get all zone_ids from campusData
  const zoneIds = new Set();
  user.campusData.forEach(campus => {
    campus.buildings?.forEach(building => {
      building.floors?.forEach(floor => {
        floor.zones?.forEach(zone => {
          if (zone.zone_id) zoneIds.add(String(zone.zone_id));
        });
      });
    });
  });

  // Filter devices that are in allowedDeviceIds and whose zone_id is in zoneIds
  return devices.filter(device => {
    const deviceIdMatch = allowedDeviceIds.has(String(device._id));
    const zoneIdMatch = device.zone_id && zoneIds.has(String(device.zone_id));
    return deviceIdMatch && zoneIdMatch;
  });
}

/**
 * Filter groups by campusData zones (for non-deleted groups)
 * @param {Array} groups - Array of group objects
 * @param {Object} user - User object containing campusData
 * @returns {Array} - Filtered array of groups
 */
export function filterGroupsByCampusData(groups, user) {
  if (!user || !Array.isArray(user.campusData)) {
    return groups;
  }

  // Get all zone_ids from campusData
  const zoneIds = new Set();
  user.campusData.forEach(campus => {
    campus.buildings?.forEach(building => {
      building.floors?.forEach(floor => {
        floor.zones?.forEach(zone => {
          if (zone.zone_id) zoneIds.add(String(zone.zone_id));
        });
      });
    });
  });

  // Filter groups that are not deleted and have devices that belong to zones in campusData
  return groups.filter(group => {
    const isNotDeleted = !group.isDeleted;
    
    // Check if group has devices and any device belongs to allowed zones
    const hasDevicesInAllowedZones = group.devices && group.devices.length > 0 && 
      group.devices.some(device => device.zone_id && zoneIds.has(String(device.zone_id)));
    
    return isNotDeleted && hasDevicesInAllowedZones;
  });
}

/**
 * Filter scenes by campusData zones (shows scenes that have devices or groups with devices in allowed zones)
 * @param {Array} scenes - Array of scene objects
 * @param {Object} user - User object containing campusData
 * @returns {Array} - Filtered array of scenes
 */
export function filterScenesByCampusData(scenes, user) {
  if (!user || !Array.isArray(user.campusData)) {
    return scenes;
  }

  // Get all zone_ids from campusData
  const zoneIds = new Set();
  user.campusData.forEach(campus => {
    campus.buildings?.forEach(building => {
      building.floors?.forEach(floor => {
        floor.zones?.forEach(zone => {
          if (zone.zone_id) zoneIds.add(String(zone.zone_id));
        });
      });
    });
  });

  // Filter scenes that have devices or groups with devices in allowed zones
  return scenes.filter(scene => {
    // Check direct devices in scene
    const hasDirectDevicesInZones = scene.devices && scene.devices.length > 0 &&
      scene.devices.some(device => device.zone_id && zoneIds.has(String(device.zone_id)));

    // Check devices in groups within the scene
    const hasGroupDevicesInZones = scene.groups && scene.groups.length > 0 &&
      scene.groups.some(group => 
        group.devices && group.devices.length > 0 &&
        group.devices.some(device => device.zone_id && zoneIds.has(String(device.zone_id)))
      );

    return hasDirectDevicesInZones || hasGroupDevicesInZones;
  });
}

/**
 * Filter sensors by campusData zones (shows sensors that have devices in allowed zones)
 * @param {Array} sensors - Array of sensor objects
 * @param {Object} user - User object containing campusData
 * @returns {Array} - Filtered array of sensors
 */
export function filterSensorsByCampusData(sensors, user) {
  if (!user || !Array.isArray(user.campusData)) {
    return sensors;
  }

  // Get all zone_ids from campusData
  const zoneIds = new Set();
  user.campusData.forEach(campus => {
    campus.buildings?.forEach(building => {
      building.floors?.forEach(floor => {
        floor.zones?.forEach(zone => {
          if (zone.zone_id) zoneIds.add(String(zone.zone_id));
        });
      });
    });
  });

  // Filter sensors that have device_id with zone_id in allowed zones
  return sensors.filter(sensor => {
    // Check if sensor has device and device's zone_id is in allowed zones
    const hasDeviceInAllowedZones = sensor.device && sensor.device.zone_id && 
      zoneIds.has(String(sensor.device.zone_id));
    
    return hasDeviceInAllowedZones;
  });
}

/**
 * Filter templates by campusData zones (shows templates that have devices in allowed zones)
 * @param {Array} templates - Array of template objects
 * @param {Object} user - User object containing campusData
 * @param {Array} allDevices - Array of all device objects to lookup device details
 * @returns {Array} - Filtered array of templates
 */
export function filterTemplatesByCampusData(templates, user, allDevices = []) {
  if (!user || !Array.isArray(user.campusData)) {
    return templates;
  }

  // Get all zone_ids from campusData
  const zoneIds = new Set();
  user.campusData.forEach(campus => {
    campus.buildings?.forEach(building => {
      building.floors?.forEach(floor => {
        floor.zones?.forEach(zone => {
          if (zone.zone_id) zoneIds.add(String(zone.zone_id));
        });
      });
    });
  });

  // Create a map of device_id to device zone for quick lookup
  const deviceZoneMap = new Map();
  allDevices.forEach(device => {
    if (device.device_id && device.zone) {
      deviceZoneMap.set(device.device_id, String(device.zone));
    }
  });

  // Filter templates that have devices in allowed zones
  return templates.filter(template => {
    if (!template.layoutStructure || !template.layoutStructure.rows) {
      return false;
    }

    // Check all devices in the template layout structure
    for (const row of template.layoutStructure.rows) {
      if (!row.columns) continue;
      
      for (const column of row.columns) {
        if (!column.elements) continue;
        
        // Check if any element (device) in this column belongs to allowed zones
        const hasDeviceInAllowedZones = column.elements.some(element => {
          // Get device_id from element
          if (element.deviceId) {
            // Look up the device's zone from the device collection
            const deviceZone = deviceZoneMap.get(element.deviceId);
            return deviceZone && zoneIds.has(deviceZone);
          }
          return false;
        });
        
        if (hasDeviceInAllowedZones) {
          return true;
        }
      }
    }
    
    return false;
  });
}
