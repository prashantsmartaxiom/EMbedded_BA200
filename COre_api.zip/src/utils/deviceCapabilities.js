/**
 * Device Capabilities - Default IoT device configuration templates
 * 
 * Provides standardized device capability definitions:
 * - LED channels (LED1-LED12) with brightness and power management
 * - Shade channels (SHADE1-SHADE4) with position and movement control
 * - Default properties for device initialization and configuration
 * - Consistent capability structure for device management
 * - Installation status tracking for operational planning
 */

const defaultCapabilities = [
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED1',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED2',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED3',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED4',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED5',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED6',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED7',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED8',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED9',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED10',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED11',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED12',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE1',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', maxMovement: '4' }
  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE2',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', maxMovement: '4' }

  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE3',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', maxMovement: '4' }
  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE4',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', maxMovement: '4' }
  }
]

const defaultBA200Capabilities = [
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED1',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED2',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED3',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED4',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED5',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED6',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED7',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED8',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED9',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED10',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED11',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED12',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED13',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED14',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED15',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED16',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED17',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED18',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED19',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED20',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED21',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'led',
    name: 'Unnamed',
    channelId: 'LED22',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '0.5'
    }
  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE1',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', maxMovement: '4' }
  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE2',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', maxMovement: '4' }

  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE3',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', maxMovement: '4' }
  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE4',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', maxMovement: '4' }
  },
   {
    type: 'expansion_led',
    name: 'Unnamed',
    channelId: 'EXP_LED1',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },
   {
    type: 'expansion_led',
    name: 'Unnamed',
    channelId: 'EXP_LED2',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },
  {
    type: 'expansion_led',
    name: 'Unnamed',
    channelId: 'EXP_LED3',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },{
    type: 'expansion_led',
    name: 'Unnamed',
    channelId: 'EXP_LED4',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },{
    type: 'expansion_led',
    name: 'Unnamed',
    channelId: 'EXP_LED5',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },{
    type: 'expansion_led',
    name: 'Unnamed',
    channelId: 'EXP_LED6',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },{
    type: 'expansion_led',
    name: 'Unnamed',
    channelId: 'EXP_LED7',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },{
    type: 'expansion_led',
    name: 'Unnamed',
    channelId: 'EXP_LED8',
    status: 'off',
    installed: false,
    properties: {
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },
  {
    type: 'expansion_color_lights',
    name: 'Unnamed',
    channelId: 'EXP_COLOR_LED1',
    status: 'off',
    installed: false,
    properties: {
      color: "yellow",
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },
   {
    type: 'expansion_color_lights',
    name: 'Unnamed',
    channelId: 'EXP_COLOR_LED2',
    status: 'off',
    installed: false,
    properties: {
      color: "yellow",
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },
  {
    type: 'expansion_color_lights',
    name: 'Unnamed',
    channelId: 'EXP_COLOR_LED3',
    status: 'off',
    installed: false,
    properties: {
      color: "yellow",
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },
  {
    type: 'expansion_color_lights',
    name: 'Unnamed',
    channelId: 'EXP_COLOR_LED4',
    status: 'off',
    installed: false,
    properties: {
      color: "yellow",
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },
  {
    type: 'expansion_color_lights',
    name: 'Unnamed',
    channelId: 'EXP_COLOR_LED5',
    status: 'off',
    installed: false,
    properties: {
      color: "yellow",
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },


  {
    type: 'expansion_color_lights',
    name: 'Unnamed',
    channelId: 'EXP_COLOR_LED6',
    status: 'off',
    installed: false,
    properties: {
      color: "yellow",
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },
  {
    type: 'expansion_color_lights',
    name: 'Unnamed',
    channelId: 'EXP_COLOR_LED7',
    status: 'off',
    installed: false,
    properties: {
      color: "yellow",
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },
  {
    type: 'expansion_color_lights',
    name: 'Unnamed',
    channelId: 'EXP_COLOR_LED8',
    status: 'off',
    installed: false,
    properties: {
      color: "yellow",
      brightness: 0,
      powerMin: '10',
      powerMax: '100'
    }
  },
  {
    type: 'rtu_CO2',
    name: 'Unnamed',
    channelId: 'RTU_CO2_1',
    status: 'inactive',
    installed: false,
    properties: {
      sensorType: "CO2",
      min_value: '10',
      max_value: '100',
      brightness: 0
    }
  },
  {
    type: 'rtu_light_sensor',
    name: 'Unnamed',
    channelId: 'RTU_LIGHT_SENSOR_1',
    status: 'inactive',
    installed: false,
    properties: {
      sensorType: "temp",
      installed: true,
      port: "2",
      sensorAddress: "4",
      commType: "io",
      brightness: 0,
    }
  },
  {
    type: 'rtu_HMI',
    name: 'Unnamed',
    channelId: 'RTU_HMI_1',
    status: 'inactive',
    installed: false,
    properties: {
      sensorType: "temp",
      installed: true,
      port: "2",
      sensorAddress: "4",
      commType: "io",
      brightness: 0,
    }
  },
  {
    type: 'io_pir',
    name: 'Unnamed',
    channelId: 'IO_PIR_1',
    status: 'inactive',
    installed: false,
    properties: {
      sensorType: "temp",
      installed: true,
      port: "2",
      sensorAddress: "4",
      commType: "io",
      brightness: 0,
    }
  }
]

const defaultLutronCapabilities = [
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE1',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', numberOfCmds: 3 }
  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE2',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', numberOfCmds: 3 }
  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE3',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', numberOfCmds: 3 }
  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE4',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', numberOfCmds: 4 }
  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE5',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', numberOfCmds: 4 }
  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE6',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', numberOfCmds: 4 }
  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE7',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', numberOfCmds: 4 }
  },
  {
    type: 'shade',
    name: 'Unnamed',
    channelId: 'SHADE8',
    status: 'closed',
    installed: false,
    properties: { openLevel: '0%', numberOfCmds: 4 }
  }
]

export { defaultCapabilities, defaultBA200Capabilities, defaultLutronCapabilities };