/**
 * User Authentication Utilities - Security and session management
 * 
 * Provides comprehensive authentication support:
 * - User-Agent parsing for device fingerprinting and security tracking
 * - IP address extraction with proxy and load balancer support
 * - OTP generation for two-factor authentication
 * - Session data creation with device and location tracking
 * - Password reset authentication with audit trail
 * - Security context creation for login/signup operations
 */

import { UAParser } from 'ua-parser-js';

/**
 * Parse User-Agent string for device identification and security tracking
 * Extracts OS, browser, and device information for session management
 */
export const parseUserAgent = (userAgent) => {
  if (!userAgent) {
    return {
      os: 'Unknown',
      browser: 'Unknown',
      rawUA: 'Unknown'
    };
  }

  const parser = new UAParser(userAgent);
  const result = parser.getResult();

  return {
    os: `${result.os.name || 'Unknown'} ${result.os.version || ''}`.trim(),
    browser: `${result.browser.name || 'Unknown'} ${result.browser.version || ''}`.trim(),
    rawUA: userAgent
  };
};

/**
 * Extract client IP address with proxy and load balancer support
 * Handles various deployment scenarios including reverse proxies
 */
export const getClientIP = (req) => {
  return req.ip || 
         req.connection?.remoteAddress || 
         req.socket?.remoteAddress || 
         req.headers['x-forwarded-for']?.split(',')[0] || 
         req.headers['x-real-ip'] || 
         'Unknown';
};

/**
 * Generate secure 6-digit OTP for two-factor authentication
 * Provides cryptographically random OTP for enhanced security
 */
export const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

/**
 * Create comprehensive user authentication data for login/signup
 * Generates session record with device fingerprinting and security context
 */
export const createUserAuthData = (req, token, expiryDate, createdBy = null) => {
  const deviceDetails = parseUserAgent(req.headers['user-agent']);
  const ipAddress = getClientIP(req);

  return {
    lastLoginDateTime: new Date(),
    ipAddress,
    deviceDetails: {
      device: deviceDetails.os,
      browser: deviceDetails.browser,
      userAgent: deviceDetails.rawUA
    },
    jwtToken: token,
    expiry: expiryDate,
    status: 'active',
    lastUse: new Date(),
    createdBy: createdBy || null,
    updatedBy: createdBy || null
  };
};

/**
 * Create password reset authentication record with security tracking
 * Maintains audit trail for password reset attempts and device context
 */
export const createPasswordResetAuthData = (req, type = 'password_reset') => {
  const deviceDetails = parseUserAgent(req.headers['user-agent']);
  const ipAddress = getClientIP(req);

  return {
    type,
    ipAddress,
    deviceDetails,
    status: 'active',
    createdAt: new Date(),
    updatedAt: new Date()
  };
};
