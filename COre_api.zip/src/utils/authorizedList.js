import mongoose from 'mongoose';
import Role from '../models/Role.js';

/**
 * Search field mappings for different resource types
 * Maps resource keys to their searchable fields
 */
const SEARCH_FIELDS_MAP = {
  campuses: ['name', 'location', 'accessId'],
  buildings: ['name', 'description'],
  floors: ['name', 'floorLevel'],
  zones: ['name', 'type', 'description'],
  devices: ['device_id', 'SNO', 'name', 'type'],
  groups: ['name', 'description'],
  scenes: ['name', 'description'],
  sensors: ['name', 'channelId'],
  template: ['name', 'description'],
  users: ['fullName', 'email', 'location'],
  roles: ['roleName'],
  event_logs: ['message', 'topic', 'user'],
  mqtt_logs: ['message', 'topic', 'user']
};

/**
 * Resource key to field mapping for filtering by hierarchical relationships
 * Maps resource keys to the field they should be filtered by
 */
const RESOURCE_FIELD_MAP = {
  campuses: '_id',
  buildings: 'campusId',
  floors: 'buildingId', 
  zones: 'floorId',
  devices: 'zone', // assuming devices are linked to zones
  groups: 'campusId',
  scenes: 'campusId',
  sensors: 'zone',
  template: 'campusId',
  users: '_id',
  roles: '_id',
  event_logs: 'campusId',
  mqtt_logs: 'campusId'
};

/**
 * Maps API resource keys to permission keys used in role documents
 * Your role structure uses different permission keys than resource keys
 */
const RESOURCE_TO_PERMISSION_MAP = {
  // Campus Management
  campuses: 'campus_management',
  buildings: 'building_management', 
  floors: 'floor_management',
  zones: 'zone_management',
  
  // Intelligent Control
  groups: 'group_management',
  scenes: 'scene_management',
  sensors: 'sensor_management',
  template: 'template_management',
  
  // Device Management
  devices: 'device_control',
  
  // User Management
  users: 'user_accounts',
  roles: 'role_management',
  
  // Logs Monitoring
  event_logs: 'event_logs',
  mqtt_logs: 'mqtt_logs'
};

/**
 * Extract all allowed IDs from user's allowedResources and campusData
 * @param {Object} user - User document or plain object
 * @returns {Object} Object with Sets of allowed IDs for each resource type
 */
export const extractAllowedIdsFromUser = (user) => {
  const allowedSets = {
    campuses: new Set(),
    buildings: new Set(),
    floors: new Set(),
    zones: new Set(),
    devices: new Set(),
    groups: new Set(),
    scenes: new Set(),
    sensors: new Set(),
    templates: new Set(),
    users: new Set(),
    roles: new Set()
  };

  // Extract from allowedResources (if exists)
  if (user.allowedResources) {
    const { allowedResources } = user;
    
    // Campus Management
    if (allowedResources.campusManagement) {
      allowedResources.campusManagement.campuses?.forEach(id => allowedSets.campuses.add(id));
      allowedResources.campusManagement.buildings?.forEach(id => allowedSets.buildings.add(id));
      allowedResources.campusManagement.floors?.forEach(id => allowedSets.floors.add(id));
      allowedResources.campusManagement.zones?.forEach(id => allowedSets.zones.add(id));
    }
    
    // Intelligent Control
    if (allowedResources.intelligentControl) {
      allowedResources.intelligentControl.groups?.forEach(id => allowedSets.groups.add(id));
      allowedResources.intelligentControl.scenes?.forEach(id => allowedSets.scenes.add(id));
      allowedResources.intelligentControl.sensors?.forEach(id => allowedSets.sensors.add(id));
      allowedResources.intelligentControl.templates?.forEach(id => allowedSets.templates.add(id));
    }
    
    // Device Management
    if (allowedResources.deviceManagement) {
      allowedResources.deviceManagement.devices?.forEach(id => allowedSets.devices.add(id));
    }
  }

  // Extract from campusData hierarchical structure (if exists)
  if (user.campusData && Array.isArray(user.campusData)) {
    user.campusData.forEach(campus => {
      allowedSets.campuses.add(campus.campus_id);
      
      if (campus.buildings && Array.isArray(campus.buildings)) {
        campus.buildings.forEach(building => {
          allowedSets.buildings.add(building.building_id);
          
          if (building.floors && Array.isArray(building.floors)) {
            building.floors.forEach(floor => {
              allowedSets.floors.add(floor.floor_id);
              
              if (floor.zones && Array.isArray(floor.zones)) {
                floor.zones.forEach(zone => {
                  allowedSets.zones.add(zone.zone_id);
                });
              }
            });
          }
        });
      }
    });
  }

  return allowedSets;
};

/**
 * Check if user's role has View permission for a specific module and resource
 * @param {Object} roleDoc - Role document with permissions
 * @param {string} moduleKey - Module key (e.g., 'CAMPUS_MANAGEMENT')
 * @param {string} resourceKey - Resource key (e.g., 'campuses')
 * @returns {boolean} Whether view permission is granted
 */
export const checkRoleViewPermission = (roleDoc, moduleKey, resourceKey) => {
  if (!roleDoc || !roleDoc.permissions) {
    return false;
  }

  try {
    // Check if permissions has the module
    const modulePermissions = roleDoc.permissions[moduleKey];
    if (!modulePermissions) {
      return false;
    }

    // Map resource key to permission key used in your role structure
    const permissionKey = RESOURCE_TO_PERMISSION_MAP[resourceKey];
    if (!permissionKey) {
      console.warn(`No permission mapping found for resource: ${resourceKey}`);
      return false;
    }

    // Get the specific permission object
    const resourcePermissions = modulePermissions[permissionKey];
    if (!resourcePermissions) {
      return false;
    }

    // Check for View permission
    return resourcePermissions.View === true;
  } catch (error) {
    console.error('Error checking role permissions:', error);
    return false;
  }
};

/**
 * Build MongoDB query filter from query parameters
 * @param {Object} queryParams - Request query parameters
 * @param {string} resourceKey - Resource key for search field mapping
 * @param {Array} searchFields - Override search fields
 * @returns {Object} MongoDB filter object
 */
export const buildQueryFromParams = (queryParams, resourceKey, searchFields = null) => {
  const filter = {};
  
  // Use provided search fields or get from mapping
  const fieldsToSearch = searchFields || SEARCH_FIELDS_MAP[resourceKey] || [];
  
  // Handle search parameter
  if (queryParams.search && fieldsToSearch.length > 0) {
    const searchRegex = { $regex: queryParams.search, $options: 'i' };
    filter.$or = fieldsToSearch.map(field => ({
      [field]: searchRegex
    }));
  }
  
  // Handle status parameter
  if (queryParams.status !== undefined) {
    if (queryParams.status === 'active') {
      filter.status = 1;
      filter.isDelete = false;
    } else if (queryParams.status === 'inactive') {
      filter.status = 0;
      filter.isDelete = false;
    } else {
      // Numeric status
      const status = parseInt(queryParams.status);
      if (!isNaN(status)) {
        filter.status = status;
        filter.isDelete = false;
      }
    }
  } else {
    // Default: only show non-deleted records
    filter.isDelete = false;
  }
  
  // Handle other common filters
  if (queryParams.type) {
    filter.type = queryParams.type;
  }
  
  if (queryParams.isActive !== undefined) {
    filter.isActive = queryParams.isActive === 'true';
  }
  
  return filter;
};

/**
 * Merge allowed resource filters with base filter
 * @param {Object} baseFilter - Base MongoDB filter
 * @param {Object} allowedSets - Sets of allowed IDs for each resource type
 * @param {string} resourceKey - Resource key to filter by
 * @param {boolean} isAdminBypass - Whether to bypass permission checks
 * @returns {Object} Merged MongoDB filter
 */
export const mergeAllowedFilters = (baseFilter, allowedSets, resourceKey, isAdminBypass = false) => {
  const mergedFilter = { ...baseFilter };
  
  // If admin bypass is enabled, return base filter only
  if (isAdminBypass) {
    return mergedFilter;
  }
  
  // Get the field to filter by for this resource type
  const filterField = RESOURCE_FIELD_MAP[resourceKey];
  if (!filterField) {
    console.warn(`No filter field mapping found for resource: ${resourceKey}`);
    return mergedFilter;
  }
  
  // Get allowed IDs for this resource type
  const allowedIds = allowedSets[resourceKey];
  if (!allowedIds || allowedIds.size === 0) {
    // No allowed IDs means no access - return filter that matches nothing
    mergedFilter._id = { $in: [] };
    return mergedFilter;
  }
  
  // Convert string IDs to ObjectIds where needed
  const filterIds = Array.from(allowedIds).map(id => {
    if (mongoose.Types.ObjectId.isValid(id)) {
      return new mongoose.Types.ObjectId(id);
    }
    return id;
  });
  
  // Add the resource-specific filter
  if (filterField === '_id') {
    mergedFilter._id = { $in: filterIds };
  } else {
    mergedFilter[filterField] = { $in: filterIds };
  }
  
  // For hierarchical resources, also check parent relationships
  if (resourceKey === 'buildings' && allowedSets.campuses.size > 0) {
    const campusIds = Array.from(allowedSets.campuses).map(id => 
      mongoose.Types.ObjectId.isValid(id) ? new mongoose.Types.ObjectId(id) : id
    );
    mergedFilter.$or = [
      { _id: { $in: filterIds } },
      { campusId: { $in: campusIds } }
    ];
  } else if (resourceKey === 'floors' && (allowedSets.buildings.size > 0 || allowedSets.campuses.size > 0)) {
    const orConditions = [{ _id: { $in: filterIds } }];
    
    if (allowedSets.buildings.size > 0) {
      const buildingIds = Array.from(allowedSets.buildings).map(id => 
        mongoose.Types.ObjectId.isValid(id) ? new mongoose.Types.ObjectId(id) : id
      );
      orConditions.push({ buildingId: { $in: buildingIds } });
    }
    
    mergedFilter.$or = orConditions;
  } else if (resourceKey === 'zones') {
    const orConditions = [{ _id: { $in: filterIds } }];
    
    if (allowedSets.floors.size > 0) {
      const floorIds = Array.from(allowedSets.floors).map(id => 
        mongoose.Types.ObjectId.isValid(id) ? new mongoose.Types.ObjectId(id) : id
      );
      orConditions.push({ floorId: { $in: floorIds } });
    }
    
    if (orConditions.length > 1) {
      mergedFilter.$or = orConditions;
    }
  }
  
  return mergedFilter;
};

/**
 * Main function to get authorized list of resources with pagination and filtering
 * @param {Object} options - Configuration options
 * @param {Object} options.user - User document or plain object
 * @param {string} options.moduleKey - Module key (e.g., 'CAMPUS_MANAGEMENT')
 * @param {string} options.resourceKey - Resource key (e.g., 'campuses')
 * @param {mongoose.Model} options.model - Mongoose model for the collection
 * @param {Object} options.queryParams - Request query parameters
 * @param {Object} options.baseFilter - Optional base filter to always apply
 * @param {Array} options.populate - Optional Mongoose populate options
 * @param {Function} options.transformResult - Optional function to transform each result
 * @param {boolean} options.strict - Whether to throw 403 on permission denied (default: false)
 * @param {boolean} options.bypassPermissions - Whether to bypass all permission checks
 * @param {Array} options.searchFields - Override search fields for this resource
 * @returns {Promise<Object>} Paginated response with data, total, page, limit
 */
export const getAuthorizedList = async (options) => {
  const {
    user,
    moduleKey,
    resourceKey,
    model,
    queryParams = {},
    baseFilter = {},
    populate = [],
    transformResult = null,
    strict = false,
    bypassPermissions = false,
    searchFields = null
  } = options;

  // Validate required parameters
  if (!user || !moduleKey || !resourceKey || !model) {
    throw new Error('Missing required parameters: user, moduleKey, resourceKey, and model are required');
  }

  // Extract pagination parameters
  const page = Math.max(1, parseInt(queryParams.page) || 1);
  const limit = Math.max(1, Math.min(100, parseInt(queryParams.limit) || 24));
  const skip = (page - 1) * limit;
  
  // Default sort
  const sortBy = queryParams.sortBy || 'createdAt';
  const sortOrder = queryParams.sortOrder === 'asc' ? 1 : -1;
  const sort = { [sortBy]: sortOrder };

  // Check if bypassing permissions (for admin routes)
  if (bypassPermissions) {
    const filter = { ...baseFilter, ...buildQueryFromParams(queryParams, resourceKey, searchFields) };
    
    const [data, total] = await Promise.all([
      model.find(filter)
        .sort(sort)
        .skip(skip)
        .limit(limit)
        .populate(populate)
        .lean(),
      model.countDocuments(filter)
    ]);

    const transformedData = transformResult ? data.map(transformResult) : data;
    
    return {
      data: transformedData,
      total,
      page,
      limit
    };
  }

  // Load role if not populated
  let roleDoc = user.role_id;
  if (user.role_id && typeof user.role_id === 'string') {
    roleDoc = await Role.findById(user.role_id).lean();
  } else if (user.role_id && !user.role_id.permissions) {
    roleDoc = await Role.findById(user.role_id._id).lean();
  }

  // Check if user is admin (bypass allowedResources checks but still check role permissions)
  const isAdmin = roleDoc && (
    roleDoc.byDefault === 'true' || 
    roleDoc.roleName === 'Admin' ||
    // Also check if user has no allowedResources (admin characteristic)
    !user.allowedResources
  );
  
  console.log('Authorization Debug:', {
    userId: user._id || user.id,
    roleId: user.role_id,
    roleName: roleDoc?.roleName,
    byDefault: roleDoc?.byDefault,
    hasAllowedResources: !!user.allowedResources,
    isAdmin,
    moduleKey,
    resourceKey
  });
  
  // Check role permissions (always required unless bypassing)
  const hasViewPermission = checkRoleViewPermission(roleDoc, moduleKey, resourceKey);
  if (!hasViewPermission) {
    if (strict) {
      const error = new Error('Forbidden: Insufficient permissions to view this resource');
      error.statusCode = 403;
      throw error;
    }
    return {
      data: [],
      total: 0,
      page,
      limit
    };
  }

  // Extract allowed IDs from user
  const allowedSets = extractAllowedIdsFromUser(user);
  
  // For non-admin users, check if they have any allowed resources for this type
  // Admin users or users without allowedResources should bypass this check
  if (!isAdmin && user.allowedResources && allowedSets[resourceKey].size === 0) {
    // Quick return for empty allowed resources (only for non-admin users who have allowedResources structure)
    console.log('No allowed resources found for non-admin user');
    return {
      data: [],
      total: 0,
      page,
      limit
    };
  }

  // Build query filters
  const queryFilter = buildQueryFromParams(queryParams, resourceKey, searchFields);
  const finalFilter = mergeAllowedFilters(
    { ...baseFilter, ...queryFilter },
    allowedSets,
    resourceKey,
    isAdmin
  );

  try {
    // Execute query with pagination
    const [data, total] = await Promise.all([
      model.find(finalFilter)
        .sort(sort)
        .skip(skip)
        .limit(limit)
        .populate(populate)
        .lean(),
      model.countDocuments(finalFilter)
    ]);

    // Transform results if transform function provided
    const transformedData = transformResult ? data.map(transformResult) : data;
    
    return {
      data: transformedData,
      total,
      page,
      limit
    };
  } catch (error) {
    console.error('Error in getAuthorizedList:', error);
    throw new Error(`Failed to fetch ${resourceKey}: ${error.message}`);
  }
};

/**
 * Simplified version for common use cases
 * @param {Object} user - User document
 * @param {string} moduleKey - Module key
 * @param {string} resourceKey - Resource key
 * @param {mongoose.Model} model - Mongoose model
 * @param {Object} queryParams - Query parameters
 * @returns {Promise<Object>} Paginated response
 */
export const getList = async (user, moduleKey, resourceKey, model, queryParams) => {
  return getAuthorizedList({
    user,
    moduleKey,
    resourceKey,
    model,
    queryParams,
    baseFilter: { isDelete: false }
  });
};

export default {
  getAuthorizedList,
  getList,
  extractAllowedIdsFromUser,
  checkRoleViewPermission,
  buildQueryFromParams,
  mergeAllowedFilters
};
