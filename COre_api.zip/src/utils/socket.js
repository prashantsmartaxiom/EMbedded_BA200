/**
 * Socket.IO Server - Real-time communication initialization
 * 
 * Manages WebSocket connections for real-time features:
 * - Socket.IO server initialization with CORS configuration
 * - Client connection/disconnection handling
 * - User registration for targeted messaging
 * - Integration with socketManager for user session tracking
 * - Global IO instance management for application-wide access
 */

import { Server } from "socket.io";
import { socketManager } from "./socketManager.js";

let io;

/**
 * Initialize Socket.IO server with connection handling
 * Sets up real-time communication infrastructure with user session management
 */
export const initSocket = (server) => {
    io = new Server(server, {
        cors: {
        origin: "*",
        methods: ["GET", "POST"],
        },
    });

    io.on("connection", (socket) => {
        console.log("Client connected:", socket.id);

        // Register user on connect
        socket.on("registerUser", (data) => {
            console.log("Registering user:", data);
            socket.userId = data.userId;
            socketManager.registerSocket(data.userId, socket.id);

        });

        socket.on("disconnect", () => {
            socketManager.unregisterSocket(socket.id);
            console.log("Client disconnected:", socket.id);
        });
    });

    return io;
};

/**
 * Get Socket.IO server instance
 * Provides access to initialized IO server for event emission throughout application
 */
export const getIO = () => {
    if (!io) throw new Error("Socket.io not initialized!");
        return io;
};
