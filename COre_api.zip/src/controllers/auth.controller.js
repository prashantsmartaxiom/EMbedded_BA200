/**
 * Authentication Controller - Auth Business Logic Layer
 * 
 * Flow: routes → CONTROLLER → service → database
 * 
 * Responsibilities:
 * - Request validation and sanitization
 * - Authentication state management
 * - JWT token handling
 * - Session tracking and audit logging
 * - Password security operations
 * - Role-based response formatting
 * 
 * Key Features:
 * - Complete user lifecycle (signup → verify → login → logout)
 * - Secure password reset flow with OTP
 * - Profile management with image handling
 * - Real-time session tracking
 * - IP-based security logging
 * - Admin user management operations
 */
import * as authService from '../services/auth.service.js';
import { resetService } from '../services/resetService.js';
import { catchAsync } from '../utils/catchAsync.js';
import { ApiResponse } from '../utils/ApiResponse.js';
const { addLog } = await import('../services/log.service.js');

export const getRoleDetailByUserId = catchAsync(async (req, res) => {
  const { id } = req.params;
  const result = await authService.getRoleDetailByUserId(id);
  return res.status(200).json(new ApiResponse(true, 'Role detail retrieved successfully', result));
});

/**
 * User Registration with OTP Generation
 * 
 * Process:
 * 1. Create user account (pending verification)
 * 2. Generate OTP for email/SMS verification
 * 3. Grant new user access to existing admin users
 * 4. Log registration action
 * 5. Return user data + OTP (for dev/testing)
 */
export const signup = catchAsync(async (req, res) => {
  const result = await authService.register(req.body, req);

  // Auto-grant new user management access to existing admins
  try {
    const newUserId = result.user?._id || result.user?.id;
    if (newUserId) {
      // Import User model to avoid circular dependency
      const { User } = await import('../models/User.js');
      // Find users with user management permissions
      const usersToUpdate = await User.find({
        'allowedResources.userManagement.users.0': { $exists: true }
      });
      for (const user of usersToUpdate) {
        // Add new user to their management scope
        if (!user.allowedResources.userManagement.users.includes(newUserId)) {
          user.allowedResources.userManagement.users.push(newUserId);
          await user.save();
        }
      }
    }
  } catch (err) {
    console.error('Error updating allowedResources for users:', err);
    // Don't fail registration if permission update fails
  }

  // Add logging for user signup
  try {
    await addLog({
      action: 'Signed Up',
      name: `${result.user?.fullName || result.user?.email || 'User'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'User',
      userId: result.user?._id?.toString() || '-',
      userName: result.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log user signup:', logErr);
  }

  return res.status(201).json(new ApiResponse(true, 'User registered successfully. OTP generated for verification.', {
    user: result.user,
    otp: result.otp
  }));
});

/**
 * Verify registration OTP and activate account
 * Generates reset token for immediate password setup if needed
 */
export const verifySignupOTP = catchAsync(async (req, res) => {
  const { email, otp } = req.body;
  const result = await authService.verifySignupOTP(email, otp);
  return res
    .status(200)
    .json(new ApiResponse(true, result.message, { user: result.user, resetToken: result.resetToken }));
});

/**
 * User Authentication and Session Creation
 * 
 * Process:
 * 1. Validate credentials
 * 2. Check user status (active/inactive)
 * 3. Generate JWT token
 * 4. Create session tracking record
 * 5. Return user profile with role details
 */
export const login = catchAsync(async (req, res) => {
  const result = await authService.login(req.body, req);
  return res.status(200).json(new ApiResponse(true, 'Login successful', result));
});

export const changePassword = catchAsync(async (req, res) => {
  const result = await authService.changePassword(req.body, req);
  return res.status(200).json({
    statusCode: 200,
    success: true,
    message: 'Password changed successfully',
    user: result.user
  });
});

/**
 * Change password for authenticated users
 * Requires current password verification for security
 */
export const protectedChangePassword = catchAsync(async (req, res) => {
  const result = await authService.protectedChangePassword(req.user._id, req.body, req);

  // Add logging for protected password change
  try {
    await addLog({
      action: 'Changed Password',
      name: `${req.user?.fullName || req.user?.email || 'User'}`,
      timestamp: Math.floor(Date.now() / 1000), // Current Unix timestamp
      type: 'User',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log password change:', logErr);
  }

  return res.status(200).json(new ApiResponse(true, 'Password changed successfully', { user: result.user }));
});

export const resetPassword = catchAsync(async (req, res) => {
  const { id } = req.params;
  const result = await authService.resetPassword(id, req.body, req);
  return res.status(200).json({
    statusCode: 200,
    success: true,
    message: 'Password reset successfully. Please login again with new password.',
    user: result.user
  });
});

export const updateUserProfile = catchAsync(async (req, res) => {
  const { id } = req.params;
  const result = await authService.updateProfile(id, req.body, req);
  return res.status(200).json({
    statusCode: 200,
    success: true,
    message: 'User updated successfully',
    data: result.user
  });
});

// ========== AUTHENTICATED USER PROFILE MANAGEMENT ==========

/**
 * Get current user profile from JWT token
 * Returns user data without sensitive information
 */
export const getProfile = catchAsync(async (req, res) => {
  return res.status(200).json(new ApiResponse(true, 'Profile retrieved successfully', { user: req.user }));
});

/**
 * Update authenticated user's profile information
 * Supports profile image, contact info, preferences
 */
export const updateProfile = catchAsync(async (req, res) => {
  const result = await authService.updateProfile(req.user._id, req.body, req);
  return res.status(200).json(new ApiResponse(true, 'Profile updated successfully', { user: result.user }));
});

// ========== ADMIN USER MANAGEMENT ==========

/**
 * Get single user details (admin only)
 * Returns full user profile for admin review
 */
export const getUserById = catchAsync(async (req, res) => {
  const { id } = req.params;
  const user = await authService.getUserById(id);
  return res.status(200).json(new ApiResponse(true, 'User retrieved successfully', { user }));
});

/**
 * Get paginated list of all users (admin only)
 * Used for user management interfaces
 */
export const getAllUsers = catchAsync(async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const result = await authService.getAllUsers(page, limit);
  return res.status(200).json(new ApiResponse(true, 'Users retrieved successfully', result));
});

/**
 * Get user's authentication/login history (admin only)
 * Shows login attempts, IPs, devices for security auditing
 */
export const getUserAuthHistory = catchAsync(async (req, res) => {
  const { id } = req.params;
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const result = await authService.getUserAuthHistory(id, page, limit);
  return res.status(200).json(new ApiResponse(true, 'User authentication history retrieved successfully', result));
});

/**
 * Secure logout with session invalidation
 * Invalidates JWT token and logs the action
 */
export const logout = catchAsync(async (req, res) => {
  // Extract JWT token for session-specific logout
  const token = req.headers.authorization?.split(' ')[1];
  const result = await authService.logout(req.user._id, token);

  // Audit log for logout action
  try {
    await addLog({
      action: 'Logged Out',
      name: `${req.user?.fullName || req.user?.email || 'User'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'User',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    console.error('Failed to log user logout:', logErr);
  }

  return res.status(200).json(new ApiResponse(true, 'Logged out successfully', result));
});

/**
 * Initiate password reset flow with email OTP
 * 
 * Features:
 * - Rate limiting (prevents OTP spam)
 * - IP tracking for security
 * - Resend parameter handling
 * - Email validation
 */
export const forgotPassword = catchAsync(async (req, res) => {
  const { email } = req.body;
  const { resend } = req.query;
  const clientIP = req.ip || req.connection.remoteAddress || req.headers['x-forwarded-for'];
  console.log(`🔐 Forgot password request received - Email: ${email}, Resend: ${resend}, IP: ${clientIP}, Timestamp: ${new Date().toISOString()}`);
  if (!email) {
    console.log(`❌ Forgot password failed - No email provided, IP: ${clientIP}`);
    return res.status(400).json(new ApiResponse(false, 'Email is required', null));
  }
  try {
    const result = await resetService.requestPasswordReset(email);

    // If no user found, send 404 with message
    if (result.code === 404) {
      console.log(`❌ Forgot password failed - User not found, Email: ${email}, IP: ${clientIP}`);
      return res.status(404).json(new ApiResponse(false, result.message, {
        email: email,
        emailSent: false,
        timestamp: new Date().toISOString()
      }));
    }

    // Handle rate limit case (OTP already sent)
    if (result.message === 'OTP already sent') {
      // If resend=1 parameter is present, show rate limit message instead
      if (resend === '1') {
        console.log(`⏰ Rate limit with resend parameter - Email: ${email}, IP: ${clientIP}, Remaining cooldown: ${result.data?.remainingCooldown} seconds`);
        return res.status(429).json(new ApiResponse(false, `Please wait ${result.data?.remainingCooldown} seconds before requesting another reset`, {
          email: email,
          emailSent: false,
          remainingCooldown: result.data?.remainingCooldown,
          timestamp: new Date().toISOString()
        }));
      }
      
      // Default behavior: show "OTP already sent" message
      console.log(`📧 OTP already sent - Email: ${email}, IP: ${clientIP}, Remaining cooldown: ${result.data?.remainingCooldown} seconds`);
      return res.status(200).json(new ApiResponse(true, 'OTP already sent to your email. Please check your inbox.', {
        email: email,
        emailSent: true,
        remainingCooldown: result.data?.remainingCooldown,
        timestamp: new Date().toISOString()
      }));
    }

    // Otherwise, handle normally
    const message = result.data?.emailSent ? 'Mail sent' : 'Mail not sent';
    const statusCode = result.data?.emailSent ? 200 : 400;
    console.log(`🔐 Forgot password response - Email: ${email}, Status: ${statusCode}, Message: ${message}, IP: ${clientIP}`);
    return res.status(statusCode).json(new ApiResponse(result.data?.emailSent, message, {
      email: email,
      emailSent: result.data?.emailSent || false,
      timestamp: new Date().toISOString()
    }));
  } catch (error) {
    console.error(`🚨 Forgot password error - Email: ${email}, IP: ${clientIP}, Error: ${error.message}`);
    throw error; // Let catchAsync handle the error response
  }
});

/**
 * Verify OTP for password reset
 * Step 2 of password reset flow
 */
export const verifyResetOTP = catchAsync(async (req, res) => {
  const { email, otp } = req.body;
  const clientIP = req.ip || req.connection.remoteAddress || req.headers['x-forwarded-for'];
  console.log(`🔢 OTP verification request - Email: ${email}, IP: ${clientIP}, Timestamp: ${new Date().toISOString()}`);
  try {
    const result = await resetService.verifyResetOTP(email, otp);
    console.log(`✅ OTP verification successful - Email: ${email}, IP: ${clientIP}`);
    return res.status(200).json(new ApiResponse(true, result.message, null));
  } catch (error) {
    console.error(`❌ OTP verification failed - Email: ${email}, IP: ${clientIP}, Error: ${error.message}`);
    throw error; // Let catchAsync handle the error response
  }
});

/**
 * Complete password reset with new password
 * Final step of password reset flow
 */
export const newResetPassword = catchAsync(async (req, res) => {
  const { email, newPassword, token } = req.body;
  const clientIP = req.ip || req.connection.remoteAddress || req.headers['x-forwarded-for'];
  console.log(`🔄 New password reset request - Email: ${email}, Has token: ${!!token}, IP: ${clientIP}, Timestamp: ${new Date().toISOString()}`);
  try {
    const result = await resetService.resetPassword(email, token, newPassword);
    console.log(`✅ Password reset successful - Email: ${email}, IP: ${clientIP}`);
    return res.status(200).json(new ApiResponse(true, result.message, null));
  } catch (error) {
    console.error(`❌ Password reset failed - Email: ${email}, IP: ${clientIP}, Error: ${error.message}`);
    throw error; // Let catchAsync handle the error response
  }
});

// ========== ROLE MANAGEMENT ==========

/**
 * Get available roles for dropdowns and UI
 * Supports different format options (array/object)
 */
export const getRoles = catchAsync(async (req, res) => {
  const { format } = req.query;
  const roles = await authService.getRoles(format);
  return res.status(200).json(new ApiResponse(true, 'Roles retrieved successfully', { roles }));
});