/**
 * Device Controller - IoT Device Management Business Logic
 * 
 * Flow: routes → CONTROLLER → service → database/MQTT
 * 
 * Responsibilities:
 * - Device discovery and configuration workflow
 * - Channel management (LED/shade/sensor controls)
 * - Real-time device status tracking
 * - Location-based device organization
 * - User permission filtering
 * - MQTT communication coordination
 * - Audit logging for device actions
 * 
 * Device Types:
 * - Own Devices: BA-series smart building devices
 * - Third-party: External IoT devices
 * 
 * Key Operations:
 * - Discovery → Configuration → Channel Management → Control
 * - Relationship management (groups, scenes, sensors, templates)
 * - Cascade cleanup when devices/channels are removed
 */

/**
 * Update channel properties including install/uninstall status
 * Handles LED, shade, and sensor channel configurations
 */
export const updateDeviceChannelName = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }
  const { deviceId, channelId } = req.params;
  
  if (!channelId) {
    return res.status(400).json(
      new ApiResponse(false, 'Channel ID is required in URL parameters', null)
    );
  }
  
  // Pass the entire request body as updateData
  const updatedChannel = await deviceService.updateDeviceChannelName(
    deviceId, 
    channelId, 
    req.body, // Pass the entire body as updateData
    req.user
  );

  // Add logging for device channel update
  try {
    let actionType = 'Channel Updated';
    
    if (req.body.installed === false || req.body.properties?.installed === false) {
      actionType = 'Channel Uninstalled';
    } else if (req.body.installed === true || req.body.properties?.installed === true) {
      actionType = 'Channel Installed';
    }
    
    await addLog({
      action: actionType,
      name: `${deviceId} - Channel ${channelId}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Device',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log device channel update:', logErr);
  }
  
  return res.status(200).json(
    new ApiResponse(true, 'Channel updated successfully', { channel: updatedChannel })
  );
});
/**
 * Get channel data by device ID
 */
/**
 * Get all channels for a specific device
 * Returns LED, shade, and sensor channels with installation status
 */
export const getDeviceChannels = catchAsync(async (req, res) => {
  const { deviceId } = req.params;
  const channels = await deviceService.getDeviceChannels(deviceId);
  return res.status(200).json(
    new ApiResponse(true, 'Device channels retrieved successfully', { channels })
  );
});

// Service imports and utilities
import * as deviceService from '../services/device.service.js';
import { catchAsync } from '../utils/catchAsync.js';
import { ApiResponse } from '../utils/ApiResponse.js';
import { getConfig } from '../config/env.js';
import axios from 'axios';
const { addLog } = await import('../services/log.service.js');
/**
 * Toggle device online/offline status
 * Affects device availability for control operations
 */
export const changeDeviceStatus = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }
  const { deviceId } = req.params;
  const { status } = req.body;
  if (!['Active', 'Inactive'].includes(status)) {
    return res.status(400).json(
      new ApiResponse(false, 'Invalid status value. Must be "Active" or "Inactive".', null)
    );
  }
  const updatedDevice = await deviceService.changeDeviceStatus(deviceId, status, req.user);

  // Add logging for device status change
  try {
    await addLog({
      action: 'Status Updated',
      name: `${updatedDevice.device_id || updatedDevice.name || deviceId}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Device',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log device status update:', logErr);
  }

  return res.status(200).json(
    new ApiResponse(true, 'Device status updated successfully', {
      device: updatedDevice,
      updatedAt: updatedDevice.updatedAt
    })
  );
});

/**
 * Get unconfigured devices available for setup
 * 
 * Process:
 * 1. Filter devices with configure_flag = false
 * 2. Apply user permission scoping
 * 3. Separate own vs third-party devices
 * 4. Return paginated results with search capabilities
 */
export const getDeviceDiscoveryList = catchAsync(async (req, res) => {
  // Extract user's device discovery permissions
  let allowedDiscoveredDeviceIds = [];
  if (req.user && req.user.allowedResources && req.user.allowedResources.deviceManagement && Array.isArray(req.user.allowedResources.deviceManagement.discoveredDevices)) {
    allowedDiscoveredDeviceIds = req.user.allowedResources.deviceManagement.discoveredDevices;
  }

  const queryParams = {
    ...req.query,
    allowedDiscoveredDeviceIds
  };
  const result = await deviceService.getDeviceDiscoveryList(queryParams);

  return res.status(200).json(
    new ApiResponse(
      true,
      'Device discovery list retrieved successfully',
      {
        own_devices: result.own_devices,
        third_party_devices: result.third_party_devices,
        summary: result.summary
      }
    )
  );
});

/**
 * Configure discovered device for production use
 * 
 * Process:
 * 1. Assign device to campus/building/floor/zone
 * 2. Set communication ports
 * 3. Set configure_flag = true
 * 4. Initialize channel capabilities
 * 5. Make device available for channel management
 */
export const configureDevice = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const configuredDevice = await deviceService.configureDevice(req.body, req.user);

  // Add logging for device configuration
  try {
    await addLog({
      action: 'Configured',
      name: `${configuredDevice.device_id || configuredDevice.name || 'Device'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Device',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log device configuration:', logErr);
  }

  return res.status(200).json(
    new ApiResponse(
      true,
      'Device configured successfully',
      configuredDevice
    )
  );
});

/**
 * Get all devices organized by ownership type
 * Separates BA-series (own) from third-party devices with location info
 */
export const getDeviceList = catchAsync(async (req, res) => {
  const result = await deviceService.getDeviceList(req.query);

  return res.status(200).json(
    new ApiResponse(
      true,
      'Device list retrieved successfully',
      {
        own_devices: result.own_devices,
        third_party_devices: result.third_party_devices,
        summary: result.summary
      }
    )
  );
});

/**
 * Get device by ID with full details
 */
export const getDeviceById = catchAsync(async (req, res) => {
  const { deviceId } = req.params;

  const device = await deviceService.getDeviceById(deviceId);

  return res.status(200).json(
    new ApiResponse(true, 'Device retrieved successfully', { device })
  );
});

/**
 * Get UI tab counter data
 * Returns counts for discovered vs configured devices for navigation
 */
export const getTabCounter = catchAsync(async (req, res) => {
  console.log('getTabCounter called');
  try {
    const result = await deviceService.getTabCounter();
    console.log('getTabCounter result:', result);
    res.status(200).json({
      success: true,
      message: 'Tab counter retrieved successfully',
      data: result
    });
  } catch (error) {
    console.error('getTabCounter error:', error);
    res.status(500).json({
      success: false,
      message: error.message,
      data: null
    });
  }
});

/**
 * Manually add new device (admin/testing purposes)
 * Creates device record with basic configuration
 */
export const addDevice = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const device = await deviceService.addDevice(req.body, req.user);

  return res.status(201).json(
    new ApiResponse(true, 'Device created successfully', { device })
  );
});

/**
 * Add third-party (non-BA series) device
 * Handles external IoT devices with different capabilities
 */
export const addThirdPartyDevice = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const device = await deviceService.addThirdPartyDevice(req.body, req.user);

  return res.status(201).json(
    new ApiResponse(true, 'Device created successfully', { device })
  );
});

/**
 * Update device
 */
export const updateDevice = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { deviceId } = req.params;
  const updatedDevice = await deviceService.updateDevice(deviceId, req.body, req.user);

  return res.status(200).json(
    new ApiResponse(true, 'Device updated successfully', {
      device: updatedDevice,
      updatedAt: updatedDevice.updatedAt
    })
  );
});

/**
 * Update device
 */
export const updateThirdPartyDevice = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { deviceId } = req.params;
  const updatedDevice = await deviceService.updateDevice(deviceId, req.body, req.user);

  return res.status(200).json(
    new ApiResponse(true, 'Device updated successfully', {
      device: updatedDevice,
      updatedAt: updatedDevice.updatedAt
    })
  );
});

/**
 * Delete device channel
 */
export const deleteDeviceChannel = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { deviceId, channelId } = req.params;
  const updatedDevice = await deviceService.deleteDeviceChannel(deviceId, channelId, req.user);

  return res.status(200).json(
    new ApiResponse(true, 'Device updated successfully', {
      device: updatedDevice,
      updatedAt: updatedDevice.updatedAt
    })
  );
});

/**
 * Soft delete device with cascade cleanup
 * 
 * Process:
 * 1. Set is_delete = true, configure_flag = false
 * 2. Remove from all groups, scenes, sensors, templates
 * 3. Notify MQTT service for device removal
 * 4. Log deletion action
 */
export const deleteDevice = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  // Device ID from URL path parameter
  const { deviceId } = req.params;

  // Get device name before deletion for logging
  let deviceName = deviceId; // Use deviceId as fallback
  try {
    const existingDevice = await deviceService.getDeviceById(deviceId);
    deviceName = existingDevice?.device_id || existingDevice?.name || deviceId;
  } catch (err) {
    // If device doesn't exist, use deviceId as name
    deviceName = deviceId;
  }

  let device = await deviceService.getDeviceById(deviceId);
  if (device) {
    // Update is_delete flag and configure_flag
    device = await deviceService.deleteDevice(deviceId, req.user);
  } else {
    // Create device with is_delete and configure_flag
    device = await deviceService.addDevice({ device_id: deviceId, is_delete: true, configure_flag: false }, req.user);
  }

  // Remove device from related collections
  await deviceService.removeDeviceFromRelatedCollections(deviceId, req.user);

  const conf = {
      MQTT_HOST: getConfig().mqttHost,
      MQTT_PORT: getConfig().mqttPort
  };
  const response = await axios.post(`http://${conf.MQTT_HOST}:${conf.MQTT_PORT}/mqtt/deleteDevice`, { "deviceId": deviceId  });

  // Add logging for device deletion
  try {
    await addLog({
      action: 'Deleted',
      name: deviceName,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Device',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log device deletion:', logErr);
  }

  return res.status(200).json(
    new ApiResponse(true, 'Device deleted successfully', {
      device,
      deletedAt: device.updatedAt || device.createdAt
    })
  );
});

/**
 * Delete third party device (soft delete)
 */
export const deletethirdPartyDevice = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  // deviceId comes from URL like devices/BAM-D71534
  const { deviceId } = req.params;

  // Get device name before deletion for logging
  let deviceName = deviceId; // Use deviceId as fallback
  try {
    const existingDevice = await deviceService.getDeviceById(deviceId);
    deviceName = existingDevice?.device_id || existingDevice?.name || deviceId;
  } catch (err) {
    // If device doesn't exist, use deviceId as name
    deviceName = deviceId;
  }

  let device = await deviceService.getDeviceById(deviceId);
  if (device) {
    // Update is_delete flag and configure_flag
    device = await deviceService.updateDevice(deviceId, { is_delete: true, configure_flag: false }, req.user);
  } else {
    // Create device with is_delete and configure_flag
    device = await deviceService.addDevice({ device_id: deviceId, is_delete: true, configure_flag: false }, req.user);
  }

  // Add logging for device deletion
  try {
    await addLog({
      action: 'Deleted',
      name: deviceName,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Device',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log device deletion:', logErr);
  }

  return res.status(200).json(
    new ApiResponse(true, 'Device deleted successfully', {
      device,
      deletedAt: device.updatedAt || device.createdAt
    })
  );
});

/**
 * Get own devices only (devices with "BA" in type)
 */
export const getOwnDevices = catchAsync(async (req, res) => {
  const result = await deviceService.getDeviceList(req.query);

  return res.status(200).json(
    new ApiResponse(
      true,
      'Own devices retrieved successfully',
      {
        devices: result.own_devices,
        count: result.own_devices.length,
        summary: {
          total_own_devices: result.own_devices.length,
          active_own_devices: result.own_devices.filter(d => d.status === 'Active').length,
          inactive_own_devices: result.own_devices.filter(d => d.status === 'Inactive').length
        }
      }
    )
  );
});

/**
 * Get third-party devices only (devices without "BA" in type)
 */
export const getThirdPartyDevices = catchAsync(async (req, res) => {
  const result = await deviceService.getDeviceList(req.query);

  return res.status(200).json(
    new ApiResponse(
      true,
      'Third-party devices retrieved successfully',
      {
        devices: result.third_party_devices,
        count: result.third_party_devices.length,
        summary: {
          total_third_party_devices: result.third_party_devices.length,
          active_third_party_devices: result.third_party_devices.filter(d => d.status === 'Active').length,
          inactive_third_party_devices: result.third_party_devices.filter(d => d.status === 'Inactive').length
        }
      }
    )
  );
});

/**
 * Get configured devices with channel installation details
 * 
 * Features:
 * - Only devices with configure_flag = true
 * - Channel counts (LED, shade, sensor)
 * - Location information
 * - User permission filtering
 * - Search and pagination support
 */
export const getConfiguredDevicesList = catchAsync(async (req, res) => {
  // Extract user's configured device permissions
  let allowedConfiguredDeviceIds = [];
  if (req.user && req.user.allowedResources && req.user.allowedResources.deviceManagement && Array.isArray(req.user.allowedResources.deviceManagement.configuredDevices)) {
    allowedConfiguredDeviceIds = req.user.allowedResources.deviceManagement.configuredDevices;
  }
  const query = { ...req.query, is_delete: false, allowedConfiguredDeviceIds };
  const result = await deviceService.getConfiguredDevicesList(query, req.user);

  return res.status(200).json(
    new ApiResponse(
      true,
      'Configured devices list retrieved successfully',
      {
        configured_devices: result.configured_devices,
        summary: result.summary
      }
    )
  );
});

/**
 * Get sensors list by device ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
export const getDeviceSensorsList = async (req, res) => {
  try {
    const { deviceId } = req.params;
    
    const sensorsData = await getDeviceSensors(deviceId);
    
    res.status(200).json({
      success: true,
      message: 'Device sensors retrieved successfully',
      data: sensorsData
    });
    
  } catch (error) {
    console.error('Error in getDeviceSensorsList:', error);
    
    if (error.message === 'Device not found') {
      return res.status(404).json({
        success: false,
        message: 'Device not found',
        data: null
      });
    }
    
    res.status(500).json({
      success: false,
      message: error.message,
      data: null
    });
  }
};
import { getDeviceSensors } from '../services/device.service.js';

/**
 * Get devices list with installed channels - supports search and filters
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
export const getDevicesListWithChannels = catchAsync(async (req, res) => {
  const result = await deviceService.getDevicesListWithChannels(req.query, req.user);

  return res.status(200).json(
    new ApiResponse(
      true,
      'Devices list with channels retrieved successfully',
      {
        devices: result.devices,
        pagination: result.pagination,
        summary: result.summary
      }
    )
  );
});

/**
 * Get devices list with installed sensor channels
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
export const getDeviceSensorList = catchAsync(async (req, res) => {
  const result = await deviceService.getDeviceSensorList(req.query, req.user);

  return res.status(200).json(
    new ApiResponse(
      true,
      'Devices list with sensors retrieved successfully',
      result
    )
  );
});
