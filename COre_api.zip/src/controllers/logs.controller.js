/**
 * Logs Controller - System audit trail and monitoring management
 * 
 * Flow: logs.routes.js → logs.controller.js → logs.service.js → MongoDB Collections
 * 
 * Orchestrates system logging operations:
 * - MQTT communication logs for device troubleshooting
 * - Event audit trails for compliance and monitoring
 * - Excel export for offline analysis and reporting
 * - Campus hierarchy context for filtered log views
 * - Real-time system health and performance monitoring
 */

import * as logsService from '../services/logs.service.js';
import { catchAsync } from '../utils/catchAsync.js';
import { ApiResponse } from '../utils/ApiResponse.js';

/**
 * Get MQTT logs with filtering and pagination
 * Supports both API response and Excel download based on download=1 parameter
 * Filters: device_id, topic, channeltype, date ranges, search terms
 */
export const getMqttLogs = catchAsync(async (req, res) => {
  if (req.query.download == 1) {
    const buffer = await logsService.exportMqttLogsToExcel(req.query, req.user);
    const devicePart = req.query.device_id ? `-${req.query.device_id}` : '';
    const filename = `mqtt-logs${devicePart}-${new Date().toISOString().split('T')[0]}.xlsx`;
    
    // Set proper headers for Excel file download
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', buffer.length);
    res.setHeader('x-skip-encryption', '1');
    
    // Send the Excel file buffer directly
    return res.send(buffer);
  }

  const result = await logsService.getMqttLogs(req.query, req.user);
  return res.status(200).json(
    new ApiResponse(
      true,
      'MQTT logs retrieved successfully',
      {
        logs: result.logs,
        pagination: result.pagination,
        summary: result.summary
      }
    )
  );
});

/**
 * Get event logs with specific audit trail fields
 * Returns: _id, type, name, action, timestamp for compliance tracking
 * Supports Excel export for offline audit analysis
 */
export const getEventLogs = catchAsync(async (req, res) => {
  if (req.query.download == 1) {
    const buffer = await logsService.exportEventLogsToExcel(req.query, req.user);
    const devicePart = req.query.device_id ? `-${req.query.device_id}` : '';
    const filename = `event-logs${devicePart}-${new Date().toISOString().split('T')[0]}.xlsx`;
    
    // Set proper headers for Excel file download
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', buffer.length);
    res.setHeader('x-skip-encryption', '1');
    
    // Send the Excel file buffer directly
    return res.send(buffer);
  }

  const result = await logsService.getEventLogs(req.query, req.user);
  return res.status(200).json(
    new ApiResponse(
      true,
      'Event logs retrieved successfully',
      {
        logs: result.logs,
        pagination: result.pagination,
        summary: result.summary
      }
    )
  );
});

/**
 * Get campus hierarchy for log filtering context
 * Returns nested structure: campus → building → floor → zone
 * Includes isChecked based on user permissions for selective log viewing
 * Used by frontend to provide hierarchical log filtering options
 */
export const getCampusHierarchy = catchAsync(async (req, res) => {
  const result = await logsService.getCampusHierarchy(req.user);

  return res.status(200).json(
    new ApiResponse(
      true,
      'Campus hierarchy retrieved successfully',
      result
    )
  );
});

/**
 * Export MQTT logs to Excel
 */
export const exportMqttLogsToExcel = catchAsync(async (req, res) => {
  const buffer = await logsService.exportMqttLogsToExcel(req.query, req.user);
  
  const filename = `mqtt-logs-${new Date().toISOString().split('T')[0]}.xlsx`;
  
  // Set proper headers for Excel file download
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.setHeader('Content-Length', buffer.length);
  res.setHeader('x-skip-encryption', '1');
  
  return res.send(buffer);
});

/**
 * Export Event logs to Excel
 */
export const exportEventLogsToExcel = catchAsync(async (req, res) => {
  const buffer = await logsService.exportEventLogsToExcel(req.query, req.user);
  
  const filename = `event-logs-${new Date().toISOString().split('T')[0]}.xlsx`;
  
  // Set proper headers for Excel file download
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.setHeader('Content-Length', buffer.length);
  res.setHeader('x-skip-encryption', '1');
  
  return res.send(buffer);
});
