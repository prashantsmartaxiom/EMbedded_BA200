/**
 * Dashboard Controller - Real-time analytics and monitoring orchestration
 * 
 * Flow: dashboard.routes.js → dashboard.controller.js → dashboard.service.js → MongoDB Collections
 * 
 * Orchestrates dashboard operations:
 * - Campus hierarchy analytics with filtered device statistics
 * - Zone-level device monitoring (LEDs, shades, sensors) with status aggregation
 * - Device information with scene associations and performance metrics
 * - Device group memberships for operational context
 * - Alert monitoring for proactive system management
 */

import { ApiResponse } from '../utils/ApiResponse.js';
import { catchAsync } from '../utils/catchAsync.js';
import * as dashboardService from '../services/dashboard.service.js';

/**
 * Get comprehensive dashboard summary with campus hierarchy analytics
 * Filters by campus/building/floor/zone IDs for scoped analytics
 * Returns device counts, zone listings, and campus statistics
 */
export const getDashboard = catchAsync(async (req, res) => {
  const data = await dashboardService.getDashboardData(req.body || {});
  return res.status(200).json(new ApiResponse(true, 'Dashboard data retrieved', data));
});

/**
 * Get zone-level device statistics aggregated by type
 * Returns LED/shade/sensor counts with status breakdowns (on/off, open/closed, active/inactive)
 * Filters by zone IDs for targeted analytics
 */
export const getZoneStats = catchAsync(async (req, res) => {
  const data = await dashboardService.getZoneStats(req.body || {});
  return res.status(200).json(new ApiResponse(true, 'Zone stats retrieved', data));
});

/**
 * Get comprehensive device information with scene associations
 * Returns device scenes, channel counts, execution history, and operational metrics
 * Validates device existence and filters by active scenes only
 */
export const getDeviceInfo = catchAsync(async (req, res) => {
  const { deviceId } = req.body;
  
  if (!deviceId) {
    return res.status(400).json(new ApiResponse(false, 'Device ID is required'));
  }

  const data = await dashboardService.getDeviceInfo(deviceId);
  return res.status(200).json(new ApiResponse(true, 'Device information retrieved successfully', data));
});

/**
 * Get all active groups containing a specific device
 * Returns group view data with device associations and operational context
 * Excludes location information for streamlined response
 */
export const getDeviceGroups = catchAsync(async (req, res) => {
  const { deviceId } = req.params;
  const data = await dashboardService.getDeviceGroups(deviceId);
  return res.status(200).json(new ApiResponse(true, 'Device groups retrieved successfully', data));
});

/**
 * Get device-specific alerts with pagination
 * Filters by device ID and returns paginated alert history for monitoring
 * Provides pagination metadata for UI navigation
 */
export const getAlerts = catchAsync(async (req, res) => {
  const { deviceId } = req.params;
  const data = await dashboardService.getAlerts({ ...req.query, deviceId });
  return res.status(200).json(new ApiResponse(true, 'Alerts retrieved successfully', data));
});


