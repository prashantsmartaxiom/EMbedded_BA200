/**
 * Zone Controller - Floor zone management business logic
 * 
 * Manages zone lifecycle within the floor hierarchy of the smart building platform.
 * Handles device association, user access control, and intelligent control cleanup.
 * Flow: zone.routes.js → zone.controller.js → zone.service.js → CampusZone model
 * 
 * Key Operations:
 * - Zone CRUD with floor association and device management
 * - User access filtering via allowedResources.campusManagement.zones
 * - Device state management during deletion (move to Discovered)
 * - Comprehensive zone statistics with device counts
 * - Hierarchy context (campus → building → floor → zone)
 * - Intelligent control cleanup during zone operations
 */

import * as zoneService from '../services/zone.service.js';
import * as optimizedService from '../services/optimized.service.js';
import { catchAsync } from '../utils/catchAsync.js';
import { ApiResponse } from '../utils/ApiResponse.js';
import { getAuthorizedList } from '../utils/authorizedList.js';
import { CampusZone } from '../models/CampusZone.js';
import { filterByUserResourceAccess } from '../utils/filterByUserAccess.js';
import { buildUserFilter } from '../utils/buildUserFilter.js';
const { addLog } = await import('../services/log.service.js');

// Get all zones for specific floor with device counts
// Returns floor-scoped zone list with pagination and search capabilities
export const getZonesByFloor = catchAsync(async (req, res) => {
  const { floorId } = req.params;
  const result = await zoneService.getZonesByFloor(floorId, req.query);
  
  return res.status(200).json(
    new ApiResponse(
      true, 
      'Zones retrieved successfully', 
      {
        zones: result.zones,
        pagination: result.pagination
      }
    )
  );
});

// Add a new zone to a floor
export const addZone = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { floorId } = req.params;
  const zoneData = { ...req.body, floorId };
  
  const zone = await zoneService.addZone(zoneData, req.user);

  // Add logging for zone creation
  try {
    await addLog({
      action: 'Created',
      name: `${zone.name || 'Zone'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Zone',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log zone creation:', logErr);
  }
  
  return res.status(201).json(
    new ApiResponse(true, 'Zone created successfully', { zone })
  );
});

// Create new zone with direct floor ID specification
// - Validates floor existence and zone name uniqueness
// - Updates floor's zones array and user allowedResources
// - Manages user campusData for immediate zone access
export const addZoneWithIds = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const zone = await zoneService.addZoneWithIds(req.body, req.user);

  // Add logging for zone creation
  try {
    await addLog({
      action: 'Created',
      name: `${zone.name || 'Zone'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Zone',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log zone creation:', logErr);
  }
  
  return res.status(201).json(
    new ApiResponse(true, 'Zone created successfully', { zone })
  );
});

// Get zone by ID
export const getZoneById = catchAsync(async (req, res) => {
  const { zoneId } = req.params;
  
  const zone = await zoneService.getZoneById(zoneId);
  
  return res.status(200).json(
    new ApiResponse(true, 'Zone retrieved successfully', { zone })
  );
});

// Get comprehensive zone details with full hierarchy context
// Returns complete campus → building → floor → zone chain with device statistics
// Includes configured device count and zone status information
export const getZoneDetails = catchAsync(async (req, res) => {
  const { zoneId } = req.params;
  
  const zoneDetails = await zoneService.getZoneDetails(zoneId);
  
  return res.status(200).json(
    new ApiResponse(true, 'Zone details retrieved successfully', { zone: zoneDetails })
  );
});

// Get paginated zones list with user access control and comprehensive statistics
// Uses optimized service for database-level filtering and hierarchy population
// Returns zone counts, device statistics, and full campus hierarchy context
export const getZoneList = catchAsync(async (req, res) => {
  // Build user-specific filter for database-level filtering
  const userFilter = buildUserFilter(req.user, 'zones');

  // Get zones with efficient database filtering and pagination
  const result = await optimizedService.getOptimizedZones({
    ...req.query,
    userFilter
  });

  // Use counts from DB (global wrt status) and compute device totals from current page
  const { totalNonDeleted, totalActive, totalInactive, ...paginationRest } = result.pagination;
  const totalDevices = result.zones.reduce((sum, zone) => sum + (zone.deviceCount || 0), 0);

  const totals = {
    totalZones: totalNonDeleted || (paginationRest.totalRecords || 0),
    totalActive: totalActive || 0,
    totalInactive: totalInactive || 0,
    totalDevices,
    totalActiveDevices: totalDevices
  };

  return res.status(200).json(
    new ApiResponse(
      true,
      'Zone list retrieved successfully',
      {
        zones: result.zones,
        pagination: paginationRest,
        totals,
        totalNonDeleted: totals.totalZones,
        totalActive: totals.totalActive,
        totalInactive: totals.totalInactive
      }
    )
  );
});
// export const getZoneList = catchAsync(async (req, res) => {
//   const result = await getAuthorizedList({
//     user: req.user,
//     moduleKey: 'CAMPUS_MANAGEMENT',
//     resourceKey: 'zones',               // Maps to 'zone_management' permission
//     model: CampusZone,
//     queryParams: req.query,
//     baseFilter: { isDelete: false },    // Only non-deleted zones
//     populate: [
//       { 
//         path: 'floorId', 
//         select: 'name buildingId',
//         populate: {
//           path: 'buildingId',
//           select: 'name campusId',
//           populate: {
//             path: 'campusId',
//             select: 'name location'
//           }
//         }
//       }
//     ],
//     transformResult: (doc) => {
//       // Format date as DD MM YYYY
//       const formatDate = (date) => {
//         const d = new Date(date);
//         const day = String(d.getDate()).padStart(2, '0');
//         const month = String(d.getMonth() + 1).padStart(2, '0');
//         const year = d.getFullYear();
//         return `${day} ${month} ${year}`;
//       };

//       return {
//         _id: doc._id,
//         type: doc.type,
//         description: doc.description,
//         createdAt: doc.createdAt,
//         zoneName: doc.name,
//         buildingName: doc.floorId?.buildingId?.name || '',
//         floorName: doc.floorId?.name || '',
//         deviceCount: 0, // TODO: Calculate actual device count
//         status: doc.status === 1 ? 'active' : 'inactive',
//         createdOn: formatDate(doc.createdAt)
//       };
//     }
//   });

//   // Calculate totals from the authorized data
//   const totalActive = result.data.filter(zone => zone.status === 'active').length;
//   const totalInactive = result.data.filter(zone => zone.status === 'inactive').length;
//   const totalDevices = result.data.reduce((sum, zone) => sum + zone.deviceCount, 0);

//   return res.status(200).json(
//     new ApiResponse(
//       true, 
//       'Zone list retrieved successfully', 
//       {
//         zones: result.data,
//         pagination: {
//           currentPage: result.page,
//           totalPages: Math.ceil(result.total / result.limit),
//           totalRecords: result.total,
//           perPage: result.limit,
//           hasNextPage: result.page < Math.ceil(result.total / result.limit),
//           hasPrevPage: result.page > 1
//         },
//         totals: {
//           totalZones: result.total,
//           totalActive: totalActive,
//           totalInactive: totalInactive,
//           totalDevices: totalDevices,
//           totalActiveDevices: totalDevices // Assuming all devices are active for now
//         }
//       }
//     )
//   );
// });

// Update zone information (name and description)
export const updateZone = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { zoneId } = req.params;
  const updateData = req.body;
  
  const zone = await zoneService.updateZone(zoneId, updateData, req.user);

  // Add logging for zone update
  try {
    await addLog({
      action: 'Updated',
      name: `${zone.name || 'Zone'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Zone',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log zone update:', logErr);
  }
  
  return res.status(200).json(
    new ApiResponse(true, 'Zone updated successfully', { zone })
  );
});

// Update zone status
export const updateZoneStatus = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { zoneId } = req.body;
  const { status } = req.body;
  
  const zone = await zoneService.updateZoneStatus(zoneId, status, req.user);

  // Add logging for zone status update
  try {
    await addLog({
      action: 'Status Updated',
      name: `${zone.name || 'Zone'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Zone',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log zone status update:', logErr);
  }
  
  return res.status(200).json(
    new ApiResponse(true, 'Zone status updated successfully', { zone })
  );
});

// Delete zone with device state management and intelligent control cleanup
// - Moves all zone devices to 'Discovered' state (preserves hardware)
// - Removes devices from groups, scenes, sensors, templates
// - Permanently deletes intelligent control associations
export const deleteZone = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { zoneId } = req.body;

  // Get zone name before deletion for logging
  let zoneName = 'Zone';
  try {
    const zoneToDelete = await zoneService.getZoneById(zoneId);
    zoneName = zoneToDelete?.name || 'Zone';
  } catch (err) {
    // If we can't get the zone name, use default
    zoneName = 'Zone';
  }
  
  const zone = await zoneService.deleteZone(zoneId, req.user);

  // Add logging for zone deletion
  try {
    await addLog({
      action: 'Deleted',
      name: zoneName,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Zone',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log zone deletion:', logErr);
  }
  
  return res.status(200).json(
    new ApiResponse(true, 'Zone deleted successfully. All devices moved to Discovered state and intelligent control data permanently deleted.', zone)
  );
});

// Get all zones without pagination for UI components
// Used for dropdowns, selection lists, and multi-select components
// Supports filtering by campus, building, floor for scoped selections
export const getAllZones = catchAsync(async (req, res) => {
  const result = await zoneService.getAllZones(req.query);
  
  return res.status(200).json(
    new ApiResponse(
      true, 
      result.message, 
      {
        zones: result.zones,
        totalCount: result.totalCount
      }
    )
  );
});
