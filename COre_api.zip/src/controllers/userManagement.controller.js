
/**
 * User Management Controller - Business Logic Layer
 * 
 * Flow: routes → CONTROLLER → service → database
 * 
 * Responsibilities:
 * - User authentication validation
 * - Request/response formatting
 * - Profile image URL generation
 * - User action logging
 * - Role-based permission checks
 * - Campus assignment management
 * 
 * Key Features:
 * - Complete user lifecycle management
 * - Role-based access control (RBAC)
 * - Permission matrix handling
 * - Module accessibility control
 * - Image upload/management
 * - Audit logging for all actions
 */
import { ApiResponse } from '../utils/ApiResponse.js';
import { catchAsync } from '../utils/catchAsync.js';
import * as userManagementService from '../services/userManagement.service.js';
import fs from 'fs';
import path from 'path';
let imageURL = null;
const baseUrl = process.env.APP_URL || 'http://localhost:4000';
/**
 * Create new user with role assignment and permissions
 * 
 * Process:
 * 1. Validate authentication
 * 2. Create user via service (handles password hashing, role assignment)
 * 3. Log user creation action
 * 4. Return created user data
 * 
 * Includes: Profile image processing, role-based permissions setup
 */
export const addUser = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const user = await userManagementService.addUser(req.body, req.user);

  // Add logging for user creation
  try {
    const { addLog } = await import('../services/log.service.js');
    await addLog({
      action: 'Created',
      name: `${user.fullName}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'User',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log user creation:', logErr);
  }

  return res.status(201).json(
    new ApiResponse(true, 'User created successfully', { user })
  );
});

/**
 * Get paginated user list with advanced filtering
 * 
 * Features:
 * - Search across multiple fields (name, email)
 * - Filter by campus, role, status
 * - User permission-based filtering (only shows allowed users)
 * - Profile image URL attachment
 * - Sorting and pagination
 */
export const getUserList = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  // Extract query parameters with defaults
  const {
    search,
    campus,
    role,
    fullName,
    email,
    filterRole,
    page = 1,
    limit = 10,
    status = '',        // accepts '1' (active) or '0' (inactive)
    sortBy = 'createdDate',
    sortOrder = 'desc'
  } = req.query;

  // Extract user's permission scope - only show users they can manage
  let allowedUserIds = [];
  if (req.user && req.user.allowedResources && req.user.allowedResources.userManagement && Array.isArray(req.user.allowedResources.userManagement.users)) {
    allowedUserIds = req.user.allowedResources.userManagement.users;
  }
  const queryParams = {
    search: search?.trim() || '',
    campus: campus?.trim() || '',
    role: role?.trim() || '',
    filters: {
      fullName: fullName?.trim() || '',
      email: email?.trim() || '',
      role: filterRole?.trim() || ''
    },
    page: Number(page) || 1,
    limit: Number(limit) || 10,
    status: status?.toString().trim(),      // pass through
    sortBy: sortBy?.trim(),
    sortOrder: sortOrder?.trim(),
    allowedUserIds
  };

  const result = await userManagementService.getUserList(queryParams);

  // Attach profile image URLs from filesystem
  if (result && Array.isArray(result.users)) {
    result.users = result.users.map(user => {
      let imageURL = null;
      // Check if profile image file exists in public/images/users/
      if (user.profileImage) {
        const extMatch = user.profileImage.match(/\.([a-zA-Z0-9]+)$/);
        const ext = extMatch ? extMatch[1] : 'jpeg';
        const imageFilePath = path.resolve('public/images/users', `${user._id}.${ext}`);
        if (fs.existsSync(imageFilePath)) {
          imageURL = `${baseUrl}/images/users/${user._id}.${ext}`;
        }
      }
      return { ...user, ImageUrl: imageURL };
    });
  }

  return res.status(200).json(
    new ApiResponse(true, 'Users retrieved successfully', result)
  );
});

/**
 * Get single user details with role info and logs
 * 
 * Process:
 * 1. Fetch user data with role information
 * 2. Attach profile image URL
 * 3. Inject real-time logs monitoring data
 * 4. Clean up Mongoose metadata
 */
export const getUserById = catchAsync(async (req, res) => {
  const { userId } = req.params;
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const user = await userManagementService.getUserById(userId);

  if (user && user.profileImage) {
    // Extract extension from profileImage path
    const extMatch = user.profileImage.match(/\.([a-zA-Z0-9]+)$/);
    const ext = extMatch ? extMatch[1] : 'jpeg';
    const imageFilePath = path.resolve('public/images/users', `${user._id}.${ext}`);
    if (fs.existsSync(imageFilePath)) {
      imageURL = `${baseUrl}/images/users/${user._id}.${ext}`;
    }
  }

  // Inject real-time logs data into user's allowedResources
  let userObj = user.toObject ? user.toObject() : { ...user };
  let allowedResources = userObj.allowedResources ? { ...userObj.allowedResources } : {};

  // Fetch actual logs data for this user (event logs + MQTT logs)
  const logsMonitoringData = await userManagementService.getLogsMonitoringDataForUser(userId);
  allowedResources.logsMonitoring = logsMonitoringData;
  userObj.allowedResources = allowedResources;

  // Clean up unwanted Mongoose metadata
  delete userObj.$__parent;
  delete userObj.$__;
  delete userObj._doc;

  // Return user with updated allowedResources
  return res.status(200).json(
    new ApiResponse(true, 'User retrieved successfully', {
      user: {
        ...userObj,
        ImageURL: imageURL,
        allowedResources: allowedResources,
        role_name: userObj.role_name
      }
    })
  );
});

/**
 * Update user profile, role, permissions, or password
 * 
 * Features:
 * - Selective resource updates (only provided sections)
 * - Smart logging based on update type (profile/role/password/resources)
 * - Role change detection and appropriate messaging
 * - Audit trail with specific action types
 */
export const updateUser = catchAsync(async (req, res) => {
  // Check if user is authenticated
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { userId } = req.params;
  const updateData = { ...req.body };

  // Get the current user data to compare what's being updated
  const currentUser = await userManagementService.getUserById(userId);
  if (!currentUser) {
    return res.status(404).json(
      new ApiResponse(false, 'User not found', null)
    );
  }

  // Update user
  const updatedUser = await userManagementService.updateUser(
    userId,
    updateData,
    req.user
  );

  // Smart update type detection for appropriate logging and messaging
  let responseMessage = 'User updated successfully';
  let logAction = 'Profile Updated';

  // Detect if role actually changed (not just provided)
  const roleChanged = updateData.role !== undefined && 
    String(updateData.role) !== String(currentUser.role_id);

  // Detect if permissions actually changed
  const resourcesChanged = updateData.allowedResources !== undefined &&
    JSON.stringify(currentUser.allowedResources) !== JSON.stringify(updatedUser.allowedResources);

  // Detect if profile fields changed
  const profileFields = ['fullName', 'email', 'profileImage', 'organization', 'contactNumber'];
  const profileChanged = profileFields.some(field => 
    updateData[field] !== undefined && updateData[field] !== currentUser[field]
  );

  // Check if password was updated
  if (updateData.password) {
    responseMessage = 'Password updated';
    logAction = 'Password updated';
  }
  // Check if role was updated (and actually changed)
  else if (roleChanged) {
    responseMessage = 'Role updated';
    logAction = 'Role updated';
  }
  // Check if profile fields were updated (prioritize profile updates over resource updates)
  else if (profileChanged) {
    responseMessage = 'Profile updated';
    logAction = 'Profile updated';
  }
  // Check if allowedResources were updated (and actually changed, and role wasn't changed)
  else if (resourcesChanged && !roleChanged) {
    responseMessage = 'Resources updated';
    logAction = 'Resources updated';
  }

  try {
    const { addLog } = await import('../services/log.service.js');

    await addLog({
      action: logAction,
      name: updatedUser.fullName || '-',
      timestamp: Math.floor(Date.now() / 1000),
      type: 'User',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    console.error('Failed to log user update:', logErr);
  }

  // Build response with all relevant fields
  const userResponse = {
    id: updatedUser._id,
    fullName: updatedUser.fullName,
    email: updatedUser.email,
    role: updatedUser.role,
    profileImage: updatedUser.profileImage,
    contactNumber: updatedUser.contactNumber,
    organization: updatedUser.organization,
    lastLogin: updatedUser.lastLogin,
    createdDate: updatedUser.createdDate,
    updatedAt: updatedUser.updatedAt,
    allowedResources: updatedUser.allowedResources,
    isActive: updatedUser.isActive,
    isDeleted: updatedUser.isDeleted,
    assignedTopics: updatedUser.assignedTopics,
    campusData: updatedUser.campusData,
    resetPassword: updatedUser.resetPassword,
    updatedBy: updatedUser.updatedBy
  };

  return res.status(200).json(
    new ApiResponse(true, responseMessage, { user: userResponse })
  );
});

/**
 * Delete user (soft delete)
 */
export const deleteUser = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  // Get user name before deletion for logging
  let userName = 'User';
  try {
    const userToDelete = await userManagementService.getUserById(req.params.userId);
    userName = userToDelete?.fullName || 'User';
  } catch (err) {
    // If we can't get the user name, use default
    userName = 'User';
  }

  await userManagementService.deleteUser(req.params.userId, req.user);

  // Add logging for user deletion
  try {
    const { addLog } = await import('../services/log.service.js');
    await addLog({
      action: 'Deleted',
      name: userName,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'User',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log user deletion:', logErr);
  }

  return res.status(200).json(
    new ApiResponse(true, 'User hard deleted successfully', null)
  );
});

/**
 * Change user status (Active/Inactive)
 */
export const changeUserStatus = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { userId } = req.params;
  const { isActive } = req.body;
  
  // Validate isActive field
  if (typeof isActive !== 'boolean') {
    return res.status(400).json(
      new ApiResponse(false, 'Invalid isActive value. Must be true or false.', null)
    );
  }
  
  const updatedUser = await userManagementService.changeUserStatus(userId, isActive, req.user);
  
  const statusText = isActive ? 'active' : 'inactive';

  // Add logging for user status change
  try {
    const { addLog } = await import('../services/log.service.js');
    await addLog({
      action: 'Status Updated',
      name: `${updatedUser.fullName}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'User',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log user status update:', logErr);
  }
  
  return res.status(200).json(
    new ApiResponse(true, `User status updated to ${statusText} successfully`, {
      user: updatedUser,
      updatedAt: updatedUser.updatedAt
    })
  );
});

/**
 * Get navigation tabs accessible to specific role
 * Used for dynamic UI generation based on permissions
 */
export const getTabNames = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { role_id } = req.body;

  if (!role_id) {
    return res.status(400).json(
      new ApiResponse(false, 'Role ID is required in request body.', null)
    );
  }

  const result = await userManagementService.getTabNames(role_id);

  return res.status(200).json(
    new ApiResponse(true, 'Tab names retrieved successfully', result)
  );
});

/**
 * Get modules (campus, device, etc.) accessible by role
 * Returns modules where role has any permission (View/Add/Update/Delete)
 */
export const getUserAccessibleModules = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { role_id } = req.body;

  if (!role_id) {
    return res.status(400).json(
      new ApiResponse(false, 'Role ID is required in request body.', null)
    );
  }

  const result = await userManagementService.getUserAccessibleModules(role_id);

  return res.status(200).json(
    new ApiResponse(true, 'User accessible modules retrieved successfully', result)
  );
});

/**
 * Get resources within modules filtered by role permissions
 * 
 * Returns:
 * - Campus management: campuses, buildings, floors, zones
 * - Intelligent control: groups, scenes, sensors, templates
 * - Device management: devices
 * - User management: users, roles
 * - Control section: filtered by specific tab permissions
 */
export const getModuleData = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { type, role_id } = req.body;

  if (!role_id) {
    return res.status(400).json(
      new ApiResponse(false, 'Role ID is required in request body.', null)
    );
  }

  let moduleData = await userManagementService.getModuleData(type, role_id, req.user);

  // Special filtering for control section based on tab permissions
  if (type === 'controlSection') {
    // Check which control tabs user can view (template_tab, group_tab, etc.)
    const Role = (await import('../models/Role.js')).default;
    const role = await Role.findById(role_id).lean();
    let controlSectionPerms = role?.permissions?.CONTROL_SECTION || {};
    
    // Filter to only tabs with View permission
    const allowedTabs = Object.entries(controlSectionPerms)
      .filter(([tab, perms]) => perms?.View === true)
      .map(([tab]) => tab);

    // If user only has template tab access, show only templates
    if (allowedTabs.length === 1 && allowedTabs[0] === 'template_tab') {
      if (Array.isArray(moduleData)) {
        moduleData = moduleData.filter(item => item.type === 'template');
      } else if (moduleData && typeof moduleData === 'object') {
        // Keep only template-related data
        Object.keys(moduleData).forEach(key => {
          if (key !== 'templates') {
            delete moduleData[key];
          }
        });
      }
    }
  }

  const message = type
    ? `${type} data retrieved successfully`
    : 'All modules data retrieved successfully';

  return res.status(200).json(new ApiResponse(true, message, moduleData));
});

/**
 * Insert campus data for a user
 */
export const insertUserCampusData = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { userId } = req.params;
  const { campusData } = req.body;

  if (!userId) {
    return res.status(400).json(
      new ApiResponse(false, 'User ID is required', null)
    );
  }

  if (!campusData) {
    return res.status(400).json(
      new ApiResponse(false, 'Campus data is required', null)
    );
  }

  const result = await userManagementService.insertUserCampusData(userId, campusData, req.user);

  return res.status(200).json(
    new ApiResponse(true, result.message, {
      campusData: result.campusData,
      user_id: userId
    })
  );
});

/**
 * Get comprehensive module data with role permissions and user selections
 * 
 * Two modes:
 * 1. Role-only (role_id): Shows all resources role can access, all marked as checked
 * 2. Role + User (role_id + user_id): Shows resources role can access, 
 *    but checks are based on user's actual allowedResources
 * 
 * Used for permission management UIs and role assignment interfaces
 */
export const getModuleDataByRole = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { role_id, user_id } = req.body;
  const data = await userManagementService.getModuleDataByRole(role_id, user_id || null);

  return res.status(200).json(
    new ApiResponse(true, 'All modules data retrieved successfully', data)
  );
});