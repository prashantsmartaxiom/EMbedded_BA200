/**
 * Floor Controller - Building floor management business logic
 * 
 * Manages floor lifecycle within the building hierarchy of the smart building platform.
 * Handles user access control, device state management, and zone cascade operations.
 * Flow: floor.routes.js → floor.controller.js → floor.service.js → CampusFloor model
 * 
 * Key Operations:
 * - Floor CRUD with building association and zone management
 * - User access filtering via allowedResources.campusManagement.floors
 * - Device state management during deletion (move to Discovered)
 * - Name-based campus/building resolution for external APIs
 * - Zone cascade operations and intelligent control cleanup
 * - Audit logging for all floor operations
 */

import * as floorService from '../services/floor.service.js';
import * as optimizedService from '../services/optimized.service.js';
import { catchAsync } from '../utils/catchAsync.js';
import { ApiResponse } from '../utils/ApiResponse.js';
import { getAuthorizedList } from '../utils/authorizedList.js';
import { CampusFloor } from '../models/CampusFloor.js';
import { filterByUserResourceAccess } from '../utils/filterByUserAccess.js';
import { buildUserFilter } from '../utils/buildUserFilter.js';
const { addLog } = await import('../services/log.service.js');

// Get paginated floors list with user access control and deleted floors support
// Uses optimized service for database-level filtering and comprehensive statistics
// Supports includeDeleted parameter for administrative views
export const getAllFloors = catchAsync(async (req, res) => {
  // Build user-specific filter for database-level filtering
  const userFilter = buildUserFilter(req.user, 'floors');
  
  // Get includeDeleted parameter from query (default to false for backward compatibility)
  const includeDeleted = req.query.includeDeleted === 'true';
  
  // Get floors with efficient database filtering and pagination
  const result = await optimizedService.getOptimizedFloors({ 
    ...req.query, 
    userFilter,
    includeDeleted
  });

  // Use global totals from the service for summary
  const summary = {
    totalActiveFloors: result.pagination.totalActive,
    totalInactiveFloors: result.pagination.totalInactive,
    totalNonDeletedFloors: result.pagination.totalNonDeleted,
    ...(includeDeleted && { totalDeletedFloors: result.pagination.totalDeleted }),
    totalFloors: includeDeleted 
      ? result.pagination.totalActive + result.pagination.totalInactive + (result.pagination.totalDeleted || 0)
      : result.pagination.totalNonDeleted
  };

  const message = includeDeleted 
    ? 'Floors retrieved successfully (including deleted floors)'
    : 'Floors retrieved successfully';

  return res.status(200).json(
    new ApiResponse(
      true,
      message,
      {
        floors: result.floors,
        totalNonDeleted: result.pagination.totalNonDeleted,
        totalActive: result.pagination.totalActive,
        totalInactive: result.pagination.totalInactive,
        ...(includeDeleted && { totalDeleted: result.pagination.totalDeleted }),
        pagination: result.pagination,
        summary
      }
    )
  );
});

// export const getAllFloors = catchAsync(async (req, res) => {
//   const result = await getAuthorizedList({
//     user: req.user,
//     moduleKey: 'CAMPUS_MANAGEMENT',
//     resourceKey: 'floors',              // Maps to 'floor_management' permission
//     model: CampusFloor,
//     queryParams: req.query,
//     baseFilter: { isDelete: false },    // Only non-deleted floors
//     populate: [
//       { 
//         path: 'buildingId', 
//         select: 'name campusId region',
//         populate: {
//           path: 'campusId',
//           select: 'name location'
//         }
//       },
//       {
//         path: 'zones',
//         select: 'name status',
//         match: { isDelete: false }
//       },
//       {
//         path: 'createdBy.userId',
//         select: 'fullName email'
//       }
//     ],
//     transformResult: (doc) => ({
//       _id: doc._id,
//       floorName: doc.name,
//       campusName: doc.buildingId?.campusId?.name || '',
//       buildingName: doc.buildingId?.name || '',
//       location: doc.buildingId?.campusId?.location || '',
//       region: doc.buildingId?.region || '',
//       floorLevel: doc.floorLevel,
//       status: doc.status,
//       addedOn: doc.createdAt,
//       zones: doc.zones ? doc.zones.map(zone => ({
//         _id: zone._id,
//         name: zone.name,
//         status: zone.status
//       })) : [],
//       zoneCount: doc.zones ? doc.zones.length : 0,
//       description: doc.description,
//       floorImage: doc.floorImage || "",
//       createdBy: doc.createdBy?.userId ? {
//         userId: {
//           _id: doc.createdBy.userId._id,
//           fullName: doc.createdBy.userId.fullName,
//           email: doc.createdBy.userId.email
//         },
//         fullName: doc.createdBy.userId.fullName,
//         email: doc.createdBy.userId.email
//       } : null
//     })
//   });

//   // Calculate summary from authorized data
//   const totalActiveFloors = result.data.filter(floor => floor.status === 1).length;
//   const totalInactiveFloors = result.data.filter(floor => floor.status === 0).length;

//   return res.status(200).json(
//     new ApiResponse(
//       true, 
//       'Floors retrieved successfully', 
//       {
//         floors: result.data,
//         pagination: {
//           currentPage: result.page,
//           totalPages: Math.ceil(result.total / result.limit),
//           totalFloors: result.total,
//           hasNextPage: result.page < Math.ceil(result.total / result.limit),
//           hasPrevPage: result.page > 1
//         },
//         summary: {
//           totalActiveFloors: totalActiveFloors,
//           totalInactiveFloors: totalInactiveFloors,
//           totalFloors: result.total
//         }
//       }
//     )
//   );
// });

// Get all floors for specific building with zone counts
// Returns building-scoped floor list with pagination and search
export const getFloorsByBuilding = catchAsync(async (req, res) => {
  const { buildingId } = req.params;
  const result = await floorService.getFloorsByBuilding(buildingId, req.query);
  
  return res.status(200).json(
    new ApiResponse(
      true, 
      'Floors retrieved successfully', 
      {
        floors: result.floors,
        pagination: result.pagination
      }
    )
  );
});

// Create new floor in specified building
// - Validates floor level uniqueness within building
// - Updates user allowedResources for access control
// - Updates building's floors array and user campusData
export const addFloor = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { buildingId } = req.params;
  const floorData = { ...req.body, buildingId };

  const floor = await floorService.addFloor(floorData, req.user);

  // Auto-grant floor access to users with existing floor permissions
  const { User } = await import('../models/User.js');
  if (floor && floor._id) {
    await User.updateMany(
      { 'allowedResources.campusManagement.floors': { $exists: true, $type: 'array' } },
      { $addToSet: { 'allowedResources.campusManagement.floors': floor._id } }
    );
  }

  // Add logging for floor creation
  try {
    await addLog({
      action: 'Created',
      name: `${floor.name || 'Floor'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Floor',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log floor creation:', logErr);
  }

  return res.status(201).json(
    new ApiResponse(true, 'Floor created successfully', { floor })
  );
});

// Get floor by ID
export const getFloorById = catchAsync(async (req, res) => {
  const { floorId } = req.params;
  
  const floor = await floorService.getFloorById(floorId);
  
  return res.status(200).json(
    new ApiResponse(true, 'Floor retrieved successfully', { floor })
  );
});

// Create floor using campus/building names (flexible API for external integrations)
// - Resolves campus and building by name with case-insensitive search
// - Validates floor level and name uniqueness within resolved building
export const addFloorWithNames = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const floor = await floorService.addFloorWithNames(req.body, req.user);

  // Add logging for floor creation
  try {
    await addLog({
      action: 'Created',
      name: `${floor.name || 'Floor'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Floor',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log floor creation:', logErr);
  }
  
  return res.status(201).json(
    new ApiResponse(true, 'Floor created successfully', { floor })
  );
});

// Update floor with name-based resolution and building transfer support
// - Supports moving floors between buildings via name resolution
// - Validates floor level/name conflicts in target building
export const updateFloorWithNames = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { floorId } = req.params;
  const updatedFloor = await floorService.updateFloorWithNames(floorId, req.body, req.user);

  // Add logging for floor update
  try {
    await addLog({
      action: 'Updated',
      name: `${updatedFloor.name || 'Floor'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Floor',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log floor update:', logErr);
  }
  
  return res.status(200).json(
    new ApiResponse(true, 'Floor updated successfully', { 
      floor: updatedFloor,
      updatedAt: updatedFloor.updatedAt 
    })
  );
});

// Change floor status (active/inactive)
export const changeFloorStatus = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { floorId } = req.params;
  const { status } = req.body;
  
  const updatedFloor = await floorService.changeFloorStatus(floorId, status, req.user);
  
  const statusText = status === 1 ? 'active' : 'inactive';

  // Add logging for floor status change
  try {
    await addLog({
      action: 'Status Updated',
      name: `${updatedFloor.name || 'Floor'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Floor',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log floor status update:', logErr);
  }
  
  return res.status(200).json(
    new ApiResponse(true, `Floor status changed to ${statusText} successfully`, { 
      floor: updatedFloor,
      previousStatus: updatedFloor.status === status ? (status === 1 ? 0 : 1) : null,
      newStatus: status,
      updatedAt: updatedFloor.updatedAt 
    })
  );
});

// Delete floor with complete cascade cleanup
// - Moves all floor devices to 'Discovered' state
// - Permanently deletes zones and intelligent control data
// - Preserves device hardware for reconfiguration
export const deleteFloor = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { floorId } = req.params;

  // Get floor name before deletion for logging
  let floorName = 'Floor';
  try {
    const floorToDelete = await floorService.getFloorById(floorId);
    floorName = floorToDelete?.name || 'Floor';
  } catch (err) {
    // If we can't get the floor name, use default
    floorName = 'Floor';
  }

  const result = await floorService.deleteFloor(floorId, req.user);

  // Add logging for floor deletion
  try {
    await addLog({
      action: 'Deleted',
      name: floorName,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Floor',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log floor deletion:', logErr);
  }
  
  return res.status(200).json(
    new ApiResponse(true, 'Floor deleted successfully. All devices moved to Discovered state and intelligent control data permanently deleted.', result)
  );
});
