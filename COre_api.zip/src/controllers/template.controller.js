/**
 * Template Controller - Dashboard template and widget management business logic
 * 
 * Handles creation and management of customizable dashboard interfaces
 * Coordinates device controls, scene widgets, and real-time data integration
 * Manages template permissions and real-time updates via socket events
 */
import { catchAsync } from '../utils/catchAsync.js';
import { ApiResponse } from '../utils/ApiResponse.js';
import * as TemplateService from '../services/template.service.js';
import Device from '../models/Device.js';
import { Group } from '../models/Group.js';
import { Scene } from '../models/Scene.js';
import { getDeviceDetailsForScene } from '../services/scene.service.js';
import { socketManager } from '../utils/socketManager.js';
const { addLog } = await import('../services/log.service.js');

// Get paginated template list with permission-based filtering and zone access control
export const getTemplateList = catchAsync(async (req, res) => {
    // Extract query params
    const {
        name,
        layout_type,
        search,
        page = 1,
        limit = 10,
        sortBy = 'createdAt',
        sortOrder = 'desc'
    } = req.query;

    const filter = {};
    if (name) filter.name = name;
    if (layout_type) filter.layout_type = layout_type;

    // Add allowed template IDs filter
    let allowedTemplateIds = [];
    if (req.user && req.user.allowedResources) {
        // Only use intelligentControl.templates for template filtering
        if (req.user.allowedResources.intelligentControl && Array.isArray(req.user.allowedResources.intelligentControl.templates)) {
            allowedTemplateIds = req.user.allowedResources.intelligentControl.templates;
        }
    }

    const params = {
        filter,
        search: search || '',
        page: Number(page) || 1,
        limit: Number(limit) || 10,
        sortBy,
        sortOrder,
        allowedTemplateIds,
        user: req.user
    };

    const list = await TemplateService.getTemplateList(params);
    return res.status(200).json(new ApiResponse(true, 'Template list fetched', list));
});

// Get template by ID with enhanced scene details and real-time widget data
export const getTemplateById = catchAsync(async (req, res) => {
    const { templateId } = req.params;

    const template = await TemplateService.getTemplateByIdWithSceneDetails(templateId);

    if (!template) {
        return res.status(404).json(new ApiResponse(false, 'Template not found'));
    }

    return res.status(200).json(new ApiResponse(true, 'Template fetched successfully', template));
});

// Get available layout configurations for template builder interface
export const getLayoutList = catchAsync(async (req, res) => {
    const layouts = await TemplateService.getLayoutList();
    return res.status(200).json(new ApiResponse(true, 'Layout list fetched', layouts));
});

// Create new dashboard template with auto-permission assignment and capability mapping
export const createTemplate = catchAsync(async (req, res) => {
    const { name, layout, status, rows, columns, layoutStructure } = req.body;

    const newTemplate = await TemplateService.createTemplate({
        name,
        layout,
        status,
        rows,
        columns,
        layoutStructure
    }, req.user);

    // Add logging for template creation
    try {
        await addLog({
            action: 'Created',
            name: `${newTemplate.name || name || 'Template'}`,
            timestamp: Math.floor(Date.now() / 1000),
            type: 'Template',
            userId: req.user?._id?.toString() || '-',
            userName: req.user?.fullName || '-',
        });
    } catch (logErr) {
        // eslint-disable-next-line no-console
        console.error('Failed to log template creation:', logErr);
    }
    socketManager.emitEvent('templateUpdate', newTemplate);
    return res.status(201).json(new ApiResponse(true, 'Template created successfully', newTemplate));
});

// Update template configuration, layout structure, and widget assignments
export const updateTemplate = catchAsync(async (req, res) => {
    const { id, name, layout, status, rows, columns, layoutStructure } = req.body;

    const updatedTemplate = await TemplateService.updateTemplate(id, {
        name,
        layout,
        status,
        rows,
        columns,
        layoutStructure
    });

    // Add logging for template update
    try {
        await addLog({
            action: 'Updated',
            name: `${updatedTemplate.name || name || 'Template'}`,
            timestamp: Math.floor(Date.now() / 1000),
            type: 'Template',
            userId: req.user?._id?.toString() || '-',
            userName: req.user?.fullName || '-',
        });
    } catch (logErr) {
        // eslint-disable-next-line no-console
        console.error('Failed to log template update:', logErr);
    }
    socketManager.emitEvent('templateUpdate', updatedTemplate);
    return res.status(200).json(new ApiResponse(true, 'Template updated successfully', updatedTemplate));
});

// Delete template and notify clients via socket events
export const deleteTemplate = catchAsync(async (req, res) => {
    const { id } = req.body;

    // Get template name before deletion for logging
    let templateName = 'Template';
    try {
        const templateToDelete = await TemplateService.getTemplateById(id);
        templateName = templateToDelete?.name || 'Template';
    } catch (err) {
        // If we can't get the template name, use default
        templateName = 'Template';
    }

    await TemplateService.deleteTemplate(id);

    // Add logging for template deletion
    try {
        await addLog({
            action: 'Deleted',
            name: templateName,
            timestamp: Math.floor(Date.now() / 1000),
            type: 'Template',
            userId: req.user?._id?.toString() || '-',
            userName: req.user?.fullName || '-',
        });
    } catch (logErr) {
        // eslint-disable-next-line no-console
        console.error('Failed to log template deletion:', logErr);
    }
    socketManager.emitEvent('templateUpdate', {id});
    return res.status(200).json(new ApiResponse(true, 'Template deleted successfully'));
});

// Get device/group/scene hierarchy for template builder with zone-based filtering
export const getHierarchy = catchAsync(async (req, res) => {
    const hierarchy = await TemplateService.getHierarchy(req.user);
    return res
        .status(200)
        .json(new ApiResponse(true, 'Hierarchy fetched successfully', hierarchy));
});

// Get templates accessible by current user based on control section permissions
export const getTemplatesByControlSection = catchAsync(async (req, res) => {
    // Extract name query parameter for search functionality
    const { search } = req.query;
    
    // Only active and non-deleted templates
    // allowedResources can be null
    let templateIds = null;
    if (req.user && req.user.allowedResources && req.user.allowedResources.controlSection && Array.isArray(req.user.allowedResources.controlSection.templateTab)) {
        templateIds = req.user.allowedResources.controlSection.templateTab;
    }
    let templates = await TemplateService.getTemplatesByUserAccess(templateIds, search, req.user);
    // Sort templates by createdAt descending (latest first)
    templates = Array.isArray(templates)
        ? templates.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        : templates;
    return res.status(200).json({
        success: true,
        message: 'Template list fetched',
        data: { data: templates }
    });
});

// Get complete templates with full widget data for dashboard rendering
export const getAllCompleteTemplatesWithWidgetData = catchAsync(async (req, res) => {
    const templates = await TemplateService.getAllCompleteTemplatesWithWidgetData(req.user);
    
    return res.status(200).json(new ApiResponse(true, 'Templates with widget data fetched successfully', templates));
});