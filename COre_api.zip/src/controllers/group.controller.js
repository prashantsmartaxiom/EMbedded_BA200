
/**
 * Group Controller - Device group management business logic
 * 
 * Handles logical grouping of devices with channel-level control
 * Manages device assignments, channel installations, and group permissions
 * Coordinates with scenes, templates, and real-time updates via socket events
 */
import * as GroupService from '../services/group.service.js';
import { catchAsync } from '../utils/catchAsync.js';
import { ApiResponse } from '../utils/ApiResponse.js';
import mongoose from 'mongoose';
import { socketManager } from '../utils/socketManager.js';
const { addLog } = await import('../services/log.service.js');
const Scene = mongoose.models.Scene || (await import('../models/Scene.js')).Scene;

// Create new device group with channel assignments and auto-assign permissions
export const createGroup = catchAsync(async (req, res) => {
    try {
        const group = await GroupService.createGroup(req.body, req.user);

        // Add logging for group creation
        try {
            await addLog({
                action: 'Created',
                name: `${group.name || group.group_name || 'Group'}`,
                timestamp: Math.floor(Date.now() / 1000),
                type: 'Group',
                userId: req.user?._id?.toString() || '-',
                userName: req.user?.fullName || '-',
            });
        } catch (logErr) {
            // eslint-disable-next-line no-console
            console.error('Failed to log group creation:', logErr);
        }

        return res.status(201).json(new ApiResponse(true, 'Group created successfully', group));
    } catch (error) {
        return res.status(400).json(new ApiResponse(false, error.message));
    }
});

// Get paginated group list with filtering, search, and permission-based access control
export const getGroupList = catchAsync(async (req, res) => {
    // Extract query params
    const {
        group_name,
        device_id,
        search,
        page,
        limit,
        sortBy: sortByRaw = 'createdAt',
        sortOrder: sortOrderRaw = 'desc',
        sort // optional shorthand: asc|desc for name
    } = req.query;

  const filter = {};
  if (group_name) filter.group_name = group_name;
  if (device_id) filter.device_id = device_id;

  // Add allowed group IDs filter
  let allowedGroupIds = [];
  if (req.user && req.user.allowedResources) {
    // Check intelligentControl.groups first (primary location)
    if (req.user.allowedResources.intelligentControl && Array.isArray(req.user.allowedResources.intelligentControl.groups)) {
      allowedGroupIds = req.user.allowedResources.intelligentControl.groups;
    }
    // If no groups found in intelligentControl, check controlSection.groupTab as fallback
    else if (req.user.allowedResources.controlSection && Array.isArray(req.user.allowedResources.controlSection.groupTab)) {
      allowedGroupIds = req.user.allowedResources.controlSection.groupTab;
    }
  }

  const shouldPaginate = page !== undefined || limit !== undefined;

  // Normalize sorting: if `sort` (asc|desc) is provided, sort by name
  let sortBy = sortByRaw;
  let sortOrder = sortOrderRaw;
  if (typeof sort === 'string' && /^(asc|desc)$/i.test(sort)) {
    sortBy = 'name';
    sortOrder = sort.toLowerCase();
  }

  const params = {
    filter,
    search: search || '',
    sortBy,
    sortOrder,
    ...(shouldPaginate && {
      page: Number(page) || 1,
      limit: Number(limit) || 10
    }),
    allowedGroupIds,
    user: req.user
  };

  let list;
  if (shouldPaginate) {
    // Use existing paginated service
    list = await GroupService.getGroupList(params);
  } else {
    // Use non-paginated service (similar to getAllGroups but with filters)
    list = await GroupService.getGroupListNoPagination(params);
  }

  return res.status(200).json(new ApiResponse(true, 'Group list fetched', list));
});

// Get devices available for grouping - filters by type (normal/BMS) and zone access
export const getActiveDevices = catchAsync(async (req, res) => {
    const { normal, bms } = req.query;
    const devices = await GroupService.getActiveDevices(req.user, { normal, bms });
    return res.status(200).json(new ApiResponse(true, 'Active devices fetched', devices));
});

// Get installed channels for specific devices - maintains input order and shows location info
export const getDeviceChannels = catchAsync(async (req, res) => {
  const { deviceIds } = req.body;
  const data = await GroupService.getDeviceChannels({ deviceIds, user: req.user });
  return res.status(200).json(new ApiResponse(true, 'Device channels fetched', data));
});

// Update group properties and device assignments - syncs with scenes and templates
export const updateGroup = catchAsync(async (req, res) => {
  const { groupId } = req.params;
  const { name, devices } = req.body;
  // Update group as before
  const result = await GroupService.updateGroup({ groupId, name, devices, user: req.user });

  // Update scenes: for all scenes containing this group, update their devices array inside Groups
  if (Array.isArray(devices)) {
    try {
      await Scene.updateMany(
        { 'Groups.groupId': groupId },
        { $set: { 'Groups.$[g].devices': devices } },
        { arrayFilters: [{ 'g.groupId': groupId }] }
      );
    } catch (sceneErr) {
      // eslint-disable-next-line no-console
      console.error('Failed to update devices in scenes:', sceneErr);
    }
  }

  // Add logging for group update
  try {
    await addLog({
      action: 'Updated',
      name: `${result.name || result.group_name || name || 'Group'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Group',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log group update:', logErr);
  }

  // Emit socket event after successful group update
  socketManager.emitEvent('templateUpdate', {
    action: 'updated',
    type: 'Group',
    groupId: groupId,
    group: result,
    timestamp: new Date().toISOString(),
    userId: req.user?._id?.toString()
  });

  return res.status(200).json(new ApiResponse(true, 'Group updated', result));
});

// Soft delete group and cascade cleanup from scenes, templates, and sensors
export const deleteGroup = catchAsync(async (req, res) => {
  const { groupId } = req.params;

  // Get group name before deletion for logging
  let groupName = 'Group';
  try {
    const groupToDelete = await GroupService.getGroupDetails(groupId, req.user);
    groupName = groupToDelete?.name || groupToDelete?.group_name || 'Group';
  } catch (err) {
    // If we can't get the group name, use default
    groupName = 'Group';
  }

  const result = await GroupService.deleteGroup(groupId, req.user);

  // Add logging for group deletion
  try {
    await addLog({
      action: 'Deleted',
      name: groupName,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Group',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log group deletion:', logErr);
  }

  // Emit socket event after successful group deletion
  socketManager.emitEvent('templateUpdate', {
    action: 'deleted',
    type: 'Group',
    groupId: groupId,
    groupName: groupName,
    timestamp: new Date().toISOString(),
    userId: req.user?._id?.toString()
  });

  return res.status(200).json(new ApiResponse(true, 'Group deleted', result));
});

// Get detailed group information - supports single or multiple group IDs for flexible access
// Accepts either a single groupId (params) or multiple groupIds (query: groupIds as comma-separated or array)
export const getGroupDetailsController = async (req, res) => {
  try {
    let groupIds = [];
    if (req.params.groupId) {
      groupIds = [req.params.groupId];
    } else if (req.query.groupIds) {
      if (Array.isArray(req.query.groupIds)) {
        groupIds = req.query.groupIds;
      } else if (typeof req.query.groupIds === 'string') {
        groupIds = req.query.groupIds.split(',').map(id => id.trim()).filter(Boolean);
      }
    }
    if (!groupIds.length) {
      return res.status(400).json({
        success: false,
        message: 'Group ID(s) is required'
      });
    }

    // Fetch details for each groupId
    const results = await Promise.all(
      groupIds.map(async (id) => {
        try {
          const groupDetails = await GroupService.getGroupDetails(id, req.user);
          return { groupId: id, success: true, data: groupDetails };
        } catch (error) {
          return { groupId: id, success: false, error: error.message };
        }
      })
    );

    // If only one groupId, return single object for backward compatibility
    if (results.length === 1) {
      if (results[0].success) {
        return res.status(200).json({
          success: true,
          message: 'Group details retrieved successfully',
          data: results[0].data
        });
      } else {
        return res.status(404).json({
          success: false,
          message: results[0].error
        });
      }
    }
    // Otherwise, return array of results
    return res.status(200).json({
      success: true,
      message: 'Group details retrieved successfully',
      data: results
    });
  } catch (error) {
    console.error('Error in getGroupDetailsController:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
};

// Get all groups without pagination - simple list for dropdowns and selections
export const getAllGroups = catchAsync(async (req, res) => {
  const {
    search,
    sortBy = 'name',
    sortOrder = 'asc'
  } = req.query;

  const params = {
    search: search || '',
    sortBy,
    sortOrder
  };

  const result = await GroupService.getAllGroupsNoPagination(params);
  return res.status(200).json(new ApiResponse(true, 'All groups fetched successfully', result));
});

// Get all groups with comprehensive device details and location hierarchy
// If allowedResources is null, return all active groups for authorized users
export const getAllGroupsWithDeviceDetails = catchAsync(async (req, res) => {
  try {
    // Check if user is authenticated
    if (!req.user) {
      return res.status(401).json(
        new ApiResponse(false, 'Authentication required. Please login first.', null)
      );
    }

    const {
      search,
      campus,
      building,
      floor,
      zone
    } = req.query;

    const filters = {};
    if (campus) filters.campus = campus;
    if (building) filters.building = building;
    if (floor) filters.floor = floor;
    if (zone) filters.zone = zone;

    const params = {
      search: search || '',
      filters,
      user: req.user
    };

    // If allowedResources is null, show all active groups for authorized user
    if (!req.user.allowedResources) {
      const result = await GroupService.getAllActiveGroupsWithDeviceDetails(params);
      return res.status(200).json(new ApiResponse(true, 'All active groups with device details fetched for authorized user', result));
    }

    // Otherwise, use the existing permission-based filtering
    params.user = req.user;
    const result = await GroupService.getAllGroupsWithDeviceDetails(params);
    return res.status(200).json(new ApiResponse(true, 'All groups with device details fetched successfully', result));
  } catch (error) {
    console.error('Error in getAllGroupsWithDeviceDetails:', error);
    return res.status(500).json(new ApiResponse(false, 'Internal server error', null, error.message));
  }
});

// Get single device details with all installed channels and location information
export const getSingleDeviceDetails = catchAsync(async (req, res) => {
  try {
    const { deviceId } = req.params;

    if (!deviceId) {
      return res.status(400).json(new ApiResponse(false, 'Device ID is required'));
    }

    const deviceDetails = await GroupService.getSingleDeviceDetails(deviceId, req.user);
    return res.status(200).json(new ApiResponse(true, 'Device details retrieved successfully', deviceDetails));

  } catch (error) {
    console.error('Error in getSingleDeviceDetails:', error);
    
    if (error.message === 'Device not found or access denied') {
      return res.status(404).json(new ApiResponse(false, error.message));
    }

    return res.status(500).json(new ApiResponse(false, 'Internal server error', null, error.message));
  }
});

// Get comprehensive group view data with all devices, channels, and location hierarchy
export const getGroupViewData = catchAsync(async (req, res) => {
  try {
    const { groupId } = req.params;

    if (!groupId) {
      return res.status(400).json(new ApiResponse(false, 'Group ID is required'));
    }

    const groupViewData = await GroupService.getGroupViewData(groupId, req.user);
    return res.status(200).json(new ApiResponse(true, 'Group view data retrieved successfully', groupViewData));

  } catch (error) {
    console.error('Error in getGroupViewData:', error);
    
    if (error.message === 'Group not found or has been deleted') {
      return res.status(404).json(new ApiResponse(false, error.message));
    }

    return res.status(500).json(new ApiResponse(false, 'Internal server error', null, error.message));
  }
});