
/**
 * Sensor Controller - IoT sensor configuration and automation business logic
 * 
 * Handles motion sensor setup with scene-based automation triggers
 * Manages sensor-device relationships and MQTT command coordination
 * Provides permission-based access control and audit logging
 */
import { catchAsync } from '../utils/catchAsync.js';
import * as SensorService from '../services/sensor.service.js';
import { ApiResponse } from '../utils/ApiResponse.js';
const { addLog } = await import('../services/log.service.js');

// Create new sensor configuration with motion/no-motion scene automation and MQTT setup
export const addSensor = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const sensor = await SensorService.addSensor(req.body, req.user);

  // Add logging for sensor creation
  try {
    await addLog({
      action: 'Created',
      name: `${sensor.sensorName || sensor.name || 'Sensor'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Sensor',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log sensor creation:', logErr);
  }

  return res.status(201).json(
    new ApiResponse(true, 'Sensor created successfully', { sensor })
  );
});

// Get paginated sensor list with permission-based filtering and zone access control
export const listSensors = catchAsync(async (req, res) => {
  const {
    deviceId,
    groupId,
    sensorName,
    search,
    page = 1,
    limit = 10
  } = req.query;

  const filter = {};
  if (deviceId) filter.deviceId = deviceId;
  if (groupId) filter.groupId = groupId;
  if (sensorName) filter.sensorName = sensorName;

  // Add allowed sensor IDs filter
  let allowedSensorIds = [];
  if (req.user && req.user.allowedResources) {
    // Only use intelligentControl.sensors for sensor filtering
    if (req.user.allowedResources.intelligentControl && Array.isArray(req.user.allowedResources.intelligentControl.sensors)) {
      allowedSensorIds = req.user.allowedResources.intelligentControl.sensors;
    }
  }

  const params = {
    filter,
    search: search || '',
    page: Number(page) || 1,
    limit: Number(limit) || 10,
    allowedSensorIds,
    user: req.user
  };

  const result = await SensorService.getSensorList(params);
  return res.status(200).json(new ApiResponse(true, 'Sensor list fetched successfully', result));
});

// Get specific sensor configuration with populated scene and device details
export const getSensor = catchAsync(async (req, res) => {
  const sensor = await SensorService.getSensorById(req.params.id);

  return res.status(200).json(
    new ApiResponse(true, 'Sensor retrieved successfully', { sensor })
  );
});

// Update sensor configuration, scenes, and MQTT trigger settings
export const updateSensor = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const sensor = await SensorService.updateSensor(req.params.id, req.body, req.user);

  // Add logging for sensor update
  try {
    await addLog({
      action: 'Updated',
      name: `${sensor.sensorName || sensor.name || 'Sensor'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Sensor',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log sensor update:', logErr);
  }

  return res.status(200).json(
    new ApiResponse(true, 'Sensor updated successfully', { sensor })
  );
});

// Soft delete sensor configuration and cleanup MQTT device settings
export const deleteSensor = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { id } = req.params;

  // Get sensor name before deletion for logging
  let sensorName = 'Sensor';
  try {
    const sensorToDelete = await SensorService.getSensorById(id);
    sensorName = sensorToDelete?.sensorName || sensorToDelete?.name || 'Sensor';
  } catch (err) {
    // If we can't get the sensor name, use default
    sensorName = 'Sensor';
  }

  const deletedSensor = await SensorService.deleteSensor(id, req.user);

  // Add logging for sensor deletion
  try {
    await addLog({
      action: 'Deleted',
      name: sensorName,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Sensor',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log sensor deletion:', logErr);
  }

  return res.status(200).json(
    new ApiResponse(true, 'Sensor deleted successfully', {
      sensor: deletedSensor,
      deletedAt: deletedSensor.updatedAt
    })
  );
});
