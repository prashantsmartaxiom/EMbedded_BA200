/**
 * Scene Controller - Automated control scene business logic
 * 
 * Handles creation and management of automation scenes for smart building control
 * Coordinates device/group assignments with real-time execution capabilities
 * Manages scene permissions and integrates with scheduling and sensor systems
 */
import { catchAsync } from '../utils/catchAsync.js';
import * as SceneService from '../services/scene.service.js';
import { ApiResponse } from '../utils/ApiResponse.js';
import { socketManager } from '../utils/socketManager.js';
const { addLog } = await import('../services/log.service.js');

// Create new automation scene with device/group assignments and auto-assign permissions
export const addScene = catchAsync(async (req, res) => {
  // Add createdBy from authenticated user
  if (req.user) {
    req.body.createdBy = {
      userId: req.user._id,
      fullName: req.user.fullName,
      email: req.user.email
    };
  }
  const { scene, warnings } = await SceneService.createScene(req.body, req.user);

  // Add logging for scene creation
  try {
    await addLog({
      action: 'Created',
      name: `${scene.name || scene.sceneName || 'Scene'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Scene',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log scene creation:', logErr);
  }

  return res.status(201).json(new ApiResponse(true, 'Scene created', { scene, warnings }));
});

// Get paginated scene list with permission-based filtering and zone access control
export const listScenes = catchAsync(async (req, res) => {

  // Superadmin bypass: if user is superadmin, do not filter by allowedSceneIds
  let isSuperAdmin = false;
  if (req.user && req.user.role_id && req.user.role_id.roleName) {
    if (req.user.role_id.roleName.trim().toLowerCase() === 'superadmin') {
      isSuperAdmin = true;
    }
  }

  let allowedSceneIds = [];
  if (!isSuperAdmin && req.user && req.user.allowedResources) {
    // Only use intelligentControl.scenes for scene filtering
    if (req.user.allowedResources.intelligentControl && Array.isArray(req.user.allowedResources.intelligentControl.scenes)) {
      allowedSceneIds = req.user.allowedResources.intelligentControl.scenes;
    }
  }

  // Only pass allowedSceneIds if not superadmin
  const data = await SceneService.listScenes({
    ...req.query,
    ...(isSuperAdmin ? {} : { allowedSceneIds }),
    user: req.user
  });
  return res.status(200).json(new ApiResponse(true, 'Scenes fetched', data));
});

// Soft delete scene and cascade cleanup from templates, sensors, and user permissions
export const deleteScene = catchAsync(async (req, res) => {
  // Check if user is authenticated
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { sceneId } = req.params;

  // Get scene name before deletion for logging
  let sceneName = 'Scene';
  try {
    const sceneToDelete = await SceneService.getSceneDetails(sceneId);
    sceneName = sceneToDelete?.name || sceneToDelete?.sceneName || 'Scene';
  } catch (err) {
    // If we can't get the scene name, use default
    sceneName = 'Scene';
  }

  const result = await SceneService.deleteScene(sceneId, req.user);

  // Add logging for scene deletion
  try {
    await addLog({
      action: 'Deleted',
      name: sceneName,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Scene',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log scene deletion:', logErr);
  }

  // Emit socket event after successful scene deletion
  socketManager.emitEvent('templateUpdate', {
    type: 'Scene',
    action: 'deleted',
    sceneId: sceneId,
    sceneName: sceneName,
    timestamp: new Date().toISOString(),
    userId: req.user?._id?.toString()
  });
  
  return res.status(200).json(
    new ApiResponse(true, 'Scene deleted successfully', result)
  );
});

// Get device details for scene creation - shows installed channels and location info
export const getDeviceDetails = catchAsync(async (req, res) => {
  const { deviceId } = req.params;
  const deviceDetails = await SceneService.getDeviceDetailsForScene(deviceId);
  return res.status(200).json(new ApiResponse(true, 'Device details retrieved successfully', deviceDetails));
});

// Update scene configuration, device/group assignments, and operation type
export const updateScene = catchAsync(async (req, res) => {
  const { id } = req.params;
  
  // Filter out fields that should not be updated by client
  const { lastExecuted, executedBy, createdBy, updatedBy, deletedAt, deletedBy, isDeleted, ...updateData } = req.body;
  
  // Set invert_flag to true when updating scene
  updateData.invert_flag = true;
  
  const { scene, warnings } = await SceneService.updateScene(id, updateData, req.user);

  // Add logging for scene update
  try {
    await addLog({
      action: 'Updated',
      name: `${scene.name || scene.sceneName || 'Scene'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Scene',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log scene update:', logErr);
  }
  
  socketManager.emitEvent("deviceStatusChanged", { uiType:"", sceneId: id });
  return res.status(200).json(
    new ApiResponse(true, 'Scene updated successfully', { scene, warnings })
  );
});

// Update scene execution status (active/inactive) for automation control
export const updateSceneStatus = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { id } = req.params;
  const { status } = req.body;
  
  const updatedScene = await SceneService.updateSceneStatus(id, status, req.user);
  
  const statusText = status === 1 ? 'active' : 'inactive';

  // Add logging for scene status update
  try {
    await addLog({
      action: 'Status Updated',
      name: `${updatedScene.name || updatedScene.sceneName || 'Scene'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Scene',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log scene status update:', logErr);
  }
  
  return res.status(200).json(
    new ApiResponse(true, `Scene status updated to ${statusText} successfully`, {
      scene: updatedScene,
      newStatus: status,
      updatedAt: updatedScene.updatedAt 
    })
  );
});


// Get all scenes without pagination - simple list for dropdowns and selections
export const getAllScenes = catchAsync(async (req, res) => {
  const {
    search,
    status,
    sortBy = 'createdAt',
    sortOrder = 'desc'
  } = req.query;

  const params = {
    search: search || '',
    status,
    sortBy,
    sortOrder
  };

  const result = await SceneService.getAllScenesNoPagination(params);
  
  return res.status(200).json(
    new ApiResponse(
      true, 
      'All scenes retrieved successfully', 
      result
    )
  );
});

// Get detailed scene information with complete device/group data and channels
export const viewScene = catchAsync(async (req, res) => {
  const { sceneId } = req.params;
  const sceneDetails = await SceneService.getSceneDetails(sceneId);
  // Add invert_flag and operateType to response if present
  const responseDetails = {
    ...sceneDetails,
    invert_flag: sceneDetails.invert_flag ?? false,
    operateType: sceneDetails.operateType ?? 'normal'
  };
  return res.status(200).json(
    new ApiResponse(
      true,
      'Scene details retrieved successfully',
      responseDetails
    )
  );
});

// Get comprehensive scene list with complete device/group details and installed channels
export const getAllScenesWithDetails = catchAsync(async (req, res) => {
  const {
    search,
    status,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    page = 1,
    limit = 50
  } = req.query;

  const params = {
    search: search || '',
    status,
    sortBy,
    sortOrder,
    page: parseInt(page),
    limit: parseInt(limit)
  };

  const result = await SceneService.getAllScenesWithDeviceGroupDetails(params);
  
  return res.status(200).json(
    new ApiResponse(
      true, 
      'All scenes with detailed information retrieved successfully', 
      result
    )
  );
});

// Get scenes accessible to current user based on permission matrix
// If allowedResources is null, return all active scenes for authorized users
export const getAllowedScenesForUser = catchAsync(async (req, res) => {
  // Check if user is authenticated
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  // Extract name query parameter for search functionality
  const { search } = req.query;

  // If allowedResources is null, show all active scenes for authorized user
  if (!req.user.allowedResources) {
    let scenes = await SceneService.getAllActiveScenes(search, req.user);
    // Sort scenes by createdAt descending (latest first)
    scenes = Array.isArray(scenes)
      ? scenes.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      : scenes;
    return res.status(200).json(new ApiResponse(true, 'All active scenes fetched for authorized user', { scenes }));
  }

  // Get allowed scene IDs from controlSection.sceneTab
  let allowedSceneIds = [];
  if (
    req.user.allowedResources.controlSection &&
    Array.isArray(req.user.allowedResources.controlSection.sceneTab)
  ) {
    allowedSceneIds = req.user.allowedResources.controlSection.sceneTab;
  }
  
  // If none, return empty array
  if (!allowedSceneIds.length) {
    return res.status(200).json(new ApiResponse(true, 'No allowed scenes for user', { scenes: [] }));
  }

  let scenes = await SceneService.getAllowedActiveScenes(allowedSceneIds, search, req.user);
  // Sort scenes by createdAt descending (latest first)
  scenes = Array.isArray(scenes)
    ? scenes.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    : scenes;
  return res.status(200).json(new ApiResponse(true, 'Allowed scenes fetched', { scenes }));
});