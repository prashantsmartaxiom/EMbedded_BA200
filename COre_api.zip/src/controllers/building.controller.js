/**
 * Building Controller - Campus building management business logic
 * 
 * Manages building lifecycle within the smart building platform hierarchy.
 * Handles user access control, device state management, and cascade operations.
 * Flow: building.routes.js → building.controller.js → building.service.js → CampusBuilding model
 * 
 * Key Operations:
 * - Building CRUD with campus association and floor generation
 * - User access filtering via allowedResources.campusManagement.buildings
 * - Device state management during building deletion (move to Discovered)
 * - Audit logging for all building operations
 * - Optimized queries with database-level filtering
 */

import * as buildingService from '../services/building.service.js';
import * as optimizedService from '../services/optimized.service.js';
import { catchAsync } from '../utils/catchAsync.js';
import { ApiResponse } from '../utils/ApiResponse.js';
import { getAuthorizedList } from '../utils/authorizedList.js';
import { CampusBuilding } from '../models/CampusBuilding.js';
import { Campus } from '../models/Campus.js';
import { filterByUserResourceAccess } from '../utils/filterByUserAccess.js';
import { buildUserFilter } from '../utils/buildUserFilter.js';
const { addLog } = await import('../services/log.service.js');

// Get paginated buildings list with user access control
// Uses optimized service for database-level filtering and efficient queries
// Respects user's allowedResources.campusManagement.buildings for access control
export const getAllBuildings = catchAsync(async (req, res) => {
  // Build user-specific filter for database-level filtering
  const userFilter = buildUserFilter(req.user, 'buildings');
  
  // Get buildings with efficient database filtering and pagination
  const result = await optimizedService.getOptimizedBuildings({ 
    ...req.query, 
    userFilter 
  });

  return res.status(200).json(
    new ApiResponse(
      true,
      'Buildings retrieved successfully',
      {
        buildings: result.buildings,
        totalNonDeleted: result.pagination.totalNonDeleted,
        totalActive: result.pagination.totalActive,
        totalInactive: result.pagination.totalInactive,
        pagination: result.pagination
      }
    )
  );
});

// export const getAllBuildings = catchAsync(async (req, res) => {
//   const result = await getAuthorizedList({
//     user: req.user,
//     moduleKey: 'CAMPUS_MANAGEMENT',
//     resourceKey: 'buildings',           // Maps to 'building_management' permission
//     model: CampusBuilding,
//     queryParams: req.query,
//     baseFilter: { isDelete: false },
//     populate: [
//       { 
//         path: 'campusId', 
//         select: 'name accessId' 
//       },
//       {
//         path: 'floors',
//         select: '_id'
//       },
//       {
//         path: 'createdBy.userId',
//         select: 'fullName email'
//       },
//       {
//         path: 'updatedBy.userId',
//         select: 'fullName email'
//       }
//     ],
//     transformResult: (doc) => ({
//       _id: doc._id,
//       name: doc.name,
//       status: doc.status,
//       campusId: doc.campusId ? {
//         _id: doc.campusId._id,
//         name: doc.campusId.name,
//         accessId: doc.campusId.accessId
//       } : null,
//       isDelete: doc.isDelete,
//       type: doc.type || '',
//       description: doc.description || '',
//       buildingImage: doc.buildingImage || '',
//       floors: doc.floors ? doc.floors.map(floor => floor._id) : [],
//       floor_count: doc.floorCount || 0,
//       createdBy: doc.createdBy?.userId ? {
//         userId: {
//           _id: doc.createdBy.userId._id,
//           fullName: doc.createdBy.userId.fullName,
//           email: doc.createdBy.userId.email
//         },
//         fullName: doc.createdBy.userId.fullName,
//         email: doc.createdBy.userId.email
//       } : null,
//       updatedBy: doc.updatedBy?.userId ? {
//         userId: {
//           _id: doc.updatedBy.userId._id,
//           fullName: doc.updatedBy.userId.fullName,
//           email: doc.updatedBy.userId.email
//         },
//         fullName: doc.updatedBy.userId.fullName,
//         email: doc.updatedBy.userId.email
//       } : null,
//       createdAt: doc.createdAt,
//       updatedAt: doc.updatedAt,
//       __v: doc.__v,
//       floorCount: doc.floors ? doc.floors.length : 0,
//       zoneCount: doc.zoneCount || 0  // TODO: Calculate actual zone count if needed
//     })
//   });

//   return res.status(200).json(
//     new ApiResponse(true, 'Buildings retrieved successfully', {
//       buildings: result.data,
//       pagination: {
//         currentPage: result.page,
//         totalPages: Math.ceil(result.total / result.limit),
//         totalBuildings: result.total,
//         hasNextPage: result.page < Math.ceil(result.total / result.limit),
//         hasPrevPage: result.page > 1
//       }
//     })
//   );
// });

// Get all buildings for specific campus with user access filtering
// Applies campus-specific user access control and optimized database queries
export const getBuildingsByCampus = catchAsync(async (req, res) => {
  const { campusId } = req.params;
  
  // Build user-specific filter for database-level filtering with campus context
  const userFilter = buildUserFilter(req.user, 'buildings', campusId);
  
  // Add campusId to the query parameters
  const queryWithCampus = { ...req.query, campusId };
  
  // Get buildings with efficient database filtering and pagination
  const result = await optimizedService.getOptimizedBuildings({ 
    ...queryWithCampus, 
    userFilter 
  });

  return res.status(200).json(
    new ApiResponse(
      true, 
      'Buildings retrieved successfully', 
      {
        buildings: result.buildings,
        totalNonDeleted: result.pagination.totalNonDeleted,
        totalActive: result.pagination.totalActive,
        totalInactive: result.pagination.totalInactive,
        pagination: result.pagination
      }
    )
  );
});

// Get active buildings for dropdowns/selection UI components
// Returns minimal data (_id, name) for performance, filtered by user access
export const getActiveBuildingsByCampus = catchAsync(async (req, res) => {
  const { campusId } = req.params;
  
  // Build user-specific filter for database-level filtering with campus context
  const userFilter = buildUserFilter(req.user, 'buildings', campusId);
  
  // Get active buildings with user filtering
  const result = await optimizedService.getOptimizedBuildings({ 
    ...req.query, 
    campusId,
    status: 1, // Only active buildings
    userFilter 
  });

  // Only return _id and name for each building
  const buildings = result.buildings.map(b => ({ _id: b._id, name: b.name }));

  return res.status(200).json(
    new ApiResponse(
      true, 
      'Active buildings retrieved successfully', 
      {
        buildings,
        pagination: result.pagination
      }
    )
  );
});

// Create new building in specified campus
// - Auto-generates floors based on floorCount
// - Updates user allowedResources for access control
// - Logs creation for audit trail
export const addBuilding = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { campusId } = req.params;
  const buildingData = { ...req.body, campusId };

  const building = await buildingService.addBuilding(buildingData, req.user);

  // Auto-grant building access to users with existing building permissions
  const { User } = await import('../models/User.js');
  if (building && building._id) {
    await User.updateMany(
      { 'allowedResources.campusManagement.buildings': { $exists: true, $type: 'array' } },
      { $addToSet: { 'allowedResources.campusManagement.buildings': building._id } }
    );
  }

  // Add logging for building creation
  try {
    await addLog({
      action: 'Created',
      name: `${building.name || 'Building'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Building',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log building creation:', logErr);
  }

  return res.status(201).json(
    new ApiResponse(true, 'Building created successfully', { building })
  );
});

// Add a new building with campus_id in payload
export const addBuildingWithPayload = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { campus_id, building_name, floorCount, ...otherData } = req.body;
  
  // Map the payload to the expected format
  const buildingData = {
    campusId: campus_id,
    name: building_name,
    floorCount,
    ...otherData
  };
  
  const building = await buildingService.addBuilding(buildingData, req.user);
  
  return res.status(201).json(
    new ApiResponse(true, 'Building created successfully', { building })
  );
});

// Create building using campus name instead of ID (flexible API)
// - Resolves campus by name with case-insensitive search
// - Alternative endpoint for external integrations
export const addBuildingWithCampusName = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const building = await buildingService.addBuildingWithCampusName(req.body, req.user);

  // Add logging for building creation
  try {
    await addLog({
      action: 'Created',
      name: `${building.name || 'Building'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Building',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log building creation:', logErr);
  }
  
  return res.status(201).json(
    new ApiResponse(true, 'Building created successfully', { building })
  );
});

// Get building by ID
export const getBuildingById = catchAsync(async (req, res) => {
  const { buildingId } = req.params;
  
  const building = await buildingService.getBuildingById(buildingId);
  
  return res.status(200).json(
    new ApiResponse(true, 'Building retrieved successfully', { building })
  );
});

// Update/Edit building by ID
export const updateBuildingById = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { buildingId } = req.params;
  const updateData = req.body;
  
  const building = await buildingService.updateBuildingById(buildingId, updateData, req.user);

  // Add logging for building update
  try {
    await addLog({
      action: 'Updated',
      name: `${building.name || 'Building'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Building',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log building update:', logErr);
  }
  
  return res.status(200).json(
    new ApiResponse(true, 'Building updated successfully', { building })
  );
});

// Update building status by ID
export const updateBuildingStatus = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { buildingId } = req.params;
  const { status } = req.body;
  
  const building = await buildingService.updateBuildingStatus(buildingId, status, req.user);
  
  const statusText = status === 1 ? 'active' : 'inactive';

  // Add logging for building status update
  try {
    await addLog({
      action: 'Status Updated',
      name: `${building.name || 'Building'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Building',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log building status update:', logErr);
  }

  return res.status(200).json(
    new ApiResponse(true, `Building status updated to ${statusText} successfully`, { building })
  );
});

// Delete building with complete cascade cleanup
// - Moves all building devices to 'Discovered' state
// - Permanently deletes floors, zones, and intelligent control data
// - Preserves device hardware for reconfiguration
export const softDeleteBuilding = catchAsync(async (req, res) => {
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { buildingId } = req.params;

  // Get building name before deletion for logging
  let buildingName = 'Building';
  try {
    const buildingToDelete = await buildingService.getBuildingById(buildingId);
    buildingName = buildingToDelete?.name || 'Building';
  } catch (err) {
    // If we can't get the building name, use default
    buildingName = 'Building';
  }
  
  const building = await buildingService.softDeleteBuilding(buildingId, req.user);

  // Add logging for building deletion
  try {
    await addLog({
      action: 'Deleted',
      name: buildingName,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Building',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log building deletion:', logErr);
  }
  
  return res.status(200).json(
    new ApiResponse(true, 'Building deleted successfully. All devices moved to Discovered state and intelligent control data permanently deleted.', building)
  );
});
