/**
 * Role Controller - Permission management business logic
 * 
 * Manages role-based access control for the smart building platform.
 * Handles permission matrix mapping, role lifecycle, and user access coordination.
 * Flow: role.routes.js → role.controller.js → role.service.js → Role/User models
 * 
 * Key Operations:
 * - Permission matrix transformation (UI format ↔ DB format)
 * - Role creation with duplicate handling and reactivation
 * - User access filtering based on allowedResources
 * - Audit logging for role changes
 */

import * as roleService from '../services/role.service.js';
import { User } from '../models/User.js';
import Role from '../models/Role.js';
import { ApiResponse } from '../utils/ApiResponse.js';
import { catchAsync } from '../utils/catchAsync.js';
import { addRoleSchema } from '../validators/role.validator.js';
const { addLog } = await import('../services/log.service.js');


// Permission matrix mapping - converts UI checkbox format to database structure
// Supports both string-based and boolean-based permission formats
// Maps: Full Access → View/Add/Delete, Read Only → View only, Add/Modify → View/Add
const accessMap = {
  'Full Access': { View: true, 'Add/Update': true, Delete: true },
  'Read Only': { View: true, 'Add/Update': false, Delete: false },
  'Add/Modify': { View: true, 'Add/Update': true, Delete: false },
  'Write Only': { View: false, 'Add/Update': true, Delete: false }
};

// Helper function to map boolean permissions to database format
const mapBooleanPermissions = (permissionObj) => {
  // Priority order: fullAccess > addModify > readOnly
  // If multiple are true, take the highest permission level
  if (permissionObj.fullAccess) {
    return { View: true, 'Add/Update': true, Delete: true };
  } else if (permissionObj.addModify) {
    return { View: true, 'Add/Update': true, Delete: false };
  } else if (permissionObj.readOnly) {
    return { View: true, 'Add/Update': false, Delete: false };
  } else {
    return { View: false, 'Add/Update': false, Delete: false };
  }
};

const mapPermissions = (permissions) => {
  const mapped = {};

  if (Array.isArray(permissions)) {
    for (const moduleObj of permissions) {
      const [module, access] = Object.entries(moduleObj)[0];

      if (typeof access === 'string') {
        // Direct access level (string format)
        mapped[module] = accessMap[access] || { View: false, 'Add/Update': false, Delete: false };
      } else if (typeof access === 'object') {
        // Nested entities
        mapped[module] = {};
        for (const [entity, entityAccess] of Object.entries(access)) {
          if (typeof entityAccess === 'string') {
            // String-based access
            mapped[module][entity] = accessMap[entityAccess] || { View: false, 'Add/Update': false, Delete: false };
          } else if (typeof entityAccess === 'object' && (entityAccess.fullAccess !== undefined || entityAccess.readOnly !== undefined || entityAccess.addModify !== undefined)) {
            // Boolean-based access
            mapped[module][entity] = mapBooleanPermissions(entityAccess);
          } else {
            mapped[module][entity] = { View: false, 'Add/Update': false, Delete: false };
          }
        }
      }
    }
  } else {
    // Handle non-array permissions object (your current payload structure)
    for (const [module, access] of Object.entries(permissions)) {
      if (typeof access === 'string') {
        // Direct access level (string format)
        mapped[module] = accessMap[access] || { View: false, 'Add/Update': false, Delete: false };
      } else if (typeof access === 'object') {
        // Nested entities
        mapped[module] = {};
        for (const [entity, entityAccess] of Object.entries(access)) {
          if (typeof entityAccess === 'string') {
            // String-based access
            mapped[module][entity] = accessMap[entityAccess] || { View: false, 'Add/Update': false, Delete: false };
          } else if (typeof entityAccess === 'object' && (entityAccess.fullAccess !== undefined || entityAccess.readOnly !== undefined || entityAccess.addModify !== undefined)) {
            // Boolean-based access (your payload format)
            mapped[module][entity] = mapBooleanPermissions(entityAccess);
          } else {
            mapped[module][entity] = { View: false, 'Add/Update': false, Delete: false };
          }
        }
      }
    }
  }

  return mapped;
};


// Create new role with smart duplicate handling
// - Reactivates soft-deleted roles with same name
// - Prevents creation if active role exists
// - Auto-updates user allowedResources for role access
export const addRole = catchAsync(async (req, res) => {
  const { error } = addRoleSchema.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.details[0].message });

  let { roleName, permissions } = req.body;
  if (!roleName) return res.status(400).json({ success: false, message: 'roleName required' });

  // Normalize input once
  const normalized = roleName.trim();
  const normalizedLower = normalized.toLowerCase();

  console.log('LOG 0 roleName raw:', JSON.stringify(req.body.roleName));
  console.log('LOG 1 normalized:', JSON.stringify(normalized));

  // Check if role exists (regardless of isDelete status)
  const existingRole = await roleService.findRoleByNameCI(normalized);
  console.log('LOG 2 Existing role:', existingRole);

  const mappedPermissions = permissions ? mapPermissions(permissions) : {};

  if (existingRole) {
    // Role exists - check if it's soft-deleted
    if (existingRole.isDelete) {
      // Reactivate the soft-deleted role with new permissions
      const updateData = {
        permissions: mappedPermissions
      };

      try {
        const reactivatedRole = await roleService.reactivateRole(existingRole._id, updateData);
        console.log('LOG 3 Role reactivated:', reactivatedRole);

        // Add logging for role reactivation
        try {
          await addLog({
            action: 'Reactivated',
            name: `${reactivatedRole.roleName || normalized}`,
            timestamp: Math.floor(Date.now() / 1000),
            type: 'Role',
            userId: req.user?._id?.toString() || '-',
            userName: req.user?.fullName || '-',
          });
        } catch (logErr) {
          // eslint-disable-next-line no-console
          console.error('Failed to log role reactivation:', logErr);
        }

        // --- Update allowedResources.userManagement.roles for any user with non-empty array ---
        const { User } = await import('../models/User.js');
        const usersWithAllowedRoles = await User.find({
          'allowedResources.userManagement.roles': { $exists: true, $type: 'array', $ne: [] }
        });
        for (const u of usersWithAllowedRoles) {
          if (!u.allowedResources) u.allowedResources = { userManagement: { roles: [] } };
          if (!u.allowedResources.userManagement) u.allowedResources.userManagement = { roles: [] };
          if (!Array.isArray(u.allowedResources.userManagement.roles)) {
            u.allowedResources.userManagement.roles = [];
          }
          const roleId = reactivatedRole._id.toString();
          if (!u.allowedResources.userManagement.roles.includes(roleId)) {
            u.allowedResources.userManagement.roles.push(roleId);
            u.markModified('allowedResources');
            await u.save();
          }
        }

        return res.status(200).json(new ApiResponse(true, 'Role reactivated successfully', { role: reactivatedRole }));
      } catch (error) {
        console.error('LOG 4 Error reactivating role', error);
        return res.status(500).json({ success: false, message: 'Error reactivating role', error: error.message });
      }
    } else {
      // Role exists and is active - do NOT allow creation
      return res.status(400).json({
        success: false,
        message: 'Role with this name already exists'
      });
    }
  } else {
    // Role doesn't exist - create new role
    const roleData = {
      roleName: normalized,
      roleNameLower: normalizedLower,
      permissions: mappedPermissions,
      isDelete: false,
      isActive: true
    };

    try {
      const savedRole = await roleService.createRole(roleData);
      console.log('LOG 3 Role created:', savedRole);

      // Add logging for role creation
      try {
        await addLog({
          action: 'Created',
          name: `${savedRole.roleName || normalized}`,
          timestamp: Math.floor(Date.now() / 1000),
          type: 'Role',
          userId: req.user?._id?.toString() || '-',
          userName: req.user?.fullName || '-',
        });
      } catch (logErr) {
        // eslint-disable-next-line no-console
        console.error('Failed to log role creation:', logErr);
      }

      // --- Update allowedResources.userManagement.roles for any user with non-empty array ---
      const { User } = await import('../models/User.js');
      const usersWithAllowedRoles = await User.find({
        'allowedResources.userManagement.roles': { $exists: true, $type: 'array', $ne: [] }
      });
      for (const u of usersWithAllowedRoles) {
        if (!u.allowedResources) u.allowedResources = { userManagement: { roles: [] } };
        if (!u.allowedResources.userManagement) u.allowedResources.userManagement = { roles: [] };
        if (!Array.isArray(u.allowedResources.userManagement.roles)) {
          u.allowedResources.userManagement.roles = [];
        }
        const newRoleId = savedRole._id.toString();
        if (!u.allowedResources.userManagement.roles.includes(newRoleId)) {
          u.allowedResources.userManagement.roles.push(newRoleId);
          u.markModified('allowedResources');
          await u.save();
        }
      }

      return res.status(201).json(new ApiResponse(true, 'Role created successfully', { role: savedRole }));
    } catch (error) {
      console.error('LOG 4 Error creating role', error);
      return res.status(500).json({ success: false, message: 'Error creating role', error: error.message });
    }
  }
});

// Get paginated roles list with user access control
// - Filters roles based on user's allowedResources.userManagement.roles
// - Supports search, pagination, status filtering
// - Excludes superadmin roles when check=1
export const getRolesList = catchAsync(async (req, res) => {
  const { search, page, limit, status, check, sort, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;

  const parsedLimit =
    limit !== undefined && limit !== null && `${limit}`.trim() !== ''
      ? Number(limit)
      : undefined;

  const parsedPage =
    page !== undefined && page !== null && `${page}`.trim() !== ''
      ? Number(page)
      : 1;

  let parsedStatus;
  if (status !== undefined && status !== null && `${status}`.trim() !== '') {
    if (`${status}` === '1') parsedStatus = true;
    else if (`${status}` === '0') parsedStatus = false;
  }

  // Parse check parameter
  const parsedCheck = check !== undefined && check !== null && `${check}`.trim() === '1';

  // Handle sort parameter - if provided, it overrides sortOrder for roleName sorting
  let finalSortBy = sortBy || 'createdAt';
  let finalSortOrder = sortOrder || 'desc';
  
  if (sort !== undefined && sort !== null && `${sort}`.trim() !== '') {
    finalSortBy = 'roleName';
    finalSortOrder = `${sort}`.trim().toLowerCase() === 'asc' ? 'asc' : 'desc';
  }

  const params = {
    search: search || '',
    page: parsedPage,
    limit: parsedLimit,
    status: parsedStatus,
    sortBy: finalSortBy,
    sortOrder: finalSortOrder,
  };

  // Get current user's allowed role IDs
  const userId = req.user?._id;
  if (!userId) {
    return res.status(401).json({ success: false, message: 'Unauthorized: user not found' });
  }
  
  const user = await User.findById(userId, 'allowedResources');
  let allowedRoleIds = [];
  
  if (user.allowedResources !== null) {
    allowedRoleIds = user?.allowedResources?.userManagement?.roles || [];
  }

  // Use the service to get roles with proper pagination and sorting
  const result = await roleService.getRolesList({
    ...params,
    allowedRoleIds: user.allowedResources === null ? null : allowedRoleIds,
    excludeSuperadmin: parsedCheck
  });

  // Ensure totalNonDeleted is the sum of totalActive and totalInactive
  if (result && typeof result === 'object') {
    const totalActive = result.totalActive || 0;
    const totalInactive = result.totalInactive || 0;
    result.totalNonDeleted = totalActive + totalInactive;
  }

  return res.json({
    success: true,
    message: 'Roles list fetched successfully',
    data: result
  });
});

// Update role with duplicate name prevention
// - Handles name conflicts by renaming deleted roles
// - Maps permissions from UI format to DB structure
// - Logs all role modifications for audit trail
export const updateRole = catchAsync(async (req, res) => {
  const { roleId } = req.params;
  const { roleName, permissions } = req.body;

  // Prevent duplicate role names (rename deleted roles to avoid conflicts)
  if (roleName) {
    const trimmedRoleName = roleName.trim();
    
    // Find any existing role with the same name (including deleted ones)
    const existingRole = await roleService.findRoleByNameCI(trimmedRoleName);
    
    if (existingRole && existingRole._id.toString() !== roleId) {
      // If existing role is not deleted, it's a conflict
      if (!existingRole.isDelete) {
        return res.status(400).json({
          success: false,
          message: 'Another role with this name already exists'
        });
      }
      // If existing role is deleted, we need to handle the unique constraint
      // by first updating the deleted role's name to avoid conflict
      await roleService.updateRole(existingRole._id, { 
        roleName: `${existingRole.roleName}_deleted_${Date.now()}` 
      });
    }
  }

  // ✅ Map permissions if provided
  const mappedPermissions = permissions ? mapPermissions(permissions) : undefined;

  const updateData = {};
  if (roleName) updateData.roleName = roleName.trim();
  if (mappedPermissions) updateData.permissions = mappedPermissions;

  try {
    const updatedRole = await roleService.updateRole(roleId, updateData);

    if (!updatedRole) {
      return res.status(404).json({
        success: false,
        message: 'Role not found'
      });
    }

    // Add logging for role update
    try {
      await addLog({
        action: 'Updated',
        name: `${updatedRole.roleName || roleName || 'Role'}`,
        timestamp: Math.floor(Date.now() / 1000),
        type: 'Role',
        userId: req.user?._id?.toString() || '-',
        userName: req.user?.fullName || '-',
      });
    } catch (logErr) {
      // eslint-disable-next-line no-console
      console.error('Failed to log role update:', logErr);
    }

    return res.status(200).json(
      new ApiResponse(true, 'Role updated successfully', { role: updatedRole })
    );
  } catch (error) {
    if (error.code === 11000 || error.message.includes('Duplicate role name not allowed')) {
      return res.status(400).json({
        success: false,
        message: 'Duplicate role name not allowed'
      });
    }

    return res.status(500).json({
      success: false,
      message: 'Error updating role',
      error: error.message
    });
  }
});

export const deleteRole = catchAsync(async (req, res) => {
  const { roleId } = req.params;

  // Get role name before deletion for logging
  let roleName = 'Role';
  try {
    const roleToDelete = await roleService.getRoleById(roleId);
    roleName = roleToDelete?.roleName || 'Role';
  } catch (err) {
    // If we can't get the role name, use default
    roleName = 'Role';
  }

  const deletedRole = await roleService.deleteRole(roleId);

  if (!deletedRole) {
    return res.status(404).json({
      success: false,
      message: 'Role not found'
    });
  }

  // Add logging for role deletion
  try {
    await addLog({
      action: 'Deleted',
      name: roleName,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Role',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log role deletion:', logErr);
  }

  return res.status(200).json(
    new ApiResponse(true, 'Role deleted successfully', { role: deletedRole })
  );
});

export const activateRole = catchAsync(async (req, res) => {
  const { roleId } = req.params;
  const { isActive } = req.body;

  // Validate isActive is provided and is a boolean
  if (typeof isActive !== 'boolean') {
    return res.status(400).json({
      success: false,
      message: 'isActive field is required and must be a boolean value'
    });
  }

  const updatedRole = await roleService.activateRole(roleId, isActive);

  if (!updatedRole) {
    return res.status(404).json({
      success: false,
      message: 'Role not found'
    });
  }

  const message = isActive ? 'Role activated successfully' : 'Role deactivated successfully';

  // Add logging for role activation/deactivation
  try {
    await addLog({
      action: isActive ? 'Activated' : 'Deactivated',
      name: `${updatedRole.roleName || 'Role'}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Role',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log role activation/deactivation:', logErr);
  }

  return res.status(200).json(
    new ApiResponse(true, message, { role: updatedRole })
  );
});
// New API: Get role details by ID
export const getRoleById = catchAsync(async (req, res) => {
  const { roleId } = req.params;

  const role = await roleService.getRoleById(roleId);

  if (!role) {
    return res.status(404).json({
      success: false,
      message: 'Role not found'
    });
  }

  // Check if role is deleted
  if (role.isDelete) {
    return res.status(404).json({
      success: false,
      message: 'Role not found'
    });
  }

  return res.status(200).json(
    new ApiResponse(true, 'Role details fetched successfully', { role })
  );
});

// Get role permission sections configuration for UI
// Returns structured permission categories and access levels
// Used by frontend to render role permission matrix interface
export const getRoleSections = catchAsync(async (req, res) => {
  const sections = roleService.getRoleSections();
  return res.status(200).json(new ApiResponse(true, 'Role sections fetched successfully', sections));
});
