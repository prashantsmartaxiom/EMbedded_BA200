/**
 * Campus Controller - Business Logic Layer
 * 
 * Flow: routes → CONTROLLER → service → database
 * 
 * Responsibilities:
 * - Input validation & sanitization
 * - Authentication/authorization checks
 * - Request/response formatting
 * - Error handling with try/catch
 * - Logging user actions
 * - Image URL attachment
 * 
 * Each function:
 * 1. Validates user authentication
 * 2. Calls appropriate service method
 * 3. Logs the action
 * 4. Returns formatted API response
 */
import { getAuthorizedList } from '../utils/authorizedList.js';
import { filterByUserResourceAccess } from '../utils/filterByUserAccess.js';
import { buildUserFilter } from '../utils/buildUserFilter.js';
import { Campus } from '../models/Campus.js';
import { catchAsync } from '../utils/catchAsync.js';
import { ApiResponse } from '../utils/ApiResponse.js';
import * as campusService from '../services/campus.service.js';
import * as optimizedService from '../services/optimized.service.js';
const { addLog } = await import('../services/log.service.js');

/**
 * Get all campuses with filtering, pagination, and user permissions
 * 
 * Process:
 * 1. Build user permission filter
 * 2. Query campuses with optimized service
 * 3. Attach image URLs from filesystem
 * 4. Return paginated results with search info
 */
export const getAllCampuses = catchAsync(async (req, res) => {
  // Build user-specific filter for database-level filtering
  const userFilter = buildUserFilter(req.user, 'campuses');

  // Get campuses with efficient database filtering and pagination
  const result = await optimizedService.getOptimizedCampuses({
    ...req.query,
    userFilter
  });

  // Attach image URLs by checking filesystem for campus images
  const fs = await import('fs');
  const path = await import('path');
  const imageDir = path.resolve(process.cwd(), 'public', 'images', 'campus');
  const imageExtensions = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'];
  const campusesWithImage = result.campuses.map(campus => {
    let imageUrl = null;
    // Check if image file exists with campus ID as filename
    for (const ext of imageExtensions) {
      const imagePath = path.join(imageDir, `${campus._id}.${ext}`);
      try {
        if (fs.existsSync(imagePath)) {
          imageUrl = `${req.protocol}://${req.get('host')}/images/campus/${campus._id}.${ext}`;
          break;
        }
      } catch (err) {
        // ignore error, try next extension
      }
    }
    return {
      ...campus,
      imageUrl
    };
  });

  // Create searchInfo
  const { search, name, location } = req.query;
  const searchInfo = {
    searchTerm: search || null,
    nameFilter: name || null,
    locationFilter: location || null,
    resultsFound: campusesWithImage.length,
    totalMatches: result.pagination.totalCampuses
  };

  return res.status(200).json(
    new ApiResponse(
      true,
      'Campuses retrieved successfully',
      {
        campuses: campusesWithImage,
        totalNonDeleted: result.pagination.totalNonDeleted,
        totalActive: result.pagination.totalActive,
        totalInactive: result.pagination.totalInactive,
        pagination: result.pagination,
        searchInfo
      }
    )
  );
});
// export const getAllCampuses = catchAsync(async (req, res) => {
//   const result = await getAuthorizedList({
//     user: req.user,
//     moduleKey: 'CAMPUS_MANAGEMENT',
//     resourceKey: 'campuses',            // Maps to 'campus_management' permission
//     model: Campus,
//     queryParams: req.query,
//     baseFilter: {},                     // Include both deleted and non-deleted as per your example
//     populate: [
//       {
//         path: 'buildings',
//         select: '_id'
//       },
//       {
//         path: 'createdBy.userId',
//         select: 'fullName email'
//       },
//       {
//         path: 'updatedBy.userId',
//         select: 'fullName email'
//       }
//     ],
//     transformResult: (doc) => ({
//       _id: doc._id,
//       name: doc.name,
//       status: doc.status,
//       location: doc.location,
//       type: doc.type,
//       description: doc.description || '',
//       campusImage: doc.campusImage || null,
//       organization: doc.organization || 'Smart Axiom Inc',
//       buildings: doc.buildings ? doc.buildings.map(building => building._id) : [],
//       createdBy: doc.createdBy?.userId ? {
//         userId: {
//           _id: doc.createdBy.userId._id,
//           fullName: doc.createdBy.userId.fullName,
//           email: doc.createdBy.userId.email
//         },
//         fullName: doc.createdBy.userId.fullName,
//         email: doc.createdBy.userId.email
//       } : null,
//       updatedBy: doc.updatedBy?.userId ? {
//         userId: {
//           _id: doc.updatedBy.userId._id,
//           fullName: doc.updatedBy.userId.fullName,
//           email: doc.updatedBy.userId.email
//         },
//         fullName: doc.updatedBy.userId.fullName,
//         email: doc.updatedBy.userId.email
//       } : null,
//       isDelete: doc.isDelete,
//       createdAt: doc.createdAt,
//       updatedAt: doc.updatedAt,
//       accessId: doc.accessId,
//       __v: doc.__v,
//       buildingCount: doc.buildingCount || 0,
//       floorCount: doc.floorCount || 0,
//       zoneCount: doc.zoneCount || 0,
//       imageUrl: doc.imageUrl || null
//     })
//   });

//   // Extract search parameters for searchInfo
//   const { search, name, location } = req.query;

//   return res.status(200).json(
//     new ApiResponse(true, 'Campuses retrieved successfully', {
//       campuses: result.data,
//       pagination: {
//         currentPage: result.page,
//         totalPages: Math.ceil(result.total / result.limit),
//         totalCampuses: result.total,
//         hasNextPage: result.page < Math.ceil(result.total / result.limit),
//         hasPrevPage: result.page > 1
//       },
//       searchInfo: {
//         searchTerm: search || null,
//         nameFilter: name || null,
//         locationFilter: location || null,
//         resultsFound: result.data.length,
//         totalMatches: result.total
//       }
//     })
//   );
// });

/**
 * Create new campus with buildings and image upload
 * 
 * Process:
 * 1. Validate user authentication
 * 2. Create campus via service (handles buildings creation)
 * 3. Update user permissions for new campus
 * 4. Log the creation action
 */
export const addCampus = catchAsync(async (req, res) => {
  // Check if user is authenticated
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

    const campus = await campusService.addCampus(req.body, req.user);

    // Grant access to new campus for users with campus management permissions
    const { User } = await import('../models/User.js');
    if (campus && campus._id) {
      await User.updateMany(
        { 'allowedResources.campusManagement.campuses': { $exists: true, $type: 'array' } },
        { $addToSet: { 'allowedResources.campusManagement.campuses': campus._id } }
      );
    }

    // Add logging for campus creation
    try {
      
      await addLog({
        action: 'Created',
        name: `${campus.name}`,
        timestamp: Math.floor(Date.now() / 1000),
        type: 'Campus',
        userId: req.user?._id?.toString() || '-',
        userName: req.user?.fullName || '-',
      });
    } catch (logErr) {
      // eslint-disable-next-line no-console
      console.error('Failed to log campus creation:', logErr);
    }

    return res.status(201).json(
      new ApiResponse(true, 'Campus created successfully', { campus })
    );
});

/**
 * Update existing campus data
 * Includes logging and user validation
 */
export const updateCampus = catchAsync(async (req, res) => {
  // Check if user is authenticated
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { campusId } = req.params;
  const updateData = req.body;

  const campus = await campusService.updateCampus(campusId, updateData, req.user);

  // Add logging for campus update
  try {
    
    await addLog({
      action: 'Updated',
      name: `${campus.name}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Campus',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log campus update:', logErr);
  }

  return res.status(200).json(
    new ApiResponse(true, 'Campus updated successfully', { campus })
  );
});

/**
 * Soft delete campus and cascade to buildings/floors/zones
 * Moves all devices to 'Discovered' state, deletes intelligent control data
 */
export const deleteCampus = catchAsync(async (req, res) => {
  // Check if user is authenticated
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { campusId } = req.params;

  // Get campus name before deletion for logging
  let campusName = 'Campus';
  try {
    const campusToDelete = await campusService.getCampusById(campusId);
    campusName = campusToDelete?.name || 'Campus';
  } catch (err) {
    // If we can't get the campus name, use default
    campusName = 'Campus';
  }

  const result = await campusService.deleteCampus(campusId, req.user);

  // Add logging for campus deletion
  try {
    
    await addLog({
      action: 'Deleted',
      name: campusName,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Campus',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log campus deletion:', logErr);
  }
  
  return res.status(200).json(
    new ApiResponse(true, 'Campus deleted successfully. All devices moved to Discovered state and intelligent control data permanently deleted.', result)
  );
});

/**
 * Get single campus by ID with image URL attachment
 */
export const getCampusById = catchAsync(async (req, res) => {
  const { campusId } = req.params;

  const campus = await campusService.getCampusById(campusId);


  // Check if image exists in public/images/campus/<campusId>.<ext>
  const fs = await import('fs');
  const path = await import('path');
  const imageDir = path.resolve(process.cwd(), 'public', 'images', 'campus');
  const imageExtensions = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'];
  let imageUrl = null;
  for (const ext of imageExtensions) {
    const imagePath = path.join(imageDir, `${campusId}.${ext}`);
    try {
      if (fs.existsSync(imagePath)) {
        imageUrl = `${req.protocol}://${req.get('host')}/images/campus/${campusId}.${ext}`;
        break;
      }
    } catch (err) {
      // ignore error, try next extension
    }
  }

  // Attach imageUrl to campus response
  const campusWithImage = {
    ...campus,
    imageUrl
  };

  return res.status(200).json(
    new ApiResponse(true, 'Campus retrieved successfully', { campus: campusWithImage })
  );
});

/**
 * Get campus with complete hierarchy (buildings → floors → zones)
 * Used for detailed campus management views
 */
export const getCampusWithHierarchy = catchAsync(async (req, res) => {
  const { campusId } = req.params;

  const campusData = await campusService.getCampusWithHierarchy(campusId);

  return res.status(200).json(
    new ApiResponse(
      true,
      'Campus data with hierarchy retrieved successfully',
      { campus: campusData }
    )
  );
});

// Update campus status only - requires authentication
export const updateCampusStatus = catchAsync(async (req, res) => {
  // Check if user is authenticated
  if (!req.user) {
    return res.status(401).json(
      new ApiResponse(false, 'Authentication required. Please login first.', null)
    );
  }

  const { campusId } = req.params;
  const { status } = req.body;

  const campus = await campusService.updateCampusStatus(campusId, status, req.user);

  // Add logging for campus status update
  try {
    
    await addLog({
      action: 'Status Updated',
      name: `${campus.name}`,
      timestamp: Math.floor(Date.now() / 1000),
      type: 'Campus',
      userId: req.user?._id?.toString() || '-',
      userName: req.user?.fullName || '-',
    });
  } catch (logErr) {
    // eslint-disable-next-line no-console
    console.error('Failed to log campus status update:', logErr);
  }

  return res.status(200).json(
    new ApiResponse(true, 'Campus status updated successfully', { campus })
  );
});

// Get campus view with detailed information including buildings, floors and zones
export const getCampusView = catchAsync(async (req, res) => {
  const result = await campusService.getCampusView(req.query);

  return res.status(200).json(
    new ApiResponse(
      true,
      'Campus view retrieved successfully',
      {
        campusViews: result.campusViews,
        pagination: result.pagination,
        searchInfo: result.searchInfo
      }
    )
  );
});

// Get all active campuses only (status = 1) - filtered by user's campusData
export const getActiveCampuses = catchAsync(async (req, res) => {
  // Build user-specific filter for database-level filtering
  const userFilter = buildUserFilter(req.user, 'campuses');
  
  // Get active campuses with user filtering
  const result = await campusService.getActiveCampuses({ 
    ...req.query, 
    userFilter 
  });

  return res.status(200).json(
    new ApiResponse(
      true,
      'Active campuses retrieved successfully',
      {
        campuses: result.activeCampuses,
        pagination: result.pagination,
        searchInfo: result.searchInfo
      }
    )
  );
});

// Get campus types for dropdown
export const getCampusTypes = catchAsync(async (req, res) => {
  const types = campusService.getCampusTypes();

  return res.status(200).json(
    new ApiResponse(true, 'Campus types retrieved successfully', { types })
  );
});
