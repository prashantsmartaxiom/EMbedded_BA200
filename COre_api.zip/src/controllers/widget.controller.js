/**
 * Widget Controller - Dashboard component and data visualization orchestration
 * 
 * Flow: widget.routes.js → widget.controller.js → widget.service.js → MongoDB Collections
 * 
 * Orchestrates widget ecosystem operations:
 * - Timezone management with global predefined data and lifecycle operations
 * - Weather integration with third-party APIs and real-time data processing
 * - Widget storage management for dashboard customization and persistence
 * - AQI and temperature monitoring with location-based services
 * - Real-time data synchronization with socket notifications
 * - Bulk operations for multi-city weather data processing
 */

import * as widgetService from '../services/widget.service.js';
import { ApiResponse } from '../utils/ApiResponse.js';
import { catchAsync } from '../utils/catchAsync.js';
import { socketManager } from '../utils/socketManager.js';

// Predefined timezone data
const timezoneData = [
    { timeZoneName: "UTC (UTC +00:00)", timeZoneValue: "UTC" },
    { timeZoneName: "GMT (GMT +00:00)", timeZoneValue: "GMT" },
    { timeZoneName: "EST (EST -05:00)", timeZoneValue: "America/New_York" },
    { timeZoneName: "CST (CST -06:00)", timeZoneValue: "America/Chicago" },
    { timeZoneName: "MST (MST -07:00)", timeZoneValue: "America/Denver" },
    { timeZoneName: "PST (PST -08:00)", timeZoneValue: "America/Los_Angeles" },
    { timeZoneName: "IST (IST +05:30)", timeZoneValue: "Asia/Kolkata" },
    { timeZoneName: "JST (JST +09:00)", timeZoneValue: "Asia/Tokyo" },
    { timeZoneName: "CET (CET +01:00)", timeZoneValue: "Europe/Paris" },
    { timeZoneName: "EET (EET +02:00)", timeZoneValue: "Europe/Athens" },
    { timeZoneName: "BST (BST +01:00)", timeZoneValue: "Europe/London" },
    { timeZoneName: "AEST (AEST +10:00)", timeZoneValue: "Australia/Sydney" },
    { timeZoneName: "NZST (NZST +12:00)", timeZoneValue: "Pacific/Auckland" },
    { timeZoneName: "SGT (SGT +08:00)", timeZoneValue: "Asia/Singapore" },
    { timeZoneName: "HKT (HKT +08:00)", timeZoneValue: "Asia/Hong_Kong" },
    { timeZoneName: "KST (KST +09:00)", timeZoneValue: "Asia/Seoul" },
    { timeZoneName: "CST (CST +08:00)", timeZoneValue: "Asia/Shanghai" },
    { timeZoneName: "MSK (MSK +03:00)", timeZoneValue: "Europe/Moscow" },
    { timeZoneName: "SAST (SAST +02:00)", timeZoneValue: "Africa/Johannesburg" },
    { timeZoneName: "BRT (BRT -03:00)", timeZoneValue: "America/Sao_Paulo" },
    { timeZoneName: "ART (ART -03:00)", timeZoneValue: "America/Argentina/Buenos_Aires" },
    { timeZoneName: "CLT (CLT -03:00)", timeZoneValue: "America/Santiago" },
    { timeZoneName: "PET (PET -05:00)", timeZoneValue: "America/Lima" },
    { timeZoneName: "VET (VET -04:00)", timeZoneValue: "America/Caracas" },
    { timeZoneName: "UYT (UYT -03:00)", timeZoneValue: "America/Montevideo" },
    { timeZoneName: "PYT (PYT -04:00)", timeZoneValue: "America/Asuncion" },
    { timeZoneName: "BOT (BOT -04:00)", timeZoneValue: "America/La_Paz" },
    { timeZoneName: "GYT (GYT -04:00)", timeZoneValue: "America/Guyana" },
    { timeZoneName: "COT (COT -05:00)", timeZoneValue: "America/Bogota" },
    { timeZoneName: "ECT (ECT -05:00)", timeZoneValue: "America/Guayaquil" },
    { timeZoneName: "GFT (GFT -03:00)", timeZoneValue: "America/Cayenne" },
    { timeZoneName: "WGT (WGT -03:00)", timeZoneValue: "America/Godthab" },
    { timeZoneName: "FKT (FKT -04:00)", timeZoneValue: "Atlantic/Stanley" },
    { timeZoneName: "BRST (BRST -02:00)", timeZoneValue: "America/Sao_Paulo" },
    { timeZoneName: "NDT (NDT -02:30)", timeZoneValue: "America/St_Johns" },
    { timeZoneName: "ADT (ADT -03:00)", timeZoneValue: "America/Halifax" },
    { timeZoneName: "EDT (EDT -04:00)", timeZoneValue: "America/New_York" },
    { timeZoneName: "CDT (CDT -05:00)", timeZoneValue: "America/Chicago" },
    { timeZoneName: "MDT (MDT -06:00)", timeZoneValue: "America/Denver" },
    { timeZoneName: "PDT (PDT -07:00)", timeZoneValue: "America/Los_Angeles" },
    { timeZoneName: "AKDT (AKDT -08:00)", timeZoneValue: "America/Anchorage" },
    { timeZoneName: "HADT (HADT -09:00)", timeZoneValue: "Pacific/Honolulu" },
    { timeZoneName: "WET (WET +00:00)", timeZoneValue: "Europe/London" },
    { timeZoneName: "WEST (WEST +01:00)", timeZoneValue: "Europe/London" },
    { timeZoneName: "CEST (CEST +02:00)", timeZoneValue: "Europe/Paris" },
    { timeZoneName: "EEST (EEST +03:00)", timeZoneValue: "Europe/Athens" },
    { timeZoneName: "MSD (MSD +04:00)", timeZoneValue: "Europe/Moscow" },
    { timeZoneName: "GST (GST +04:00)", timeZoneValue: "Asia/Dubai" },
    { timeZoneName: "PKT (PKT +05:00)", timeZoneValue: "Asia/Karachi" },
    { timeZoneName: "BDT (BDT +06:00)", timeZoneValue: "Asia/Dhaka" },
    { timeZoneName: "ICT (ICT +07:00)", timeZoneValue: "Asia/Bangkok" },
    { timeZoneName: "WIT (WIT +07:00)", timeZoneValue: "Asia/Jakarta" },
    { timeZoneName: "PHT (PHT +08:00)", timeZoneValue: "Asia/Manila" },
    { timeZoneName: "AWST (AWST +08:00)", timeZoneValue: "Australia/Perth" },
    { timeZoneName: "ACST (ACST +09:30)", timeZoneValue: "Australia/Adelaide" },
    { timeZoneName: "AEST (AEST +10:00)", timeZoneValue: "Australia/Brisbane" },
    { timeZoneName: "ACDT (ACDT +10:30)", timeZoneValue: "Australia/Adelaide" },
    { timeZoneName: "AEDT (AEDT +11:00)", timeZoneValue: "Australia/Sydney" },
    { timeZoneName: "NZDT (NZDT +13:00)", timeZoneValue: "Pacific/Auckland" },
    { timeZoneName: "FJT (FJT +12:00)", timeZoneValue: "Pacific/Fiji" },
    { timeZoneName: "TVT (TVT +12:00)", timeZoneValue: "Pacific/Funafuti" },
    { timeZoneName: "GILT (GILT +12:00)", timeZoneValue: "Pacific/Tarawa" },
    { timeZoneName: "WST (WST +13:00)", timeZoneValue: "Pacific/Apia" },
    { timeZoneName: "CHAST (CHAST +12:45)", timeZoneValue: "Pacific/Chatham" },
    { timeZoneName: "CHADT (CHADT +13:45)", timeZoneValue: "Pacific/Chatham" },
    { timeZoneName: "LINT (LINT +14:00)", timeZoneValue: "Pacific/Kiritimati" },
    { timeZoneName: "TOT (TOT +13:00)", timeZoneValue: "Pacific/Tongatapu" },
    { timeZoneName: "CHUT (CHUT +10:00)", timeZoneValue: "Pacific/Chuuk" },
    { timeZoneName: "PONT (PONT +11:00)", timeZoneValue: "Pacific/Pohnpei" },
    { timeZoneName: "KOST (KOST +11:00)", timeZoneValue: "Pacific/Kosrae" },
    { timeZoneName: "MHT (MHT +12:00)", timeZoneValue: "Pacific/Majuro" },
    { timeZoneName: "NRT (NRT +12:00)", timeZoneValue: "Pacific/Nauru" },
    { timeZoneName: "PWT (PWT +09:00)", timeZoneValue: "Pacific/Palau" },
    { timeZoneName: "CHST (CHST +10:00)", timeZoneValue: "Pacific/Guam" }
];

/**
 * Get all active timezones for widget display
 * Returns simple list of timezone names and values for frontend dropdowns
 */
export const getTimezones = catchAsync(async (req, res) => {
  const timezones = await widgetService.getAllTimezones();
  
  res.status(200).json(new ApiResponse(
    true, 
    'Timezones fetched successfully', 
    timezones
  ));
});

/**
 * Get all timezones including inactive ones
 */
export const getAllTimezonesIncludingInactive = catchAsync(async (req, res) => {
  const timezones = await widgetService.getAllTimezonesIncludingInactive();
  
  res.status(200).json(new ApiResponse(
    true, 
    'All timezones fetched successfully', 
    timezones
  ));
});



/**
 * Get timezone by ID
 */
export const getTimezone = catchAsync(async (req, res) => {
  const { id } = req.params;
  
  const timezone = await widgetService.getTimezoneById(id);
  
  if (!timezone) {
    return res.status(404).json(new ApiResponse(
      false, 
      'Timezone not found'
    ));
  }
  
  res.status(200).json(new ApiResponse(
    true, 
    'Timezone fetched successfully', 
    timezone
  ));
});

/**
 * Create a new timezone
 */
export const createTimezone = catchAsync(async (req, res) => {
  const { timeZoneName, timeZoneValue } = req.body;
  
  if (!timeZoneName || !timeZoneValue) {
    return res.status(400).json(new ApiResponse(
      false, 
      'Timezone name and value are required'
    ));
  }
  
  const createdBy = req.user ? {
    userId: req.user._id,
    fullName: req.user.fullName,
    email: req.user.email
  } : null;
  
  const timezoneData = {
    timeZoneName,
    timeZoneValue,
    createdBy,
    createdDate: new Date().toISOString()
  };
  
  const result = await widgetService.createOrActivateTimezone(timezoneData);
  
  const statusCode = result.status === 'created' ? 201 : 200;
  const message = result.status === 'created' 
    ? 'Timezone created successfully' 
    : 'Timezone activated successfully';
  
  res.status(statusCode).json(new ApiResponse(
    true, 
    message, 
    result.data
  ));
});





/**
 * Toggle timezone status (activate/deactivate)
 */
export const toggleTimezoneStatus = catchAsync(async (req, res) => {
  const { id } = req.params;
  const { isActive } = req.body;
  
  if (typeof isActive !== 'boolean') {
    return res.status(400).json(new ApiResponse(
      false, 
      'isActive field is required and must be boolean'
    ));
  }
  
  const existing = await widgetService.getTimezoneById(id);
  if (!existing) {
    return res.status(404).json(new ApiResponse(
      false, 
      'Timezone not found'
    ));
  }
  
  const updatedBy = req.user ? {
    userId: req.user._id,
    fullName: req.user.fullName,
    email: req.user.email
  } : null;
  
  const timezone = await widgetService.toggleTimezoneStatus(id, isActive, updatedBy);
  
  res.status(200).json(new ApiResponse(
    true, 
    `Timezone ${isActive ? 'activated' : 'deactivated'} successfully`, 
    timezone
  ));
});

/**
 * Update timezone information
 */
export const updateTimezone = catchAsync(async (req, res) => {
  const { id } = req.params;
  const { timeZoneName, timeZoneValue } = req.body;
  
  if (!timeZoneName || !timeZoneValue) {
    return res.status(400).json(new ApiResponse(
      false, 
      'Timezone name and value are required'
    ));
  }
  
  const existing = await widgetService.getTimezoneById(id);
  if (!existing) {
    return res.status(404).json(new ApiResponse(
      false, 
      'Timezone not found'
    ));
  }
  
  const updatedBy = req.user ? {
    userId: req.user._id,
    fullName: req.user.fullName,
    email: req.user.email
  } : null;
  
  const updateData = {
    timeZoneName,
    timeZoneValue,
    updatedBy,
    updatedDate: new Date().toISOString()
  };
  
  const result = await widgetService.updateTimezone(id, updateData);
  
  // Handle different response types based on the operation result
  const statusCode = result.status === 'updated' ? 200 : 200;
  const message = result.message || 'Timezone updated successfully';
  
  res.status(statusCode).json(new ApiResponse(
    true, 
    message, 
    result.data,
    { operationType: result.status }
  ));
});

/**
 * Initialize timezones with predefined data
 */
export const initializeTimezones = catchAsync(async (req, res) => {
  const createdBy = req.user ? {
    userId: req.user._id,
    fullName: req.user.fullName,
    email: req.user.email
  } : null;
  
  const results = await widgetService.bulkInsertTimezones(timezoneData, createdBy);
  
  const created = results.filter(r => r.status === 'created').length;
  const existing = results.filter(r => r.status === 'exists').length;
  
  res.status(200).json(new ApiResponse(
    true, 
    `Timezone initialization completed. ${created} new timezones created, ${existing} already existed.`, 
    { created, existing, details: results }
  ));
});

/**
 * Get weather information by location coordinates
 * Integrates with Open-Meteo API for comprehensive weather and AQI data
 * Creates/updates weather record with location-specific timezone handling
 */
export const getWeatherInfo = catchAsync(async (req, res) => {
  const { lat, long, placeName } = req.body;
  const userId = req.user._id;

  if (!lat || !long || !placeName) {
    return res.status(400).json(new ApiResponse(
      false, 
      'Latitude, longitude, and place name are required'
    ));
  }

  const result = await widgetService.getWeatherInfo(userId, lat, long, placeName);
  
  const statusCode = result.status === 'created' ? 201 : 200;
  const message = result.status === 'created' 
    ? 'Weather data created successfully' 
    : 'Weather data retrieved successfully';

  res.status(statusCode).json(new ApiResponse(
    true, 
    message, 
    result.data
  ));
});

/**
 * Get weather data by user ID
 */
export const getWeatherByUser = catchAsync(async (req, res) => {
  const userId = req.user._id;
  
  const weatherData = await widgetService.getWeatherByUserId(userId);
  
  res.status(200).json(new ApiResponse(
    true, 
    'User weather data fetched successfully', 
    weatherData
  ));
});

/**
 * Get weather data by coordinates
 */
export const getWeatherByCoordinates = catchAsync(async (req, res) => {
  const { lat, long } = req.query;
  
  if (!lat || !long) {
    return res.status(400).json(new ApiResponse(
      false, 
      'Latitude and longitude are required'
    ));
  }
  
  const weatherData = await widgetService.getWeatherByCoordinates(
    parseFloat(lat), 
    parseFloat(long)
  );
  
  if (!weatherData) {
    return res.status(404).json(new ApiResponse(
      false, 
      'Weather data not found for these coordinates'
    ));
  }
  
  res.status(200).json(new ApiResponse(
    true, 
    'Weather data fetched successfully', 
    weatherData
  ));
});

/**
 * Get current temperature for multiple cities
 */
export const getCurrentTemperatures = catchAsync(async (req, res) => {
  const { cities } = req.body;
  
  if (!cities || !Array.isArray(cities) || cities.length === 0) {
    return res.status(400).json(new ApiResponse(
      false, 
      'Cities array is required and must not be empty'
    ));
  }

  if (cities.length > 50) {
    return res.status(400).json(new ApiResponse(
      false, 
      'Maximum 50 cities allowed per request'
    ));
  }

  const result = await widgetService.getCurrentTemperatures(cities);
  
  res.status(200).json(new ApiResponse(
    true, 
    `Temperature data fetched for ${result.successCount}/${result.totalCities} cities`, 
    result
  ));
});

/**
 * Get all weather data (active and not deleted)
 */
export const getAllWeatherData = catchAsync(async (req, res) => {
  const weatherList = await widgetService.getAllWeatherData();
  res.status(200).json(new ApiResponse(
    true,
    'All weather data fetched successfully',
    weatherList
  ));
});

/**
 * Get first weather data (active and not deleted)
 */
export const getFirstWeatherData = catchAsync(async (req, res) => {
  const firstWeatherData = await widgetService.getFirstWeatherData();
  res.status(200).json(new ApiResponse(
    true,
    'First weather data fetched successfully',
    firstWeatherData
  ));
});

/**
 * Update weather information
 */
export const updateWeather = catchAsync(async (req, res) => {
  const { id } = req.params;
  const { lat, long, placeName } = req.body;

  if (!lat || !long || !placeName) {
    return res.status(400).json(new ApiResponse(
      false,
      'Latitude, longitude, and place name are required'
    ));
  }

  const result = await widgetService.updateWeatherWithFreshData(id, lat, long, placeName, req.user._id);

  res.status(200).json(new ApiResponse(
    true,
    'Weather updated successfully',
    result.data
  ));
});

/**
 * Get current hour AQI and temperature for specific coordinates
 * Public endpoint for real-time air quality and temperature monitoring
 * Returns location-timezone adjusted data for accurate current conditions
 */
export const getAqiAndTemperatureCurrentHour = catchAsync(async (req, res) => {
  const { lat, long, longitude } = req.query;
  const lngValue = long !== undefined ? long : longitude;
  if (!lat || lngValue === undefined) {
    return res.status(400).json(new ApiResponse(
      false,
      'Latitude and longitude are required'
    ));
  }
  const result = await widgetService.getAqiAndTemperatureCurrentHour(parseFloat(lat), parseFloat(lngValue));
  res.status(200).json(new ApiResponse(
    true,
    'AQI and temperature for current hour fetched successfully',
    result
  ));
});

/**
 * Delete weather location
 */
export const deleteWeather = catchAsync(async (req, res) => {
  const { id } = req.params;

  const existing = await widgetService.getWeatherById(id);
  if (!existing) {
    return res.status(404).json(new ApiResponse(
      false,
      'Weather record not found'
    ));
  }

  const deletedBy = {
    userId: req.user._id,
    fullName: req.user.fullName,
    email: req.user.email
  };

  const updateData = {
    isDeleted: true,
    deletedBy,
    deletedDate: new Date().toISOString()
  };

  await widgetService.updateWeather(id, updateData);

  res.status(200).json(new ApiResponse(
    true,
    'Weather location deleted successfully'
  ));
});

/**
 * Refresh weather data for all active locations
 * Bulk operation to update all weather records with fresh API data
 * Emits socket event for real-time dashboard updates
 */
export const refreshAllWeatherData = catchAsync(async (req, res) => {
  const userId = req.user ? req.user._id : null;
  const result = await widgetService.refreshAllWeatherData(userId);
  // Emit socket event after successful API call
  socketManager.emitEvent('weatherDataRefreshed', {
    message: `Weather data refreshed for ${result.successCount}/${result.totalCount} locations`,
    successCount: result.successCount,
    totalCount: result.totalCount,
    timestamp: new Date().toISOString(),
    result: result
  });
  
  res.status(200).json(new ApiResponse(
    true,
    `Weather data refreshed for ${result.successCount}/${result.totalCount} locations`,
    result
  ));
});

/**
 * Add widgets to user storage for dashboard customization
 * Creates new widget storage with user-specific configuration
 * Supports array of widget configurations for bulk operations
 */
export const addWidgets = catchAsync(async (req, res) => {
  const widgets = req.body;
  const userId = req.user._id;

  if (!Array.isArray(widgets)) {
    return res.status(400).json(new ApiResponse(
      false,
      'Request body must be an array of widgets'
    ));
  }

  const result = await widgetService.addWidgets(userId, widgets);
  
  const statusCode = result.status === 'created' ? 201 : 200;
  const message = result.status === 'created' 
    ? 'Widgets created successfully' 
    : 'Widgets updated successfully';

  res.status(statusCode).json(new ApiResponse(
    true,
    message,
    result.data
  ));
});

/**
 * Update widget storage configuration
 * Modifies existing widget layout and emits real-time socket update
 * Triggers templateUpdate event for dashboard synchronization
 */
export const updateWidgets = catchAsync(async (req, res) => {
  const { id } = req.params;
  const widgets = req.body;

  const result = await widgetService.updateWidgets(id, widgets);
  
  if (!result.data) {
    return res.status(404).json(new ApiResponse(
      false,
      'Widget not found'
    ));
  }

  // Emit socket event after successful widget update
  socketManager.emitEvent('templateUpdate', {
    action: 'updated',
    type: 'Widget',
    widgetId: id,
    widget: result.data,
    timestamp: new Date().toISOString(),
    userId: req.user?._id?.toString()
  });

  res.status(200).json(new ApiResponse(
    true,
    'Widgets updated successfully',
    result.data
  ));
});

/**
 * Get widget by ID
 */
export const getWidgetById = catchAsync(async (req, res) => {
  const { id } = req.params;
  
  const widget = await widgetService.getWidgetById(id);
  
  if (!widget) {
    return res.status(404).json(new ApiResponse(
      false,
      'Widget not found'
    ));
  }
  
  res.status(200).json(new ApiResponse(
    true,
    'Widget fetched successfully',
    widget
  ));
});

/**
 * Delete widget
 */
export const deleteWidget = catchAsync(async (req, res) => {
  const { id } = req.params;
  
  const deleted = await widgetService.deleteWidget(id);
  
  if (!deleted) {
    return res.status(404).json(new ApiResponse(
      false,
      'Widget not found'
    ));
  }

  // Emit socket event after successful widget deletion
  socketManager.emitEvent('templateUpdate', {
    action: 'deleted',
    type: 'Widget',
    widgetId: id,
    timestamp: new Date().toISOString(),
    userId: req.user?._id?.toString()
  });
  
  res.status(200).json(new ApiResponse(
    true,
    'Widget deleted successfully'
  ));
});

/**
 * Get all active widgets
 */
export const getAllWidgets = catchAsync(async (req, res) => {
  const widgets = await widgetService.getAllWidgets();
  
  res.status(200).json(new ApiResponse(
    true,
    'Widgets fetched successfully',
    widgets
  ));
});