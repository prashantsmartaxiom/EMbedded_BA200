/**
 * Event Controller - IoT device communication and real-time event processing
 * 
 * Manages real-time device interactions, MQTT communication, and hardware integration.
 * Handles device discovery, command execution, and sensor automation within the smart building platform.
 * Flow: event.routes.js → event.controller.js → event.service.js → Device/Message models
 * 
 * Key Operations:
 * - Device discovery and automatic registration from MQTT
 * - Real-time channel command execution (LED, shade, sensor control)
 * - Group and scene command orchestration across multiple devices
 * - Third-party device integration and protocol translation
 * - MQTT message logging and device status monitoring
 * - Sensor automation trigger processing
 */

import { catchAsync } from '../utils/catchAsync.js';
import { ApiResponse } from '../utils/ApiResponse.js';
import * as EventService from '../services/event.service.js';

// Execute device/channel commands with comprehensive logging
// Handles LED, shade, group, and scene operations with real-time socket updates
export const sendChannelEvent = catchAsync(async (req, res) => {
    const { username, device_id, deviceData, channelType, channelAddress,invertFlag, command, uiType, groupId } = req.body;
    const userDetails = { id: req.user?._id?.toString() || '-', name: username || '-' };
    const eventMessage = await EventService.sendChannelEvent({ username, device_id, deviceData, channelType, channelAddress, invertFlag, command, uiType, groupId }, userDetails);
    return res.status(201).json(new ApiResponse(true, 'Event sent successfully', eventMessage));
});

// Handle automatic device discovery from MQTT broadcasts
// Creates new device entries with default capabilities based on device type
export const deviceDiscoveryEvent = catchAsync(async (req, res) => {
    const { device_id, SNO, Firmware, MacAddr } = req.body;
    const deviceData = await EventService.discoverDevice({ device_id, SNO, Firmware, MacAddr });
    return res.status(201).json(new ApiResponse(true, 'Event sent successfully', deviceData));
});

export const sendHmiCommands = catchAsync(async (req, res) => {
    const { device_id, command } = req.body;
    const deviceData = await EventService.sendHmiCommands({ device_id, command });
    return res.status(201).json(new ApiResponse(true, 'Event sent successfully', deviceData));
});

export const thirdPartyEvent = catchAsync(async (req, res) => {
    const { channel, command } = req.body;
    const deviceData = await EventService.thirdPartyEvent({ command, channel });
    return res.status(201).json(new ApiResponse(true, 'Event sent successfully', deviceData));
});

export const updateSensorData = catchAsync(async (req, res) => {
    const { statusData, deviceId } = req.body;
    const deviceData = await EventService.updateSensorData({ statusData, deviceId });
    return res.status(201).json(new ApiResponse(true,'Sensor event called' ,deviceData));
});

export const getStoredDevices = catchAsync (async (req,res) => {
    const devices = await EventService.getStoredDevices();
    return res.status(201).json(new ApiResponse(true, 'Event sent successfully', devices));
});

export const rebootDevice = catchAsync (async (req,res) => {
    const { device_id } = req.body;
    const userDetails = {id: req.user?._id?.toString() || '-', name: req.user?.fullName || '-'};
    const device = await EventService.rebootDevice({device_id}, userDetails);
    return res.status(201).json(new ApiResponse(true, 'Device rebooted successfully', device));
});

export const updateDeviceStatus = catchAsync (async (req,res) => {
    const { deviceData, status } = req.body;
    const updateDevice = await EventService.updateDeviceStatus({deviceData,status});
    return res.status(201).json(new ApiResponse(true, 'Event sent successfully', updateDevice));
});

export const sendChannelConfig = catchAsync (async (req,res) => {
    const { device_id } = req.body;
    const updateDevice = await EventService.sendChannelConfigurations(device_id.toString());
    return res.status(201).json(new ApiResponse(true, 'Event sent successfully', updateDevice));
});

export const getSensorData = catchAsync (async (req,res) => {
    const { sensorData, deviceId } = req.body;
    const updateDevice = await EventService.getSensorData({sensorData,deviceId});
    return res.status(201).json(new ApiResponse(true, 'Event sent successfully', updateDevice));
});

export const hmiUpdate = catchAsync (async (req,res) => {
    const { statusData, deviceId } = req.body;
    const updateDevice = await EventService.hmiUpdate({statusData,deviceId});
    return res.status(201).json(new ApiResponse(true, 'Event sent successfully', updateDevice));
});

export const storeDeviceMessage = catchAsync (async (req,res) => {
    const { id, control_topic, message } = req.body;
    const storeMessage = await EventService.storeDeviceMessage({id, control_topic, message});
    return res.status(201).json(new ApiResponse(true, 'Event sent successfully', storeMessage));
});
