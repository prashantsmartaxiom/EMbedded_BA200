/**
 * Main Express application setup
 * Architecture: app.js → routes → controllers → services → database
 * 
 * Flow:
 * 1. Security middleware (helmet, cors, sanitization)
 * 2. Request parsing with size limits based on route
 * 3. Encryption/decryption middleware
 * 4. Route mounting with authentication
 * 5. Error handling
 */
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import mongoSanitize from 'express-mongo-sanitize';
import xss from 'xss-clean';
import hpp from 'hpp';
import morgan from 'morgan';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

// Custom middleware: encryption, rate limiting, error handling
import { 
  decryptPayload, 
  encryptResponse, 
  authLimiter, 
  notFound, 
  errorHandler 
} from './middleware/index.js';

// Route modules - each handles specific resource endpoints
import authRoutes from './routes/auth.routes.js';
import campusRoutes from './routes/campus.routes.js';
import buildingRoutes from './routes/building.routes.js';
import floorRoutes from './routes/floor.routes.js';
import zoneRoutes from './routes/zone.routes.js';
import deviceRoutes from './routes/device.routes.js';
import groupRoutes from './routes/group.routes.js';
import sceneRoutes from './routes/scene.routes.js';
import templateRoutes from './routes/template.routes.js';
import sensorRoutes from './routes/sensor.routes.js';
import userRoutes from './routes/user.routes.js';
import roleRoutes from './routes/role.routes.js';  
import eventRoutes from './routes/event.routes.js';
import logsRoutes from './routes/logs.routes.js';
import dashboardRoutes from './routes/dashboard.routes.js';
import widgetRoutes from './routes/widget.routes.js';

const app = express();

// Trust proxy for load balancers/reverse proxies
app.set('trust proxy', 1);

// Security middleware stack
app.use(helmet()); // Security headers
app.use(cors({ origin: true, credentials: true })); // CORS with credentials
app.use(mongoSanitize()); // Prevent NoSQL injection
app.use(xss()); // XSS protection
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev')); // Request logging

// Static file serving for uploaded images
const IMAGES_DIR = path.resolve(process.env.IMAGES_DIR || 'public/images');
app.use('/images', express.static(IMAGES_DIR));
console.log(`📂 Serving images from: ${IMAGES_DIR}`);

// Route-specific body parsing with size limits
// Campus routes: Large limits for image uploads
app.use('/campus',
  express.json({ limit: '20mb' }),
  express.urlencoded({ limit: '20mb', extended: true }),
  decryptPayload,
  encryptResponse,
  campusRoutes
);

// User routes: Large limits for profile images
app.use('/users',
  express.json({ limit: '20mb' }),
  express.urlencoded({ limit: '20mb', extended: true }),
  decryptPayload,
  encryptResponse,
  userRoutes
);

// Default parsing limits for other routes
app.use(express.json({ limit: '50kb' }));
app.use(express.urlencoded({ limit: '50kb', extended: true }));

// Global encryption middleware for remaining routes
app.use(decryptPayload);
app.use(encryptResponse);

// Auth routes with rate limiting
app.use('/auth', authLimiter, authRoutes);

// Resource routes - each protected by authentication middleware in routes
app.use('/devices', deviceRoutes);
app.use('/groups', groupRoutes);
app.use('/scenes', sceneRoutes);
app.use('/template', templateRoutes);
app.use('/sensors', sensorRoutes);
app.use('/roles', roleRoutes);
app.use('/buildings', buildingRoutes);
app.use('/floors', floorRoutes);
app.use('/zones', zoneRoutes);
app.use('/events', eventRoutes);
app.use('/logs', logsRoutes);
app.use('/dashboard', dashboardRoutes);
app.use('/widgets', widgetRoutes);

// Global error handling
app.use(notFound); // 404 handler
app.use(errorHandler); // Global error handler

export default app;