// Core configuration and database imports
import { initializeConfig } from './config/env.js';
import { connectDB } from './config/db.js';

// Service imports for scheduled tasks and device management
import { scheduleService } from './services/scheduleService.js';
import { connectAllLutronClients } from './services/device.lutron.js';
import { startHourlyTask } from './services/cron.service.js';

// Express application instance
import app from './app.js';

// Socket.IO server setup for real-time communication
import http from "http";
import { initSocket } from "./utils/socket.js";


// Create HTTP server instance with Express app
const server = http.createServer(app);

// Initialize Socket.IO for real-time communication with clients
const io = initSocket(server);

/**
 * Main server startup function
 * Handles configuration, database connection, and service initialization
 */
const start = async () => {
  try {
    // Step 1: Initialize configuration (handles both local .env and VCAP_SERVICES)
    const config = initializeConfig();
    console.log(`Environment: ${config.nodeEnv}`);
    
    // Step 2: Establish database connection
    await connectDB();
    
    // Step 3: Start scheduled background tasks
    startHourlyTask(); // Weather data refresh and WebSocket updates
    
    // Step 4: Initialize Lutron device connections
    await connectAllLutronClients();
    
    // Step 5: Start cleanup scheduled jobs
    scheduleService.startResetCleanup();
    
    // Step 6: Add health check endpoint
    app.get("/", (req, res) => {
      res.send("Socket + Express server running!");
    });
    
    // Step 7: Start the server
    server.listen(config.port, () => {
      console.log(`Server running on - ${config.reset.appUrl} `);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1); // Exit with error code if startup fails
  }
};

// Start the server application
start();
