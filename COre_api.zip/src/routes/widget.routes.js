/**
 * Widget Routes - Dashboard components and data visualization endpoints
 * 
 * Flow: app.js → widget.routes.js → widget.controller.js → widget.service.js → MongoDB
 * 
 * Manages comprehensive widget ecosystem:
 * - Timezone management with predefined global timezone data
 * - Weather integration with real-time API data and location-based services
 * - Widget storage system for dashboard customization and layout persistence
 * - AQI (Air Quality Index) monitoring with hourly data tracking
 * - Temperature monitoring for multiple cities with bulk operations
 * - Real-time data refresh with socket notifications for live updates
 */

import express from 'express';
import * as widgetController from '../controllers/widget.controller.js';
import { protect } from '../middleware/index.js';
import {
  createTimezoneSchema,
  getTimezoneByIdSchema,
  toggleTimezoneStatusSchema,
  getWeatherInfoSchema,
  getWeatherByCoordinatesSchema,
  getCurrentTemperaturesSchema,
  updateWeatherSchema,
  weatherIdSchema,
  validateRequest,
  validateParams,
  validateQuery
} from '../validators/widget.validator.js';

const router = express.Router();

// Public weather endpoint (no auth required)
router.get('/weather/aqi-temp-current',
  validateQuery(getWeatherByCoordinatesSchema),
  widgetController.getAqiAndTemperatureCurrentHour
);

/**
 * @route   POST /widgets/weather/refresh-all
 * @desc    Update weather data for all locations
 * @access  Public
 */
router.post('/weather/refresh-all', widgetController.refreshAllWeatherData);

// Protect all routes below this middleware
router.use(protect);

/**
 * @route   GET /widgets/timezones
 * @desc    Get all active timezones (simple list)
 * @access  Private
 */
router.get('/timezones', widgetController.getTimezones);

/**
 * @route   GET /widgets/timezones/all
 * @desc    Get all timezones including inactive ones
 * @access  Private
 */
router.get('/timezones/all', widgetController.getAllTimezonesIncludingInactive);

/**
 * @route   POST /widgets/timezones/initialize
 * @desc    Initialize timezones with predefined data
 * @access  Private
 */
router.post('/timezones/initialize', widgetController.initializeTimezones);

/**
 * @route   POST /widgets/timezones
 * @desc    Create a new timezone
 * @access  Private
 */
router.post('/timezones', 
  validateRequest(createTimezoneSchema), 
  widgetController.createTimezone
);

/**
 * @route   GET /widgets/timezones/:id
 * @desc    Get timezone by ID
 * @access  Private
 */
router.get('/timezones/:id', 
  validateParams(getTimezoneByIdSchema), 
  widgetController.getTimezone
);

/**
 * @route   PATCH /widgets/timezones/:id/status
 * @desc    Toggle timezone status (activate/deactivate)
 * @access  Private
 */
router.patch('/timezones/:id/status',
  validateParams(getTimezoneByIdSchema),
  validateRequest(toggleTimezoneStatusSchema),
  widgetController.toggleTimezoneStatus
);

/**
 * @route   PUT /widgets/timezones/:id
 * @desc    Update timezone information
 * @access  Private
 */
router.put('/timezones/:id',
  validateParams(getTimezoneByIdSchema),
  validateRequest(createTimezoneSchema),
  widgetController.updateTimezone
);

/**
 * @route   POST /api/widgets/weather
 * @desc    Get weather information by location
 * @access  Private
 */
router.post('/weather', 
  validateRequest(getWeatherInfoSchema), 
  widgetController.getWeatherInfo
);

/**
 * @route   GET /api/widgets/weather/user
 * @desc    Get weather data by user ID
 * @access  Private
 */
router.get('/weather/user', widgetController.getWeatherByUser);

/**
 * @route   GET /api/widgets/weather/coordinates
 * @desc    Get weather data by coordinates
 * @access  Private
 */
router.get('/weather/coordinates', widgetController.getWeatherByCoordinates);



/**
 * @route   GET /widgets/weather/all
 * @desc    Get all weather data (active and not deleted) - Returns all times in UTC
 * @access  Private
 */
router.get('/weather/all', widgetController.getAllWeatherData);

/**
 * @route   GET /widgets/weather/first
 * @desc    Get first weather data (active and not deleted)
 * @access  Private
 */
router.get('/weather/first', widgetController.getFirstWeatherData);

/**
 * @route   POST /api/widgets/weather/temperatures
 * @desc    Get current temperature for multiple cities
 * @access  Private
 */
router.post('/weather/temperatures', 
  validateRequest(getCurrentTemperaturesSchema), 
  widgetController.getCurrentTemperatures
);

/**
 * @route   PUT /widgets/weather/:id
 * @desc    Update weather information
 * @access  Private
 */
router.put('/weather/:id',
  validateParams(weatherIdSchema),
  validateRequest(updateWeatherSchema),
  widgetController.updateWeather
);

/**
 * @route   DELETE /widgets/weather/:id
 * @desc    Delete weather location
 * @access  Private
 */
router.delete('/weather/:id', widgetController.deleteWeather);



/**
 * @route   POST /widgets/add
 * @desc    Add widgets to storage
 * @access  Private
 */
router.post('/add', widgetController.addWidgets);

/**
 * @route   PUT /widgets/update-widget/:id
 * @desc    Update widget storage
 * @access  Private
 */
router.put('/update-widget/:id', widgetController.updateWidgets);

/**
 * @route   GET /widgets/view/:id
 * @desc    Get widget by ID
 * @access  Private
 */
router.get('/view/:id', widgetController.getWidgetById);

/**
 * @route   DELETE /widgets/:id
 * @desc    Delete widget
 * @access  Private
 */
router.delete('/delete/:id', widgetController.deleteWidget);

/**
 * @route   GET /widgets/list
 * @desc    Get all active widgets
 * @access  Private
 */
router.get('/list', widgetController.getAllWidgets);

export default router;