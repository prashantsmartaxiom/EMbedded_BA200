/**
 * Floor Routes - Building floor management endpoints
 * 
 * Handles floor lifecycle within the building hierarchy of the smart building platform.
 * Flow: app.js → floor.routes.js → floor.controller.js → floor.service.js → CampusFloor model
 * 
 * Features:
 * - Floor CRUD operations with building association
 * - Zone cascade operations during floor deletion
 * - Status management and soft delete functionality
 * - Device state management (move to Discovered during deletion)
 * - Name-based resolution for external integrations
 * - User access control via allowedResources
 */

import express from 'express';
import {
  getFloorsByBuilding,
  addFloor,
  getFloorById,
  addFloorWithNames,
  getAllFloors,
  updateFloorWithNames,
  changeFloorStatus,
  deleteFloor
} from '../controllers/floor.controller.js';
import { validate, protect } from '../middleware/index.js';
import { 
  addFloorSchema, 
  addFloorWithNamesSchema,
  updateFloorWithNamesSchema,
  changeFloorStatusSchema
} from '../validators/floor.validator.js';

const router = express.Router();

// All floor routes require authentication
router.use(protect);

// Get paginated floors list across all buildings with optional deleted floors
router.get('/floor-list', getAllFloors);

// Building-scoped floor operations
router.get('/building/:buildingId', getFloorsByBuilding); // Get all floors in building
router.post('/building/:buildingId', validate(addFloorSchema), addFloor); // Create floor in building

// Create floor using campus/building names (flexible API for external integrations)
router.post('/add-campus', validate(addFloorWithNamesSchema), addFloorWithNames);

// Update floor with name-based resolution and building transfer support
router.put('/:floorId/update-floor', validate(updateFloorWithNamesSchema), updateFloorWithNames);

// Toggle floor active/inactive status
router.patch('/:floorId/change-status', validate(changeFloorStatusSchema), changeFloorStatus);

// Delete floor with cascade cleanup (zones, devices move to Discovered)
router.delete('/:floorId/delete-floor', deleteFloor);

// Get specific floor details with zone/device counts
router.get('/:floorId', getFloorById);

export default router;
