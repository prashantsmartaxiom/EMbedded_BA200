/**
 * Zone Routes - Floor zone management endpoints
 * 
 * Handles zone lifecycle within the floor hierarchy of the smart building platform.
 * Flow: app.js → zone.routes.js → zone.controller.js → zone.service.js → CampusZone model
 * 
 * Features:
 * - Zone CRUD operations with floor association
 * - Device cascade operations during zone deletion  
 * - Comprehensive zone listing with hierarchy context
 * - Status management and device count statistics
 * - Device state management (move to Discovered during deletion)
 * - Flexible APIs for dropdowns and detailed views
 */

import express from 'express';
import {
  getZonesByFloor,
  getZoneDetails,
  addZoneWithIds,
  getZoneList,
  getAllZones,
  updateZone,
  updateZoneStatus,
  deleteZone
} from '../controllers/zone.controller.js';
import { validate, protect, validateParams, validateQuery } from '../middleware/index.js';
import { 
  addZoneWithIdsSchema, 
  getZoneListSchema, 
  getAllZonesQuerySchema,
  updateZoneSchema,
  updateZoneStatusSchema,
  deleteZoneSchema,
  floorIdParamsSchema,
  zoneIdParamsSchema,
  getZonesByFloorQuerySchema
} from '../validators/zone.validator.js';

const router = express.Router();

// All zone routes require authentication
router.use(protect);

// Get paginated zones list with full hierarchy context and device statistics
router.get('/zone-list', validateQuery(getZoneListSchema), getZoneList);

// Get all zones without pagination (for dropdowns, selection components)
router.get('/all-zones', validateQuery(getAllZonesQuerySchema), getAllZones);

// Create zone with direct floor ID specification
router.post('/create-zone', validate(addZoneWithIdsSchema), addZoneWithIds);

// Get zones within specific floor with pagination and search
router.get('/zones-by-floor/:floorId', 
  validateParams(floorIdParamsSchema),
  validateQuery(getZonesByFloorQuerySchema),
  getZonesByFloor
);

// Get comprehensive zone details with full hierarchy and device counts
router.get('/:zoneId/view-zone-details', validateParams(zoneIdParamsSchema), getZoneDetails);

// Update zone information (name, description, type)
router.put('/:zoneId/update-zone', 
  validateParams(zoneIdParamsSchema),
  validate(updateZoneSchema), 
  updateZone
);

// Toggle zone active/inactive status
router.patch('/update-status', validate(updateZoneStatusSchema), updateZoneStatus);

// Delete zone with cascade cleanup (devices move to Discovered)
router.delete('/delete-zone', validate(deleteZoneSchema), deleteZone);

export default router;
