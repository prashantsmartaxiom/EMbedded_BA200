/**
 * Campus Routes - Smart Building Management System
 * 
 * Flow: routes → controller → service → database
 * 
 * Public routes: /types, /view (no auth)
 * Protected routes: All CRUD operations require authentication
 * 
 * Route structure:
 * - GET /types - Campus types dropdown
 * - GET /view - Public campus view
 * - GET / - All campuses (paginated, filtered)
 * - GET /active_campuses - Active campuses only
 * - POST / - Create campus
 * - PUT /:id - Update campus
 * - PATCH /:id/status - Update status only
 * - DELETE /:id/delete - Soft delete campus
 * - GET /:id - Single campus by ID
 * - GET /:id/hierarchy - Campus with buildings/floors/zones
 */
import express from 'express';
import {
  getAllCampuses,
  getActiveCampuses,
  addCampus,
  updateCampus,
  deleteCampus,
  getCampusById,
  getCampusWithHierarchy,
  updateCampusStatus,
  getCampusTypes,
  getCampusView
} from '../controllers/campus.controller.js';
import { validate, protect, validateParams } from '../middleware/index.js';
import {
  getAllCampusesSchema,
  addCampusSchema,
  updateCampusSchema,
  deleteCampusSchema,
  updateCampusStatusSchema,
  getCampusViewSchema
} from '../validators/campus.validator.js';

const router = express.Router();

// ========== PUBLIC ROUTES (No Authentication Required) ==========

// Dropdown data for campus types
router.get('/types', getCampusTypes);

// Public campus view with building/floor/zone info
router.get('/view', validate(getCampusViewSchema, 'query'), getCampusView);

// ========== PROTECTED ROUTES (Authentication Required) ==========
// All routes below require valid JWT token
router.use(protect);

// Campus listing with user permissions filtering
router.get('/active_campuses', validate(getAllCampusesSchema, 'query'), getActiveCampuses);
router.get('/', validate(getAllCampusesSchema, 'query'), getAllCampuses);

// Campus CRUD operations
router.post('/', validate(addCampusSchema), addCampus);
router.put('/:campusId', validate(updateCampusSchema), updateCampus);
router.patch('/:campusId/status', validate(updateCampusStatusSchema), updateCampusStatus);
router.delete('/:campusId/delete', validateParams(deleteCampusSchema), deleteCampus);

// Campus detail views
router.get('/:campusId', getCampusById);
router.get('/:campusId/hierarchy', getCampusWithHierarchy);

export default router;
