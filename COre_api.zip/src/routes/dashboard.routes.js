/**
 * Dashboard Routes - Real-time analytics and monitoring endpoints
 * 
 * Flow: app.js → dashboard.routes.js → dashboard.controller.js → dashboard.service.js → MongoDB
 * 
 * Provides comprehensive dashboard functionality:
 * - Campus hierarchy analytics with device counts and statistics
 * - Zone-level device statistics (LEDs, shades, sensors) with status tracking
 * - Device information with scene associations and channel analytics
 * - Device group memberships and alert monitoring
 * - Real-time system health and performance metrics
 */

import express from 'express';
import { getDashboard, getZoneStats, getDeviceInfo, getAlerts, getDeviceGroups } from '../controllers/dashboard.controller.js';
import { validate, protect } from '../middleware/index.js';
import { dashboardPayloadSchema, zoneStatsPayloadSchema, deviceInfoSchema } from '../validators/dashboard.validator.js';

const router = express.Router();

router.use(protect);

// POST to get campus data for dashboard
router.post('/summary', validate(dashboardPayloadSchema), getDashboard);

// to get channel stats for a specific zones
router.post('/zone-stats', validate(zoneStatsPayloadSchema), getZoneStats);

// Get comprehensive device information by device ID
router.post('/device-info', validate(deviceInfoSchema), getDeviceInfo);

// Get all active groups for a given device
router.get('/device-groups/:deviceId', getDeviceGroups);

// Get alerts with pagination and filtering by deviceId
router.get('/alerts/:deviceId', getAlerts);

export default router;


