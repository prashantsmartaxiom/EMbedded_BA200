
/**
 * User Management Routes - User CRUD & Permission System
 * 
 * Flow: routes → controller → service → database
 * 
 * Features:
 * - Complete user lifecycle (CRUD operations)
 * - Role-based access control (RBAC)
 * - Permission management & resource allocation
 * - Campus/location assignment
 * - Profile image handling
 * - Module accessibility based on roles
 * 
 * All routes require authentication (JWT token)
 * 
 * Route structure:
 * - POST /add-user - Create new user
 * - GET /users-list - Paginated user listing with filters
 * - GET /:userId - Single user details
 * - PUT /update-user/:userId - Update user profile/permissions
 * - DELETE /:userId - Hard delete user
 * - PATCH /:userId/status - Toggle active/inactive status
 * - POST /tab-names - Get accessible tabs by role
 * - POST /accessible-modules - Get modules by role permissions
 * - POST /module-data - Get module resources with permissions
 * - POST /:userId/update_location - Update user campus assignment
 * - POST /module-data-by-role - Get role-specific module data
 */
import express from 'express';
import {
  addUser,
  getUserList,
  getUserById,
  updateUser,
  deleteUser,
  changeUserStatus,
  getModuleData,
  getUserAccessibleModules,
  getTabNames,
  insertUserCampusData,
  getModuleDataByRole // <-- NEW controller
} from '../controllers/userManagement.controller.js';
// Validation middleware and schemas
import { validate, validateParams, validateQuery, protect } from '../middleware/index.js';
import {
  addUserSchema,
  updateUserSchema,
  userListQuerySchema,
  userIdSchema,
  changeUserStatusSchema,
  moduleDataSchema,
  accessibleModulesSchema,
  tabNamesSchema,
  campusDataSchema,
  moduleDataByRoleSchema // <-- NEW validator
} from '../validators/userManagement.validator.js';

const router = express.Router();

// ========== ALL ROUTES REQUIRE AUTHENTICATION ==========
// JWT token validation for all user management endpoints
router.use(protect);

// ========== USER CRUD OPERATIONS ==========

// Create new user with role and permissions
router.post('/add-user', validate(addUserSchema), addUser);

// Get paginated user list with search/filter capabilities
router.get('/users-list', validateQuery(userListQuerySchema), getUserList);

// Get single user details with role information
router.get('/:userId', validateParams(userIdSchema), getUserById);

// Update user profile, role, or permissions
router.put('/update-user/:userId', validateParams(userIdSchema), validate(updateUserSchema), updateUser);

// Permanently delete user (hard delete)
router.delete('/:userId', validateParams(userIdSchema), deleteUser);

// Toggle user active/inactive status
router.patch('/:userId/status', validateParams(userIdSchema), validate(changeUserStatusSchema), changeUserStatus);

// ========== ROLE & PERMISSION MANAGEMENT ==========

// Get navigation tabs visible to specific role
router.post('/tab-names', validate(tabNamesSchema), getTabNames);

// Get modules accessible by role (permission-based filtering)
router.post('/accessible-modules', validate(accessibleModulesSchema), getUserAccessibleModules);

// Get resources within modules (campuses, devices, etc.) with permissions
router.post('/module-data', validate(moduleDataSchema), getModuleData);

// Assign campus/location access to user
router.post('/:userId/update_location', validateParams(userIdSchema), validate(campusDataSchema), insertUserCampusData);

// Get role-specific module data with user-specific selections
router.post('/module-data-by-role', validate(moduleDataByRoleSchema), getModuleDataByRole);

export default router;
