
/**
 * Role Routes - User permission system endpoints
 * 
 * Handles role-based access control for the smart building platform.
 * Flow: app.js → role.routes.js → role.controller.js → role.service.js → Role model
 * 
 * Features:
 * - Role CRUD with permission matrix management
 * - Role activation/deactivation system
 * - Permission inheritance and validation
 * - Role sections configuration for UI
 */

import express from 'express';
import * as roleController from '../controllers/role.controller.js';
import { validate, validateParams,protect } from '../middleware/index.js';
import { addRoleSchema } from '../validators/role.validator.js';
import { getRolesList } from '../controllers/role.controller.js';
import { validateQuery } from '../middleware/index.js';
import { getRolesListSchema,updateRoleSchema, getRoleByIdSchema } from '../validators/role.validator.js';

const router = express.Router();

// All role routes require authentication
router.use(protect); 

// Create new role with permission matrix
router.post('/add-role', validate(addRoleSchema), roleController.addRole);

// Get paginated roles list with search/filter
router.get('/list', 
  validateQuery(getRolesListSchema), 
  getRolesList
);

// Get role permission sections for UI configuration (must come before /:roleId)
router.get('/sections', roleController.getRoleSections);

// Get specific role details by ID
router.get('/:roleId', validateParams(getRoleByIdSchema), roleController.getRoleById);

// Update role name and permissions
router.put(
  '/:roleId',
  validateParams(getRoleByIdSchema),
  validate(updateRoleSchema),
  roleController.updateRole
);

// Soft delete role (sets isDelete flag)
router.delete('/:roleId', roleController.deleteRole);

// Activate/deactivate role status
router.patch('/:roleId/activate', roleController.activateRole);

export default router;
