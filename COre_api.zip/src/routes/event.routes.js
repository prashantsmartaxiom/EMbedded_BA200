/**
 * Event Routes - IoT device communication and event handling endpoints
 * 
 * Handles real-time device events, MQTT communication, and hardware integration.
 * Flow: app.js → event.routes.js → event.controller.js → event.service.js → Device/Message models
 * 
 * Features:
 * - Device discovery and lifecycle management
 * - Real-time channel/device command execution
 * - MQTT message handling and logging
 * - Sensor data processing and automation triggers
 * - Third-party device integration (Lutron, etc.)
 * - Device status monitoring and reboot functionality
 * - Group and scene command orchestration
 */

import express from 'express';
import { sendChannelEvent, deviceDiscoveryEvent, getStoredDevices, updateDeviceStatus, storeDeviceMessage, rebootDevice, updateSensorData, thirdPartyEvent, getSensorData, sendChannelConfig, hmiUpdate } from '../controllers/event.controller.js';
import { protect } from '../middleware/index.js';

const router = express.Router();

// Most event routes are unauthenticated for IoT device communication
// Authentication applied selectively for user-initiated actions

// Process sensor data updates and trigger automation events
router.post('', updateSensorData);

// Handle automatic device discovery from MQTT broadcasts
router.post('/storeDevice', deviceDiscoveryEvent);

// Get list of discovered devices (for device management UI)
router.get('/getDevices', getStoredDevices);

// Update device online/offline status from MQTT keepalive
router.post('/updateDeviceStatus', updateDeviceStatus);

// Send channel configurations on device reboot
router.post('/sendChannelConfig', sendChannelConfig);

// Get sensor data
router.post('/sensorData', getSensorData);

// Get sensor data
router.post('/hmiUpdate', hmiUpdate);

// Store MQTT messages for debugging and audit logging
router.post('/devicesMessage', storeDeviceMessage);

// Reboot device and reset channel states
router.post('/reboot', rebootDevice);

// Execute device/channel commands (LED, shade, group operations)
router.post('/trigger', sendChannelEvent);

// Execute third-party device commands (Lutron integration)
router.post('/thirdPartyTrigger', thirdPartyEvent);

export default router;
