/**
 * Group Routes - Device group management endpoints
 * 
 * Flow: Client → Routes → Controller → Service → DB
 * Handles logical grouping of devices with channel-level control
 * Supports location-based filtering and permission scoping
 */
import express from 'express';
import { createGroup, getGroupList, getActiveDevices, getDeviceChannels, updateGroup,deleteGroup, getAllGroups,getGroupDetailsController, getAllGroupsWithDeviceDetails, getSingleDeviceDetails, getGroupViewData } from '../controllers/group.controller.js';
import { createGroupSchema, getDeviceChannelsSchema, updateGroupBodySchema, groupIdParamSchema, deviceIdParamSchema, getAllGroupsWithDeviceDetailsQuerySchema } from '../validators/group.validator.js';
import { validate, validateParams, validateQuery, protect } from '../middleware/index.js';

const router = express.Router();

// Apply authentication to all group routes
router.use(protect);

// Create new device group with channel assignments
router.post('/add', validate(createGroupSchema), createGroup);
// Get paginated group list with filtering and search
router.get('/list', getGroupList);
// Get devices available for grouping (filtered by type and status)
router.get('/active-devices', getActiveDevices);
// Get channels for given deviceIds (always returns one entry per input id)
router.post('/device-channels', validate(getDeviceChannelsSchema), getDeviceChannels);
// Edit a group (rename, replace devices, and flip installed flags on device channels)
router.put(
  '/:groupId',
  validateParams(groupIdParamSchema),
  validate(updateGroupBodySchema),
  updateGroup
);
// Soft delete group and cascade cleanup
router.delete(
  '/:groupId',
  validateParams(groupIdParamSchema),
  deleteGroup
);
// Get all groups (simple list without pagination)
router.get('/all', getAllGroups);
// Get all groups with device details (where isDeleted is false)
router.get('/groups-list', validateQuery(getAllGroupsWithDeviceDetailsQuerySchema), getAllGroupsWithDeviceDetails);

// Get single device details with all installed channels (must come before /:groupId/details)
router.get('/device/:deviceId/details', validateParams(deviceIdParamSchema), getSingleDeviceDetails);

// Get comprehensive group view data including all devices and their installed channels
router.get('/:groupId/view', validateParams(groupIdParamSchema), getGroupViewData);

// Get detailed group information - supports single or multiple group IDs
// Accepts either /:groupId/details or /details?groupIds=...
router.get('/:groupId/details', getGroupDetailsController);
router.get('/details', getGroupDetailsController);
export default router;