/**
 * Template Routes - Dashboard template and widget management endpoints
 * 
 * Flow: Client → Routes → Controller → Service → DB
 * Handles creation and management of customizable dashboard templates
 * Supports device controls, scenes, groups, and weather widgets with real-time data
 */
import express from 'express';
import {
  getTemplateList,
  getLayoutList,
  createTemplate,
  updateTemplate,
  deleteTemplate,
  getTemplateById,
  getHierarchy,
  getTemplatesByControlSection,
  getAllCompleteTemplatesWithWidgetData
} from '../controllers/template.controller.js';
import { validate, protect } from '../middleware/index.js';
import {
  addTemplateSchema,
  updateTemplateSchema,
  deleteTemplateSchema,
  templatesListQuerySchema
} from '../validators/template.validator.js';

const router = express.Router();

// Public template access by ID (no authentication required for viewing)
router.get('/id/:templateId([0-9a-fA-F]{24})', getTemplateById);

// All other operations require authentication
router.use(protect);

// Get paginated template list with permission filtering
router.get('/list', getTemplateList);
// Get templates accessible to current user based on control section permissions
router.get('/templates-list', validate(templatesListQuerySchema, 'query'), getTemplatesByControlSection);
// Get complete templates with full widget data for dashboard rendering
router.get('/complete-templates-with-widgets', getAllCompleteTemplatesWithWidgetData);
// Get available layout configurations for template creation
router.get('/layout', getLayoutList);
// Create new dashboard template with widget assignments
router.post('/add', validate(addTemplateSchema), createTemplate);
// Update existing template configuration and layout
router.put('/update', validate(updateTemplateSchema), updateTemplate);
// Delete template and cleanup references
router.delete('/delete', validate(deleteTemplateSchema), deleteTemplate);
// Get device/group/scene hierarchy for template builder
router.get('/hierarchy', getHierarchy);

export default router;
