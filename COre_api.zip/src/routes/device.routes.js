/**
 * Device Management Routes - IoT Device Control System
 * 
 * Flow: routes → controller → service → database/MQTT
 * 
 * Device System Features:
 * - Device discovery and configuration
 * - Channel management (LED, shade, sensor controls)
 * - Own devices (BA-series) vs Third-party device separation
 * - Real-time device status management
 * - Location-based device organization
 * - MQTT integration for device communication
 * 
 * Device Lifecycle:
 * 1. Discovery (unconfigured devices)
 * 2. Configuration (assign location, ports)
 * 3. Channel installation/management
 * 4. Real-time control and monitoring
 * 5. Status management (active/inactive)
 * 
 * Route Structure:
 * - GET /discovery-list - Unconfigured devices
 * - GET /configured-list - Configured devices with channels
 * - GET /devices-list - All devices with channel info
 * - GET /tab-counter - UI counter data
 * - POST /configure - Configure discovered device
 * - Channel management: /:deviceId/channels
 * - Device CRUD operations
 * - Third-party device management
 * 
 * All routes require JWT authentication
 */
import express from 'express';
import {
  getDeviceList,
  getDeviceById,
  addDevice,
  updateDevice,
  deleteDevice,
  getOwnDevices,
  getThirdPartyDevices,
  getDeviceDiscoveryList,
  configureDevice,
  getConfiguredDevicesList,
  getTabCounter,
  changeDeviceStatus,
  getDeviceChannels,
  updateDeviceChannelName,
  getDeviceSensorsList,
  getDevicesListWithChannels,
  addThirdPartyDevice,
  updateThirdPartyDevice,
  deletethirdPartyDevice,
  deleteDeviceChannel,
  getDeviceSensorList
} from '../controllers/device.controller.js';
// Validation middleware and device-specific schemas
import { validate, validateParams, validateQuery, protect } from '../middleware/index.js';
import {
  addDeviceSchema,
  updateDeviceSchema,
  deviceListQuerySchema,
  deviceIdSchema,
  deviceChannelIdSchema,
  deviceDiscoveryQuerySchema,
  configureDeviceSchema,
  configuredDevicesQuerySchema,
  updateChannelNameSchema,
  devicesListQuerySchema
} from '../validators/device.validator.js';

const router = express.Router();

// ========== ALL ROUTES REQUIRE AUTHENTICATION ==========
// JWT token validation for all device management endpoints
router.use(protect);

// ========== DEVICE DISCOVERY & LISTING ==========

// Unconfigured devices available for setup (configure_flag = false)
router.get('/discovery-list', validateQuery(deviceDiscoveryQuerySchema), getDeviceDiscoveryList);

// Configured devices with location and channel details (configure_flag = true)
router.get('/configured-list', validateQuery(configuredDevicesQuerySchema), getConfiguredDevicesList);

// All devices with channel installation status and controls
router.get('/devices-list', validateQuery(devicesListQuerySchema), getDevicesListWithChannels);

// All sensors with device
router.get('/device-sensor-list', getDeviceSensorList);

// UI counter data for tabs (discovered vs configured counts)
router.get('/tab-counter', getTabCounter);

// ========== DEVICE DETAIL & CHANNEL MANAGEMENT ==========

// Single device details with location and capabilities (MUST be after specific routes)
router.get('/:deviceId', validateParams(deviceIdSchema), getDeviceById);

// Device channel list (LED, shade, sensor channels)
router.get('/:deviceId/channels', validateParams(deviceIdSchema), getDeviceChannels);

// Device sensor configurations and settings
router.get('/:deviceId/sensors-by-device', validateParams(deviceIdSchema), getDeviceSensorsList);

// Channel control operations (install/uninstall, rename, configure)
router.put('/:deviceId/channels/:channelId', validateParams(deviceChannelIdSchema), validate(updateChannelNameSchema), updateDeviceChannelName);

// ========== DEVICE CONFIGURATION & CRUD ==========

// Configure discovered device (assign location, ports, make it "configured")
router.post('/configure', validate(configureDeviceSchema), configureDevice);

// Manual device creation (for testing/admin purposes)
router.post('/add-device', validate(addDeviceSchema), addDevice);

// Third-party device management (non-BA series devices)
router.post('/add-third-party-device', addThirdPartyDevice);
router.put('/update-third-party-device/:deviceId', updateThirdPartyDevice);
router.delete('/delete-third-party-device/:deviceId', deletethirdPartyDevice);

// ========== DEVICE UPDATES & STATUS MANAGEMENT ==========

// Update device configuration (ports, location, description)
router.put('/update-device/:deviceId', validateParams(deviceIdSchema), validate(updateDeviceSchema), updateDevice);

// Soft delete device (sets is_delete flag, removes from groups/scenes)
router.delete('/:deviceId', validateParams(deviceIdSchema), deleteDevice);

// Delete sensor channel data
router.delete('/:deviceId/channels/:channelId', validateParams(deviceChannelIdSchema), deleteDeviceChannel)

// Toggle device online/offline status
router.patch('/:deviceId/status', validateParams(deviceIdSchema), changeDeviceStatus);

export default router;