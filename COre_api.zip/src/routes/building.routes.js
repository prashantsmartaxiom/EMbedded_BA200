/**
 * Building Routes - Campus building management endpoints
 * 
 * Handles building lifecycle within the smart building hierarchy.
 * Flow: app.js → building.routes.js → building.controller.js → building.service.js → CampusBuilding model
 * 
 * Features:
 * - Building CRUD operations with campus association
 * - User access control based on allowedResources
 * - Floor/zone cascade operations during deletion
 * - Status management (active/inactive)
 * - Device state management during building lifecycle
 */

import express from 'express';
import {
  getAllBuildings,
  getBuildingsByCampus,
  getActiveBuildingsByCampus,
  addBuilding,
  addBuildingWithPayload,
  addBuildingWithCampusName,
  getBuildingById,
  updateBuildingById,
  updateBuildingStatus,
  softDeleteBuilding
} from '../controllers/building.controller.js';
import { validate, protect, validateParams, validateQuery } from '../middleware/index.js';
import { 
  addBuildingSchema,
  addBuildingWithCampusNameSchema,
  updateBuildingSchema,
  updateBuildingStatusSchema,
  getBuildingsByCampusSchema,
  getActiveBuildingsByCampusSchema,
  campusIdParamSchema
} from '../validators/building.validator.js';

const router = express.Router();

// All building routes require authentication
router.use(protect);

// Get paginated buildings list across all campuses with user access filtering
router.get('/', getAllBuildings);

// Get active buildings for dropdown/selection (campus-specific)
router.get('/campus/:campusId/active', 
  validateParams(campusIdParamSchema),
  validateQuery(getActiveBuildingsByCampusSchema), 
  getActiveBuildingsByCampus
);

// Create building using campus name instead of ID (flexible endpoint)
router.post('/add', validate(addBuildingWithCampusNameSchema), addBuildingWithCampusName);

// Campus-scoped building operations
router.get('/campus/:campusId', getBuildingsByCampus); // Get all buildings in campus
router.post('/campus/:campusId', validate(addBuildingSchema), addBuilding); // Create building in campus

// Individual building management
router.get('/:buildingId', getBuildingById); // Get building details with floor/zone counts
router.put('/:buildingId', validate(updateBuildingSchema), updateBuildingById); // Update building info
router.patch('/:buildingId/status', validate(updateBuildingStatusSchema), updateBuildingStatus); // Toggle active/inactive
router.delete('/:buildingId', softDeleteBuilding); // Soft delete with cascade cleanup

export default router;
