/**
 * Scene Routes - Automated control scene management endpoints
 * 
 * Flow: Client → Routes → Controller → Service → DB
 * Handles creation and execution of device/group automation scenes
 * Supports both device-level and group-level scene configurations
 */
import express from 'express';
import { protect } from '../middleware/index.js';
import { addSceneSchema, listScenesQuerySchema, deviceIdParamSchema, updateSceneSchema, updateSceneParamsSchema, updateSceneStatusSchema, sceneParamsSchema, getAllScenesValidator, viewSceneParamsSchema, getAllScenesWithDetailsValidator, scenesListQuerySchema } from '../validators/scene.validator.js';
import { addScene, listScenes, getDeviceDetails, updateScene, updateSceneStatus, deleteScene, getAllScenes, viewScene, getAllScenesWithDetails, getAllowedScenesForUser } from '../controllers/scene.controller.js';
import { validate, validateQuery, validateParams } from '../middleware/index.js';

const router = express.Router();

// Apply authentication to scene routes that need protection
router.use(protect);

// Get scenes allowed for current user based on permissions
router.get('/scenes-list', validateQuery(scenesListQuerySchema), getAllowedScenesForUser);

// Get device details for scene creation - shows installed channels only
router.get('/:deviceId/details', 
  validateParams(deviceIdParamSchema), 
  getDeviceDetails
);

// Create new automation scene (device or group type)
router.post('/add-scene', validate(addSceneSchema), addScene);

// Get paginated scene list with filtering and search
router.get('/', validateQuery(listScenesQuerySchema), listScenes);


// Get all scenes without pagination - simple list for selections
router.get('/all', validateQuery(getAllScenesValidator), getAllScenes);

// Get all scenes with complete device/group details and installed channels only
router.get('/scene-list', validateQuery(getAllScenesWithDetailsValidator), getAllScenesWithDetails);

// View detailed scene information with complete device/group data
router.get('/view/:sceneId', validateParams(viewSceneParamsSchema), viewScene);

// Update scene configuration and device/group assignments
router.put(
  '/:id',
  validateParams(updateSceneParamsSchema),
  validate(updateSceneSchema),
  updateScene
);

// Update scene status (active/inactive) for execution control
router.patch(
  '/:id/status',
  validateParams(sceneParamsSchema),
  validate(updateSceneStatusSchema),
  updateSceneStatus
);

// Soft delete scene and cascade cleanup from templates/sensors
router.delete('/:sceneId', deleteScene);



export default router;
