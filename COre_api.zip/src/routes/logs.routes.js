/**
 * Logs Routes - System audit and monitoring endpoints
 * 
 * Flow: app.js → logs.routes.js → logs.controller.js → logs.service.js → MongoDB
 * 
 * Handles comprehensive system logging including:
 * - MQTT device communication logs with filtering/export
 * - Event audit trails with Excel export capabilities  
 * - Campus hierarchy for log filtering context
 * - Real-time system monitoring and troubleshooting
 */

import express from 'express';
import {
  getMqttLogs,
  getEventLogs,
  getCampusHierarchy,
  exportMqttLogsToExcel,
  exportEventLogsToExcel
//   getMqttLogStats
} from '../controllers/logs.controller.js';
import { validateQuery, protect } from '../middleware/index.js';
import {
  getMqttLogsQuerySchema,
  getEventLogsQuerySchema,
//   getMqttLogStatsQuerySchema
} from '../validators/logs.validator.js';

const router = express.Router();

// Apply authentication to all logs routes
router.use(protect);

// Get MQTT logs with filtering and pagination (supports download=1 for Excel export)
router.get('/get-mqtt-logs', validateQuery(getMqttLogsQuerySchema), getMqttLogs);

// Get event logs with specific fields (supports download=1 for Excel export)
router.get('/get-event-logs', validateQuery(getEventLogsQuerySchema), getEventLogs);

// Get campus hierarchy with nested buildings, floors, and zones
router.get('/campus-hierarchy', getCampusHierarchy);

export default router;
