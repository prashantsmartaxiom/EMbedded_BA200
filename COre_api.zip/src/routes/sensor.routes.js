
/**
 * Sensor Routes - IoT sensor configuration and automation endpoints
 * 
 * Flow: Client → Routes → Controller → Service → DB
 * Handles motion sensor setup with scene-based automation triggers
 * Manages sensor-to-device mapping and MQTT command integration
 */
import express from 'express';
import { protect } from '../middleware/index.js';
import { 
  addSensorSchema, 
  listSensorsQuerySchema, 
  sensorParamsSchema, 
  updateSensorSchema 
} from '../validators/sensor.validator.js';
import { 
  addSensor, 
  listSensors, 
  getSensor, 
  updateSensor, 
  deleteSensor 
} from '../controllers/sensor.controller.js';
import { validate, validateQuery, validateParams } from '../middleware/index.js';

const router = express.Router();

// Apply authentication to all sensor routes
router.use(protect);

// Create new sensor configuration with motion/no-motion scene triggers
router.post('/', validate(addSensorSchema), addSensor);

// Get paginated sensor list with device and zone filtering
router.get('/sensor-list', validateQuery(listSensorsQuerySchema), listSensors);

// Get specific sensor configuration and linked scenes
router.get('/:id', validateParams(sensorParamsSchema), getSensor);

// Update sensor configuration and trigger settings
router.put(
  '/update-sensor/:id',
  validateParams(sensorParamsSchema),
  validate(updateSensorSchema),
  updateSensor
);

// Soft delete sensor and cleanup MQTT configurations
router.delete('/delete/:id', validateParams(sensorParamsSchema), deleteSensor);

// Placeholder routes - implement as needed
// router.get('/', (req, res) => {
//   res.json({ message: 'Sensor routes - coming soon' });
// });

export default router;
