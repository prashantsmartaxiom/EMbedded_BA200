/**
 * Authentication Routes - User Auth & Session Management
 * 
 * Flow: routes → controller → service → database
 * 
 * Authentication System Features:
 * - User registration with OTP verification
 * - JWT-based login/logout with session tracking
 * - Password reset flow with email OTP
 * - Role-based authorization
 * - Profile management for authenticated users
 * - Admin-only user management endpoints
 * 
 * Security Features:
 * - Rate limiting on auth endpoints (applied in app.js)
 * - JWT token validation
 * - Role-based access control
 * - Audit trail for authentication events
 * 
 * Route Structure:
 * PUBLIC: /signup, /verify-otp, /login, /forgot-password, /verify-code, /reset-password
 * PROTECTED: /profile, /change-password, /logout
 * ADMIN-ONLY: /users (CRUD operations)
 */
import express from 'express';
import { 
  signup, 
  login,
  verifySignupOTP,
  forgotPassword,
  verifyResetOTP,
  newResetPassword,
  getProfile,
  getUserById,
  getAllUsers,
  getUserAuthHistory,
  updateProfile,
  protectedChangePassword,
  logout,
  getRoles,
  getRoleDetailByUserId
} from '../controllers/auth.controller.js';
// Authentication middleware and validation schemas
import { validate, validateParams, protect, authorize } from '../middleware/index.js';
import { 
  signupSchema, 
  loginSchema, 
  verifySignupOTPSchema,
  forgotPasswordSchema,
  verifyOTPSchema,
  newResetPasswordSchema,
  userIdParamSchema,
  updateProfileSchema,
  protectedChangePasswordSchema
} from '../validators/auth.validator.js';

const router = express.Router();

// ========== PUBLIC ROUTES (No Authentication Required) ==========

// User Registration Flow
router.post('/signup', validate(signupSchema), signup);
router.post('/verify-otp', validate(verifySignupOTPSchema), verifySignupOTP);
router.post('/login', validate(loginSchema), login);

// Password Reset Flow (Email + OTP based)
router.post('/forgot-password', validate(forgotPasswordSchema), forgotPassword);
router.post('/verify-code', validate(verifyOTPSchema), verifyResetOTP);
router.post('/reset-password', validate(newResetPasswordSchema), newResetPassword);

// ========== PROTECTED ROUTES (JWT Authentication Required) ==========
router.use(protect); // All routes below require valid JWT token

// User Profile Management
router.get('/profile', getProfile);
router.put('/profile', validate(updateProfileSchema), updateProfile);
router.post('/change-password', validate(protectedChangePasswordSchema), protectedChangePassword);
router.post('/logout', logout);

// ========== ADMIN-ONLY ROUTES (Role Authorization Required) ==========

// User Management (Admin Access Only)
router.get('/users', authorize('admin'), getAllUsers);
router.get('/users/:id', authorize('admin'), validateParams(userIdParamSchema), getUserById);
router.get('/users/:id/auth-history', authorize('admin'), validateParams(userIdParamSchema), getUserAuthHistory);

// ========== GENERAL AUTHENTICATED ROUTES ==========

// Role Information (Available to all authenticated users)
router.get('/users/:id/role-detail', validateParams(userIdParamSchema), getRoleDetailByUserId);
router.get('/roles', getRoles);

export default router;
