/**
 * Database configuration and connection module
 * Handles MongoDB connection using Mongoose ODM
 */

import mongoose from 'mongoose';
import { getConfig } from './env.js';

/**
 * Establishes connection to MongoDB database
 * Automatically creates indexes in development environment for better performance
 * 
 * @throws {Error} If database connection fails
 */
export const connectDB = async () => {
  const config = getConfig();
  await mongoose.connect(config.mongoUri, {
    // Enable automatic index creation only in development
    // In production, indexes should be created manually for better control
    autoIndex: config.nodeEnv === 'development'
  });
  console.log('MongoDB connected ➡️');
};
