/**
 * Google Cloud Secret Manager integration service
 * Provides secure access to secrets stored in Google Cloud Secret Manager
 * Supports caching and environment-specific behavior
 * 
 * Features:
 * - Automatic environment detection (local/development/production)
 * - Secret caching for performance
 * - JSON object secret parsing
 * - Cloud Run deployment support via VERSION_NAME
 */

import { SecretManagerServiceClient } from '@google-cloud/secret-manager';

/**
 * Secret Manager Service Class
 * Handles initialization, secret retrieval, and caching
 */
class SecretManagerService {
  constructor() {
    this.client = null; // Google Cloud Secret Manager client
    this.projectId = null; // Google Cloud project ID
    // Environment detection for conditional behavior
    this.isLocal = process.env.NODE_ENV === 'local' || (!process.env.NODE_ENV && !process.env.VCAP_SERVICES && !process.env.VERSION_NAME);
    this.isDevelopment = process.env.NODE_ENV === 'development' || process.env.VERSION_NAME;
    this.secretCache = new Map(); // In-memory cache for retrieved secrets
  }

  /**
   * Initialize the Secret Manager client
   * Only initializes in development environments, skips local and production
   * 
   * @throws {Error} If Secret Manager client initialization fails
   */
  async initialize() {
    // Skip initialization for local development
    if (this.isLocal) {
      return;
    }

    // Only initialize in development environments
    if (!this.isDevelopment) {
      return;
    }

    try {
      this.client = new SecretManagerServiceClient();
      // Get project ID from environment variables with fallback
      this.projectId = process.env.GOOGLE_CLOUD_PROJECT || process.env.GCLOUD_PROJECT || 'sa-mps';
      
      // Check if VERSION_NAME is provided (indicates Cloud Run deployment)
      if (process.env.VERSION_NAME) {
        // Log for debugging deployment issues if needed
      }
    } catch (error) {
      console.error('Failed to initialize Secret Manager:', error);
      throw error;
    }
  }

  async getSecret(secretName, version = 'latest') {
    if (this.isLocal) {
      // For local development, return undefined to fall back to process.env
      return undefined;
    }

    if (!this.isDevelopment || !this.client) {
      return undefined;
    }

    // Check cache first
    const cacheKey = `${secretName}:${version}`;
    if (this.secretCache.has(cacheKey)) {
      return this.secretCache.get(cacheKey);
    }

    try {
      const name = `projects/${this.projectId}/secrets/${secretName}/versions/${version}`;
      const [response] = await this.client.accessSecretVersion({ name });
      const secretValue = response.payload.data.toString();
      
      // Cache the secret
      this.secretCache.set(cacheKey, secretValue);
      
      return secretValue;
    } catch (error) {
      console.error(`Failed to access secret ${secretName}:`, error.message);
      return undefined; // Return undefined instead of throwing
    }
  }

  async getSecretObject(secretName, version = 'latest') {
    if (this.isLocal) {
      // For local development, return null to indicate no secret object
      return null;
    }

    if (!this.isDevelopment || !this.client) {
      return null;
    }

    try {
      let secretValue;
      
      // If VERSION_NAME is set (Cloud Run deployment), use it directly
      if (process.env.VERSION_NAME) {
        const [response] = await this.client.accessSecretVersion({ 
          name: process.env.VERSION_NAME 
        });
        secretValue = response.payload.data.toString();
      } else {
        // Otherwise, use the traditional approach
        secretValue = await this.getSecret(secretName, version);
      }
      
      if (!secretValue) {
        return null;
      }
      const parsed = JSON.parse(secretValue);
      
      // Handle nested structure (Environment.Variables)
      if (parsed.Environment && parsed.Environment.Variables) {
        return parsed.Environment.Variables;
      }
      
      // Return as-is if it's a flat structure
      return parsed;
    } catch (error) {
      console.error(`Failed to parse secret ${secretName || 'VERSION_NAME'} as JSON:`, error.message);
      return null; // Return null instead of throwing
    }
  }

  // Clear cache - useful for testing or if secrets are rotated
  clearCache() {
    this.secretCache.clear();
  }
}

export const secretManager = new SecretManagerService();
