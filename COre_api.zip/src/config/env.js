/**
 * Environment configuration module for Smart Axiom MPS API
 * Handles configuration loading from .env files, VCAP_SERVICES (Cloud Foundry),
 * and Google Cloud Secret Manager integration
 * 
 * Supports multiple deployment environments:
 * - local: Development on local machine
 * - development: Development environment (with potential Cloud Run deployment)
 * - production: Production environment
 */

import dotenv from 'dotenv';
// Secret manager is currently disabled - using only environment variables
// import { secretManager } from './secretManager.js';

// Load environment-specific .env files
// Uses .env.local for local development, .env for other environments
const envFile = process.env.NODE_ENV === 'local' ? '.env.local' : '.env';
dotenv.config({ path: envFile });

// Load main .env file as fallback for missing variables
if (envFile !== '.env') {
  dotenv.config({ path: '.env' });
}

// Environment detection logic
const isLocal = process.env.NODE_ENV === 'local';
const isDevelopment = process.env.NODE_ENV === 'development' || process.env.VERSION_NAME;
const isProduction = process.env.NODE_ENV === 'production' || (!isLocal && !isDevelopment);

// Handle VCAP_SERVICES for Cloud Foundry deployments
// VCAP_SERVICES contains service bindings and credentials in CF environments
let vcapCredentials = {};
const vcap_services = process.env.VCAP_SERVICES;
if (vcap_services) {
  try {
    const dataParse = JSON.parse(vcap_services);
    // Extract credentials from user-provided services
    vcapCredentials = dataParse['user-provided']?.[0]?.credentials || {};
  } catch (error) {
    console.error('Failed to parse VCAP_SERVICES:', error);
  }
}

// Create a merged environment object
const customize_string = { ...process.env, ...vcapCredentials };

const required = (name, v = customize_string[name]) => {
  if (!v) throw new Error(`Missing env var: ${name}`);
  return v;
};

const optional = (name, defaultValue = null, v = customize_string[name]) => {
  return v || defaultValue;
};

// Configuration store
let configStore = null;

// Function to get config value from environment or VCAP_SERVICES
const getConfigValue = (envVarName, defaultValue = null) => {
  // First, check VCAP_SERVICES credentials
  if (vcapCredentials[envVarName]) {
    return vcapCredentials[envVarName];
  }
  
  // Use process.env or default value
  return process.env[envVarName] || customize_string[envVarName] || defaultValue;
};

/**
 * Initialize and return application configuration
 * Merges environment variables, VCAP_SERVICES, and handles caching
 * Must be called before using getConfig()
 * 
 * @returns {Object} Complete application configuration object
 */
export const initializeConfig = () => {
  if (configStore) {
    return configStore; // Return cached config if already initialized
  }

  console.log(`Environment mode: ⏩ ${isLocal ? 'local' : isDevelopment ? 'development' + (process.env.VERSION_NAME ? ' (VERSION_NAME)' : '') : 'production'} ⏪`,`and loading environment from: ${envFile}`);
  console.log(`Available environment variables: NODE_ENV=${process.env.NODE_ENV}, VERSION_NAME=${process.env.VERSION_NAME}, PORT=${process.env.PORT}`);
  
  // Secret manager is disabled - using only environment variables
  // if (isDevelopment) {
  //   await secretManager.initialize();
  // }
  
  // let secrets = null;
  
  // For development environments, try to get the main secret object
  // if (isDevelopment) {
  //   try {
  //     // Based on cloudbuild.yaml, the secret name appears to be dev-203-mps-api-secret
  //     secrets = await secretManager.getSecretObject('dev-203-mps-api-secret');
  //     console.log('Successfully loaded secrets object from Secret Manager');
  //   } catch (error) {
  //     console.warn('Could not load secrets object, falling back to individual secrets and env vars');
  //   }
  // }

  configStore = {
    nodeEnv: optional('NODE_ENV', 'development'),
    port: Number(optional('PORT', 4000)),
    mongoUri: required('MONGO_URI'),
    mqttHost: required('MQTT_HOST'),
    mqttPort: required('MQTT_PORT'),
    jwt: {
      secret: required('JWT_SECRET'),
      expiresIn: optional('JWT_EXPIRES_IN', '1d'),
    },
    aes: {
      keyB64: required('AES_KEY_BASE64')
    },
    reset: {
      tokenExpiresIn: optional('RESET_TOKEN_EXPIRES_IN', '15m'),
      tokenExpiryMinutes: 15, // For consistent use in resetService
      otpExpiresIn: optional('OTP_EXPIRES_IN', '10m'),
      sessionExpiresIn: optional('RESET_SESSION_EXPIRES_IN', '7d'),
      appUrl: optional('APP_URL', 'http://localhost:3000'),
      maxAttempts: 5 // Maximum OTP verification attempts
    },
    email: {
      provider: optional('EMAIL_PROVIDER', 'sendgrid'), // 'smtp' or 'sendgrid'
      from: optional('EMAIL_FROM', 'support@smartaxiom.com'),
      host: optional('EMAIL_HOST', 'smtp.gmail.com'),
      port: Number(optional('EMAIL_PORT', 587)),
      secure: optional('EMAIL_SECURE', 'false') === 'true',
      user: optional('EMAIL_USER', 'support@smartaxiom.com'),
      pass: optional('EMAIL_PASS')
    },
    sendgrid: {
      apiKey: optional('SENDGRID_API_KEY', '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')
    },
    graph: {
      appId: required('MS_APP_ID'),
      appSecret: required('MS_APP_SECRET'),
      tokenUrl: required('GRAPH_API_URL_TOKEN'),
      scope: required('MS_GRAPH_SCOPE')
    }
  };

  return configStore;
};

/**
 * Get the initialized configuration object
 * Throws error if configuration hasn't been initialized
 * 
 * @returns {Object} Complete application configuration
 * @throws {Error} If configuration not initialized
 */
export const getConfig = () => {
  if (!configStore) {
    throw new Error('Configuration not initialized. Call initializeConfig() first.');
  }
  return configStore;
};

/**
 * Backward compatibility proxy for accessing configuration
 * Provides helpful error messages if configuration not initialized
 * 
 * @deprecated Use getConfig() instead for better error handling
 */
export const env = new Proxy({}, {
  get(target, prop) {
    if (!configStore) {
      throw new Error(`Configuration not initialized. Cannot access env.${String(prop)}. Make sure to call initializeConfig() in your server startup.`);
    }
    return configStore[prop];
  }
});
