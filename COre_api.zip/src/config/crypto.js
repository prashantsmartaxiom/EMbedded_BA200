/**
 * Cryptographic utilities for the Smart Axiom MPS API
 * Provides AES-256-GCM encryption/decryption, token generation, and hashing functions
 * Used for secure data transmission and password reset functionality
 */

import crypto from 'crypto';
import { getConfig } from './env.js';

// Get the AES encryption key from configuration (32 bytes for AES-256)
const getKey = () => Buffer.from(getConfig().aes.keyB64, 'base64');

/**
 * Encrypt a JavaScript object using AES-256-GCM
 * 
 * @param {Object} plainObj - The object to encrypt
 * @returns {string} Base64 encoded string in format: "iv.tag.ciphertext"
 */
export const aesEncrypt = (plainObj) => {
  const key = getKey();
  const iv = crypto.randomBytes(12); // GCM recommended 12-byte IV
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const plaintext = Buffer.from(JSON.stringify(plainObj), 'utf8');
  const encrypted = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const tag = cipher.getAuthTag(); // Authentication tag for integrity
  // Return base64 encoded "iv.tag.ciphertext" format
  return `${iv.toString('base64')}.${tag.toString('base64')}.${encrypted.toString('base64')}`;
};

/**
 * Decrypt an AES-256-GCM encrypted string back to a JavaScript object
 * 
 * @param {string} tripleB64 - Base64 encoded string in format: "iv.tag.ciphertext"
 * @returns {Object} The decrypted JavaScript object
 * @throws {Error} If the encrypted payload format is invalid
 */
export const aesDecrypt = (tripleB64) => {
  const key = getKey();
  const [ivB64, tagB64, dataB64] = String(tripleB64).split('.');
  if (!ivB64 || !tagB64 || !dataB64) throw new Error('Invalid encrypted payload format');
  const iv = Buffer.from(ivB64, 'base64');
  const tag = Buffer.from(tagB64, 'base64');
  const data = Buffer.from(dataB64, 'base64');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag); // Set authentication tag for verification
  const decrypted = Buffer.concat([decipher.update(data), decipher.final()]);
  return JSON.parse(decrypted.toString('utf8'));
};

/**
 * Generate a cryptographically secure random token
 * Used for password reset tokens and session identifiers
 * 
 * @param {number} length - Length of the token in bytes (default: 32)
 * @returns {string} Hexadecimal string token
 */
export const generateSecureToken = (length = 32) => {
  return crypto.randomBytes(length).toString('hex');
};

/**
 * Generate a 6-digit numeric OTP (One-Time Password)
 * Used for email verification and two-factor authentication
 * 
 * @returns {string} 6-digit numeric string
 */
export const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

/**
 * Create SHA256 hash of the provided data
 * Used for data integrity verification and secure comparisons
 * 
 * @param {string} data - Data to hash
 * @returns {string} Hexadecimal SHA256 hash
 */
export const createHash = (data) => {
  return crypto.createHash('sha256').update(data).digest('hex');
};

/**
 * Verify data against a SHA256 hash using timing-safe comparison
 * Prevents timing attacks by using constant-time comparison
 * 
 * @param {string} data - Original data to verify
 * @param {string} hash - Expected hash value
 * @returns {boolean} True if data matches the hash
 */
export const verifyHash = (data, hash) => {
  const computedHash = createHash(data);
  return crypto.timingSafeEqual(Buffer.from(computedHash, 'hex'), Buffer.from(hash, 'hex'));
};

/**
 * Generate a shorter reset session identifier
 * Used for temporary session tracking during password reset flows
 * 
 * @returns {string} 32-character hexadecimal session ID
 */
export const generateResetSessionId = () => {
  return crypto.randomBytes(16).toString('hex');
};

/**
 * Calculate expiry time based on duration string
 * Supports seconds (s), minutes (m), hours (h), and days (d)
 * 
 * @param {string} duration - Duration string (e.g., "15m", "1h", "7d")
 * @returns {Date} Future date object representing expiry time
 */
export const getExpiryTime = (duration) => {
  const now = new Date();
  const [amount, unit] = duration.match(/(\d+)([smhd])/).slice(1);
  const multipliers = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  return new Date(now.getTime() + parseInt(amount) * multipliers[unit]);
};
