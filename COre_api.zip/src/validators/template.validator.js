// Import Joi validation library for schema validation
import Joi from 'joi';

// Common validation patterns used throughout template schemas
const objectIdPattern = /^[0-9a-fA-F]{24}$/; // MongoDB ObjectId pattern
const statusValues = ['Active', 'Drafted']; // Valid template status values

// Reusable pagination schema for template list endpoints
const paginationSchema = {
  // Page number for pagination (starts from 1)
  page: Joi.number()
    .integer()
    .min(1)
    .default(1)
    .messages({
      'number.base': 'Page must be a number',
      'number.integer': 'Page must be an integer',
      'number.min': 'Page must be at least 1'
    }),
  // Number of items per page (max 100 for performance)
  limit: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .default(20)
    .messages({
      'number.base': 'Limit must be a number',
      'number.integer': 'Limit must be an integer',
      'number.min': 'Limit must be at least 1',
      'number.max': 'Limit cannot exceed 100'
    })
};

// Base sorting schema
const sortingSchema = {
  sortBy: Joi.string()
    .optional()
    .valid('createdAt', 'layout')
    .default('createdAt')
    .messages({
      'any.only': 'Sort by must be one of: createdAt, layout'
    }),
  sortOrder: Joi.string()
    .optional()
    .valid('asc', 'desc')
    .default('desc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    })
};

// =======================
// PARAMETER VALIDATION SCHEMAS
// =======================

// Template name parameter validation
export const TemplateNameParamsSchema = Joi.object({
  name: Joi.string()
    .required()
    .trim()
    .messages({
      'string.empty': 'Template Name is required',
      'any.required': 'Template Name is required'
    })
});

// Template ID parameter validation
export const templateIdParamsSchema = Joi.object({
  templateId: Joi.string()
    .required()
    .trim()
    .pattern(objectIdPattern)
    .messages({
      'string.empty': 'Template ID is required',
      'string.pattern.base': 'Template ID must be a valid ObjectId',
      'any.required': 'Template ID is required'
    })
});

// =======================
// QUERY VALIDATION SCHEMAS
// =======================


// =======================
// BODY VALIDATION SCHEMAS
// =======================

/**
 * Base template schema containing common fields used across template operations
 * Defines validation rules for template properties like layout, status, and grid structure
 */
const baseTemplateSchema = {
    // Template ID (MongoDB ObjectId)
    id: Joi.string()
    .trim()
        .pattern(objectIdPattern)
        .messages({
            'string.pattern.base': 'ID must be a valid ObjectId'
        }),
    // Template display name
    name: Joi.string()
    .trim()
        .min(1)
        .max(100)
        .messages({
            'string.empty': 'Template name cannot be empty',
            'string.min': 'Template name must be at least 1 character long',
            'string.max': 'Template name cannot exceed 100 characters'
        }),
    // Template layout description or identifier
    layout: Joi.string()
    .trim()
        .max(500)
        .messages({
            'string.empty': 'Layout cannot be empty'
        }),
    // Template status (Active = published, Drafted = work in progress)
    status: Joi.string()
    .trim()
        .valid(...statusValues)
        .default('Drafted')
        .messages({
            'any.only': `Status must be one of: ${statusValues.join(', ')}`
        }),
    // Number of rows in the template grid (max 4 for UI constraints)
    rows: Joi.number()
        .integer()
        .min(1)
        .max(4)
        .messages({
            'number.base': 'Rows must be a number',
            'number.integer': 'Rows must be an integer',
            'number.min': 'Rows must be at least 1',
            'number.max': 'Rows cannot exceed 4'
        }),
    // Number of columns in the template grid (max 4 for UI constraints)
    columns: Joi.number()
            .integer()
            .min(1)
            .max(4)
            .messages({
                'number.base': 'Columns must be a number',  
                'number.integer': 'Columns must be an integer',
                'number.min': 'Columns must be at least 1',
                'number.max': 'Columns cannot exceed 4' 
        }),
    // JSON object defining the detailed layout structure and widget positions
    layoutStructure: Joi.object()
        .messages({
            'object.base': 'Layout structure must be an object'
        }),
};

// Validation schema for template list query parameters
export const updateTemplateListQuerySchema = Joi.object({
  ...paginationSchema,
  sortBy: Joi.string()
    .optional()
    .valid('createdAt', 'name')
    .default('createdAt')
    .messages({
      'any.only': 'Sort by must be one of: createdAt, name'
    }),
  sortOrder: Joi.string()
    .optional()
    .valid('asc', 'desc')
    .default('desc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    }),
  name: Joi.string()
    .optional()
    .trim()
    .messages({
      'string.pattern.base': 'Name must be a valid string'
    }),
  layout: Joi.string()
    .optional()
    .trim()
    .messages({
      'string.pattern.base': 'Layout must be a valid string'
    }),
  status: Joi.string()
    .optional()
    .trim()
    .messages({
      'string.pattern.base': 'Status must be a valid status'
    }),
  rows: Joi.number()
    .optional()
    .integer()
    .min(1)
    .max(4)
      .messages({
        'number.base': 'Rows must be a number',
        'number.integer': 'Rows must be an integer',
        'number.min': 'Rows must be at least 1',
          'number.max': 'Rows cannot exceed 4'    
    }),
  columns: Joi.number()
    .optional()
    .integer()
    .min(1)
    .max(4)
      .messages({
        'number.base': 'Rows must be a number',
        'number.integer': 'Rows must be an integer',
        'number.min': 'Rows must be at least 1',
          'number.max': 'Rows cannot exceed 4'    
    }),
  layoutStructure: Joi.object()
    .optional()
    .messages({
      'object.base': 'Layout structure must be an object'
  }),
});


// Validation schema for adding a template to a specific floor
export const addTemplateBodySchema = Joi.object({
    name: baseTemplateSchema.name.required().messages({
        'any.required': 'Template name is required',
        'string.empty': 'Template name is required'
    }),
    layout: baseTemplateSchema.layout,
    status: baseTemplateSchema.status,
    rows: baseTemplateSchema.rows,
    columns: baseTemplateSchema.columns,
    layoutStructure: baseTemplateSchema.layoutStructure
});

// Validation schema for updating a template
export const updateTemplateBodySchema = Joi.object({
  id: Joi.string()
    .required()
    .trim()
    .pattern(objectIdPattern) 
    .messages({
      'string.empty': 'Template ID is required',
      'string.pattern.base': 'Template ID must be a valid ObjectId',
      'any.required': 'Template ID is required'
    }),
    name: baseTemplateSchema.name.optional(),
    layout: baseTemplateSchema.layout.optional(),
    status: baseTemplateSchema.status.optional(),
    rows: baseTemplateSchema.rows.optional(),
    columns: baseTemplateSchema.columns.optional(),
    layoutStructure: baseTemplateSchema.layoutStructure.optional()
});

// Validation schema for deleting a template
export const deleteTemplateBodySchema = Joi.object({
  id: Joi.string()
    .required()
    .trim()
    .pattern(objectIdPattern)
    .messages({
      'string.empty': 'Template ID is required',
      'string.pattern.base': 'Template ID must be a valid ObjectId',
      'any.required': 'Template ID is required'
    })
});

// =======================
// LEGACY SCHEMA ALIASES (for backward compatibility)
// =======================

// Validation schema for templates-list endpoint query parameters
export const templatesListQuerySchema = Joi.object({
  search: Joi.string()
    .optional()
    .trim()
    .min(1)
    .max(100)
    .messages({
      'string.empty': 'Search name cannot be empty',
      'string.min': 'Search name must be at least 1 character long',
      'string.max': 'Search name cannot exceed 100 characters'
    })
});

// Legacy schema names - keep for backward compatibility
export const addTemplateSchema = addTemplateBodySchema;
export const updateTemplateSchema = updateTemplateBodySchema;
export const deleteTemplateSchema = deleteTemplateBodySchema;