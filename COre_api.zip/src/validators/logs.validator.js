// Import Joi validation library for schema validation
import Joi from 'joi';

/**
 * Validation schema for MQTT logs query parameters
 * Supports filtering, pagination, sorting, and date range queries for MQTT message logs
 */
export const getMqttLogsQuerySchema = Joi.object({
  // Filter by specific device ID
  device_id: Joi.string().optional().trim(),
  // Filter by MQTT topic name
  topic: Joi.string().optional().trim(),
  // Filter by channel type (led, shade, sensor)
  channeltype: Joi.string().optional().trim(),
  // Pagination: page number (starts from 1)
  page: Joi.number().integer().min(1).default(1),
  // Pagination: number of records per page (max 1000)
  limit: Joi.number().integer().min(1).max(1000).default(10),
  // Sort field for ordering results
  sort: Joi.string().valid('createdAt', 'id', 'device_id').default('createdAt'),
  // Sort order: ascending or descending
  order: Joi.string().valid('asc', 'desc').default('desc'),
  // Filter by log status (0 = inactive, 1 = active)
  status: Joi.number().valid(0, 1).optional(),
  // General search term for filtering logs
  search: Joi.string().optional().trim().allow(''),
  startDate: Joi.date().iso().optional(),
  endDate: Joi.date().iso().optional().when('startDate', {
    is: Joi.exist(),
    then: Joi.date().min(Joi.ref('startDate')),
    otherwise: Joi.date()
  }),
  startTime: Joi.string().pattern(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/).optional(),
  endTime: Joi.string().pattern(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/).optional().when('startTime', {
    is: Joi.exist(),
    then: Joi.string().required(),
    otherwise: Joi.string().optional()
  }),
  download: Joi.number().valid(0, 1).optional(),
  timezone: Joi.string().optional().trim()
});

/**
 * Validation schema for event logs query parameters
 * Similar to MQTT logs but for system events and user actions
 */
export const getEventLogsQuerySchema = Joi.object({
  device_id: Joi.string().optional().trim(),
  type: Joi.string().optional().trim(),
  action: Joi.string().optional().trim(),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(1000).default(10),
  sort: Joi.string().valid('timestamp', '_id', 'type', 'name', 'action').default('timestamp'),
  order: Joi.string().valid('asc', 'desc').default('desc'),
  search: Joi.string().optional().trim().allow(''),
  startDate: Joi.date().iso().optional(),
  endDate: Joi.date().iso().optional().when('startDate', {
    is: Joi.exist(),
    then: Joi.date().min(Joi.ref('startDate')),
    otherwise: Joi.date()
  }),
  startTime: Joi.string().pattern(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/).optional(),
  endTime: Joi.string().pattern(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/).optional().when('startTime', {
    is: Joi.exist(),
    then: Joi.string().required(),
    otherwise: Joi.string().optional()
  }),
  download: Joi.number().valid(0, 1).optional(),
  timezone: Joi.string().optional().trim()
});

// Query validation schema for getting MQTT log statistics
// export const getMqttLogStatsQuerySchema = Joi.object({
//   device_id: Joi.string().optional().trim(),
//   startDate: Joi.date().iso().optional(),
//   endDate: Joi.date().iso().optional().when('startDate', {
//     is: Joi.exist(),
//     then: Joi.date().min(Joi.ref('startDate')),
//     otherwise: Joi.date()
//   })
// });
