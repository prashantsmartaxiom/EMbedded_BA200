// Import Joi validation library for schema validation
import Joi from 'joi';

/**
 * Generic validation middleware for query parameters
 * @param {Object} schema - Joi validation schema
 * @returns {Function} Express middleware function
 */
export const validateQuery = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.query);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message
      });
    }
    next();
  };
};

/**
 * Validation schema for creating a new timezone entry
 * Used for managing timezone data in the widget system
 */
export const createTimezoneSchema = Joi.object({
  // Human-readable timezone name (e.g., "Eastern Time")
  timeZoneName: Joi.string()
    .trim()
    .min(1)
    .max(100)
    .required()
    .messages({
      'string.empty': 'Timezone name is required',
      'string.min': 'Timezone name must be at least 1 character',
      'string.max': 'Timezone name cannot exceed 100 characters',
      'any.required': 'Timezone name is required'
    }),
  // Timezone identifier/value (e.g., "America/New_York")
  timeZoneValue: Joi.string()
    .trim()
    .min(1)
    .max(100)
    .required()
    .messages({
      'string.empty': 'Timezone value is required',
      'string.min': 'Timezone value must be at least 1 character',
      'string.max': 'Timezone value cannot exceed 100 characters',
      'any.required': 'Timezone value is required'
    })
});



/**
 * Validation schema for getting timezone by ID
 */
export const getTimezoneByIdSchema = Joi.object({
  id: Joi.string()
    .regex(/^[0-9a-fA-F]{24}$/)
    .required()
    .messages({
      'string.pattern.base': 'Invalid timezone ID format',
      'any.required': 'Timezone ID is required'
    })
});



/**
 * Validation schema for toggling timezone status
 */
export const toggleTimezoneStatusSchema = Joi.object({
  isActive: Joi.boolean()
    .required()
    .messages({
      'boolean.base': 'isActive must be a boolean',
      'any.required': 'isActive field is required'
    })
});

/**
 * Validation middleware function
 */
export const validateRequest = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message
      });
    }
    next();
  };
};

/**
 * Validation schema for weather information request
 * Used to get weather data for a specific location by coordinates and place name
 */
export const getWeatherInfoSchema = Joi.object({
  // Latitude coordinate (-90 to 90 degrees)
  lat: Joi.number()
    .min(-90)
    .max(90)
    .required()
    .messages({
      'number.base': 'Latitude must be a number',
      'number.min': 'Latitude must be between -90 and 90',
      'number.max': 'Latitude must be between -90 and 90',
      'any.required': 'Latitude is required'
    }),
  // Longitude coordinate (-180 to 180 degrees)
  long: Joi.number()
    .min(-180)
    .max(180)
    .required()
    .messages({
      'number.base': 'Longitude must be a number',
      'number.min': 'Longitude must be between -180 and 180',
      'number.max': 'Longitude must be between -180 and 180',
      'any.required': 'Longitude is required'
    }),
  // Human-readable place name for weather location
  placeName: Joi.string()
    .trim()
    .min(1)
    .max(200)
    .required()
    .messages({
      'string.empty': 'Place name cannot be empty',
      'string.min': 'Place name must be at least 1 character',
      'string.max': 'Place name cannot exceed 200 characters',
      'any.required': 'Place name is required'
    })
});

/**
 * Validation schema for weather coordinates query
 */
export const getWeatherByCoordinatesSchema = Joi.object({
  lat: Joi.number()
    .min(-90)
    .max(90)
    .required()
    .messages({
      'number.base': 'Latitude must be a number',
      'number.min': 'Latitude must be between -90 and 90',
      'number.max': 'Latitude must be between -90 and 90',
      'any.required': 'Latitude is required'
    }),
  long: Joi.alternatives().try(
    Joi.number()
      .min(-180)
      .max(180),
    Joi.any().forbidden()
  ),
  longitude: Joi.number()
    .min(-180)
    .max(180)
    .messages({
      'number.base': 'Longitude must be a number',
      'number.min': 'Longitude must be between -180 and 180',
      'number.max': 'Longitude must be between -180 and 180',
      'any.required': 'Longitude is required'
    })
}).or('long', 'longitude');

/**
 * Validation schema for city temperatures request
 */
export const getCurrentTemperaturesSchema = Joi.object({
  cities: Joi.array()
    .items(
      Joi.object({
        cityName: Joi.string()
          .trim()
          .min(1)
          .max(100)
          .required()
          .messages({
            'string.empty': 'City name cannot be empty',
            'string.min': 'City name must be at least 1 character',
            'string.max': 'City name cannot exceed 100 characters',
            'any.required': 'City name is required'
          }),
        lat: Joi.number()
          .min(-90)
          .max(90)
          .required()
          .messages({
            'number.base': 'Latitude must be a number',
            'number.min': 'Latitude must be between -90 and 90',
            'number.max': 'Latitude must be between -90 and 90',
            'any.required': 'Latitude is required'
          }),
        long: Joi.number()
          .min(-180)
          .max(180)
          .required()
          .messages({
            'number.base': 'Longitude must be a number',
            'number.min': 'Longitude must be between -180 and 180',
            'number.max': 'Longitude must be between -180 and 180',
            'any.required': 'Longitude is required'
          })
      })
    )
    .min(1)
    .max(50)
    .required()
    .messages({
      'array.base': 'Cities must be an array',
      'array.min': 'At least 1 city is required',
      'array.max': 'Maximum 50 cities allowed',
      'any.required': 'Cities array is required'
    })
});

/**
 * Validation middleware for URL parameters
 */
export const validateParams = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.params);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message
      });
    }
    next();
  };
};

// For AQI/temperature current hour endpoint (alias for getWeatherByCoordinatesSchema)
export const getAqiAndTemperatureCurrentHourSchema = getWeatherByCoordinatesSchema;

/**
 * Validation schema for updating weather information
 */
export const updateWeatherSchema = getWeatherInfoSchema;

/**
 * Validation schema for weather ID parameter
 */
export const weatherIdSchema = Joi.object({
  id: Joi.string()
    .regex(/^[0-9a-fA-F]{24}$/)
    .required()
    .messages({
      'string.pattern.base': 'Invalid weather ID format',
      'any.required': 'Weather ID is required'
    })
});