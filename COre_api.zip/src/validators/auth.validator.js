// Import Joi validation library for schema validation
import Joi from 'joi';

/**
 * Validation schema for user signup/registration
 * Validates user input for creating new accounts with required fields and constraints
 */
export const signupSchema = Joi.object({
  // User's full name - required field with length constraints
  fullName: Joi.string()
    .trim()
    .min(2)
    .max(100)
    .required()
    .messages({
      'string.empty': 'Full name is required',
      'string.min': 'Full name must be at least 2 characters long',
      'string.max': 'Full name cannot exceed 100 characters'
    }),

  // User's location/address - required field for profile setup
  location: Joi.string()
    .trim()
    .min(2)
    .max(100)
    .required()
    .messages({
      'string.empty': 'Location is required',
      'string.min': 'Location must be at least 2 characters long',
      'string.max': 'Location cannot exceed 100 characters'
    }),

  // Optional contact number - can be empty or null
  contactNumber: Joi.string()
      .optional()
      .allow('', null),

  email: Joi.string()
    .email()
    .lowercase()
    .required()
    .messages({
      'string.email': 'Please provide a valid email address',
      'string.empty': 'Email is required'
    }),

  // Strong password requirements: min 8 chars, must include uppercase, lowercase, number, and special character
  password: Joi.string()
    .min(8)
    .max(128)
    .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).+$/)
    .required()
    .messages({
      'string.min': 'Password must be at least 8 characters long',
      'string.max': 'Password cannot exceed 128 characters',
      'string.pattern.base': 'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character',
      'string.empty': 'Password is required'
    }),

  // User role - defaults to 'user' if not specified, determines access permissions
  role: Joi.string()
    .valid('admin', 'manager', 'user', 'viewer')
    .default('user')
    .messages({
      'any.only': 'Role must be one of: admin, manager, user, viewer'
    }),

  // Optional array of topics/resources assigned to the user for access control
  // Each topic can specify campus, building, floor, zone, template, group, scene, or sensor events
  assignedTopics: Joi.array()
    .items(
      Joi.object({
        campus: Joi.string().trim().allow(''),
        building: Joi.string().trim().allow(''),
        floor: Joi.string().trim().allow(''),
        zone: Joi.string().trim().allow(''),
        template: Joi.string().trim().allow(''),
        group: Joi.string().trim().allow(''),
        scene: Joi.string().trim().allow(''),
        sensorEvent: Joi.string().trim().allow('')
      })
    )
    .default([])
});

/**
 * Validation schema for user login
 * Validates email and password for authentication
 */
export const loginSchema = Joi.object({
  email: Joi.string()
    .email()
    .lowercase()
    .required()
    .messages({
      'string.email': 'Please provide a valid email address',
      'string.empty': 'Email is required'
    }),

  password: Joi.string()
    .required()
    .messages({
      'string.empty': 'Password is required'
    })
});

/**
 * Validation schema for verifying signup OTP
 * Used to validate the 6-digit OTP sent to user's email during registration
 */
export const verifySignupOTPSchema = Joi.object({
  // Email address to verify OTP against
  email: Joi.string()
    .email()
    .lowercase()
    .required()
    .messages({
      'string.email': 'Please provide a valid email address',
      'string.empty': 'Email is required'
    }),

  // 6-digit numeric OTP code
  otp: Joi.string()
    .length(6)
    .pattern(/^\d{6}$/)
    .required()
    .messages({
      'string.length': 'OTP must be exactly 6 digits',
      'string.pattern.base': 'OTP must contain only numbers',
      'string.empty': 'OTP is required'
    })
});

/**
 * Validation schema for password reset (when user knows current password)
 * Validates both old and new passwords for security
 */
export const resetPasswordSchema = Joi.object({
  // Current password for verification
  oldPassword: Joi.string()
    .required()
    .messages({
      'string.empty': 'Current password is required'
    }),

  // New password with strong security requirements
  newPassword: Joi.string()
    .min(8)
    .max(128)
    .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).+$/)
    .required()
    .messages({
      'string.min': 'New password must be at least 8 characters long',
      'string.max': 'New password cannot exceed 128 characters',
      'string.pattern.base': 'New password must contain at least one uppercase letter, one lowercase letter, one number, and one special character',
      'string.empty': 'New password is required'
    })
});

export const changePasswordSchema = Joi.object({
  email: Joi.string()
    .email()
    .lowercase()
    .required()
    .messages({
      'string.email': 'Please provide a valid email address',
      'string.empty': 'Email is required'
    }),

  oldPassword: Joi.string()
    .required()
    .messages({
      'string.empty': 'Old password is required'
    })
});

export const userIdParamSchema = Joi.object({
  id: Joi.string()
    .pattern(/^[0-9a-fA-F]{24}$/)
    .required()
    .messages({
      'string.pattern.base': 'Invalid user ID format',
      'string.empty': 'User ID is required'
    })
});

export const updateProfileSchema = Joi.object({
  fullName: Joi.string()
    .trim()
    .min(2)
    .max(100)
    .optional()
    .messages({
      'string.min': 'Full name must be at least 2 characters long',
      'string.max': 'Full name cannot exceed 100 characters'
    }),

  password: Joi.string()
    .min(8)
    .max(128)
    .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).+$/)
    .optional()
    .messages({
      'string.min': 'Password must be at least 8 characters long',
      'string.max': 'Password cannot exceed 128 characters',
      'string.pattern.base': 'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character'
    }),

  role: Joi.string()
    .valid('admin', 'manager', 'user', 'viewer')
    .optional()
    .messages({
      'any.only': 'Role must be one of: admin, manager, user, viewer'
    }),

  profileImage: Joi.string()
    .uri()
    .optional()
    .allow('')
    .messages({
      'string.uri': 'Profile image must be a valid URL'
    })
});

/**
 * Validation schema for forgot password request
 * Initiates password reset process by sending OTP to user's email
 */
export const forgotPasswordSchema = Joi.object({
  // Email address to send password reset OTP
  email: Joi.string()
    .email()
    .lowercase()
    .required()
    .messages({
      'string.email': 'Please provide a valid email address',
      'string.empty': 'Email is required'
    })
});

export const verifyOTPSchema = Joi.object({
  email: Joi.string()
    .email()
    .lowercase()
    .required()
    .messages({
      'string.email': 'Please provide a valid email address',
      'string.empty': 'Email is required'
    }),

  otp: Joi.string()
    .length(6)
    .pattern(/^\d{6}$/)
    .required()
    .messages({
      'string.length': 'OTP must be exactly 6 digits',
      'string.pattern.base': 'OTP must contain only numbers',
      'string.empty': 'OTP is required'
    })
});

export const newResetPasswordSchema = Joi.object({
  email: Joi.string()
    .email()
    .lowercase()
    .required()
    .messages({
      'string.email': 'Please provide a valid email address',
      'string.empty': 'Email is required'
    }),

  newPassword: Joi.string()
    .min(8)
    .max(128)
    .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).+$/)
    .required()
    .messages({
      'string.min': 'Password must be at least 8 characters long',
      'string.max': 'Password cannot exceed 128 characters',
      'string.pattern.base': 'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character',
      'string.empty': 'New password is required'
    }),

  token: Joi.string()
    .min(32)
    .optional()
    .messages({
      'string.min': 'Invalid reset token format'
    })
});

// Schema for protected change password (when user is logged in)
export const protectedChangePasswordSchema = Joi.object({
  currentPassword: Joi.string()
    .required()
    .messages({
      'string.empty': 'Current password is required'
    }),

  newPassword: Joi.string()
    .min(8)
    .max(128)
    .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).+$/)
    .required()
    .messages({
      'string.min': 'New password must be at least 8 characters long',
      'string.max': 'New password cannot exceed 128 characters',
      'string.pattern.base': 'New password must contain at least one uppercase letter, one lowercase letter, one number, and one special character',
      'string.empty': 'New password is required'
    }),

  confirmPassword: Joi.string()
    .valid(Joi.ref('newPassword'))
    .required()
    .messages({
      'any.only': 'Password confirmation must match new password',
      'string.empty': 'Password confirmation is required'
    })
});

export const resetStatusSchema = Joi.object({
  email: Joi.string()
    .email()
    .lowercase()
    .required()
    .messages({
      'string.email': 'Please provide a valid email address',
      'string.empty': 'Email is required'
    })
});
