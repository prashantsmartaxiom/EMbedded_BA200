// Import Joi validation library for schema validation
import Joi from 'joi';

/**
 * Schema for validating device capabilities (LED, shade, sensor)
 * Each capability has a type, channel ID, name, status, and properties
 */
const capabilitySchema = Joi.object({
  // Type of capability: LED lighting, shade/blind control, or sensor
  type: Joi.string().valid('led', 'shade', 'sensor').required(),
  // Unique identifier for the channel within the device
  channelId: Joi.string().required(),
  // Human-readable name for the capability
  name: Joi.string().required(),
  // Current operational status of the capability
  status: Joi.string().required(),
  // Additional properties specific to the capability type
  properties: Joi.object().required()
});

/**
 * Validation schema for adding a new device
 * Includes device identification, location, capabilities, and port configuration
 */
export const addDeviceSchema = Joi.object({
  // Unique device identifier
  device_id: Joi.string().required().trim(),
  // Serial number of the device
  SNO: Joi.string().required().trim(),
  // Firmware version installed on the device
  firmware: Joi.string().required().trim(),
  // MAC address of the device for network identification
  Mac_addr: Joi.string().required().trim(),
  // Current operational status of the device
  status: Joi.string().valid('Active', 'Inactive').default('Active'),
  // Optional description of the device
  description: Joi.string().optional().allow('').trim(),
  // Human-readable name for the device
  name: Joi.string().required().trim(),
  // Configuration flag: 0 = not configured, 1 = configured
  configure_flag: Joi.number().valid(0, 1).default(0),
  // Type/category of the device (e.g., dimmer, switch, sensor)
  type: Joi.string().required().trim(),
  // Array of device capabilities (LED, shade, sensor channels)
  capabilities: Joi.array().items(capabilitySchema).optional(),

  // Location information - hierarchical placement of the device
  // Campus ID where the device is installed
  campus: Joi.string().required(),
  // Building ID within the campus
  building: Joi.string().required(),
  // Floor ID within the building
  floor: Joi.string().required(),
  // Zone ID within the floor
  zone: Joi.string().required(),

  // Port information - can be provided as separate fields or combined
  port: Joi.string().optional().trim(), // Optional combined port string
  port_primary: Joi.string().optional().trim().pattern(/^\d+\/\d+$/), // Format: 1/2
  port_secondary: Joi.string().optional().trim().pattern(/^\d+(\/\d+)*$/), // Format: 3/4/5
    is_delete: Joi.boolean().optional()
});

/**
 * Validation schema for updating existing device information
 * All fields are optional - only provided fields will be updated
 */
export const updateDeviceSchema = Joi.object({
  SNO: Joi.string().optional().trim(),
  firmware: Joi.string().optional().trim(),
  Mac_addr: Joi.string().optional().trim(),
  status: Joi.string().valid('Active', 'Inactive').optional(),
  description: Joi.string().optional().allow('').trim(),
  device_name: Joi.string().optional().trim(), // Added device_name field
  name: Joi.string().optional().trim(),
  configure_flag: Joi.number().valid(0, 1).optional(),
  type: Joi.string().optional().trim(),
  capabilities: Joi.array().items(capabilitySchema).optional(),

  // Location information
  campus: Joi.string().optional(),
  building: Joi.string().optional(),
  floor: Joi.string().optional(),
  zone: Joi.string().optional(),

  // Port information
  port: Joi.string().optional().trim(),
  port_primary: Joi.string().optional().trim().pattern(/^\d+(\/\d+)*$/), // Updated to allow flexible format
  port_secondary: Joi.string().optional().trim().pattern(/^\d+(\/\d+)*$/),
  is_delete: Joi.boolean().optional()
});

/**
 * Validation schema for device list query parameters
 * Supports filtering devices by various criteria
 */
export const deviceListQuerySchema = Joi.object({
  status: Joi.string().valid('Active', 'Inactive').optional(),
  campusId: Joi.string().optional(),
  buildingId: Joi.string().optional(),
  floorId: Joi.string().optional(),
  zoneId: Joi.string().optional(),
  type: Joi.string().optional(),
  ownership: Joi.string().valid('own', 'third-party').optional(),
  search: Joi.string().optional().trim()
});

// Query parameters validation for device discovery list with search
export const deviceDiscoveryQuerySchema = Joi.object({
  status: Joi.string().valid('Active', 'Inactive').optional(),
  campusId: Joi.string().optional(),
  buildingId: Joi.string().optional(),
  floorId: Joi.string().optional(),
  zoneId: Joi.string().optional(),
  search: Joi.string().optional().trim().allow(''),
  deviceId: Joi.string().optional().trim().allow(''),
  type: Joi.string().optional(),
  ownership: Joi.string().valid('own', 'third-party').optional(),
  limit: Joi.number().integer().min(1).max(1000).optional().default(100),
  page: Joi.number().integer().min(1).optional().default(1)
});

/**
 * Validation schema for device configuration
 * Used when setting up a device in a specific location with custom settings
 */
export const configureDeviceSchema = Joi.object({
  device_id: Joi.string().required().trim(),
  campus_id: Joi.string().required(),
  building_id: Joi.string().required(),
  floor_id: Joi.string().required(),
  zone_id: Joi.string().required(),
  device_name: Joi.string().required().trim(),
  serial_name: Joi.string().required().trim(),
  description: Joi.string().optional().allow('').trim(),
  port: Joi.alternatives().try(
    // Port as string (e.g., "1/2/3/4/5")
    Joi.string().trim(),
    // Port as object with primary and secondary
    Joi.object({
       primary: Joi.string().trim().pattern(/^\d+(\/\d+)*$/),   // Accepts "1", "1/2", "1/2/3"...
      secondary: Joi.string().trim().pattern(/^\d+(\/\d+)*$/) 
    })
  ).optional()
});

// Query parameters validation for configured devices list
export const configuredDevicesQuerySchema = Joi.object({
  status: Joi.string().valid('Active', 'Inactive').optional(),
  active: Joi.alternatives().try(Joi.string().valid('1', '0'), Joi.number().valid(0, 1)).optional(),
  device_type: Joi.string().optional().trim(),
  device_id: Joi.string().optional().trim(),
  campus_id: Joi.string().optional(),
  building_id: Joi.string().optional(),
  floor_id: Joi.string().optional(),
  zone_id: Joi.string().optional(),
  search: Joi.string().optional().trim().allow(''),
  limit: Joi.number().integer().min(1).max(500).optional().default(50),
  page: Joi.number().integer().min(1).optional().default(1)
});

// Device ID parameter validation
export const deviceIdSchema = Joi.object({
  deviceId: Joi.string().optional()
});

// Device ID and Channel ID parameter validation  
export const deviceChannelIdSchema = Joi.object({
  deviceId: Joi.string().required(),
  channelId: Joi.string().required()
});

// Update the channel update schema to match what your service expects
export const updateChannelNameSchema = Joi.object({
  type: Joi.string().valid('led', 'shade', 'sensor').required(),
  name: Joi.string().optional().trim(),
  properties: Joi.object().optional(),
  status: Joi.string().optional(),
  installed: Joi.boolean().optional() // Allow top-level installed flag
});

// Query parameters validation for devices list with channels
export const devicesListQuerySchema = Joi.object({
  search: Joi.string().optional().trim().allow(''), // Search by device name
  campus: Joi.string().optional(), // Filter by campus ID
  building: Joi.string().optional(), // Filter by building ID
  floor: Joi.string().optional(), // Filter by floor ID
  zone: Joi.string().optional(), // Filter by zone ID
  status: Joi.string().valid('Active', 'Inactive').optional(), // Filter by status
  limit: Joi.number().integer().min(1).max(500).optional().default(50),
  page: Joi.number().integer().min(1).optional().default(1)
});