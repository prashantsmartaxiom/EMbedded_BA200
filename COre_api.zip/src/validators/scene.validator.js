import Joi from 'joi';
export const deviceIdParamSchema = Joi.object({
  deviceId: Joi.string()
    .trim()
    .min(1)
    .max(50)
    .required()
    .messages({
      'string.empty': 'Device ID cannot be empty',
      'string.min': 'Device ID must be at least 1 character long',
      'string.max': 'Device ID cannot exceed 50 characters',
      'any.required': 'Device ID is required'
    })
});

const channel = Joi.object({
  channelType: Joi.string().valid('led', 'shade', 'sensor').required(),
  channelId: Joi.string().trim().required(),
  command: Joi.string().valid('on', 'off', 'open', 'close').optional(),
  // Accept number or string, coerce later in custom() and clamp 0-100
  brightness: Joi.alternatives().try(Joi.number().integer(), Joi.string()), // for led
  openLevel: Joi.alternatives().try(Joi.number().integer(), Joi.string())  // for shade
})
  .custom((val, helpers) => {
    const coerced = { ...val };

    // Auto-generate command if not provided
    if (coerced.channelType === 'led') {
      if (coerced.command && !['on', 'off'].includes(coerced.command)) {
        return helpers.error('any.invalid', { message: 'LED command must be "on" or "off"' });
      }
      // Auto-generate command based on brightness if not provided
      if (!coerced.command) {
        coerced.command = (coerced.brightness && parseInt(coerced.brightness) > 0) ? 'on' : 'off';
      }

      if (typeof coerced.brightness !== 'undefined') {
        let b = coerced.brightness;
        if (typeof b === 'string') {
          b = b.trim();
          if (b.endsWith('%')) b = b.slice(0, -1);
        }
        b = parseInt(b, 10);
        if (Number.isNaN(b)) {
          return helpers.error('any.invalid', { message: 'brightness must be a number' });
        }
        if (b < 0) b = 0;
        if (b > 100) b = 100;
        coerced.brightness = b;
      }
    }

    if (coerced.channelType === 'shade') {
      if (coerced.command && !['open', 'close'].includes(coerced.command)) {
        return helpers.error('any.invalid', { message: 'Shade command must be "open" or "close"' });
      }
      // Auto-generate command based on openLevel if not provided
      if (!coerced.command) {
        coerced.command = (coerced.openLevel && parseInt(coerced.openLevel) > 0) ? 'open' : 'close';
      }

      if (typeof coerced.openLevel !== 'undefined') {
        let o = coerced.openLevel;
        if (typeof o === 'string') {
          o = o.trim();
          if (o.endsWith('%')) o = o.slice(0, -1);
        }
        o = parseInt(o, 10);
        if (Number.isNaN(o)) {
          return helpers.error('any.invalid', { message: 'openLevel must be a number' });
        }
        if (o < 0) o = 0;
        if (o > 100) o = 100;
        coerced.openLevel = o;
      }
    }

    return coerced;
  }, 'channel cross-field rules and coercion');

const deviceEntry = Joi.object({
  deviceId: Joi.string().trim().required(),
  channels: Joi.array().items(channel).min(1).required()
});

const groupEntry = Joi.object({
  groupId: Joi.string().hex().length(24).required(),
  devices: Joi.array().items(deviceEntry).min(1).required()
});

export const addSceneSchema = Joi.object({
  name: Joi.string().trim().min(2).max(100).required(),
  type: Joi.string().valid('device', 'group').required(),

  // Exactly one of Devices or Groups must be provided, matching the type
  Devices: Joi.alternatives().conditional('type', {
    is: 'device',
    then: Joi.array().items(deviceEntry).min(1).required(),
    otherwise: Joi.forbidden()
  }),
  Groups: Joi.alternatives().conditional('type', {
    is: 'group',
    then: Joi.array().items(groupEntry).min(1).required(),
    otherwise: Joi.forbidden()
  }),

  lastExecuted: Joi.string().isoDate().allow(null).default(null),
  executedBy: Joi.string().allow(null).default(null),
  operateType: Joi.string().valid('invert', 'normal').default('normal') // 'normal'=default, 'invert'=inverted operation
});

export const listScenesQuerySchema = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  // filters
  groupId: Joi.string().hex().length(24),
  deviceId: Joi.string().trim(),
  channelType: Joi.string().valid('led', 'shade', 'sensor'),
  status: Joi.number().integer().valid(0, 1), // Add status filter
  // search
  search: Joi.string().trim().allow('')
});

export const updateSceneSchema = Joi.object({
  name: Joi.string().trim().min(2).max(100),
  type: Joi.string().valid('device', 'group'),

  // Exactly one of Devices or Groups must be provided, matching the type
  Devices: Joi.alternatives().conditional('type', {
    is: 'device',
    then: Joi.array().items(deviceEntry).min(1),
    otherwise: Joi.forbidden()
  }),
  Groups: Joi.alternatives().conditional('type', {
    is: 'group',
    then: Joi.array().items(groupEntry).min(1),
    otherwise: Joi.forbidden()
  }),

  // lastExecuted and executedBy are internal fields, not allowed in updates
  operateType: Joi.string().valid('invert', 'normal'),
  invert_flag: Joi.boolean().default(false),
  status: Joi.number().valid(0, 1)
}).min(1); // At least one field must be provided for update

export const updateSceneParamsSchema = Joi.object({
  id: Joi.string().hex().length(24).required()
});

// Add this export to the existing scene.validator.js file
export const updateSceneStatusSchema = Joi.object({
  status: Joi.number().integer().valid(0, 1).required()
});

export const sceneParamsSchema = Joi.object({
  id: Joi.string().hex().length(24).required()
});


export const getAllScenesValidator = Joi.object({
  search: Joi.string()
    .optional()
    .allow('')
    .max(100)
    .messages({
      'string.max': 'Search term cannot exceed 100 characters'
    }),
  status: Joi.number()
    .optional()
    .valid(0, 1)
    .messages({
      'any.only': 'Status must be 0 (inactive) or 1 (active)'
    }),
  sortBy: Joi.string()
    .optional()
    .valid('createdAt', 'name', 'type', 'status')
    .default('createdAt')
    .messages({
      'any.only': 'Sort by must be one of: createdAt, name, type, status'
    }),
  sortOrder: Joi.string()
    .optional()
    .valid('asc', 'desc')
    .default('desc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    })
});

export const viewSceneParamsSchema = Joi.object({
  sceneId: Joi.string()
    .hex()
    .length(24)
    .required()
    .messages({
      'string.hex': 'Scene ID must be a valid hexadecimal string',
      'string.length': 'Scene ID must be exactly 24 characters long',
      'any.required': 'Scene ID is required'
    })
});

export const getAllScenesWithDetailsValidator = Joi.object({
  search: Joi.string()
    .optional()
    .allow('')
    .max(100)
    .messages({
      'string.max': 'Search term cannot exceed 100 characters'
    }),
  status: Joi.number()
    .optional()
    .valid(0, 1)
    .messages({
      'any.only': 'Status must be 0 (inactive) or 1 (active)'
    }),
  sortBy: Joi.string()
    .optional()
    .valid('createdAt', 'name', 'type', 'status')
    .default('createdAt')
    .messages({
      'any.only': 'Sort by must be one of: createdAt, name, type, status'
    }),
  sortOrder: Joi.string()
    .optional()
    .valid('asc', 'desc')
    .default('desc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    }),
  page: Joi.number()
    .integer()
    .min(1)
    .default(1)
    .messages({
      'number.base': 'Page must be a number',
      'number.integer': 'Page must be an integer',
      'number.min': 'Page must be at least 1'
    }),
  limit: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .default(50)
    .messages({
      'number.base': 'Limit must be a number',
      'number.integer': 'Limit must be an integer',
      'number.min': 'Limit must be at least 1',
      'number.max': 'Limit cannot exceed 100'
    })
});

// Validation schema for scenes-list endpoint query parameters
export const scenesListQuerySchema = Joi.object({
  search: Joi.string()
    .optional()
    .trim()
    .min(1)
    .max(100)
    .messages({
      'string.empty': 'Search name cannot be empty',
      'string.min': 'Search name must be at least 1 character long',
      'string.max': 'Search name cannot exceed 100 characters'
    })
});
