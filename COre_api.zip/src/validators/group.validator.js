// Import Joi validation library for schema validation
import Joi from 'joi';

/**
 * Validation schema for creating a new device group
 * Groups allow controlling multiple device channels together
 */
export const createGroupSchema = Joi.object({
	// Group name - unique identifier for the device group
	name: Joi.string().trim().min(2).max(100).required().messages({
		'string.empty': 'Group name is required',
		'string.min': 'Group name must be at least 2 characters long',
		'string.max': 'Group name cannot exceed 100 characters'
	}),
	// Array of devices and their channels to include in the group
	devices: Joi.array().items(
		Joi.object({
			// Unique device identifier
			deviceId: Joi.string().required().messages({
				'string.empty': 'Device ID is required'
			}),
			// Array of channels from this device to include in the group
			channels: Joi.array().items(
				Joi.object({
					// Channel identifier within the device
					channelId: Joi.string().required().messages({
						'string.empty': 'Channel ID is required'
					}),
					// Type of channel (led, shade, sensor)
					channelType: Joi.string().required().messages({
						'string.empty': 'Channel Type is required'
					})
				})
			).min(1).required().messages({
				'array.min': 'At least one channel is required',
				'array.base': 'Channels must be an array'
			})
		})
	).min(1).required().messages({
		'array.min': 'At least one device is required',
		'array.base': 'Devices must be an array'
	})
});

/**
 * Middleware function to validate group creation request
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 * @returns {Object} Error response if validation fails, otherwise calls next()
 */
export function validateCreateGroup(req, res, next) {
	const { error } = createGroupSchema.validate(req.body, { abortEarly: false });
	if (error) {
		return res.status(400).json({ success: false, errors: error.details });
	}
	next();
}

/**
 * Validation schema for getting device channels
 * Used to retrieve channel information for specified devices
 */
export const getDeviceChannelsSchema = Joi.object({
  // Array of device IDs to get channel information for
  deviceIds: Joi.array()
    .items(Joi.string().trim().min(1))
    .min(1)
    .required()
    .messages({
      'any.required': 'deviceIds is required',
      'array.min': 'Provide at least one deviceId'
    })
});

/**
 * Validation schema for group ID parameter
 * Validates MongoDB ObjectId format for group operations
 */
export const groupIdParamSchema = Joi.object({
  // MongoDB ObjectId for the group (24-character hex string)
  groupId: Joi.string().hex().length(24).required().messages({
    'string.length': 'groupId must be a 24-char hex ObjectId'
  })
});

/**
 * Validation schema for device ID parameter
 * Validates device identifier for device-specific operations
 */
export const deviceIdParamSchema = Joi.object({
  // Device identifier (string format)
  deviceId: Joi.string().trim().min(1).required().messages({
    'string.empty': 'Device ID is required',
    'any.required': 'Device ID is required'
  })
});

/**
 * Validation schema for getting all groups with detailed device information
 * Supports filtering, searching, and pagination
 */
export const getAllGroupsWithDeviceDetailsQuerySchema = Joi.object({
  search: Joi.string().trim().max(100).optional().messages({
    'string.max': 'Search term cannot exceed 100 characters'
  }),
  campus: Joi.string().hex().length(24).optional().messages({
    'string.length': 'Campus ID must be a 24-character hex ObjectId'
  }),
  building: Joi.string().hex().length(24).optional().messages({
    'string.length': 'Building ID must be a 24-character hex ObjectId'
  }),
  floor: Joi.string().hex().length(24).optional().messages({
    'string.length': 'Floor ID must be a 24-character hex ObjectId'
  }),
  zone: Joi.string().hex().length(24).optional().messages({
    'string.length': 'Zone ID must be a 24-character hex ObjectId'
  }),
  page: Joi.number().integer().min(1).default(1).optional().messages({
    'number.base': 'Page must be a number',
    'number.integer': 'Page must be an integer',
    'number.min': 'Page must be at least 1'
  }),
  limit: Joi.number().integer().min(1).max(100).default(50).optional().messages({
    'number.base': 'Limit must be a number',
    'number.integer': 'Limit must be an integer',
    'number.min': 'Limit must be at least 1',
    'number.max': 'Limit cannot exceed 100'
  })
});

// // body: at least one of name, devices must be present
// export const updateGroupBodySchema = Joi.object({
//   name: Joi.string().trim().min(2).max(100),
//   devices: Joi.array().items(
//     Joi.object({
//       deviceId: Joi.string().trim().required(),
//       channels: Joi.array().items(
//         Joi.object({
//           channelId: Joi.string().trim().required(),
//           channelType: Joi.string().valid('led', 'shade', 'sensor').required(),
//           installed: Joi.boolean().required() // desired target flag
//         })
//       )
//         .min(1)
//         .required()
//     })
//   )
// })
// .or('name', 'devices')
// .messages({
//   'object.missing': 'Provide at least one of name or devices'
// });

// body: at least one of name, devices must be present
export const updateGroupBodySchema = Joi.object({
  name: Joi.string().trim().min(2).max(100),
  devices: Joi.array().items(
    Joi.object({
      deviceId: Joi.string().trim().required(),
      channels: Joi.array().items(
        Joi.object({
          channelId: Joi.string().trim().required(),
          channelType: Joi.string().valid('led', 'shade', 'sensor').required(),

          // these are OPTIONAL now; if provided, they must be true
          checked: Joi.boolean().valid(true).optional(),
          installed: Joi.boolean().valid(true).optional()
        })
      )
        .min(1)
        .required()
    })
  )
})
.or('name', 'devices')
.messages({
  'object.missing': 'Provide at least one of name or devices'
});
