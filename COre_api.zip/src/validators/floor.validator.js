import Joi from 'joi';

// Validation schema for getting all floors query parameters
export const getAllFloorsSchema = Joi.object({
  page: Joi.number()
    .integer()
    .min(1)
    .default(1)
    .messages({
      'number.base': 'Page must be a number',
      'number.integer': 'Page must be an integer',
      'number.min': 'Page must be at least 1'
    }),
  limit: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .default(20)
    .messages({
      'number.base': 'Limit must be a number',
      'number.integer': 'Limit must be an integer',
      'number.min': 'Limit must be at least 1',
      'number.max': 'Limit cannot exceed 100'
    }),
  status: Joi.number()
    .valid(0, 1)
    .optional()
    .messages({
      'any.only': 'Status must be either 0 (inactive) or 1 (active)'
    }),
  campusName: Joi.string()
    .optional()
    .trim()
    .max(100)
    .messages({
      'string.max': 'Campus name cannot exceed 100 characters'
    }),
  buildingName: Joi.string()
    .optional()
    .trim()
    .max(100)
    .messages({
      'string.max': 'Building name cannot exceed 100 characters'
    }),
  floorLevel: Joi.string()
    .optional()
    .trim()
    .max(20)
    .messages({
      'string.max': 'Floor level cannot exceed 20 characters'
    }),
  location: Joi.string()
    .optional()
    .trim()
    .max(200)
    .messages({
      'string.max': 'Location cannot exceed 200 characters'
    }),
  region: Joi.string()
    .optional()
    .trim()
    .max(200)
    .messages({
      'string.max': 'Region cannot exceed 200 characters'
    }),
  search: Joi.string()
    .optional()
    .trim()
    .max(100)
    .messages({
      'string.max': 'Search term cannot exceed 100 characters'
    }),
  sortBy: Joi.string()
    .optional()
    .valid('createdAt', 'name', 'floorLevel', 'status')
    .default('createdAt')
    .messages({
      'any.only': 'Sort by must be one of: createdAt, name, floorLevel, status'
    }),
  sortOrder: Joi.string()
    .optional()
    .valid('asc', 'desc')
    .default('desc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    })
});

// Validation schema for getting floors by building query parameters
export const getFloorsByBuildingSchema = Joi.object({
  page: Joi.number()
    .integer()
    .min(1)
    .default(1)
    .messages({
      'number.base': 'Page must be a number',
      'number.integer': 'Page must be an integer',
      'number.min': 'Page must be at least 1'
    }),
  limit: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .default(20)
    .messages({
      'number.base': 'Limit must be a number',
      'number.integer': 'Limit must be an integer',
      'number.min': 'Limit must be at least 1',
      'number.max': 'Limit cannot exceed 100'
    }),
  status: Joi.number()
    .valid(0, 1)
    .optional()
    .messages({
      'any.only': 'Status must be either 0 (inactive) or 1 (active)'
    }),
  search: Joi.string()
    .optional()
    .trim()
    .max(100)
    .messages({
      'string.max': 'Search term cannot exceed 100 characters'
    }),
  sortBy: Joi.string()
    .optional()
    .valid('floorLevel', 'name', 'createdAt', 'status')
    .default('floorLevel')
    .messages({
      'any.only': 'Sort by must be one of: floorLevel, name, createdAt, status'
    }),
  sortOrder: Joi.string()
    .optional()
    .valid('asc', 'desc')
    .default('asc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    })
});

// Validation schema for adding a floor
export const addFloorSchema = Joi.object({
  name: Joi.string()
    .required()
    .trim()
    .max(100)
    .messages({
      'string.empty': 'Floor name is required',
      'string.max': 'Floor name cannot exceed 100 characters',
      'any.required': 'Floor name is required'
    }),
  status: Joi.alternatives()
    .try(
      Joi.string().valid('active', 'inactive'),
      Joi.number().valid(0, 1)
    )
    .default('active')
    .messages({
      'alternatives.match': 'Status must be one of: active, inactive, 1, 0'
    }),
  floorLevel: Joi.string()
    .required()
    .trim()
    .max(20)
    .messages({
      'string.empty': 'Floor level is required',
      'string.max': 'Floor level cannot exceed 20 characters',
      'any.required': 'Floor level is required'
    }),
  description: Joi.string()
    .optional()
    .allow('', null)
    .trim()
    .max(500)
    .messages({
      'string.max': 'Description cannot exceed 500 characters'
    }),
  floorImage: Joi.string()
    .optional()
    .uri()
    .messages({
      'string.uri': 'Floor image must be a valid URL'
    })
});

// Validation schema for updating a floor
export const updateFloorSchema = Joi.object({
  name: Joi.string()
    .optional()
    .trim()
    .max(100)
    .messages({
      'string.max': 'Floor name cannot exceed 100 characters'
    }),
  status: Joi.alternatives()
    .try(
      Joi.string().valid('active', 'inactive'),
      Joi.number().valid(0, 1)
    )
    .optional()
    .messages({
      'alternatives.match': 'Status must be one of: active, inactive, 1, 0'
    }),
  floorLevel: Joi.string()
    .optional()
    .trim()
    .max(20)
    .messages({
      'string.max': 'Floor level cannot exceed 20 characters'
    }),
  description: Joi.string()
    .optional()
    .allow('', null)
    .trim()
    .max(500)
    .messages({
      'string.max': 'Description cannot exceed 500 characters'
    }),
  floorImage: Joi.string()
    .optional()
    .uri()
    .messages({
      'string.uri': 'Floor image must be a valid URL'
    })
});

// Validation schema for adding a floor using campus name and building name
export const addFloorWithNamesSchema = Joi.object({
  campusName: Joi.string()
    .required()
    .trim()
    .max(100)
    .messages({
      'string.empty': 'Campus name is required',
      'string.max': 'Campus name cannot exceed 100 characters',
      'any.required': 'Campus name is required'
    }),
  buildingName: Joi.string()
    .required()
    .trim()
    .max(100)
    .messages({
      'string.empty': 'Building name is required',
      'string.max': 'Building name cannot exceed 100 characters',
      'any.required': 'Building name is required'
    }),
  floorName: Joi.string()
    .required()
    .trim()
    .max(100)
    .messages({
      'string.empty': 'Floor name is required',
      'string.max': 'Floor name cannot exceed 100 characters',
      'any.required': 'Floor name is required'
    }),
  floorLevel: Joi.string()
    .required()
    .trim()
    .max(20)
    .messages({
      'string.empty': 'Floor level is required',
      'string.max': 'Floor level cannot exceed 20 characters',
      'any.required': 'Floor level is required'
    }),
  status: Joi.alternatives()
    .try(
      Joi.string().valid('active', 'inactive'),
      Joi.number().valid(0, 1)
    )
    .default('active')
    .messages({
      'alternatives.match': 'Status must be one of: active, inactive, 1, 0'
    }),
  description: Joi.string()
    .optional()
    .allow('', null)
    .trim()
    .max(500)
    .messages({
      'string.max': 'Description cannot exceed 500 characters'
    }),
  floorImage: Joi.string()
    .optional()
    .uri()
    .messages({
      'string.uri': 'Floor image must be a valid URL'
    })
});

// Validation schema for updating a floor using campus name and building name
export const updateFloorWithNamesSchema = Joi.object({
  campusName: Joi.string()
    .optional()
    .trim()
    .max(100)
    .messages({
      'string.max': 'Campus name cannot exceed 100 characters'
    }),
  buildingName: Joi.string()
    .optional()
    .trim()
    .max(100)
    .messages({
      'string.max': 'Building name cannot exceed 100 characters'
    }),
  floorName: Joi.string()
    .optional()
    .trim()
    .max(100)
    .messages({
      'string.max': 'Floor name cannot exceed 100 characters'
    }),
  floorLevel: Joi.string()
    .optional()
    .trim()
    .max(20)
    .messages({
      'string.max': 'Floor level cannot exceed 20 characters'
    }),
  zones: Joi.array()
    .items(Joi.string())
    .optional()
    .messages({
      'array.base': 'Zones must be an array of zone names or IDs'
    }),
  status: Joi.number()
    .valid(0, 1) // 0 = inactive, 1 = active
    .optional()
    .messages({
      'any.only': 'Status must be either 0 (inactive) or 1 (active)'
    }),
  description: Joi.string()
    .optional()
    .allow('', null)
    .trim()
    .max(500)
    .messages({
      'string.max': 'Description cannot exceed 500 characters'
    }),
  floorImage: Joi.string()
    .optional()
    .uri()
    .messages({
      'string.uri': 'Floor image must be a valid URL'
    })
}).min(1).messages({
  'object.min': 'At least one field must be provided for update'
});

// Validation schema for changing floor status
export const changeFloorStatusSchema = Joi.object({
  status: Joi.number()
    .valid(0, 1) // 0 = inactive, 1 = active
    .required()
    .messages({
      'any.only': 'Status must be either 0 (inactive) or 1 (active)',
      'any.required': 'Status is required'
    })
});
