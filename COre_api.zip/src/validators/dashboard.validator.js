// Import Joi validation library for schema validation
import Joi from 'joi';

/**
 * Validation schema for dashboard payload
 * Accepts arrays of IDs for filtering dashboard data by campus, building, floor, and zone
 */
export const dashboardPayloadSchema = Joi.object({
  // Array of campus IDs to filter dashboard data
  campus_ids: Joi.array().items(Joi.string().trim()).default([]),
  // Array of building IDs to filter dashboard data
  building_ids: Joi.array().items(Joi.string().trim()).default([]),
  // Array of floor IDs to filter dashboard data
  floor_ids: Joi.array().items(Joi.string().trim()).default([]),
  // Array of zone IDs to filter dashboard data
  zone_ids: Joi.array().items(Joi.string().trim()).default([])
}).required();

/**
 * Validation schema for zone statistics payload
 * Used to get statistical data for specific zones
 */
export const zoneStatsPayloadSchema = Joi.object({
  // Array of zone IDs to get statistics for
  zone_ids: Joi.array().items(Joi.string().trim()).default([])
}).required();

/**
 * Validation schema for device information requests
 * Validates device ID parameter for retrieving device details
 */
export const deviceInfoSchema = Joi.object({
  // Device identifier - required for device operations
  deviceId: Joi.string().trim().required().messages({
    'any.required': 'Device ID is required',
    'string.empty': 'Device ID cannot be empty'
  })
}).required();



/**
 * Validation schema for alerts query parameters
 * Supports filtering alerts by device, date range, and pagination
 */
export const alertsSchema = Joi.object({
  // Pagination: page number for alerts list
  page: Joi.number().integer().min(1).default(1),
  // Filter by device name
  device: Joi.string().trim().allow(''),
  // Filter by device code
  deviceCode: Joi.string().trim().allow(''),
  // Filter by device ID
  deviceID: Joi.string().trim().allow(''),
  // Filter by alert state/status
  state: Joi.string().trim().allow(''),
  // Filter alerts from this start date (ISO format)
  startDate: Joi.string().isoDate().allow(''),
  // Filter alerts until this end date (ISO format)
  endDate: Joi.string().isoDate().allow('')
}).optional();


