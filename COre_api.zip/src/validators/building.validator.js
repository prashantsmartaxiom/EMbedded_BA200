// Import Joi validation library for schema validation
import Joi from 'joi';

/**
 * Validation schema for getting all buildings with query parameters
 * Supports pagination, filtering, searching, and sorting options
 */
export const getAllBuildingsSchema = Joi.object({
  page: Joi.number()
    .integer()
    .min(1)
    .default(1)
    .messages({
      'number.base': 'Page must be a number',
      'number.integer': 'Page must be an integer',
      'number.min': 'Page must be at least 1'
    }),
  limit: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .default(20)
    .messages({
      'number.base': 'Limit must be a number',
      'number.integer': 'Limit must be an integer',
      'number.min': 'Limit must be at least 1',
      'number.max': 'Limit cannot exceed 100'
    }),
  status: Joi.number()
    .valid(0, 1)
    .optional()
    .messages({
      'any.only': 'Status must be either 0 (inactive) or 1 (active)'
    }),
  type: Joi.string()
      .optional(),
  search: Joi.string()
    .optional()
    .trim()
    .max(100)
    .messages({
      'string.max': 'Search term cannot exceed 100 characters'
    }),
  campusId: Joi.string()
    .optional()
    .trim()
    .pattern(/^[0-9a-fA-F]{24}$/)
    .messages({
      'string.pattern.base': 'Campus ID must be a valid ObjectId'
    }),
  sortBy: Joi.string()
    .optional()
    .valid('createdAt', 'name', 'type', 'status')
    .default('createdAt')
    .messages({
      'any.only': 'Sort by must be one of: createdAt, name, type, status'
    }),
  sortOrder: Joi.string()
    .optional()
    .valid('asc', 'desc')
    .default('desc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    })
});

/**
 * Validation schema for getting buildings filtered by campus
 * Similar to getAllBuildingsSchema but specifically for campus-based queries
 */
export const getBuildingsByCampusSchema = Joi.object({
  page: Joi.number()
    .integer()
    .min(1)
    .default(1)
    .messages({
      'number.base': 'Page must be a number',
      'number.integer': 'Page must be an integer',
      'number.min': 'Page must be at least 1'
    }),
  limit: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .default(20)
    .messages({
      'number.base': 'Limit must be a number',
      'number.integer': 'Limit must be an integer',
      'number.min': 'Limit must be at least 1',
      'number.max': 'Limit cannot exceed 100'
    }),
  status: Joi.number()
    .valid(0, 1)
    .optional()
    .messages({
      'any.only': 'Status must be either 0 (inactive) or 1 (active)'
    }),
  type: Joi.string()
      .optional(),
  search: Joi.string()
    .optional()
    .trim()
    .max(100)
    .messages({
      'string.max': 'Search term cannot exceed 100 characters'
    }),
  sortBy: Joi.string()
    .optional()
    .valid('createdAt', 'name', 'type', 'status')
    .default('createdAt')
    .messages({
      'any.only': 'Sort by must be one of: createdAt, name, type, status'
    }),
  sortOrder: Joi.string()
    .optional()
    .valid('asc', 'desc')
    .default('desc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    })
});

/**
 * Validation schema for adding a building using campus name instead of ID
 * Allows creating buildings by referencing campus by name rather than ObjectId
 */
export const addBuildingWithCampusNameSchema = Joi.object({
  // Name of the campus where the building will be located
  campus_name: Joi.string()
    .required()
    .trim()
    .max(100)
    .messages({
      'string.empty': 'Campus name is required',
      'string.max': 'Campus name cannot exceed 100 characters',
      'any.required': 'Campus name is required'
    }),
  // Name of the building to be created
  building_name: Joi.string()
    .required()
    .trim()
    .max(100)
    .messages({
      'string.empty': 'Building name is required',
      'string.max': 'Building name cannot exceed 100 characters',
      'any.required': 'Building name is required'
    }),
  floor_count: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .required()
    .messages({
      'number.base': 'Floor count must be a number',
      'number.integer': 'Floor count must be an integer',
      'number.min': 'Floor count must be at least 1',
      'number.max': 'Floor count cannot exceed 100',
      'any.required': 'Floor count is required'
    }),
  status: Joi.string()
    .valid('active', 'inactive')
    .default('active')
    .messages({
      'any.only': 'Status must be either "active" or "inactive"'
    }),
  type: Joi.string()
      .optional(),
  description: Joi.string()
    .optional()
    .allow('', null)
    .trim()
    .max(500)
    .messages({
      'string.max': 'Description cannot exceed 500 characters'
    }),
  buildingImage: Joi.string()
    .optional()
    .uri()
    .messages({
      'string.uri': 'Building image must be a valid URL'
    })
});

// Validation schema for adding a building
export const addBuildingSchema = Joi.object({
  name: Joi.string()
    .required()
    .trim()
    .max(100)
    .messages({
      'string.empty': 'Building name is required',
      'string.max': 'Building name cannot exceed 100 characters',
      'any.required': 'Building name is required'
    }),
  floorCount: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .optional()
    .messages({
      'number.base': 'Floor count must be a number',
      'number.integer': 'Floor count must be an integer',
      'number.min': 'Floor count must be at least 1',
      'number.max': 'Floor count cannot exceed 100'
    }),
  floor_count: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .optional()
    .messages({
      'number.base': 'Floor count must be a number',
      'number.integer': 'Floor count must be an integer',
      'number.min': 'Floor count must be at least 1',
      'number.max': 'Floor count cannot exceed 100'
    }),
  status: Joi.string()
    .valid('active', 'inactive')
    .default('active')
    .messages({
      'any.only': 'Status must be either "active" or "inactive"'
    }),
  type: Joi.string()
      .optional(),
  description: Joi.string()
    .optional()
    .allow('', null)
    .trim()
    .max(500)
    .messages({
      'string.max': 'Description cannot exceed 500 characters'
    }),
  buildingImage: Joi.string()
    .optional()
    .uri()
    .messages({
      'string.uri': 'Building image must be a valid URL'
    })
});

// Validation schema for updating a building
export const updateBuildingSchema = Joi.object({
  name: Joi.string()
    .optional()
    .trim()
    .max(100)
    .messages({
      'string.max': 'Building name cannot exceed 100 characters'
    }),
  status: Joi.string()
    .optional()
    .valid('active', 'inactive')
    .messages({
      'any.only': 'Status must be either "active" or "inactive"'
    }),
  type: Joi.string()
      .optional(),
  description: Joi.string()
    .optional()
    .allow('', null)
    .trim()
    .max(500)
    .messages({
      'string.max': 'Description cannot exceed 500 characters'
    }),
  buildingImage: Joi.string()
    .optional()
    .uri()
    .messages({
      'string.uri': 'Building image must be a valid URL'
    })
});

// Validation schema for getting active buildings by campus
export const getActiveBuildingsByCampusSchema = Joi.object({
  page: Joi.number()
    .integer()
    .min(1)
    .default(1)
    .messages({
      'number.base': 'Page must be a number',
      'number.integer': 'Page must be an integer',
      'number.min': 'Page must be at least 1'
    }),
  limit: Joi.number()
    .integer()
    .min(1)
    .max(1000)
    .optional()
    .messages({
      'number.base': 'Limit must be a number',
      'number.integer': 'Limit must be an integer',
      'number.min': 'Limit must be at least 1',
      'number.max': 'Limit cannot exceed 1000'
    }),
  type: Joi.string()
      .optional(),
  search: Joi.string()
    .optional()
    .trim()
    .max(100)
    .messages({
      'string.max': 'Search term cannot exceed 100 characters'
    }),
  sortBy: Joi.string()
    .optional()
    .valid('createdAt', 'name', 'type')
    .default('createdAt')
    .messages({
      'any.only': 'Sort by must be one of: createdAt, name, type'
    }),
  sortOrder: Joi.string()
    .optional()
    .valid('asc', 'desc')
    .default('desc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    })
});

// Validation schema for campus ID parameter
export const campusIdParamSchema = Joi.object({
  campusId: Joi.string()
    .required()
    .trim()
    .pattern(/^[0-9a-fA-F]{24}$/)
    .messages({
      'string.pattern.base': 'Campus ID must be a valid MongoDB ObjectId',
      'any.required': 'Campus ID is required'
    })
});

// Validation schema for updating building status
export const updateBuildingStatusSchema = Joi.object({
  status: Joi.number()
    .required()
    .valid(0, 1)
    .messages({
      'number.base': 'Status must be a number',
      'any.only': 'Status must be 0 (inactive) or 1 (active)',
      'any.required': 'Status is required'
    })
});
