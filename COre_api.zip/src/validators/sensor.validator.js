
// Import Joi validation library for schema validation
import Joi from 'joi';

/**
 * Validation schema for creating a new sensor event configuration
 * Defines motion detection rules and associated scene triggers
 */
export const addSensorSchema = Joi.object({
  // Name/description of the sensor event
  sensorEvent: Joi.string().required().trim().min(1).max(255),
  // Device ID associated with the sensor
  device: Joi.string().required().trim().min(1).max(100),
  // Array of sensor IDs that trigger this event
  sensor: Joi.array().items(Joi.string().trim().min(1)).min(1).required(),
  // Scene to execute when motion is detected (ObjectId)
  motionScene: Joi.string().pattern(/^[0-9a-fA-F]{24}$/).required(),
  // Scene to execute when no motion is detected (ObjectId)
  NoMotionScene: Joi.string().pattern(/^[0-9a-fA-F]{24}$/).required(),
  // Duration in seconds before triggering no-motion scene
  Trigger_duration: Joi.number().integer().min(0).required(),
  // Current status of the sensor event (Active/Inactive)
  status: Joi.string().valid('Active', 'Inactive').optional().default('Active')
});

/**
 * Validation schema for listing sensors with filtering and pagination
 * Supports filtering by device, group, sensor name, and general search
 */
export const listSensorsQuerySchema = Joi.object({
  // Pagination parameters
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(10),
  
  // Filter options
  deviceId: Joi.string().trim(), // Filter by specific device
  groupId: Joi.string().hex().length(24), // Filter by group (ObjectId)
  sensorName: Joi.string().trim(), // Filter by sensor name
  
  // General search functionality
  search: Joi.string().trim().allow('') // Search across multiple fields
});

export const sensorParamsSchema = Joi.object({
  id: Joi.string().pattern(/^[0-9a-fA-F]{24}$/).required()
});

/**
 * Validation schema for updating sensor configurations
 * Supports both direct field names and alternative field names for backward compatibility
 * All fields are optional - only provided fields will be updated
 */
export const updateSensorSchema = Joi.object({
  // Direct field names matching the database schema
  sensorEvent: Joi.string().trim().min(1).max(255).optional(), // Sensor event name
  device: Joi.string().trim().min(1).max(100).optional(), // Associated device
  sensor: Joi.array().items(Joi.string().trim().min(1)).min(1).optional(), // Sensor IDs array
  motionScene: Joi.string().pattern(/^[0-9a-fA-F]{24}$/).optional(), // Motion detected scene
  NoMotionScene: Joi.string().pattern(/^[0-9a-fA-F]{24}$/).optional(), // No motion scene
  Trigger_duration: Joi.number().integer().min(0).optional(), // Trigger delay in seconds
  status: Joi.string().valid('Active', 'Inactive').optional(), // Sensor status
  
  // Alternative field names for backward compatibility with older API versions
  sensorName: Joi.string().trim().min(2).max(100).optional(), // Alternative to sensorEvent
  deviceId: Joi.string().trim().optional(), // Alternative to device
  sensorId: Joi.alternatives().try(
    Joi.string().trim(), // Single sensor ID
    Joi.array().items(Joi.string().trim().min(1)).min(1) // Array of sensor IDs
  ).optional(), // Alternative to sensor array
  noMotionScene: Joi.string().pattern(/^[0-9a-fA-F]{24}$/).optional(), // Alternative to NoMotionScene
  triggerMotion: Joi.number().integer().min(0).max(600).optional() // Alternative to Trigger_duration (with max limit)
}).min(1); // At least one field must be provided for update
