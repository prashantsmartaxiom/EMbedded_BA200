// Import Joi validation library for schema validation
import Joi from 'joi';

// Common validation patterns used throughout zone schemas
const objectIdPattern = /^[0-9a-fA-F]{24}$/; // MongoDB ObjectId pattern
const zoneTypes = ['classroom', 'laboratory', 'office', 'meeting-room', 'library', 'cafeteria', 'restroom', 'corridor', 'lobby', 'other']; // Valid zone types
const statusValues = ['active', 'inactive']; // Valid zone status values

// Reusable pagination schema for zone list endpoints
const paginationSchema = {
  // Page number for pagination (starts from 1)
  page: Joi.number()
    .integer()
    .min(1)
    .default(1)
    .messages({
      'number.base': 'Page must be a number',
      'number.integer': 'Page must be an integer',
      'number.min': 'Page must be at least 1'
    }),
  // Number of items per page (max 100 for performance)
  limit: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .default(20)
    .messages({
      'number.base': 'Limit must be a number',
      'number.integer': 'Limit must be an integer',
      'number.min': 'Limit must be at least 1',
      'number.max': 'Limit cannot exceed 100'
    })
};

// Base sorting schema
const sortingSchema = {
  sortBy: Joi.string()
    .optional()
    .valid('createdAt', 'name', 'type', 'status')
    .default('createdAt')
    .messages({
      'any.only': 'Sort by must be one of: createdAt, name, type, status'
    }),
  sortOrder: Joi.string()
    .optional()
    .valid('asc', 'desc')
    .default('desc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    })
};

// Reusable filtering schema for zone queries
const zoneFilterSchema = {
  // Filter by zone status (active/inactive)
  status: Joi.string()
    .optional()
    .valid(...statusValues)
    .messages({
      'any.only': `Status must be one of: ${statusValues.join(', ')}`
    }),
  // Filter by zone type (classroom, office, etc.)
  type: Joi.string()
    .optional()
    .valid(...zoneTypes)
    .messages({
      'any.only': `Type must be one of: ${zoneTypes.join(', ')}`
    }),
  // General search term for zone names and descriptions
  search: Joi.string()
    .optional()
    .trim()
    .max(100)
    .allow('')
    .messages({
      'string.max': 'Search term cannot exceed 100 characters'
    })
};

// =======================
// PARAMETER VALIDATION SCHEMAS
// =======================

// Floor ID parameter validation
export const floorIdParamsSchema = Joi.object({
  floorId: Joi.string()
    .required()
    .trim()
    .pattern(objectIdPattern)
    .messages({
      'string.empty': 'Floor ID is required',
      'string.pattern.base': 'Floor ID must be a valid ObjectId',
      'any.required': 'Floor ID is required'
    })
});

// Zone ID parameter validation
export const zoneIdParamsSchema = Joi.object({
  zoneId: Joi.string()
    .required()
    .trim()
    .pattern(objectIdPattern)
    .messages({
      'string.empty': 'Zone ID is required',
      'string.pattern.base': 'Zone ID must be a valid ObjectId',
      'any.required': 'Zone ID is required'
    })
});

// =======================
// QUERY VALIDATION SCHEMAS
// =======================

// Validation schema for getting zones by floor query parameters
export const getZonesByFloorQuerySchema = Joi.object({
  ...paginationSchema,
  ...zoneFilterSchema,
  ...sortingSchema
});

// Validation schema for zone list query parameters
export const getZoneListQuerySchema = Joi.object({
  ...paginationSchema,
  ...zoneFilterSchema,
  sortBy: Joi.string()
    .optional()
    .valid('createdAt', 'zoneName', 'campusName', 'buildingName', 'floorName')
    .default('createdAt')
    .messages({
      'any.only': 'Sort by must be one of: createdAt, zoneName, campusName, buildingName, floorName'
    }),
  sortOrder: Joi.string()
    .optional()
    .valid('asc', 'desc')
    .default('desc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    }),
  campusId: Joi.string()
    .optional()
    .trim()
    .pattern(objectIdPattern)
    .messages({
      'string.pattern.base': 'Campus ID must be a valid ObjectId'
    }),
  buildingId: Joi.string()
    .optional()
    .trim()
    .pattern(objectIdPattern)
    .messages({
      'string.pattern.base': 'Building ID must be a valid ObjectId'
    }),
  floorId: Joi.string()
    .optional()
    .trim()
    .pattern(objectIdPattern)
    .messages({
      'string.pattern.base': 'Floor ID must be a valid ObjectId'
    })
});

// =======================
// BODY VALIDATION SCHEMAS
// =======================

// Base zone data schema for common fields
const baseZoneSchema = {
  name: Joi.string()
    .trim()
    .min(1)
    .max(100)
    .messages({
      'string.empty': 'Zone name cannot be empty',
      'string.min': 'Zone name must be at least 1 character long',
      'string.max': 'Zone name cannot exceed 100 characters'
    }),
  description: Joi.string()
    .optional()
    .allow('', null)
    .trim()
    .max(500)
    .messages({
      'string.max': 'Description cannot exceed 500 characters'
    }),
  type: Joi.string()
    .valid(...zoneTypes)
    .default('other')
    .messages({
      'any.only': `Type must be one of: ${zoneTypes.join(', ')}`
    }),
  status: Joi.string()
    .valid(...statusValues)
    .default('active')
    .messages({
      'any.only': `Status must be one of: ${statusValues.join(', ')}`
    }),
  zoneImage: Joi.string()
    .optional()
    .uri()
    .allow('')
    .messages({
      'string.uri': 'Zone image must be a valid URL'
    })
};

// Validation schema for adding a zone to a specific floor
export const addZoneBodySchema = Joi.object({
  name: baseZoneSchema.name.required().messages({
    'any.required': 'Zone name is required',
    'string.empty': 'Zone name is required'
  }),
  description: baseZoneSchema.description,
  type: baseZoneSchema.type,
  status: baseZoneSchema.status,
  zoneImage: baseZoneSchema.zoneImage
});

// Validation schema for creating a zone with campus, building, and floor IDs
export const addZoneWithIdsBodySchema = Joi.object({
  floorId: Joi.string()
    .required()
    .trim()
    .pattern(objectIdPattern)
    .messages({
      'string.empty': 'Floor ID is required',
      'string.pattern.base': 'Floor ID must be a valid ObjectId',
      'any.required': 'Floor ID is required'
    }),
  zoneName: baseZoneSchema.name.required().messages({
    'any.required': 'Zone name is required',
    'string.empty': 'Zone name is required'
  }),
  description: baseZoneSchema.description,
  type: baseZoneSchema.type,
  status: baseZoneSchema.status,
  zoneImage: baseZoneSchema.zoneImage
});

// Validation schema for updating a zone
export const updateZoneBodySchema = Joi.object({
  name: baseZoneSchema.name.optional(),
  zoneName: baseZoneSchema.name.optional(),
  description: baseZoneSchema.description,
  zoneDescription: baseZoneSchema.description,
  type: baseZoneSchema.type.optional(),
  status: baseZoneSchema.status.optional(),
  zoneImage: baseZoneSchema.zoneImage
});

// Validation schema for updating zone status
export const updateZoneStatusBodySchema = Joi.object({
  zoneId: Joi.string()
    .required()
    .trim()
    .pattern(objectIdPattern)
    .messages({
      'string.empty': 'Zone ID is required',
      'string.pattern.base': 'Zone ID must be a valid ObjectId',
      'any.required': 'Zone ID is required'
    }),
  status: Joi.alternatives()
    .try(
      Joi.string().valid(...statusValues),
      Joi.number().valid(0, 1)
    )
    .required()
    .messages({
      'any.required': 'Status is required',
      'alternatives.match': 'Status must be "active", "inactive", 0, or 1'
    })
});

// Validation schema for deleting a zone
export const deleteZoneBodySchema = Joi.object({
  zoneId: Joi.string()
    .required()
    .trim()
    .pattern(objectIdPattern)
    .messages({
      'string.empty': 'Zone ID is required',
      'string.pattern.base': 'Zone ID must be a valid ObjectId',
      'any.required': 'Zone ID is required'
    })
});

// =======================
// LEGACY SCHEMA ALIASES (for backward compatibility)
// =======================

// Legacy schema names - keep for backward compatibility
export const getZonesByFloorSchema = getZonesByFloorQuerySchema;
export const addZoneSchema = addZoneBodySchema;
export const addZoneWithIdsSchema = addZoneWithIdsBodySchema;
export const updateZoneSchema = updateZoneBodySchema;
export const updateZoneStatusSchema = updateZoneStatusBodySchema;
export const deleteZoneSchema = deleteZoneBodySchema;
export const getZoneListSchema = getZoneListQuerySchema;
export const getZoneDetailsSchema = zoneIdParamsSchema;

// Validation schema for getting all zones without pagination
export const getAllZonesQuerySchema = Joi.object({
  ...zoneFilterSchema,
  sortBy: Joi.string()
    .optional()
    .valid('name', 'zoneName', 'campusName', 'buildingName', 'floorName', 'createdAt', 'type', 'status')
    .default('name')
    .messages({
      'any.only': 'Sort by must be one of: name, zoneName, campusName, buildingName, floorName, createdAt, type, status'
    }),
  sortOrder: Joi.string()
    .optional()
    .valid('asc', 'desc')
    .default('asc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    }),
  campusId: Joi.string()
    .optional()
    .trim()
    .pattern(objectIdPattern)
    .messages({
      'string.pattern.base': 'Campus ID must be a valid ObjectId'
    }),
  buildingId: Joi.string()
    .optional()
    .trim()
    .pattern(objectIdPattern)
    .messages({
      'string.pattern.base': 'Building ID must be a valid ObjectId'
    }),
  floorId: Joi.string()
    .optional()
    .trim()
    .pattern(objectIdPattern)
    .messages({
      'string.pattern.base': 'Floor ID must be a valid ObjectId'
    })
});