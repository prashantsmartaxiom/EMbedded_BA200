
import Joi from 'joi';

export const addUserSchema = Joi.object({
  fullName: Joi.string().min(2).max(100).required().messages({
    'string.empty': 'Full name is required',
    'string.min': 'Full name must be at least 2 characters long',
    'string.max': 'Full name cannot exceed 100 characters'
  }),
  organization: Joi.string().max(200).optional().messages({
    'string.max': 'Organization cannot exceed 200 characters'
  }),
  location: Joi.string().min(2).max(200).required().messages({
    'string.empty': 'Location is required',
    'string.min': 'Location must be at least 2 characters long',
    'string.max': 'Location cannot exceed 200 characters'
  }),
  contactNumber: Joi.string().pattern(/^[0-9+\-\s()]+$/).min(10).max(15).optional().messages({
    'string.pattern.base': 'Contact number must contain only numbers, +, -, spaces, and parentheses',
    'string.min': 'Contact number must be at least 10 characters long',
    'string.max': 'Contact number cannot exceed 15 characters'
  }),
  email: Joi.string().email().required().messages({
    'string.empty': 'Email is required',
    'string.email': 'Please provide a valid email address'
  }),
  password: Joi.string().min(8).pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).+$/).required().messages({
    'string.empty': 'Password is required',
    'string.min': 'Password must be at least 8 characters long',
    'string.pattern.base': 'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character'
  }),
  confirmPassword: Joi.any().valid(Joi.ref('password')).required().messages({
    'any.only': 'Passwords do not match',
    'any.required': 'Confirm password is required'
  }),
  // Expect role to be a Mongo ObjectId string (24 hex chars)
  role: Joi.string().pattern(/^[a-fA-F0-9]{24}$/).required().messages({
    'string.pattern.base': 'Role must be a valid role id'
  }),
  profileImage: Joi.string().uri().allow('').optional().messages({
    'string.uri': 'profileImage must be a valid URI'
  }),
  assignedTopics: Joi.array().items(Joi.string()).default([]),
  allowedResources: Joi.object({
    campusManagement: Joi.object({
      campuses: Joi.array().items(Joi.string()).default([]),
      buildings: Joi.array().items(Joi.string()).default([]),
      floors: Joi.array().items(Joi.string()).default([]),
      zones: Joi.array().items(Joi.string()).default([])
    }).default(null).allow(null),
    intelligentControl: Joi.object({
      groups: Joi.array().items(Joi.string()).default([]),
      scenes: Joi.array().items(Joi.string()).default([]),
      sensors: Joi.array().items(Joi.string()).default([]),
      templates: Joi.array().items(Joi.string()).default([])
    }).default(null).allow(null),
    deviceManagement: Joi.object({
      devices: Joi.array().items(Joi.string()).default([]),
      configuredDevices: Joi.array().items(Joi.string()).default([]),
      discoveredDevices: Joi.array().items(Joi.string()).default([])
    }).default(null).allow(null),
    logsMonitoring: Joi.object({
      eventLogs: Joi.array().items(Joi.string()).default([]),
      mqttLogs: Joi.array().items(Joi.string()).default([])
    }).default(null).allow(null),
    controlSection: Joi.object({
      filters: Joi.array().items(Joi.string()).default([]),
      templateTab: Joi.array().items(Joi.string()).default([]),
      groupTab: Joi.array().items(Joi.string()).default([]),
      sceneTab: Joi.array().items(Joi.string()).default([]),
      deviceTab: Joi.array().items(Joi.string()).default([])
    }).default(null).allow(null),
    userManagement: Joi.object({
      users: Joi.array().items(Joi.string()).default([]),
      roles: Joi.array().items(Joi.string()).default([])
    }).default(null).allow(null)
  }).default(null).allow(null).optional()
});

export const updateUserSchema = Joi.object({
  fullName: Joi.string().min(2).max(100).optional(),
  email: Joi.string().email().optional(),
  password: Joi.string().min(6).optional(),
  role: Joi.string().pattern(/^[a-fA-F0-9]{24}$/).optional().messages({
    'string.pattern.base': 'Role must be a valid role id'
  }),
  profileImage: Joi.string().optional().allow('', null),
  contactNumber: Joi.string().pattern(/^[0-9+\-\s()]+$/).min(10).max(15).optional().messages({
    'string.pattern.base': 'Contact number must contain only numbers, +, -, spaces, and parentheses',
    'string.min': 'Contact number must be at least 10 characters long',
    'string.max': 'Contact number cannot exceed 15 characters'
  }),
  organization: Joi.string().max(200).optional().messages({
    'string.max': 'Organization cannot exceed 200 characters'
  }),
  allowedResources: Joi.object({
    campusManagement: Joi.object({
      campuses: Joi.array().items(Joi.string()).default([]),
      buildings: Joi.array().items(Joi.string()).default([]),
      floors: Joi.array().items(Joi.string()).default([]),
      zones: Joi.array().items(Joi.string()).default([])
    }).default(null).allow(null),
    intelligentControl: Joi.object({
      groups: Joi.array().items(Joi.string()).default([]),
      scenes: Joi.array().items(Joi.string()).default([]),
      sensors: Joi.array().items(Joi.string()).default([]),
      templates: Joi.array().items(Joi.string()).default([])
    }).default(null).allow(null),
    deviceManagement: Joi.object({
      devices: Joi.array().items(Joi.string()).default([]),
      configuredDevices: Joi.array().items(Joi.string()).default([]),
      discoveredDevices: Joi.array().items(Joi.string()).default([])
    }).default(null).allow(null),
    logsMonitoring: Joi.object({
      eventLogs: Joi.array().items(Joi.string()).default([]),
      mqttLogs: Joi.array().items(Joi.string()).default([])
    }).default(null).allow(null),
    controlSection: Joi.object({
      filters: Joi.array().items(Joi.string()).default([]),
      templateTab: Joi.array().items(Joi.string()).default([]),
      groupTab: Joi.array().items(Joi.string()).default([]),
      sceneTab: Joi.array().items(Joi.string()).default([]),
      deviceTab: Joi.array().items(Joi.string()).default([])
    }).default(null).allow(null),
    userManagement: Joi.object({
      users: Joi.array().items(Joi.string()).default([]),
      roles: Joi.array().items(Joi.string()).default([])
    }).default(null).allow(null)
  }).default(null).allow(null).optional()
}).min(1); // At least one field must be provided

export const userListQuerySchema = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(10),
  search: Joi.string().allow('').max(100),
  campus: Joi.string().allow('').max(100),
  role: Joi.string().allow('').max(100), // Allow role ID or role name
  fullName: Joi.string().allow('').max(100),
  email: Joi.string().allow('').max(100),
  filterRole: Joi.string().allow('').max(100),

  // Accept either "status" (1/0) or "isActive" (true/false) for backwards compatibility.
  // We allow empty string so existing clients can still send search= with no status.
  status: Joi.alternatives().try(
    Joi.string().valid('1', '0', 'true', 'false', '').allow(''),
    Joi.number().valid(1, 0)
  ).default(''),

  isActive: Joi.alternatives().try(
    Joi.string().valid('1', '0', 'true', 'false', '').allow(''),
    Joi.boolean()
  ).default(''),

  sortBy: Joi.string().valid('fullName', 'email', 'createdDate', 'role').default('createdDate'),
  sortOrder: Joi.string().valid('asc', 'desc').default('desc')
}).unknown(false); // disallow unknown fields (optional; remove/change if you rely on unknowns)


export const userIdSchema = Joi.object({
  userId: Joi.string().pattern(/^[0-9a-fA-F]{24}$/).required().messages({
    'string.pattern.base': 'Invalid user ID format',
    'string.empty': 'User ID is required'
  })
});

export const getRolesQuerySchema = Joi.object({
  format: Joi.string().valid('array', 'object').default('array').messages({
    'any.only': 'Format must be either "array" or "object"'
  })
});

export const changeUserStatusSchema = Joi.object({
  isActive: Joi.boolean().required().messages({
    'boolean.base': 'isActive must be a boolean value',
    'any.required': 'isActive field is required'
  })
});

export const tabNamesSchema = Joi.object({
  role_id: Joi.string().pattern(/^[a-fA-F0-9]{24}$/).required().messages({
    'string.pattern.base': 'Role ID must be a valid MongoDB ObjectId',
    'string.empty': 'Role ID is required',
    'any.required': 'Role ID is required'
  })
});

export const accessibleModulesSchema = Joi.object({
  role_id: Joi.string().pattern(/^[a-fA-F0-9]{24}$/).required().messages({
    'string.pattern.base': 'Role ID must be a valid MongoDB ObjectId',
    'string.empty': 'Role ID is required',
    'any.required': 'Role ID is required'
  })
});

export const moduleDataSchema = Joi.object({
  type: Joi.string()
    .valid(
      'campusManagement',
      'IntelligentControl',
      'deviceManagement',
      'userManagement',
      'logsMonitoring',
      'controlSection'
    )
    .optional()
    .messages({
      'any.only':
        'Type must be one of: campusManagement, IntelligentControl, deviceManagement, userManagement, logsMonitoring, controlSection'
    }),

  role_id: Joi.string()
    .pattern(/^[a-fA-F0-9]{24}$/)
    .required()
    .messages({
      'string.pattern.base': 'Role ID must be a valid MongoDB ObjectId',
      'string.empty': 'Role ID is required',
      'any.required': 'Role ID is required'
    })
});

export const campusDataSchema = Joi.object({
  campusData: Joi.array().items(
    Joi.object({
      campus_id: Joi.string().required().messages({
        'string.empty': 'Campus ID is required',
        'any.required': 'Campus ID is required'
      }),
      campus_name: Joi.string().required().messages({
        'string.empty': 'Campus name is required',
        'any.required': 'Campus name is required'
      }),
      buildings: Joi.array().items(
        Joi.object({
          building_id: Joi.string().required().messages({
            'string.empty': 'Building ID is required',
            'any.required': 'Building ID is required'
          }),
          building_name: Joi.string().required().messages({
            'string.empty': 'Building name is required',
            'any.required': 'Building name is required'
          }),
          floors: Joi.array().items(
            Joi.object({
              floor_id: Joi.string().required().messages({
                'string.empty': 'Floor ID is required',
                'any.required': 'Floor ID is required'
              }),
              floor_name: Joi.string().required().messages({
                'string.empty': 'Floor name is required',
                'any.required': 'Floor name is required'
              }),
              zones: Joi.array().items(
                Joi.object({
                  zone_id: Joi.string().required().messages({
                    'string.empty': 'Zone ID is required',
                    'any.required': 'Zone ID is required'
                  }),
                  zone_name: Joi.string().required().messages({
                    'string.empty': 'Zone name is required',
                    'any.required': 'Zone name is required'
                  })
                })
              ).default([])
            })
          ).default([])
        })
      ).default([])
    })
  ).required().messages({
    'any.required': 'Campus data is required',
    'array.base': 'Campus data must be an array'
  })
});

export const userCampusDataSchema = Joi.object({
  userId: Joi.string().pattern(/^[0-9a-fA-F]{24}$/).required().messages({
    'string.pattern.base': 'Invalid user ID format',
    'string.empty': 'User ID is required',
    'any.required': 'User ID is required'
  })
}).concat(campusDataSchema);

export const moduleDataByRoleSchema = Joi.object({
  role_id: Joi.string()
    .pattern(/^[a-fA-F0-9]{24}$/)
    .required()
    .messages({
      'string.pattern.base': 'Role ID must be a valid MongoDB ObjectId',
      'string.empty': 'Role ID is required',
      'any.required': 'Role ID is required'
    }),
  user_id: Joi.string()
    .pattern(/^[a-fA-F0-9]{24}$/)
    .optional()
    .allow('', null)
    .messages({
      'string.pattern.base': 'User ID must be a valid MongoDB ObjectId'
    })
});
