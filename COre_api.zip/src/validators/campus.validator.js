import Joi from 'joi';

// Get All Campuses Query Schema - validation for search and filtering parameters
export const getAllCampusesSchema = Joi.object({
  page: Joi.number()
    .integer()
    .min(1)
    .default(1)
    .messages({
      'number.base': 'Page must be a number',
      'number.integer': 'Page must be an integer',
      'number.min': 'Page must be at least 1'
    }),
  
  limit: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .default(20)
    .messages({
      'number.base': 'Limit must be a number',
      'number.integer': 'Limit must be an integer',
      'number.min': 'Limit must be at least 1',
      'number.max': 'Limit cannot exceed 100'
    }),
  
  search: Joi.string()
    .trim()
    .min(1)
    .max(100)
    .optional()
    .messages({
      'string.min': 'Search term must be at least 1 character long',
      'string.max': 'Search term cannot exceed 100 characters'
    }),
  
  name: Joi.string()
    .trim()
    .min(1)
    .max(100)
    .optional()
    .messages({
      'string.min': 'Campus name search must be at least 1 character long',
      'string.max': 'Campus name search cannot exceed 100 characters'
    }),
  
  location: Joi.string()
    .trim()
    .min(1)
    .max(200)
    .optional()
    .messages({
      'string.min': 'Location search must be at least 1 character long',
      'string.max': 'Location search cannot exceed 200 characters'
    }),
  
  status: Joi.number()
    .valid(0, 1) // 0 = inactive, 1 = active
    .optional()
    .messages({
      'any.only': 'Status must be either 0 (inactive) or 1 (active)'
    }),
  
  type: Joi.string()
    .valid('Residential Apartment', 'Commercial', 'Hotel & Resort')
    .optional()
    .messages({
      'any.only': 'Campus type must be one of: Residential Apartment, Commercial, Hotel & Resort'
    }),
  
  organization: Joi.string()
    .trim()
    .min(1)
    .max(100)
    .optional()
    .messages({
      'string.min': 'Organization search must be at least 1 character long',
      'string.max': 'Organization search cannot exceed 100 characters'
    }),
  
  sortBy: Joi.string()
    .valid('name', 'location', 'createdAt', 'updatedAt', 'status', 'type', 'organization')
    .default('createdAt')
    .messages({
      'any.only': 'Sort field must be one of: name, location, createdAt, updatedAt, status, type, organization'
    }),
  
  sortOrder: Joi.string()
    .valid('asc', 'desc')
    .default('desc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    })
});

// Add Campus Schema - only validation schema available for now
export const addCampusSchema = Joi.object({
  name: Joi.string()
    .trim()
    // .min(2)
    .max(100)
    .required()
    .messages({
      'string.empty': 'Campus name is required',
      // 'string.min': 'Campus name must be at least 2 characters long',
      'string.max': 'Campus name cannot exceed 100 characters',
      'any.required': 'Campus name is required'
    }),
  
  type: Joi.string()
    .valid('Residential Apartment', 'Commercial', 'Hotel & Resort')
    .required()
    .messages({
      'any.only': 'Campus type must be one of: Residential Apartment, Commercial, Hotel & Resort',
      'any.required': 'Campus type is required'
    }),
  
  location: Joi.string()
    .trim()
    .max(200)
    .required()
    .messages({
      'string.empty': 'Campus location is required',
      'string.max': 'Location cannot exceed 200 characters',
      'any.required': 'Campus location is required'
    }),
  
  description: Joi.string()
    .trim()
    .max(500)
    .allow('', null)
    .messages({
      'string.max': 'Description cannot exceed 500 characters'
    }),
  
  campusImage: Joi.string()
    .uri()
    .allow('', null)
    .messages({
      'string.uri': 'Campus image must be a valid URL'
    }),
  
  organization: Joi.string()
    .trim()
    .min(2)
    .max(100)
    .required()
    .messages({
      'string.empty': 'Organization is required',
      'string.min': 'Organization must be at least 2 characters long',
      'string.max': 'Organization cannot exceed 100 characters',
      'any.required': 'Organization is required'
    }),
  
  accessId: Joi.string()
    .trim()
    .min(3)
    .max(50)
    .optional()
    .messages({
      'string.min': 'Access ID must be at least 3 characters long',
      'string.max': 'Access ID cannot exceed 50 characters'
    }),
  
  status: Joi.number()
    .valid(0, 1) // 0 = inactive, 1 = active
    .default(1)
    .messages({
      'any.only': 'Status must be either 0 (inactive) or 1 (active)'
    }),
  
  buildings: Joi.array()
    .items(
      Joi.alternatives().try(
        // Option 1: Building ObjectId (existing functionality)
        Joi.string().pattern(/^[0-9a-fA-F]{24}$/),
        // Option 2: Building object (new functionality)
        Joi.object({
          name: Joi.string()
            .trim()
            .min(2)
            .max(100)
            .required()
            .messages({
              'string.empty': 'Building name is required',
              'string.min': 'Building name must be at least 2 characters long',
              'string.max': 'Building name cannot exceed 100 characters',
              'any.required': 'Building name is required'
            }),
          type: Joi.string()
            .valid('academic', 'administrative', 'residential', 'recreational', 'parking', 'utility', 'other', 'Residential Apartment', 'Commercial', 'Hotel & Resort')
            .optional()
            .messages({
              'any.only': 'Building type must be one of: academic, administrative, residential, recreational, parking, utility, other, Residential Apartment, Commercial, Hotel & Resort'
            }),
          description: Joi.string()
            .trim()
            .max(500)
            .allow('', null)
            .messages({
              'string.max': 'Building description cannot exceed 500 characters'
            }),
          buildingImage: Joi.string()
            .uri()
            .allow('', null)
            .messages({
              'string.uri': 'Building image must be a valid URL'
            }),
          status: Joi.number()
            .valid(0, 1)
            .default(1)
            .messages({
              'any.only': 'Building status must be either 0 (inactive) or 1 (active)'
            }),
          floor_count: Joi.number()
            .integer()
            .min(1)
            .max(100)
            .optional()
            .messages({
              'number.base': 'Floor count must be a number',
              'number.integer': 'Floor count must be an integer',
              'number.min': 'Floor count must be at least 1',
              'number.max': 'Floor count cannot exceed 100'
            })
        })
      )
    )
    .default([])
    .messages({
      'array.base': 'Buildings must be an array'
    })
});

// Update Campus Schema - validation for updating campus data
export const updateCampusSchema = Joi.object({
  name: Joi.string()
    .trim()
    // .min(2)
    .max(100)
    .optional()
    .messages({
      'string.empty': 'Campus name cannot be empty',
      // 'string.min': 'Campus name must be at least 2 characters long',
      'string.max': 'Campus name cannot exceed 100 characters'
    }),
  
  type: Joi.string()
    .valid('Residential Apartment', 'Commercial', 'Hotel & Resort')
    .optional()
    .messages({
      'any.only': 'Campus type must be one of: Residential Apartment, Commercial, Hotel & Resort'
    }),
  
  location: Joi.string()
    .trim()
    .max(200)
    .optional()
    .messages({
      'string.empty': 'Campus location cannot be empty',
      'string.max': 'Location cannot exceed 200 characters'
    }),
  
  description: Joi.string()
    .trim()
    .max(500)
    .allow('', null)
    .optional()
    .messages({
      'string.max': 'Description cannot exceed 500 characters'
    }),
  
  campusImage: Joi.string()
    .uri()
    .allow('', null)
    .optional()
    .messages({
      'string.uri': 'Campus image must be a valid URL'
    }),
  
  organization: Joi.string()
    .trim()
    .min(2)
    .max(100)
    .optional()
    .messages({
      'string.empty': 'Organization cannot be empty',
      'string.min': 'Organization must be at least 2 characters long',
      'string.max': 'Organization cannot exceed 100 characters'
    }),
  
  accessId: Joi.string()
    .trim()
    .min(3)
    .max(50)
    .optional()
    .messages({
      'string.min': 'Access ID must be at least 3 characters long',
      'string.max': 'Access ID cannot exceed 50 characters'
    }),
  
  status: Joi.number()
    .valid(0, 1) // 0 = inactive, 1 = active
    .optional()
    .messages({
      'any.only': 'Status must be either 0 (inactive) or 1 (active)'
    }),
  
  buildings: Joi.array()
    .items(Joi.string().pattern(/^[0-9a-fA-F]{24}$/))
    .optional()
    .messages({
      'array.base': 'Buildings must be an array',
      'string.pattern.base': 'Each building ID must be a valid MongoDB ObjectId'
    })
}).min(1).messages({
  'object.min': 'At least one field must be provided for update'
});

// Update Campus Status Schema - validation for status update only
export const updateCampusStatusSchema = Joi.object({
  status: Joi.number()
    .valid(0, 1)
    .required()
    .messages({
      'any.only': 'Status must be either 0 (inactive) or 1 (active)',
      'any.required': 'Status is required'
    })
});

// Campus View Query Schema - validation for campus view with detailed information
export const getCampusViewSchema = Joi.object({
  page: Joi.number()
    .integer()
    .min(1)
    .default(1)
    .messages({
      'number.base': 'Page must be a number',
      'number.integer': 'Page must be an integer',
      'number.min': 'Page must be at least 1'
    }),
  
  limit: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .default(20)
    .messages({
      'number.base': 'Limit must be a number',
      'number.integer': 'Limit must be an integer',
      'number.min': 'Limit must be at least 1',
      'number.max': 'Limit cannot exceed 100'
    }),
  
  search: Joi.string()
    .trim()
    .min(1)
    .max(100)
    .optional()
    .messages({
      'string.min': 'Search term must be at least 1 character long',
      'string.max': 'Search term cannot exceed 100 characters'
    }),
  
  status: Joi.number()
    .valid(0, 1) // 0 = inactive, 1 = active
    .optional()
    .messages({
      'any.only': 'Status must be either 0 (inactive) or 1 (active)'
    }),
  
  type: Joi.string()
    .valid('Residential Apartment', 'Commercial', 'Hotel & Resort')
    .optional()
    .messages({
      'any.only': 'Campus type must be one of: Residential Apartment, Commercial, Hotel & Resort'
    }),
  
  organization: Joi.string()
    .trim()
    .min(1)
    .max(100)
    .optional()
    .messages({
      'string.min': 'Organization search must be at least 1 character long',
      'string.max': 'Organization search cannot exceed 100 characters'
    }),
  
  sortBy: Joi.string()
    .valid('name', 'location', 'createdAt', 'updatedAt', 'status', 'type', 'organization')
    .default('createdAt')
    .messages({
      'any.only': 'Sort field must be one of: name, location, createdAt, updatedAt, status, type, organization'
    }),
  
  sortOrder: Joi.string()
    .valid('asc', 'desc')
    .default('desc')
    .messages({
      'any.only': 'Sort order must be either asc or desc'
    })
});

// Delete Campus Schema - validation for campus ID parameter
export const deleteCampusSchema = Joi.object({
  campusId: Joi.string()
    .pattern(/^[0-9a-fA-F]{24}$/)
    .required()
    .messages({
      'string.pattern.base': 'Campus ID must be a valid MongoDB ObjectId',
      'any.required': 'Campus ID is required'
    })
});
