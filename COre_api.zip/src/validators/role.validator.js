// Import Joi validation library for schema validation
import Joi from 'joi';

// Predefined access levels for role permissions
const accessLevels = Joi.string().valid('Full Access', 'Read Only', 'Add/Modify');

// Schema for module-level permissions (boolean flags for each access type)
const modulePermissions = Joi.object({
  // Full access permission (create, read, update, delete)
  fullAccess: Joi.boolean().default(false),
  // Read-only permission (view only)
  readOnly: Joi.boolean().default(false),
  // Add/modify permission (create and update, but not delete)
  addModify: Joi.boolean().default(false)
});

// Schema for entity-level permissions (same structure as module permissions)
const entityPermissions = Joi.object({
  // Full access to entity operations
  fullAccess: Joi.boolean().default(false),
  // Read-only access to entities
  readOnly: Joi.boolean().default(false),
  // Add/modify access to entities
  addModify: Joi.boolean().default(false)
});

/**
 * Comprehensive permissions schema defining access levels for all system modules
 * Organized by major functional areas with granular permission control
 */
const permissionsSchema = Joi.object({
  // Campus and property management permissions
  CAMPUS_MANAGEMENT: Joi.object({
    campus_management: modulePermissions,
    building_management: modulePermissions,
    floor_management: modulePermissions,
    zone_management: modulePermissions
  }),
  INTELLIGENT_CONTROL: Joi.object({
    group_management: modulePermissions,
    scene_management: modulePermissions,
    sensor_management: modulePermissions,
    template_management: modulePermissions
  }),
  DEVICE_MANAGEMENT: Joi.object({
    device_control: modulePermissions,
    manage_channels: modulePermissions,
    manage_sensors: modulePermissions
  }),
  USER_MANAGEMENT: Joi.object({
    user_accounts: modulePermissions,
    role_management: modulePermissions
  }),
  LOGS_MONITORING: Joi.object({
    event_logs: modulePermissions,
    mqtt_logs: modulePermissions
  }),
  CONTROL_SECTION: Joi.object({
    filter: modulePermissions,
    template_tab: modulePermissions,
    scene_tab: modulePermissions,
    group_tab: modulePermissions,
    device_tab: modulePermissions,
  })
});

/**
 * Validation schema for creating a new role
 * Requires role name and comprehensive permissions configuration
 */
export const addRoleSchema = Joi.object({
  // Name of the role (must be unique)
  roleName: Joi.string().trim().min(1).max(100).required(),
  // Complete permissions structure for the role
  permissions: permissionsSchema
});



// export const addRoleSchema = Joi.object({
//   roleName: Joi.string().required().trim().min(1).max(100),
//   permissions: Joi.array()
//     .items(
//       Joi.object().pattern(
//         Joi.string(), // Module name
//         Joi.alternatives().try(
//           accessLevels, // direct access string
//           Joi.object().pattern(Joi.string(), accessLevels) // nested entities
//         )
//       )
//     )
//     .required()
// });

export const updateRoleSchema = Joi.object({
  roleName: Joi.string().trim().min(1).max(100).optional(),
  permissions: permissionsSchema.optional()
});

export const getRolesListSchema = Joi.object({
  search: Joi.string().allow('').optional(),
  page: Joi.number().integer().min(1).optional(),
  limit: Joi.number().integer().min(1).optional(),
  status: Joi.string().valid('0', '1').optional(),   // '1' -> active, '0' -> inactive
  sort: Joi.string().valid('asc', 'desc').optional(), // sorting by roleName
  check: Joi.string().valid('0', '1').optional(),    // '1' -> exclude superadmin, '0' -> include all
});

export const getRoleByIdSchema = Joi.object({
  roleId: Joi.string().regex(/^[0-9a-fA-F]{24}$/).required().messages({
    'string.pattern.base': 'Invalid role ID format'
  })
});

// In role.validator.js

// For update we allow partial permissions
const updatePermissionSchema = Joi.object({
  View: Joi.boolean().optional(),
  'Add/Update': Joi.boolean().optional(),
  Delete: Joi.boolean().optional()
});

// export const updateRoleSchema = Joi.object({
//   roleName: Joi.string().trim().min(1).max(100).optional(),
//   permissions: Joi.object({
//     'Property Management': updatePermissionSchema.optional(),
//     'Device Management': updatePermissionSchema.optional(),
//     'User Management': updatePermissionSchema.optional(),
//     'Intelligent Control': updatePermissionSchema.optional(),
//     'Logs Monitoring': updatePermissionSchema.optional(),
//     'Control Section': updatePermissionSchema.optional()
//   }).optional()
// });



