export const emailSubject = {
  EMAIL_VERIFICATION_OTP: 'Password Reset Request - Smart Axiom',
  PASSWORD_CHANGED: 'Password Changed Successfully - Smart Axiom',
  TRACKER_HUMIDITY_ALERT: 'Humidity Alert - Smart Axiom',
  TRACKER_TEMPERATURE_ALERT: 'Temperature Alert - Smart Axiom',
  GEOFENCE_ALERT: 'Geofence Alert - Smart Axiom'
};