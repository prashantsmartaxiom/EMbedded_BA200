import { CampusBuilding } from '../models/CampusBuilding.js';
import { Campus } from '../models/Campus.js';
import Device from '../models/Device.js';
import { CampusFloor } from '../models/CampusFloor.js';
import { CampusZone } from '../models/CampusZone.js';
import { User } from '../models/User.js';

// Get all buildings (across all campuses)
export const getAllBuildings = async (queryParams = {}) => {
  const {
    page = 1,
    limit = 20,
    status,
    type,
    search,
    campusId,
    sortBy = 'createdAt',
    sortOrder = 'desc'
  } = queryParams;

  // Build filter object
  const filter = {};
  
  // Filter out deleted buildings
  filter.isDelete = { $ne: true };
  
  // Show only active buildings by default
  filter.status = 1;
  
  if (status !== undefined) {
    filter.status = parseInt(status);
  }
  
  if (type) {
    filter.type = type;
  }
  
  if (campusId) {
    filter.campusId = campusId;
  }
  
  if (search) {
    filter.$or = [
      { name: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } }
    ];
  }

  // Calculate skip value for pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);

  // Get sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // Execute query with pagination
  let buildings = await CampusBuilding.find(filter)
    .populate('campusId', 'name accessId')
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email')
    .sort(sort)
    .skip(skip)
    .limit(parseInt(limit))
    .lean();

  // Add active floor and zone counts for each building
  for (const building of buildings) {
    // Get active floor count for this building (deleted: false and status: 1)
    const floorCount = await CampusFloor.countDocuments({
      buildingId: building._id,
      deleted: { $ne: true },
      status: 1
    });

    // Get active floor IDs for zone count query
    const activeFloorIds = await CampusFloor.find({
      buildingId: building._id,
      deleted: { $ne: true },
      status: 1
    }).distinct('_id');

    // Get active zone count for all floors in this building (deleted: false and status: 1)
    const zoneCount = activeFloorIds.length > 0 ? await CampusZone.countDocuments({
      floorId: { $in: activeFloorIds },
      deleted: { $ne: true },
      status: 1
    }) : 0;

    // Add counts to building object
    building.floorCount = floorCount;
    building.zoneCount = zoneCount;
  }

  // Get total count for pagination
  const total = await CampusBuilding.countDocuments(filter);

  return {
    buildings,
    pagination: {
      currentPage: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit)),
      totalBuildings: total,
      hasNextPage: skip + buildings.length < total,
      hasPrevPage: parseInt(page) > 1
    }
  };
};

// Get all buildings for a campus
export const getBuildingsByCampus = async (campusId, queryParams = {}) => {
  const {
    page = 1,
    limit = 20,
    status,
    type,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc'
  } = queryParams;

  // Build filter object
  const filter = { campusId };
  
  // Filter out deleted buildings
  filter.isDelete = { $ne: true };
  
  // Show only active buildings by default
  filter.status = 1;
  
  if (status !== undefined) {
    filter.status = parseInt(status);
  }
  
  if (type) {
    filter.type = type;
  }
  
  if (search) {
    filter.$or = [
      { name: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } }
    ];
  }

  // Calculate skip value for pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);

  // Get sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // Execute query with pagination
  let buildings = await CampusBuilding.find(filter)
    .populate('campusId', 'name accessId')
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email')
    .sort(sort)
    .skip(skip)
    .limit(parseInt(limit))
    .lean();

  // Add active floor and zone counts for each building
  for (const building of buildings) {
    // Get active floor count for this building (deleted: false and status: 1)
    const floorCount = await CampusFloor.countDocuments({
      buildingId: building._id,
      deleted: { $ne: true },
      status: 1
    });

    // Get active floor IDs for zone count query
    const activeFloorIds = await CampusFloor.find({
      buildingId: building._id,
      deleted: { $ne: true },
      status: 1
    }).distinct('_id');

    // Get active zone count for all floors in this building (deleted: false and status: 1)
    const zoneCount = activeFloorIds.length > 0 ? await CampusZone.countDocuments({
      floorId: { $in: activeFloorIds },
      deleted: { $ne: true },
      status: 1
    }) : 0;

    // Add counts to building object
    building.floorCount = floorCount;
    building.zoneCount = zoneCount;
  }

  // Get total count for pagination
  const total = await CampusBuilding.countDocuments(filter);

  return {
    buildings,
    pagination: {
      currentPage: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit)),
      totalBuildings: total,
      hasNextPage: skip + buildings.length < total,
      hasPrevPage: parseInt(page) > 1
    }
  };
};

// Create building with automatic floor generation and user access setup
// - Validates campus existence and building name uniqueness
// - Auto-creates floors based on floorCount parameter
// - Updates admin users' allowedResources for immediate access
export const addBuilding = async (buildingData, user) => {
  // Verify campus exists
  const campus = await Campus.findById(buildingData.campusId);
  if (!campus) {
    throw new Error('Campus not found');
  }

  // Check if building with same name already exists in this campus
  const existingBuilding = await CampusBuilding.findOne({ 
    name: buildingData.name, 
    campusId: buildingData.campusId 
  });
  if (existingBuilding) {
    throw new Error('Building with this name already exists in the campus');
  }

  // Extract floorCount from buildingData (support both floorCount and floor_count)
  const { floorCount, floor_count, status, ...buildingInfo } = buildingData;
  
  // Set building type to match campus type
  buildingInfo.type = campus.type || '';
  const actualFloorCount = floorCount || floor_count;

  // Convert string status to numeric status
  let numericStatus = 1; // default to active (1)
  if (status) {
    switch (status.toLowerCase()) {
      case 'active':
        numericStatus = 1;
        break;
      case 'inactive':
        numericStatus = 0;
        break;
      default:
        throw new Error('Invalid status. Status must be "active" or "inactive"');
    }
  }

  // Create building with user information
  const building = new CampusBuilding({
    ...buildingInfo,
    status: numericStatus,
    floor_count: actualFloorCount, // Save floor_count to the database
    createdBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    },
    updatedBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    }
  });

  await building.save();

  // Create floors if actualFloorCount is provided
  const floorIds = [];
  if (actualFloorCount && actualFloorCount > 0) {
    for (let i = 1; i <= actualFloorCount; i++) {
      const floor = new CampusFloor({
        name: `Floor ${i}`,
        floorLevel: i.toString(),
        buildingId: building._id,
        createdBy: {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        },
        updatedBy: {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        }
      });
      
      await floor.save();
      floorIds.push(floor._id);
    }

    // Update building with floor IDs
    building.floors = floorIds;
    await building.save();
  }

  // Add building to campus buildings array
  await Campus.findByIdAndUpdate(
    buildingData.campusId,
    { $push: { buildings: building._id } },
    { new: true }
  );

  await building.populate([
    { path: 'campusId', select: 'name accessId' },
    { path: 'createdBy.userId', select: 'fullName email' },
    { path: 'floors', select: 'name floorLevel status' }
  ]);

  // --- Add building._id and floorIds to allowedResources.campusManagement for all admin users ---
  const { default: Role } = await import('../models/Role.js');
  const { User } = await import('../models/User.js');
  const adminRole = await Role.findOne({ roleName: { $regex: /^admin$/i }, byDefault: "true" });
  if (adminRole) {
    const adminUsers = await User.find({ role_id: adminRole._id });
    for (const adminUser of adminUsers) {
      if (!adminUser.allowedResources) adminUser.allowedResources = { campusManagement: { buildings: [], floors: [] } };
      if (!adminUser.allowedResources.campusManagement) adminUser.allowedResources.campusManagement = { buildings: [], floors: [] };
      if (!Array.isArray(adminUser.allowedResources.campusManagement.buildings)) {
        adminUser.allowedResources.campusManagement.buildings = [];
      }
      if (!Array.isArray(adminUser.allowedResources.campusManagement.floors)) {
        adminUser.allowedResources.campusManagement.floors = [];
      }
      // Add building ID
      if (!adminUser.allowedResources.campusManagement.buildings.includes(building._id.toString())) {
        adminUser.allowedResources.campusManagement.buildings.push(building._id.toString());
      }
      // Add floor IDs
      if (floorIds && floorIds.length > 0) {
        for (const fId of floorIds) {
          const fIdStr = fId.toString();
          if (!adminUser.allowedResources.campusManagement.floors.includes(fIdStr)) {
            adminUser.allowedResources.campusManagement.floors.push(fIdStr);
          }
        }
      }
      await adminUser.save();
    }
  }

  // --- Also append this building (and created floors) into the requesting user's campusData for that campus ---
  try {
    // Determine campus doc and name for fallback matching
    const campusDoc = await Campus.findById(buildingData.campusId).select('name');

    // Build floors payload for user's campusData (if any floors were created)
    let floorsForUser = [];
    if (floorIds && floorIds.length > 0) {
      const floors = await CampusFloor.find({ _id: { $in: floorIds } }).select('name');
      floorsForUser = floors.map(f => ({
        floor_id: f._id.toString(),
        floor_name: f.name,
        zones: []
      }));
    }

    const byCampusIdResult = await User.updateOne(
      { _id: user._id, 'campusData.campus_id': buildingData.campusId.toString() },
      {
        $push: {
          'campusData.$.buildings': {
            building_id: building._id.toString(),
            building_name: building.name,
            floors: floorsForUser
          }
        },
        $set: {
          updatedBy: {
            userId: user._id,
            fullName: user.fullName,
            email: user.email
          },
          updatedDate: new Date().toISOString()
        }
      }
    );

    if (!byCampusIdResult || (byCampusIdResult.modifiedCount === 0 && byCampusIdResult.matchedCount === 0)) {
      if (campusDoc?.name) {
        await User.updateOne(
          { _id: user._id, 'campusData.campus_name': { $regex: new RegExp(`^${campusDoc.name}$`, 'i') } },
          {
            $push: {
              'campusData.$.buildings': {
                building_id: building._id.toString(),
                building_name: building.name,
                floors: floorsForUser
              }
            },
            $set: {
              updatedBy: {
                userId: user._id,
                fullName: user.fullName,
                email: user.email
              },
              updatedDate: new Date().toISOString()
            }
          }
        );
      }
    }
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error('Failed to update requesting user campusData with new building:', e);
  }

  return building;
};

// Get building by ID
export const getBuildingById = async (buildingId) => {
  // Get building with campus info (both active and inactive)
  const building = await CampusBuilding.findOne({
    _id: buildingId
  })
    .populate('campusId', 'name accessId type')
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email')
    .lean();

  if (!building) {
    throw new Error('Building not found');
  }

  // Get all non-deleted floors for this building (both active and inactive)
  const floors = await CampusFloor.find({
    buildingId: building._id,
    $or: [
      { deleted: { $exists: false } },
      { deleted: false },
      { deleted: { $ne: true } }
    ]
  }).lean();

  building.floorCount = floors.length;
  building.floors = [];
  let totalZoneCount = 0;

  for (const floor of floors) {
    // Get all non-deleted zones for this floor (both active and inactive)
    const zones = await CampusZone.find({
      floorId: floor._id,
      $or: [
        { isDelete: { $exists: false } },
        { isDelete: false },
        { isDelete: { $ne: true } }
      ]
    }).lean();

    totalZoneCount += zones.length;

    // For each zone, get count of configured devices (configure_flag: true)
    for (const zone of zones) {
      const configuredDeviceCount = await Device.countDocuments({
        zone: zone._id,
        configure_flag: true,
        is_delete: { $ne: true }
      });
      zone.configuredDeviceCount = configuredDeviceCount;
    }

    // Attach zones to floor
    floor.zones = zones;
    floor.zoneCount = zones.length;
    // Optionally, you can add floor's configured device count as sum of all zones
    floor.configuredDeviceCount = zones.reduce((sum, z) => sum + (z.configuredDeviceCount || 0), 0);

    building.floors.push(floor);
  }

  building.zoneCount = totalZoneCount;

  return building;
};

// Update/Edit building by ID
export const updateBuildingById = async (buildingId, updateData, user) => {
  // Check if building exists (both active and inactive)
  const existingBuilding = await CampusBuilding.findOne({ 
    _id: buildingId
  });
  
  if (!existingBuilding) {
    throw new Error('Building not found');
  }

  // If name is being updated, check for duplicates in the same campus
  if (updateData.name && updateData.name !== existingBuilding.name) {
    const duplicateBuilding = await CampusBuilding.findOne({
      name: updateData.name,
      campusId: existingBuilding.campusId,
      _id: { $ne: buildingId }, // Exclude current building
      isDelete: { $ne: true } // Only check non-deleted buildings
    });

    if (duplicateBuilding) {
      throw new Error('Building with this name already exists in the campus');
    }
  }

  // Prepare update data with user information
  // Handle status conversion if status is provided
  const processedUpdateData = { ...updateData };
  if (updateData.status && typeof updateData.status === 'string') {
    switch (updateData.status.toLowerCase()) {
      case 'active':
        processedUpdateData.status = 1;
        break;
      case 'inactive':
        processedUpdateData.status = 0;
        break;
      default:
        throw new Error('Invalid status. Status must be "active" or "inactive"');
    }
  }

  const updatePayload = {
    ...processedUpdateData,
    updatedBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    },
    updatedAt: new Date()
  };

  // Update the building
  const updatedBuilding = await CampusBuilding.findByIdAndUpdate(
    buildingId,
    updatePayload,
    { 
      new: true, // Return updated document
      runValidators: true // Run schema validators
    }
  ).populate([
    { path: 'campusId', select: 'name accessId' },
    { path: 'floors', select: 'name floorLevel status' },
    { path: 'createdBy.userId', select: 'fullName email' },
    { path: 'updatedBy.userId', select: 'fullName email' }
  ]);

  return updatedBuilding;
};

// Update building status by ID
export const updateBuildingStatus = async (buildingId, status, user) => {
  // Check if building exists
  const existingBuilding = await CampusBuilding.findById(buildingId);
  
  if (!existingBuilding) {
    throw new Error('Building not found');
  }

  // Validate status value
  const validStatuses = [0, 1]; // 0 = inactive, 1 = active
  if (!validStatuses.includes(status)) {
    throw new Error('Invalid status. Status must be 0 (inactive) or 1 (active)');
  }

  // Prepare update data with user information
  const updatePayload = {
    status: status,
    updatedBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    },
    updatedAt: new Date()
  };

  // Update the building status
  const updatedBuilding = await CampusBuilding.findByIdAndUpdate(
    buildingId,
    updatePayload,
    { 
      new: true, // Return updated document
      runValidators: true // Run schema validators
    }
  ).populate([
    { path: 'campusId', select: 'name accessId' },
    { path: 'floors', select: 'name floorLevel status' },
    { path: 'createdBy.userId', select: 'fullName email' },
    { path: 'updatedBy.userId', select: 'fullName email' }
  ]);

  return updatedBuilding;
};

// Delete building with complete cascade cleanup and device state management
// - Moves devices to 'Discovered' state (preserves hardware for reconfiguration)
// - Permanently deletes floors, zones, groups, scenes, sensors, templates
// - Removes devices from all intelligent control collections
export const softDeleteBuilding = async (buildingId, user) => {
  if (!buildingId.match(/^[0-9a-fA-F]{24}$/)) {
    throw new Error('Invalid building ID format');
  }

  const existingBuilding = await CampusBuilding.findOne({ 
    _id: buildingId,
    isDelete: { $ne: true }
  });
  
  if (!existingBuilding) {
    throw new Error('Building not found or already deleted');
  }

  // Import required models and functions
  const Device = (await import('../models/Device.js')).default;
  const { removeDeviceFromRelatedCollections } = await import('./device.service.js');

  // Get all floors and zones under this building
  const floors = await CampusFloor.find({ buildingId });
  const floorIds = floors.map(f => f._id);
  
  const zones = floorIds.length > 0 ? await CampusZone.find({ floorId: { $in: floorIds } }) : [];
  const zoneIds = zones.map(z => z._id);

  // Get devices in building and move them to 'Discovered' state
  const devices = await Device.find({ building: buildingId }).select('device_id');
  
  // Update devices to 'Discovered' state (same as device deletion)
  await Device.updateMany(
    { building: buildingId },
    { 
      is_delete: false,
      configure_flag: false
    }
  );

  // Remove each device from related collections (same as device deletion)
  for (const device of devices) {
    await removeDeviceFromRelatedCollections(device.device_id, user);
  }

  // Delete zones and floors
  if (zoneIds.length > 0) {
    await CampusZone.deleteMany({ _id: { $in: zoneIds } });
  }
  if (floorIds.length > 0) {
    await CampusFloor.deleteMany({ _id: { $in: floorIds } });
  }

  // Delete building
  await CampusBuilding.deleteOne({ _id: buildingId });

  return {
    success: true,
    message: 'Building deleted successfully. All devices moved to Discovered state and intelligent control data permanently deleted.',
    building: { _id: buildingId },
    deletedCounts: {
      floors: floorIds.length,
      zones: zoneIds.length,
      devicesMovedToDiscovered: devices.length
    }
  };
};

// Get all active buildings for a specific campus (status = 1 only)
export const getActiveBuildingsByCampus = async (campusId, queryParams = {}) => {
  // First verify that the campus exists and is active
  const campus = await Campus.findOne({ _id: campusId, status: 1 });
  if (!campus) {
    throw new Error('Campus not found or inactive');
  }

  const {
    page = 1,
    limit,
    type,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc'
  } = queryParams;

  // Build filter object - always filter for active buildings only
  const filter = { 
    campusId,
    status: 1  // Only active buildings
  };
  
  if (type) {
    filter.type = type;
  }
  
  if (search) {
    filter.$or = [
      { name: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } }
    ];
  }

  // Get sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  let query = CampusBuilding.find(filter)
    .select('name type description buildingImage createdAt updatedAt floors')
    .populate('campusId', 'name accessId location')
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email')
    .sort(sort);

  // Apply pagination only if limit is provided
  if (limit && limit > 0) {
    const skip = (parseInt(page) - 1) * parseInt(limit);
    query = query.skip(skip).limit(parseInt(limit));
  }

  // Execute query
  const buildings = await query.lean();

  // Get total count for pagination info
  const total = await CampusBuilding.countDocuments(filter);

  // Add active floor and zone counts for each building
  for (const building of buildings) {
    // Get active floor count for this building (deleted: false and status: 1)
    const floorCount = await CampusFloor.countDocuments({
      buildingId: building._id,
      deleted: { $ne: true },
      status: 1
    });

    // Get active floor IDs for zone count query
    const activeFloorIds = await CampusFloor.find({
      buildingId: building._id,
      deleted: { $ne: true },
      status: 1
    }).distinct('_id');

    // Get active zone count for all floors in this building (deleted: false and status: 1)
    const zoneCount = activeFloorIds.length > 0 ? await CampusZone.countDocuments({
      floorId: { $in: activeFloorIds },
      deleted: { $ne: true },
      status: 1
    }) : 0;

    // Add counts to building object
    building.floorCount = floorCount;
    building.zoneCount = zoneCount;
  }

  // Prepare pagination object
  let pagination = null;
  if (limit && limit > 0) {
    const skip = (parseInt(page) - 1) * parseInt(limit);
    pagination = {
      currentPage: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit)),
      totalActiveBuildings: total,
      hasNextPage: skip + buildings.length < total,
      hasPrevPage: parseInt(page) > 1
    };
  } else {
    pagination = {
      totalActiveBuildings: total,
      returnedBuildings: buildings.length,
      allResultsReturned: true
    };
  }

  return {
    activeBuildings: buildings,
    campusInfo: {
      id: campus._id,
      name: campus.name,
      accessId: campus.accessId,
      location: campus.location,
      type: campus.type
    },
    pagination,
    searchInfo: {
      searchTerm: search || null,
      typeFilter: type || null,
      resultsFound: buildings.length,
      totalMatches: total
    }
  };
};

// Create building using campus name resolution (flexible API endpoint)
// - Case-insensitive campus name lookup for external integrations
// - Validates building name uniqueness within resolved campus
export const addBuildingWithCampusName = async (buildingData, user) => {
  const { campus_name, building_name, floor_count, status, ...otherData } = buildingData;
  
  // Convert string status to numeric status
  let numericStatus = 1; // default to active (1)
  if (status) {
    switch (status.toLowerCase()) {
      case 'active':
        numericStatus = 1;
        break;
      case 'inactive':
        numericStatus = 0;
        break;
      default:
        throw new Error('Invalid status. Status must be "active" or "inactive"');
    }
  }
  
  // Find campus by name
  const campus = await Campus.findOne({ 
    name: { $regex: new RegExp(`^${campus_name}$`, 'i') }, // Case-insensitive exact match
    status: 1 // Only active campuses
  });
  
  if (!campus) {
    throw new Error(`Campus with name "${campus_name}" not found or is inactive`);
  }

  // Check if building with same name already exists in this campus
  const existingBuilding = await CampusBuilding.findOne({ 
    name: { $regex: new RegExp(`^${building_name}$`, 'i') }, // Case-insensitive exact match
    campusId: campus._id,
    status: 1 // Only check active buildings
  });
  
  if (existingBuilding) {
    throw new Error(`Building with name "${building_name}" already exists in campus "${campus_name}"`);
  }

  // Prepare building data with campus ID and building name
  const buildingInfo = {
    ...otherData,
    campusId: campus._id,
    name: building_name
  };

  // Create building with user information
  const building = new CampusBuilding({
    ...buildingInfo,
    status: numericStatus,
    floor_count: floor_count,
    createdBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    },
    updatedBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    }
  });

  await building.save();

  // Create floors if floor_count is provided
  const floorIds = [];
  if (floor_count && floor_count > 0) {
    for (let i = 1; i <= floor_count; i++) {
      const floor = new CampusFloor({
        name: `Floor ${i}`,
        floorLevel: i.toString(),
        buildingId: building._id,
        createdBy: {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        },
        updatedBy: {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        }
      });
      
      await floor.save();
      floorIds.push(floor._id);
    }

    // Update building with floor IDs
    building.floors = floorIds;
    await building.save();
  }

  // Add building to campus buildings array
  await Campus.findByIdAndUpdate(
    campus._id,
    { $push: { buildings: building._id } },
    { new: true }
  );

  // If the campus is already present in the requesting user's campusData, add this building under that campus
  try {
    // Build floors payload for user's campusData (if any floors were created)
    let floorsForUser = [];
    if (floorIds.length > 0) {
      const floors = await CampusFloor.find({ _id: { $in: floorIds } }).select('name');
      floorsForUser = floors.map(f => ({
        floor_id: f._id.toString(),
        floor_name: f.name,
        zones: []
      }));
    }

    const byIdResult = await User.updateOne(
      { _id: user._id, 'campusData.campus_id': campus._id.toString() },
      {
        $push: {
          'campusData.$.buildings': {
            building_id: building._id.toString(),
            building_name: building.name,
            floors: floorsForUser
          }
        },
        $set: {
          updatedBy: {
            userId: user._id,
            fullName: user.fullName,
            email: user.email
          },
          updatedDate: new Date().toISOString()
        }
      }
    );

    // If not modified (no campus matched by id), try matching by campus_name
    if (!byIdResult || (byIdResult.modifiedCount === 0 && byIdResult.matchedCount === 0)) {
      await User.updateOne(
        { _id: user._id, 'campusData.campus_name': { $regex: new RegExp(`^${campus.name}$`, 'i') } },
        {
          $push: {
            'campusData.$.buildings': {
              building_id: building._id.toString(),
              building_name: building.name,
              floors: floorsForUser
            }
          },
          $set: {
            updatedBy: {
              userId: user._id,
              fullName: user.fullName,
              email: user.email
            },
            updatedDate: new Date().toISOString()
          }
        }
      );
    }
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error('Failed to update user campusData with new building:', e);
  }

  await building.populate([
    { path: 'campusId', select: 'name accessId' },
    { path: 'createdBy.userId', select: 'fullName email' },
    { path: 'floors', select: 'name floorLevel status' }
  ]);
  
  return building;
};
