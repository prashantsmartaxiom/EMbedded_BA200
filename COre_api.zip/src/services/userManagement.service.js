/**
 * User Management Service - Data Access & Business Logic Layer
 * 
 * Flow: routes → controller → SERVICE → database
 * 
 * Core Responsibilities:
 * - User CRUD operations with role/permission management
 * - Role-based access control (RBAC) implementation
 * - Permission matrix calculations
 * - Module data filtering based on permissions
 * - Profile image processing and storage
 * - Campus/location assignment logic
 * - Audit logging data aggregation
 * 
 * Key Features:
 * - Advanced user filtering with permission scopes
 * - Selective resource updating (preserves unchanged sections)
 * - Real-time logs integration
 * - Image upload/filesystem management
 * - Complex permission inheritance and checks
 * - Multi-module resource management
 */

/**
 * Get real-time logs data for specific user
 * Combines event logs and MQTT message logs
 */
export const getLogsMonitoringDataForUser = async (userId) => {
  // Get user to access email and allowedResources
  const user = await User.findById(userId).lean();
  // Get event logs for this user
  const eventLogs = await Log.find({ userId })
    .select('_id level message meta userId createdAt')
    .sort({ createdAt: -1 })
    .limit(1000)
    .lean();

  const transformedEventLogs = eventLogs.map(log => ({
    _id: log._id,
    level: log.level,
    message: log.message,
    meta: log.meta,
    userId: log.userId,
    timestamp: log.createdAt
  }));

  // Message collection does not have userId, so filter by topic/email if possible, else return all
  let mqttLogs = [];
  if (user && user.email) {
    mqttLogs = await Message.find({ 'message.topic': { $regex: user.email, $options: 'i' } })
      .select('_id id message.topic message.payload status createdAt')
      .sort({ createdAt: -1 })
      .limit(1000)
      .lean();
    if (!mqttLogs.length) {
      mqttLogs = await Message.find({})
        .select('_id id message.topic message.payload status createdAt')
        .sort({ createdAt: -1 })
        .limit(1000)
        .lean();
    }
  } else {
    mqttLogs = await Message.find({})
      .select('_id id message.topic message.payload status createdAt')
      .sort({ createdAt: -1 })
      .limit(1000)
      .lean();
  }

  const transformedMqttLogs = mqttLogs.map(log => ({
    id: log._id,
    device_id: log.id,
    topic: log.message?.topic || '',
    payload: log.message?.payload || '',
    status: log.status || 1,
    createdAt: log.createdAt
  }));

  // If no event logs, return allowedResources.logsMonitoring as fallback (booleans)
  if (!transformedEventLogs.length && user && user.allowedResources && user.allowedResources.logsMonitoring) {
    return user.allowedResources.logsMonitoring;
  }

  return {
    eventLogs: transformedEventLogs,
    mqttLogs: transformedMqttLogs
  };
};
import { User } from '../models/User.js';
import { UserAuth } from '../models/UserAuth.js';
import { createUserAuthData } from '../utils/userAuth.js';
import bcrypt from 'bcryptjs';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import mongoose from 'mongoose';
import Role from '../models/Role.js';
import { Campus } from '../models/Campus.js';
import { CampusBuilding } from '../models/CampusBuilding.js';
import { CampusFloor } from '../models/CampusFloor.js';
import { CampusZone } from '../models/CampusZone.js';
import { Group } from '../models/Group.js';
import { Scene } from '../models/Scene.js';
import { Sensor } from '../models/Sensor.js';
import { Template } from '../models/Template.js';
import Device from '../models/Device.js';
import Message from '../models/Message.js'; 
import Log from '../models/Log.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ========== PERMISSION SYSTEM UTILITIES ==========
// Helper functions for role-based access control (RBAC)

/**
 * Check if role has view permission for specific feature
 * Used to determine UI visibility and data access
 */
const hasViewPermission = (permissions, moduleType, feature) => {
  try {
    if (!permissions || !moduleType || !feature) {
      return false;
    }

    const modulePermissions = permissions[moduleType];
    if (!modulePermissions) {
      return false;
    }

    const featurePermissions = modulePermissions[feature];
    if (!featurePermissions) {
      return false;
    }

    return featurePermissions.View === true;
  } catch (error) {
    console.error('Error checking view permission:', error);
    return false;
  }
};

/**
 * Check if a role has any view permissions for a module type
 * @param {Object} permissions - Role permissions object
 * @param {string} moduleType - Module type (e.g., 'CAMPUS_MANAGEMENT', 'INTELLIGENT_CONTROL')
 * @returns {boolean} - True if has any view permission in the module, false otherwise
 */
const hasAnyViewPermissionInModule = (permissions, moduleType) => {
  try {
    if (!permissions || !moduleType) {
      return false;
    }

    const modulePermissions = permissions[moduleType];
    if (!modulePermissions) {
      return false;
    }

    // Check if any feature in the module has View permission
    for (const feature in modulePermissions) {
      if (modulePermissions[feature] && modulePermissions[feature].View === true) {
        return true;
      }
    }

    return false;
  } catch (error) {
    console.error('Error checking module view permissions:', error);
    return false;
  }
};

/**
 * Get allowed features for a module based on view permissions
 * @param {Object} permissions - Role permissions object
 * @param {string} moduleType - Module type (e.g., 'CAMPUS_MANAGEMENT', 'INTELLIGENT_CONTROL')
 * @returns {Array} - Array of feature names that have view permission
 */
const getAllowedFeaturesInModule = (permissions, moduleType) => {
  try {
    if (!permissions || !moduleType) {
      return [];
    }

    const modulePermissions = permissions[moduleType];
    if (!modulePermissions) {
      return [];
    }

    const allowedFeatures = [];
    for (const feature in modulePermissions) {
      if (modulePermissions[feature] && modulePermissions[feature].View === true) {
        allowedFeatures.push(feature);
      }
    }

    return allowedFeatures;
  } catch (error) {
    console.error('Error getting allowed features:', error);
    return [];
  }
};

// ========== MODULE & PERMISSION MAPPINGS ==========

/**
 * Maps API module names to internal permission keys
 * Ensures consistent permission checking across the system
 */
const MODULE_TYPE_MAPPING = {
  'campusManagement': 'CAMPUS_MANAGEMENT',
  'intelligentControl': 'INTELLIGENT_CONTROL',
  'deviceManagement': 'DEVICE_MANAGEMENT',
  'userManagement': 'USER_MANAGEMENT',
  'logsMonitoring': 'LOGS_MONITORING',
  'controlSection': 'CONTROL_SECTION'
};

/**
 * Maps permission modules to UI tab information
 * Used for dynamic navigation generation
 */
const MODULE_TO_TAB_MAPPING = {
  'CAMPUS_MANAGEMENT': { id: 'campusManagement', label: 'Campus Management' },
  'INTELLIGENT_CONTROL': { id: 'intelligentControl', label: 'Intelligent Control' },
  'DEVICE_MANAGEMENT': { id: 'deviceManagement', label: 'Device Management' },
  'USER_MANAGEMENT': { id: 'userManagement', label: 'User Management' },
  'LOGS_MONITORING': { id: 'logsMonitoring', label: 'Logs Monitoring' },
  'CONTROL_SECTION': { id: 'controlSection', label: 'Control Section' }
};

/**
 * Get permission module key from API module type
 * @param {string} apiModuleType - API module type
 * @returns {string} - Permission module key
 */
const getPermissionModuleKey = (apiModuleType) => {
  return MODULE_TYPE_MAPPING[apiModuleType] || null;
};

/**
 * Generate module tabs based on user permissions
 * @param {Object} permissions - Role permissions object
 * @returns {Array} - Array of module tab objects with id and label
 */
const generateModuleTabsFromPermissions = (permissions) => {
  try {
    if (!permissions) {
      return [];
    }

    const tabs = [];

    // Check each module for any view permissions
    Object.keys(MODULE_TO_TAB_MAPPING).forEach(moduleType => {
      if (hasAnyViewPermissionInModule(permissions, moduleType)) {
        tabs.push(MODULE_TO_TAB_MAPPING[moduleType]);
      }
    });

    return tabs;
  } catch (error) {
    console.error('Error generating module tabs from permissions:', error);
    return [];
  }
};

/**
 * Save base64 image to file system
 */
const saveProfileImage = async (base64Image, userId) => {
  if (!base64Image) return '';

  try {
    // Extract the image data and format
    const matches = base64Image.match(/^data:image\/([a-zA-Z]+);base64,(.+)$/);
    if (!matches) {
      throw new Error('Invalid base64 image format');
    }

    const imageFormat = matches[1];
    const imageData = matches[2];

    // Create public/images/users directory if it doesn't exist
    const imagesDir = path.join(__dirname, '../../public/images/users');
    await fs.mkdir(imagesDir, { recursive: true });

  // Use userId as filename
  const filename = `${userId}.${imageFormat}`;
  const filepath = path.join(imagesDir, filename);

  // Save the image
  await fs.writeFile(filepath, imageData, 'base64');

  // Return relative path for public access
  return `/images/users/${filename}`;
  } catch (error) {
    console.error('Error saving profile image:', error);
    throw new Error('Failed to save profile image');
  }
};

/**
 * Create new user with role assignment and permissions setup
 * 
 * Process:
 * 1. Validate email uniqueness
 * 2. Process and save profile image
 * 3. Hash password and create user record
 * 4. Assign role and initialize permissions
 * 5. Set up campus access based on role
 */
export const addUser = async (userData, currentUser) => {
  try {
    const {
      fullName,
      organization,
      location,
      contactNumber,
      email,
      password,
      role, // incoming value expected to be ObjectId string
      assignedTopics = [],
      profileImage,
      allowedResources
    } = userData;

    // ---------------- Normalizer ----------------
    const normalizeAllowedResources = (raw) => {
      if (!raw || typeof raw !== 'object') return null;

      const pick = (obj, ...keys) => {
        for (const k of keys) if (obj[k] !== undefined) return obj[k];
        return undefined;
      };

      const mergeOrDefault = (value, defaultObj) => {
        if (value === undefined || value === null) return defaultObj;
        if (value && typeof value === 'object' && Object.keys(value).length === 0) {
          // preserve explicit empty object from client
          return {};
        }
        // merge defaults so missing subkeys are provided but incoming extras are preserved
        return { ...defaultObj, ...value };
      };

      const rawDeviceMgmt = pick(raw, 'deviceManagement', 'DeviceMgmt', 'DeviceManagement');

      // Build normalized object
      const normalized = {
        campusManagement: mergeOrDefault(
          pick(raw, 'campusManagement', 'CampusManagement'),
          { campuses: [], buildings: [], floors: [], zones: [] }
        ),
        intelligentControl: mergeOrDefault(
          pick(raw, 'intelligentControl', 'IntelligentControl', 'Intelligent_Control'),
          { groups: [], scenes: [], sensors: [], templates: [] }
        ),
        deviceManagement: (() => {
          const defaults = { devices: [], configuredDevices: [], discoveredDevices: [] };
          if (rawDeviceMgmt === undefined || rawDeviceMgmt === null) return defaults;
          if (typeof rawDeviceMgmt === 'object' && Object.keys(rawDeviceMgmt).length === 0) return {};
          return { ...defaults, ...rawDeviceMgmt };
        })(),
        logsMonitoring: mergeOrDefault(
          pick(raw, 'logsMonitoring', 'LogsMonitoring'),
          { eventLogs: [], mqttLogs: [] }
        ),
        controlSection: mergeOrDefault(
          pick(raw, 'controlSection', 'ControlSection'),
          { filters: [], templateTab: [] }
        ),
        userManagement: mergeOrDefault(
          pick(raw, 'userManagement', 'UserManagement'),
          { users: [], roles: [] }
        )
      };

      // Defensive: strip any top-level keys the schema doesn't support (for safety)
      // If you later add schema fields, update this list.
      return normalized;
    };
    // --------------- end Normalizer ----------------

    // ---------------------------------------------------------------------------

    // ---------------- role validation ----------------
    if (!role) {
      throw Object.assign(new Error('Role is required'), { status: 400 });
    }
    if (!mongoose.Types.ObjectId.isValid(role)) {
      throw Object.assign(new Error('Invalid role id'), { status: 400 });
    }

    const roleDoc = await Role.findById(role);
    if (!roleDoc) {
      throw Object.assign(new Error(`Role not found for provided value: ${role}`), { status: 404 });
    }
    // -------------------------------------------------

    // ---------------- uniqueness checks ----------------
    const normalizedEmail = email ? String(email).toLowerCase() : '';
    if (!normalizedEmail) {
      throw Object.assign(new Error('Email is required'), { status: 400 });
    }

    const existingEmail = await User.findOne({ email: normalizedEmail, isDeleted: { $ne: true } });
    if (existingEmail) throw Object.assign(new Error('Email already registered'), { status: 409 });


    if (contactNumber) {
      const existingContact = await User.findOne({ contactNumber, isDeleted: { $ne: true } });
      if (existingContact) throw Object.assign(new Error('Contact number already registered'), { status: 409 });
    }
    // ---------------------------------------------------

    // ---------------- build user object ----------------
    const userDataObj = {
      fullName,
      organization,
      location,
      email: normalizedEmail,
      password, // model pre-save will hash
      role_id: roleDoc._id,
      assignedTopics,
      createdDate: new Date().toISOString()
    };

    if (contactNumber) userDataObj.contactNumber = contactNumber;
  // profileImage will be handled after user creation

    if (allowedResources) {
      const normalized = normalizeAllowedResources(allowedResources);

      // Debug logs — remove in production once verified
      // eslint-disable-next-line no-console
      console.log('DEBUG normalized allowedResources:', JSON.stringify(normalized, null, 2));

      // Defensive check: ensure discoveredDevices preserved if payload had them
      const payloadHasDiscovered =
        allowedResources.deviceManagement &&
        Array.isArray(allowedResources.deviceManagement.discoveredDevices) &&
        allowedResources.deviceManagement.discoveredDevices.length > 0;

      const normalizedHasDiscovered =
        normalized.deviceManagement &&
        Array.isArray(normalized.deviceManagement.discoveredDevices) &&
        normalized.deviceManagement.discoveredDevices.length > 0;

      // eslint-disable-next-line no-console
      console.log('DEBUG payloadHasDiscovered:', payloadHasDiscovered, 'normalizedHasDiscovered:', normalizedHasDiscovered);

      if (payloadHasDiscovered && !normalizedHasDiscovered) {
        // eslint-disable-next-line no-console
        console.error('ERROR: discoveredDevices present in incoming payload but missing after normalization. raw allowedResources:', JSON.stringify(allowedResources, null, 2));
      }

      // Force plain JSON copy to avoid prototype getters interfering with mongoose
      userDataObj.allowedResources = JSON.parse(JSON.stringify(normalized));
    }

    // ---------------- create and return ----------------
    const user = await User.create(userDataObj);

    // Save profile image if provided
    if (profileImage) {
      try {
        const imagePath = await saveProfileImage(profileImage, user._id);
        user.profileImage = imagePath;
        await user.save();
      } catch (imgErr) {
        // Log error but don't fail user creation
        console.error('Profile image save failed:', imgErr);
      }
    }

    // --- Add user._id to allowedResources.userManagement.users for any user with non-empty array ---
    // Find users where allowedResources.userManagement.users is a non-empty array
    const usersWithAllowed = await User.find({
      'allowedResources.userManagement.users': { $exists: true, $type: 'array', $ne: [] }
    });
    for (const u of usersWithAllowed) {
      // Defensive: ensure structure exists and is an array
      if (!u.allowedResources) u.allowedResources = { userManagement: { users: [] } };
      if (!u.allowedResources.userManagement) u.allowedResources.userManagement = { users: [] };
      if (!Array.isArray(u.allowedResources.userManagement.users)) {
        u.allowedResources.userManagement.users = [];
      }
      // Only push string IDs
      const newUserId = user._id.toString();
      if (!u.allowedResources.userManagement.users.includes(newUserId)) {
        u.allowedResources.userManagement.users.push(newUserId);
        u.markModified('allowedResources');
        await u.save();
      }
    }

    // remove password from returned object
    const userObj = user.toObject();
    delete userObj.password;

    return userObj;

  } catch (err) {
    // Keep consistent error shape
    if (err && err.status) throw err;
    // eslint-disable-next-line no-console
    console.error('addUser error:', err);
    throw Object.assign(new Error('Email already registered.'), { status: 500, original: err });
  }
};

/**
 * Get paginated user list with advanced filtering and permission scoping
 * 
 * Features:
 * - Multi-field search (name, email, role)
 * - Status filtering (active/inactive)
 * - Role-based filtering
 * - User permission scope (only shows users current user can manage)
 * - Campus/location filtering
 * - Sorting and pagination
 */
export const getUserList = async (queryParams = {}) => {
  try {
    const {
      search = '',
      campus = '',
      role = '',
      filters = {},
      page = 1,
      limit = 10,
      status = '',
      sortBy = 'createdDate',
      sortOrder = 'desc'
    } = queryParams;

    const pageNum = Number(page) > 0 ? Number(page) : 1;
    const limitNum = Number(limit) > 0 ? Number(limit) : 10;
    const skip = (pageNum - 1) * limitNum;

    // Map API sortBy values to pipeline fields AFTER projection
    const sortFieldMap = {
      fullName: 'fullName',
      email: 'email',
      createdDate: 'createdAt',
      role: 'role'
    };
    const resolvedSortField = sortFieldMap[sortBy] || 'createdAt';
    const resolvedSortOrder = sortOrder === 'asc' ? 1 : -1;


    // Start pipeline with non-deleted filter and role lookup
    const matchStage = { isDeleted: { $ne: true } };
    // Filter by allowedUserIds if provided
    if (queryParams.allowedUserIds && Array.isArray(queryParams.allowedUserIds) && queryParams.allowedUserIds.length > 0) {
      matchStage._id = { $in: queryParams.allowedUserIds.map(id => new mongoose.Types.ObjectId(id)) };
    }
    const pipeline = [
      { $match: matchStage },
      {
        $lookup: {
          from: 'roles',
          localField: 'role_id',
          foreignField: '_id',
          as: 'role'
        }
      },
      {
        $unwind: {
          path: '$role',
          preserveNullAndEmptyArrays: true
        }
      },
      // Exclude users with Superadmin role (case-insensitive, robust)
      // {
      //   $match: {
      //     $or: [
      //       { 'role.roleName': { $exists: false } },
      //       { 'role.roleName': { $not: /^superadmin$/i } }
      //     ]
      //   }
      // }
    ];

    // Prepare match conditions if any filter/search/status present
    const hasFilterOrSearch = (
      (search && search.trim() !== '') ||
      (campus && campus.trim() !== '') ||
      (role && role.trim() !== '') ||
      Object.values(filters).some(f => f && f.trim() !== '') ||
      (status !== undefined && status !== null && status !== '')
    );

    if (hasFilterOrSearch) {
      const matchConditions = { $and: [] };

      if (search && search.trim() !== '') {
        const r = search.trim();
        matchConditions.$and.push({
          $or: [
            { fullName: { $regex: r, $options: 'i' } },
            { email: { $regex: r, $options: 'i' } },
            { 'role.roleName': { $regex: r, $options: 'i' } }
          ]
        });
      }
      if (campus && campus.trim() !== '') {
        matchConditions.$and.push({ location: { $regex: campus.trim(), $options: 'i' } });
      }
      if (role && role.trim() !== '') {
        matchConditions.$and.push({ 'role.roleName': { $regex: role.trim(), $options: 'i' } });
      }
      // Individual filters
      if (filters.fullName && filters.fullName.trim() !== '') {
        matchConditions.$and.push({
          fullName: { $regex: filters.fullName.trim(), $options: 'i' }
        });
      }
      if (filters.email && filters.email.trim() !== '') {
        matchConditions.$and.push({
          email: { $regex: filters.email.trim(), $options: 'i' }
        });
      }
      // Updated role filter handling: support role _id (ObjectId) OR roleName (string)
      if (filters.role && filters.role.trim() !== '') {
        const fr = filters.role.trim();
        if (mongoose.Types.ObjectId.isValid(fr)) {
          matchConditions.$and.push({ 'role._id': new mongoose.Types.ObjectId(fr) });
        } else {
          matchConditions.$and.push({ 'role.roleName': { $regex: fr, $options: 'i' } });
        }
      }
      // Status handling: API uses 'status' query param; DB field is isActive (true/false)
      if (status !== undefined && status !== null && status !== '') {
        const s = status.toString().trim();
        if (s === '1' || s.toLowerCase() === 'true') {
          matchConditions.$and.push({ isActive: true });
        } else if (s === '0' || s.toLowerCase() === 'false') {
          matchConditions.$and.push({ isActive: false });
        }
      }
      if (matchConditions.$and.length > 0) {
        pipeline.push({ $match: matchConditions });
      }
    }

    // Add projection for required fields (this defines the field names we will sort on)
    pipeline.push({
      $project: {
        _id: 1,
        fullName: 1,
        email: 1,
        // project role as a simple string so sorting can use 'role'
        role: { $ifNull: ['$role.roleName', 'user'] },
        createdAt: 1,
        updatedAt: 1,
        profileImage: { $ifNull: ['$profileImage', ''] },
        campus: '$location',
        isActive: { $ifNull: ['$isActive', true] }
      }
    });

    // Sorting (use resolvedSortField and order)
    const sortObj = {};
    sortObj[resolvedSortField] = resolvedSortOrder;
    pipeline.push({ $sort: sortObj });

    // Execute aggregation for total count
    const totalPipeline = [...pipeline, { $count: 'total' }];

    // Determine if we should apply collation (case-insensitive) for sorting.
    // We typically want collation for string fields: fullName, email, role
    const stringSortFields = ['fullName', 'email', 'role'];
    const useCollation = stringSortFields.includes(resolvedSortField);

    // Run total count aggregation (apply collation when needed)
    let totalAgg = User.aggregate(totalPipeline);
    if (useCollation) totalAgg = totalAgg.collation({ locale: 'en', strength: 2 });
    const totalResult = await totalAgg.exec();
    const totalCount = totalResult[0]?.total || 0;

    // Add pagination to main pipeline
    pipeline.push({ $skip: skip }, { $limit: limitNum });

    // Execute main aggregation (apply collation when needed)
    let usersAgg = User.aggregate(pipeline);
    if (useCollation) usersAgg = usersAgg.collation({ locale: 'en', strength: 2 });
    const users = await usersAgg.exec();

    // Calculate pagination info
    const totalPages = Math.ceil(totalCount / limitNum);

    // --- Get user counts based on allowed user access filtering AND applied filters ---
    // Build the same filter pipeline for counts as used for the main query
    const baseCountPipeline = [
      { $match: matchStage },
      {
        $lookup: {
          from: 'roles',
          localField: 'role_id',
          foreignField: '_id',
          as: 'role'
        }
      },
      {
        $unwind: {
          path: '$role',
          preserveNullAndEmptyArrays: true
        }
      }
    ];

    // Add the same filter conditions as the main query if they exist
    if (hasFilterOrSearch) {
      const matchConditions = { $and: [] };

      if (search && search.trim() !== '') {
        const r = search.trim();
        matchConditions.$and.push({
          $or: [
            { fullName: { $regex: r, $options: 'i' } },
            { email: { $regex: r, $options: 'i' } },
            { 'role.roleName': { $regex: r, $options: 'i' } }
          ]
        });
      }
      if (campus && campus.trim() !== '') {
        matchConditions.$and.push({ location: { $regex: campus.trim(), $options: 'i' } });
      }
      if (role && role.trim() !== '') {
        matchConditions.$and.push({ 'role.roleName': { $regex: role.trim(), $options: 'i' } });
      }
      // Individual filters
      if (filters.fullName && filters.fullName.trim() !== '') {
        matchConditions.$and.push({
          fullName: { $regex: filters.fullName.trim(), $options: 'i' }
        });
      }
      if (filters.email && filters.email.trim() !== '') {
        matchConditions.$and.push({
          email: { $regex: filters.email.trim(), $options: 'i' }
        });
      }
      // Updated role filter handling: support role _id (ObjectId) OR roleName (string)
      if (filters.role && filters.role.trim() !== '') {
        const fr = filters.role.trim();
        if (mongoose.Types.ObjectId.isValid(fr)) {
          matchConditions.$and.push({ 'role._id': new mongoose.Types.ObjectId(fr) });
        } else {
          matchConditions.$and.push({ 'role.roleName': { $regex: fr, $options: 'i' } });
        }
      }
      if (matchConditions.$and.length > 0) {
        baseCountPipeline.push({ $match: matchConditions });
      }
    }

    // Count all filtered users
    const totalCountPipeline = [...baseCountPipeline, { $count: 'total' }];
    const filteredTotalResult = await User.aggregate(totalCountPipeline).exec();
    const totalNonDeleted = filteredTotalResult[0]?.total || 0;

    // Count active filtered users
    const activeCountPipeline = [...baseCountPipeline, { $match: { isActive: true } }, { $count: 'total' }];
    const filteredActiveResult = await User.aggregate(activeCountPipeline).exec();
    const totalActive = filteredActiveResult[0]?.total || 0;

    // Count inactive filtered users  
    const inactiveCountPipeline = [...baseCountPipeline, { $match: { isActive: false } }, { $count: 'total' }];
    const filteredInactiveResult = await User.aggregate(inactiveCountPipeline).exec();
    const totalInactive = filteredInactiveResult[0]?.total || 0;

    return {
      users,
      pagination: {
        currentPage: pageNum,
        totalPages,
        totalRecords: totalCount,
        perPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPrevPage: pageNum > 1
      },
      summary: {
        totalUsers: totalCount,
        usersOnCurrentPage: users.length,
        searchCriteria: {
          search: search || null,
          campus: campus || null,
          role: role || null,
          filters: {
            fullName: filters.fullName || null,
            email: filters.email || null,
            role: filters.role || null
          },
          status: status !== undefined ? status : null,
          sortBy,
          sortOrder
        },
        totalNonDeleted,
        totalActive,
        totalInactive
      }
    };

  } catch (error) {
    throw new Error(`Error fetching user list: ${error.message}`);
  }
};

/**
 * Get user by ID
 */
export const getUserById = async (userId) => {
  const user = await User.findById(userId);
  if (!user) {
    throw Object.assign(new Error('User not found'), { status: 404 });
  }
  
  // Fetch role name if role_id exists
  let roleName = null;
  if (user.role_id) {
    try {
      const role = await Role.findById(user.role_id).select('roleName');
      if (role) {
        roleName = role.roleName;
      }
    } catch (error) {
      console.error('Error fetching role name:', error);
      // Don't throw error, just continue without role name
    }
  }
  
  // Add role_name to user object
  const userObj = user.toObject ? user.toObject() : { ...user };
  userObj.role_name = roleName;
  
  return userObj;
};

/**
 * Helper function to merge allowedResources selectively
 * Only updates the sections that are provided in the updateData
 * @param {Object} currentAllowedResources - Current user's allowedResources
 * @param {Object} updateAllowedResources - New allowedResources data
 * @returns {Object} - Merged allowedResources object
 */
const mergeAllowedResourcesSelectively = (currentAllowedResources = {}, updateAllowedResources = {}) => {
  // Define the allowed sections that can be updated
  const allowedSections = [
    'campusManagement',
    'intelligentControl', 
    'deviceManagement',
    'userManagement',
    'logsMonitoring',
    'controlSection'
  ];
  
  // Start with a copy of current allowedResources
  const mergedResources = { ...currentAllowedResources };
  
  // Selectively update only the provided sections
  allowedSections.forEach(section => {
    if (updateAllowedResources[section] !== undefined) {
      mergedResources[section] = updateAllowedResources[section];
    }
  });
  
  return mergedResources;
};

/**
 * Update user with intelligent permission merging
 * 
 * Smart Features:
 * - Selective allowedResources updating (only updates provided sections)
 * - Role change detection and permission reset
 * - Password hashing via Mongoose pre-save hooks
 * - Campus data synchronization from permissions
 * - Profile image processing
 * - Audit trail with updatedBy tracking
 * 
 * Permission Sections (selectively updatable):
 * - campusManagement: Campus/building/floor/zone access
 * - intelligentControl: Group/scene/sensor/template access  
 * - deviceManagement: Device access control
 * - userManagement: User management permissions
 * - logsMonitoring: Log viewing permissions
 * - controlSection: Control panel tab access
 * 
 * @example Selective update (preserves other sections):
 * updateUser(userId, {
 *   allowedResources: {
 *     campusManagement: { campuses: ['id1', 'id2'] }
 *   }
 * }, currentUser)
 */
export const updateUser = async (userId, updateData, currentUser) => {
  // Find user by ID
  const user = await User.findById(userId).select('+password');
  if (!user) {
    throw Object.assign(new Error('User not found'), { status: 404 });
  }

  // Check if email is being updated and if it already exists
  if (updateData.email && updateData.email !== user.email) {
    const existingUser = await User.findOne({ email: updateData.email });
    if (existingUser) {
      throw Object.assign(new Error('Email already exists'), { status: 400 });
    }
  }

  // Build fields to update
  const updateFields = {};

  if (updateData.fullName !== undefined) updateFields.fullName = updateData.fullName;

  if (updateData.email !== undefined) updateFields.email = updateData.email;
  if (updateData.contactNumber !== undefined) updateFields.contactNumber = updateData.contactNumber;
  if (updateData.organization !== undefined) updateFields.organization = updateData.organization;
  if (updateData.location !== undefined) updateFields.location = updateData.location;
  if (updateData.profileImage !== undefined) updateFields.profileImage = updateData.profileImage;

  // role validation and mapping to role_id
  if (updateData.role !== undefined) {
    if (!mongoose.Types.ObjectId.isValid(updateData.role)) {
      throw Object.assign(new Error('Invalid role id'), { status: 400 });
    }
    const roleDoc = await Role.findById(updateData.role);
    if (!roleDoc) {
      throw Object.assign(new Error(`Role not found for provided value: ${updateData.role}`), { status: 404 });
    }
    updateFields.role_id = roleDoc._id;
  }

  // -----------------------
  // allowedResources handling (explicit dot-path updates for arrays)
  // -----------------------
  const allowedSections = [
    'campusManagement',
    'intelligentControl',
    'deviceManagement',
    'userManagement',
    'logsMonitoring',
    'controlSection'
  ];

  const shallowMerge = (base = {}, incoming = {}) => ({ ...(base || {}), ...(incoming || {}) });
  let campusManagementUpdated = false;
  let updatedCampusManagement = null;

  if (Object.prototype.hasOwnProperty.call(updateData, 'allowedResources')) {
    const incoming = updateData.allowedResources;


    // --- PRE-UPDATE: If user.allowedResources is null, update DB to set it to {} ---
    // PATCH: Ensure allowedResources is not null before updating nested sections
    // If incoming is not null AND user.allowedResources is null, patch it with an empty object first in DB
    if (incoming !== null && user.allowedResources === null) {
      // Set allowedResources to {} in DB so we can update nested fields
      await User.findByIdAndUpdate(userId, { $set: { allowedResources: {} } }, { new: false });
      // Also patch the local user doc

      user.allowedResources = {};
    }

    if (incoming === null) {
      // Explicit wipe-out of whole allowedResources
      updateFields['allowedResources'] = null;
      console.log('[allowedResources] -> set to null');
    } else if (typeof incoming !== 'object') {
      throw Object.assign(new Error('allowedResources must be an object or null'), { status: 400 });
    } else {
      // Iterate allowed sections
      allowedSections.forEach((section) => {
        if (!Object.prototype.hasOwnProperty.call(incoming, section)) {
          // Not provided -> leave as is
          return;
        }

        const incomingSection = incoming[section];

        // explicit null removes the section
        if (incomingSection === null) {
          updateFields[`allowedResources.${section}`] = null;
          console.log(`[allowedResources.${section}] -> set to null`);
          if (section === 'campusManagement') {
            campusManagementUpdated = true;
            updatedCampusManagement = null;
          }
          return;
        }

        // If incomingSection is not object, replace entire section
        if (!incomingSection || typeof incomingSection !== 'object') {
          updateFields[`allowedResources.${section}`] = incomingSection;
          console.log(`[allowedResources.${section}] -> replaced with primitive or array`);
          if (section === 'campusManagement') {
            campusManagementUpdated = true;
            updatedCampusManagement = incomingSection;
          }
          return;
        }

        // SECTION-LEVEL: build a full section object and set it atomically.
        // This avoids creating nested fields when the current section is null.
        const currentSection = (user.allowedResources && user.allowedResources[section]) || null;

        // Start with currentSection if it's an object; otherwise start fresh
        const sectionObj = {};
        if (currentSection && typeof currentSection === 'object') {
          Object.keys(currentSection).forEach((k) => {
            sectionObj[k] = currentSection[k];
          });
        }

        // Apply incoming keys: arrays replace exactly, objects shallow-merge, primitives replace
        Object.keys(incomingSection).forEach((key) => {
          const val = incomingSection[key];

          // Explicitly handle controlSection groupTab, sceneTab, deviceTab and userManagement.roles
          if (
            (section === 'controlSection' && ['groupTab', 'sceneTab', 'deviceTab', 'templateTab'].includes(key)) ||
            (section === 'userManagement' && key === 'roles')
          ) {
            sectionObj[key] = Array.isArray(val) ? val : [];
            console.log(`[allowedResources.${section}.${key}] -> explicit array replace, length ${sectionObj[key].length}`);
            return;
          }

          if (Array.isArray(val)) {
            // exact replace for arrays
            sectionObj[key] = val;
            console.log(`[allowedResources.${section}.${key}] -> section-level replace array length ${val.length}`);
          } else if (val && typeof val === 'object') {
            // shallow merge nested objects with current value (if present)
            const existingVal = (currentSection && currentSection[key]) || {};
            sectionObj[key] = { ...(existingVal || {}), ...(val || {}) };
            console.log(`[allowedResources.${section}.${key}] -> section-level shallow-merge object`);
          } else {
            // primitive -> replace
            sectionObj[key] = val;
            console.log(`[allowedResources.${section}.${key}] -> section-level replaced with primitive`);
          }
        });

        // set the whole section at once
        updateFields[`allowedResources.${section}`] = sectionObj;
        console.log(`[allowedResources.${section}] -> will be set (section-level object)`);
        
        if (section === 'campusManagement') {
          campusManagementUpdated = true;
          updatedCampusManagement = sectionObj;
        }
      });
    }
  }

  // -----------------------
  // password update (hash via pre-save)
  // -----------------------
  if (updateData.password) {
    // Check if new password is same as current password
    const isSamePassword = await user.comparePassword(updateData.password);
    if (isSamePassword) {
      throw Object.assign(new Error('New password cannot be the same as the current password'), { status: 400 });
    }

    // set and save on the user doc so pre-save hash middleware runs
    user.password = updateData.password;
    await user.save();

    // invalidate token and active sessions
    updateFields.token = null;

    await UserAuth.updateMany(
      { userId: user._id, status: 'active' },
      {
        status: 'expired',
        updatedOn: new Date(),
        updatedBy: {
          userId: currentUser._id,
          fullName: currentUser.fullName,
          email: currentUser.email
        }
      }
    );
  }

  // Add updatedBy / updatedAt metadata
  updateFields.updatedBy = {
    userId: currentUser._id,
    fullName: currentUser.fullName,
    email: currentUser.email
  };
  updateFields.updatedAt = new Date();

  // Sync campusData when campusManagement is updated
  if (campusManagementUpdated && updatedCampusManagement) {
    try {
      const campusData = await syncCampusDataFromAllowedResources(updatedCampusManagement);
      updateFields.campusData = campusData;
      console.log('[campusData] -> synced from allowedResources.campusManagement');
    } catch (error) {
      console.error('Error syncing campusData:', error);
    }
  } else if (campusManagementUpdated && updatedCampusManagement === null) {
    // If campusManagement is set to null, clear campusData
    updateFields.campusData = [];
    console.log('[campusData] -> cleared due to null campusManagement');
  }

  // Debug: show exactly what will be passed to Mongo
  console.log('FINAL updateFields:', JSON.stringify(updateFields, null, 2));

  // Run the update using $set so we only update provided keys
  const updatedUser = await User.findByIdAndUpdate(
    userId,
    { $set: updateFields },
    { new: true, runValidators: true }
  );

  return updatedUser;
};

/**
 * Sync campusData from allowedResources.campusManagement
 * @param {Object} campusManagement - The campusManagement object from allowedResources
 * @returns {Array} - Array of campus data objects
 */
const syncCampusDataFromAllowedResources = async (campusManagement) => {
  if (!campusManagement || typeof campusManagement !== 'object') {
    return [];
  }

  const { campuses = [], buildings = [], floors = [], zones = [] } = campusManagement;
  const campusData = [];

  // Process each campus
  for (const campusId of campuses) {
    try {
      const campus = await Campus.findById(campusId).lean();
      if (!campus) continue;

      const campusObj = {
        campus_id: campus._id.toString(),
        campus_name: campus.name,
        buildings: []
      };

      // Find buildings for this campus
      const campusBuildings = await CampusBuilding.find({
        campusId: campus._id,
        _id: { $in: buildings },
        isDelete: { $ne: true }
      }).lean();

      for (const building of campusBuildings) {
        const buildingObj = {
          building_id: building._id.toString(),
          building_name: building.name,
          floors: []
        };

        // Find floors for this building
        const buildingFloors = await CampusFloor.find({
          buildingId: building._id,
          _id: { $in: floors },
          isDelete: { $ne: true },
          deleted: { $ne: true }
        }).lean();

        for (const floor of buildingFloors) {
          const floorObj = {
            floor_id: floor._id.toString(),
            floor_name: floor.name,
            zones: []
          };

          // Find zones for this floor
          const floorZones = await CampusZone.find({
            floorId: floor._id,
            _id: { $in: zones },
            isDelete: { $ne: true }
          }).lean();

          for (const zone of floorZones) {
            floorObj.zones.push({
              zone_id: zone._id.toString(),
              zone_name: zone.name
            });
          }

          buildingObj.floors.push(floorObj);
        }

        campusObj.buildings.push(buildingObj);
      }

      campusData.push(campusObj);
    } catch (error) {
      console.error(`Error processing campus ${campusId}:`, error);
    }
  }

  return campusData;
};

export default {
  updateUser
};

/**
 * Delete user (soft delete)
 */
export const deleteUser = async (userId, currentUser) => {
  const user = await User.findById(userId);
  if (!user) {
    throw Object.assign(new Error('User not found'), { status: 404 });
  }

  // Remove image file(s) for user
  const fs = await import('fs');
  const path = await import('path');
  const extensions = ['jpeg', 'jpg', 'png', 'webp'];
  for (const ext of extensions) {
    const imageFilePath = path.resolve('public/images/users', `${user._id}.${ext}`);
    if (fs.existsSync(imageFilePath)) {
      try { fs.unlinkSync(imageFilePath); } catch (e) { /* ignore */ }
    }
  }

  // Hard delete user from MongoDB
  await User.deleteOne({ _id: userId });

  return { message: 'User hard deleted successfully' };
};

/**
 * Change user status (Active/Inactive)
 */
export const changeUserStatus = async (userId, isActive, currentUser) => {
  const user = await User.findById(userId);
  if (!user || user.isDeleted) {
    throw Object.assign(new Error('User not found'), { status: 404 });
  }

  // Update status with the provided isActive value
  const updatedUser = await User.findByIdAndUpdate(
    userId,
    {
      isActive: isActive,
      updatedDate: new Date().toISOString(),
      updatedBy: {
        userId: currentUser._id,
        fullName: currentUser.fullName,
        email: currentUser.email
      }
    },
    { new: true, select: '-password' }
  );

  return updatedUser;
};

/**
 * Update user password
 */
export const updateUserPassword = async (userId, currentPassword, newPassword, confirmPassword) => {
  try {
    // Verify current password
    const user = await User.findById(userId);
    if (!user) {
      throw new Error('User not found');
    }

    const isPasswordValid = await bcrypt.compare(currentPassword, user.password);
    if (!isPasswordValid) {
      throw new Error('Current password is incorrect');
    }

    // Check if new passwords match
    if (newPassword !== confirmPassword) {
      throw new Error('New passwords do not match');
    }

    // Check if new password is same as current password
    const isSamePassword = await bcrypt.compare(newPassword, user.password);
    if (isSamePassword) {
      throw new Error('New password cannot be the same as the current password');
    }

    // Hash new password
    const saltRounds = 12;
    const hashedPassword = await bcrypt.hash(newPassword, saltRounds);

    // Update password
    user.password = hashedPassword;
    user.updatedAt = new Date().toISOString();
    
    await user.save();

    return { message: 'Password updated successfully' };
  } catch (error) {
    console.error('Error in updateUserPassword service:', error);
    throw error;
  }
};

/**
 * Get user statistics
 */
export const getUserStats = async () => {
  try {
    const totalUsers = await User.countDocuments();
    const activeUsers = await User.countDocuments({ 
      lastLogin: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } 
    });
    
    const roleDistribution = await User.aggregate([
      {
        $group: {
          _id: '$role',
          count: { $sum: 1 }
        }
      }
    ]);

    return {
      totalUsers,
      activeUsers,
      inactiveUsers: totalUsers - activeUsers,
      roleDistribution
    };
  } catch (error) {
    console.error('Error in getUserStats service:', error);
    throw error;
  }
};

/**
 * Get tab names based on user role permissions
 */
export const getTabNames = async (roleId) => {
  try {
    // Validate role_id
    if (!mongoose.Types.ObjectId.isValid(roleId)) {
      throw Object.assign(new Error('Invalid role ID format'), { status: 400 });
    }

    // Fetch role with permissions
    const role = await Role.findById(roleId);
    if (!role) {
      throw Object.assign(new Error('Role not found'), { status: 404 });
    }

    if (!role.isActive) {
      throw Object.assign(new Error('Role is not active'), { status: 403 });
    }

    // Generate module tabs based on permissions
    const tabs = generateModuleTabsFromPermissions(role.permissions);

    return {
      tabs
    };
  } catch (error) {
    throw error;
  }
};

/**
 * Get all accessible modules for a user based on role permissions
 */
export const getUserAccessibleModules = async (roleId) => {
  try {
    // Validate role_id
    if (!mongoose.Types.ObjectId.isValid(roleId)) {
      throw Object.assign(new Error('Invalid role ID format'), { status: 400 });
    }

    // Fetch role with permissions
    const role = await Role.findById(roleId);
    if (!role) {
      throw Object.assign(new Error('Role not found'), { status: 404 });
    }

    if (!role.isActive) {
      throw Object.assign(new Error('Role is not active'), { status: 403 });
    }

    // Generate module tabs based on permissions
    const tabs = generateModuleTabsFromPermissions(role.permissions);

    return {
      tabs,
      role: {
        id: role._id,
        name: role.roleName,
        isActive: role.isActive
      }
    };
  } catch (error) {
    throw error;
  }
};

// Helper: recursively ensure objects have isChecked property.
// - Preserve existing isChecked (true/false) if present.
// - If not present, set isChecked: false for object items.
// - Leaves primitives and arrays of primitives untouched.
const markEntitiesChecked = (data) => {
  if (Array.isArray(data)) {
    return data.map(item => {
      if (item && typeof item === 'object' && !Array.isArray(item)) {
        const hasChecked = Object.prototype.hasOwnProperty.call(item, 'isChecked');
        return { ...item, isChecked: hasChecked ? Boolean(item.isChecked) : false };
      }
      // nested array or primitive -> recurse/return
      return markEntitiesChecked(item);
    });
  } else if (data && typeof data === 'object') {
    const out = {};
    for (const key of Object.keys(data)) {
      out[key] = markEntitiesChecked(data[key]);
    }
    return out;
  }
  return data;
};

/**
 * Get module resources filtered by role permissions
 * 
 * Two return modes:
 * 1. Specific module (type provided): Returns { tabs, ...moduleResources }
 * 2. All modules (no type): Returns array of all accessible modules
 * 
 * Each resource includes permission-based filtering:
 * - Only shows resources role can view/access
 * - Marks entities with isChecked based on user's allowedResources
 * - Applies permission inheritance (role → user)
 * 
 * Module types: campusManagement, intelligentControl, deviceManagement, 
 *               userManagement, logsMonitoring, controlSection
 */
export const getModuleData = async (type, roleId, user = null) => {
  try {
    // Validate role_id
    if (!mongoose.Types.ObjectId.isValid(roleId)) {
      throw Object.assign(new Error('Invalid role ID format'), { status: 400 });
    }

    // Fetch role with permissions
    const role = await Role.findById(roleId);
    if (!role) {
      throw Object.assign(new Error('Role not found'), { status: 404 });
    }

    if (!role.isActive) {
      throw Object.assign(new Error('Role is not active'), { status: 403 });
    }

    // ---------- CASE 1: no type provided -> return all modules as array ----------
    if (!type) {
      const modules = [
        {
          id: 'campusManagement',
          label: 'Campus Management',
          fetcher: getCampusManagementDataWithPermissions
        },
        {
          id: 'intelligentControl',
          label: 'Intelligent Control',
          fetcher: getIntelligentControlDataWithPermissions
        },
        {
          id: 'deviceManagement',
          label: 'Device Management',
          fetcher: getDeviceManagementDataWithPermissions
        },
        {
          id: 'userManagement',
          label: 'User Management',
          fetcher: getUserManagementDataWithPermissions
        },
        {
          id: 'logsMonitoring',
          label: 'Logs Monitoring',
          fetcher: getLogsMonitoringDataWithPermissions
        },
        {
          id: 'controlSection',
          label: 'Control Section',
          fetcher: getControlSectionDataWithPermissions
        }
      ];

      const results = await Promise.all(
        modules.map(async (m) => {
          try {
            const permissionKey = getPermissionModuleKey(m.id);

            // If permissionKey missing or role lacks view permission, return empty data object
            if (!permissionKey || !hasAnyViewPermissionInModule(role.permissions, permissionKey)) {
              return {
                id: m.id,
                label: m.label,
                data: {}
              };
            }

            // Determine allowed features for this module (forward to fetcher)
            const allowedFeatures = getAllowedFeaturesInModule(role.permissions, permissionKey);

            // Call the module-specific fetcher — pass user for those that accept it
            let data = await m.fetcher(role.permissions, allowedFeatures, user);

            // Ensure we return an object for data; if fetcher returns primitive or null, normalize to {}
            if (data == null || typeof data !== 'object') {
              data = {};
            }

            // For controlSection rely on fetcher (it sets isChecked correctly).
            // For other modules, use markEntitiesChecked to preserve existing isChecked or default to false.
            const marked = m.id === 'controlSection' ? data : markEntitiesChecked(data);

            return {
              id: m.id,
              label: m.label,
              data: marked
            };
          } catch (err) {
            console.error(`Failed to fetch module ${m.id}:`, err);
            return {
              id: m.id,
              label: m.label,
              data: {}
            };
          }
        })
      );


      return results;
    }

    // ---------- CASE 2: type provided -> original single-module flow ----------
    // Get permission module key
    const permissionModuleKey = getPermissionModuleKey(type);
    if (!permissionModuleKey) {
      throw Object.assign(new Error('Invalid module type'), { status: 400 });
    }

    // Check if role has any view permissions for this module
    if (!hasAnyViewPermissionInModule(role.permissions, permissionModuleKey)) {
      throw Object.assign(new Error('Access denied: No view permissions for this module'), { status: 403 });
    }

    // Get allowed features for this module
    const allowedFeatures = getAllowedFeaturesInModule(role.permissions, permissionModuleKey);

    // For backward compatibility, include feature-level tabs for the specific module
    const moduleTabs = generateModuleTabsFromPermissions(role.permissions);

    // Get module data based on permissions
    let moduleData;
    switch (type) {
      case 'campusManagement':
        moduleData = await getCampusManagementDataWithPermissions(role.permissions, allowedFeatures, user);
        break;

      case 'intelligentControl':
        moduleData = await getIntelligentControlDataWithPermissions(role.permissions, allowedFeatures, user);
        break;

      case 'deviceManagement':
        moduleData = await getDeviceManagementDataWithPermissions(role.permissions, allowedFeatures, user);
        break;

      case 'userManagement':
        moduleData = await getUserManagementDataWithPermissions(role.permissions, allowedFeatures);
        break;

      case 'logsMonitoring':
        moduleData = await getLogsMonitoringDataWithPermissions(role.permissions, allowedFeatures, user);
        break;

      case 'controlSection':
        moduleData = await getControlSectionDataWithPermissions(role.permissions, allowedFeatures, user);
        break;

      default:
        throw Object.assign(new Error('Invalid module type. Supported types: campusManagement, IntelligentControl, deviceManagement, userManagement, logsMonitoring, controlSection'), { status: 400 });
    }

    // Normalize moduleData and return with tabs
    if (!moduleData || typeof moduleData !== 'object') {
      moduleData = {};
    }

    return {
      tabs: moduleTabs,
      ...moduleData
    };
  } catch (error) {
    // Re-throw so controller's catchAsync can handle it
    throw error;
  }
};

/**
 * Helper function to check if an entity should be marked as checked based on user's allowedResources
 */
const isEntityCheckedInAllowedResources = (entityId, user, entityType) => {
  // Debug logging
    if (user && user.allowedResources) {
    console.log('User allowedResources:', JSON.stringify(user.allowedResources, null, 2));
  }
  
  if (!user || !user.allowedResources) {
    return false;
  }

  const { allowedResources } = user;

  switch (entityType) {
    case 'campus':
      return allowedResources.campusManagement?.campuses?.includes(entityId.toString()) || false;
    
    case 'building':
      return allowedResources.campusManagement?.buildings?.includes(entityId.toString()) || false;
    
    case 'floor':
      return allowedResources.campusManagement?.floors?.includes(entityId.toString()) || false;
    
    case 'zone':
      return allowedResources.campusManagement?.zones?.includes(entityId.toString()) || false;
    
    case 'group':
      return allowedResources.intelligentControl?.groups?.includes(entityId.toString()) || false;
    
    case 'scene':
      return allowedResources.intelligentControl?.scenes?.includes(entityId.toString()) || false;
    
    case 'sensor':
      return allowedResources.intelligentControl?.sensors?.includes(entityId.toString()) || false;
    
    case 'template':
      return allowedResources.intelligentControl?.templates?.includes(entityId.toString()) || false;
    
    case 'device':
      return allowedResources.deviceManagement?.devices?.includes(entityId.toString()) || false;
    
    default:
      return false;
  }
};

/**
 * Get campus management data
 */
const getCampusManagementData = async () => {
  // Get all non-deleted campuses
  const campuses = await Campus.find({ 
    isDelete: { $ne: true } 
  }).select('_id name status location type organization').lean();

  // Get all non-deleted buildings
  const buildings = await CampusBuilding.find({ 
    isDelete: { $ne: true } 
  }).select('_id name status type campusId').lean();

  // Get all non-deleted floors  
  const floors = await CampusFloor.find({ 
    deleted: { $ne: true },
    isDelete: { $ne: true }
  }).select('_id name status floorLevel buildingId').lean();

  // Get all non-deleted zones
  const zones = await CampusZone.find({ 
    isDelete: { $ne: true } 
  }).select('_id name status type floorId').lean();

  return {
    campus: campuses,
    building: buildings,
    floor: floors,
    zone: zones
  };
};

/**
 * Get intelligent control data
 */
const getIntelligentControlData = async () => {
  // Get all non-deleted groups
  const groups = await Group.find({ 
    isDeleted: { $ne: true } 
  }).select('_id name devices createdAt updatedAt').lean();

  // Get all non-deleted scenes
  const scenes = await Scene.find({ 
    isDeleted: { $ne: true } 
  }).select('_id name type status lastExecuted executedBy createdAt updatedAt').lean();

  // Get all non-deleted sensors
  const sensors = await Sensor.find({ 
    isDelete: { $ne: true } 
  }).select('_id sensorEvent device sensor motionScene NoMotionScene Trigger_duration status createdAt updatedAt').lean();

  // Get all non-deleted templates
  const templates = await Template.find({ 
    isDelete: { $ne: true },
    deleted: { $ne: true }
  }).select('_id name layout status rows columns layoutStructure createdAt updatedAt').lean();

  return {
    Group: groups,
    Scene: scenes,
    Sensor: sensors,
    Template: templates
  };
};

/**
 * Get device management data
 */
const getDeviceManagementData = async () => {
  // Remove devices from deviceManagement response
  return {};
};

/**
 * Get user management data
 */
const getUserManagementData = async () => {
  // Get all non-deleted users
  const users = await User.find({ 
    isDeleted: { $ne: true } 
  }).select('_id fullName email role_id location contactNumber profileImage lastLogin isActive createdDate').lean();

  // Get all non-deleted roles
  const roles = await Role.find({ 
    isDelete: { $ne: true } 
  }).select('_id roleName description permissions').lean();

  return {
    users: users,
    roles: roles
  };
};

/**
 * Get logs monitoring data
 */
const getLogsMonitoringData = async () => {
  // Get event logs from logs collection
  const eventLogs = await Log.find({})
    .select('_id level message meta userId createdAt')
    .sort({ createdAt: -1 })
    .limit(1000)
    .lean();

  // Transform event logs to match expected format
  const transformedEventLogs = eventLogs.map(log => ({
    _id: log._id,
    level: log.level,
    message: log.message,
    meta: log.meta,
    userId: log.userId,
    timestamp: log.createdAt
  }));

  // Get MQTT logs from messages collection
  const mqttLogs = await Message.find({})
    .select('_id id message.topic message.payload status createdAt')
    .sort({ createdAt: -1 })
    .limit(1000)
    .lean();

  // Transform MQTT logs to match expected format
  const transformedMqttLogs = mqttLogs.map(log => ({
    id: log._id,
    device_id: log.id,
    topic: log.message?.topic || '',
    payload: log.message?.payload || '',
    status: log.status || 1,
    createdAt: log.createdAt
  }));

  return {
    eventLogs: transformedEventLogs,
    MQTTLogs: transformedMqttLogs
  };
};

/**
 * Get control section data (comprehensive control data)
 */
const getControlSectionData = async () => {
  // Get all non-deleted groups
  const groups = await Group.find({ 
    isDeleted: { $ne: true } 
  }).select('_id name devices createdAt updatedAt').lean();

  // Get all non-deleted scenes
  const scenes = await Scene.find({ 
    isDeleted: { $ne: true } 
  }).select('_id name type status lastExecuted executedBy createdAt updatedAt').lean();

  // Get all devices and split by configure_flag
  const allDevices = await Device.find({ is_delete: false })
    .select('_id device_id name type status campus building floor zone capabilities configure_flag createdAt updatedAt').lean();

  const configuredDevices = allDevices.filter(d => d.configure_flag === true || d.configure_flag === 1);
  const discoveredDevices = allDevices.filter(d => d.configure_flag === false || d.configure_flag === 0);

  // Get all non-deleted sensors for automation control
  const sensors = await Sensor.find({ 
    isDelete: { $ne: true } 
  }).select('_id sensorEvent device sensor motionScene NoMotionScene Trigger_duration status createdAt updatedAt').lean();

  // Get all non-deleted templates for layout control
  const templates = await Template.find({ 
    isDelete: { $ne: true },
    deleted: { $ne: true }
  }).select('_id name layout status rows columns layoutStructure createdAt updatedAt').lean();

  return {
    groups,
    scenes,
    configuredDevices,
    discoveredDevices,
    sensors,
    templates
  };
};

/**
 * Get campus management data with permission filtering
 */
const getCampusManagementDataWithPermissions = async (permissions, allowedFeatures, user = null) => {
  const result = {};

  // Check permissions for each feature and only include allowed data
  if (allowedFeatures.includes('campus_management')) {
    const campuses = await Campus.find({ 
      isDelete: { $ne: true } 
    }).select('_id name status location type organization').lean();
    
    // Add isChecked flag based on user's allowedResources
    result.campuses = campuses.map(campus => {
      const isChecked = isEntityCheckedInAllowedResources(campus._id, user, 'campus');
      console.log(`Campus ${campus._id} (${campus.name}): isChecked = ${isChecked}`);
      return {
        ...campus,
        isChecked: isChecked
      };
    });
    console.log('============================');
  }

  if (allowedFeatures.includes('building_management')) {
    const buildings = await CampusBuilding.find({ 
      isDelete: { $ne: true } 
    }).select('_id name status type campusId').lean();
    
    // Add isChecked flag based on user's allowedResources
    result.buildings = buildings.map(building => ({
      ...building,
      isChecked: isEntityCheckedInAllowedResources(building._id, user, 'building')
    }));
  }

  if (allowedFeatures.includes('floor_management')) {
    const floors = await CampusFloor.find({ 
      deleted: { $ne: true },
      isDelete: { $ne: true }
    }).select('_id name status floorLevel buildingId').lean();
    
    // Add isChecked flag based on user's allowedResources
    result.floors = floors.map(floor => ({
      ...floor,
      isChecked: isEntityCheckedInAllowedResources(floor._id, user, 'floor')
    }));
  }

  if (allowedFeatures.includes('zone_management')) {
    const zones = await CampusZone.find({ 
      isDelete: { $ne: true } 
    }).select('_id name status type floorId').lean();
    
    // Add isChecked flag based on user's allowedResources
    result.zones = zones.map(zone => ({
      ...zone,
      isChecked: isEntityCheckedInAllowedResources(zone._id, user, 'zone')
    }));
  }

  return result;
};

/**
 * Get intelligent control data with permission filtering
 */
const getIntelligentControlDataWithPermissions = async (permissions, allowedFeatures, user = null) => {
  const result = {};

  if (allowedFeatures.includes('group_management')) {
    const groups = await Group.find({ 
      isDeleted: { $ne: true } 
    }).select('_id name devices createdAt updatedAt').lean();
    
    // Add isChecked flag based on user's allowedResources
    result.groups = groups.map(group => ({
      ...group,
      isChecked: isEntityCheckedInAllowedResources(group._id, user, 'group')
    }));
  }

  if (allowedFeatures.includes('scene_management')) {
    const scenes = await Scene.find({ 
      isDeleted: { $ne: true } 
    }).select('_id name type status lastExecuted executedBy createdAt updatedAt').lean();
    
    // Add isChecked flag based on user's allowedResources
    result.scenes = scenes.map(scene => ({
      ...scene,
      isChecked: isEntityCheckedInAllowedResources(scene._id, user, 'scene')
    }));
  }

  if (allowedFeatures.includes('sensor_management')) {
    const sensors = await Sensor.find({ 
      isDelete: { $ne: true } 
    }).select('_id sensorEvent device sensor motionScene NoMotionScene Trigger_duration status createdAt updatedAt').lean();
    
    // Add isChecked flag based on user's allowedResources
    result.sensors = sensors.map(sensor => ({
      ...sensor,
      isChecked: isEntityCheckedInAllowedResources(sensor._id, user, 'sensor')
    }));
  }

  if (allowedFeatures.includes('template_management')) {
    const templates = await Template.find({ 
      isDelete: { $ne: true },
      deleted: { $ne: true }
    }).select('_id name layout status rows columns layoutStructure createdAt updatedAt').lean();
    
    // Add isChecked flag based on user's allowedResources
    result.templates = templates.map(template => ({
      ...template,
      isChecked: isEntityCheckedInAllowedResources(template._id, user, 'template')
    }));
  }

  return result;
};

/**
 * Get device management data with permission filtering
 */
const getDeviceManagementDataWithPermissions = async (permissions, allowedFeatures, user = null) => {
  const result = {};

  if (allowedFeatures.includes('device_configuration') || allowedFeatures.includes('device_control')) {
    const devices = await Device.find({ 
      is_delete: false
    }).select('_id device_id name type status campus building floor zone capabilities configure_flag createdAt updatedAt').lean();

    // Add isChecked flag to all devices
    const devicesWithChecked = devices.map(device => ({
      ...device,
      isChecked: isEntityCheckedInAllowedResources(device._id, user, 'device')
    }));

    // Only return configuredDevices and discoveredDevices, not 'devices'
    result.discoveredDevices = devicesWithChecked.filter(device => device.configure_flag === false || device.configure_flag === 0);
    result.configuredDevices = devicesWithChecked.filter(device => device.configure_flag === true || device.configure_flag === 1);
  }

  return result;
};

/**
 * Get user management data with permission filtering
 */
const getUserManagementDataWithPermissions = async (permissions, allowedFeatures) => {
  const result = {};

  if (allowedFeatures.includes('user_accounts')) {
    result.users = await User.find({ 
      isDelete: { $ne: true } 
    }).select('_id fullName email role_id isActive lastLogin createdDate updatedAt').lean();
  }

  if (allowedFeatures.includes('role_management')) {
    result.roles = await Role.find({ 
      isDelete: { $ne: true } 
    }).select('_id roleName permissions isActive createdAt updatedAt').lean();
  }

  return result;
};

/**
 * Get logs monitoring data with permission filtering
 */
// import Log from '../models/Log.js';

const getLogsMonitoringDataWithPermissions = async (permissions, allowedFeatures, user = null) => {
  // Default: no access
  let eventLogs = false;
  let mqttLogs = false;
  let roleName = null;

  // If user is provided, try to get roleName
  if (user) {
    if (user.role_id) {
      // Dynamically import Role model
      const Role = (await import('../models/Role.js')).default || (await import('../models/Role.js'));
      let roleDoc = null;
      try {
        roleDoc = await Role.findById(user.role_id);
      } catch (e) {
        // ignore
      }
      if (roleDoc && roleDoc.roleName) {
        roleName = roleDoc.roleName;
      }
    }
  }

  if (roleName) {
    const name = roleName.toLowerCase();
    if (name === 'admin' || name === 'technician' || name === 'superadmin') {
      eventLogs = true;
      mqttLogs = true;
    } else if (name === 'operator') {
      eventLogs = true;
      mqttLogs = false;
    } else if (name === 'tenant') {
      eventLogs = false;
      mqttLogs = false;
    }
  }

  return {
    eventLogs,
    mqttLogs
  };
};

/**
 * Get control section data with permission filtering
 */
/**
 * Get control section data with permission filtering AND user allowedResources checks.
 *
 * - permissions: role.permissions
 * - allowedFeatures: (not used heavily here, kept for signature compat)
 * - user: current user object (used to read allowedResources.controlSection.templateTab|groupTab|sceneTab|deviceTab)
 *
 * Returns an object that contains only the tabs that are enabled in permissions.CONTROL_SECTION.
 * Each returned item gets `isChecked: true` only if the user's allowedResources.controlSection.<TabName>
 * includes that entity's _id (stringified).
 */
const getControlSectionDataWithPermissions = async (permissions, allowedFeatures, user = null) => {
  // Read CONTROL_SECTION permission block from role
  const controlPerms = (permissions && permissions.CONTROL_SECTION) ? permissions.CONTROL_SECTION : {};

  const anyTrue = (obj) => {
    if (!obj || typeof obj !== 'object') return false;
    return Object.values(obj).some(v => v === true);
  };

  const includeTemplate = anyTrue(controlPerms.template_tab);
  const includeGroup = anyTrue(controlPerms.group_tab);
  const includeScene = anyTrue(controlPerms.scene_tab);
  const includeDevice = anyTrue(controlPerms.device_tab);

  // Fetch full control-section source data (unfiltered, no isChecked)
  const csData = await getControlSectionData(); // uses groups, scenes, configuredDevices, templates
  const groups = csData.groups || [];
  const scenes = csData.scenes || [];
  const templates = csData.templates || [];
  const configuredDevices = csData.configuredDevices || [];

  // Get the user's controlSection allowedResources arrays (safe defaults)
  const userControl = (user && user.allowedResources && user.allowedResources.controlSection) ? user.allowedResources.controlSection : {};
  const allowedTemplateArr = Array.isArray(userControl.templateTab) ? userControl.templateTab.map(String) : [];
  const allowedGroupArr = Array.isArray(userControl.groupTab) ? userControl.groupTab.map(String) : [];
  const allowedSceneArr = Array.isArray(userControl.sceneTab) ? userControl.sceneTab.map(String) : [];
  const allowedDeviceArr = Array.isArray(userControl.deviceTab) ? userControl.deviceTab.map(String) : [];

  const mapWithChecked = (items, allowedArr) => {
    return (Array.isArray(items) ? items : []).map(item => {
      const idStr = item && item._id ? String(item._id) : '';
      const isChecked = allowedArr.includes(idStr);
      return { ...item, isChecked };
    });
  };

  const result = {};

  if (includeGroup) {
    result.groupTab = mapWithChecked(groups, allowedGroupArr);
  }

  if (includeScene) {
    result.sceneTab = mapWithChecked(scenes, allowedSceneArr);
  }

  if (includeTemplate) {
    // return all templates (role allowed) but mark isChecked based on user.allowedResources.controlSection.templateTab
    result.templateTab = mapWithChecked(templates, allowedTemplateArr);
  }

  if (includeDevice) {
    // configured devices for control section; mark based on controlSection.deviceTab
    result.deviceTab = mapWithChecked(configuredDevices, allowedDeviceArr);
  }

  return result;
};

/**
 * Insert campus data for a user
 */
export const insertUserCampusData = async (userId, campusData, currentUser) => {
  try {
    // Validate user ID
    if (!mongoose.Types.ObjectId.isValid(userId)) {
      throw Object.assign(new Error('Invalid user ID format'), { status: 400 });
    }

    // Find user
    const user = await User.findById(userId);
    if (!user || user.isDeleted) {
      throw Object.assign(new Error('User not found'), { status: 404 });
    }

    // Update user with campus data
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      {
        campusData: campusData,
        updatedBy: {
          userId: currentUser._id,
          fullName: currentUser.fullName,
          email: currentUser.email
        },
        updatedDate: new Date().toISOString()
      },
      { 
        new: true, 
        runValidators: true,
        select: '-password' // Exclude password from response
      }
    );

    return {
      message: 'Campus data inserted successfully',
      user: updatedUser,
      campusData: updatedUser.campusData
    };
  } catch (error) {
    throw error;
  }
};

// ...existing imports and code at top
const hasAnyPermissionForFeature = (permissions, moduleType, feature) => {
  try {
    const block = permissions?.[moduleType];
    const feat = block?.[feature];
    if (!feat || typeof feat !== 'object') return false;
    return feat.View === true || feat['Add/Update'] === true || feat.Delete === true;
  } catch {
    return false;
  }
};

const getAllowedFeaturesByAnyPermission = (permissions, moduleType) => {
  const block = permissions?.[moduleType];
  if (!block || typeof block !== 'object') return [];
  return Object.keys(block).filter(f => hasAnyPermissionForFeature(permissions, moduleType, f));
};

const hasAnyPermissionInModule = (permissions, moduleType) =>
  getAllowedFeaturesByAnyPermission(permissions, moduleType).length > 0;

const attachIsChecked = (items, checker /* id => boolean */) =>
  (Array.isArray(items) ? items : []).map(item => ({
    ...item,
    isChecked: checker(item?._id)
  }));

const attachLogsIsChecked = (items, gateBool) =>
  (Array.isArray(items) ? items : []).map(item => ({
    ...item,
    isChecked: Boolean(gateBool)
  }));

const MODULE_LABELS = {
  campusManagement: 'Campus Management',
  intelligentControl: 'Intelligent Control',
  deviceManagement: 'Device Management',
  userManagement: 'User Management',
  logsMonitoring: 'Logs Monitoring',
  controlSection: 'Control Section'
};

/**
 * Get comprehensive module data for role assignment UI
 * 
 * Logic:
 * - Role-only: Include all resources where role has ANY permission (View/Add/Update/Delete)
 *              Mark all as isChecked: true (full role access)
 * - Role + User: Same inclusion criteria, but isChecked reflects user's actual allowedResources
 * 
 * Used in:
 * - Role permission setup interfaces
 * - User permission assignment forms  
 * - Permission audit/review screens
 * 
 * Returns: All module data with permission-aware filtering and checking
 */
export const getModuleDataByRole = async (roleId, userId = null) => {
  if (!mongoose.Types.ObjectId.isValid(roleId)) {
    throw Object.assign(new Error('Invalid role ID format'), { status: 400 });
  }
  const role = await Role.findById(roleId).lean();
  if (!role) throw Object.assign(new Error('Role not found'), { status: 404 });
  if (!role.isActive) throw Object.assign(new Error('Role is not active'), { status: 403 });

  const userMode = Boolean(userId && mongoose.Types.ObjectId.isValid(userId));
  let userDoc = null;
  let ALL_TRUE = !userMode; // role only -> every item checked
  let roleMatches = true; // Default to true for role-only mode
  
  if (userMode) {
    userDoc = await User.findById(userId).lean();
    if (!userDoc) throw Object.assign(new Error('User not found for provided user_id'), { status: 404 });
    
    // Check if payload role_id matches user's current role_id
    roleMatches = String(userDoc.role_id) === String(roleId);
    
    if (!roleMatches) {
      // If role doesn't match, set ALL_TRUE to show all data with isChecked: true
      ALL_TRUE = true;
    } else {
      // If role matches, use existing logic
      // If allowedResources is null or undefined, treat as ALL_TRUE
      if (userDoc.allowedResources == null) {
        ALL_TRUE = true;
      }
    }
  }

  const rolePerms = role.permissions || {};
  // ALL_TRUE is set above

  const modules = [];

  // --- CAMPUS MANAGEMENT ---
  if (hasAnyPermissionInModule(rolePerms, 'CAMPUS_MANAGEMENT')) {
    const feats = getAllowedFeaturesByAnyPermission(rolePerms, 'CAMPUS_MANAGEMENT');
    const raw = await getCampusManagementData(); // { campus, building, floor, zone }
    const cm = {};
    if (feats.includes('campus_management')) {
      cm.campuses = attachIsChecked(
        raw.campus,
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.campusManagement?.campuses || []).map(String).includes(String(id))
      );
    }
    if (feats.includes('building_management')) {
      cm.buildings = attachIsChecked(
        raw.building,
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.campusManagement?.buildings || []).map(String).includes(String(id))
      );
    }
    if (feats.includes('floor_management')) {
      cm.floors = attachIsChecked(
        raw.floor,
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.campusManagement?.floors || []).map(String).includes(String(id))
      );
    }
    if (feats.includes('zone_management')) {
      cm.zones = attachIsChecked(
        raw.zone,
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.campusManagement?.zones || []).map(String).includes(String(id))
      );
    }
    modules.push({ id: 'campusManagement', label: MODULE_LABELS.campusManagement, data: cm });
  }

  // --- INTELLIGENT CONTROL ---
  if (hasAnyPermissionInModule(rolePerms, 'INTELLIGENT_CONTROL')) {
    const feats = getAllowedFeaturesByAnyPermission(rolePerms, 'INTELLIGENT_CONTROL');
    const raw = await getIntelligentControlData(); // { Group, Scene, Sensor, Template }
    const ic = {};
    if (feats.includes('group_management')) {
      ic.groups = attachIsChecked(
        raw.Group,
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.intelligentControl?.groups || []).map(String).includes(String(id))
      );
    }
    if (feats.includes('scene_management')) {
      ic.scenes = attachIsChecked(
        raw.Scene,
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.intelligentControl?.scenes || []).map(String).includes(String(id))
      );
    }
    if (feats.includes('sensor_management')) {
      ic.sensors = attachIsChecked(
        raw.Sensor,
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.intelligentControl?.sensors || []).map(String).includes(String(id))
      );
    }
    if (feats.includes('template_management')) {
      ic.templates = attachIsChecked(
        raw.Template,
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.intelligentControl?.templates || []).map(String).includes(String(id))
      );
    }
    modules.push({ id: 'intelligentControl', label: MODULE_LABELS.intelligentControl, data: ic });
  }

  // --- DEVICE MANAGEMENT ---
  if (hasAnyPermissionInModule(rolePerms, 'DEVICE_MANAGEMENT')) {
    const feats = getAllowedFeaturesByAnyPermission(rolePerms, 'DEVICE_MANAGEMENT');
    if (feats.length > 0) {
      const devices = await Device.find({ is_delete: false })
        .select('_id device_id name type status campus building floor zone capabilities configure_flag createdAt updatedAt')
        .lean();

      const devicesWithChecked = attachIsChecked(
        devices,
        ALL_TRUE
          ? () => true
          : (id) => {
              const deviceManagement = userDoc?.allowedResources?.deviceManagement || {};
              const configuredDevices = deviceManagement.configuredDevices || [];
              const discoveredDevices = deviceManagement.discoveredDevices || [];
              const devices = deviceManagement.devices || [];
              
              return [...configuredDevices, ...discoveredDevices, ...devices]
                .map(String)
                .includes(String(id));
            }
      );

      const dm = {
        discoveredDevices: devicesWithChecked.filter(d => d.configure_flag === false || d.configure_flag === 0),
        configuredDevices: devicesWithChecked.filter(d => d.configure_flag === true || d.configure_flag === 1)
      };

      modules.push({ id: 'deviceManagement', label: MODULE_LABELS.deviceManagement, data: dm });
    }
  }

  // --- USER MANAGEMENT ---
  if (hasAnyPermissionInModule(rolePerms, 'USER_MANAGEMENT')) {
    const feats = getAllowedFeaturesByAnyPermission(rolePerms, 'USER_MANAGEMENT');
    const raw = await getUserManagementData(); // { users, roles }
    const um = {};
    if (feats.includes('user_accounts')) {
      um.users = attachIsChecked(
        raw.users,
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.userManagement?.users || []).map(String).includes(String(id))
      );
    }
    if (feats.includes('role_management')) {
      um.roles = attachIsChecked(
        raw.roles,
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.userManagement?.roles || []).map(String).includes(String(id))
      );
    }
    modules.push({ id: 'userManagement', label: MODULE_LABELS.userManagement, data: um });
  }

  // --- LOGS MONITORING ---
  if (hasAnyPermissionInModule(rolePerms, 'LOGS_MONITORING')) {
    const feats = getAllowedFeaturesByAnyPermission(rolePerms, 'LOGS_MONITORING');
    if (feats.length > 0) {
      const lm = {};

      if (ALL_TRUE) {
        // Role-only mode: set both to true (checked)
        if (feats.some(f => /event/i.test(f))) {
          lm.eventLogs = true;
        }
        if (feats.some(f => /mqtt/i.test(f))) {
          lm.mqttLogs = true;
        }
      } else {
        // User mode: return exact stored data from database
        const userLogsMonitoring = userDoc?.allowedResources?.logsMonitoring;
        
        if (feats.some(f => /event/i.test(f))) {
          lm.eventLogs = userLogsMonitoring?.eventLogs !== undefined 
            ? userLogsMonitoring.eventLogs 
            : [];
        }
        if (feats.some(f => /mqtt/i.test(f))) {
          lm.mqttLogs = userLogsMonitoring?.mqttLogs !== undefined 
            ? userLogsMonitoring.mqttLogs 
            : [];
        }
      }

      modules.push({ id: 'logsMonitoring', label: MODULE_LABELS.logsMonitoring, data: lm });
    }
  }

  // --- CONTROL SECTION ---
  if (hasAnyPermissionInModule(rolePerms, 'CONTROL_SECTION')) {
    const controlPerms = rolePerms?.CONTROL_SECTION || {};
    const anyTrue = (obj) => obj && typeof obj === 'object' && Object.values(obj).some(v => v === true);

    const includeTemplate = anyTrue(controlPerms.template_tab);
    const includeGroup   = anyTrue(controlPerms.group_tab);
    const includeScene   = anyTrue(controlPerms.scene_tab);
    const includeDevice  = anyTrue(controlPerms.device_tab);

    const raw = await getControlSectionData(); // groups, scenes, configuredDevices, templates
    const cs = {};

    if (includeGroup) {
      cs.groupTab = attachIsChecked(
        raw.groups,
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.controlSection?.groupTab || []).map(String).includes(String(id))
      );
    }
    if (includeScene) {
      cs.sceneTab = attachIsChecked(
        raw.scenes,
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.controlSection?.sceneTab || []).map(String).includes(String(id))
      );
    }
    if (includeTemplate) {
      cs.templateTab = attachIsChecked(
        raw.templates,
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.controlSection?.templateTab || []).map(String).includes(String(id))
      );
    }
    if (includeDevice) {
      cs.deviceTab = attachIsChecked(
        raw.configuredDevices, // controlSection uses configured devices
        ALL_TRUE
          ? () => true
          : (id) => (userDoc?.allowedResources?.controlSection?.deviceTab || []).map(String).includes(String(id))
      );
    }

    modules.push({ id: 'controlSection', label: MODULE_LABELS.controlSection, data: cs });
  }

  return modules;
};
