/**
 * Widget Service - Comprehensive dashboard component and data visualization backend
 * 
 * Flow: widget.controller.js → widget.service.js → MongoDB (Multiple Collections + External APIs)
 * 
 * Provides enterprise widget capabilities:
 * - Timezone management with global predefined data and lifecycle operations
 * - Weather integration with Open-Meteo API for real-time data and forecasting
 * - AQI monitoring with air quality tracking and location-based services
 * - Widget storage system for dashboard customization and layout persistence
 * - Multi-city temperature monitoring with bulk processing capabilities
 * - Real-time data synchronization with automated refresh mechanisms
 * - Location-timezone handling for accurate time-based data representation
 */

/**
 * Deactivate any other active weather record for the same location except the current one
 */
export const deactivateOtherActiveWeatherRecords = async (currentId, lat, long, placeName) => {
  try {
    await Weather.updateMany(
      {
        _id: { $ne: currentId },
        lat,
        long,
        placeName,
        isActive: true,
        isDeleted: false
      },
      { $set: { isActive: false } }
    );
  } catch (error) {
    throw new Error(`Error deactivating other active weather records: ${error.message}`);
  }
};
import { MasterTimezone } from '../models/MasterTimezone.js';
import { Weather } from '../models/Weather.js';
import { WidgetStorage } from '../models/WidgetStorage.js';
import { User } from '../models/User.js';
import { Types } from 'mongoose';
import axios from 'axios';

/**
 * Get all active timezones for widget dropdown display
 * 
 * Returns filtered timezone list:
 * - Only active (isActive=true) and added (is_added=true) timezones
 * - Excludes deleted timezones for clean UI presentation
 * - Sorted by updatedAt for consistent ordering
 * - Minimal fields for optimized frontend performance
 */
export const getAllTimezones = async () => {
  try {
    return await MasterTimezone.find({ 
      isDeleted: false, 
      isActive: true,
      is_added: true
    }).select('timeZoneName timeZoneValue').sort({ updatedAt: 1 });
  } catch (error) {
    throw new Error(`Error fetching timezones: ${error.message}`);
  }
};

/**
 * Get all timezones including inactive ones (excludes only deleted)
 */
export const getAllTimezonesIncludingInactive = async () => {
  try {
    return await MasterTimezone.find({ 
      isDeleted: false 
    }).select('timeZoneName timeZoneValue isActive createdDate updatedDate').sort({ updatedAt: 1 });
  } catch (error) {
    throw new Error(`Error fetching all timezones: ${error.message}`);
  }
};

/**
 * Get timezone by ID
 */
export const getTimezoneById = async (timezoneId) => {
  try {
    return await MasterTimezone.findById(timezoneId);
  } catch (error) {
    throw new Error(`Error finding timezone by ID: ${error.message}`);
  }
};

/**
 * Get timezone by name
 */
export const getTimezoneByName = async (timeZoneName) => {
  try {
    return await MasterTimezone.findOne({ 
      timeZoneName, 
      isDeleted: false 
    });
  } catch (error) {
    throw new Error(`Error finding timezone by name: ${error.message}`);
  }
};

/**
 * Get timezone by value
 */
export const getTimezoneByValue = async (timeZoneValue) => {
  try {
    return await MasterTimezone.findOne({ 
      timeZoneValue, 
      isDeleted: false 
    });
  } catch (error) {
    throw new Error(`Error finding timezone by value: ${error.message}`);
  }
};

/**
 * Create new timezone
 */
export const createTimezone = async (timezoneData) => {
  try {
    const timezone = new MasterTimezone(timezoneData);
    return await timezone.save();
  } catch (error) {
    if (error.code === 11000) {
      throw new Error('Timezone with this name already exists');
    }
    throw error;
  }
};

/**
 * Create or activate timezone
 * If timezone exists, activate it and update metadata
 * If timezone doesn't exist, create new one with isActive: true
 */
export const createOrActivateTimezone = async (timezoneData) => {
  try {
    const { timeZoneName, timeZoneValue, createdBy } = timezoneData;
    
    // Check if timezone already exists (including inactive and deleted ones)
    const existing = await MasterTimezone.findOne({ 
      timeZoneName 
    });
    
    if (existing) {
      // Update existing timezone to active status and trigger updatedAt
      const updatedTimezone = await MasterTimezone.findByIdAndUpdate(
        existing._id,
        { 
          isActive: true,
          isDeleted: false,
          is_added: true,
          timeZoneValue, // Update value in case it changed
          updatedDate: new Date().toISOString(),
          updatedBy: createdBy
        },
        { new: true }
      );
      
      return {
        status: 'activated',
        data: updatedTimezone
      };
    } else {
      // Create new timezone with isActive: true and is_added: true
      const newTimezoneData = {
        ...timezoneData,
        isActive: true,
        is_added: true
      };
      
      const timezone = new MasterTimezone(newTimezoneData);
      const savedTimezone = await timezone.save();
      
      return {
        status: 'created',
        data: savedTimezone
      };
    }
  } catch (error) {
    throw new Error(`Error creating or activating timezone: ${error.message}`);
  }
};





/**
 * Activate/deactivate timezone
 */
export const toggleTimezoneStatus = async (timezoneId, isActive, updatedBy) => {
  try {
    return await MasterTimezone.findByIdAndUpdate(
      timezoneId,
      { 
        isActive,
        updatedDate: new Date().toISOString(),
        updatedBy
      },
      { new: true }
    );
  } catch (error) {
    throw new Error(`Error updating timezone status: ${error.message}`);
  }
};

/**
 * Update timezone information
 */
export const updateTimezone = async (timezoneId, updateData) => {
  try {
    // Get the current timezone being updated
    const currentTimezone = await MasterTimezone.findById(timezoneId);
    if (!currentTimezone) {
      throw new Error('Timezone not found');
    }
    
    // Check if timezone with same timeZoneValue already exists
    const existingTimezone = await MasterTimezone.findOne({
      timeZoneValue: updateData.timeZoneValue,
      _id: { $ne: timezoneId }
    });
    
    if (existingTimezone) {
      // Transfer the updatedAt from current timezone to existing timezone
      await MasterTimezone.findByIdAndUpdate(existingTimezone._id, {
        $set: { 
          updatedAt: currentTimezone.updatedAt,
          updatedDate: updateData.updatedDate,
          updatedBy: updateData.updatedBy,
          isActive: true,
          is_added: true
        }
      }, { timestamps: false });
      
      // Mark current timezone as inactive and not deleted
      await MasterTimezone.findByIdAndUpdate(timezoneId, {
        isActive: false,
        isDeleted: false,
        is_added: false
      }, { timestamps: false });
      
      return {
        status: 'transferred',
        message: 'UpdatedAt transferred to existing timezone and current timezone deactivated',
        data: await MasterTimezone.findById(existingTimezone._id)
      };
    }
    
    // Check if new timezone name already exists (excluding current timezone)
    if (updateData.timeZoneName) {
      const existingByName = await MasterTimezone.findOne({
        timeZoneName: updateData.timeZoneName,
        _id: { $ne: timezoneId }
      });
      
      if (existingByName) {
        // Handle different scenarios based on existing timezone status
        if (existingByName.isDeleted) {
          // If existing timezone is deleted, restore it and delete the current one
          await MasterTimezone.findByIdAndUpdate(existingByName._id, {
            isDeleted: false,
            isActive: true,
            is_added: true,
            timeZoneValue: updateData.timeZoneValue,
            updatedDate: updateData.updatedDate,
            updatedBy: updateData.updatedBy
          }, { timestamps: false });
          
          // Mark current timezone as deleted
          await MasterTimezone.findByIdAndUpdate(timezoneId, {
            isDeleted: true,
            deletedDate: new Date().toISOString(),
            deletedBy: updateData.updatedBy
          }, { timestamps: false });
          
          return {
            status: 'restored',
            message: 'Existing timezone restored and current timezone removed',
            data: await MasterTimezone.findById(existingByName._id)
          };
        } else if (!existingByName.isActive) {
          // If existing timezone is inactive, activate it and delete current one
          await MasterTimezone.findByIdAndUpdate(existingByName._id, {
            isActive: true,
            is_added: true,
            timeZoneValue: updateData.timeZoneValue,
            updatedDate: updateData.updatedDate,
            updatedBy: updateData.updatedBy
          }, { timestamps: false });
          
          // Mark current timezone as deleted
          await MasterTimezone.findByIdAndUpdate(timezoneId, {
            isDeleted: true,
            deletedDate: new Date().toISOString(),
            deletedBy: updateData.updatedBy
          }, { timestamps: false });
          
          return {
            status: 'activated',
            message: 'Existing timezone activated and current timezone removed',
            data: await MasterTimezone.findById(existingByName._id)
          };
        } else {
          // If existing timezone is active, merge with current and delete current
          await MasterTimezone.findByIdAndUpdate(existingByName._id, {
            timeZoneValue: updateData.timeZoneValue,
            is_added: true,
            updatedDate: updateData.updatedDate,
            updatedBy: updateData.updatedBy
          }, { timestamps: false });
          
          // Mark current timezone as deleted and set is_added to false
          await MasterTimezone.findByIdAndUpdate(timezoneId, {
            isDeleted: false,
            is_added: false,
            deletedDate: new Date().toISOString(),
            deletedBy: updateData.updatedBy
          }, { timestamps: false });
          
          return {
            status: 'merged',
            message: 'Merged with existing active timezone and current timezone removed',
            data: await MasterTimezone.findById(existingByName._id)
          };
        }
      }
    }
    
    // If no existing timezone found, proceed with normal update without updating timestamps
    const updatedTimezone = await MasterTimezone.findByIdAndUpdate(
      timezoneId,
      updateData,
      { new: true, timestamps: false }
    );
    
    return {
      status: 'updated',
      message: 'Timezone updated successfully',
      data: updatedTimezone
    };
  } catch (error) {
    throw new Error(`Error updating timezone: ${error.message}`);
  }
};



/**
 * Bulk insert timezones with the predefined data
 */
export const bulkInsertTimezones = async (timezonesData, createdBy) => {
  try {
    const results = [];
    
    for (const timezoneData of timezonesData) {
      // Check if timezone already exists
      const existing = await MasterTimezone.findOne({ 
        timeZoneName: timezoneData.timeZoneName 
      });
      
      if (!existing) {
        const timezone = new MasterTimezone({
          ...timezoneData,
          createdBy,
          createdDate: new Date().toISOString()
        });
        const saved = await timezone.save();
        results.push({ status: 'created', data: saved });
      } else {
        results.push({ 
          status: 'exists', 
          data: existing, 
          message: `${timezoneData.timeZoneName} already exists` 
        });
      }
    }
    
    return results;
  } catch (error) {
    throw new Error(`Error bulk inserting timezones: ${error.message}`);
  }
};

/**
 * Get comprehensive weather information by location coordinates
 * 
 * Integrates with Open-Meteo API for:
 * - Location timezone detection for accurate time representation
 * - Daily weather data: sunset/sunrise, min/max temperatures
 * - Hourly data: weather codes, temperature, humidity, wind, UV index
 * - Air Quality Index (AQI) data: PM2.5, PM10, US AQI standards
 * - Smart location handling with duplicate prevention
 * - User attribution and audit trail tracking
 */
export const getWeatherInfo = async (userId, lat, long, placeName) => {
  try {
    const user = await User.findById(userId);
    if (!user) throw new Error('User not found');

    // Check if weather data already exists for this location (not deleted)
    const existingWeather = await Weather.findOne({
      userId,
      lat,
      long,
      isDeleted: false
    });

    // Get timezone for the location first
    const timezoneUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${long}&timezone=auto&forecast_days=1`;
    const timezoneResponse = await axios.get(timezoneUrl, {
      timeout: parseInt(process.env.API_TIMEOUT) || 30000,
      headers: { 'User-Agent': 'MPS-API/1.0' }
    });
    
    const timezone = timezoneResponse.data?.timezone || 'UTC';
    
    // Use the location-specific timezone for weather data
    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${long}&timezone=${timezone}&daily=sunset,sunrise,temperature_2m_max,temperature_2m_min&hourly=weather_code,temperature_2m,dew_point_2m,cloud_cover,apparent_temperature,relative_humidity_2m,surface_pressure,wind_speed_10m,visibility,uv_index,sunshine_duration&forecast_days=1`;
    const aqiUrl = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${long}&timezone=${timezone}&hourly=us_aqi,pm10,pm2_5&forecast_days=1`;

    const axiosConfig = {
      timeout: parseInt(process.env.API_TIMEOUT) || 30000,
      headers: {
        'User-Agent': 'MPS-API/1.0'
      }
    };

    const [weatherResponse, aqiResponse] = await Promise.allSettled([
      axios.get(weatherUrl, axiosConfig),
      axios.get(aqiUrl, axiosConfig)
    ]);
    
    if (weatherResponse.status === 'rejected' || !weatherResponse.value?.data) {
      throw new Error('Weather API did not return data');
    }

    const weatherData = weatherResponse.value.data;
    
    // Merge AQI data if available
    if (aqiResponse.status === 'fulfilled' && aqiResponse.value?.data?.hourly) {
      const aqiHourly = aqiResponse.value.data.hourly;
      if (aqiHourly.us_aqi) weatherData.hourly.us_aqi = aqiHourly.us_aqi;
      if (aqiHourly.pm10) weatherData.hourly.pm10 = aqiHourly.pm10;
      if (aqiHourly.pm2_5) weatherData.hourly.pm2_5 = aqiHourly.pm2_5;
    }
    const lastTimeArray = weatherData.hourly?.time || [];
    const lastWeatherDate = lastTimeArray.length ? lastTimeArray[lastTimeArray.length - 1] : null;

    if (existingWeather) {
      existingWeather.weatherData = weatherData;
      existingWeather.lastWeatherDate = lastWeatherDate;
      existingWeather.updatedBy = {
        userId: user._id,
        fullName: user.fullName,
        email: user.email
      };
      existingWeather.updatedDate = new Date().toISOString();

      await existingWeather.save();

      return {
        status: 'exists',
        data: existingWeather
      };
    }

    const weatherPayload = {
      userId,
      lat,
      long,
      placeName,
      lastWeatherDate,
      weatherData,
      createdBy: {
        userId: user._id,
        fullName: user.fullName,
        email: user.email
      },
      createdDate: new Date().toISOString()
    };

    const newWeather = new Weather(weatherPayload);
    const savedWeather = await newWeather.save();

    return {
      status: 'created',
      data: savedWeather
    };

  } catch (error) {
    throw new Error(`Error getting weather info: ${error.message}`);
  }
};

/**
 * Get weather data by user ID
 */
export const getWeatherByUserId = async (userId) => {
  try {
    return await Weather.find({ 
      userId, 
      isDeleted: false 
    }).sort({ createdAt: -1 });
  } catch (error) {
    throw new Error(`Error fetching weather by user ID: ${error.message}`);
  }
};

/**
 * Get weather data by coordinates
 */
export const getWeatherByCoordinates = async (lat, long) => {
  try {
    return await Weather.findOne({ 
      lat, 
      long, 
      isDeleted: false 
    }).populate('userId', 'fullName email');
  } catch (error) {
    throw new Error(`Error fetching weather by coordinates: ${error.message}`);
  }
};

/**
 * Get current temperature for multiple cities
 */
export const getCurrentTemperatures = async (cities) => {
  try {
    const temperaturePromises = cities.map(async (city) => {
      try {
        // Fetch current weather data for each city using forecast endpoint
        const weatherBaseUrl = process.env.WEATHER_API_URL || 'https://api.open-meteo.com';
        const axiosConfig = {
          timeout: parseInt(process.env.API_TIMEOUT) || 30000,
          headers: { 'User-Agent': 'MPS-API/1.0' }
        };
        
        // Get timezone first
        const timezoneResponse = await axios.get(
          `${weatherBaseUrl}/v1/forecast?latitude=${city.lat}&longitude=${city.long}&timezone=auto&forecast_days=1`,
          axiosConfig
        );
        const timezone = timezoneResponse.data?.timezone || 'UTC';
        
        const response = await axios.get(
          `${weatherBaseUrl}/v1/forecast?latitude=${city.lat}&longitude=${city.long}&current_weather=true&hourly=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timezone=${timezone}&forecast_days=1`,
          axiosConfig
        );

        const currentWeather = response.data.current_weather;
        const hourlyData = response.data.hourly;
        
        // Find the current hour's data
        const currentHour = new Date().toISOString().slice(0, 13) + ':00';
        const currentIndex = hourlyData.time.findIndex(time => time.startsWith(currentHour.slice(0, 13)));
        
        return {
          cityName: city.cityName,
          lat: city.lat,
          long: city.long,
          temperature: currentWeather.temperature,
          humidity: currentIndex >= 0 ? hourlyData.relative_humidity_2m[currentIndex] : null,
          weatherCode: currentWeather.weathercode,
          windSpeed: currentWeather.windspeed,
          time: currentWeather.time,
          timezone: response.data.timezone,
          status: 'success'
        };
      } catch (error) {
        return {
          cityName: city.cityName,
          lat: city.lat,
          long: city.long,
          temperature: null,
          error: error.message,
          status: 'error'
        };
      }
    });

    const results = await Promise.all(temperaturePromises);
    
    return {
      totalCities: cities.length,
      successCount: results.filter(r => r.status === 'success').length,
      errorCount: results.filter(r => r.status === 'error').length,
      cities: results,
      fetchedAt: new Date().toISOString()
    };
  } catch (error) {
    throw new Error(`Error fetching city temperatures: ${error.message}`);
  }
};

/**
 * Get all weather data (active and not deleted) for current hour index - Returns all times in UTC
 */
export const getAllWeatherData = async () => {
  try {
    const weatherRecords = await Weather.find({ isActive: true, isDeleted: false }).sort({ createdAt: 1 });
    
    return weatherRecords.map(record => {
      const hourlyData = record.weatherData?.hourly;
      const dailyData = record.weatherData?.daily;
      
      if (!hourlyData?.time || !hourlyData.time.length) {
        return { 
          _id: record._id, 
          lat: record.lat, 
          long: record.long, 
          placeName: record.placeName, 
          currentHourData: null 
        };
      }
      
      // Get timezone info from weather data
      const storedTimezone = record.weatherData?.timezone || 'UTC';
      const utcOffsetSeconds = record.weatherData?.utc_offset_seconds || 0;
      
      // Get current time in UTC
      const now = new Date();
      const utcTime = new Date(now.getTime()); // Already in UTC
      const utcTimeISO = utcTime.toISOString().slice(0, 13) + ':00';
      
      // Determine the actual timezone for this location based on coordinates
      // This is a simple mapping for known problematic locations
      let actualTimezone = storedTimezone;
      
      // Special handling for India (coordinates around 22.75, 75.89 = Indore)
      if (record.lat >= 6 && record.lat <= 37 && record.long >= 68 && record.long <= 97) {
        actualTimezone = 'Asia/Kolkata'; // India timezone
      }
      // Add more regions as needed
      
      // Calculate current time in the actual location timezone  
      let locationTime;
      if (actualTimezone !== storedTimezone && (storedTimezone === 'GMT' || storedTimezone === 'UTC')) {
        // Data stored in GMT but location is in a different timezone
        locationTime = new Date(now.toLocaleString("en-US", {timeZone: actualTimezone}));
      } else if (storedTimezone === 'GMT' || storedTimezone === 'UTC') {
        // Use UTC offset from weather data
        locationTime = new Date(now.getTime() + (utcOffsetSeconds * 1000));
      } else {
        // Use the stored timezone
        locationTime = new Date(now.toLocaleString("en-US", {timeZone: storedTimezone}));
      }
      
      // Format location time to match the stored data format
      const locationYear = locationTime.getFullYear();
      const locationMonth = String(locationTime.getMonth() + 1).padStart(2, '0');
      const locationDay = String(locationTime.getDate()).padStart(2, '0');
      const locationHour = String(locationTime.getHours()).padStart(2, '0');
      const locationTimeISO = `${locationYear}-${locationMonth}-${locationDay}T${locationHour}:00`;
      
      // Find the exact or closest time index to current location time
      let hourIndex = hourlyData.time.findIndex(time => time === locationTimeISO);
      if (hourIndex === -1) {
        // If exact match not found, find the closest previous time that exists
        const availableTimes = hourlyData.time.map((time, index) => ({ time, index }));
        const targetTime = new Date(locationTimeISO).getTime();
        
        // Find the closest time that is not in the future
        let closestIndex = -1;
        let closestDiff = Infinity;
        
        availableTimes.forEach(({ time, index }) => {
          const timeMs = new Date(time).getTime();
          const diff = targetTime - timeMs;
          
          // Only consider times that are not in the future (diff >= 0)
          if (diff >= 0 && diff < closestDiff) {
            closestDiff = diff;
            closestIndex = index;
          }
        });
        
        // If no past time found, use the last available time
        hourIndex = closestIndex >= 0 ? closestIndex : hourlyData.time.length - 1;
      }
      
      // Determine if it's day or night based on location time
      const currentTime = hourlyData.time[hourIndex];
      const sunrise = dailyData?.sunrise?.[0];
      const sunset = dailyData?.sunset?.[0];
      let is_day = null;
      
      if (currentTime && sunrise && sunset) {
        const currentTimeMs = new Date(currentTime).getTime();
        const sunriseMs = new Date(sunrise).getTime();
        const sunsetMs = new Date(sunset).getTime();
        is_day = currentTimeMs >= sunriseMs && currentTimeMs < sunsetMs;
      }
      
      // Convert sunset and sunrise to UTC
      let sunriseUTC = null;
      let sunsetUTC = null;
      
      if (sunrise) {
        // The sunrise/sunset times are in local timezone, need to convert to UTC
        // They come as "2025-11-10T06:28" and need location timezone context
        const sunriseLocalDate = new Date(sunrise);
        
        // Calculate UTC offset for the location
        const tempDate = new Date();
        const utcTime = tempDate.getTime() + tempDate.getTimezoneOffset() * 60000;
        const locationTempTime = new Date(utcTime + (record.weatherData?.utc_offset_seconds || 0) * 1000);
        const locationOffset = locationTempTime.getTimezoneOffset() - tempDate.getTimezoneOffset();
        
        // Apply offset to convert local sunrise to UTC
        const sunriseUTCTime = sunriseLocalDate.getTime() - (record.weatherData?.utc_offset_seconds || 0) * 1000;
        sunriseUTC = new Date(sunriseUTCTime).toISOString();
      }
      
      if (sunset) {
        // The sunset time is in local timezone, need to convert to UTC
        const sunsetLocalDate = new Date(sunset);
        
        // Apply offset to convert local sunset to UTC
        const sunsetUTCTime = sunsetLocalDate.getTime() - (record.weatherData?.utc_offset_seconds || 0) * 1000;
        sunsetUTC = new Date(sunsetUTCTime).toISOString();
      }
      
      return {
        _id: record._id,
        lat: record.lat,
        long: record.long,
        placeName: record.placeName,
        currentHourData: {
          time: utcTimeISO, // Show current UTC time instead of local time
          weather_code: hourlyData.weather_code?.[hourIndex] !== undefined ? hourlyData.weather_code[hourIndex] : null,
          temperature_2m: hourlyData.temperature_2m?.[hourIndex] ?? null,
          dew_point_2m: hourlyData.dew_point_2m?.[hourIndex] ?? null,
          cloud_cover: hourlyData.cloud_cover?.[hourIndex] !== undefined ? hourlyData.cloud_cover[hourIndex] : null,
          apparent_temperature: hourlyData.apparent_temperature?.[hourIndex] ?? null,
          relative_humidity_2m: hourlyData.relative_humidity_2m?.[hourIndex] ?? null,
          surface_pressure: hourlyData.surface_pressure?.[hourIndex] ?? null,
          wind_speed_10m: hourlyData.wind_speed_10m?.[hourIndex] !== undefined ? hourlyData.wind_speed_10m[hourIndex] : null,
          visibility: hourlyData.visibility?.[hourIndex] ?? null,
          uv_index: hourlyData.uv_index?.[hourIndex] !== undefined ? hourlyData.uv_index[hourIndex] : null,
          sunshine_duration: hourlyData.sunshine_duration?.[hourIndex] !== undefined ? hourlyData.sunshine_duration[hourIndex] : null,
          us_aqi: hourlyData.us_aqi?.[hourIndex] ?? null,
          pm10: hourlyData.pm10?.[hourIndex] ?? null,
          pm2_5: hourlyData.pm2_5?.[hourIndex] ?? null,
          sunset: sunsetUTC,
          sunrise: sunriseUTC,
          temperature_2m_max: dailyData?.temperature_2m_max?.[0] || null,
          temperature_2m_min: dailyData?.temperature_2m_min?.[0] || null,
          is_day,
          timezone: "UTC" // Always UTC
        }
      };
    });
  } catch (error) {
    throw new Error(`Error fetching all weather data: ${error.message}`);
  }
};



/**
 * Get first weather data (active and not deleted)
 */
export const getFirstWeatherData = async () => {
  try {
    const allWeatherData = await getAllWeatherData();
    return allWeatherData.length > 0 ? allWeatherData[0] : null;
  } catch (error) {
    throw new Error(`Error fetching first weather data: ${error.message}`);
  }
};

/**
 * Get weather by ID
 */
export const getWeatherById = async (weatherId) => {
  try {
    return await Weather.findById(weatherId);
  } catch (error) {
    throw new Error(`Error finding weather by ID: ${error.message}`);
  }
};

/**
 * Update weather information
 */
export const updateWeather = async (weatherId, updateData) => {
  try {
    const updatedWeather = await Weather.findByIdAndUpdate(
      weatherId,
      updateData,
      { new: true }
    );
    
    return {
      status: 'updated',
      message: 'Weather updated successfully',
      data: updatedWeather
    };
  } catch (error) {
    throw new Error(`Error updating weather: ${error.message}`);
  }
};

/**
 * Update weather information with fresh data
 */
export const updateWeatherWithFreshData = async (weatherId, lat, long, placeName, userId) => {
  try {
    const user = await User.findById(userId);
    if (!user) throw new Error('User not found');

    // Check if weather record exists
    const existingWeather = await Weather.findById(weatherId);
    if (!existingWeather) {
      throw new Error('Weather record not found');
    }

    // Get timezone for the location first
    const timezoneUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${long}&timezone=auto&forecast_days=1`;
    const timezoneResponse = await axios.get(timezoneUrl, {
      timeout: parseInt(process.env.API_TIMEOUT) || 30000,
      headers: { 'User-Agent': 'MPS-API/1.0' }
    });
    
    const timezone = timezoneResponse.data?.timezone || 'UTC';
    
    // Fetch fresh weather data from API with location timezone
    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${long}&timezone=${timezone}&daily=sunset,sunrise,temperature_2m_max,temperature_2m_min&hourly=weather_code,temperature_2m,dew_point_2m,cloud_cover,apparent_temperature,relative_humidity_2m,surface_pressure,wind_speed_10m,visibility,uv_index,sunshine_duration&forecast_days=1`;
    const aqiUrl = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${long}&timezone=${timezone}&hourly=us_aqi,pm10,pm2_5&forecast_days=1`;

    const axiosConfig = {
      timeout: parseInt(process.env.API_TIMEOUT) || 30000,
      headers: { 'User-Agent': 'MPS-API/1.0' }
    };

    const [weatherResponse, aqiResponse] = await Promise.allSettled([
      axios.get(weatherUrl, axiosConfig),
      axios.get(aqiUrl, axiosConfig)
    ]);
    
    if (weatherResponse.status === 'rejected' || !weatherResponse.value?.data) {
      throw new Error('Weather API did not return data');
    }

    const weatherData = weatherResponse.value.data;
    
    // Merge AQI data if available
    if (aqiResponse.status === 'fulfilled' && aqiResponse.value?.data?.hourly) {
      const aqiHourly = aqiResponse.value.data.hourly;
      if (aqiHourly.us_aqi) weatherData.hourly.us_aqi = aqiHourly.us_aqi;
      if (aqiHourly.pm10) weatherData.hourly.pm10 = aqiHourly.pm10;
      if (aqiHourly.pm2_5) weatherData.hourly.pm2_5 = aqiHourly.pm2_5;
    }

    const lastTimeArray = weatherData.hourly?.time || [];
    const lastWeatherDate = lastTimeArray.length ? lastTimeArray[lastTimeArray.length - 1] : null;
    
    // Update the existing record with new location and fresh weather data
    const updateData = {
      lat,
      long,
      placeName,
      weatherData,
      lastWeatherDate,
      updatedBy: {
        userId: user._id,
        fullName: user.fullName,
        email: user.email
      },
      updatedDate: new Date().toISOString()
    };

    const updatedWeather = await Weather.findByIdAndUpdate(
      weatherId,
      updateData,
      { new: true }
    );
    
    return {
      status: 'updated',
      message: 'Weather updated with fresh data successfully',
      data: updatedWeather
    };
  } catch (error) {
    throw new Error(`Error updating weather with fresh data: ${error.message}`);
  }
};

/**
 * Get real-time AQI and temperature for current hour
 * 
 * Provides location-specific current conditions:
 * - Timezone detection for accurate "current hour" calculation
 * - US AQI standards for air quality monitoring
 * - Temperature data with location-timezone adjustment
 * - Graceful error handling with null fallbacks
 * - Optimized for public endpoint performance
 */
export const getAqiAndTemperatureCurrentHour = async (lat, long) => {
  try {
    const weatherBaseUrl = process.env.WEATHER_API_URL || 'https://api.open-meteo.com';
    const aqiBaseUrl = process.env.AQI_API_URL || 'https://air-quality-api.open-meteo.com';
    
    const axiosConfig = {
      timeout: parseInt(process.env.API_TIMEOUT) || 30000,
      headers: { 'User-Agent': 'MPS-API/1.0' }
    };
    
    // Get timezone for the location
    const timezoneResponse = await axios.get(
      `${weatherBaseUrl}/v1/forecast?latitude=${lat}&longitude=${long}&timezone=auto&forecast_days=1`,
      axiosConfig
    );
    const timezone = timezoneResponse.data?.timezone || 'UTC';
    
    // Calculate current time in location timezone
    const now = new Date();
    const locationTime = new Date(now.toLocaleString("en-US", {timeZone: timezone}));
    const yyyy = locationTime.getFullYear();
    const mm = String(locationTime.getMonth() + 1).padStart(2, '0');
    const dd = String(locationTime.getDate()).padStart(2, '0');
    const hh = String(locationTime.getHours()).padStart(2, '0');
    const today = `${yyyy}-${mm}-${dd}`;
    const currentHourIso = `${today}T${hh}:00`;
    
    const weatherUrl = `${weatherBaseUrl}/v1/forecast?latitude=${lat}&longitude=${long}&hourly=temperature_2m&timezone=${timezone}&start_date=${today}&end_date=${today}`;
    const aqiUrl = `${aqiBaseUrl}/v1/air-quality?latitude=${lat}&longitude=${long}&hourly=us_aqi&timezone=${timezone}&start_date=${today}&end_date=${today}`;

    const [weatherResponse, airQualityResponse] = await Promise.allSettled([
      axios.get(weatherUrl, axiosConfig),
      axios.get(aqiUrl, axiosConfig)
    ]);

    if (weatherResponse.status === 'rejected' && airQualityResponse.status === 'rejected') {
      return {
        time: currentHourIso,
        temperature_2m: null,
        us_aqi: null,
        error: 'External APIs unavailable'
      };
    }

    const weatherData = weatherResponse.status === 'fulfilled' ? weatherResponse.value.data : null;
    const aqiData = airQualityResponse.status === 'fulfilled' ? airQualityResponse.value.data : null;

    const weatherTimes = weatherData?.hourly?.time || [];
    const aqiTimes = aqiData?.hourly?.time || [];
    const weatherIdx = weatherTimes.indexOf(currentHourIso);
    const aqiIdx = aqiTimes.indexOf(currentHourIso);

    const temperature_2m = (weatherIdx !== -1 && weatherData?.hourly?.temperature_2m)
      ? weatherData.hourly.temperature_2m[weatherIdx]
      : null;
    const us_aqi = (aqiIdx !== -1 && aqiData?.hourly?.us_aqi)
      ? aqiData.hourly.us_aqi[aqiIdx]
      : null;

    return {
      time: currentHourIso,
      temperature_2m,
      us_aqi
    };
  } catch (error) {
    return {
      time: new Date().toISOString(),
      temperature_2m: null,
      us_aqi: null,
      error: 'Service temporarily unavailable'
    };
  }
};

/**
 * Add widgets to user storage for dashboard customization
 * 
 * Creates new widget storage configuration:
 * - User-specific widget layouts and arrangements
 * - Supports complex widget structure arrays
 * - Always creates new storage (no updates) for data integrity
 * - Enables personalized dashboard experiences
 */
export const addWidgets = async (userId, widgets) => {
  try {
    // Always create new widget storage instead of updating existing ones
    const widgetStorage = new WidgetStorage({
      userId,
      structure: widgets
    });
    
    const saved = await widgetStorage.save();
    return { status: 'created', data: saved };
  } catch (error) {
    throw new Error(`Error adding widgets: ${error.message}`);
  }
};

/**
 * Update widgets storage
 */
export const updateWidgets = async (id, widgets) => {
  try {
    const updated = await WidgetStorage.findByIdAndUpdate(
      id,
      { structure: widgets },
      { new: true }
    );
    return { status: 'updated', data: updated };
  } catch (error) {
    throw new Error(`Error updating widgets: ${error.message}`);
  }
};

/**
 * Get widget configuration with real-time weather data integration
 * 
 * Provides enriched widget data:
 * - Base widget configuration from storage
 * - Real-time weather data injection for weather widgets
 * - Current hour data calculation with timezone handling
 * - Weather map generation for efficient data lookup
 * - Dynamic widget content updates with live API data
 */
export const getWidgetById = async (id) => {
  try {
    const widget = await WidgetStorage.findById(id);
    if (!widget) return null;
    
    const weatherData = await Weather.find({ isActive: true, isDeleted: false });
    
    const weatherMap = {};
    
    for (const weather of weatherData) {
      const hourlyData = weather.weatherData?.hourly;
      const dailyData = weather.weatherData?.daily;
      
      if (hourlyData?.time && hourlyData.time.length) {
        // Get timezone info from weather data
        const storedTimezone = weather.weatherData?.timezone || 'UTC';
        const utcOffsetSeconds = weather.weatherData?.utc_offset_seconds || 0;
        
        // Get current time in UTC
        const now = new Date();
        const utcTimeISO = now.toISOString().slice(0, 13) + ':00';
        
        // Determine the actual timezone for this location based on coordinates
        let actualTimezone = storedTimezone;
        
        // Special handling for India (coordinates around 22.75, 75.89 = Indore)
        if (weather.lat >= 6 && weather.lat <= 37 && weather.long >= 68 && weather.long <= 97) {
          actualTimezone = 'Asia/Kolkata'; // India timezone
        }
        // Add more regions as needed
        
        // Calculate current time in the actual location timezone  
        let locationTime;
        if (actualTimezone !== storedTimezone && (storedTimezone === 'GMT' || storedTimezone === 'UTC')) {
          // Data stored in GMT but location is in a different timezone
          locationTime = new Date(now.toLocaleString("en-US", {timeZone: actualTimezone}));
        } else if (storedTimezone === 'GMT' || storedTimezone === 'UTC') {
          // Use UTC offset from weather data
          locationTime = new Date(now.getTime() + (utcOffsetSeconds * 1000));
        } else {
          // Use the stored timezone
          locationTime = new Date(now.toLocaleString("en-US", {timeZone: storedTimezone}));
        }
        
        // Format location time to match the stored data format
        const locationYear = locationTime.getFullYear();
        const locationMonth = String(locationTime.getMonth() + 1).padStart(2, '0');
        const locationDay = String(locationTime.getDate()).padStart(2, '0');
        const locationHour = String(locationTime.getHours()).padStart(2, '0');
        const locationTimeISO = `${locationYear}-${locationMonth}-${locationDay}T${locationHour}:00`;
        
        // Find the exact or closest time index to current location time
        let hourIndex = hourlyData.time.findIndex(time => time === locationTimeISO);
        if (hourIndex === -1) {
          // If exact match not found, find the closest previous time that exists
          const availableTimes = hourlyData.time.map((time, index) => ({ time, index }));
          const targetTime = new Date(locationTimeISO).getTime();
          
          // Find the closest time that is not in the future
          let closestIndex = -1;
          let closestDiff = Infinity;
          
          availableTimes.forEach(({ time, index }) => {
            const timeMs = new Date(time).getTime();
            const diff = targetTime - timeMs;
            
            // Only consider times that are not in the future (diff >= 0)
            if (diff >= 0 && diff < closestDiff) {
              closestDiff = diff;
              closestIndex = index;
            }
          });
          
          // If no past time found, use the last available time
          hourIndex = closestIndex >= 0 ? closestIndex : hourlyData.time.length - 1;
        }
        
        // Determine if it's day or night based on location time
        const currentTime = hourlyData.time[hourIndex];
        const sunrise = dailyData?.sunrise?.[0];
        const sunset = dailyData?.sunset?.[0];
        let is_day = null;
        
        if (currentTime && sunrise && sunset) {
          const currentTimeMs = new Date(currentTime).getTime();
          const sunriseMs = new Date(sunrise).getTime();
          const sunsetMs = new Date(sunset).getTime();
          is_day = currentTimeMs >= sunriseMs && currentTimeMs < sunsetMs;
        }
        
        // Convert sunset and sunrise to UTC
        let sunriseUTC = null;
        let sunsetUTC = null;
        
        if (dailyData?.sunrise?.[0]) {
          const sunriseLocalDate = new Date(dailyData.sunrise[0]);
          const sunriseUTCTime = sunriseLocalDate.getTime() - (weather.weatherData?.utc_offset_seconds || 0) * 1000;
          sunriseUTC = new Date(sunriseUTCTime).toISOString();
        }
        
        if (dailyData?.sunset?.[0]) {
          const sunsetLocalDate = new Date(dailyData.sunset[0]);
          const sunsetUTCTime = sunsetLocalDate.getTime() - (weather.weatherData?.utc_offset_seconds || 0) * 1000;
          sunsetUTC = new Date(sunsetUTCTime).toISOString();
        }
        
        weatherMap[weather._id.toString()] = {
          time: utcTimeISO, // Show current UTC time
          weather_code: hourlyData.weather_code?.[hourIndex] !== undefined ? hourlyData.weather_code[hourIndex] : null,
          temperature_2m: hourlyData.temperature_2m?.[hourIndex] !== undefined ? hourlyData.temperature_2m[hourIndex] : null,
          dew_point_2m: hourlyData.dew_point_2m?.[hourIndex] !== undefined ? hourlyData.dew_point_2m[hourIndex] : null,
          cloud_cover: hourlyData.cloud_cover?.[hourIndex] !== undefined ? hourlyData.cloud_cover[hourIndex] : null,
          apparent_temperature: hourlyData.apparent_temperature?.[hourIndex] !== undefined ? hourlyData.apparent_temperature[hourIndex] : null,
          relative_humidity_2m: hourlyData.relative_humidity_2m?.[hourIndex] !== undefined ? hourlyData.relative_humidity_2m[hourIndex] : null,
          surface_pressure: hourlyData.surface_pressure?.[hourIndex] !== undefined ? hourlyData.surface_pressure[hourIndex] : null,
          wind_speed_10m: hourlyData.wind_speed_10m?.[hourIndex] !== undefined ? hourlyData.wind_speed_10m[hourIndex] : null,
          visibility: hourlyData.visibility?.[hourIndex] !== undefined ? hourlyData.visibility[hourIndex] : null,
          uv_index: hourlyData.uv_index?.[hourIndex] !== undefined ? hourlyData.uv_index[hourIndex] : null,
          sunshine_duration: hourlyData.sunshine_duration?.[hourIndex] !== undefined ? hourlyData.sunshine_duration[hourIndex] : null,
          us_aqi: hourlyData.us_aqi?.[hourIndex] !== undefined ? hourlyData.us_aqi[hourIndex] : null,
          pm10: hourlyData.pm10?.[hourIndex] !== undefined ? hourlyData.pm10[hourIndex] : null,
          pm2_5: hourlyData.pm2_5?.[hourIndex] !== undefined ? hourlyData.pm2_5[hourIndex] : null,
          sunset: sunsetUTC,
          sunrise: sunriseUTC,
          temperature_2m_max: dailyData?.temperature_2m_max?.[0] || null,
          temperature_2m_min: dailyData?.temperature_2m_min?.[0] || null,
          is_day,
          timezone: "UTC" // Always UTC
        };
      }
    }
    
    const widgetObj = widget.toObject();
    
    // Update weather widgets with current hour data
    if (widgetObj.structure) {
      widgetObj.structure = widgetObj.structure.map(item => {
        if (item.type === 'weather' && item.data?._id && weatherMap[item.data._id]) {
          return {
            ...item,
            data: {
              ...item.data,
              currentHourData: weatherMap[item.data._id]
            }
          };
        }
        return item;
      });
    }
    
    return widgetObj;
  } catch (error) {
    throw new Error(`Error fetching widget: ${error.message}`);
  }
};

/**
 * Delete widget
 */
export const deleteWidget = async (id) => {
  try {
    return await WidgetStorage.findByIdAndDelete(id);
  } catch (error) {
    throw new Error(`Error deleting widget: ${error.message}`);
  }
};

/**
 * Get all active widgets with current hour weather data
 */
export const getAllWidgets = async () => {
  try {
    const widgets = await WidgetStorage.find({ isDeleted: false }).sort({ createdAt: -1 });
    const weatherData = await Weather.find({ isActive: true, isDeleted: false });
    
    const weatherMap = {};
    
    for (const weather of weatherData) {
      const hourlyData = weather.weatherData?.hourly;
      const dailyData = weather.weatherData?.daily;
      
      if (hourlyData?.time && hourlyData.time.length) {
        // Get timezone info from weather data
        const storedTimezone = weather.weatherData?.timezone || 'UTC';
        const utcOffsetSeconds = weather.weatherData?.utc_offset_seconds || 0;
        
        // Get current time in UTC
        const now = new Date();
        const utcTimeISO = now.toISOString().slice(0, 13) + ':00';
        
        // Determine the actual timezone for this location based on coordinates
        let actualTimezone = storedTimezone;
        
        // Special handling for India (coordinates around 22.75, 75.89 = Indore)
        if (weather.lat >= 6 && weather.lat <= 37 && weather.long >= 68 && weather.long <= 97) {
          actualTimezone = 'Asia/Kolkata'; // India timezone
        }
        // Add more regions as needed
        
        // Calculate current time in the actual location timezone  
        let locationTime;
        if (actualTimezone !== storedTimezone && (storedTimezone === 'GMT' || storedTimezone === 'UTC')) {
          // Data stored in GMT but location is in a different timezone
          locationTime = new Date(now.toLocaleString("en-US", {timeZone: actualTimezone}));
        } else if (storedTimezone === 'GMT' || storedTimezone === 'UTC') {
          // Use UTC offset from weather data
          locationTime = new Date(now.getTime() + (utcOffsetSeconds * 1000));
        } else {
          // Use the stored timezone
          locationTime = new Date(now.toLocaleString("en-US", {timeZone: storedTimezone}));
        }
        
        // Format location time to match the stored data format
        const locationYear = locationTime.getFullYear();
        const locationMonth = String(locationTime.getMonth() + 1).padStart(2, '0');
        const locationDay = String(locationTime.getDate()).padStart(2, '0');
        const locationHour = String(locationTime.getHours()).padStart(2, '0');
        const locationTimeISO = `${locationYear}-${locationMonth}-${locationDay}T${locationHour}:00`;
        
        // Find the exact or closest time index to current location time
        let hourIndex = hourlyData.time.findIndex(time => time === locationTimeISO);
        if (hourIndex === -1) {
          // If exact match not found, find the closest previous time that exists
          const availableTimes = hourlyData.time.map((time, index) => ({ time, index }));
          const targetTime = new Date(locationTimeISO).getTime();
          
          // Find the closest time that is not in the future
          let closestIndex = -1;
          let closestDiff = Infinity;
          
          availableTimes.forEach(({ time, index }) => {
            const timeMs = new Date(time).getTime();
            const diff = targetTime - timeMs;
            
            // Only consider times that are not in the future (diff >= 0)
            if (diff >= 0 && diff < closestDiff) {
              closestDiff = diff;
              closestIndex = index;
            }
          });
          
          // If no past time found, use the last available time
          hourIndex = closestIndex >= 0 ? closestIndex : hourlyData.time.length - 1;
        }
        
        // Determine if it's day or night based on location time
        const currentTime = hourlyData.time[hourIndex];
        const sunrise = dailyData?.sunrise?.[0];
        const sunset = dailyData?.sunset?.[0];
        let is_day = null;
        
        if (currentTime && sunrise && sunset) {
          const currentTimeMs = new Date(currentTime).getTime();
          const sunriseMs = new Date(sunrise).getTime();
          const sunsetMs = new Date(sunset).getTime();
          is_day = currentTimeMs >= sunriseMs && currentTimeMs < sunsetMs;
        }
        
        // Convert sunset and sunrise to UTC
        let sunriseUTC = null;
        let sunsetUTC = null;
        
        if (sunrise) {
          const sunriseLocalDate = new Date(sunrise);
          const sunriseUTCTime = sunriseLocalDate.getTime() - (weather.weatherData?.utc_offset_seconds || 0) * 1000;
          sunriseUTC = new Date(sunriseUTCTime).toISOString();
        }
        
        if (sunset) {
          const sunsetLocalDate = new Date(sunset);
          const sunsetUTCTime = sunsetLocalDate.getTime() - (weather.weatherData?.utc_offset_seconds || 0) * 1000;
          sunsetUTC = new Date(sunsetUTCTime).toISOString();
        }
        
        weatherMap[weather._id.toString()] = {
          time: utcTimeISO, // Show current UTC time
          weather_code: hourlyData.weather_code?.[hourIndex] !== undefined ? hourlyData.weather_code[hourIndex] : null,
          temperature_2m: hourlyData.temperature_2m?.[hourIndex] || null,
          dew_point_2m: hourlyData.dew_point_2m?.[hourIndex] || null,
          cloud_cover: hourlyData.cloud_cover?.[hourIndex] !== undefined ? hourlyData.cloud_cover[hourIndex] : null,
          apparent_temperature: hourlyData.apparent_temperature?.[hourIndex] || null,
          relative_humidity_2m: hourlyData.relative_humidity_2m?.[hourIndex] || null,
          surface_pressure: hourlyData.surface_pressure?.[hourIndex] || null,
          wind_speed_10m: hourlyData.wind_speed_10m?.[hourIndex] !== undefined ? hourlyData.wind_speed_10m[hourIndex] : null,
          visibility: hourlyData.visibility?.[hourIndex] || null,
          uv_index: hourlyData.uv_index?.[hourIndex] !== undefined ? hourlyData.uv_index[hourIndex] : null,
          sunshine_duration: hourlyData.sunshine_duration?.[hourIndex] !== undefined ? hourlyData.sunshine_duration[hourIndex] : null,
          us_aqi: hourlyData.us_aqi?.[hourIndex] || null,
          pm10: hourlyData.pm10?.[hourIndex] || null,
          pm2_5: hourlyData.pm2_5?.[hourIndex] || null,
          sunset: sunsetUTC,
          sunrise: sunriseUTC,
          temperature_2m_max: dailyData?.temperature_2m_max?.[0] || null,
          temperature_2m_min: dailyData?.temperature_2m_min?.[0] || null,
          is_day,
          timezone: "UTC" // Always UTC
        };
      }
    }
    
    return widgets.map(widget => {
      const widgetObj = widget.toObject();
      
      // Update weather widgets with current hour data
      if (widgetObj.structure) {
        widgetObj.structure = widgetObj.structure.map(item => {
          if (item.type === 'weather' && item.data?._id && weatherMap[item.data._id]) {
            return {
              ...item,
              data: {
                ...item.data,
                currentHourData: weatherMap[item.data._id]
              }
            };
          }
          return item;
        });
      }
      
      return widgetObj;
    });
  } catch (error) {
    throw new Error(`Error fetching widgets: ${error.message}`);
  }
};

/**
 * Refresh weather data for all active locations
 * 
 * Bulk weather update operation:
 * - Processes all active, non-deleted weather records
 * - Fetches fresh data from Open-Meteo API for each location
 * - Updates timezone-specific data with location accuracy
 * - Comprehensive error handling with success/failure tracking
 * - Optimized for batch processing with parallel API calls
 * - Provides detailed operation results for monitoring
 */
export const refreshAllWeatherData = async (userId) => {
  try {
    let user = null;
    if (userId) {
      user = await User.findById(userId);
      if (!user) throw new Error('User not found');
    }

    const weatherRecords = await Weather.find({ isActive: true, isDeleted: false });
    const results = [];
    
    for (const record of weatherRecords) {
      try {
        // Get timezone for the location to calculate local current time
        const timezoneUrl = `https://api.open-meteo.com/v1/forecast?latitude=${record.lat}&longitude=${record.long}&timezone=auto&forecast_days=1`;
        const timezoneResponse = await axios.get(timezoneUrl, {
          timeout: parseInt(process.env.API_TIMEOUT) || 30000,
          headers: { 'User-Agent': 'MPS-API/1.0' }
        });
        
        const timezone = timezoneResponse.data?.timezone || 'UTC';
        
        const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${record.lat}&longitude=${record.long}&timezone=${timezone}&daily=sunset,sunrise,temperature_2m_max,temperature_2m_min&hourly=weather_code,temperature_2m,dew_point_2m,cloud_cover,apparent_temperature,relative_humidity_2m,surface_pressure,wind_speed_10m,visibility,uv_index,sunshine_duration&forecast_days=1`;
        const aqiUrl = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${record.lat}&longitude=${record.long}&timezone=${timezone}&hourly=us_aqi,pm10,pm2_5&forecast_days=1`;

        const axiosConfig = {
          timeout: parseInt(process.env.API_TIMEOUT) || 30000,
          headers: { 'User-Agent': 'MPS-API/1.0' }
        };

        const [weatherResponse, aqiResponse] = await Promise.allSettled([
          axios.get(weatherUrl, axiosConfig),
          axios.get(aqiUrl, axiosConfig)
        ]);
        
        if (weatherResponse.status === 'fulfilled' && weatherResponse.value?.data) {
          const weatherData = weatherResponse.value.data;
          
          if (aqiResponse.status === 'fulfilled' && aqiResponse.value?.data?.hourly) {
            const aqiHourly = aqiResponse.value.data.hourly;
            if (aqiHourly.us_aqi) weatherData.hourly.us_aqi = aqiHourly.us_aqi;
            if (aqiHourly.pm10) weatherData.hourly.pm10 = aqiHourly.pm10;
            if (aqiHourly.pm2_5) weatherData.hourly.pm2_5 = aqiHourly.pm2_5;
          }

          const lastTimeArray = weatherData.hourly?.time || [];
          const lastWeatherDate = lastTimeArray.length ? lastTimeArray[lastTimeArray.length - 1] : null;

          const updateData = {
            weatherData,
            lastWeatherDate,
            updatedDate: new Date().toISOString()
          };
          
          if (user) {
            updateData.updatedBy = {
              userId: user._id,
              fullName: user.fullName,
              email: user.email
            };
          }

          await Weather.findByIdAndUpdate(record._id, updateData);
          
          results.push({ id: record._id, placeName: record.placeName, status: 'success', timezone });
        } else {
          results.push({ id: record._id, placeName: record.placeName, status: 'failed', error: 'API error' });
        }
      } catch (error) {
        results.push({ id: record._id, placeName: record.placeName, status: 'failed', error: error.message });
      }
    }
    
    return {
      totalCount: weatherRecords.length,
      successCount: results.filter(r => r.status === 'success').length,
      failedCount: results.filter(r => r.status === 'failed').length,
      results
    };
  } catch (error) {
    throw new Error(`Error refreshing weather data: ${error.message}`);
  }
};