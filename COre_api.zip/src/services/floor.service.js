/**
 * Floor Service - Building floor database operations
 * 
 * Handles all floor-related database interactions within the building hierarchy.
 * Flow: floor.controller.js → floor.service.js → CampusFloor/Building/Campus/Zone models → MongoDB
 * 
 * Core Functions:
 * - Floor CRUD with building association and level validation
 * - Name-based campus/building resolution for external APIs
 * - Zone cascade operations during floor deletion
 * - Device state management (move to Discovered during deletion)
 * - Building transfer support with conflict validation
 * - User access control integration and campusData updates
 * - Floor statistics with zone/device counts
 */

import { CampusFloor } from '../models/CampusFloor.js';
import { CampusBuilding } from '../models/CampusBuilding.js';
import { Campus } from '../models/Campus.js';
import { CampusZone } from '../models/CampusZone.js';
import { User } from '../models/User.js';

// Get comprehensive floors list with building/campus context and statistics
// - Supports includeDeleted parameter for administrative views
// - Calculates zone counts and provides floor statistics
// - Includes campus/building population for context display
export const getAllFloors = async (queryParams = {}) => {
  const {
    page = 1,
    limit = 20,
    status,
    campusName,
    buildingName,
    floorLevel,
    location,
    region,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    includeDeleted = false // New parameter to control inclusion of deleted floors
  } = queryParams;

  // Build filter object - Conditionally include deleted floors
  const filter = {};
  if (!includeDeleted) {
    filter.deleted = { $ne: true }; // Only exclude deleted floors if includeDeleted is false
  }
  
  if (status !== undefined) {
    filter.status = parseInt(status);
  }
  
  if (floorLevel) {
    filter.floorLevel = { $regex: floorLevel, $options: 'i' };
  }
  
  if (search) {
    filter.$or = [
      { name: { $regex: search, $options: 'i' } },
      { floorLevel: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } }
    ];
  }

  // Calculate skip value for pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);

  // Get sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  try {
    // First, try a simple approach to get floors with basic info
    const floors = await CampusFloor.find(filter)
      .populate({
        path: 'buildingId',
        select: 'name type',
        populate: {
          path: 'campusId',
          select: 'name organization location'
        }
      })
      .populate({
        path: 'zones',
        match: { deleted: { $ne: true } },
        select: 'name status'
      })
      .populate('createdBy.userId', 'fullName email')
      .sort(sort)
      .skip(skip)
      .limit(parseInt(limit))
      .lean();

    // Get total count for pagination
    const total = await CampusFloor.countDocuments(filter);

    // Transform the data to match expected format and add active zone count
    const transformedFloors = [];
    
    for (const floor of floors) {
      // Get active zone count for this floor (deleted: false and status: 1)
      const zoneCount = await CampusZone.countDocuments({
        floorId: floor._id,
        deleted: { $ne: true },
        status: 1
      });

      transformedFloors.push({
        _id: floor._id,
        floorName: floor.name,
        campusName: floor.buildingId?.campusId?.name || 'Unknown Campus',
        buildingName: floor.buildingId?.name || 'Unknown Building',
        location: floor.buildingId?.campusId?.location || 'Unknown Location',
        region: floor.buildingId?.campusId?.location || 'Unknown Location',
        floorLevel: floor.floorLevel,
        status: floor.status,
        addedOn: floor.createdAt,
        zones: (floor.zones || []).map(zone => ({
          _id: zone._id,
          name: zone.name,
          status: zone.status
        })),
        zoneCount: zoneCount, // Active zones only
        description: floor.description,
        floorImage: floor.floorImage,
        createdBy: floor.createdBy,
        // Add deletion information
        isDeleted: floor.deleted === true,
        deletedAt: floor.deletedAt || null,
        deletedBy: floor.deletedBy || null
      });
    }

    // Apply additional filters if needed
    let filteredFloors = transformedFloors;
    
    if (campusName) {
      filteredFloors = filteredFloors.filter(floor => 
        floor.campusName.toLowerCase().includes(campusName.toLowerCase())
      );
    }
    
    if (buildingName) {
      filteredFloors = filteredFloors.filter(floor => 
        floor.buildingName.toLowerCase().includes(buildingName.toLowerCase())
      );
    }
    
    if (location) {
      filteredFloors = filteredFloors.filter(floor => 
        floor.location.toLowerCase().includes(location.toLowerCase())
      );
    }
    
    if (region) {
      filteredFloors = filteredFloors.filter(floor => 
        floor.region.toLowerCase().includes(region.toLowerCase())
      );
    }

    // Get summary counts
    const activeFloorsCount = await CampusFloor.countDocuments({ 
      deleted: { $ne: true }, // Always exclude deleted for active count
      status: 1 
    });
    const inactiveFloorsCount = await CampusFloor.countDocuments({ 
      deleted: { $ne: true }, // Always exclude deleted for inactive count
      status: 0 
    });
    
    // Get deleted count only if includeDeleted is true
    let deletedFloorsCount = 0;
    if (includeDeleted) {
      deletedFloorsCount = await CampusFloor.countDocuments({ 
        deleted: true 
      });
    }

    const summary = {
      totalActiveFloors: activeFloorsCount,
      totalInactiveFloors: inactiveFloorsCount,
      totalNonDeletedFloors: activeFloorsCount + inactiveFloorsCount,
      ...(includeDeleted && { totalDeletedFloors: deletedFloorsCount }),
      totalFloors: includeDeleted 
        ? activeFloorsCount + inactiveFloorsCount + deletedFloorsCount
        : activeFloorsCount + inactiveFloorsCount
    };

    return {
      floors: filteredFloors,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / parseInt(limit)),
        totalFloors: total,
        hasNextPage: skip + floors.length < total,
        hasPrevPage: parseInt(page) > 1
      },
      summary
    };

  } catch (error) {
    console.error('Error in getAllFloors:', error);
    // Fallback to very basic query if everything fails
    const floors = await CampusFloor.find(filter)
      .sort(sort)
      .skip(skip)
      .limit(parseInt(limit))
      .lean();

    const total = await CampusFloor.countDocuments(filter);
    
    return {
      floors: floors.map(floor => ({
        _id: floor._id,
        floorName: floor.name,
        campusName: 'Loading...',
        buildingName: 'Loading...',
        location: 'Loading...',
        region: 'Loading...',
        floorLevel: floor.floorLevel,
        status: floor.status,
        addedOn: floor.createdAt,
        zones: [],
        zoneCount: 0,
        description: floor.description,
        floorImage: floor.floorImage,
        createdBy: floor.createdBy,
        // Add deletion information
        isDeleted: floor.deleted === true,
        deletedAt: floor.deletedAt || null,
        deletedBy: floor.deletedBy || null
      })),
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / parseInt(limit)),
        totalFloors: total,
        hasNextPage: skip + floors.length < total,
        hasPrevPage: parseInt(page) > 1
      },
      summary: {
        totalActiveFloors: 0,
        totalInactiveFloors: 0,
        ...(includeDeleted && { totalDeletedFloors: 0 }),
        totalFloors: total
      }
    };
  }
};

// Get all floors for a building
export const getFloorsByBuilding = async (buildingId, queryParams = {}) => {
  const {
    page = 1,
    limit = 20,
    status,
    search,
    sortBy = 'floorLevel',
    sortOrder = 'asc'
  } = queryParams;

  // Build filter object
  const filter = { buildingId, deleted: { $ne: true } };
  
  if (status) {
    filter.status = status;
  }
  
  if (search) {
    filter.$or = [
      { name: { $regex: search, $options: 'i' } },
      { floorLevel: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } }
    ];
  }

  // Calculate skip value for pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);

  // Get sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // Execute query with pagination
  let floors = await CampusFloor.find(filter)
    .populate('buildingId', 'name type')
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email')
    .sort(sort)
    .skip(skip)
    .limit(parseInt(limit))
    .lean();

  // Add active zone count for each floor
  for (const floor of floors) {
    // Get active zone count for this floor (deleted: false and status: 1)
    const zoneCount = await CampusZone.countDocuments({
      floorId: floor._id,
      deleted: { $ne: true },
      status: 1
    });

    // Add active zone count to floor object
    floor.zoneCount = zoneCount;
  }

  // Get total count for pagination
  const total = await CampusFloor.countDocuments(filter);

  return {
    floors,
    pagination: {
      currentPage: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit)),
      totalFloors: total,
      hasNextPage: skip + floors.length < total,
      hasPrevPage: parseInt(page) > 1
    }
  };
};

// Create floor with building validation and user access setup
// - Validates building existence and floor level uniqueness
// - Updates building's floors array and admin user access
// - Manages user campusData for immediate floor access
export const addFloor = async (floorData, user) => {
  // Verify building exists
  const building = await CampusBuilding.findById(floorData.buildingId);
  if (!building) {
    throw new Error('Building not found');
  }

  // Check if floor with same level already exists in this building
  const existingFloor = await CampusFloor.findOne({ 
    floorLevel: floorData.floorLevel, 
    buildingId: floorData.buildingId,
    deleted: { $ne: true }
  });
  if (existingFloor) {
    throw new Error('Floor with this level already exists in the building');
  }

  // Create floor with user information
  const floor = new CampusFloor({
    ...floorData,
    createdBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    },
    updatedBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    }
  });

  await floor.save();

  // Add floor to building floors array
  await CampusBuilding.findByIdAndUpdate(
    floorData.buildingId,
    { $push: { floors: floor._id } },
    { new: true }
  );

  await floor.populate([
    { path: 'buildingId', select: 'name type' },
    { path: 'createdBy.userId', select: 'fullName email' }
  ]);

  // --- Add floor._id to allowedResources.campusManagement.floors for all admin users ---
  const { default: Role } = await import('../models/Role.js');
  const { User } = await import('../models/User.js');
  const adminRole = await Role.findOne({ roleName: { $regex: /^admin$/i }, byDefault: "true" });
  if (adminRole) {
    const adminUsers = await User.find({ role_id: adminRole._id });
    for (const adminUser of adminUsers) {
      if (!adminUser.allowedResources) adminUser.allowedResources = { campusManagement: { floors: [] } };
      if (!adminUser.allowedResources.campusManagement) adminUser.allowedResources.campusManagement = { floors: [] };
      if (!Array.isArray(adminUser.allowedResources.campusManagement.floors)) {
        adminUser.allowedResources.campusManagement.floors = [];
      }
      if (!adminUser.allowedResources.campusManagement.floors.includes(floor._id.toString())) {
        adminUser.allowedResources.campusManagement.floors.push(floor._id.toString());
        await adminUser.save();
      }
    }
  }

  // --- Append this floor into the requesting user's campusData under the correct campus/building ---
  try {
    // Fetch campus name for fallback matching
    const campusDoc = await Campus.findById(building.campusId).select('name');
    const campusIdStr = building.campusId.toString();
    const buildingIdStr = building._id.toString();

    const floorForUser = {
      floor_id: floor._id.toString(),
      floor_name: floor.name,
      zones: []
    };

    // 1) Try pushing into existing building by campus_id + building_id
    const byIds = await User.updateOne(
      { _id: user._id },
      {
        $push: { 'campusData.$[c].buildings.$[b].floors': floorForUser },
        $set: {
          updatedBy: { userId: user._id, fullName: user.fullName, email: user.email },
          updatedDate: new Date().toISOString()
        }
      },
      {
        arrayFilters: [
          { 'c.campus_id': campusIdStr },
          { 'b.building_id': buildingIdStr }
        ]
      }
    );

    if (!byIds || (byIds.modifiedCount === 0 && byIds.matchedCount === 0)) {
      // 2) Try campus_name + building_name (case-insensitive)
      const byNames = await User.updateOne(
        { _id: user._id },
        {
          $push: { 'campusData.$[c].buildings.$[b].floors': floorForUser },
          $set: {
            updatedBy: { userId: user._id, fullName: user.fullName, email: user.email },
            updatedDate: new Date().toISOString()
          }
        },
        {
          arrayFilters: [
            { 'c.campus_name': { $regex: new RegExp(`^${campusDoc?.name || ''}$`, 'i') } },
            { 'b.building_name': { $regex: new RegExp(`^${building.name}$`, 'i') } }
          ]
        }
      );

      if (!byNames || (byNames.modifiedCount === 0 && byNames.matchedCount === 0)) {
        // 3) If building entry is missing, append a new building with this floor under campus (by id, then by name)
        const pushBuildingById = await User.updateOne(
          { _id: user._id, 'campusData.campus_id': campusIdStr },
          {
            $push: {
              'campusData.$.buildings': {
                building_id: buildingIdStr,
                building_name: building.name,
                floors: [floorForUser]
              }
            },
            $set: {
              updatedBy: { userId: user._id, fullName: user.fullName, email: user.email },
              updatedDate: new Date().toISOString()
            }
          }
        );

        if (!pushBuildingById || (pushBuildingById.modifiedCount === 0 && pushBuildingById.matchedCount === 0)) {
          await User.updateOne(
            { _id: user._id, 'campusData.campus_name': { $regex: new RegExp(`^${campusDoc?.name || ''}$`, 'i') } },
            {
              $push: {
                'campusData.$.buildings': {
                  building_id: buildingIdStr,
                  building_name: building.name,
                  floors: [floorForUser]
                }
              },
              $set: {
                updatedBy: { userId: user._id, fullName: user.fullName, email: user.email },
                updatedDate: new Date().toISOString()
              }
            }
          );
        }
      }
    }
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error('Failed to update requesting user campusData with new floor:', e);
  }

  return floor;
};

// Get floor details with complete hierarchy context and device statistics
// - Populates full campus → building → floor chain
// - Calculates zone counts and configured device statistics
// - Returns restructured data with proper hierarchy levels
export const getFloorById = async (floorId) => {

  const floor = await CampusFloor.findOne({ _id: floorId, deleted: { $ne: true } })
    .populate({
      path: 'buildingId',
      select: 'name type',
      populate: {
        path: 'campusId',
        select: 'name organization location type accessId campusImage description'
      }
    })
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email')
    .lean();

  if (!floor) {
    throw new Error('Floor not found');
  }

  // Get all non-deleted zones for this floor
  const zones = await CampusZone.find({
    floorId: floor._id,
    $or: [
      { isDelete: { $exists: false } },
      { isDelete: false },
      { isDelete: { $ne: true } }
    ]
  }).lean();

  const zoneCount = zones.length;
  let configuredDeviceCount = 0;

  // For each zone, get its devices
  const Device = (await import('../models/Device.js')).default;
  for (const zone of zones) {
    // Get all non-deleted devices for this zone
    const devices = await Device.find({
      zone: zone._id,
      is_delete: { $ne: true }
    }).lean();
    
    zone.devices = devices;
    
    // Count configured devices
    const configuredCount = devices.filter(device => device.configure_flag === true).length;
    configuredDeviceCount += configuredCount;
  }

  // Attach zones to floor
  floor.zones = zones;

  // Restructure the response to have campusId at the same level as buildingId
  const restructuredFloor = {
    ...floor,
    campusId: floor.buildingId?.campusId || null,
    buildingId: {
      _id: floor.buildingId?._id,
      name: floor.buildingId?.name,
      type: floor.buildingId?.type
    },
    zoneCount,
    configuredDeviceCount
  };

  return restructuredFloor;
};

// Create floor using campus/building name resolution (flexible API)
// - Case-insensitive campus and building name lookup
// - Validates floor level and name uniqueness within resolved building
// - Updates building's floors array and populates response data
export const addFloorWithNames = async (floorData, user) => {
  const { campusName, buildingName, floorName, floorLevel, ...otherData } = floorData;
  
  // Find campus by name (case-insensitive)
  const campus = await Campus.findOne({ 
    name: { $regex: new RegExp(`^${campusName}$`, 'i') }, // Case-insensitive exact match
    status: 1 // Only active campuses
  });
  
  if (!campus) {
    throw new Error(`Campus with name "${campusName}" not found or is inactive`);
  }

  // Find building by name within the campus (case-insensitive)
  const building = await CampusBuilding.findOne({ 
    name: { $regex: new RegExp(`^${buildingName}$`, 'i') }, // Case-insensitive exact match
    campusId: campus._id,
    status: 1 // Only active buildings
  });
  
  if (!building) {
    throw new Error(`Building with name "${buildingName}" not found in campus "${campusName}" or is inactive`);
  }

  // Check if floor with same level already exists in this building
  const existingFloorByLevel = await CampusFloor.findOne({ 
    floorLevel: floorLevel, 
    buildingId: building._id,
    status: 1, // Only check active floors
    deleted: { $ne: true } // Exclude deleted floors
  });
  if (existingFloorByLevel) {
    throw new Error(`Floor with level "${floorLevel}" already exists in building "${buildingName}"`);
  }

  // Check if floor with same name already exists in this building
  const existingFloorByName = await CampusFloor.findOne({ 
    name: { $regex: new RegExp(`^${floorName}$`, 'i') }, // Case-insensitive exact match
    buildingId: building._id,
    status: 1, // Only check active floors
    deleted: { $ne: true } // Exclude deleted floors
  });
  if (existingFloorByName) {
    throw new Error(`Floor with name "${floorName}" already exists in building "${buildingName}"`);
  }

  // Create floor with user information
  const floor = new CampusFloor({
    name: floorName,
    floorLevel: floorLevel,
    buildingId: building._id,
    ...otherData,
    createdBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    },
    updatedBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    }
  });

  await floor.save();

  // Add floor to building floors array
  await CampusBuilding.findByIdAndUpdate(
    building._id,
    { $push: { floors: floor._id } },
    { new: true }
  );

  // Populate floor data for response
  await floor.populate([
    { 
      path: 'buildingId', 
      select: 'name type',
      populate: {
        path: 'campusId',
        select: 'name organization'
      }
    },
    { path: 'createdBy.userId', select: 'fullName email' }
  ]);
  
  return floor;
};

// Update floor with name-based resolution and building transfer support
// - Supports moving floors between buildings via campus/building names
// - Validates conflicts for floor level and name in target building
// - Handles building array updates when transferring floors
export const updateFloorWithNames = async (floorId, updateData, user) => {
  const { campusName, buildingName, floorName, floorLevel, zones, ...otherData } = updateData;
  
  // Find the existing floor
  const existingFloor = await CampusFloor.findOne({ _id: floorId, deleted: { $ne: true } })
    .populate({
      path: 'buildingId',
      populate: {
        path: 'campusId'
      }
    });
  
  if (!existingFloor) {
    throw new Error('Floor not found');
  }

  // If campus name is provided, validate it
  let targetCampus = existingFloor.buildingId.campusId;
  if (campusName) {
    const campus = await Campus.findOne({ 
      name: { $regex: new RegExp(`^${campusName}$`, 'i') },
      status: 1
    });
    
    if (!campus) {
      throw new Error(`Campus with name "${campusName}" not found or is inactive`);
    }
    targetCampus = campus;
  }

  // If building name is provided, validate it and potentially move the floor
  let targetBuilding = existingFloor.buildingId;
  if (buildingName) {
    const building = await CampusBuilding.findOne({ 
      name: { $regex: new RegExp(`^${buildingName}$`, 'i') },
      campusId: targetCampus._id,
      status: 1
    });
    
    if (!building) {
      throw new Error(`Building with name "${buildingName}" not found in campus "${targetCampus.name}" or is inactive`);
    }
    targetBuilding = building;
  }

  // Check for conflicts if floor level is being changed
  if (floorLevel && floorLevel !== existingFloor.floorLevel) {
    const conflictingFloor = await CampusFloor.findOne({ 
      floorLevel: floorLevel, 
      buildingId: targetBuilding._id,
      _id: { $ne: floorId }, // Exclude current floor
      status: 1,
      deleted: { $ne: true } // Exclude deleted floors
    });
    if (conflictingFloor) {
      throw new Error(`Floor with level "${floorLevel}" already exists in building "${targetBuilding.name}"`);
    }
  }

  // Check for conflicts if floor name is being changed
  if (floorName && floorName !== existingFloor.name) {
    const conflictingFloor = await CampusFloor.findOne({ 
      name: { $regex: new RegExp(`^${floorName}$`, 'i') },
      buildingId: targetBuilding._id,
      _id: { $ne: floorId }, // Exclude current floor
      status: 1,
      deleted: { $ne: true } // Exclude deleted floors
    });
    if (conflictingFloor) {
      throw new Error(`Floor with name "${floorName}" already exists in building "${targetBuilding.name}"`);
    }
  }

  // Handle building change (if building is different)
  if (targetBuilding._id.toString() !== existingFloor.buildingId._id.toString()) {
    // Remove floor from old building
    await CampusBuilding.findByIdAndUpdate(
      existingFloor.buildingId._id,
      { $pull: { floors: floorId } }
    );
    
    // Add floor to new building
    await CampusBuilding.findByIdAndUpdate(
      targetBuilding._id,
      { $push: { floors: floorId } }
    );
    
    // Update buildingId in floor
    otherData.buildingId = targetBuilding._id;
  }

  // Handle zone updates if provided
  if (zones && Array.isArray(zones)) {
    // Find zones by name or ID
    const zoneIds = [];
    for (const zone of zones) {
      let zoneDoc;
      
      // Check if it's a valid ObjectId
      if (zone.match(/^[0-9a-fA-F]{24}$/)) {
        zoneDoc = await CampusZone.findById(zone);
      } else {
        // Find by name within the floor
        zoneDoc = await CampusZone.findOne({
          name: { $regex: new RegExp(`^${zone}$`, 'i') },
          floorId: floorId,
          status: 1
        });
      }
      
      if (zoneDoc) {
        zoneIds.push(zoneDoc._id);
      }
    }
    otherData.zones = zoneIds;
  }

  // Prepare update data
  const finalUpdateData = {
    ...(floorName && { name: floorName }),
    ...(floorLevel && { floorLevel }),
    ...otherData,
    updatedBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    },
    updatedAt: new Date()
  };

  // Update the floor
  const updatedFloor = await CampusFloor.findByIdAndUpdate(
    floorId,
    finalUpdateData,
    { 
      new: true, 
      runValidators: true 
    }
  ).populate([
    { 
      path: 'buildingId', 
      select: 'name type',
      populate: {
        path: 'campusId',
        select: 'name organization location'
      }
    },
    { path: 'zones', select: 'name type status' },
    { path: 'createdBy.userId', select: 'fullName email' },
    { path: 'updatedBy.userId', select: 'fullName email' }
  ]);

  if (!updatedFloor) {
    throw new Error('Floor not found or could not be updated');
  }

  return updatedFloor;
};

// Change floor status (active/inactive)
export const changeFloorStatus = async (floorId, status, user) => {
  // Validate floorId format
  if (!floorId.match(/^[0-9a-fA-F]{24}$/)) {
    throw new Error('Invalid floor ID format');
  }

  // Find the floor first
  const floor = await CampusFloor.findOne({ _id: floorId, deleted: { $ne: true } });
  if (!floor) {
    throw new Error('Floor not found');
  }

  try {
    const updatedFloor = await CampusFloor.findByIdAndUpdate(
      floorId,
      {
        status,
        updatedBy: {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        },
        updatedAt: new Date()
      },
      { 
        new: true, 
        runValidators: true 
      }
    ).populate([
      { 
        path: 'buildingId', 
        select: 'name type',
        populate: {
          path: 'campusId',
          select: 'name organization location'
        }
      },
      { path: 'zones', select: 'name type status' },
      { path: 'createdBy.userId', select: 'fullName email' },
      { path: 'updatedBy.userId', select: 'fullName email' }
    ]);

    if (!updatedFloor) {
      throw new Error('Floor not found or could not be updated');
    }

    return updatedFloor;
  } catch (error) {
    // Handle mongoose validation errors
    if (error.name === 'ValidationError') {
      const validationErrors = Object.values(error.errors).map(err => err.message);
      throw new Error(`Validation failed: ${validationErrors.join(', ')}`);
    }
    
    throw error;
  }
};

// Delete floor with complete cascade cleanup and device state management
// - Moves floor devices to 'Discovered' state (preserves hardware)
// - Permanently deletes zones and removes devices from intelligent control
// - Returns deletion statistics for audit logging
export const deleteFloor = async (floorId, user) => {
  if (!floorId.match(/^[0-9a-fA-F]{24}$/)) {
    throw new Error('Invalid floor ID format');
  }

  const floor = await CampusFloor.findOne({ _id: floorId, deleted: { $ne: true } });
  if (!floor) {
    throw new Error('Floor not found or already deleted');
  }

  // Import required models and functions
  const Device = (await import('../models/Device.js')).default;
  const { removeDeviceFromRelatedCollections } = await import('./device.service.js');

  // Get all zones under this floor
  const zones = await CampusZone.find({ floorId });
  const zoneIds = zones.map(z => z._id);

  // Get devices in floor and move them to 'Discovered' state
  const devices = await Device.find({ floor: floorId }).select('device_id');
  
  // Update devices to 'Discovered' state (same as device deletion)
  await Device.updateMany(
    { floor: floorId },
    { 
      is_delete: false,
      configure_flag: false
    }
  );

  // Remove each device from related collections (same as device deletion)
  for (const device of devices) {
    await removeDeviceFromRelatedCollections(device.device_id, user);
  }

  // Delete zones
  if (zoneIds.length > 0) {
    await CampusZone.deleteMany({ _id: { $in: zoneIds } });
  }

  // Delete floor
  await CampusFloor.deleteOne({ _id: floorId });

  return {
    success: true,
    message: 'Floor deleted successfully. All devices moved to Discovered state and intelligent control data permanently deleted.',
    floor: { _id: floorId },
    deletedCounts: {
      zones: zoneIds.length,
      devicesMovedToDiscovered: devices.length
    }
  };
};
