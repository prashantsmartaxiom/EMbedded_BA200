import { resetService } from '../services/resetService.js';

class ScheduleService {
  constructor() {
    this.intervals = new Map();
  }

  // Start cleanup job for expired password reset requests
  startResetCleanup() {
    // Run cleanup every 30 minutes
    const interval = setInterval(async () => {
      try {
        await resetService.cleanupExpiredResets();
      } catch (error) {
        console.error('⚠️  Reset cleanup job failed:', error);
      }
    }, 30 * 60 * 1000); // 30 minutes

    this.intervals.set('resetCleanup', interval);
  }

  // Stop a specific job
  stopJob(jobName) {
    const interval = this.intervals.get(jobName);
    if (interval) {
      clearInterval(interval);
      this.intervals.delete(jobName);
    }
  }

  // Stop all jobs
  stopAllJobs() {
    for (const [jobName, interval] of this.intervals) {
      clearInterval(interval);
    }
    this.intervals.clear();
  }

  // Get status of all jobs
  getJobStatus() {
    const jobs = Array.from(this.intervals.keys());
    return {
      activeJobs: jobs,
      totalJobs: jobs.length
    };
  }
}

export const scheduleService = new ScheduleService();
