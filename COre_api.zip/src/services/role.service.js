/**
 * Role Service - Database operations for role management
 * 
 * Handles all role-related database interactions for the permission system.
 * Flow: role.controller.js → role.service.js → Role model → MongoDB
 * 
 * Core Functions:
 * - CRUD operations with soft delete support
 * - Case-insensitive role name queries
 * - Paginated role listing with access control
 * - Permission sections configuration
 * - Role reactivation for deleted entries
 */

import Role from '../models/Role.js';
import { Types } from 'mongoose';

// Find role by exact name match (includes deleted roles)
export const findRoleByName = async (roleName) => {
  try {
    return await Role.findOne({ roleName });
  } catch (error) {
    throw new Error(`Error finding role: ${error.message}`);
  }
};

// Find active (non-deleted) role by name
export const findActiveRoleByName = async (roleName) => {
  try {
    return await Role.findOne({ 
      roleName, 
      isDelete: { $ne: true } 
    });
  } catch (error) {
    throw new Error(`Error finding active role: ${error.message}`);
  }
};

// Create new role with permission matrix
export const createRole = async (roleData) => { 
  try {
    const role = new Role(roleData);
    return await role.save();
  } catch (error) {
    throw error;
  }
};

export const getAllRoles = async () => {
  try {
    return await Role.find({});
  } catch (error) {
    throw new Error(`Error fetching roles: ${error.message}`);
  }
};

export const getRoleById = async (roleId) => {
  try {
    return await Role.findById(roleId);
  } catch (error) {
    throw new Error(`Error finding role by ID: ${error.message}`);
  }
};

export const updateRole = async (roleId, updateData) => {
  try {
    return await Role.findByIdAndUpdate(roleId, updateData, { new: true });
  } catch (error) {
    if (error.code === 11000) {
      throw new Error('Duplicate role name not allowed');
    }
    throw new Error(`Error updating role: ${error.message}`);
  }
};

// Get paginated roles list with comprehensive filtering
// - Respects user access control via allowedRoleIds
// - Supports search, status filtering, superadmin exclusion
// - Returns role counts (total, active, inactive) for UI stats
// - Handles both paginated and full list requests
export const getRolesList = async (params = {}) => {
  try {
    const { 
      search = '', 
      page = 1, 
      limit, 
      status, 
      sortBy = 'createdAt',
      sortOrder = 'desc',
      allowedRoleIds = null,
      excludeSuperadmin = false
    } = params;

    // Convert allowedRoleIds to ObjectIds once if provided
    let objectIds = null;
    if (allowedRoleIds !== null && Array.isArray(allowedRoleIds)) {
      objectIds = allowedRoleIds.map(id => new Types.ObjectId(id));
    }

    const filter = { isDelete: { $ne: true } };

    // Apply user access filter if provided
    if (objectIds) {
      filter._id = { $in: objectIds };
    }

    if (typeof status === 'boolean') {
      filter.isActive = status;
    }

    if (search && `${search}`.trim() !== '') {
      filter.roleName = { $regex: search, $options: 'i' };
    }

    // Exclude superadmin roles if requested
    if (excludeSuperadmin) {
      filter.roleName = { 
        ...filter.roleName,
        $not: /^superadmin$/i 
      };
    }

    // Build sorting - default to latest created first
    const sortOption = { [sortBy]: sortOrder === 'asc' ? 1 : -1 };

    // Create filtered count filter - apply the same filters as the main query to counts
    const filteredCountFilter = { ...filter };
    
    const totalNonDeleted = await Role.countDocuments(filteredCountFilter);
    const totalActive = await Role.countDocuments({ ...filteredCountFilter, isActive: true });
    const totalInactive = await Role.countDocuments({ ...filteredCountFilter, isActive: false });

    const limitNum = Number(limit);
    const isPaginated = Number.isFinite(limitNum) && limitNum > 0;

    if (isPaginated) {
      const pageNum = Number(page) > 0 ? Number(page) : 1;
      const skip = (pageNum - 1) * limitNum;

      const [roles, total] = await Promise.all([
        Role.find(filter).sort(sortOption).skip(skip).limit(limitNum).lean(),
        Role.countDocuments(filter),
      ]);

      const totalPages = Math.max(1, Math.ceil(total / limitNum));

      return {
        roles,
        pagination: {
          currentPage: pageNum,
          totalPages,
          totalRoles: total,
          hasNextPage: pageNum < totalPages,
          hasPrevPage: pageNum > 1,
          limit: limitNum,
        },
        totalNonDeleted,
        totalActive,
        totalInactive
      };
    }

    // no limit provided → full list
    const roles = await Role.find(filter).sort(sortOption).lean();
    return {
      roles,
      pagination: null,
      totalNonDeleted,
      totalActive,
      totalInactive
    };
  } catch (error) {
    throw new Error(`Error fetching roles list: ${error.message}`);
  }
};

export const deleteRole = async (roleId) => {
  try {
    return await Role.findByIdAndUpdate(
      roleId,
      { isDelete: true },
      { new: true }
    );
  } catch (error) {
    throw new Error(`Error deleting role: ${error.message}`);
  }
};

export const activateRole = async (roleId, isActive) => {
  try {
    return await Role.findByIdAndUpdate(
      roleId,
      { isActive },
      { new: true }
    );
  } catch (error) {
    throw new Error(`Error updating role status: ${error.message}`);
  }
};

// Static role permission sections configuration
// Defines UI structure for permission matrix with categories and access levels
// Used by frontend to render role creation/editing interface
export const getRoleSections = () => {
  return {
    "CAMPUS_MANAGEMENT": {
      "label": "Campus Management",
      "permissions": {
        "categories": [
          {
            "name": "Campus Management",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          },
          {
            "name": "Building Management",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          },
          {
            "name": "Floor Management",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          },
          {
            "name": "Zone Management",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          }
        ]
      }
    },
    "INTELLIGENT_CONTROL": {
      "label": "Intelligent Control",
      "permissions": {
        "categories": [
          {
            "name": "Group Management",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          },
          {
            "name": "Scene Management",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          },
          {
            "name": "Sensor Management",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          },
          {
            "name": "Template Management",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          }
        ]
      }
    },
    "DEVICE_MANAGEMENT": {
      "label": "Device Management",
      "permissions": {
        "categories": [
          {
            "name": "Device Control",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          },
          {
            "name": "Manage Channels",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          },
          {
            "name": "Manage Sensors",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          }
        ]
      }
    },
    "USER_MANAGEMENT": {
      "label": "User Management",
      "permissions": {
        "categories": [
          {
            "name": "User Accounts",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          },
          {
            "name": "Role Management",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          }
        ]
      }
    },
    "LOGS_MONITORING": {
      "label": "Logs Monitoring",
      "permissions": {
        "categories": [
          {
            "name": "Event Logs",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          },
          {
            "name": "MQTT Logs",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          }
        ]
      }
    },
    "CONTROL_SECTION": {
      "label": "Control Section",
      "permissions": {
        "categories": [
          {
            "name": "Template Tab",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          },
          {
            "name": "Scene Tab",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          },
          {
            "name": "Group Tab",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          },
          {
            "name": "Device Tab",
            "accesses": [
              { "label": "Full Access", "value": "fullAccess", "checked": false },
              { "label": "Read Only", "value": "readOnly", "checked": false },
              { "label": "Add/Modify", "value": "addModify", "checked": false }
            ]
          }
        ]
      }
    }
  }
    ;
};

// Case-insensitive role name search (includes deleted roles)
export const findRoleByNameCI = async (roleName) => {
  return Role.findOne({ roleName: roleName }).collation({ locale: 'en', strength: 2 });
};

// Case-insensitive search for active roles only
export const findActiveRoleByNameCI = async (roleName) => {
  return Role.findOne({ 
    roleName: roleName, 
    isDelete: { $ne: true } 
  }).collation({ locale: 'en', strength: 2 });
};

// Reactivate soft-deleted role with new permissions
// Resets timestamps and activation status
export const reactivateRole = async (roleId, updateData) => {
  try {
    const now = new Date();
    const reactivationData = {
      ...updateData,
      isDelete: false,
      isActive: true,
      createdAt: now,
      updatedAt: now
    };
    return await Role.findByIdAndUpdate(roleId, reactivationData, { new: true });
  } catch (error) {
    if (error.code === 11000) {
      throw new Error('Duplicate role name not allowed');
    }
    throw new Error(`Error reactivating role: ${error.message}`);
  }
};