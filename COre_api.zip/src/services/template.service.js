import { User } from '../models/User.js';
import { Template } from "../models/Template.js";
import Device from '../models/Device.js';
import { Group } from '../models/Group.js';
import { Scene } from '../models/Scene.js';
import mongoose from 'mongoose';
import { socketManager } from '../utils/socketManager.js';
/**
 * Template Service - Dashboard template and widget management with real-time data integration
 * 
 * Handles creation and management of customizable dashboard interfaces
 * Manages device controls, scene widgets, weather data, and capability mapping
 * Coordinates with permission system and provides real-time widget updates
 */

const { Types } = mongoose;

// Get paginated template list with permission filtering and zone-based access control
export const getTemplateList = async (params) => {
  const {
    filter = {},
    search = '',
    page = 1,
    limit = 10,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    user = null
  } = params;

  const query = {};

  // Filter by allowedTemplateIds if provided (skip for superadmin)
  if (params.allowedTemplateIds && Array.isArray(params.allowedTemplateIds) && user?.role_id?.roleName?.toLowerCase() !== 'superadmin') {
    if (params.allowedTemplateIds.length > 0) {
      query._id = { $in: params.allowedTemplateIds.map(id => new mongoose.Types.ObjectId(id)) };
    } else {
      // Empty array means no templates allowed - return no results
      query._id = { $in: [] };
    }
  }

  // Filter by template name
  if (filter.name) {
    query.name = { $regex: filter.name, $options: 'i' };
  }

  // Filter by layout type
  if (filter.layout_type) {
    query.layout_type = filter.layout_type;
  }

  // Search by template name
  if (search) {
    query.$or = [
      { name: { $regex: search, $options: 'i' } }
    ];
  }

  const skip = (page - 1) * limit;

  // Build sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // Apply zone-based filtering first to get accurate total count
  let zoneFilterQuery = { ...query };
  if (user && user.campusData && Array.isArray(user.campusData) && user.campusData.length > 0) {
    // Extract zone IDs from user's campus data
    const zoneIds = [];
    user.campusData.forEach(campus => {
      if (campus.buildings && Array.isArray(campus.buildings)) {
        campus.buildings.forEach(building => {
          if (building.floors && Array.isArray(building.floors)) {
            building.floors.forEach(floor => {
              if (floor.zones && Array.isArray(floor.zones)) {
                floor.zones.forEach(zone => {
                  if (zone.zone_id) {
                    zoneIds.push(zone.zone_id);
                  }
                });
              }
            });
          }
        });
      }
    });

    if (zoneIds.length > 0) {
      // Get all templates first to apply zone filtering
      const allTemplates = await Template.find(query).lean();
      
      // Filter templates based on whether they have devices in allowed zones
      const templateFilterPromises = allTemplates.map(async (template) => {
        const deviceIds = new Set();
        const sceneIds = new Set();
        
        const rows = (template.layoutStructure?.rows) || [];
        for (const row of rows) {
          for (const col of row.columns || []) {
            if (col.type === 'scene' && col.id) {
              sceneIds.add(String(col.id));
            }
            for (const el of col.elements || []) {
              if (el.deviceId) deviceIds.add(el.deviceId);
              if (el.sceneId) sceneIds.add(String(el.sceneId));
              if (el.type === 'scene' && el.id) {
                sceneIds.add(String(el.id));
              }
            }
          }
        }

        let hasAllowedDevice = false;

        if (deviceIds.size > 0) {
          const allowedDevicesCount = await Device.countDocuments({
            device_id: { $in: Array.from(deviceIds) },
            zone: { $in: zoneIds },
            deletedAt: null
          });
          hasAllowedDevice = allowedDevicesCount > 0;
        }

        if (!hasAllowedDevice && sceneIds.size > 0) {
          const scenes = await Scene.find({
            _id: { $in: Array.from(sceneIds) },
            isDeleted: { $ne: true }
          }).lean();

          for (const scene of scenes) {
            if (scene.type === 'device' && scene.Devices && scene.Devices.length > 0) {
              const sceneDeviceIds = scene.Devices.map(d => d.deviceId);
              const allowedDevicesCount = await Device.countDocuments({
                device_id: { $in: sceneDeviceIds },
                zone: { $in: zoneIds },
                deletedAt: null
              });
              if (allowedDevicesCount > 0) {
                hasAllowedDevice = true;
                break;
              }
            }

            if (scene.type === 'group' && scene.Groups && scene.Groups.length > 0) {
              const allDeviceIds = scene.Groups.flatMap(group => 
                (group.devices || []).map(d => d.deviceId)
              );
              if (allDeviceIds.length > 0) {
                const allowedDevicesCount = await Device.countDocuments({
                  device_id: { $in: allDeviceIds },
                  zone: { $in: zoneIds },
                  deletedAt: null
                });
                if (allowedDevicesCount > 0) {
                  hasAllowedDevice = true;
                  break;
                }
              }
            }
          }
        }

        return hasAllowedDevice ? template._id : null;
      });

      const templateFilterResults = await Promise.all(templateFilterPromises);
      const allowedTemplateIds = templateFilterResults.filter(id => id !== null);
      
      if (allowedTemplateIds.length === 0) {
        return {
          data: [],
          total: 0,
          page,
          limit
        };
      }
      
      // Update query to only include zone-filtered templates
      zoneFilterQuery._id = { 
        $in: allowedTemplateIds,
        ...(zoneFilterQuery._id ? { $in: zoneFilterQuery._id.$in.filter(id => allowedTemplateIds.some(aid => aid.toString() === id.toString())) } : {})
      };
    } else {
      // No zones in user's campus data, return empty
      return {
        data: [],
        total: 0,
        page,
        limit
      };
    }
  }

  // Now get the final filtered templates with pagination
  const templates = await Template.find(zoneFilterQuery)
    .sort(sort)
    .skip(skip)
    .limit(limit)
    .lean();

  const total = await Template.countDocuments(zoneFilterQuery);

  return {
    data: templates,
    total,
    page,
    limit
  };
};

// Get predefined layout configurations for template creation interface
export const getLayoutList = async () => {
  // Assuming layouts are predefined. This can be fetched from DB if needed.
  const layouts = [
    {
      id: "1x1_landscape",
      rows: 1,
      columns: 1,
      layout: "landscape",
    },
    {
      id: "1x2_landscape",
      rows: 1,
      columns: 2,
      layout: "landscape",
    },
    {
      id: "1x3_landscape",
      rows: 1,
      columns: 3,
      layout: "landscape",
    },
    {
      id: "1x1_portrait",
      rows: 1,
      columns: 1,
      layout: "portrait",
    },
    {
      id: "1x2_portrait",
      rows: 1,
      columns: 2,
      layout: "portrait",
    },
    {
      id: "1x3_portrait",
      rows: 1,
      columns: 3,
      layout: "portrait",
    },
  ];
  return layouts;
}

// Create dashboard template with capability mapping and auto-permission assignment
export const createTemplate = async (data, user = null) => {
  const { name, layout, status, rows, columns, layoutStructure } = data;

  // deep clone to avoid mutating caller's object
  const layoutClone = JSON.parse(JSON.stringify(layoutStructure || {}));

  // cache to avoid repeated DB hits for same pair: { "<deviceId>::<channelId>": capabilityOrNull }
  const capabilityCache = new Map();

  // helper to fetch capability for a given deviceId + channelId using positional projection
  const fetchCapabilityId = async (deviceId, channelId) => {
    const key = `${deviceId}::${channelId}`;
    if (capabilityCache.has(key)) return capabilityCache.get(key); // may be ObjectId or null

    if (!deviceId || !channelId) {
      capabilityCache.set(key, null);
      return null;
    }

    // find the device that contains a capability with this channelId and return only that capability
    const deviceDoc = await Device.findOne(
      { 
        device_id: deviceId, 
        'capabilities.channelId': channelId,
        deletedAt: null,
        is_delete: { $ne: true }
      },
      { 'capabilities.$': 1 } // positional projection returns only the matching capability in the array
    ).lean();

    // deviceDoc?.capabilities[0] will be the matched capability or undefined
    const capability = deviceDoc && Array.isArray(deviceDoc.capabilities) ? deviceDoc.capabilities[0] : null;
    const capabilityId = capability && capability._id ? capability._id : null;

    capabilityCache.set(key, capabilityId);
    return capabilityId;
  };

  // iterate layout structure and fill capabilityId by querying DB per unique (deviceId, channelId)
  if (layoutClone && Array.isArray(layoutClone.rows)) {
    // collect pairs first (optional) or just iterate and fetch inline
    for (const row of layoutClone.rows) {
      if (!row || !Array.isArray(row.columns)) continue;
      for (const col of row.columns) {
        if (!col || !Array.isArray(col.elements)) continue;
        for (const el of col.elements) {
          // default null
          el.capabilityId = null;

          // only check when both deviceId and channelId present
          if (el && el.deviceId && el.channelId) {
            try {
              const capId = await fetchCapabilityId(el.deviceId, el.channelId);
              // capId will be an ObjectId (if found) or null
              el.capabilityId = capId;
            } catch (err) {
              // in case of DB errors, leave null but log if needed
              // console.error('fetch capability error', err);
              el.capabilityId = null;
            }
          }
        }
      }
    }
  }

  // create and save template
  const newTemplate = new Template({
    name,
    layout,
    status,
    rows,
    columns,
    layoutStructure: layoutClone
  });

  await newTemplate.save();

  // --- Add template._id to allowedResources based on user roles ---
  // Superadmin: Always has allowedResources: null, don't update anything
  // Admin & Technician: Add to both intelligentControl.templates and controlSection.templateTab
  // Operator & Tenant: Add only to controlSection.templateTab
  try {
    const { default: Role } = await import('../models/Role.js');
    const { User } = await import('../models/User.js');
    
    // Find roles for admin, technician (case insensitive)
    const adminTechRoles = await Role.find({ 
      roleName: { 
        $in: ['admin', 'technician'].map(name => new RegExp(`^${name}$`, 'i')) 
      },
      isDelete: { $ne: true },
      isActive: true
    });
    
    // Find roles for operator, tenant (case insensitive)
    const operatorTenantRoles = await Role.find({ 
      roleName: { 
        $in: ['operator', 'tenant'].map(name => new RegExp(`^${name}$`, 'i')) 
      },
      isDelete: { $ne: true },
      isActive: true
    });
    
    console.log(`Found ${adminTechRoles.length} admin/technician roles and ${operatorTenantRoles.length} operator/tenant roles for template access`);
    
    const adminTechRoleIds = adminTechRoles.map(r => r._id);
    const operatorTenantRoleIds = operatorTenantRoles.map(r => r._id);
    
    // Update admin and technician users (add to both intelligentControl.templates and controlSection.templateTab)
    if (adminTechRoleIds.length > 0) {
      const adminTechUsers = await User.find({ 
        role_id: { $in: adminTechRoleIds },
        allowedResources: { $ne: null },
        isDeleted: { $ne: true },
        isActive: true
      });
      
      console.log(`Found ${adminTechUsers.length} admin/technician users to update with template access`);
      
      for (const user of adminTechUsers) {
        // Initialize structures if needed
        if (!user.allowedResources.intelligentControl) {
          user.allowedResources.intelligentControl = {};
        }
        if (!Array.isArray(user.allowedResources.intelligentControl.templates)) {
          user.allowedResources.intelligentControl.templates = [];
        }
        if (!user.allowedResources.controlSection) {
          user.allowedResources.controlSection = {};
        }
        if (!Array.isArray(user.allowedResources.controlSection.templateTab)) {
          user.allowedResources.controlSection.templateTab = [];
        }
        
        // Add to intelligentControl.templates if not already present
        if (!user.allowedResources.intelligentControl.templates.includes(newTemplate._id.toString())) {
          user.allowedResources.intelligentControl.templates.push(newTemplate._id.toString());
        }
        
        // Add to controlSection.templateTab if not already present
        if (!user.allowedResources.controlSection.templateTab.includes(newTemplate._id.toString())) {
          user.allowedResources.controlSection.templateTab.push(newTemplate._id.toString());
        }
        
        await user.save();
        console.log(`Updated admin/technician user ${user.email} with template ID: ${newTemplate._id}`);
      }
    }
    
    // Update operator and tenant users (add only to controlSection.templateTab)
    if (operatorTenantRoleIds.length > 0) {
      const operatorTenantUsers = await User.find({ 
        role_id: { $in: operatorTenantRoleIds },
        allowedResources: { $ne: null },
        isDeleted: { $ne: true },
        isActive: true
      });
      
      console.log(`Found ${operatorTenantUsers.length} operator/tenant users to update with template access`);
      
      for (const user of operatorTenantUsers) {
        // Initialize controlSection if needed
        if (!user.allowedResources.controlSection) {
          user.allowedResources.controlSection = {};
        }
        if (!Array.isArray(user.allowedResources.controlSection.templateTab)) {
          user.allowedResources.controlSection.templateTab = [];
        }
        
        // Add to controlSection.templateTab if not already present
        if (!user.allowedResources.controlSection.templateTab.includes(newTemplate._id.toString())) {
          user.allowedResources.controlSection.templateTab.push(newTemplate._id.toString());
        }
        
        await user.save();
        console.log(`Updated operator/tenant user ${user.email} with template ID: ${newTemplate._id} (controlSection only)`);
      }
    }
    
    console.log(`Successfully updated users with new template access permissions`);
  } catch (userUpdateError) {
    console.error('Error updating users with new template access:', userUpdateError);
    // Don't throw the error here - we still want to return the created template
    // The template was created successfully, user updates are a bonus feature
  }
  socketManager.emitEvent("template", {uiType: ""});
  return newTemplate.toObject();
};

// export const createTemplate = async (data) => {
//   const { name, layout, status, rows, columns, layoutStructure } = data;

//   const newTemplate = new Template({
//     name,
//     layout,
//     status,
//     rows,
//     columns,
//     layoutStructure
//   });

//   await newTemplate.save();
//   return newTemplate.toObject();
// };

// Update template configuration and layout structure with real-time notifications
export const updateTemplate = async (id, data) => {
  const { name, layout, status, rows, columns, layoutStructure } = data;

  const updatedTemplate = await Template.findByIdAndUpdate(
    id,
    {
      name,
      layout,
      status,
      rows,
      columns,
      layoutStructure
    },
    { new: true }
  );

  if (!updatedTemplate) {
    throw new Error('Template not found');
  }
  socketManager.emitEvent("template", {uiType: ""});
  return updatedTemplate.toObject();
};

// Delete template and notify connected clients
export const deleteTemplate = async (id) => {
  const deletedTemplate = await Template.deleteOne({ _id: id });
  if (!deletedTemplate) {
    throw new Error('Template not found');
  }
  socketManager.emitEvent("template", {uiType: ""});
  return deletedTemplate;
};

export const getHierarchy = async (user = null) => {
  // Build device filter with zone-based filtering
  const deviceFilter = { 
    status: 'Active', 
    deletedAt: null,
    is_delete: { $ne: true },
    configure_flag: true
  };

  // Add zone filtering based on user's campusData
  if (user && user.campusData && Array.isArray(user.campusData)) {
    // If campusData is empty, show all data (no zone filtering)
    if (user.campusData.length === 0) {
      // No zone filtering - show all active devices
    } else {
      // Extract zone IDs from user's campusData
      const zoneIds = [];
      user.campusData.forEach(campus => {
        campus.buildings?.forEach(building => {
          building.floors?.forEach(floor => {
            floor.zones?.forEach(zone => {
              if (zone.zone_id) {
                zoneIds.push(zone.zone_id);
              }
            });
          });
        });
      });
      
      // Add zone filter if user has specific zones in campusData
      if (zoneIds.length > 0) {
        deviceFilter.zone = { $in: zoneIds };
      } else {
        // If no zones found in user's campus data, return empty result
        deviceFilter.zone = { $in: [] };
      }
    }
  }

  // 1. Devices - only get devices in authorized zones with Active status, excluding deleted devices
  const devices = await Device.find(deviceFilter).sort({ createdAt: -1 }).lean();

  const formattedDevices = devices.map((d) => ({
    id: d.device_id,
    name: d.name,
    mac_addr: d.Mac_addr || null,
    channels: d.capabilities
      .filter((c) => c.properties?.installed === true || c.installed === true)
      .map((c) => ({
        id: c.channelId,
        name: c.name,
        type: c.type,
        status: c.status,
        properties: c.properties || {}
      }))
  })).filter(device => device.channels.length > 0);

  // 2. Groups - only include groups that have devices in authorized zones
  const allGroups = await Group.find({ isDeleted: false }).sort({ createdAt: -1 }).lean();

  const formattedGroups = allGroups.map((g) => {
    const groupDevices = g.devices.map((gd) => {
      const device = devices.find((d) => d.device_id === gd.deviceId);
      if (!device) return null;

      return {
        id: device.device_id,
        name: device.name,
        mac_addr: device.Mac_addr || null,
        channels: device.capabilities
          .filter((c) => c.properties?.installed === true || c.installed === true)
          .filter((c) => gd.channels.some((gc) => gc.channelId === c.channelId))
          .map((c) => ({
            id: c.channelId,
            name: c.name,
            type: c.type,
            status: c.status,
            properties: c.properties || {}
          }))
      };
    }).filter(Boolean);

    // Only include groups that have at least one device in authorized zones
    if (groupDevices.length > 0) {
      return {
        id: g._id,
        name: g.name,
        devices: groupDevices
      };
    }
    return null;
  }).filter(Boolean);

  // 3. Scenes - only include scenes that have devices in authorized zones
  const allScenes = await Scene.find({ deletedAt: null, isDeleted: { $ne: true } }).sort({ createdAt: -1 }).lean();

  const formattedScenes = allScenes.map((s) => {
    let sceneDevices = [];
    let sceneGroups = [];

    if (s.Devices && s.Devices.length > 0) {
      sceneDevices = s.Devices.map((sd) => {
        const device = devices.find((d) => d.device_id === sd.deviceId);
        if (!device) return null;

        return {
          id: device.device_id,
          name: device.name,
          mac_addr: device.Mac_addr || null,
          channels: device.capabilities
            .filter((c) => c.properties?.installed === true || c.installed === true)
            .filter((c) => sd.channels.some((sc) => sc.channelId === c.channelId))
            .map((c) => ({
              id: c.channelId,
              name: c.name,
              type: c.type,
              status: c.status,
              properties: c.properties || {}
            }))
        };
      }).filter(Boolean);
    }

    if (s.Groups && s.Groups.length > 0) {
      sceneGroups = s.Groups.map((sg) => {
        const group = formattedGroups.find((g) => g.id.toString() === sg.groupId.toString());
        return group || null;
      }).filter(Boolean);
    }

    // Only include scenes that have at least one device or group with devices in authorized zones
    if (sceneDevices.length > 0 || sceneGroups.length > 0) {
      return {
        id: s._id,
        name: s.name,
        devices: sceneDevices,
        groups: sceneGroups,
        invert_flag: s.invert_flag ?? false,
        operateType: s.operateType ?? 'normal'
      };
    }
    return null;
  }).filter(Boolean);

  return {
    devices: formattedDevices,
    groups: formattedGroups,
    scenes: formattedScenes
  };
};

// export const getTemplateById = async (templateId) => {
//   const template = await Template.findById(templateId);

//   if (!template) {
//     return null;
//   }

//   return template.toObject();
// };

// Get template by ID with device capability mapping and widget data integration
export const getTemplateById = async (templateId) => {
  const templateDoc = await Template.findById(templateId);
  if (!templateDoc) return null;

  // Convert to plain object so we can modify safely
  const template = templateDoc.toObject();

  // helper to get a stable string id from various shapes
  const toStrId = (v) => {
    if (!v) return null;
    if (Types.ObjectId.isValid(v)) return String(v);
    if (typeof v === "object" && v.$oid) return v.$oid;
    if (typeof v === "string") return v;
    return String(v);
  };

  // collect deviceIds, sceneIds, and widgetIds
  const deviceIds = new Set();
  const sceneIds = new Set();
  const widgetIds = new Set();
  const rows = (template.layoutStructure?.rows) || [];
  for (const row of rows) {
    for (const col of row.columns || []) {
      // If columns are scene type, collect id as sceneId
      if (col.type === 'scene' && col.id) {
        sceneIds.add(toStrId(col.id));
      }
      // If columns are widget type, collect id as widgetId
      if (col.type === 'widget' && col.id) {
        widgetIds.add(toStrId(col.id));
      }
      for (const el of col.elements || []) {
        if (el.deviceId) deviceIds.add(el.deviceId);
        if (el.sceneId) sceneIds.add(toStrId(el.sceneId));
        // If element is scene type and has id, collect as sceneId
        if (el.type === 'scene' && el.id) {
          sceneIds.add(toStrId(el.id));
        }
      }
    }
  }

  // fetch devices
  let devicesById = {};
  if (deviceIds.size > 0) {
    const devices = await Device.find({ 
      device_id: { $in: Array.from(deviceIds) },
      deletedAt: null,
      is_delete: { $ne: true }
    }).lean();
    devicesById = devices.reduce((acc, d) => {
      acc[d.device_id] = d;
      return acc;
    }, {});
  }

  // fetch widgets
  let widgetsById = {};
  if (widgetIds.size > 0) {
    const { WidgetStorage } = await import('../models/WidgetStorage.js');
    const widgets = await WidgetStorage.find({ 
      _id: { $in: Array.from(widgetIds) },
      isDeleted: false
    }).lean();
    widgetsById = widgets.reduce((acc, w) => {
      acc[toStrId(w._id)] = w;
      return acc;
    }, {});
  }

  // fetch scenes for operateType and invert_flag
  let scenesById = {};
  if (sceneIds.size > 0) {
    const scenes = await Scene.find({ _id: { $in: Array.from(sceneIds) } }).lean();
    scenesById = scenes.reduce((acc, s) => {
      acc[toStrId(s._id)] = s;
      return acc;
    }, {});
  }

  // Walk elements and update capabilityId => string and status from device capability if found
  for (const row of rows) {
    for (const col of row.columns || []) {
      // If column is scene type and has id, override operateType and invert_flag
      if (col.type === 'scene' && col.id) {
        const scene = scenesById[toStrId(col.id)];
        if (scene) {
          col.operateType = scene.operateType;
          col.invert_flag = scene.invert_flag;
        }
      }
      
      // If column is widget type and has id, add widget data
      if (col.type === 'widget' && col.id) {
        const widgetData = widgetsById[toStrId(col.id)];
        if (widgetData) {
          col.widget_data = {
            _id: widgetData._id,
            structure: widgetData.structure
          };
        }
      }
      for (const el of col.elements || []) {
        const capIdStr = toStrId(el.capabilityId);
        if (capIdStr) el.capabilityId = capIdStr;

        const device = devicesById[el.deviceId];
        if (device?.capabilities) {
          // First try to match by capabilityId (existing logic)
          let matchedCap = device.capabilities.find((c) => toStrId(c._id) === capIdStr);
          
          // If no match by capabilityId and element has channelId, match by channelId
          if (!matchedCap && el.channelId) {
            matchedCap = device.capabilities.find((c) => c.channelId === el.channelId);
            
            // If matched by channelId, update the element's capabilityId for consistency
            if (matchedCap) {
              el.capabilityId = toStrId(matchedCap._id);
            }
          }
          
          if (matchedCap) {
            el.status = matchedCap.status;
            if (!el.properties) el.properties = {};
            
            // Copy all capability properties to element properties
            if (matchedCap.properties) {
              Object.assign(el.properties, matchedCap.properties);
            }
            
            // Add additional device information to element
            el.deviceName = device.name;
            el.deviceType = device.type;
            el.channelName = matchedCap.name;
            el.channelType = matchedCap.type;
          }
        }

        // If element has sceneId, always take operateType and invert_flag from scene
        let sceneRefId = null;
        if (el.sceneId) sceneRefId = toStrId(el.sceneId);
        else if (el.type === 'scene' && el.id) sceneRefId = toStrId(el.id);
        if (sceneRefId) {
          const scene = scenesById[sceneRefId];
          if (scene) {
            el.operateType = scene.operateType;
            el.invert_flag = scene.invert_flag;
          }
        }
      }
    }
  }

  // normalize dates
  template.createdAt = new Date(template.createdAt).toISOString();
  template.updatedAt = new Date(template.updatedAt).toISOString();
  template.id = toStrId(template._id);

  return template;
};

// Get templates accessible by user based on permission matrix and zone access
export const getTemplatesByUserAccess = async (templateIds, searchName = null, user = null) => {
  // Only fetch templates with status 'Active' (case-insensitive) and not deleted
  // If templateIds is null, return all active, non-deleted templates
  const query = {
    status: { $regex: /^active$/i }
  };
  if (Array.isArray(templateIds)) {
    query._id = { $in: templateIds };
  }
  
  // Add name search functionality if searchName is provided
  if (searchName && searchName.trim()) {
    query.name = { $regex: searchName.trim(), $options: 'i' }; // Case-insensitive search
  }
  
  // If template schema ever adds isDeleted, add: isDeleted: false
  const templates = await Template.find(query).lean();
  
  // Apply zone-based filtering if user has campusData
  let filteredTemplates = templates;
  if (user && user.campusData && Array.isArray(user.campusData)) {
    // If campusData is empty array, show all data (no filtering)
    if (user.campusData.length > 0) {
      // Extract zone IDs from user's campus data
      const zoneIds = [];
      user.campusData.forEach(campus => {
        if (campus.buildings && Array.isArray(campus.buildings)) {
          campus.buildings.forEach(building => {
            if (building.floors && Array.isArray(building.floors)) {
              building.floors.forEach(floor => {
                if (floor.zones && Array.isArray(floor.zones)) {
                  floor.zones.forEach(zone => {
                    if (zone.zone_id) {
                      zoneIds.push(zone.zone_id);
                    }
                  });
                }
              });
            }
          });
        }
      });

      if (zoneIds.length > 0) {
        // Filter templates based on whether they have devices in allowed zones
        const templateFilterPromises = templates.map(async (template) => {
          // Extract device IDs from template's layoutStructure
          const deviceIds = new Set();
          const sceneIds = new Set();
          
          const rows = (template.layoutStructure?.rows) || [];
          for (const row of rows) {
            for (const col of row.columns || []) {
              // If column is scene type, collect scene ID
              if (col.type === 'scene' && col.id) {
                sceneIds.add(String(col.id));
              }
              for (const el of col.elements || []) {
                if (el.deviceId) deviceIds.add(el.deviceId);
                if (el.sceneId) sceneIds.add(String(el.sceneId));
                if (el.type === 'scene' && el.id) {
                  sceneIds.add(String(el.id));
                }
              }
            }
          }

          let hasAllowedDevice = false;

          // Check if any directly referenced devices are in allowed zones
          if (deviceIds.size > 0) {
            const allowedDevicesCount = await Device.countDocuments({
              device_id: { $in: Array.from(deviceIds) },
              zone: { $in: zoneIds },
              deletedAt: null
            });
            hasAllowedDevice = allowedDevicesCount > 0;
          }

          // Check if any referenced scenes have devices in allowed zones
          if (!hasAllowedDevice && sceneIds.size > 0) {
            const scenes = await Scene.find({
              _id: { $in: Array.from(sceneIds) },
              isDeleted: { $ne: true }
            }).lean();

            for (const scene of scenes) {
              // Check devices directly in scene
              if (scene.type === 'device' && scene.Devices && scene.Devices.length > 0) {
                const sceneDeviceIds = scene.Devices.map(d => d.deviceId);
                const allowedDevicesCount = await Device.countDocuments({
                  device_id: { $in: sceneDeviceIds },
                  zone: { $in: zoneIds },
                  deletedAt: null
                });
                if (allowedDevicesCount > 0) {
                  hasAllowedDevice = true;
                  break;
                }
              }

              // Check devices in groups within scene  
              if (scene.type === 'group' && scene.Groups && scene.Groups.length > 0) {
                const allDeviceIds = scene.Groups.flatMap(group => 
                  (group.devices || []).map(d => d.deviceId)
                );
                if (allDeviceIds.length > 0) {
                  const allowedDevicesCount = await Device.countDocuments({
                    device_id: { $in: allDeviceIds },
                    zone: { $in: zoneIds },
                    deletedAt: null
                  });
                  if (allowedDevicesCount > 0) {
                    hasAllowedDevice = true;
                    break;
                  }
                }
              }
            }
          }

          return hasAllowedDevice ? template : null;
        });

        const results = await Promise.all(templateFilterPromises);
        filteredTemplates = results.filter(template => template !== null);
      } else {
        // No zones in user's campus data, return empty result
        filteredTemplates = [];
      }
    }
  }
  
  return filteredTemplates;
};

// Get template with complete scene details and real-time widget data for dashboard rendering
export const getTemplateByIdWithSceneDetails = async (templateId) => {
  const templateDoc = await Template.findById(templateId);
  if (!templateDoc) return null;

  // Convert to plain object so we can modify safely
  const template = templateDoc.toObject();

  // helper to get a stable string id from various shapes
  const toStrId = (v) => {
    if (!v) return null;
    if (Types.ObjectId.isValid(v)) return String(v);
    if (typeof v === "object" && v.$oid) return v.$oid;
    if (typeof v === "string") return v;
    return String(v);
  };

  // collect deviceIds, sceneIds, and widgetIds
  const deviceIds = new Set();
  const sceneIds = new Set();
  const widgetIds = new Set();
  const rows = (template.layoutStructure?.rows) || [];
  for (const row of rows) {
    for (const col of row.columns || []) {
      // If columns are scene type, collect id as sceneId
      if (col.type === 'scene' && col.id) {
        sceneIds.add(toStrId(col.id));
      }
      // If columns are widget type, collect id as widgetId
      if (col.type === 'widget' && col.id) {
        widgetIds.add(toStrId(col.id));
      }
      for (const el of col.elements || []) {
        if (el.deviceId) deviceIds.add(el.deviceId);
        if (el.sceneId) sceneIds.add(toStrId(el.sceneId));
        // If element is scene type and has id, collect as sceneId
        if (el.type === 'scene' && el.id) {
          sceneIds.add(toStrId(el.id));
        }
      }
    }
  }

  // fetch devices
  let devicesById = {};
  if (deviceIds.size > 0) {
    const devices = await Device.find({ 
      device_id: { $in: Array.from(deviceIds) },
      deletedAt: null,
      is_delete: { $ne: true }
    }).lean();
    devicesById = devices.reduce((acc, d) => {
      acc[d.device_id] = d;
      return acc;
    }, {});
  }

  // fetch widgets with current weather data
  let widgetsById = {};
  if (widgetIds.size > 0) {
    const { WidgetStorage } = await import('../models/WidgetStorage.js');
    const { Weather } = await import('../models/Weather.js');
    
    const widgets = await WidgetStorage.find({ 
      _id: { $in: Array.from(widgetIds) },
      isDeleted: false
    }).lean();
    
    // Get current weather data for all active weather records
    const weatherData = await Weather.find({ isActive: true, isDeleted: false });
    const weatherMap = {};
    
    for (const weather of weatherData) {
      const hourlyData = weather.weatherData?.hourly;
      const dailyData = weather.weatherData?.daily;
      
      if (hourlyData?.time && hourlyData.time.length) {
        // Get timezone info from weather data
        const storedTimezone = weather.weatherData?.timezone || 'UTC';
        const utcOffsetSeconds = weather.weatherData?.utc_offset_seconds || 0;
        
        // Get current time in UTC
        const now = new Date();
        const utcTimeISO = now.toISOString().slice(0, 13) + ':00';
        
        // Determine the actual timezone for this location based on coordinates
        let actualTimezone = storedTimezone;
        
        // Special handling for India (coordinates around 22.75, 75.89 = Indore)
        if (weather.lat >= 6 && weather.lat <= 37 && weather.long >= 68 && weather.long <= 97) {
          actualTimezone = 'Asia/Kolkata'; // India timezone
        }
        // Add more regions as needed
        
        // Calculate current time in the actual location timezone  
        let locationTime;
        if (actualTimezone !== storedTimezone && (storedTimezone === 'GMT' || storedTimezone === 'UTC')) {
          // Data stored in GMT but location is in a different timezone
          locationTime = new Date(now.toLocaleString("en-US", {timeZone: actualTimezone}));
        } else if (storedTimezone === 'GMT' || storedTimezone === 'UTC') {
          // Use UTC offset from weather data
          locationTime = new Date(now.getTime() + (utcOffsetSeconds * 1000));
        } else {
          // Use the stored timezone
          locationTime = new Date(now.toLocaleString("en-US", {timeZone: storedTimezone}));
        }
        
        // Format location time to match the stored data format
        const locationYear = locationTime.getFullYear();
        const locationMonth = String(locationTime.getMonth() + 1).padStart(2, '0');
        const locationDay = String(locationTime.getDate()).padStart(2, '0');
        const locationHour = String(locationTime.getHours()).padStart(2, '0');
        const locationTimeISO = `${locationYear}-${locationMonth}-${locationDay}T${locationHour}:00`;
        
        // Find the exact or closest time index to current location time
        let hourIndex = hourlyData.time.findIndex(time => time === locationTimeISO);
        if (hourIndex === -1) {
          // If exact match not found, find the closest previous time that exists
          const availableTimes = hourlyData.time.map((time, index) => ({ time, index }));
          const targetTime = new Date(locationTimeISO).getTime();
          
          // Find the closest time that is not in the future
          let closestIndex = -1;
          let closestDiff = Infinity;
          
          availableTimes.forEach(({ time, index }) => {
            const timeMs = new Date(time).getTime();
            const diff = targetTime - timeMs;
            
            // Only consider times that are not in the future (diff >= 0)
            if (diff >= 0 && diff < closestDiff) {
              closestDiff = diff;
              closestIndex = index;
            }
          });
          
          // If no past time found, use the last available time
          hourIndex = closestIndex >= 0 ? closestIndex : hourlyData.time.length - 1;
        }
        
        // Determine if it's day or night based on location time
        const currentTime = hourlyData.time[hourIndex];
        const sunrise = dailyData?.sunrise?.[0];
        const sunset = dailyData?.sunset?.[0];
        let is_day = null;
        
        if (currentTime && sunrise && sunset) {
          const currentTimeMs = new Date(currentTime).getTime();
          const sunriseMs = new Date(sunrise).getTime();
          const sunsetMs = new Date(sunset).getTime();
          is_day = currentTimeMs >= sunriseMs && currentTimeMs < sunsetMs;
        }
        
        // Convert sunset and sunrise to UTC
        let sunriseUTC = null;
        let sunsetUTC = null;
        
        if (sunrise) {
          const sunriseLocalDate = new Date(sunrise);
          const sunriseUTCTime = sunriseLocalDate.getTime() - (weather.weatherData?.utc_offset_seconds || 0) * 1000;
          sunriseUTC = new Date(sunriseUTCTime).toISOString();
        }
        
        if (sunset) {
          const sunsetLocalDate = new Date(sunset);
          const sunsetUTCTime = sunsetLocalDate.getTime() - (weather.weatherData?.utc_offset_seconds || 0) * 1000;
          sunsetUTC = new Date(sunsetUTCTime).toISOString();
        }
        
        weatherMap[weather._id.toString()] = {
          time: utcTimeISO, // Show current UTC time
          weather_code: hourlyData.weather_code?.[hourIndex] !== undefined ? hourlyData.weather_code[hourIndex] : null,
          temperature_2m: hourlyData.temperature_2m?.[hourIndex] !== undefined ? hourlyData.temperature_2m[hourIndex] : null,
          dew_point_2m: hourlyData.dew_point_2m?.[hourIndex] !== undefined ? hourlyData.dew_point_2m[hourIndex] : null,
          cloud_cover: hourlyData.cloud_cover?.[hourIndex] !== undefined ? hourlyData.cloud_cover[hourIndex] : null,
          apparent_temperature: hourlyData.apparent_temperature?.[hourIndex] !== undefined ? hourlyData.apparent_temperature[hourIndex] : null,
          relative_humidity_2m: hourlyData.relative_humidity_2m?.[hourIndex] !== undefined ? hourlyData.relative_humidity_2m[hourIndex] : null,
          surface_pressure: hourlyData.surface_pressure?.[hourIndex] !== undefined ? hourlyData.surface_pressure[hourIndex] : null,
          wind_speed_10m: hourlyData.wind_speed_10m?.[hourIndex] !== undefined ? hourlyData.wind_speed_10m[hourIndex] : null,
          visibility: hourlyData.visibility?.[hourIndex] !== undefined ? hourlyData.visibility[hourIndex] : null,
          uv_index: hourlyData.uv_index?.[hourIndex] !== undefined ? hourlyData.uv_index[hourIndex] : null,
          sunshine_duration: hourlyData.sunshine_duration?.[hourIndex] !== undefined ? hourlyData.sunshine_duration[hourIndex] : null,
          us_aqi: hourlyData.us_aqi?.[hourIndex] !== undefined ? hourlyData.us_aqi[hourIndex] : null,
          pm10: hourlyData.pm10?.[hourIndex] !== undefined ? hourlyData.pm10[hourIndex] : null,
          pm2_5: hourlyData.pm2_5?.[hourIndex] !== undefined ? hourlyData.pm2_5[hourIndex] : null,
          sunset: sunsetUTC,
          sunrise: sunriseUTC,
          temperature_2m_max: dailyData?.temperature_2m_max?.[0] || null,
          temperature_2m_min: dailyData?.temperature_2m_min?.[0] || null,
          is_day,
          timezone: "UTC" // Always UTC
        };
      }
    }
    
    widgetsById = widgets.reduce((acc, w) => {
      const widgetObj = { ...w };
      
      // Update weather widgets with current hour data
      if (widgetObj.structure) {
        widgetObj.structure = widgetObj.structure.map(item => {
          if (item.type === 'weather' && item.data?._id && weatherMap[item.data._id]) {
            return {
              ...item,
              data: {
                ...item.data,
                currentHourData: weatherMap[item.data._id]
              }
            };
          }
          return item;
        });
      }
      
      acc[toStrId(w._id)] = widgetObj;
      return acc;
    }, {});
  }

  // fetch scenes with detailed information
  let scenesById = {};
  if (sceneIds.size > 0) {
    const { getSceneDetails } = await import('./scene.service.js');
    
    const scenePromises = Array.from(sceneIds).map(async (sceneId) => {
      try {
        const sceneDetails = await getSceneDetails(sceneId);
        
        // Transform scene details to match expected format (remove extra fields)
        const filteredSceneDetails = {
          _id: sceneDetails._id,
          name: sceneDetails.name,
          type: sceneDetails.type,
          status: sceneDetails.status,
          statusText: sceneDetails.statusText,
          lastExecuted: sceneDetails.lastExecuted,
          executedBy: sceneDetails.executedBy,
          createdAt: sceneDetails.createdAt,
          updatedAt: sceneDetails.updatedAt,
          invert_flag: sceneDetails.invert_flag,
          operateType: sceneDetails.operateType,
          devices: sceneDetails.devices ? sceneDetails.devices.map(device => ({
            deviceId: device.deviceId,
            deviceName: device.deviceName,
            deviceType: device.deviceType,
            serialNumber: device.serialNumber,
            macAddress: device.macAddress,
            status: device.status,
            isActive: device.isActive,
            isConfigured: device.isConfigured,
            isReadyForScene: device.isReadyForScene,
            statusMessage: device.statusMessage,
            sceneChannels: device.sceneChannels
          })) : [],
          groups: sceneDetails.groups ? sceneDetails.groups.map(group => ({
            groupId: group.groupId,
            groupName: group.groupName,
            groupDescription: group.groupDescription,
            groupStatus: group.groupStatus,
            devices: group.devices ? group.devices.map(device => ({
              deviceId: device.deviceId,
              deviceName: device.deviceName,
              deviceType: device.deviceType,
              serialNumber: device.serialNumber,
              macAddress: device.macAddress,
              status: device.status,
              isActive: device.isActive,
              isConfigured: device.isConfigured,
              isReadyForScene: device.isReadyForScene,
              statusMessage: device.statusMessage,
              sceneChannels: device.sceneChannels
            })) : []
          })) : [],
          deviceCount: sceneDetails.deviceCount,
          activeDeviceCount: sceneDetails.activeDeviceCount,
          readyDeviceCount: sceneDetails.readyDeviceCount,
          totalChannels: sceneDetails.totalChannels,
          validChannels: sceneDetails.validChannels,
          isSceneExecutable: sceneDetails.isSceneExecutable
        };
        
        return { id: sceneId, details: filteredSceneDetails };
      } catch (error) {
        console.error(`Error fetching scene details for ${sceneId}:`, error.message);
        // Fallback to basic scene info
        const scene = await Scene.findById(sceneId).lean();
        return { 
          id: sceneId, 
          details: scene ? {
            _id: scene._id,
            name: scene.name,
            type: scene.type,
            status: scene.status,
            statusText: scene.status === 1 ? 'active' : 'inactive',
            operateType: scene.operateType || 'normal',
            invert_flag: scene.invert_flag || false,
            error: 'Failed to fetch detailed information'
          } : null
        };
      }
    });
    
    const sceneResults = await Promise.all(scenePromises);
    scenesById = sceneResults.reduce((acc, result) => {
      if (result.details) {
        acc[result.id] = result.details;
      }
      return acc;
    }, {});
  }

  // Walk elements and update capabilityId => string and status from device capability if found
  for (const row of rows) {
    for (const col of row.columns || []) {
      // If column is scene type and has id, add detailed scene information
      if (col.type === 'scene' && col.id) {
        const sceneDetails = scenesById[toStrId(col.id)];
        if (sceneDetails) {
          // Get brightness from first scene channel (check both devices and groups)
          let sceneBrightness = null;
          
          // First try to get brightness from devices
          if (sceneDetails.devices && sceneDetails.devices.length > 0) {
            const firstDevice = sceneDetails.devices[0];
            if (firstDevice.sceneChannels && firstDevice.sceneChannels.length > 0) {
              const firstChannel = firstDevice.sceneChannels[0];
              sceneBrightness = firstChannel.brightness !== undefined ? firstChannel.brightness : null;
            }
          }
          
          // If no brightness from devices, try to get from groups
          if (sceneBrightness === null && sceneDetails.groups && sceneDetails.groups.length > 0) {
            const firstGroup = sceneDetails.groups[0];
            if (firstGroup.devices && firstGroup.devices.length > 0) {
              const firstDevice = firstGroup.devices[0];
              if (firstDevice.sceneChannels && firstDevice.sceneChannels.length > 0) {
                const firstChannel = firstDevice.sceneChannels[0];
                sceneBrightness = firstChannel.brightness !== undefined ? firstChannel.brightness : null;
              }
            }
          }
          
          col.scene_brightness = sceneBrightness;
          col.sceneDetails = sceneDetails;
          col.operateType = sceneDetails.operateType;
          col.invert_flag = sceneDetails.invert_flag;
          col.scene_name = sceneDetails.name;
          col.isSceneExecutable = sceneDetails.isSceneExecutable || false;
        }
      }
      
      // If column is widget type and has id, add widget data
      if (col.type === 'widget' && col.id) {
        const widgetData = widgetsById[toStrId(col.id)];
        if (widgetData) {
          col.widget_data = {
            _id: widgetData._id,
            structure: widgetData.structure
          };
        }
      }
      
      for (const el of col.elements || []) {
        const capIdStr = toStrId(el.capabilityId);
        if (capIdStr) el.capabilityId = capIdStr;

        const device = devicesById[el.deviceId];
        if (device?.capabilities) {
          // First try to match by capabilityId (existing logic)
          let matchedCap = device.capabilities.find((c) => toStrId(c._id) === capIdStr);
          
          // If no match by capabilityId and element has channelId, match by channelId
          if (!matchedCap && el.channelId) {
            matchedCap = device.capabilities.find((c) => c.channelId === el.channelId);
            
            // If matched by channelId, update the element's capabilityId for consistency
            if (matchedCap) {
              el.capabilityId = toStrId(matchedCap._id);
            }
          }
          
          if (matchedCap) {
            el.status = matchedCap.status;
            if (!el.properties) el.properties = {};
            
            // Copy all capability properties to element properties
            if (matchedCap.properties) {
              Object.assign(el.properties, matchedCap.properties);
            }
            
            // Add additional device information to element
            el.deviceName = device.name;
            el.deviceType = device.type;
            el.channelName = matchedCap.name;
            el.channelType = matchedCap.type;
          }
        }

        // If element has sceneId or is scene type, add detailed scene information
        let sceneRefId = null;
        if (el.sceneId) sceneRefId = toStrId(el.sceneId);
        else if (el.type === 'scene' && el.id) sceneRefId = toStrId(el.id);
        
        if (sceneRefId) {
          const sceneDetails = scenesById[sceneRefId];
          if (sceneDetails) {
            el.sceneDetails = sceneDetails;
            el.operateType = sceneDetails.operateType;
            el.invert_flag = sceneDetails.invert_flag;
            el.scene_name = sceneDetails.name;
            el.isSceneExecutable = sceneDetails.isSceneExecutable || false;
          }
        }
      }
    }
  }

  // normalize dates
  template.createdAt = new Date(template.createdAt).toISOString();
  template.updatedAt = new Date(template.updatedAt).toISOString();
  template.id = toStrId(template._id);

  return template;
};

// Update templates when scenes are deleted - maintains template integrity with cascade cleanup
export const updateTemplatesForDeletedScene = async (sceneId, user) => {
  try {
    console.log(`Updating templates for deleted scene ${sceneId}...`);
    
    const templateSummary = {
      updated: 0,
      deleted: 0,
      inactivated: 0
    };
    
    const templates = await Template.find({ 
      status: { $ne: 'Inactive' } // Only check active templates
    });

    for (const template of templates) {
      let templateUpdated = false;
      let totalElementsRemaining = 0;
      let hasNonEmptyColumns = false;
      const layoutStructure = template.layoutStructure || { rows: [] };
      
      // Navigate through the layout structure
      if (layoutStructure.rows && Array.isArray(layoutStructure.rows)) {
        for (const row of layoutStructure.rows) {
          if (row.columns && Array.isArray(row.columns)) {
            for (const col of row.columns) {
              // Remove scene columns that reference deleted scene
              if (col.type === 'scene' && col.id && col.id.toString() === sceneId.toString()) {
                col.type = 'empty';
                delete col.id;
                delete col.scene_name;
                templateUpdated = true;
                console.log(`Scene column removed from template ${template._id} due to deleted scene ${sceneId}`);
              }
              
              if (col.elements && Array.isArray(col.elements)) {
                const originalLength = col.elements.length;
                col.elements = col.elements.filter(element => {
                  // Remove scene elements that reference deleted scene
                  if (element.type === 'scene' && element.id && element.id.toString() === sceneId.toString()) return false;
                  if (element.sceneId && element.sceneId.toString() === sceneId.toString()) return false;
                  return true;
                });
                
                if (col.elements.length < originalLength) {
                  templateUpdated = true;
                  console.log(`Scene elements removed from template ${template._id} (${template.name})`);
                }
                
                totalElementsRemaining += col.elements.length;
              }
              
              // Check if column has content (not empty type and has elements or is a valid type)
              if (col.type !== 'empty' && (col.elements?.length > 0 || ['group', 'scene', 'device'].includes(col.type))) {
                hasNonEmptyColumns = true;
              }
            }
          }
        }
      }
      
      if (templateUpdated) {
        if (totalElementsRemaining === 0 && !hasNonEmptyColumns) {
          // If no elements left and no non-empty columns, delete the template completely
          await Template.findByIdAndDelete(template._id);
          templateSummary.deleted++;
          console.log(`Template ${template._id} (${template.name}) deleted completely - no content left after removing scene ${sceneId}`);
        } else {
          // Update template normally (keep active if it has other content)
          await Template.findByIdAndUpdate(
            template._id,
            { 
              layoutStructure,
              updatedAt: new Date()
            },
            { new: true }
          );
          templateSummary.updated++;
          console.log(`Template ${template._id} (${template.name}) updated - ${totalElementsRemaining} elements remaining after removing scene ${sceneId}`);
        }
      }
    }

    console.log(`Scene ${sceneId} template update summary:`, templateSummary);
    return templateSummary;

  } catch (error) {
    console.error(`Error updating templates for deleted scene ${sceneId}:`, error);
    throw new Error(`Failed to update templates for deleted scene: ${error.message}`);
  }
};

// Update templates when groups are deleted - maintains template integrity with cascade cleanup
export const updateTemplatesForDeletedGroup = async (groupId, user) => {
  try {
    console.log(`Updating templates for deleted group ${groupId}...`);
    
    const templateSummary = {
      updated: 0,
      deleted: 0,
      inactivated: 0
    };
    
    const templates = await Template.find({ 
      status: { $ne: 'Inactive' } // Only check active templates
    });

    for (const template of templates) {
      let templateUpdated = false;
      let totalElementsRemaining = 0;
      let hasNonEmptyColumns = false;
      const layoutStructure = template.layoutStructure || { rows: [] };
      
      // Navigate through the layout structure
      if (layoutStructure.rows && Array.isArray(layoutStructure.rows)) {
        for (const row of layoutStructure.rows) {
          if (row.columns && Array.isArray(row.columns)) {
            for (const col of row.columns) {
              // Remove group columns that reference deleted group
              if (col.type === 'group' && col.id && col.id.toString() === groupId.toString()) {
                col.type = 'empty';
                delete col.id;
                delete col.group_name;
                templateUpdated = true;
                console.log(`Group column removed from template ${template._id} due to deleted group ${groupId}`);
              }
              
              if (col.elements && Array.isArray(col.elements)) {
                const originalLength = col.elements.length;
                col.elements = col.elements.filter(element => {
                  // Remove group elements that reference deleted group
                  if (element.type === 'group' && element.id && element.id.toString() === groupId.toString()) return false;
                  if (element.groupId && element.groupId.toString() === groupId.toString()) return false;
                  return true;
                });
                
                if (col.elements.length < originalLength) {
                  templateUpdated = true;
                  console.log(`Group elements removed from template ${template._id} (${template.name})`);
                }
                
                totalElementsRemaining += col.elements.length;
              }
              
              // Check if column has content (not empty type and has elements or is a valid type)
              if (col.type !== 'empty' && (col.elements?.length > 0 || ['group', 'scene', 'device'].includes(col.type))) {
                hasNonEmptyColumns = true;
              }
            }
          }
        }
      }
      
      if (templateUpdated) {
        if (totalElementsRemaining === 0 && !hasNonEmptyColumns) {
          // If no elements left and no non-empty columns, delete the template completely
          await Template.findByIdAndDelete(template._id);
          templateSummary.deleted++;
          console.log(`Template ${template._id} (${template.name}) deleted completely - no content left after removing group ${groupId}`);
        } else {
          // Update template normally (keep active if it has other content)
          await Template.findByIdAndUpdate(
            template._id,
            { 
              layoutStructure,
              updatedAt: new Date()
            },
            { new: true }
          );
          templateSummary.updated++;
          console.log(`Template ${template._id} (${template.name}) updated - ${totalElementsRemaining} elements remaining after removing group ${groupId}`);
        }
      }
    }

    console.log(`Group ${groupId} template update summary:`, templateSummary);
    return templateSummary;

  } catch (error) {
    console.error(`Error updating templates for deleted group ${groupId}:`, error);
    throw new Error(`Failed to update templates for deleted group: ${error.message}`);
  }
};

// Get complete templates with widget data for dashboard rendering - includes weather and real-time updates
export const getAllCompleteTemplatesWithWidgetData = async (user = null) => {
  // Helper to get a stable string id from various shapes
  const toStrId = (v) => {
    if (!v) return null;
    if (Types.ObjectId.isValid(v)) return String(v);
    if (typeof v === "object" && v.$oid) return v.$oid;
    if (typeof v === "string") return v;
    return String(v);
  };

  // Build the initial query for active templates
  const query = {
    status: { $regex: /^active$/i }
  };

  // Apply user access restrictions
  if (user && user.allowedResources && user.allowedResources.controlSection && Array.isArray(user.allowedResources.controlSection.templateTab)) {
    const allowedTemplateIds = user.allowedResources.controlSection.templateTab;
    if (allowedTemplateIds.length > 0) {
      query._id = { $in: allowedTemplateIds.map(id => new mongoose.Types.ObjectId(id)) };
    } else {
      // Empty array means no templates allowed
      return [];
    }
  }

  // Get all active templates
  let templates = await Template.find(query).lean();

  // Apply zone-based filtering if user has campusData
  if (user && user.campusData && Array.isArray(user.campusData) && user.campusData.length > 0) {
    // Extract zone IDs from user's campus data
    const zoneIds = [];
    user.campusData.forEach(campus => {
      if (campus.buildings && Array.isArray(campus.buildings)) {
        campus.buildings.forEach(building => {
          if (building.floors && Array.isArray(building.floors)) {
            building.floors.forEach(floor => {
              if (floor.zones && Array.isArray(floor.zones)) {
                floor.zones.forEach(zone => {
                  if (zone.zone_id) {
                    zoneIds.push(zone.zone_id);
                  }
                });
              }
            });
          }
        });
      }
    });

    if (zoneIds.length > 0) {
      // Filter templates based on whether they have devices in allowed zones
      const templateFilterPromises = templates.map(async (template) => {
        const deviceIds = new Set();
        const sceneIds = new Set();
        
        const rows = (template.layoutStructure?.rows) || [];
        for (const row of rows) {
          for (const col of row.columns || []) {
            if (col.type === 'scene' && col.id) {
              sceneIds.add(String(col.id));
            }
            for (const el of col.elements || []) {
              if (el.deviceId) deviceIds.add(el.deviceId);
              if (el.sceneId) sceneIds.add(String(el.sceneId));
              if (el.type === 'scene' && el.id) {
                sceneIds.add(String(el.id));
              }
            }
          }
        }

        let hasAllowedDevice = false;

        if (deviceIds.size > 0) {
          const allowedDevicesCount = await Device.countDocuments({
            device_id: { $in: Array.from(deviceIds) },
            zone: { $in: zoneIds },
            deletedAt: null
          });
          hasAllowedDevice = allowedDevicesCount > 0;
        }

        if (!hasAllowedDevice && sceneIds.size > 0) {
          const scenes = await Scene.find({
            _id: { $in: Array.from(sceneIds) },
            isDeleted: { $ne: true }
          }).lean();

          for (const scene of scenes) {
            if (scene.type === 'device' && scene.Devices && scene.Devices.length > 0) {
              const sceneDeviceIds = scene.Devices.map(d => d.deviceId);
              const allowedDevicesCount = await Device.countDocuments({
                device_id: { $in: sceneDeviceIds },
                zone: { $in: zoneIds },
                deletedAt: null
              });
              if (allowedDevicesCount > 0) {
                hasAllowedDevice = true;
                break;
              }
            }

            if (scene.type === 'group' && scene.Groups && scene.Groups.length > 0) {
              const allDeviceIds = scene.Groups.flatMap(group => 
                (group.devices || []).map(d => d.deviceId)
              );
              if (allDeviceIds.length > 0) {
                const allowedDevicesCount = await Device.countDocuments({
                  device_id: { $in: allDeviceIds },
                  zone: { $in: zoneIds },
                  deletedAt: null
                });
                if (allowedDevicesCount > 0) {
                  hasAllowedDevice = true;
                  break;
                }
              }
            }
          }
        }

        return hasAllowedDevice ? template : null;
      });

      const templateFilterResults = await Promise.all(templateFilterPromises);
      templates = templateFilterResults.filter(template => template !== null);
    } else {
      // No zones in user's campus data, return empty
      templates = [];
    }
  }

  if (templates.length === 0) {
    return [];
  }

  // Filter templates to only include those with widget type
  const templatesWithWidgets = templates.filter(template => {
    const rows = (template.layoutStructure?.rows) || [];
    let hasWidget = false;
    
    for (const row of rows) {
      for (const col of row.columns || []) {
        // Check if column is widget type
        if (col.type === 'widget') {
          hasWidget = true;
          break;
        }
        // Check if any element is widget type
        for (const el of col.elements || []) {
          if (el.type === 'widget') {
            hasWidget = true;
            break;
          }
        }
        if (hasWidget) break;
      }
      if (hasWidget) break;
    }
    
    return hasWidget;
  });

  if (templatesWithWidgets.length === 0) {
    return [];
  }

  // Process each template with widgets to add complete widget data
  const processedTemplates = await Promise.all(templatesWithWidgets.map(async (template) => {
    // Collect deviceIds, sceneIds, and widgetIds from the template
    const deviceIds = new Set();
    const sceneIds = new Set();
    const widgetIds = new Set();
    const rows = (template.layoutStructure?.rows) || [];
    
    for (const row of rows) {
      for (const col of row.columns || []) {
        // If columns are scene type, collect id as sceneId
        if (col.type === 'scene' && col.id) {
          sceneIds.add(toStrId(col.id));
        }
        // If columns are widget type, collect id as widgetId
        if (col.type === 'widget' && col.id) {
          widgetIds.add(toStrId(col.id));
        }
        for (const el of col.elements || []) {
          if (el.deviceId) deviceIds.add(el.deviceId);
          if (el.sceneId) sceneIds.add(toStrId(el.sceneId));
          // If element is scene type and has id, collect as sceneId
          if (el.type === 'scene' && el.id) {
            sceneIds.add(toStrId(el.id));
          }
          // If element is widget type and has id, collect as widgetId
          if (el.type === 'widget' && el.id) {
            widgetIds.add(toStrId(el.id));
          }
        }
      }
    }

    // Fetch devices
    let devicesById = {};
    if (deviceIds.size > 0) {
      const devices = await Device.find({ 
        device_id: { $in: Array.from(deviceIds) },
        deletedAt: null,
        is_delete: { $ne: true }
      }).lean();
      devicesById = devices.reduce((acc, d) => {
        acc[d.device_id] = d;
        return acc;
      }, {});
    }

    // Fetch widgets with current weather data
    let widgetsById = {};
    if (widgetIds.size > 0) {
      const { WidgetStorage } = await import('../models/WidgetStorage.js');
      const { Weather } = await import('../models/Weather.js');
      
      const widgets = await WidgetStorage.find({ 
        _id: { $in: Array.from(widgetIds) },
        isDeleted: false
      }).lean();
      
      // Get current weather data for all active weather records
      const weatherData = await Weather.find({ isActive: true, isDeleted: false });
      const weatherMap = {};
      
      for (const weather of weatherData) {
        const hourlyData = weather.weatherData?.hourly;
        const dailyData = weather.weatherData?.daily;
        
        if (hourlyData?.time && hourlyData.time.length) {
          // Get timezone info from weather data
          const storedTimezone = weather.weatherData?.timezone || 'UTC';
          const utcOffsetSeconds = weather.weatherData?.utc_offset_seconds || 0;
          
          // Get current time in UTC
          const now = new Date();
          const utcTimeISO = now.toISOString().slice(0, 13) + ':00';
          
          // Determine the actual timezone for this location based on coordinates
          let actualTimezone = storedTimezone;
          
          // Special handling for India (coordinates around 22.75, 75.89 = Indore)
          if (weather.lat >= 6 && weather.lat <= 37 && weather.long >= 68 && weather.long <= 97) {
            actualTimezone = 'Asia/Kolkata'; // India timezone
          }
          // Add more regions as needed
          
          // Calculate current time in the actual location timezone  
          let locationTime;
          if (actualTimezone !== storedTimezone && (storedTimezone === 'GMT' || storedTimezone === 'UTC')) {
            // Data stored in GMT but location is in a different timezone
            locationTime = new Date(now.toLocaleString("en-US", {timeZone: actualTimezone}));
          } else if (storedTimezone === 'GMT' || storedTimezone === 'UTC') {
            // Use UTC offset from weather data
            locationTime = new Date(now.getTime() + (utcOffsetSeconds * 1000));
          } else {
            // Use the stored timezone
            locationTime = new Date(now.toLocaleString("en-US", {timeZone: storedTimezone}));
          }
          
          // Format location time to match the stored data format
          const locationYear = locationTime.getFullYear();
          const locationMonth = String(locationTime.getMonth() + 1).padStart(2, '0');
          const locationDay = String(locationTime.getDate()).padStart(2, '0');
          const locationHour = String(locationTime.getHours()).padStart(2, '0');
          const locationTimeISO = `${locationYear}-${locationMonth}-${locationDay}T${locationHour}:00`;
          
          // Find the exact or closest time index to current location time
          let hourIndex = hourlyData.time.findIndex(time => time === locationTimeISO);
          if (hourIndex === -1) {
            // If exact match not found, find the closest previous time that exists
            const availableTimes = hourlyData.time.map((time, index) => ({ time, index }));
            const targetTime = new Date(locationTimeISO).getTime();
            
            // Find the closest time that is not in the future
            let closestIndex = -1;
            let closestDiff = Infinity;
            
            availableTimes.forEach(({ time, index }) => {
              const timeMs = new Date(time).getTime();
              const diff = targetTime - timeMs;
              
              // Only consider times that are not in the future (diff >= 0)
              if (diff >= 0 && diff < closestDiff) {
                closestDiff = diff;
                closestIndex = index;
              }
            });
            
            // If no past time found, use the last available time
            hourIndex = closestIndex >= 0 ? closestIndex : hourlyData.time.length - 1;
          }
          
          // Determine if it's day or night based on location time
          const currentTime = hourlyData.time[hourIndex];
          const sunrise = dailyData?.sunrise?.[0];
          const sunset = dailyData?.sunset?.[0];
          let is_day = null;
          
          if (currentTime && sunrise && sunset) {
            const currentTimeMs = new Date(currentTime).getTime();
            const sunriseMs = new Date(sunrise).getTime();
            const sunsetMs = new Date(sunset).getTime();
            is_day = currentTimeMs >= sunriseMs && currentTimeMs < sunsetMs;
          }
          
          // Convert sunset and sunrise to UTC
          let sunriseUTC = null;
          let sunsetUTC = null;
          
          if (sunrise) {
            const sunriseLocalDate = new Date(sunrise);
            const sunriseUTCTime = sunriseLocalDate.getTime() - (weather.weatherData?.utc_offset_seconds || 0) * 1000;
            sunriseUTC = new Date(sunriseUTCTime).toISOString();
          }
          
          if (sunset) {
            const sunsetLocalDate = new Date(sunset);
            const sunsetUTCTime = sunsetLocalDate.getTime() - (weather.weatherData?.utc_offset_seconds || 0) * 1000;
            sunsetUTC = new Date(sunsetUTCTime).toISOString();
          }
          
          weatherMap[weather._id.toString()] = {
            time: utcTimeISO, // Show current UTC time
            weather_code: hourlyData.weather_code?.[hourIndex] !== undefined ? hourlyData.weather_code[hourIndex] : null,
            temperature_2m: hourlyData.temperature_2m?.[hourIndex] !== undefined ? hourlyData.temperature_2m[hourIndex] : null,
            dew_point_2m: hourlyData.dew_point_2m?.[hourIndex] !== undefined ? hourlyData.dew_point_2m[hourIndex] : null,
            cloud_cover: hourlyData.cloud_cover?.[hourIndex] !== undefined ? hourlyData.cloud_cover[hourIndex] : null,
            apparent_temperature: hourlyData.apparent_temperature?.[hourIndex] !== undefined ? hourlyData.apparent_temperature[hourIndex] : null,
            relative_humidity_2m: hourlyData.relative_humidity_2m?.[hourIndex] !== undefined ? hourlyData.relative_humidity_2m[hourIndex] : null,
            surface_pressure: hourlyData.surface_pressure?.[hourIndex] !== undefined ? hourlyData.surface_pressure[hourIndex] : null,
            wind_speed_10m: hourlyData.wind_speed_10m?.[hourIndex] !== undefined ? hourlyData.wind_speed_10m[hourIndex] : null,
            visibility: hourlyData.visibility?.[hourIndex] !== undefined ? hourlyData.visibility[hourIndex] : null,
            uv_index: hourlyData.uv_index?.[hourIndex] !== undefined ? hourlyData.uv_index[hourIndex] : null,
            sunshine_duration: hourlyData.sunshine_duration?.[hourIndex] !== undefined ? hourlyData.sunshine_duration[hourIndex] : null,
            us_aqi: hourlyData.us_aqi?.[hourIndex] !== undefined ? hourlyData.us_aqi[hourIndex] : null,
            pm10: hourlyData.pm10?.[hourIndex] !== undefined ? hourlyData.pm10[hourIndex] : null,
            pm2_5: hourlyData.pm2_5?.[hourIndex] !== undefined ? hourlyData.pm2_5[hourIndex] : null,
            sunset: sunsetUTC,
            sunrise: sunriseUTC,
            temperature_2m_max: dailyData?.temperature_2m_max?.[0] || null,
            temperature_2m_min: dailyData?.temperature_2m_min?.[0] || null,
            is_day,
            timezone: "UTC" // Always UTC
          };
        }
      }
      
      widgetsById = widgets.reduce((acc, w) => {
        const widgetObj = { ...w };
        
        // Update weather widgets with current hour data
        if (widgetObj.structure) {
          widgetObj.structure = widgetObj.structure.map(item => {
            if (item.type === 'weather' && item.data?._id && weatherMap[item.data._id]) {
              return {
                ...item,
                data: {
                  ...item.data,
                  currentHourData: weatherMap[item.data._id]
                }
              };
            }
            return item;
          });
        }
        
        acc[toStrId(w._id)] = widgetObj;
        return acc;
      }, {});
    }

    // Fetch scenes for operateType and invert_flag
    let scenesById = {};
    if (sceneIds.size > 0) {
      const scenes = await Scene.find({ _id: { $in: Array.from(sceneIds) } }).lean();
      scenesById = scenes.reduce((acc, s) => {
        acc[toStrId(s._id)] = s;
        return acc;
      }, {});
    }

    // Walk elements and update capabilityId => string and status from device capability if found
    for (const row of rows) {
      for (const col of row.columns || []) {
        // If column is scene type and has id, override operateType and invert_flag
        if (col.type === 'scene' && col.id) {
          const scene = scenesById[toStrId(col.id)];
          if (scene) {
            col.operateType = scene.operateType;
            col.invert_flag = scene.invert_flag;
          }
        }
        
        // If column is widget type and has id, add widget data
        if (col.type === 'widget' && col.id) {
          const widgetData = widgetsById[toStrId(col.id)];
          if (widgetData) {
            col.widget_data = {
              _id: widgetData._id,
              structure: widgetData.structure
            };
          }
        }
        
        for (const el of col.elements || []) {
          const capIdStr = toStrId(el.capabilityId);
          if (capIdStr) el.capabilityId = capIdStr;

          // If element is widget type and has id, add widget data
          if (el.type === 'widget' && el.id) {
            const widgetData = widgetsById[toStrId(el.id)];
            if (widgetData) {
              el.widget_data = {
                _id: widgetData._id,
                structure: widgetData.structure
              };
            }
          }

          const device = devicesById[el.deviceId];
          if (device?.capabilities) {
            // First try to match by capabilityId (existing logic)
            let matchedCap = device.capabilities.find((c) => toStrId(c._id) === capIdStr);
            
            // If no match by capabilityId and element has channelId, match by channelId
            if (!matchedCap && el.channelId) {
              matchedCap = device.capabilities.find((c) => c.channelId === el.channelId);
              
              // If matched by channelId, update the element's capabilityId for consistency
              if (matchedCap) {
                el.capabilityId = toStrId(matchedCap._id);
              }
            }
            
            if (matchedCap) {
              el.status = matchedCap.status;
              if (!el.properties) el.properties = {};
              
              // Copy all capability properties to element properties
              if (matchedCap.properties) {
                Object.assign(el.properties, matchedCap.properties);
              }
              
              // Add additional device information to element
              el.deviceName = device.name;
              el.deviceType = device.type;
              el.channelName = matchedCap.name;
              el.channelType = matchedCap.type;
            }
          }

          // If element has sceneId, always take operateType and invert_flag from scene
          let sceneRefId = null;
          if (el.sceneId) sceneRefId = toStrId(el.sceneId);
          else if (el.type === 'scene' && el.id) sceneRefId = toStrId(el.id);
          if (sceneRefId) {
            const scene = scenesById[sceneRefId];
            if (scene) {
              el.operateType = scene.operateType;
              el.invert_flag = scene.invert_flag;
            }
          }
        }
      }
    }

    // Normalize dates and add id field
    template.createdAt = new Date(template.createdAt).toISOString();
    template.updatedAt = new Date(template.updatedAt).toISOString();
    template.id = toStrId(template._id);

    return template;
  }));

  // Sort templates by createdAt descending (latest first)
  return processedTemplates.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
};