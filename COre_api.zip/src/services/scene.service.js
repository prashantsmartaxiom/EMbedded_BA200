import { Scene } from '../models/Scene.js';
import Device from '../models/Device.js';
import { Group } from '../models/Group.js';


/**
 * Scene Service - Automated control scene management with complex validation
 * 
 * Handles creation and execution of automation scenes for smart building control
 * Manages device/group assignments, channel validation, and permission distribution
 * Coordinates with templates, sensors, and scheduling systems for comprehensive automation
 */

// Create new automation scene with device/group validation and auto-permission assignment
export const createScene = async (payload, user = null) => {
  const { type } = payload;
  const warnings = [];

  if (type === 'group') {
    // Validate that referenced groups exist and are not deleted
    const ids = [...new Set((payload.Groups || []).map(g => g.groupId))];
    const found = await Group.find({ _id: { $in: ids }, isDeleted: { $ne: true } }, { _id: 1 }).lean();
    const foundSet = new Set(found.map(x => String(x._id)));
    for (const id of ids) if (!foundSet.has(String(id))) warnings.push(`Group not found: ${id}`);
  }

  // Collect and validate all devices and their channels referenced in the scene
  const allDeviceIds = new Set();
  if (type === 'device') {
    (payload.Devices || []).forEach(d => allDeviceIds.add(d.deviceId));
  } else {
    (payload.Groups || []).forEach(g => (g.devices || []).forEach(d => allDeviceIds.add(d.deviceId)));
  }
  const ids = [...allDeviceIds];
  if (ids.length) {
    const devs = await Device.find({ device_id: { $in: ids } }, { device_id: 1, capabilities: 1 }).lean();
    const byId = new Map(devs.map(d => [d.device_id, d]));
    // Validate that each device exists and has the required channels for the scene
    const checkDeviceBlock = (d) => {
      const doc = byId.get(d.deviceId);
      if (!doc) {
        warnings.push(`Device not found: ${d.deviceId}`);
        return;
      }
      const caps = Array.isArray(doc.capabilities) ? doc.capabilities : [];
      for (const ch of d.channels || []) {
        const ok = caps.find(c => c.type === ch.channelType && String(c.channelId) === String(ch.channelId));
        if (!ok) warnings.push(`Channel not found on ${d.deviceId}: ${ch.channelType}/${ch.channelId}`);
      }
    };

    if (type === 'device') {
      (payload.Devices || []).forEach(checkDeviceBlock);
    } else {
      (payload.Groups || []).forEach(g => (g.devices || []).forEach(checkDeviceBlock));
    }
  }

  // Set invert flag for reverse operation scenes before database creation
  const { operateType } = payload;
  if (operateType === 'invert') {
    payload.invert_flag = true;
  }
  const scene = await Scene.create(payload);

  // Auto-assign scene permissions based on user roles for immediate access
  // Superadmin: Always has allowedResources: null, don't update anything
  // Admin & Technician: Add to both intelligentControl.scenes and controlSection.sceneTab
  // Operator: Add only to controlSection.sceneTab
  try {
    const { default: Role } = await import('../models/Role.js');
    const { User } = await import('../models/User.js');
    
    // Find roles for admin, technician, and operator (case insensitive)
    const adminTechRoles = await Role.find({ 
      roleName: { 
        $in: ['admin', 'technician'].map(name => new RegExp(`^${name}$`, 'i')) 
      },
      isDelete: { $ne: true },
      isActive: true
    });
    
    const operatorRoles = await Role.find({ 
      roleName: { 
        $in: [new RegExp('^operator$', 'i')] 
      },
      isDelete: { $ne: true },
      isActive: true
    });
    
    console.log(`Found ${adminTechRoles.length} admin/technician roles and ${operatorRoles.length} operator roles for scene access`);
    
    const adminTechRoleIds = adminTechRoles.map(r => r._id);
    const operatorRoleIds = operatorRoles.map(r => r._id);
    
    // Update admin and technician users (add to both intelligentControl.scenes and controlSection.sceneTab)
    if (adminTechRoleIds.length > 0) {
      const adminTechUsers = await User.find({ 
        role_id: { $in: adminTechRoleIds },
        allowedResources: { $ne: null },
        isDeleted: { $ne: true },
        isActive: true
      });
      
      console.log(`Found ${adminTechUsers.length} admin/technician users to update with scene access`);
      
      for (const user of adminTechUsers) {
        // Initialize structures if needed
        if (!user.allowedResources.intelligentControl) {
          user.allowedResources.intelligentControl = {};
        }
        if (!Array.isArray(user.allowedResources.intelligentControl.scenes)) {
          user.allowedResources.intelligentControl.scenes = [];
        }
        if (!user.allowedResources.controlSection) {
          user.allowedResources.controlSection = {};
        }
        if (!Array.isArray(user.allowedResources.controlSection.sceneTab)) {
          user.allowedResources.controlSection.sceneTab = [];
        }
        
        // Add to intelligentControl.scenes if not already present
        if (!user.allowedResources.intelligentControl.scenes.includes(scene._id.toString())) {
          user.allowedResources.intelligentControl.scenes.push(scene._id.toString());
        }
        
        // Add to controlSection.sceneTab if not already present
        if (!user.allowedResources.controlSection.sceneTab.includes(scene._id.toString())) {
          user.allowedResources.controlSection.sceneTab.push(scene._id.toString());
        }
        
        await user.save();
        console.log(`Updated admin/technician user ${user.email} with scene ID: ${scene._id}`);
      }
    }
    
    // Update operator users (add only to controlSection.sceneTab)
    if (operatorRoleIds.length > 0) {
      const operatorUsers = await User.find({ 
        role_id: { $in: operatorRoleIds },
        allowedResources: { $ne: null },
        isDeleted: { $ne: true },
        isActive: true
      });
      
      console.log(`Found ${operatorUsers.length} operator users to update with scene access`);
      
      for (const user of operatorUsers) {
        // Initialize controlSection if needed
        if (!user.allowedResources.controlSection) {
          user.allowedResources.controlSection = {};
        }
        if (!Array.isArray(user.allowedResources.controlSection.sceneTab)) {
          user.allowedResources.controlSection.sceneTab = [];
        }
        
        // Add to controlSection.sceneTab if not already present
        if (!user.allowedResources.controlSection.sceneTab.includes(scene._id.toString())) {
          user.allowedResources.controlSection.sceneTab.push(scene._id.toString());
        }
        
        await user.save();
        console.log(`Updated operator user ${user.email} with scene ID: ${scene._id} (controlSection only)`);
      }
    }
    
    console.log(`Successfully updated users with new scene access permissions`);
  } catch (userUpdateError) {
    console.error('Error updating users with new scene access:', userUpdateError);
    // Don't throw the error here - we still want to return the created scene
    // The scene was created successfully, user updates are a bonus feature
  }

  return { scene, warnings };
};


// Get device details for scene creation - shows installed channels, location, and capabilities
export const getDeviceDetailsForScene = async (deviceId) => {
  try {
    console.log(`Fetching device details for scene module with ID: ${deviceId}`);
    
    // Find device regardless of configuration status - scenes can work with any device
    const device = await Device.findOne({
      device_id: deviceId,
      deletedAt: null
    })
      .populate({ path: 'campus', select: 'name code description' })
      .populate({ path: 'building', select: 'name code description' })
      .populate({ path: 'floor', select: 'name number description' })
      .populate({ path: 'zone', select: 'name code description' })
      .lean();

    if (!device) {
      throw new Error('Device not found');
    }

    // Extract only installed capabilities for scene creation - prevents using unconfigured channels
    const installedCapabilities = (device.capabilities || [])
      .filter(cap => cap?.properties?.installed === true)
      .map(cap => ({
        id: cap.channelId,
        name: cap.name,
        type: cap.type,
        properties: cap.properties,
        description: cap.description || 'N/A'
      }));

    // Group capabilities by type
    const capabilitiesByType = {
      led: installedCapabilities.filter(cap => cap.type === 'led'),
      shade: installedCapabilities.filter(cap => cap.type === 'shade'),
      sensor: installedCapabilities.filter(cap => cap.type === 'sensor')
    };

    return {
      device_id: device.device_id,
      device_name: device.name || 'N/A',
      device_type: device.type || 'N/A',
      serial_number: device.SNO || 'N/A',
      mac_address: device.Mac_addr || 'N/A',
      status: device.status,
      configure_flag: device.configure_flag,
      is_configured: device.configure_flag === 1 || device.configure_flag === '1' || device.configure_flag === true,
      location: {
        campus: {
          id: device.campus?._id || null,
          name: device.campus?.name || 'N/A',
          code: device.campus?.code || null
        },
        building: {
          id: device.building?._id || null,
          name: device.building?.name || 'N/A',
          code: device.building?.code || null
        },
        floor: {
          id: device.floor?._id || null,
          name: device.floor?.name || 'N/A',
          number: device.floor?.number || null
        },
        zone: {
          id: device.zone?._id || null,
          name: device.zone?.name || 'N/A',
          code: device.zone?.code || null
        }
      },
      installed_capabilities: {
        total_count: installedCapabilities.length,
        by_type: {
          led: {
            count: capabilitiesByType.led.length,
            channels: capabilitiesByType.led
          },
          shade: {
            count: capabilitiesByType.shade.length,
            channels: capabilitiesByType.shade
          },
          sensor: {
            count: capabilitiesByType.sensor.length,
            channels: capabilitiesByType.sensor
          }
        },
        all_channels: installedCapabilities
      },
      ownership_type: /^BA-\d{3,4}$/i.test(device.type || "") ? 'own' : 'third-party'
    };

  } catch (error) {
    throw new Error(`Error fetching device details for scene: ${error.message}`);
  }
};

// Update scene configuration with device/group validation and type switching support
export const updateScene = async (sceneId, updateData, user) => {
  try {
    // Find the existing scene
    const existingScene = await Scene.findById(sceneId);
    if (!existingScene) {
      throw new Error('Scene not found');
    }

    const warnings = [];

    // If type is being changed, validate the corresponding data
    if (updateData.type && updateData.type !== existingScene.type) {
      if (updateData.type === 'device' && !updateData.Devices) {
        throw new Error('Devices array is required when changing type to device');
      }
      if (updateData.type === 'group' && !updateData.Groups) {
        throw new Error('Groups array is required when changing type to group');
      }
    }

    // Validate devices if provided
    if (updateData.Devices) {
      for (const deviceEntry of updateData.Devices) {
        const device = await Device.findOne({ 
          device_id: deviceEntry.deviceId, 
          deletedAt: null 
        });
        
        if (!device) {
          warnings.push(`Device ${deviceEntry.deviceId} not found`);
          continue;
        }

        // Validate channels
        for (const channel of deviceEntry.channels) {
          const deviceChannel = device.capabilities?.find(
            cap => cap.channelId === channel.channelId
          );
          
          if (!deviceChannel) {
            warnings.push(
              `Channel ${channel.channelId} not found in device ${deviceEntry.deviceId}`
            );
            continue;
          }

          if (deviceChannel.channelType !== channel.channelType) {
            warnings.push(
              `Channel ${channel.channelId} type mismatch. Expected ${deviceChannel.channelType}, got ${channel.channelType}`
            );
          }
        }
      }
    }

    // Validate groups if provided
    if (updateData.Groups) {
      for (const groupEntry of updateData.Groups) {
        const group = await Group.findById(groupEntry.groupId);
        if (!group) {
          warnings.push(`Group ${groupEntry.groupId} not found`);
          continue;
        }

        // Validate devices within the group
        for (const deviceEntry of groupEntry.devices) {
          const device = await Device.findOne({ 
            device_id: deviceEntry.deviceId, 
            deletedAt: null 
          });
          
          if (!device) {
            warnings.push(`Device ${deviceEntry.deviceId} not found in group ${groupEntry.groupId}`);
            continue;
          }

          // Validate channels
          for (const channel of deviceEntry.channels) {
            const deviceChannel = device.capabilities?.find(
              cap => cap.channelId === channel.channelId
            );
            
            if (!deviceChannel) {
              warnings.push(
                `Channel ${channel.channelId} not found in device ${deviceEntry.deviceId}`
              );
              continue;
            }

            if (deviceChannel.channelType !== channel.channelType) {
              warnings.push(
                `Channel ${channel.channelId} type mismatch. Expected ${deviceChannel.channelType}, got ${channel.channelType}`
              );
            }
          }
        }
      }
    }

    // Prepare update data
    const updateFields = { ...updateData };

    // Ensure invert_flag aligns with operateType changes
    if (typeof updateData.operateType === 'string' && updateData.operateType !== existingScene.operateType) {
      if (updateData.operateType === 'invert') {
        updateFields.invert_flag = true;
      } else if (updateData.operateType === 'normal' && typeof updateData.invert_flag === 'undefined') {
        updateFields.invert_flag = false;
      }
    }

    let updateQuery = {};

    // Handle scene type switching - remove incompatible arrays when changing types
    if (updateData.type === 'device') {
      updateQuery = {
        $set: updateFields,
        $unset: { Groups: "" }
      };
    } else if (updateData.type === 'group') {
      updateQuery = {
        $set: updateFields,
        $unset: { Devices: "" }
      };
    } else {
      updateQuery = { $set: updateFields };
    }

    // Update the scene
    const updatedScene = await Scene.findByIdAndUpdate(
      sceneId,
      updateQuery,
      { new: true, runValidators: true }
    );

    return { scene: updatedScene, warnings };
  } catch (error) {
    throw new Error(`Error updating scene: ${error.message}`);
  }
};

// Update scene execution status for automation control - toggles active/inactive state
export const updateSceneStatus = async (sceneId, status, user) => {
  try {
    // Find the existing scene
    const existingScene = await Scene.findById(sceneId);
    if (!existingScene) {
      throw new Error('Scene not found');
    }

    // Update the scene status (no need to check if it's the same)
    const updatedScene = await Scene.findByIdAndUpdate(
      sceneId,
      { 
        status,
        updatedBy: user?._id,
        updatedAt: new Date()
      },
      { new: true, runValidators: true }
    );

    return updatedScene;
  } catch (error) {
    throw new Error(`Error updating scene status: ${error.message}`);
  }
};


// Get paginated scene list with filtering, search, and zone-based access control
export const listScenes = async (queryParams) => {
  try {
    const {
      page,
      limit,
      groupId,
      deviceId,
      channelType,
      search = '',
      status,
      user = null
    } = queryParams;

    // Build filter object
    const filter = {
      isDeleted: { $ne: true } // Exclude deleted scenes
    };

    if (status !== undefined) {
      filter.status = parseInt(status);
    }

    if (groupId) {
      filter['Groups.groupId'] = groupId;
    }

    if (deviceId) {
      filter.$or = [
        { 'Devices.deviceId': deviceId },
        { 'Groups.devices.deviceId': deviceId }
      ];
    }

    if (channelType) {
      filter.$or = [
        { 'Devices.channels.channelType': channelType },
        { 'Groups.devices.channels.channelType': channelType }
      ];
    }

    if (search) {
      filter.name = { $regex: search, $options: 'i' };
    }

    // Filter by allowedSceneIds if provided (skip for superadmin)
    if (queryParams.allowedSceneIds && Array.isArray(queryParams.allowedSceneIds) && user?.role_id?.roleName?.toLowerCase() !== 'superadmin') {
      if (queryParams.allowedSceneIds.length > 0) {
        const mongoose = await import('mongoose');
        filter._id = { $in: queryParams.allowedSceneIds.map(id => new mongoose.default.Types.ObjectId(id)) };
      } else {
        // Empty array means no scenes allowed - return no results
        filter._id = { $in: [] };
      }
    }

    let scenesQuery = Scene.find(filter)
      .sort({ createdAt: -1 })
      .populate('createdBy', 'name email')
      .populate('updatedBy', 'name email');

    let pagination = null;

    if (page && limit) {
      // If pagination params are given
      const pageNum = parseInt(page, 10);
      const limitNum = parseInt(limit, 10);
      const skip = (pageNum - 1) * limitNum;

      scenesQuery = scenesQuery.skip(skip).limit(limitNum);

      const total = await Scene.countDocuments(filter);

      pagination = {
        currentPage: pageNum,
        totalPages: Math.ceil(total / limitNum),
        totalScenes: total,
        hasNextPage: pageNum < Math.ceil(total / limitNum),
        hasPrevPage: pageNum > 1
      };
    }

    const scenes = await scenesQuery;

    // Apply location-based access control - filter scenes by user's zone permissions
    let filteredScenes = scenes;
    if (user && user.campusData && Array.isArray(user.campusData)) {
      // If campusData is empty array, show all data (no filtering)
      if (user.campusData.length > 0) {
      // Extract zone IDs from user's campus data
      const zoneIds = [];
      user.campusData.forEach(campus => {
        if (campus.buildings && Array.isArray(campus.buildings)) {
          campus.buildings.forEach(building => {
            if (building.floors && Array.isArray(building.floors)) {
              building.floors.forEach(floor => {
                if (floor.zones && Array.isArray(floor.zones)) {
                  floor.zones.forEach(zone => {
                    if (zone.zone_id) {
                      zoneIds.push(zone.zone_id);
                    }
                  });
                }
              });
            }
          });
        }
      });

      if (zoneIds.length > 0) {
        // Apply zone-based security - only show scenes with devices in user's accessible zones
        const sceneFilterPromises = scenes.map(async (scene) => {
          let hasAllowedDevice = false;

          // Check devices directly in scene
          if (scene.type === 'device' && scene.Devices && scene.Devices.length > 0) {
            const deviceIds = scene.Devices.map(d => d.deviceId);
            const allowedDevicesCount = await Device.countDocuments({
              device_id: { $in: deviceIds },
              zone: { $in: zoneIds },
              deletedAt: null
            });
            hasAllowedDevice = allowedDevicesCount > 0;
          }

          // Check devices in groups within scene
          if (scene.type === 'group' && scene.Groups && scene.Groups.length > 0) {
            const allDeviceIds = scene.Groups.flatMap(group => 
              (group.devices || []).map(d => d.deviceId)
            );
            if (allDeviceIds.length > 0) {
              const allowedDevicesCount = await Device.countDocuments({
                device_id: { $in: allDeviceIds },
                zone: { $in: zoneIds },
                deletedAt: null
              });
              hasAllowedDevice = allowedDevicesCount > 0;
            }
          }

          return hasAllowedDevice ? scene : null;
        });

        const sceneFilterResults = await Promise.all(sceneFilterPromises);
        filteredScenes = sceneFilterResults.filter(scene => scene !== null);
        } else {
          // No zones in user's campus data, return empty
          filteredScenes = [];
        }
      }
    }

    // Enhance scenes with location information
    const enhancedScenes = await Promise.all(
      filteredScenes.map(async (scene) => {
        const sceneObj = scene.toObject();
        
        // Add location information for device-type scenes
        if (scene.type === 'device' && scene.Devices && scene.Devices.length > 0) {
          const deviceIds = scene.Devices.map(d => d.deviceId);
          
          console.log(`Processing device scene: ${scene.name}, Device IDs:`, deviceIds);
          
          // Get unique location info from devices in this scene
          const devices = await Device.find({
            device_id: { $in: deviceIds }
            // Remove deletedAt filter to check if it's causing issues
          })
            .populate({ path: 'campus', select: 'name code' })
            .populate({ path: 'building', select: 'name code' })
            .populate({ path: 'floor', select: 'name number' })
            .populate({ path: 'zone', select: 'name code' })
            .lean();

          // Extract unique locations
          const locations = devices.reduce((acc, device) => {
            if (device.campus && !acc.campuses.find(c => c.id === String(device.campus._id))) {
              acc.campuses.push({
                id: device.campus._id,
                name: device.campus.name,
                code: device.campus.code
              });
            }
            if (device.building && !acc.buildings.find(b => b.id === String(device.building._id))) {
              acc.buildings.push({
                id: device.building._id,
                name: device.building.name,
                code: device.building.code
              });
            }
            if (device.floor && !acc.floors.find(f => f.id === String(device.floor._id))) {
              acc.floors.push({
                id: device.floor._id,
                name: device.floor.name,
                number: device.floor.number
              });
            }
            if (device.zone && !acc.zones.find(z => z.id === String(device.zone._id))) {
              acc.zones.push({
                id: device.zone._id,
                name: device.zone.name,
                code: device.zone.code
              });
            }
            return acc;
          }, { campuses: [], buildings: [], floors: [], zones: [] });

          sceneObj.locations = locations;
        }

        // Add location information for group-type scenes
        if (scene.type === 'group' && scene.Groups && scene.Groups.length > 0) {
          // Collect all device IDs from all groups in this scene
          const allDeviceIds = scene.Groups.flatMap(group => 
            (group.devices || []).map(d => d.deviceId)
          );

          if (allDeviceIds.length > 0) {
            // Get unique location info from all devices in all groups of this scene
            const devices = await Device.find({
              device_id: { $in: allDeviceIds },
              deletedAt: null
            })
              .populate({ path: 'campus', select: 'name code' })
              .populate({ path: 'building', select: 'name code' })
              .populate({ path: 'floor', select: 'name number' })
              .populate({ path: 'zone', select: 'name code' })
              .lean();

            // Extract unique locations
            const locations = devices.reduce((acc, device) => {
              if (device.campus && !acc.campuses.find(c => c.id === String(device.campus._id))) {
                acc.campuses.push({
                  id: device.campus._id,
                  name: device.campus.name,
                  code: device.campus.code
                });
              }
              if (device.building && !acc.buildings.find(b => b.id === String(device.building._id))) {
                acc.buildings.push({
                  id: device.building._id,
                  name: device.building.name,
                  code: device.building.code
                });
              }
              if (device.floor && !acc.floors.find(f => f.id === String(device.floor._id))) {
                acc.floors.push({
                  id: device.floor._id,
                  name: device.floor.name,
                  number: device.floor.number
                });
              }
              if (device.zone && !acc.zones.find(z => z.id === String(device.zone._id))) {
                acc.zones.push({
                  id: device.zone._id,
                  name: device.zone.name,
                  code: device.zone.code
                });
              }
              return acc;
            }, { campuses: [], buildings: [], floors: [], zones: [] });

            sceneObj.locations = locations;
          }
        }

        // Set lastExecuted to empty string if null
        sceneObj.lastExecuted = scene.lastExecuted || "";
        return sceneObj;
      })
    );

    return {
      scenes: enhancedScenes,
      ...(pagination ? { pagination } : {}) // include pagination only if applied
    };
  } catch (error) {
    throw new Error(`Error fetching scenes: ${error.message}`);
  }
};

// Soft delete scene with comprehensive cascade cleanup from templates, sensors, and users
export const deleteScene = async (sceneId, user) => {
  // Check if scene exists and is not already deleted
  const scene = await Scene.findOne({ 
    _id: sceneId, 
    isDeleted: { $ne: true } 
  });

  if (!scene) {
    throw new Error('Scene not found or already deleted');
  }

  // Comprehensive cascade cleanup - remove scene references to prevent orphaned links
  try {
    console.log(`Removing scene references for scene ID: ${sceneId} from templates`);
    
    // Import Template model
    const { Template } = await import('../models/Template.js');
    
    // Find all templates that might reference this scene
    const templates = await Template.find({});
    
    let templatesUpdated = 0;
    
    // Helper function to normalize ID for comparison
    const normalizeId = (id) => {
      if (!id) return null;
      if (typeof id === 'object' && id.$oid) return id.$oid;
      return id.toString();
    };
    
    const sceneIdStr = normalizeId(sceneId);
    
    for (const template of templates) {
      let templateModified = false;
      const layoutStructure = template.layoutStructure || {};
      const rows = layoutStructure.rows || [];
      
      // Process each row and column
      for (const row of rows) {
        const columns = row.columns || [];
        
        for (let colIndex = 0; colIndex < columns.length; colIndex++) {
          const col = columns[colIndex];
          
          // Check if column is scene type and references our scene
          if (col.type === 'scene' && col.id && normalizeId(col.id) === sceneIdStr) {
            console.log(`Removing scene reference from column in template: ${template.name}, column index: ${colIndex}`);
            // Remove scene reference by changing type to empty and clearing all scene-related properties
            col.type = 'empty';
            delete col.id;
            delete col.scene_name;
            delete col.operateType;
            delete col.invert_flag;
            templateModified = true;
          }
          
          // Process elements within the column
          const elements = col.elements || [];
          for (let elIndex = 0; elIndex < elements.length; elIndex++) {
            const el = elements[elIndex];
            
            // Check if element references the scene via sceneId
            if (el.sceneId && normalizeId(el.sceneId) === sceneIdStr) {
              console.log(`Removing sceneId reference from element in template: ${template.name}, element index: ${elIndex}`);
              delete el.sceneId;
              delete el.scene_name;
              delete el.operateType;
              delete el.invert_flag;
              templateModified = true;
            }
            
            // Check if element is scene type and references our scene via id
            if (el.type === 'scene' && el.id && normalizeId(el.id) === sceneIdStr) {
              console.log(`Removing scene type element reference in template: ${template.name}, element index: ${elIndex}`);
              el.type = 'empty';
              delete el.id;
              delete el.scene_name;
              delete el.operateType;
              delete el.invert_flag;
              templateModified = true;
            }
          }
        }
      }
      
      // Save template if it was modified
      if (templateModified) {
        template.layoutStructure = layoutStructure;
        template.markModified('layoutStructure'); // Ensure mongoose knows the nested object changed
        await template.save();
        templatesUpdated++;
        console.log(`Updated template: ${template.name} (ID: ${template._id})`);
      }
    }
    
    console.log(`Successfully removed scene references from ${templatesUpdated} template(s)`);
    
  } catch (templateUpdateError) {
    console.error('Error removing scene references from templates:', templateUpdateError);
    // Log error but continue with scene deletion
    // This ensures scene deletion doesn't fail if template update fails
  }

  // Remove scene references from sensors collection
  try {
    console.log(`Removing scene references for scene ID: ${sceneId} from sensors collection`);
    
    // Import Sensor model
    const { Sensor } = await import('../models/Sensor.js');
    
    // Find sensors that reference this scene as motionScene
    const sensorsWithMotionScene = await Sensor.find({ 
      motionScene: sceneId, 
      isDelete: { $ne: true } 
    });
    
    // Find sensors that reference this scene as NoMotionScene
    const sensorsWithNoMotionScene = await Sensor.find({ 
      NoMotionScene: sceneId, 
      isDelete: { $ne: true } 
    });
    
    let sensorsUpdated = 0;
    
    // Handle sensors that reference this scene as motionScene
    for (const sensor of sensorsWithMotionScene) {
      console.log(`Removing motionScene reference in sensor: ${sensor.sensorEvent} (Device: ${sensor.device})`);
      // Set motionScene to null and make sensor inactive as it has invalid reference
      await Sensor.findByIdAndUpdate(sensor._id, { 
        motionScene: null,
        status: 'Inactive'
      });
      sensorsUpdated++;
    }
    
    // Handle sensors that reference this scene as NoMotionScene
    for (const sensor of sensorsWithNoMotionScene) {
      console.log(`Removing NoMotionScene reference in sensor: ${sensor.sensorEvent} (Device: ${sensor.device})`);
      // Set NoMotionScene to null and make sensor inactive as it has invalid reference
      await Sensor.findByIdAndUpdate(sensor._id, { 
        NoMotionScene: null,
        status: 'Inactive'
      });
      sensorsUpdated++;
    }
    
    console.log(`Successfully removed scene references from ${sensorsUpdated} sensor(s)`);
    
  } catch (sensorUpdateError) {
    console.error('Error removing scene references from sensors:', sensorUpdateError);
    // Log error but continue with scene deletion
    // This ensures scene deletion doesn't fail if sensor update fails
  }

  // Remove scene references from user allowedResources
  try {
    console.log(`Removing scene references for scene ID: ${sceneId} from user allowedResources`);
    
    // Import User model
    const { User } = await import('../models/User.js');
    
    const sceneIdStr = sceneId.toString();
    
    // Find users that have this scene in their allowedResources
    const usersWithSceneAccess = await User.find({
      $or: [
        { 'allowedResources.intelligentControl.scenes': sceneIdStr },
        { 'allowedResources.controlSection.sceneTab': sceneIdStr }
      ],
      isDeleted: { $ne: true }
    });
    
    let usersUpdated = 0;
    
    for (const user of usersWithSceneAccess) {
      let userModified = false;
      
      // Remove from intelligentControl.scenes if present
      if (user.allowedResources?.intelligentControl?.scenes) {
        const sceneIndex = user.allowedResources.intelligentControl.scenes.indexOf(sceneIdStr);
        if (sceneIndex > -1) {
          user.allowedResources.intelligentControl.scenes.splice(sceneIndex, 1);
          userModified = true;
          console.log(`Removed scene from intelligentControl.scenes for user: ${user.email}`);
        }
      }
      
      // Remove from controlSection.sceneTab if present
      if (user.allowedResources?.controlSection?.sceneTab) {
        const sceneTabIndex = user.allowedResources.controlSection.sceneTab.indexOf(sceneIdStr);
        if (sceneTabIndex > -1) {
          user.allowedResources.controlSection.sceneTab.splice(sceneTabIndex, 1);
          userModified = true;
          console.log(`Removed scene from controlSection.sceneTab for user: ${user.email}`);
        }
      }
      
      if (userModified) {
        user.markModified('allowedResources');
        await user.save();
        usersUpdated++;
      }
    }
    
    console.log(`Successfully removed scene references from ${usersUpdated} user(s) allowedResources`);
    
  } catch (userUpdateError) {
    console.error('Error removing scene references from user allowedResources:', userUpdateError);
    // Log error but continue with scene deletion
    // This ensures scene deletion doesn't fail if user update fails
  }

  // Update scene with soft delete flag and audit information
  const updatedScene = await Scene.findByIdAndUpdate(
    sceneId,
    {
      isDeleted: true,
      deletedAt: new Date(),
      deletedBy: {
        userId: user._id,
        fullName: user.fullName,
        email: user.email
      },
      updatedBy: {
        userId: user._id,
        fullName: user.fullName,
        email: user.email
      }
    },
    { new: true }
  );

  return {
    sceneId: updatedScene._id,
    sceneName: updatedScene.name,
    deletedAt: updatedScene.deletedAt,
    deletedBy: updatedScene.deletedBy
  };
};

// Get all scenes without pagination - simple list for dropdowns and basic selections
export const getAllScenesNoPagination = async (queryParams = {}) => {
  try {
    const {
      search = '',
      status,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = queryParams;

    // Build filter object
    const filter = {
      isDeleted: { $ne: true } // Exclude soft-deleted scenes
    };

    // Add status filter if provided
    if (status !== undefined) {
      filter.status = parseInt(status);
    }

    // Add search filter if provided
    if (search && search.trim()) {
      filter.name = { $regex: search.trim(), $options: 'i' };
    }

    // Build sort object
    const sort = {};
    sort[sortBy] = sortOrder === 'asc' ? 1 : -1;

    // Fetch all scenes without pagination
    const scenes = await Scene.find(filter)
      .sort(sort)
      .populate('createdBy', 'fullName email')
      .populate('updatedBy', 'fullName email')
      .lean();

    // Transform scenes data for consistent response
      const transformedScenes = scenes.map(scene => ({
        _id: scene._id,
        name: scene.name,
        description: scene.description,
        type: scene.type,
        status: scene.status === 1 ? 'active' : 'inactive',
        statusValue: scene.status,
        lastExecuted: scene.lastExecuted || "",
        deviceCount: scene.type === 'device' 
          ? (scene.Devices || []).length 
          : (scene.Groups || []).reduce((total, group) => total + (group.devices || []).length, 0),
        groupCount: scene.type === 'group' ? (scene.Groups || []).length : 0,
        createdAt: scene.createdAt,
        updatedAt: scene.updatedAt,
        createdBy: scene.createdBy,
        updatedBy: scene.updatedBy,
        invert_flag: scene.invert_flag ?? false,
        operateType: scene.operateType ?? 'normal'
      }));

    // Calculate summary statistics
    const summary = {
      totalScenes: transformedScenes.length,
      activeScenes: transformedScenes.filter(scene => scene.statusValue === 1).length,
      inactiveScenes: transformedScenes.filter(scene => scene.statusValue === 0).length,
      deviceScenes: transformedScenes.filter(scene => scene.type === 'device').length,
      groupScenes: transformedScenes.filter(scene => scene.type === 'group').length
    };

    return {
      scenes: transformedScenes,
      summary
    };
  } catch (error) {
    throw new Error(`Error fetching all scenes: ${error.message}`);
  }
};

/**
 * Get detailed scene information with device/group complete details but only installed channels
 * @param {string} sceneId - Scene ID
 * @returns {Object} Scene details with populated device/group information
 */
export const getSceneDetails = async (sceneId) => {
  try {
    console.log(`Fetching scene details for ID: ${sceneId}`);
    
    // Find scene and populate audit fields
    const scene = await Scene.findOne({
      _id: sceneId,
      isDeleted: { $ne: true }
    })
      .populate('createdBy.userId', 'fullName email')
      .populate('updatedBy.userId', 'fullName email')
      .lean();

    if (!scene) {
      throw new Error('Scene not found or has been deleted');
    }

    // Initialize response structure
    const sceneDetails = {
      _id: scene._id,
      name: scene.name,
      type: scene.type,
      status: scene.status,
      statusText: scene.status === 1 ? 'active' : 'inactive',
      lastExecuted: scene.lastExecuted || "",
      executedBy: scene.executedBy,
      createdAt: scene.createdAt,
      updatedAt: scene.updatedAt,
      createdBy: scene.createdBy,
      updatedBy: scene.updatedBy,
      invert_flag: scene.invert_flag ?? false,
      operateType: scene.operateType ?? 'normal'
    };

    // Process based on scene type
    if (scene.type === 'device') {
      sceneDetails.devices = await processDevicesForScene(scene.Devices || []);
      sceneDetails.deviceCount = sceneDetails.devices.length;
      sceneDetails.activeDeviceCount = sceneDetails.devices.filter(device => device.isActive).length;
      sceneDetails.readyDeviceCount = sceneDetails.devices.filter(device => device.isReadyForScene).length;
      sceneDetails.totalChannels = sceneDetails.devices.reduce(
        (total, device) => total + device.installedChannels.length, 0
      );
      sceneDetails.validChannels = sceneDetails.devices.reduce(
        (total, device) => total + device.validChannelCount, 0
      );
      // Scene is executable if it has ready devices with valid installed channels
      sceneDetails.isSceneExecutable = sceneDetails.readyDeviceCount > 0 && sceneDetails.validChannels > 0;
    } else if (scene.type === 'group') {
      sceneDetails.groups = await processGroupsForScene(scene.Groups || []);
      sceneDetails.groupCount = sceneDetails.groups.length;
      sceneDetails.totalDevices = sceneDetails.groups.reduce(
        (total, group) => total + group.devices.length, 0
      );
      sceneDetails.activeDeviceCount = sceneDetails.groups.reduce(
        (total, group) => total + group.activeDeviceCount, 0
      );
      sceneDetails.readyDeviceCount = sceneDetails.groups.reduce(
        (total, group) => total + group.readyDeviceCount, 0
      );
      sceneDetails.totalChannels = sceneDetails.groups.reduce(
        (total, group) => total + group.devices.reduce(
          (groupTotal, device) => groupTotal + device.installedChannels.length, 0
        ), 0
      );
      sceneDetails.validChannels = sceneDetails.groups.reduce(
        (total, group) => total + group.totalValidChannels, 0
      );
      sceneDetails.isSceneExecutable = sceneDetails.readyDeviceCount > 0 && sceneDetails.validChannels > 0;
    }

    return sceneDetails;
  } catch (error) {
    throw new Error(`Error fetching scene details: ${error.message}`);
  }
};

// Process scene devices with installed channels and complete location information
const processDevicesForScene = async (sceneDevices) => {
  const deviceIds = sceneDevices.map(sd => sd.deviceId);
  
  // Fetch all devices in one query
  const devices = await Device.find({
    device_id: { $in: deviceIds },
    deletedAt: null
  })
    .populate({ path: 'campus', select: 'name code description' })
    .populate({ path: 'building', select: 'name code description' })
    .populate({ path: 'floor', select: 'name number description' })
    .populate({ path: 'zone', select: 'name code description' })
    .lean();

  // Create device lookup map
  const deviceMap = new Map(devices.map(d => [d.device_id, d]));

  return sceneDevices.map(sceneDevice => {
    const device = deviceMap.get(sceneDevice.deviceId);
    
    if (!device) {
      return {
        deviceId: sceneDevice.deviceId,
        deviceName: 'Device Not Found',
        status: 'not_found',
        isActive: false,
        isConfigured: false,
        sceneChannels: sceneDevice.channels || [],
        installedChannels: [],
        location: null,
        statusMessage: 'Device not found in database'
      };
    }

    // Check if device is active
    const isActive = device.status === 'active' || device.status === 1 || device.status === '1';
    const isConfigured = device.configure_flag === 1 || device.configure_flag === '1' || device.configure_flag === true;

    // Filter only installed capabilities
    const installedCapabilities = (device.capabilities || [])
      .filter(cap => cap?.properties?.installed === true)
      .map(cap => ({
        id: cap.channelId,
        name: cap.name,
        type: cap.type,
        status: cap.status || 'off',
        properties: cap.properties
      }));

    // Match scene channels with installed channels only and populate with real-time device capabilities data
    const matchedChannels = (sceneDevice.channels || [])
      .map(sceneChannel => {
        const installedChannel = installedCapabilities.find(
          cap => cap.id === sceneChannel.channelId && 
                 cap.type === sceneChannel.channelType
        );
        
        // Integrate real-time device status instead of stored scene values for accuracy
        let actualBrightness = null;
        let actualOpenLevel = null;
        let actualStatus = 'unknown';
        let actualPowerMin = null;
        let actualPowerMax = null;
        
        if (installedChannel) {
          actualStatus = installedChannel.status || 'unknown';
          
          // For LED channels, get brightness from device capabilities
          if (installedChannel.type === 'led') {
            actualBrightness = installedChannel.properties?.brightness || 
                              installedChannel.properties?.level || 
                              (installedChannel.status === 'on' ? 100 : 0);
            actualPowerMin = installedChannel.properties?.powerMin || 0;
            actualPowerMax = installedChannel.properties?.powerMax || 0;

          }
          // For shade channels, get openLevel from device capabilities  
          else if (installedChannel.type === 'shade') {
            actualOpenLevel = installedChannel.properties?.openLevel || 
                             installedChannel.properties?.level ||
                             installedChannel.properties?.position || 0;
          }
        }
        
        const result = {
          channelType: sceneChannel.channelType,
          channelId: sceneChannel.channelId,
          command: sceneChannel.command,
          isInstalled: !!installedChannel,
          channelDescription: installedChannel?.description || 'N/A',
          channelName: installedChannel?.name || 'N/A',
          channelStatus: actualStatus, // Use actual status from device capabilities
          numberOfCmds: installedChannel?.properties?.numberOfCmds || null,
          deviceType: device.type || 'N/A'
        };

        // Use real-time brightness/openLevel from device capabilities instead of stored scene values
        if (sceneChannel.channelType === 'led') {
          result.brightness = actualBrightness !== null ? actualBrightness : (sceneChannel.brightness || 0);
          result.properties = {
            powerMin: actualPowerMin,
            powerMax: actualPowerMax
          };
        }
        if (sceneChannel.channelType === 'shade') {
          result.openLevel = actualOpenLevel !== null ? actualOpenLevel : (sceneChannel.openLevel || 0);
        }
        
        return result;
      });

    // Generate status message based on device state
    let statusMessage = '';
    if (!isActive) {
      statusMessage = 'Device is inactive';
    } else if (!isConfigured) {
      statusMessage = 'Device is active but not configured';
    } else if (installedCapabilities.length === 0) {
      statusMessage = 'Device has no installed capabilities';
    } else if (matchedChannels.filter(ch => ch.isInstalled).length === 0) {
      statusMessage = 'No valid channels for this scene';
    } else {
      statusMessage = 'Device is ready for scene execution';
    }

    return {
      deviceId: sceneDevice.deviceId,
      deviceName: device.name || 'N/A',
      deviceType: device.type || 'N/A',
      serialNumber: device.SNO || 'N/A',
      macAddress: device.Mac_addr || 'N/A',
      status: device.status,
      isActive: isActive,
      isConfigured: isConfigured,
      // Device is ready for scene execution if active, configured, and has installed channels
      isReadyForScene: isActive && isConfigured && installedCapabilities.length > 0,
      statusMessage: statusMessage,
      location: {
        campus: {
          id: device.campus?._id || null,
          name: device.campus?.name || 'N/A',
          code: device.campus?.code || null
        },
        building: {
          id: device.building?._id || null,
          name: device.building?.name || 'N/A',
          code: device.building?.code || null
        },
        floor: {
          id: device.floor?._id || null,
          name: device.floor?.name || 'N/A',
          number: device.floor?.number || null
        },
        zone: {
          id: device.zone?._id || null,
          name: device.zone?.name || 'N/A',
          code: device.zone?.code || null
        }
      },
      sceneChannels: matchedChannels,
      installedChannels: installedCapabilities,
      installedChannelCount: installedCapabilities.length,
      sceneChannelCount: matchedChannels.length,
      validChannelCount: matchedChannels.filter(ch => ch.isInstalled).length
    };
  });
};

// Get comprehensive scene list with detailed device/group information and installed channels
export const getAllScenesWithDeviceGroupDetails = async (queryParams = {}) => {
  try {
    const {
      search = '',
      status,
      sortBy = 'createdAt',
      sortOrder = 'desc',
      page = 1,
      limit = 50
    } = queryParams;

    // Build filter object
    const filter = {
      isDeleted: { $ne: true } // Exclude soft-deleted scenes
    };

    // Add status filter if provided
    if (status !== undefined) {
      filter.status = parseInt(status);
    }

    // Add search filter if provided
    if (search && search.trim()) {
      filter.name = { $regex: search.trim(), $options: 'i' };
    }

    // Build sort object
    const sort = {};
    sort[sortBy] = sortOrder === 'asc' ? 1 : -1;

    // Calculate pagination values
    const skip = (page - 1) * limit;
    
    // Get total count for pagination
    const totalScenes = await Scene.countDocuments(filter);

    // Fetch scenes with pagination
    const scenes = await Scene.find(filter)
      .sort(sort)
      .skip(skip)
      .limit(parseInt(limit))
      .populate('createdBy.userId', 'fullName email')
      .populate('updatedBy.userId', 'fullName email')
      .lean();

    console.log(`Processing ${scenes.length} scenes with detailed information`);

    // Process each scene with detailed device/group information
    const detailedScenes = await Promise.all(
      scenes.map(async (scene) => {
        const sceneBase = {
          _id: scene._id,
          name: scene.name,
          description: scene.description,
          type: scene.type,
          status: scene.status,
          statusText: scene.status === 1 ? 'active' : 'inactive',
          lastExecuted: scene.lastExecuted || "",
          executedBy: scene.executedBy,
          createdAt: scene.createdAt,
          updatedAt: scene.updatedAt,
          createdBy: scene.createdBy,
          updatedBy: scene.updatedBy
        };

        // Process based on scene type
        if (scene.type === 'device') {
          const devices = await processDevicesForScene(scene.Devices || []);
          
          return {
            ...sceneBase,
            devices: devices,
            deviceCount: devices.length,
            activeDeviceCount: devices.filter(device => device.isActive).length,
            readyDeviceCount: devices.filter(device => device.isReadyForScene).length,
            totalChannels: devices.reduce((total, device) => total + device.installedChannels.length, 0),
            validChannels: devices.reduce((total, device) => total + device.validChannelCount, 0),
            isSceneExecutable: devices.filter(device => device.isReadyForScene).length > 0 && 
                             devices.reduce((total, device) => total + device.validChannelCount, 0) > 0,
            // Summary statistics for this scene
            summary: {
              totalDevices: devices.length,
              activeDevices: devices.filter(device => device.isActive).length,
              configuredDevices: devices.filter(device => device.isConfigured).length,
              readyDevices: devices.filter(device => device.isReadyForScene).length,
              totalInstalledChannels: devices.reduce((total, device) => total + device.installedChannelCount, 0),
              validSceneChannels: devices.reduce((total, device) => total + device.validChannelCount, 0)
            }
          };
        } else if (scene.type === 'group') {
          const groups = await processGroupsForScene(scene.Groups || []);
          
          return {
            ...sceneBase,
            groups: groups,
            groupCount: groups.length,
            totalDevices: groups.reduce((total, group) => total + group.devices.length, 0),
            activeDeviceCount: groups.reduce((total, group) => total + group.activeDeviceCount, 0),
            readyDeviceCount: groups.reduce((total, group) => total + group.readyDeviceCount, 0),
            totalChannels: groups.reduce((total, group) => total + 
              group.devices.reduce((groupTotal, device) => groupTotal + device.installedChannels.length, 0), 0),
            validChannels: groups.reduce((total, group) => total + group.totalValidChannels, 0),
            isSceneExecutable: groups.reduce((total, group) => total + group.readyDeviceCount, 0) > 0 && 
                             groups.reduce((total, group) => total + group.totalValidChannels, 0) > 0,
            // Summary statistics for this scene
            summary: {
              totalGroups: groups.length,
              totalDevices: groups.reduce((total, group) => total + group.devices.length, 0),
              activeDevices: groups.reduce((total, group) => total + group.activeDeviceCount, 0),
              readyDevices: groups.reduce((total, group) => total + group.readyDeviceCount, 0),
              totalInstalledChannels: groups.reduce((total, group) => total + group.totalInstalledChannels, 0),
              validSceneChannels: groups.reduce((total, group) => total + group.totalValidChannels, 0)
            }
          };
        }
        
        return sceneBase;
      })
    );

    // Calculate current page summary statistics
    const currentPageSummary = {
      total_scenes: totalScenes,
      current_page_scenes: detailedScenes.length,
      active_scenes: detailedScenes.filter(scene => scene.status === 1).length,
      inactive_scenes: detailedScenes.filter(scene => scene.status === 0).length,
      device_scenes: detailedScenes.filter(scene => scene.type === 'device').length,
      group_scenes: detailedScenes.filter(scene => scene.type === 'group').length,
      executable_scenes: detailedScenes.filter(scene => scene.isSceneExecutable).length,
      total_devices: detailedScenes.reduce((total, scene) => {
        if (scene.type === 'device') return total + (scene.deviceCount || 0);
        if (scene.type === 'group') return total + (scene.totalDevices || 0);
        return total;
      }, 0),
      total_active_devices: detailedScenes.reduce((total, scene) => total + (scene.activeDeviceCount || 0), 0),
      total_ready_devices: detailedScenes.reduce((total, scene) => total + (scene.readyDeviceCount || 0), 0),
      total_installed_channels: detailedScenes.reduce((total, scene) => total + (scene.totalChannels || 0), 0),
      total_valid_channels: detailedScenes.reduce((total, scene) => total + (scene.validChannels || 0), 0)
    };

    // Calculate pagination info
    const totalPages = Math.ceil(totalScenes / limit);
    const hasNextPage = page < totalPages;
    const hasPrevPage = page > 1;

    return {
      scenes: detailedScenes,
      pagination: {
        current_page: page,
        total_pages: totalPages,
        total_scenes: totalScenes,
        scenes_per_page: limit,
        has_next_page: hasNextPage,
        has_prev_page: hasPrevPage
      },
      summary: currentPageSummary,
      executionReadiness: {
        executable_scenes: currentPageSummary.executable_scenes,
        total_scenes: currentPageSummary.total_scenes,
        readiness_percentage: currentPageSummary.total_scenes > 0 
          ? Math.round((currentPageSummary.executable_scenes / currentPageSummary.total_scenes) * 100) 
          : 0
      }
    };
  } catch (error) {
    throw new Error(`Error fetching all scenes with detailed information: ${error.message}`);
  }
};

// Process scene groups with devices, installed channels, and location data
const processGroupsForScene = async (sceneGroups) => {
  const groupIds = sceneGroups.map(sg => sg.groupId);
  
  // Fetch all groups in one query
  const groups = await Group.find({
    _id: { $in: groupIds },
    isDeleted: { $ne: true }
  }).lean();

  // Create group lookup map
  const groupMap = new Map(groups.map(g => [String(g._id), g]));

  // Collect all device IDs from all groups
  const allDeviceIds = sceneGroups.flatMap(sg => 
    (sg.devices || []).map(d => d.deviceId)
  );

  // Fetch all devices in one query
  const devices = await Device.find({
    device_id: { $in: allDeviceIds },
    deletedAt: null
  })
    .populate({ path: 'campus', select: 'name code description' })
    .populate({ path: 'building', select: 'name code description' })
    .populate({ path: 'floor', select: 'name number description' })
    .populate({ path: 'zone', select: 'name code description' })
    .lean();

  // Create device lookup map
  const deviceMap = new Map(devices.map(d => [d.device_id, d]));

  return sceneGroups.map(sceneGroup => {
    const group = groupMap.get(String(sceneGroup.groupId));
    
    if (!group) {
      return {
        groupId: sceneGroup.groupId,
        groupName: 'Group Not Found',
        status: 'not_found',
        devices: []
      };
    }

    // Process devices within this group
    const processedDevices = (sceneGroup.devices || []).map(sceneDevice => {
      const device = deviceMap.get(sceneDevice.deviceId);
      
      if (!device) {
        return {
          deviceId: sceneDevice.deviceId,
          deviceName: 'Device Not Found',
          status: 'not_found',
          isActive: false,
          isConfigured: false,
          sceneChannels: sceneDevice.channels || [],
          installedChannels: [],
          location: null,
          statusMessage: 'Device not found in database'
        };
      }

      // Check if device is active
      const isActive = device.status === 'active' || device.status === 1 || device.status === '1';
      const isConfigured = device.configure_flag === 1 || device.configure_flag === '1' || device.configure_flag === true;

      // Filter only installed capabilities
      const installedCapabilities = (device.capabilities || [])
        .filter(cap => cap?.properties?.installed === true)
        .map(cap => ({
          id: cap.channelId,
          name: cap.name,
          type: cap.type,
          status: cap.status || 'off',
          properties: cap.properties
        }));

      // Match scene channels with installed channels only and populate with real-time device capabilities data
      const matchedChannels = (sceneDevice.channels || [])
        .map(sceneChannel => {
          const installedChannel = installedCapabilities.find(
            cap => cap.id === sceneChannel.channelId && 
                   cap.type === sceneChannel.channelType
          );
          
          // Integrate real-time device status instead of stored scene values for accuracy
          let actualBrightness = null;
          let actualOpenLevel = null;
          let actualStatus = 'unknown';
          let actualPowerMin = null;
          let actualPowerMax = null;
        
          
          if (installedChannel) {
            actualStatus = installedChannel.status || 'unknown';
            
            // For LED channels, get brightness from device capabilities
            if (installedChannel.type === 'led') {
              actualBrightness = installedChannel.properties?.brightness || 
                                installedChannel.properties?.level || 
                                (installedChannel.status === 'on' ? 100 : 0);
              actualPowerMin = installedChannel.properties?.powerMin || 0;
              actualPowerMax = installedChannel.properties?.powerMax || 0;
            }
            // For shade channels, get openLevel from device capabilities  
            else if (installedChannel.type === 'shade') {
              actualOpenLevel = installedChannel.properties?.openLevel || 
                               installedChannel.properties?.level ||
                               installedChannel.properties?.position || 0;
            }
          }

          const result = {
            channelType: sceneChannel.channelType,
            channelId: sceneChannel.channelId,
            command: sceneChannel.command,
            isInstalled: !!installedChannel,
            channelName: installedChannel?.name || 'Channel Not Found',
            channelStatus: actualStatus, // Use actual status from device capabilities
            numberOfCmds: installedChannel?.properties?.numberOfCmds || null,
            deviceType: device.type || 'N/A'
          };

          // Use real-time brightness/openLevel from device capabilities instead of stored scene values
          if (sceneChannel.channelType === 'led') {
            result.brightness = actualBrightness !== null ? actualBrightness : (sceneChannel.brightness || 0);
            result.properties = {
              powerMin: actualPowerMin,
              powerMax: actualPowerMax
            };
          }
          if (sceneChannel.channelType === 'shade') {
            result.openLevel = actualOpenLevel !== null ? actualOpenLevel : (sceneChannel.openLevel || 0);
          }
          
          return result;
        });

      // Generate status message based on device state
      let statusMessage = '';
      if (!isActive) {
        statusMessage = 'Device is inactive';
      } else if (!isConfigured) {
        statusMessage = 'Device is active but not configured';
      } else if (installedCapabilities.length === 0) {
        statusMessage = 'Device has no installed capabilities';
      } else if (matchedChannels.filter(ch => ch.isInstalled).length === 0) {
        statusMessage = 'No valid channels for this scene';
      } else {
        statusMessage = 'Device is ready for scene execution';
      }

      // Include complete group channel information for comprehensive device control
      // Find the actual group document to get ALL channels for this device
      const groupDoc = group;
      const groupDevice = groupDoc?.devices?.find(d => d.deviceId === sceneDevice.deviceId);
      const allGroupChannels = groupDevice?.channels || [];
      
      const deviceGroupsChannels = allGroupChannels.map(channel => {
        // Find the corresponding capability in the device to get full details
        const deviceCapability = device?.capabilities?.find(
          cap => cap.channelId === channel.channelId && cap.type === channel.channelType
        );

        // Get actual brightness and openLevel values from device capabilities
        let actualBrightness = null;
        let actualOpenLevel = null;
        
        if (deviceCapability && deviceCapability.properties?.installed === true) {
          // For LED channels, get brightness from properties or status
          if (channel.channelType === 'led') {
            actualBrightness = deviceCapability.properties?.brightness || 
                              deviceCapability.properties?.level || 
                              (deviceCapability.status === 'on' ? 100 : 0);
          }
          // For shade channels, get openLevel from properties or status  
          else if (channel.channelType === 'shade') {
            actualOpenLevel = deviceCapability.properties?.openLevel || 
                             deviceCapability.properties?.level ||
                             deviceCapability.properties?.position || 0;
          }
        }

        const channelResult = {
          deviceId: sceneDevice.deviceId,
          id: channel.channelId,
          name: deviceCapability?.name || `Channel ${channel.channelId}`,
          type: channel.channelType,
          status: deviceCapability?.status || 'off',
          properties: deviceCapability?.properties || {},
          isInstalled: deviceCapability?.properties?.installed === true
        };
        
        // Add only the relevant actual value based on channel type
        if (channel.channelType === 'led' && actualBrightness !== null) {
          channelResult.brightness = actualBrightness;
        } else if (channel.channelType === 'shade' && actualOpenLevel !== null) {
          channelResult.openLevel = actualOpenLevel;
        }
        
        return channelResult;
      });

      return {
        deviceId: sceneDevice.deviceId,
        deviceName: device.name || 'N/A',
        deviceType: device.type || 'N/A',
        serialNumber: device.SNO || 'N/A',
        macAddress: device.Mac_addr || 'N/A',
        status: device.status,
        isActive: isActive,
        isConfigured: isConfigured,
        isReadyForScene: isActive && isConfigured && installedCapabilities.length > 0,
        statusMessage: statusMessage,
        location: {
          campus: {
            id: device.campus?._id || null,
            name: device.campus?.name || 'N/A',
            code: device.campus?.code || null
          },
          building: {
            id: device.building?._id || null,
            name: device.building?.name || 'N/A',
            code: device.building?.code || null
          },
          floor: {
            id: device.floor?._id || null,
            name: device.floor?.name || 'N/A',
            number: device.floor?.number || null
          },
          zone: {
            id: device.zone?._id || null,
            name: device.zone?.name || 'N/A',
            code: device.zone?.code || null
          }
        },
        sceneChannels: matchedChannels,
        installedChannels: installedCapabilities,
        groupsChannels: deviceGroupsChannels,
        installedChannelCount: installedCapabilities.length,
        sceneChannelCount: matchedChannels.length,
        validChannelCount: matchedChannels.filter(ch => ch.isInstalled).length
      };
    });

    return {
      groupId: sceneGroup.groupId,
      groupName: group.name || 'N/A',
      groupDescription: group.description || 'N/A',
      groupStatus: group.status || 'active',
      devices: processedDevices,
      deviceCount: processedDevices.length,
      activeDeviceCount: processedDevices.filter(device => device.isActive).length,
      readyDeviceCount: processedDevices.filter(device => device.isReadyForScene).length,
      totalInstalledChannels: processedDevices.reduce(
        (total, device) => total + device.installedChannelCount, 0
      ),
      totalValidChannels: processedDevices.reduce(
        (total, device) => total + device.validChannelCount, 0
      )
    };
  });
};

// Get all active scenes for users with unrestricted access (allowedResources = null)
export const getAllActiveScenes = async (searchName = null, user = null) => {
  const query = {
    isDeleted: { $ne: true },
    status: 1
  };
  
  // Add name search functionality if searchName is provided
  if (searchName && searchName.trim()) {
    query.name = { $regex: searchName.trim(), $options: 'i' }; // Case-insensitive search
  }
  
  const scenes = await Scene.find(query).sort({ createdAt: -1 }).lean();
  
  // Apply zone-based filtering if user has campusData
  if (user && user.campusData && Array.isArray(user.campusData)) {
    // If campusData is empty array, show all data (no filtering)
    if (user.campusData.length > 0) {
      // Extract zone IDs from user's campus data
      const zoneIds = [];
      user.campusData.forEach(campus => {
        if (campus.buildings && Array.isArray(campus.buildings)) {
          campus.buildings.forEach(building => {
            if (building.floors && Array.isArray(building.floors)) {
              building.floors.forEach(floor => {
                if (floor.zones && Array.isArray(floor.zones)) {
                  floor.zones.forEach(zone => {
                    if (zone.zone_id) {
                      zoneIds.push(zone.zone_id);
                    }
                  });
                }
              });
            }
          });
        }
      });

      if (zoneIds.length > 0) {
        // Filter scenes based on whether they have devices in allowed zones
        const filteredScenes = [];
        for (const scene of scenes) {
          let hasAllowedDevice = false;

          // Check devices directly in scene
          if (scene.type === 'device' && scene.Devices && scene.Devices.length > 0) {
            const sceneDeviceIds = scene.Devices.map(d => d.deviceId);
            const allowedDevicesCount = await Device.countDocuments({
              device_id: { $in: sceneDeviceIds },
              zone: { $in: zoneIds },
              deletedAt: null
            });
            hasAllowedDevice = allowedDevicesCount > 0;
          }

          // Check devices in groups within scene  
          if (!hasAllowedDevice && scene.type === 'group' && scene.Groups && scene.Groups.length > 0) {
            const allDeviceIds = scene.Groups.flatMap(group => 
              (group.devices || []).map(d => d.deviceId)
            );
            if (allDeviceIds.length > 0) {
              const allowedDevicesCount = await Device.countDocuments({
                device_id: { $in: allDeviceIds },
                zone: { $in: zoneIds },
                deletedAt: null
              });
              hasAllowedDevice = allowedDevicesCount > 0;
            }
          }

          if (hasAllowedDevice) {
            filteredScenes.push(scene);
          }
        }
        return filteredScenes;
      } else {
        // No zones in user's campus data, return empty result
        return [];
      }
    }
  }
  
  return scenes;
};

// Get active scenes filtered by user's allowed scene IDs from permission matrix
export const getAllowedActiveScenes = async (allowedSceneIds, searchName = null, user = null) => {
  if (!Array.isArray(allowedSceneIds) || allowedSceneIds.length === 0) return [];
  
  const query = {
    _id: { $in: allowedSceneIds },
    isDeleted: { $ne: true },
    status: 1
  };
  
  // Add name search functionality if searchName is provided
  if (searchName && searchName.trim()) {
    query.name = { $regex: searchName.trim(), $options: 'i' }; // Case-insensitive search
  }
  
  const scenes = await Scene.find(query).sort({ createdAt: -1 }).lean();
  
  // Apply zone-based filtering if user has campusData
  if (user && user.campusData && Array.isArray(user.campusData)) {
    // If campusData is empty array, show all data (no filtering)
    if (user.campusData.length > 0) {
      // Extract zone IDs from user's campus data
      const zoneIds = [];
      user.campusData.forEach(campus => {
        if (campus.buildings && Array.isArray(campus.buildings)) {
          campus.buildings.forEach(building => {
            if (building.floors && Array.isArray(building.floors)) {
              building.floors.forEach(floor => {
                if (floor.zones && Array.isArray(floor.zones)) {
                  floor.zones.forEach(zone => {
                    if (zone.zone_id) {
                      zoneIds.push(zone.zone_id);
                    }
                  });
                }
              });
            }
          });
        }
      });

      if (zoneIds.length > 0) {
        // Filter scenes based on whether they have devices in allowed zones
        const filteredScenes = [];
        for (const scene of scenes) {
          let hasAllowedDevice = false;

          // Check devices directly in scene
          if (scene.type === 'device' && scene.Devices && scene.Devices.length > 0) {
            const sceneDeviceIds = scene.Devices.map(d => d.deviceId);
            const allowedDevicesCount = await Device.countDocuments({
              device_id: { $in: sceneDeviceIds },
              zone: { $in: zoneIds },
              deletedAt: null
            });
            hasAllowedDevice = allowedDevicesCount > 0;
          }

          // Check devices in groups within scene  
          if (!hasAllowedDevice && scene.type === 'group' && scene.Groups && scene.Groups.length > 0) {
            const allDeviceIds = scene.Groups.flatMap(group => 
              (group.devices || []).map(d => d.deviceId)
            );
            if (allDeviceIds.length > 0) {
              const allowedDevicesCount = await Device.countDocuments({
                device_id: { $in: allDeviceIds },
                zone: { $in: zoneIds },
                deletedAt: null
              });
              hasAllowedDevice = allowedDevicesCount > 0;
            }
          }

          if (hasAllowedDevice) {
            filteredScenes.push(scene);
          }
        }
        return filteredScenes;
      } else {
        // No zones in user's campus data, return empty result
        return [];
      }
    }
  }
  
  return scenes;
};