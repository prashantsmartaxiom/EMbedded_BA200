import jwt from 'jsonwebtoken';
import { User } from '../models/User.js';
import { UserAuth } from '../models/UserAuth.js';
import Role from '../models/Role.js';
import Device from '../models/Device.js';
import { Template } from '../models/Template.js';
import { Scene } from '../models/Scene.js';
import { Group } from '../models/Group.js';
import { getConfig } from '../config/env.js';
import { createUserAuthData, generateOTP } from '../utils/userAuth.js';
import { generateSecureToken, createHash } from '../config/crypto.js';
import { addLog } from './log.service.js';

/**
 * Authentication Service - Core Auth & Security Layer
 * 
 * Flow: routes → controller → SERVICE → database
 * 
 * Core Responsibilities:
 * - User registration and account activation
 * - JWT token generation and validation
 * - Password hashing and verification
 * - Role-based permission initialization
 * - Session management and tracking
 * - Security audit logging
 * 
 * Security Features:
 * - BCrypt password hashing
 * - JWT token expiration
 * - OTP-based verification
 * - Session tracking with IP/device info
 * - Default role system with permission matrix
 * - Password reset flow with secure tokens
 */

// System default roles created on first user registration
const DEFAULT_ROLES = [
  {
    roleName: "Superadmin",
    permissions: {
      CAMPUS_MANAGEMENT: {
        campus_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        building_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        floor_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        zone_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      },
      INTELLIGENT_CONTROL: {
        group_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        scene_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        sensor_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        template_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      },
      DEVICE_MANAGEMENT: {
        device_control: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        manage_channels: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        manage_sensors: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      },
      USER_MANAGEMENT: {
        user_accounts: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        role_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      },
      LOGS_MONITORING: {
        event_logs: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        mqtt_logs: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      },
      CONTROL_SECTION: {
        device_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        template_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        scene_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        group_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      }
    },
    isDelete: false,
    isActive: true,
    byDefault: "true"
  },
  {
    roleName: "Admin",
    permissions: {
      CAMPUS_MANAGEMENT: {
        campus_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        building_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        floor_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        zone_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      },
      INTELLIGENT_CONTROL: {
        group_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        scene_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        sensor_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        template_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      },
      DEVICE_MANAGEMENT: {
        device_control: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        manage_channels: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        manage_sensors: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      },
      USER_MANAGEMENT: {
        user_accounts: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        role_management: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      },
      LOGS_MONITORING: {
        event_logs: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        mqtt_logs: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      },
      CONTROL_SECTION: {
        device_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        template_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        scene_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        group_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      }
    },
    isDelete: false,
    isActive: true,
    byDefault: "true"
  },
  {
    roleName: "Technician",
    permissions: {
      CAMPUS_MANAGEMENT: {
        campus_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        building_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        floor_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        zone_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        }
      },
      INTELLIGENT_CONTROL: {
        group_management: {
          View: true,
          "Add/Update": true,
          Delete: false
        },
        scene_management: {
          View: true,
          "Add/Update": true,
          Delete: false
        },
        sensor_management: {
          View: true,
          "Add/Update": true,
          Delete: false
        },
        template_management: {
          View: true,
          "Add/Update": true,
          Delete: false
        }
      },
      DEVICE_MANAGEMENT: {
        device_control: {
          View: true,
          "Add/Update": true,
          Delete: false
        },
        manage_channels: {
          View: true,
          "Add/Update": true,
          Delete: false
        },
        manage_sensors: {
          View: true,
          "Add/Update": true,
          Delete: false
        }
      },
      USER_MANAGEMENT: {
        user_accounts: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        role_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        }
      },
      LOGS_MONITORING: {
        event_logs: {
          View: true,
          "Add/Update": false,
          Delete: false
        },
        mqtt_logs: {
          View: true,
          "Add/Update": false,
          Delete: false
        }
      },
      CONTROL_SECTION: {
        template_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        scene_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        group_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        device_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      }
    },
    isDelete: false,
    isActive: true,
    byDefault: "true"
  },
  {
    roleName: "Operator",
    permissions: {
      CAMPUS_MANAGEMENT: {
        campus_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        building_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        floor_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        zone_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        }
      },
      INTELLIGENT_CONTROL: {
        group_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        scene_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        sensor_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        template_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        }
      },
      DEVICE_MANAGEMENT: {
        device_control: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        manage_channels:{
          View: false,
          "Add/Update": false,
          Delete: false
        },
        manage_sensors: {
          View: false,
          "Add/Update": false,
          Delete: false
        }
      },
      USER_MANAGEMENT: {
        user_accounts: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        role_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        }
      },
      LOGS_MONITORING: {
        event_logs: {
          View: true,
          "Add/Update": false,
          Delete: false
        },
        mqtt_logs: {
          View: false,
          "Add/Update": false,
          Delete: false
        }
      },
      CONTROL_SECTION: {
        template_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        scene_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        group_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        device_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        }
      }
    },
    isDelete: false,
    isActive: true,
    byDefault: "true"
  },
  {
    roleName: "Tenant",
    permissions: {
      CAMPUS_MANAGEMENT: {
        campus_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        building_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        floor_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        zone_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        }
      },
      INTELLIGENT_CONTROL: {
        group_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        scene_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        sensor_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        template_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        }
      },
      DEVICE_MANAGEMENT: {
        device_control: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        manage_channels: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        manage_sensors: {
          View: false,
          "Add/Update": false,
          Delete: false
        }
      },
      USER_MANAGEMENT: {
        user_accounts: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        role_management: {
          View: false,
          "Add/Update": false,
          Delete: false
        }
      },
      LOGS_MONITORING: {
        system_logs: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        activity_logs: {
          View: false,
          "Add/Update": false,
          Delete: false
        }
      },
      CONTROL_SECTION: {
        template_tab: {
          View: true,
          "Add/Update": true,
          Delete: true
        },
        scene_tab: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        group_tab: {
          View: false,
          "Add/Update": false,
          Delete: false
        },
        device_tab: {
          View: false,
          "Add/Update": false,
          Delete: false
        }
      }
    },
    isDelete: false,
    isActive: true,
    byDefault: "true"
  }
];

/**
 * Get role details for a specific user
 * Used for permission checking and UI role display
 */
export const getRoleDetailByUserId = async (userId) => {
  const user = await User.findById(userId).populate({ path: 'role_id', model: Role }).lean();
  if (!user) throw Object.assign(new Error('User not found'), { status: 404 });
  let roleDoc = null;
  if (user.role_id && typeof user.role_id === 'object' && user.role_id._id) {
    roleDoc = user.role_id;
  } else if (user.role_id) {
    roleDoc = await Role.findById(user.role_id).lean();
  }
  if (!roleDoc) throw Object.assign(new Error('Role not found'), { status: 404 });
  return {
    roleDetail: {
      id: roleDoc._id ?? roleDoc.id,
      roleName: roleDoc.roleName,
      isActive: roleDoc.isActive,
      isDelete: roleDoc.isDelete,
      permissions: roleDoc.permissions
    }
  };
};

/**
 * Initialize system default roles on first setup
 * Creates: Superadmin, Admin, Technician, Operator, Tenant
 * Each with predefined permission matrix
 */
const initializeDefaultRoles = async () => {
  try {
    // Only create default roles if no roles exist
    const roleCount = await Role.countDocuments();
    if (roleCount === 0) {
      console.log('No roles found. Creating default roles...');
      // Insert roles (ordered:false helps continue on duplicate key errors if any)
      const createdRoles = await Role.insertMany(DEFAULT_ROLES, { ordered: false }).catch(err => {
        // If duplicate key or partial failure, try to return existing roles
        console.warn('insertMany warning:', err.message || err);
        return null;
      });
      if (createdRoles && createdRoles.length) {
        console.log(`Successfully created ${createdRoles.length} default roles`);
        return createdRoles;
      }
      // Fallback: return all roles present after attempted creation
      return await Role.find({ roleName: { $in: DEFAULT_ROLES.map(r => r.roleName) } }).lean();
    }
    return null; // Roles already exist
  } catch (error) {
    console.error('Error initializing default roles:', error);
    throw error;
  }
};

export const register = async (userData, req) => {
  const { fullName, location, contactNumber, email, password, assignedTopics = [] } = userData;

  const exists = await User.findOne({ email });
  if (exists) throw Object.assign(new Error('Email already registered'), { status: 409 });

  if (contactNumber) {
    const existingContact = await User.findOne({ contactNumber });
    if (existingContact) throw Object.assign(new Error('Contact number already registered'), { status: 409 });
  }

  // Determine if this is the very first user
  const isFirstUser = (await User.countDocuments()) === 0;

  // Ensure default roles exist (create only if no roles)
  await initializeDefaultRoles();

  // Decide role assignment:
  // - First user => Admin
  // - Subsequent users with no role provided => Operator
  // - If user provided role_id, keep it
  let role_id = userData.role_id ?? null;

  if (isFirstUser) {
    const adminRole = await Role.findOne({ roleName: 'Superadmin' }).lean();
    if (adminRole) role_id = adminRole._id;
  } else {
    if (!role_id) {
      const operatorRole = await Role.findOne({ roleName: 'Operator' }).lean();
      if (operatorRole) role_id = operatorRole._id;
    }
  }

  // Generate 6-digit OTP (use generateOTP() in production)
  const otp = generateOTP ? generateOTP() : '123456';

  // Create allowedResources for non-first users
  let allowedResources = null;
  if (!isFirstUser) {
    try {
      // Fetch active, non-deleted devices
      const devices = await Device.find({ 
        status: 'Active', 
        is_delete: false 
      }).select('_id').lean();

      // Fetch active, non-deleted templates (assuming active status means status field exists and is not inactive)
      const templates = await Template.find({ 
        status: { $ne: 'Inactive' } 
      }).select('_id').lean();

      // Fetch active, non-deleted scenes
      const scenes = await Scene.find({ 
        status: 1, 
        isDeleted: false 
      }).select('_id').lean();

      // Fetch active, non-deleted groups
      const groups = await Group.find({ 
        isDeleted: false 
      }).select('_id').lean();

      allowedResources = {
        controlSection: {
          deviceTab: devices.map(device => device._id.toString()),
          templateTab: templates.map(template => template._id.toString()),
          sceneTab: scenes.map(scene => scene._id.toString()),
          groupTab: groups.map(group => group._id.toString())
        },
        logsMonitoring: {
          eventLogs: ["true"]
        }
      };
    } catch (error) {
      console.error('Error fetching resources for allowedResources:', error);
      // Continue with null allowedResources if there's an error
    }
  }

  const user = await User.create({
    fullName,
    location,
    contactNumber,
    email,
    password,
    role_id,
    otp,
    assignedTopics,
    ...(allowedResources && { allowedResources }),
    createdDate: new Date().toISOString()
  });

  // Create initial UserAuth entry for signup tracking
  const signupAuthData = createUserAuthData(req, null, null, {
    userId: user._id,
    fullName: user.fullName,
    email: user.email
  });

  await UserAuth.create({
    userId: user._id,
    ...signupAuthData,
    createdOn: new Date(),
    updatedOn: new Date()
  });

  return { user: publicUser(user), otp: otp }; // Return OTP for verification (in production, send via SMS/email)
};

export const verifySignupOTP = async (email, providedOTP) => {
  const user = await User.findOne({ email: email.toLowerCase() }).select('+otp');
  if (!user) throw Object.assign(new Error('User not found'), { status: 404 });

  const storedOtp = (user.otp ?? user[' otp'])?.toString().trim();

  if (!storedOtp) {
    throw Object.assign(new Error('No OTP found for this user'), { status: 400 });
  }

  if (storedOtp !== String(providedOTP).trim()) {
    throw Object.assign(new Error('Invalid OTP'), { status: 400 });
  }

  const rawResetToken = generateSecureToken(32);        // raw token to return
  const hashedResetToken = createHash(rawResetToken);   // stored hash

  const now = new Date();
  const expiresAt = new Date(now.getTime() + (getConfig().reset.tokenExpiryMinutes * 60 * 1000 || 15 * 60 * 1000));

  await User.findByIdAndUpdate(
    user._id,
    {
      $unset: { otp: 1, ' otp': 1 }, // clean both keys
      $set: {
        resetPassword: {
          token: hashedResetToken,
          otp: null,
          expiresAt,
          requestedAt: now,
          attempts: 0,
          verified: true // mark verified so OTP path is unlocked too
        }
      }
    }
  );

  return {
    message: 'OTP verified successfully',
    user: publicUser(user),
    resetToken: rawResetToken
  };
};

export const login = async (loginData, req) => {
  const { email, password } = loginData;

  const user = await User.findOne({ email }).select('+password');
  if (!user) throw Object.assign(new Error('Invalid credentials'), { status: 401 });

  // 🔒 Prevent login if inactive or deleted
  if (user.isActive === false || user.isDeleted === true) {
    throw Object.assign(new Error('Your account is disabled. Please contact support.'), { status: 403 });
  }

  const ok = await user.comparePassword(password);
  if (!ok) throw Object.assign(new Error('Invalid credentials'), { status: 401 });

  const token = signToken(user._id);
  const expiryDate = new Date(Date.now() + (365 * 24 * 60 * 60 * 1000)); // 1 year

  // Create user auth entry
  const userAuthData = createUserAuthData(req, token, expiryDate, {
    userId: user._id,
    fullName: user.fullName,
    email: user.email
  });

  await UserAuth.create({
    userId: user._id,
    ...userAuthData,
    createdOn: new Date(),
    updatedOn: new Date()
  });

  // Update user token + lastLogin
  await User.findByIdAndUpdate(user._id, {
    lastLogin: new Date(),
    token
  });

  // === Fetch the fresh user and try to get role details ===
  let updatedUser = await User.findById(user._id).populate({ path: 'role_id', model: Role }).exec();
  const uObj = updatedUser && typeof updatedUser.toObject === 'function'
    ? updatedUser.toObject()
    : (updatedUser || {});

  // Role handling
  let roleDoc = null;
  let roleIdValue = null;

  if (uObj.role_id && typeof uObj.role_id === 'object' && uObj.role_id._id) {
    roleDoc = uObj.role_id;
    roleIdValue = String(uObj.role_id._id);
  } else {
    if (uObj.role_id) roleIdValue = String(uObj.role_id);
    else if (uObj.roleId) roleIdValue = String(uObj.roleId);

    if (roleIdValue) {
      try {
        roleDoc = await Role.findById(roleIdValue).lean();
      } catch (err) {
        roleDoc = null;
      }
    }

    if (!roleDoc && uObj.role && typeof uObj.role === 'string') {
      try {
        roleDoc = await Role.findOne({ roleName: uObj.role }).lean();
        if (roleDoc) roleIdValue = String(roleDoc._id);
      } catch (err) {
        roleDoc = null;
      }
    }
  }

  const updatedUserPlain = uObj;

  const userPublic = {
    id: updatedUserPlain._id ?? updatedUserPlain.id,
    fullName: updatedUserPlain.fullName,
    location: updatedUserPlain.location,
    contactNumber: updatedUserPlain.contactNumber,
    email: updatedUserPlain.email,
    role: updatedUserPlain.role,
    profileImage: updatedUserPlain.profileImage,
    lastLogin: updatedUserPlain.lastLogin,
    createdDate: updatedUserPlain.createdDate,
    assignedTopics: updatedUserPlain.assignedTopics ?? [],
    createdAt: updatedUserPlain.createdAt,
    updatedAt: updatedUserPlain.updatedAt,
    roleId: roleIdValue ?? null,
    organization: updatedUserPlain.organization ?? null
  };


    // Add logging for user login
    try {
      await addLog({
        action: 'Logged In',
        name: `${userPublic?.fullName || userPublic?.email || 'User'}`,
        timestamp: Math.floor(Date.now() / 1000),
        type: 'User',
        userId: userPublic?.id?.toString() || '-',
        userName: userPublic?.fullName || '-',
      });
    } catch (logErr) {
      // eslint-disable-next-line no-console
      console.error('Failed to log user login:', logErr);
    }

  const roleDetail = roleDoc
    ? {
        id: roleDoc._id ?? roleDoc.id,
        roleName: roleDoc.roleName,
        isActive: roleDoc.isActive,
        isDelete: roleDoc.isDelete,
        permissions: roleDoc.permissions
      }
    : null;


  // Add isAdmin flag: true if roleName is 'Admin', else false. By default, true for Admin.
  const isAdmin = roleDoc && roleDoc.roleName === 'Admin' ? true : false;

  const result = {
    user: { ...userPublic, isAdmin },
    token,
    roleDetail
  };

  return result;
};

export const changePassword = async ({ email, oldPassword }, req) => {
  // Find user by email with password field
  const user = await User.findOne({ email }).select('+password');
  if (!user) throw Object.assign(new Error('User not found'), { status: 404 });

  // Verify old password
  const isOldPasswordValid = await user.comparePassword(oldPassword);
  if (!isOldPasswordValid) {
    throw Object.assign(new Error('Current password is incorrect'), { status: 400 });
  }

  // Update user auth entry
  await UserAuth.findOneAndUpdate(
    { userId: user._id, status: 'active' },
    {
      lastUse: new Date(),
      updatedOn: new Date(),
      updatedBy: {
        userId: user._id,
        fullName: user.fullName,
        email: user.email
      }
    }
  );

  // Get updated user data (without password)
  const updatedUser = await User.findById(user._id);

  return { user: publicUser(updatedUser) };
};

// New protected change password method for logged-in users
export const protectedChangePassword = async (userId, { currentPassword, newPassword }, req) => {
  // Find user with password field
  const user = await User.findById(userId).select('+password');
  if (!user) throw Object.assign(new Error('User not found'), { status: 404 });

  // Verify current password
  const isCurrentPasswordValid = await user.comparePassword(currentPassword);
  if (!isCurrentPasswordValid) {
    throw Object.assign(new Error('Current password is incorrect'), { status: 400 });
  }

  // Check if new password is same as current password
  const isSamePassword = await user.comparePassword(newPassword);
  if (isSamePassword) {
    throw Object.assign(new Error('New password cannot be the same as the current password'), { status: 400 });
  }

  // Update password (pre-save middleware will hash it)
  user.password = newPassword;
  await user.save();

  // Update user auth information (keep user logged in, no token invalidation)
  await UserAuth.findOneAndUpdate(
    { userId: user._id, status: 'active' },
    {
      lastUse: new Date(),
      updatedOn: new Date(),
      updatedBy: {
        userId: user._id,
        fullName: user.fullName,
        email: user.email
      }
    }
  );

  // Get updated user data (without password)
  const updatedUser = await User.findById(user._id);

  return { user: publicUser(updatedUser) };
};

export const resetPassword = async (userId, { oldPassword, newPassword }, req) => {
  // Find user with password field
  const user = await User.findById(userId).select('+password');
  if (!user) throw Object.assign(new Error('User not found'), { status: 404 });

  // Verify old password
  const isOldPasswordValid = await user.comparePassword(oldPassword);
  if (!isOldPasswordValid) {
    throw Object.assign(new Error('Current password is incorrect'), { status: 400 });
  }

  // Check if new password is same as current password
  const isSamePassword = await user.comparePassword(newPassword);
  if (isSamePassword) {
    throw Object.assign(new Error('New password cannot be the same as the current password'), { status: 400 });
  }

  // Update password (pre-save middleware will hash it)
  user.password = newPassword;
  await user.save();

  // Invalidate existing token by clearing it and updating auth status
  await User.findByIdAndUpdate(user._id, { token: null });

  // Update all active UserAuth entries to expired
  await UserAuth.updateMany(
    { userId: user._id, status: 'active' },
    {
      status: 'expired',
      lastUse: new Date(),
      updatedOn: new Date(),
      updatedBy: {
        userId: user._id,
        fullName: user.fullName,
        email: user.email
      }
    }
  );

  // Get updated user data (without password)
  const updatedUser = await User.findById(user._id);

  return { user: publicUser(updatedUser) };
};

export const updateProfile = async (userId, updateData, req) => {
  // Find user by ID
  const user = await User.findById(userId).select('+password');
  if (!user) throw Object.assign(new Error('User not found'), { status: 404 });

  // Create update object with only provided fields
  const updateFields = {};

  if (updateData.fullName !== undefined) updateFields.fullName = updateData.fullName;
  if (updateData.role !== undefined) updateFields.role = updateData.role;
  if (updateData.profileImage !== undefined) updateFields.profileImage = updateData.profileImage;

  // Handle password update separately if provided
  if (updateData.password) {
    // Check if new password is same as current password
    const isSamePassword = await user.comparePassword(updateData.password);
    if (isSamePassword) {
      throw Object.assign(new Error('New password cannot be the same as the current password'), { status: 400 });
    }

    user.password = updateData.password;
    await user.save(); // This will trigger the pre-save middleware to hash the password

    // If password is updated, invalidate token (user needs to login again)
    updateFields.token = null;

    // Update all active UserAuth entries to expired
    await UserAuth.updateMany(
      { userId: user._id, status: 'active' },
      { status: 'expired', updatedOn: new Date() }
    );
  } else {
    // Update active UserAuth entry with last use
    await UserAuth.findOneAndUpdate(
      { userId: user._id, status: 'active' },
      {
        lastUse: new Date(),
        updatedOn: new Date(),
        updatedBy: {
          userId: user._id,
          fullName: updateData.fullName || user.fullName,
          email: user.email
        }
      }
    );
  }

  // Update user fields
  await User.findByIdAndUpdate(userId, updateFields);

  // Get updated user data (without password)
  const updatedUser = await User.findById(user._id);

  return { user: publicUser(updatedUser) };
};

// Get user by ID (for protected routes)
export const getUserById = async (userId) => {
  const user = await User.findById(userId);
  if (!user) throw Object.assign(new Error('User not found'), { status: 404 });
  return publicUser(user);
};

// Get all users (admin only)
export const getAllUsers = async (page = 1, limit = 10) => {
  const skip = (page - 1) * limit;
  const users = await User.find({}).skip(skip).limit(limit);
  const total = await User.countDocuments();

  return {
    users: users.map(user => publicUser(user)),
    pagination: {
      currentPage: page,
      totalPages: Math.ceil(total / limit),
      totalUsers: total,
      hasNextPage: page < Math.ceil(total / limit),
      hasPrevPage: page > 1
    }
  };
};

// Get user authentication history
export const getUserAuthHistory = async (userId, page = 1, limit = 10) => {
  const skip = (page - 1) * limit;
  const authHistory = await UserAuth.find({ userId })
    .sort({ createdOn: -1 })
    .skip(skip)
    .limit(limit)
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email');

  const total = await UserAuth.countDocuments({ userId });

  return {
    authHistory,
    pagination: {
      currentPage: page,
      totalPages: Math.ceil(total / limit),
      totalRecords: total,
      hasNextPage: page < Math.ceil(total / limit),
      hasPrevPage: page > 1
    }
  };
};

// Logout (invalidate token)
export const logout = async (userId) => {
  // Remove token from user document (optional, for legacy single-login)
  await User.findByIdAndUpdate(userId, { token: null });

  // Invalidate only the current session's token
  if (!arguments[1] || typeof arguments[1] !== 'string') {
    throw Object.assign(new Error('Token required for logout'), { status: 400 });
  }
  const token = arguments[1];
  const userAuth = await UserAuth.findOne({ userId, jwtToken: token, status: 'active' });
  if (userAuth) {
    await UserAuth.findByIdAndUpdate(userAuth._id, {
      status: 'expired',
      lastUse: new Date(),
      updatedOn: new Date()
    });
  }
  return { message: 'Logged out successfully' };
};

/**
 * Get system roles with optional formatting
 * Supports array or object format for different UI needs
 */
export const getRoles = async (format = 'array') => {
  const roles = ['Admin', 'Technician', 'Operator', 'Tenant'];

  if (format === 'object') {
    return roles.map(role => ({
      value: role,
      label: role,
      description: getRoleDescription(role)
    }));
  }

  return roles;
};

const getRoleDescription = (role) => {
  const descriptions = {
    'Admin': 'Full system access and user management',
    'Technician': 'Technical operations and maintenance',
    'Operator': 'Day-to-day operations management',
    'Tenant': 'Limited access for tenant users'
  };
  return descriptions[role] || '';
};

// ========== UTILITY FUNCTIONS ==========

/**
 * Generate JWT token with user ID
 * Uses configurable secret and expiration time
 */
const signToken = (userId) =>
  jwt.sign({ sub: String(userId) }, getConfig().jwt.secret, { expiresIn: getConfig().jwt.expiresIn });

/**
 * Filter user object for public consumption
 * Removes sensitive fields (password, tokens, etc.)
 */
const publicUser = (u) => ({
  id: u.id,
  fullName: u.fullName,
  location: u.location,
  contactNumber: u.contactNumber,
  email: u.email,
  role: u.role,
  profileImage: u.profileImage,
  lastLogin: u.lastLogin,
  createdDate: u.createdDate,
  assignedTopics: u.assignedTopics,
  createdAt: u.createdAt,
  updatedAt: u.updatedAt
});