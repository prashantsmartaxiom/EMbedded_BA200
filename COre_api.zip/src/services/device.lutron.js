import { EventEmitter } from 'events';
import net from 'net';
import Device from '../models/Device.js';

// ---- GLOBAL CONNECTION STORE ----
const lutronConnections = new Map(); // device_id => LutronConnection

// ---- CONNECTION STATES ----
const ConnectionState = {
  AWAITING_LOGIN: 1,
  LOGGED_IN: 2,
};

export class LutronConnection extends EventEmitter {
  constructor(host, port) {
    super();

    this.host = host;
    this.port = port;
    this.state = ConnectionState.AWAITING_LOGIN;
    this.connectInterval = null;
    this.socket = new net.Socket();

    this._connect();
    this._setupListeners();
  }

  _connect() {
    try {
      console.log(`Connecting to Lutron at ${this.host}:${this.port}`);
      this.socket.connect({ host: this.host, port: this.port });
    } catch (err) {
      console.log('Initial connection to Lutron failed:', err.message);
    }
  }

  _setupListeners() {
    this.socket.on('connect', () => {
      console.log(`Lutron connected (${this.host}:${this.port})`);
      this.state = ConnectionState.AWAITING_LOGIN;
      clearInterval(this.connectInterval);
      this.connectInterval = null;
    });

    this.socket.on('error', (err) => {
      console.log('Lutron socket error:', err.message);
      this._reconnect();
    });

    this.socket.on('close', () => {
      console.log('Lutron connection closed');
      this._reconnect();
    });

    this.socket.on('data', this._onData.bind(this));
  }

  _reconnect() {
    if (this.connectInterval) {
      console.log('Already attempting to reconnect...');
      return;
    }
    console.log('Attempting to reconnect every 10min...');
    this.connectInterval = setInterval(() => this._connect(), 600000);
  }

  _onData(data) {
    const lines = data.toString().split('\r\n').filter((l) => l !== '');
    for (const line of lines) {
      switch (this.state) {
        case ConnectionState.AWAITING_LOGIN:
          if (/^login:\s*/.test(line)) {
            this.socket.write(`lutron\r\n`);
          } else if (/^password:\s*/.test(line)) {
            this.socket.write(`integration\r\n`);
          } else if (/^GNET>\s*/.test(line)) {
            this.state = ConnectionState.LOGGED_IN;
            console.log('Logged in to Lutron system');
          }
          break;
        case ConnectionState.LOGGED_IN:
          if (line.startsWith('~')) {
            console.log('Lutron Event:', line);
            this.emit('event', line);
          }
          break;
      }
    }
  }

  send(command) {
    if (this.state === ConnectionState.LOGGED_IN) {
      console.log(`Sending: ${command}`);
      this.socket.write(`${command}\r\n`);
    } else {
      console.log(`Command dropped (not logged in): ${command}`);
    }
  }
}

// ---- GLOBAL GETTER/SETTER HELPERS ----
export async function setLutronClient(deviceId, host, port) {
  if (!lutronConnections.has(deviceId)) {
    const client = new LutronConnection(host, port);
    lutronConnections.set(deviceId, client);
    console.log(`Stored Lutron client for device ${deviceId}`);
  }
  return await lutronConnections.get(deviceId);
}

export async function connectAllLutronClients() {
  const devices = await Device.find({ type: 'shade_lutron', is_delete: false });
  for (const device of devices) {
    if (device.Mac_addr) {
      const connectionDetails = device.Mac_addr.split('_');
      const host = connectionDetails[0];
      const port = connectionDetails[1];
      console.log("--connecting to lutron", host, port);
      
      await setLutronClient(device.device_id, host, Number(port));
    }
  }
}

export async function getLutronClient(deviceId) {
  return await lutronConnections.get(deviceId);
}


export const shadeCommands = {
  SHADE1: {
    "SHADE_UP": ["#DEVICE,11,2,4"],
    "SHADE_DOWN": ["#DEVICE,11,4,4"],
    "SHADE_STOP": ["#DEVICE,11,5,4", "#DEVICE,11,6,4"]
  },
  SHADE2: {
    "SHADE_UP": ["#DEVICE,8,2,4"],
    "SHADE_DOWN": ["#DEVICE,8,4,4"],
    "SHADE_STOP": ["#DEVICE,8,5,4", "#DEVICE,8,6,4"]
  },
  SHADE3: {
    "SHADE_UP": ["#DEVICE,5,2,4"],
    "SHADE_DOWN": ["#DEVICE,5,4,4"],
    "SHADE_STOP": ["#DEVICE,5,5,4", "#DEVICE,5,6,4"]
  },
  SHADE4: {
    "SHADE_UP": ["#DEVICE,14,8,4"],
    "SHADE_66": ["#DEVICE,14,9,4"],
    "SHADE_33": ["#DEVICE,14,10,4"],
    "SHADE_DOWN": ["#DEVICE,14,11,4"]
  },
  SHADE5: {
    "SHADE_UP": ["#DEVICE,17,8,4"],
    "SHADE_66": ["#DEVICE,17,9,4"],
    "SHADE_33": ["#DEVICE,17,10,4"],
    "SHADE_DOWN": ["#DEVICE,17,11,4"]
  },
  SHADE6: {
    "SHADE_UP": ["#DEVICE,20,8,4"],
    "SHADE_66": ["#DEVICE,20,9,4"],
    "SHADE_33": ["#DEVICE,20,10,4"],
    "SHADE_DOWN": ["#DEVICE,20,11,4"]
  },
  SHADE7: {
    "SHADE_UP": ["#DEVICE,23,8,4"],
    "SHADE_66": ["#DEVICE,23,9,4"],
    "SHADE_33": ["#DEVICE,23,10,4"],
    "SHADE_DOWN": ["#DEVICE,23,11,4"]
  },
  SHADE8: {
    "SHADE_UP": ["#DEVICE,26,8,4"],
    "SHADE_66": ["#DEVICE,26,9,4"],
    "SHADE_33": ["#DEVICE,26,10,4"],
    "SHADE_DOWN": ["#DEVICE,26,11,4"]
  },
}