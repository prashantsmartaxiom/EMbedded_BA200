import Log from '../models/Log.js';
import { socketManager } from '../utils/socketManager.js';

/**
 * Add a log entry to the logs collection
 * @param {Object} logData - The log data to save
 * @param {string} logData.action - The action performed (e.g., 'Executed')
 * @param {string} logData.name - The name/description (e.g., 'Conference Room 402 LED On')
 * @param {number} logData.timestamp - The timestamp (UNIX epoch seconds)
 * @param {string} logData.type - The type (e.g., 'Scene')
 * @param {string} logData.userId - The user ID (string or '-')
 * @param {string} logData.userName - The user name (string or '-')
 * @returns {Promise<Object>} The created log document
 */
export async function addLog(logData, hideToaster) {
  const log = new Log(logData);
  let message = '';
  switch (logData.type) {
    case 'User':
      if (logData.userId && logData.userName && logData.userId !== '-' && logData.userName !== '-') {
        message = `${logData.action} on ${logData.name} by ${logData.userName}`;
      } else {
        message = `${logData.name} ${logData.action}`;
      }
      break;
    case 'Device':
      if (logData.action === 'Discovered')
        message = undefined;
      else if (logData.channelId)
        message = `${logData.action} on ${logData.deviceName}'s ${logData.name}(${logData.channelId}) by ${logData.userName}`
      else if (logData.userName && logData.userName !== '-')
        message = `${logData.action}  on ${logData.type}-${logData.name} by ${logData.userName}`
      else
        message = `${logData.action}  on ${logData.type}-${logData.name} by ${logData.userName}`
      break;
    case 'Sensor':
      message = undefined;
      break;
    case 'Group': case 'Scene':
      message = `${logData.action} on ${logData.name} by ${logData.userName}`;
      break;
    default:
      message = `${logData.action} on ${logData.type}-${logData.name} by ${logData.userName}`;
  }
  socketManager.emitEvent("logAdded",  {...logData,"hideToaster": hideToaster,message} );
  return await log.save();
}
