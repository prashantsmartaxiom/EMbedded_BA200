import { Group } from '../models/Group.js';
import Device from '../models/Device.js';
import mongoose from 'mongoose';
import { Template } from '../models/Template.js';
import { Scene } from '../models/Scene.js';
import { socketManager } from '../utils/socketManager.js';

/**
 * Group Service - Device group management with complex channel control
 * 
 * Handles logical grouping of devices with channel-level installation tracking
 * Manages permissions, location-based filtering, and cascade operations
 * Coordinates with scenes, templates, and sensor configurations
 */

/**
 * Create a group and mark specified channels as installed=true on each device.
 * Cleanly rolls back the group and device changes if anything fails.
 */
export const createGroup = async (groupData, user) => {
  if (
    !groupData ||
    typeof groupData.name !== 'string' ||
    !Array.isArray(groupData.devices)
  ) {
    throw new Error('Invalid groupData');
  }

  // Validate device entries (shape only; no DB reads/updates)
  for (const d of groupData.devices) {
    if (!d?.deviceId || typeof d.deviceId !== 'string') {
      throw new Error('Each device requires a valid deviceId');
    }
    if (!Array.isArray(d.channels)) {
      throw new Error('Channels must be an array');
    }
    for (const ch of d.channels) {
      if (!ch?.channelId || typeof ch.channelId !== 'string') {
        throw new Error('Each channel requires a valid channelId');
      }
      if (!ch?.channelType || typeof ch.channelType !== 'string') {
        throw new Error('Each channel requires a valid channelType');
      }
    }
  }

  const name = groupData.name.trim();
  const devices = groupData.devices;

  // -------- De-dupe by name (only check non-deleted groups) --------
  const existingGroup = await Group.findOne({ name, isDeleted: { $ne: true } });
  if (existingGroup) {
    throw new Error('A group with this name already exists');
  }

  // -------- Create group (no Device collection mutations) --------
  let group;
  try {
    group = new Group({
      name,
      devices,
      createdBy: user
        ? { userId: user._id, fullName: user.fullName, email: user.email }
        : undefined,
      updatedBy: user
        ? { userId: user._id, fullName: user.fullName, email: user.email }
        : undefined,
    });

    await group.save();
    socketManager.emitEvent("group", {uiType: ""});

    // (Optional) populate creator info like addCampus did
    if (user?._id) {
      await group.populate('createdBy.userId', 'fullName email');
    }

    // --- Add group._id to allowedResources for specific roles with different permissions ---
    // Always update permissions regardless of the creating user's allowedResources
    try {
      const { default: Role } = await import('../models/Role.js');
      const { User } = await import('../models/User.js');
      
      // Define role-based permissions
      const rolePermissions = {
        'admin': { intelligentControl: true, controlSection: true },
        'technician': { intelligentControl: true, controlSection: true },
        'operator': { intelligentControl: false, controlSection: true }
        // superadmin is intentionally excluded - they should always have allowedResources: null
      };
      
      const targetRoleNames = Object.keys(rolePermissions);
      
      // Find all roles with names matching admin, technician, operator (case insensitive)
      const roles = await Role.find({ 
        roleName: { 
          $in: targetRoleNames.map(name => new RegExp(`^${name}$`, 'i')) 
        },
        isDelete: { $ne: true },
        isActive: true
      });
      
      console.log(`Found ${roles.length} matching roles:`, roles.map(r => r.roleName));
      
      if (roles.length > 0) {
        const roleIds = roles.map(r => r._id);
        
        // Get users with target roles who have allowedResources (not null)
        // Superadmin users should always have allowedResources: null, so they won't be included
        const users = await User.find({ 
          role_id: { $in: roleIds },
          allowedResources: { $ne: null },
          isDeleted: { $ne: true },
          isActive: true
        }).populate('role_id', 'roleName');
        
        console.log(`Found ${users.length} users with target roles and allowedResources to update`);
        
        for (const u of users) {
          const userRole = u.role_id?.roleName?.toLowerCase();
          const permissions = rolePermissions[userRole];
          
          if (!permissions) {
            console.log(`Skipping user ${u.email} - role ${userRole} not in target permissions`);
            continue;
          }
          
          // Initialize allowedResources structure if needed
          if (!u.allowedResources) {
            u.allowedResources = { 
              intelligentControl: { groups: [] }, 
              controlSection: { groupTab: [] } 
            };
          }
          
          // Handle intelligentControl.groups (for admin and technician only)
          if (permissions.intelligentControl) {
            if (!u.allowedResources.intelligentControl) {
              u.allowedResources.intelligentControl = { groups: [] };
            }
            if (!Array.isArray(u.allowedResources.intelligentControl.groups)) {
              u.allowedResources.intelligentControl.groups = [];
            }
            
            // Add to intelligentControl.groups if not already present
            if (!u.allowedResources.intelligentControl.groups.includes(group._id.toString())) {
              u.allowedResources.intelligentControl.groups.push(group._id.toString());
              console.log(`Added group ${group._id} to intelligentControl.groups for ${u.email} (${userRole})`);
            }
          }
          
          // Handle controlSection.groupTab (for admin, technician, and operator)
          if (permissions.controlSection) {
            if (!u.allowedResources.controlSection) {
              u.allowedResources.controlSection = { groupTab: [] };
            }
            if (!Array.isArray(u.allowedResources.controlSection.groupTab)) {
              u.allowedResources.controlSection.groupTab = [];
            }
            
            // Add to controlSection.groupTab if not already present
            if (!u.allowedResources.controlSection.groupTab.includes(group._id.toString())) {
              u.allowedResources.controlSection.groupTab.push(group._id.toString());
              console.log(`Added group ${group._id} to controlSection.groupTab for ${u.email} (${userRole})`);
            }
          }
          
          await u.save();
          console.log(`Updated user ${u.email} (${userRole}) with new group permissions`);
        }
        
        console.log(`Successfully updated ${users.length} users with new group access`);
      } else {
        console.log('No matching roles found for automatic group access assignment');
      }
    } catch (userUpdateError) {
      console.error('Error updating users with new group access:', userUpdateError);
      // Don't throw the error here - we still want to return the created group
      // The group was created successfully, user updates are a bonus feature
    }

    return group;
  } catch (err) {
    // If creation partially succeeded and you want to ensure no leftover doc:
    if (group?._id) {
      try {
        await Group.findByIdAndDelete(group._id);
      } catch (_) {
        // log if needed, but don't mask the original error
      }
    }
    throw err;
  }
};


// Get paginated group list with filtering, search, and zone-based access control
export const getGroupList = async (params = {}) => {
  const {
    filter = {},
    search = '',
    page = 1,
    limit = 10,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    user = null
  } = params;

  const query = {
    isDeleted: { $ne: true } // Exclude deleted groups
  };

  // Filter by group name
  if (filter.group_name) {
    query.name = { $regex: filter.group_name, $options: 'i' };
  }

  // Filter by device_id
  if (filter.device_id) {
    query['devices.deviceId'] = filter.device_id;
  }

  // Search by group name or device name
  if (search) {
    query.$or = [
      { name: { $regex: search, $options: 'i' } },
      { 'devices.deviceId': { $regex: search, $options: 'i' } }
    ];
  }

  const skip = (page - 1) * limit;
      // Filter by allowedGroupIds if provided (skip for superadmin)
  if (params.allowedGroupIds && Array.isArray(params.allowedGroupIds) && user?.role_id?.roleName?.toLowerCase() !== 'superadmin') {
    if (params.allowedGroupIds.length > 0) {
      query._id = { $in: params.allowedGroupIds.map(id => new mongoose.Types.ObjectId(id)) };
    } else {
      // Empty array means no groups allowed - return no results
      query._id = { $in: [] };
    }
  }

  // Build sort object; add stable secondary sort by createdAt desc when sorting by name
  const sort = {};
  if (sortBy === 'name') {
    sort.name = sortOrder === 'desc' ? -1 : 1;
    // secondary sort for stability
    sort.createdAt = -1;
  } else if (sortBy === 'createdAt') {
    sort.createdAt = sortOrder === 'asc' ? 1 : -1;
  } else {
    // fallback to createdAt desc
    sort.createdAt = -1;
  }

  // Apply zone-based filtering first to get accurate total count
  let zoneFilterQuery = { ...query };
  if (user && user.campusData && Array.isArray(user.campusData) && user.campusData.length > 0) {
    // Extract zone IDs from user's campus data
    const zoneIds = [];
    user.campusData.forEach(campus => {
      if (campus.buildings && Array.isArray(campus.buildings)) {
        campus.buildings.forEach(building => {
          if (building.floors && Array.isArray(building.floors)) {
            building.floors.forEach(floor => {
              if (floor.zones && Array.isArray(floor.zones)) {
                floor.zones.forEach(zone => {
                  if (zone.zone_id) {
                    zoneIds.push(zone.zone_id);
                  }
                });
              }
            });
          }
        });
      }
    });

    if (zoneIds.length > 0) {
      // Get all groups first to apply zone filtering
      const allGroups = await Group.find(query, { _id: 1, name: 1, devices: 1 }).lean();
      
      // Get all device IDs from the groups
      const allDeviceIds = [...new Set(
        allGroups.flatMap(group => 
          Array.isArray(group.devices) ? group.devices.map(d => d.deviceId) : []
        )
      )];

      if (allDeviceIds.length > 0) {
        // Find devices that are in allowed zones
        const allowedDevices = await Device.find({
          device_id: { $in: allDeviceIds },
          zone: { $in: zoneIds },
          deletedAt: null
        }, { device_id: 1 }).lean();

        const allowedDeviceIds = new Set(allowedDevices.map(d => d.device_id));

        // Filter groups to only include those that have at least one device in allowed zones
        const allowedGroupIds = allGroups
          .filter(group => {
            const groupDeviceIds = Array.isArray(group.devices) ? group.devices.map(d => d.deviceId) : [];
            return groupDeviceIds.some(deviceId => allowedDeviceIds.has(deviceId));
          })
          .map(group => group._id);
        
        if (allowedGroupIds.length === 0) {
          return {
            data: [],
            total: 0,
            page,
            limit
          };
        }
        
        // Update query to only include zone-filtered groups
        zoneFilterQuery._id = { 
          $in: allowedGroupIds,
          ...(zoneFilterQuery._id ? { $in: zoneFilterQuery._id.$in.filter(id => allowedGroupIds.some(aid => aid.toString() === id.toString())) } : {})
        };
      } else {
        // No devices in any group, return empty
        return {
          data: [],
          total: 0,
          page,
          limit
        };
      }
    } else {
      // No zones in user's campus data, return empty
      return {
        data: [],
        total: 0,
        page,
        limit
      };
    }
  }

  // Now get the final filtered groups with pagination
  const groups = await Group.find(zoneFilterQuery, { _id: 1, name: 1, devices: 1 })
    .sort(sort)
    .skip(skip)
    .limit(limit)
    .lean();

  const total = await Group.countDocuments(zoneFilterQuery);

  const filteredGroups = groups;

  const result = filteredGroups.map(g => ({
    id: g._id,
    group_name: g.name,
    device_ids: Array.isArray(g.devices) ? g.devices.map(d => d.deviceId) : [],
    channelList: Array.isArray(g.devices)
      ? g.devices.flatMap(d => Array.isArray(d.channels) ? d.channels.map(ch => ch.channelId) : [])
      : []
  }));

  return {
    data: result,
    total,
    page,
    limit
  };
};

// Get all groups without pagination - supports filtering and search with zone access control
export const getGroupListNoPagination = async (params = {}) => {
  const {
    filter = {},
    search = '',
    sortBy = 'createdAt',
    sortOrder = 'desc',
    user = null
  } = params;

  const query = {
    isDeleted: { $ne: true } // Exclude deleted groups
  };

  // Filter by group name
  if (filter.group_name) {
    query.name = { $regex: filter.group_name, $options: 'i' };
  }

  // Filter by device_id
  if (filter.device_id) {
    query['devices.deviceId'] = filter.device_id;
  }

  // Search by group name or device name
  if (search) {
    query.$or = [
      { name: { $regex: search, $options: 'i' } },
      { 'devices.deviceId': { $regex: search, $options: 'i' } }
    ];
  }

  // Build sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  const groups = await Group.find(query, { _id: 1, name: 1, devices: 1 })
    .sort(sort)
    .lean();

  // Apply zone-based filtering if user has campus data
  let filteredGroups = groups;
  if (user && user.campusData && Array.isArray(user.campusData)) {
    // If campusData is empty array, show all data (no filtering)
    if (user.campusData.length === 0) {
      filteredGroups = groups;
    } else {
    // Extract zone IDs from user's campus data
    const zoneIds = [];
    user.campusData.forEach(campus => {
      if (campus.buildings && Array.isArray(campus.buildings)) {
        campus.buildings.forEach(building => {
          if (building.floors && Array.isArray(building.floors)) {
            building.floors.forEach(floor => {
              if (floor.zones && Array.isArray(floor.zones)) {
                floor.zones.forEach(zone => {
                  if (zone.zone_id) {
                    zoneIds.push(zone.zone_id);
                  }
                });
              }
            });
          }
        });
      }
    });

    if (zoneIds.length > 0) {
      // Get all device IDs from the groups
      const allDeviceIds = [...new Set(
        groups.flatMap(group => 
          Array.isArray(group.devices) ? group.devices.map(d => d.deviceId) : []
        )
      )];

      if (allDeviceIds.length > 0) {
        // Find devices that are in allowed zones
        const allowedDevices = await Device.find({
          device_id: { $in: allDeviceIds },
          zone: { $in: zoneIds },
          deletedAt: null
        }, { device_id: 1 }).lean();

        const allowedDeviceIds = new Set(allowedDevices.map(d => d.device_id));

        // Filter groups to only include those that have at least one device in allowed zones
        filteredGroups = groups.filter(group => {
          const groupDeviceIds = Array.isArray(group.devices) ? group.devices.map(d => d.deviceId) : [];
          return groupDeviceIds.some(deviceId => allowedDeviceIds.has(deviceId));
        });
      } else {
        // No devices in any group, return empty
        filteredGroups = [];
      }
      } else {
        // No zones in user's campus data, return empty
        filteredGroups = [];
      }
    }
  }

  const result = filteredGroups.map(g => ({
    id: g._id,
    group_name: g.name,
    device_ids: Array.isArray(g.devices) ? g.devices.map(d => d.deviceId) : [],
    channelList: Array.isArray(g.devices)
      ? g.devices.flatMap(d => Array.isArray(d.channels) ? d.channels.map(ch => ch.channelId) : [])
      : []
  }));

  return {
    data: result,
    total: result.length
  };
};


/**
 * Get list of devices with status: Active, filtered by user's zone access and device type
 * @param {Object} user - User object containing campusData for zone filtering
 * @param {Object} filters - Query filters { normal, bms }
 */
// Get devices for grouping - filters by type (normal/BMS/all) and zone access permissions
export const getActiveDevices = async (user = null, filters = {}) => {
  let baseQuery = { is_delete: { $ne: true } };
  
  // Add filtering based on query parameters
  if (filters.normal !== undefined) {
    // For normal: show all devices (to be configured, active, inactive) but exclude configured BMS devices
    baseQuery.$or = [
      // All non-BMS devices (configured, active, inactive)
      { type: { $not: /^shade_lutron$/i } },
      // BMS devices that are not configured (to be configured)
      { 
        type: /^shade_lutron$/i, 
        $and: [
          { configure_flag: { $ne: true } },
          { configure_flag: { $ne: 1 } }
        ]
      }
    ];
  } else if (filters.bms !== undefined) {
    // Show devices having type: shade_lutron (case insensitive)
    baseQuery.type = /^shade_lutron$/i;
    baseQuery.status = 'Active';
    baseQuery.$or = [
      { configure_flag: true },
      { configure_flag: 1 }
    ];
  } else {
    // Default behavior: only active configured devices
    baseQuery.status = 'Active';
    baseQuery.$or = [
      { configure_flag: true },
      { configure_flag: 1 }
    ];
  }
  
  // If user is provided, filter by zones from user's campusData
  if (user && user.campusData && Array.isArray(user.campusData)) {
    // If campusData is empty, show all data
    if (user.campusData.length === 0) {
      // No additional filtering needed - show all active devices
    } else {
      // Extract zone IDs from user's campusData
      const zoneIds = [];
      user.campusData.forEach(campus => {
        campus.buildings?.forEach(building => {
          building.floors?.forEach(floor => {
            floor.zones?.forEach(zone => {
              if (zone.zone_id) {
                zoneIds.push(zone.zone_id);
              }
            });
          });
        });
      });
      
      // Add zone filter if user has specific zones in campusData
      if (zoneIds.length > 0) {
        const zoneObjectIds = zoneIds
          .map((id) => {
            try { return new mongoose.Types.ObjectId(id); } catch { return null; }
          })
          .filter(Boolean);
        if (zoneObjectIds.length > 0) {
          baseQuery.zone = { $in: zoneObjectIds };
        }
      }
    }
  }
  // If user has no campusData or is admin (allowedResources null), show all active devices
  
  const devices = await Device.find(baseQuery, { device_id: 1, name: 1, status: 1, type: 1 }).sort({ createdAt: -1 }).lean();
  return devices;
};

// Get installed channels for specific devices with location info - maintains input order
export const getDeviceChannels = async ({ deviceIds = [], user = null }) => {
  const ids = [...new Set(deviceIds.map(String).filter(Boolean))];
  if (ids.length === 0) return [];

  // Build device query with zone filtering
  let deviceQuery = {
    device_id: { $in: ids },
    deletedAt: null
  };

  // Add zone filtering if user has campusData
  if (user && user.campusData && Array.isArray(user.campusData)) {
    // If campusData is empty, show all data
    if (user.campusData.length === 0) {
      // No additional filtering needed - show all devices
    } else {
      const zoneIds = [];
      user.campusData.forEach(campus => {
        campus.buildings?.forEach(building => {
          building.floors?.forEach(floor => {
            floor.zones?.forEach(zone => {
              if (zone.zone_id) {
                zoneIds.push(zone.zone_id);
              }
            });
          });
        });
      });
      
      if (zoneIds.length > 0) {
        const zoneObjectIds = zoneIds
          .map((id) => {
            try { return new mongoose.Types.ObjectId(id); } catch { return null; }
          })
          .filter(Boolean);
        if (zoneObjectIds.length > 0) {
          deviceQuery.zone = { $in: zoneObjectIds };
        }
      }
    }
  }

  // Fetch devices with populated location information
  const devices = await Device.find(deviceQuery)
    .populate('campus', 'name')
    .populate('building', 'name')
    .populate('floor', 'name number')
    .populate('zone', 'name')
    .lean();

  const deviceMap = new Map(devices.map(d => [String(d.device_id), d]));

  return ids.map(id => {
    const device = deviceMap.get(id);
    if (!device) {
      return {
        device_id: id,
        location: {
          campus: { name: 'N/A' },
          building: { name: 'N/A' },
          floor: { name: 'N/A', number: null },
          zone: { name: 'N/A' }
        },
        channels: []
      };
    }

    // Filter capabilities to only include installed channels
    const channels = (device.capabilities || [])
      .filter(cap => cap.properties?.installed === true || cap.installed === true)
      .map(c => ({
        type: c.type,
        channelId: String(c.channelId),
        name: c.name,
        status: c.status,
        properties: c.properties
      }));

    return {
      device_id: id,
      location: {
        campus: {
          name: device.campus?.name || 'N/A'
        },
        building: {
          name: device.building?.name || 'N/A'
        },
        floor: {
          name: device.floor?.name || 'N/A',
          number: device.floor?.number || null
        },
        zone: {
          name: device.zone?.name || 'N/A'
        }
      },
      channels
    };
  });
};


// Update group name and device assignments - syncs changes to templates and scenes
export const updateGroup = async ({ groupId, name, devices = [], user }) => {
  // 1) Load existing group
  const group = await Group.findById(groupId);
  if (!group) throw new Error('Group not found');

  // 2) (Optional) rename, ensuring uniqueness
  if (typeof name === 'string' && name.trim()) {
    const trimmed = name.trim();
    const dupe = await Group.findOne({ _id: { $ne: groupId }, name: trimmed, isDeleted: false });
    if (dupe) throw new Error('Another group with this name already exists');
    group.name = trimmed;
  }

  // 3) Process devices array if provided
  const nextDevices = [];
  if (Array.isArray(devices) && devices.length > 0) {
    for (const d of devices) {
      if (!d?.deviceId) continue;

      const processedChannels = [];
      for (const ch of Array.isArray(d.channels) ? d.channels : []) {
        if (!ch?.channelId || !ch?.channelType) continue;

        // Include the channel if:
        // - No checked/installed flags are provided (assume it should be included)
        // - checked flag is true
        // - installed flag is true
        const shouldInclude = (ch.checked === undefined && ch.installed === undefined) || 
                            ch.checked === true || 
                            ch.installed === true;

        if (shouldInclude) {
          processedChannels.push({
            channelId: ch.channelId,
            channelType: ch.channelType
          });
        }
      }

      if (processedChannels.length > 0) {
        nextDevices.push({ 
          deviceId: d.deviceId, 
          channels: processedChannels 
        });
      }
    }
  }

  // 4) Compute diff stats and track changes for template updates
  const key = (devId, type, chId) => `${devId}::${type}::${chId}`;
  const prevSet = new Set(
    (group.devices || []).flatMap(d =>
      (d.channels || []).map(ch => key(d.deviceId, ch.channelType, ch.channelId))
    )
  );
  const nextSet = new Set(
    nextDevices.flatMap(d =>
      d.channels.map(ch => key(d.deviceId, ch.channelType, ch.channelId))
    )
  );
  
  const addedChannels = [];
  const removedChannels = [];
  
  for (const k of nextSet) {
    if (!prevSet.has(k)) {
      const [deviceId, channelType, channelId] = k.split('::');
      addedChannels.push({ deviceId, channelId, channelType });
    }
  }
  
  for (const k of prevSet) {
    if (!nextSet.has(k)) {
      const [deviceId, channelType, channelId] = k.split('::');
      removedChannels.push({ deviceId, channelId, channelType });
    }
  }

  let channelsAdded = addedChannels.length;
  let channelsRemoved = removedChannels.length;

  // 5) Update the group with processed devices
  group.devices = nextDevices;
  
  // Add updatedBy information if user is provided
  if (user) {
    group.updatedBy = {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    };
  }
  
  await group.save();
  socketManager.emitEvent("group", {uiType: ""});

  // 6) Update templates that reference this group (only when channels are added or removed)
  if (channelsAdded > 0 || channelsRemoved > 0) {
    try {
      const { Template } = await import('../models/Template.js');
      
      // Get device capabilities for creating new elements (only if channels were added)
      const deviceCapabilities = new Map();
      if (addedChannels.length > 0) {
        const allDeviceIds = [...new Set(addedChannels.map(ch => ch.deviceId))];
        const deviceDocs = await Device.find({ 
          device_id: { $in: allDeviceIds } 
        }).lean();
        
        for (const deviceDoc of deviceDocs) {
          const capMap = new Map();
          (deviceDoc.capabilities || []).forEach(cap => {
            capMap.set(cap.channelId, cap);
          });
          deviceCapabilities.set(deviceDoc.device_id, capMap);
        }
      }
      
      // Find templates that have group columns referencing this specific group
      const templates = await Template.find({}).lean();
      
      for (const template of templates) {
        let templateUpdated = false;
        const layoutStructure = template.layoutStructure || {};
        
        if (layoutStructure.rows && Array.isArray(layoutStructure.rows)) {
          for (const row of layoutStructure.rows) {
            if (!row.columns || !Array.isArray(row.columns)) continue;
            
            for (const col of row.columns) {
              // Only update group columns that reference this specific group
              const isTargetGroupColumn = col.type === 'group' && 
                (col.id === groupId || 
                 col.id === String(groupId) || 
                 String(col.id) === String(groupId) ||
                 col.group_name === group.name);
              
              if (isTargetGroupColumn && col.elements && Array.isArray(col.elements)) {
                // Remove elements with removed channels from this group
                const originalLength = col.elements.length;
                col.elements = col.elements.filter(el => {
                  if (!el.deviceId || !el.channelId) return true;
                  
                  const isRemovedFromThisGroup = removedChannels.some(rc => 
                    rc.deviceId === el.deviceId && rc.channelId === el.channelId
                  );
                  
                  return !isRemovedFromThisGroup;
                });
                
                if (col.elements.length !== originalLength) {
                  templateUpdated = true;
                }
                
                // Add elements for channels newly added to this group
                for (const addedChannel of addedChannels) {
                  const deviceCaps = deviceCapabilities.get(addedChannel.deviceId);
                  if (!deviceCaps) continue;
                  
                  const capability = deviceCaps.get(addedChannel.channelId);
                  if (!capability) continue;
                  
                  // Check if element already exists in this group column
                  const existingElement = col.elements.find(el => 
                    el.deviceId === addedChannel.deviceId && 
                    el.channelId === addedChannel.channelId
                  );
                  
                  if (!existingElement) {
                    const newElement = {
                      id: capability.channelId,
                      name: capability.name || 'Unknown Channel',
                      deviceId: addedChannel.deviceId,
                      type: capability.type || addedChannel.channelType,
                      channelId: capability.channelId,
                      status: capability.status || 'off',
                      properties: capability.properties || {},
                      capabilityId: capability._id
                    };
                    
                    col.elements.push(newElement);
                    templateUpdated = true;
                  }
                }
              }
              // Note: We're removing the individual device element updates since 
              // we only want to update group columns when group channels change
            }
          }
        }
        
        // Update the template if it was modified
        if (templateUpdated) {
          await Template.findByIdAndUpdate(
            template._id,
            { 
              layoutStructure,
              updatedAt: new Date()
            },
            { new: true }
          );
        }
      }
    } catch (templateUpdateError) {
      console.error('Error updating group templates after channel changes:', templateUpdateError);
      // Don't throw the error - the group update should succeed even if template updates fail
    }
  }

  // 7) Return
  return {
    group: {
      _id: group._id,
      name: group.name,
      devices: group.devices
    },
    // keep a familiar field if your UI expects it
    channelsUpdated: channelsAdded + channelsRemoved,
    summary: { 
      channelsAdded, 
      channelsRemoved, 
      totalDevices: group.devices.length,
      templatesChecked: true
    }
  };
};



// Soft delete group and cascade cleanup from scenes, templates, and sensor configurations
export const deleteGroup = async (groupId, user) => {
  const group = await Group.findById(groupId);
  if (!group) throw new Error('Group not found');
  if (group.isDeleted) throw new Error('Group already deleted');

  group.isDeleted = true;
  if (user) {
    group.updatedBy = {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    };
  }
  socketManager.emitEvent("group", {uiType: ""});
  await group.save();

  // 1) Remove this group's references from all Scenes (pull from Groups array)
  try {
    await Scene.updateMany(
      { 'Groups.groupId': groupId },
      { $pull: { Groups: { groupId } } }
    );

    // After pulling the group, soft-delete any scenes that are now empty
    const sceneDeleteFilter = {
      isDeleted: { $ne: true },
      $or: [
        {
          type: 'group',
          $or: [
            { Groups: { $exists: false } },
            { Groups: { $size: 0 } }
          ]
        },
        {
          type: 'device',
          $or: [
            { Devices: { $exists: false } },
            { Devices: { $size: 0 } }
          ]
        }
      ]
    };

    // Find impacted scenes so we can also clean them from templates
    const scenesToDelete = await Scene.find(sceneDeleteFilter, { _id: 1 }).lean();

    const softDeleteUpdate = {
      $set: {
        isDeleted: true,
        deletedAt: new Date(),
        ...(user ? {
          deletedBy: {
            userId: user._id,
            fullName: user.fullName,
            email: user.email
          },
          updatedBy: {
            userId: user._id,
            fullName: user.fullName,
            email: user.email
          }
        } : {})
      }
    };

    await Scene.updateMany(sceneDeleteFilter, softDeleteUpdate);

    // If any scenes were deleted, remove their references from all templates
    if (Array.isArray(scenesToDelete) && scenesToDelete.length > 0) {
      const deletedSceneIdSet = new Set(scenesToDelete.map(s => String(s._id)));

      const templates = await Template.find({}).lean();
      for (const tpl of templates) {
        let updated = false;
        const layout = tpl.layoutStructure || {};

        if (Array.isArray(layout.rows)) {
          for (const row of layout.rows) {
            if (Array.isArray(row.columns)) {
              // 1) Remove scene-type columns whose id matches a deleted scene
              const originalColumnsLen = row.columns.length;
              row.columns = row.columns.filter(col => {
                if (col?.type === 'scene') {
                  const colId = col?.id != null ? String(col.id) : null;
                  if (colId && deletedSceneIdSet.has(colId)) return false;
                }
                return true;
              });
              if (row.columns.length !== originalColumnsLen) updated = true;

              // 2) For remaining columns, scrub elements that reference deleted scenes
              for (const col of row.columns) {
                if (!Array.isArray(col.elements)) continue;

                const originalElementsLen = col.elements.length;
                col.elements = col.elements.filter(el => {
                  const sceneId = el?.sceneId != null ? String(el.sceneId) : null;
                  const elIsSceneType = el?.type === 'scene';
                  const elId = elIsSceneType && el?.id != null ? String(el.id) : null;
                  if (sceneId && deletedSceneIdSet.has(sceneId)) return false;
                  if (elIsSceneType && elId && deletedSceneIdSet.has(elId)) return false;
                  return true;
                });
                if (col.elements.length !== originalElementsLen) updated = true;
              }
            }
          }
        }

        if (updated) {
          await Template.updateOne(
            { _id: tpl._id },
            { $set: { layoutStructure: layout } }
          );
        }
      }
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error(`Failed to remove group ${groupId} from Scenes:`, err);
  }

  // 2) Update sensor scenes that reference deleted groups - set motionScene and NoMotionScene to null
  await updateSensorScenesForDeletedGroup(groupId, user);

  // 3) Remove this group's references from all Templates
  //    We remove any column with type==='group' and id/group_name referencing this group
  try {
    const templates = await Template.find({}).lean();
    const groupIdStr = String(groupId);
    const groupName = group.name;

    for (const tpl of templates) {
      let updated = false;
      const layout = tpl.layoutStructure || {};

      if (Array.isArray(layout.rows)) {
        for (const row of layout.rows) {
          if (Array.isArray(row.columns)) {
            const originalLength = row.columns.length;
            row.columns = row.columns.filter(col => {
              if (col?.type !== 'group') return true;
              const colId = col?.id != null ? String(col.id) : null;
              const matchesId = colId && (colId === groupIdStr);
              const matchesName = col?.group_name && groupName && (col.group_name === groupName);
              // Drop the column if it references this group by id or name
              return !(matchesId || matchesName);
            });
            if (row.columns.length !== originalLength) updated = true;
          }
        }
      }

      if (updated) {
        await Template.updateOne(
          { _id: tpl._id },
          { $set: { layoutStructure: layout } }
        );
      }
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error(`Failed to remove group ${groupId} references from Templates:`, err);
  }

  return { _id: group._id, name: group.name, isDeleted: group.isDeleted };
};


// Get simple list of all active groups - used for dropdowns and basic selections
export const getAllGroupsNoPagination = async (params = {}) => {
  const {
    search = '',
    sortBy = 'name',
    sortOrder = 'asc'
  } = params;

  // Build the filter for non-deleted groups
  const filter = {
    isDeleted: { $ne: true }
  };

  // Add search functionality if search term is provided
  if (search && search.trim()) {
    filter.name = { $regex: search.trim(), $options: 'i' };
  }

  // Build sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // Fetch groups with only _id and name
  const groups = await Group.find(filter)
    .select('_id name')
    .sort(sort)
    .lean();

  return {
    data: groups,
    total: groups.length
  };
};



// Get comprehensive group data with device details, channels, and location hierarchy
export const getAllGroupsWithDeviceDetails = async (params = {}) => {
  try {
    const { search = '', filters = {}, page = 1, limit = 50, user } = params;
    
    // Build query for groups
    const groupQuery = { isDeleted: { $ne: true } };
    
    // Add search by group name
    if (search && search.trim()) {
      groupQuery.name = { $regex: search.trim(), $options: 'i' };
    }

    // Calculate pagination values
    const skip = (page - 1) * limit;
    
    // Get total count for pagination
    const totalGroups = await Group.countDocuments(groupQuery);

    // Get allowed group IDs from the authenticated user's permissions
    const allowedGroupIds = new Set();
    if (user && user.allowedResources && user.allowedResources.controlSection && user.allowedResources.controlSection.groupTab) {
      const groupTab = user.allowedResources.controlSection.groupTab;
      if (Array.isArray(groupTab)) {
        groupTab.forEach(id => allowedGroupIds.add(id));
      }
    }
    
    console.log(`User ${user?._id} has access to ${allowedGroupIds.size} groups.`);

    // Find non-deleted groups with pagination and sorting by latest first (createdAt descending)
    let groups = await Group.find(groupQuery)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .lean();

    // Filter groups: only those whose _id exists in allowedGroupIds
    groups = groups.filter(g => allowedGroupIds.has(String(g._id)));

    if (groups.length === 0) {
      return {
        data: [],
        pagination: {
          current_page: page,
          total_pages: 0,
          total_groups: totalGroups,
          groups_per_page: limit,
          has_next_page: false,
          has_prev_page: false
        },
        summary: {
          total_groups: totalGroups,
          current_page_groups: 0,
          total_devices: 0,
          total_channels: 0
        },
        filters_applied: {
          search: search || null,
          campus: filters.campus || null,
          building: filters.building || null,
          floor: filters.floor || null,
          zone: filters.zone || null
        }
      };
    }

    // Extract all unique device IDs from all groups
    const allDeviceIds = [...new Set(
      groups.flatMap(group => 
        group.devices?.map(d => d.deviceId) || []
      )
    )];

    // Build device query with location filters
    const deviceQuery = {
      device_id: { $in: allDeviceIds },
      deletedAt: null
    };

    // Add zone filtering based on user's campus data
    if (user && user.campusData && Array.isArray(user.campusData)) {
      // If campusData is empty, show all data (no zone filtering)
      if (user.campusData.length === 0) {
        // No zone filtering - show all devices
      } else {
        const zoneIds = [];
        user.campusData.forEach(campus => {
          if (campus.buildings && Array.isArray(campus.buildings)) {
            campus.buildings.forEach(building => {
              if (building.floors && Array.isArray(building.floors)) {
                building.floors.forEach(floor => {
                  if (floor.zones && Array.isArray(floor.zones)) {
                    floor.zones.forEach(zone => {
                      if (zone.zone_id) {
                        zoneIds.push(zone.zone_id);
                      }
                    });
                  }
                });
              }
            });
          }
        });
        
        if (zoneIds.length > 0) {
          deviceQuery.zone = { $in: zoneIds };
        } else {
          // If no zones found in user's campus data, return empty result
          deviceQuery.zone = { $in: [] };
        }
      }
    }

    // Add location filters if provided (these will override zone filtering from user's campus data)
    if (filters.campus) {
      deviceQuery.campus = filters.campus;
    }
    if (filters.building) {
      deviceQuery.building = filters.building;
    }
    if (filters.floor) {
      deviceQuery.floor = filters.floor;
    }
    if (filters.zone) {
      deviceQuery.zone = filters.zone;
    }

    // Fetch all devices with populated location information
    const devices = await Device.find(deviceQuery)
      .populate('campus', 'name code description')
      .populate('building', 'name code description')
      .populate('floor', 'name number description')
      .populate('zone', 'name code description')
      .lean();

    // Create a map of devices for easy lookup
    const deviceMap = new Map(devices.map(d => [d.device_id, d]));

    // Process each group and filter out groups with no matching devices
    const processedGroups = [];
    let totalDevicesCount = 0;
    let totalChannelsCount = 0;

    for (const group of groups) {
      const groupDevices = [];
      let groupChannelsCount = 0;

      for (const groupDevice of group.devices || []) {
        const device = deviceMap.get(groupDevice.deviceId);
        
        if (!device) {
          // Device not found, deleted, or doesn't match location filters
          continue;
        }

        // Get group channels for this device
        const groupChannelIds = new Set(groupDevice.channels?.map(ch => ch.channelId) || []);
        
        // Show all installed channels of the device (not just group channels)
        const deviceChannels = (device.capabilities || [])
          .filter(cap => cap.properties?.installed === true || cap.installed === true)
          .map(cap => ({
            channel_id: cap.channelId,
            channel_name: cap.name,
            channel_type: cap.type,
            status: cap.status,
            is_active: cap.properties?.installed === true || cap.installed === true,
            is_in_group: groupChannelIds.has(cap.channelId),
            properties: cap.properties
          }));

        groupChannelsCount += deviceChannels.length;

        groupDevices.push({
          device_id: device.device_id,
          device_name: device.name,
          device_type: device.type,
          device_status: device.status,
          sno: device.SNO,
          mac_address: device.Mac_addr,
          firmware: device.firmware,
          location: {
            campus: {
              _id: device.campus?._id || null,
              name: device.campus?.name || 'N/A',
              description: device.campus?.description || null
            },
            building: {
              _id: device.building?._id || null,
              name: device.building?.name || 'N/A',
              description: device.building?.description || null
            },
            floor: {
              _id: device.floor?._id || null,
              name: device.floor?.name || 'N/A'
            },
            zone: {
              _id: device.zone?._id || null,
              name: device.zone?.name || 'N/A',
              description: device.zone?.description || null
            }
          },
          channels: deviceChannels,
          channel_summary: {
            total: deviceChannels.length,
            active: deviceChannels.filter(ch => ch.is_active).length,
            by_type: {
              led: deviceChannels.filter(ch => ch.channel_type === 'led').length,
              shade: deviceChannels.filter(ch => ch.channel_type === 'shade').length,
              sensor: deviceChannels.filter(ch => ch.channel_type === 'sensor').length
            }
          }
        });
      }

      // Only include groups that have at least one device matching the filters
      if (groupDevices.length > 0) {
        totalDevicesCount += groupDevices.length;
        totalChannelsCount += groupChannelsCount;

        processedGroups.push({
          group_id: group._id,
          group_name: group.name,
          isDeleted: group.isDeleted || false,
          createdBy: group.createdBy,
          updatedBy: group.updatedBy,
          createdAt: group.createdAt,
          updatedAt: group.updatedAt,
          devices: groupDevices,
          device_count: groupDevices.length,
          channel_count: groupChannelsCount
        });
      }
    }

    // Calculate pagination info
    const totalPages = Math.ceil(totalGroups / limit);
    const hasNextPage = page < totalPages;
    const hasPrevPage = page > 1;

    return {
      data: processedGroups,
      pagination: {
        current_page: page,
        total_pages: totalPages,
        total_groups: totalGroups,
        groups_per_page: limit,
        has_next_page: hasNextPage,
        has_prev_page: hasPrevPage
      },
      summary: {
        total_groups: totalGroups,
        current_page_groups: processedGroups.length,
        total_devices: totalDevicesCount,
        total_channels: totalChannelsCount
      },
      filters_applied: {
        search: search || null,
        campus: filters.campus || null,
        building: filters.building || null,
        floor: filters.floor || null,
        zone: filters.zone || null
      }
    };

  } catch (error) {
    throw new Error(`Error fetching groups with device details: ${error.message}`);
  }
};

// Get detailed group information with devices, channels, and location hierarchy
export const getGroupDetails = async (groupId, user = null) => {
  try {
    // Find the group
    const group = await Group.findById(groupId).lean();
    if (!group) {
      throw new Error('Group not found');
    }

    if (group.isDeleted) {
      throw new Error('Group has been deleted');
    }

    // Extract device IDs from the group
    const deviceIds = group.devices?.map(d => d.deviceId) || [];
    
    if (deviceIds.length === 0) {
      return {
        group_id: group._id,
        group_name: group.name,
        total_devices: 0,
        locations: [],
        devices: [],
        summary: {
          total_channels: 0,
          active_channels: 0,
          channel_types: {
            led: 0,
            shade: 0,
            sensor: 0
          },
          unique_locations: {
            campuses: 0,
            buildings: 0,
            floors: 0,
            zones: 0
          }
        },
        created_at: group.createdAt,
        updated_at: group.updatedAt
      };
    }

    // Build device query with zone filtering
    let deviceQuery = {
      device_id: { $in: deviceIds },
      deletedAt: null
    };

    if (user && user.campusData && Array.isArray(user.campusData) && user.campusData.length > 0) {
      const zoneIds = [];
      user.campusData.forEach(campus => {
        campus.buildings?.forEach(building => {
          building.floors?.forEach(floor => {
            floor.zones?.forEach(zone => {
              if (zone.zone_id) {
                zoneIds.push(zone.zone_id);
              }
            });
          });
        });
      });
      
      if (zoneIds.length > 0) {
        deviceQuery.zone = { $in: zoneIds };
      }
    }

    // Fetch devices with populated location information
    const devices = await Device.find(deviceQuery)
      .populate('campus', 'name code description')
      .populate('building', 'name code description')
      .populate('floor', 'name number description')
      .populate('zone', 'name code description')
      .lean();

    // Create a map of devices for easy lookup
    const deviceMap = new Map(devices.map(d => [d.device_id, d]));

    // Process each device in the group
    const processedDevices = [];
    const locationSet = new Set();
    let totalChannels = 0;
    let activeChannels = 0;
    const channelTypeCounts = { led: 0, shade: 0, sensor: 0 };

    for (const groupDevice of group.devices) {
      const device = deviceMap.get(groupDevice.deviceId);
      
      if (!device) {
        // Device not found or deleted, skip
        continue;
      }

      // Get group channels for this device
      const groupChannelIds = new Set(groupDevice.channels?.map(ch => ch.channelId) || []);
      
      // Filter device capabilities to only include group channels and active ones
      const deviceChannels = (device.capabilities || [])
        .filter(cap => groupChannelIds.has(cap.channelId))
        .map(cap => {
          const isActive = cap.properties?.installed === true;
          if (isActive) {
            activeChannels++;
            if (channelTypeCounts[cap.type] !== undefined) {
              channelTypeCounts[cap.type]++;
            }
          }
          totalChannels++;
          
          return {
            channel_id: cap.channelId,
            channel_name: cap.name,
            channel_type: cap.type,
            status: cap.status,
            is_active: isActive,
            properties: cap.properties
          };
        });

      // Build location string for uniqueness check
      const locationKey = `${device.campus?.name || 'N/A'}-${device.building?.name || 'N/A'}-${device.floor?.name || 'N/A'}-${device.zone?.name || 'N/A'}`;
      locationSet.add(locationKey);

      processedDevices.push({
        device_id: device.device_id,
        device_name: device.name,
        device_type: device.type,
        status: device.status,
        location: {
          campus: {
            id: device.campus?._id || null,
            name: device.campus?.name || 'N/A',
            code: device.campus?.code || null
          },
          building: {
            id: device.building?._id || null,
            name: device.building?.name || 'N/A',
            code: device.building?.code || null
          },
          floor: {
            id: device.floor?._id || null,
            name: device.floor?.name || 'N/A',
            number: device.floor?.number || null
          },
          zone: {
            id: device.zone?._id || null,
            name: device.zone?.name || 'N/A',
            code: device.zone?.code || null
          }
        },
        channels: deviceChannels,
        channel_summary: {
          total: deviceChannels.length,
          active: deviceChannels.filter(ch => ch.is_active).length,
          by_type: {
            led: deviceChannels.filter(ch => ch.channel_type === 'led').length,
            shade: deviceChannels.filter(ch => ch.channel_type === 'shade').length,
            sensor: deviceChannels.filter(ch => ch.channel_type === 'sensor').length
          }
        }
      });
    }

    // Extract unique locations
    const uniqueLocations = Array.from(
      new Map(
        processedDevices.map(device => [
          `${device.location.campus.id}-${device.location.building.id}-${device.location.floor.id}-${device.location.zone.id}`,
          {
            campus: device.location.campus,
            building: device.location.building,
            floor: device.location.floor,
            zone: device.location.zone,
            device_count: processedDevices.filter(d => 
              d.location.campus.id === device.location.campus.id &&
              d.location.building.id === device.location.building.id &&
              d.location.floor.id === device.location.floor.id &&
              d.location.zone.id === device.location.zone.id
            ).length
          }
        ])
      ).values()
    );

    // Calculate unique location counts
    const uniqueCampuses = new Set(processedDevices.map(d => d.location.campus.id).filter(Boolean));
    const uniqueBuildings = new Set(processedDevices.map(d => d.location.building.id).filter(Boolean));
    const uniqueFloors = new Set(processedDevices.map(d => d.location.floor.id).filter(Boolean));
    const uniqueZones = new Set(processedDevices.map(d => d.location.zone.id).filter(Boolean));

    return {
      group_id: group._id,
      group_name: group.name,
      total_devices: processedDevices.length,
      locations: uniqueLocations,
      devices: processedDevices,
      summary: {
        total_channels: totalChannels,
        active_channels: activeChannels,
        channel_types: channelTypeCounts,
        unique_locations: {
          campuses: uniqueCampuses.size,
          buildings: uniqueBuildings.size,
          floors: uniqueFloors.size,
          zones: uniqueZones.size
        }
      },
      created_by: group.createdBy || null,
      updated_by: group.updatedBy || null,
      created_at: group.createdAt,
      updated_at: group.updatedAt
    };

  } catch (error) {
    throw new Error(`Error fetching group details: ${error.message}`);
  }
};

// Get single device details with installed channels and complete location information
export const getSingleDeviceDetails = async (deviceId, user = null) => {
  try {
    if (!deviceId || typeof deviceId !== 'string') {
      throw new Error('Device ID is required');
    }

    // Build query with zone filtering if user has campusData
    let deviceQuery = {
      device_id: deviceId,
      deletedAt: null
    };

    if (user && user.campusData && Array.isArray(user.campusData) && user.campusData.length > 0) {
      const zoneIds = [];
      user.campusData.forEach(campus => {
        campus.buildings?.forEach(building => {
          building.floors?.forEach(floor => {
            floor.zones?.forEach(zone => {
              if (zone.zone_id) {
                zoneIds.push(zone.zone_id);
              }
            });
          });
        });
      });
      
      if (zoneIds.length > 0) {
        deviceQuery.zone = { $in: zoneIds };
      }
    }

    // Fetch device with populated location information
    const device = await Device.findOne(deviceQuery)
      .populate('campus', 'name code description')
      .populate('building', 'name code description')
      .populate('floor', 'name number description')
      .populate('zone', 'name code description')
      .lean();

    if (!device) {
      throw new Error('Device not found or access denied');
    }

    // Filter capabilities to only include installed channels
    const installedChannels = (device.capabilities || [])
      .filter(cap => cap.properties?.installed === true || cap.installed === true)
      .map(cap => ({
        channel_id: cap.channelId,
        channel_name: cap.name,
        channel_type: cap.type,
        status: cap.status,
        is_active: cap.properties?.installed === true || cap.installed === true,
        properties: cap.properties
      }));

    // Calculate channel summary
    const allCapabilities = Array.isArray(device.capabilities) ? device.capabilities : [];
    const channelSummary = {
      // Installed-only counts
      total: installedChannels.length,
      active: installedChannels.filter(ch => ch.is_active).length,
      by_type: {
        led: installedChannels.filter(ch => ch.channel_type === 'led').length,
        shade: installedChannels.filter(ch => ch.channel_type === 'shade').length,
        sensor: installedChannels.filter(ch => ch.channel_type === 'sensor').length
      },
      // Totals across all channels (installed and uninstalled)
      total_leds: allCapabilities.filter(cap => cap.type === 'led').length,
      total_shades: allCapabilities.filter(cap => cap.type === 'shade').length,
      total_sensors: allCapabilities.filter(cap => cap.type === 'sensor').length
    };

    return {
      device_id: device.device_id,
      device_name: device.name,
      device_type: device.type,
      status: device.status,
      sno: device.SNO,
      mac_address: device.Mac_addr,
      firmware: device.firmware,
      description: device.description,
      configure_flag: device.configure_flag,
      location: {
        campus: {
          id: device.campus?._id || null,
          name: device.campus?.name || 'N/A',
          code: device.campus?.code || null,
          description: device.campus?.description || null
        },
        building: {
          id: device.building?._id || null,
          name: device.building?.name || 'N/A',
          code: device.building?.code || null,
          description: device.building?.description || null
        },
        floor: {
          id: device.floor?._id || null,
          name: device.floor?.name || 'N/A',
          number: device.floor?.number || null,
          description: device.floor?.description || null
        },
        zone: {
          id: device.zone?._id || null,
          name: device.zone?.name || 'N/A',
          code: device.zone?.code || null,
          description: device.zone?.description || null
        }
      },
      port_info: {
        primary: device.port_primary || null,
        secondary: device.port_secondary || null
      },
      installed_channels: installedChannels,
      channel_summary: channelSummary,
      created_at: device.createdAt,
      updated_at: device.updatedAt
    };

  } catch (error) {
    throw new Error(`Error fetching device details: ${error.message}`);
  }
};

// Get comprehensive group view with all devices, channels, and control capabilities
export const getGroupViewData = async (groupId, user = null) => {
  try {
    console.log(`Fetching comprehensive group view data for ID: ${groupId}`);
    
    // Find the group
    const group = await Group.findOne({
      _id: groupId,
      isDeleted: { $ne: true }
    })
      .lean();

    if (!group) {
      throw new Error('Group not found or has been deleted');
    }

    // Extract device IDs from the group
    const deviceIds = group.devices?.map(d => d.deviceId) || [];
    
    if (deviceIds.length === 0) {
      return {
        group: {
          id: group._id,
          name: group.name,
          description: null, // Group model doesn't have description field
          created_at: group.createdAt,
          updated_at: group.updatedAt,
          created_by: null, // Group model doesn't have createdBy field
          updated_by: null  // Group model doesn't have updatedBy field
        },
        devices: [],
        summary: {
          total_devices: 0,
          active_devices: 0,
          configured_devices: 0,
          total_installed_channels: 0,
          channels_by_type: {
            led: 0,
            shade: 0,
            sensor: 0,
            other: 0
          },
          unique_locations: {
            campuses: 0,
            buildings: 0,
            floors: 0,
            zones: 0
          }
        }
      };
    }

    // Build device query with zone filtering
    let deviceQuery = {
      device_id: { $in: deviceIds },
      deletedAt: null
    };

    if (user && user.campusData && Array.isArray(user.campusData) && user.campusData.length > 0) {
      const zoneIds = [];
      user.campusData.forEach(campus => {
        campus.buildings?.forEach(building => {
          building.floors?.forEach(floor => {
            floor.zones?.forEach(zone => {
              if (zone.zone_id) {
                zoneIds.push(zone.zone_id);
              }
            });
          });
        });
      });
      
      if (zoneIds.length > 0) {
        deviceQuery.zone = { $in: zoneIds };
      }
    }

    // Fetch all devices with populated location information
    const devices = await Device.find(deviceQuery)
      .populate('campus', 'name code description')
      .populate('building', 'name code description')
      .populate('floor', 'name number description')
      .populate('zone', 'name code description')
      .lean();

    // Create a map of devices for easy lookup
    const deviceMap = new Map(devices.map(d => [d.device_id, d]));

    // Create a map of group channels for each device
    const groupDeviceChannels = new Map();
    group.devices.forEach(gd => {
      const channelMap = new Map();
      (gd.channels || []).forEach(ch => {
        channelMap.set(ch.channelId, ch);
      });
      groupDeviceChannels.set(gd.deviceId, channelMap);
    });

    // Process devices and collect summary data
    const processedDevices = [];
    let activeDevices = 0;
    let configuredDevices = 0;
    let totalInstalledChannels = 0;
    const channelsByType = { led: 0, shade: 0, sensor: 0, other: 0 };
    const uniqueLocations = {
      campuses: new Set(),
      buildings: new Set(),
      floors: new Set(),
      zones: new Set()
    };

    for (const deviceId of deviceIds) {
      const device = deviceMap.get(deviceId);
      
      if (!device) {
        // Device not found or deleted
        processedDevices.push({
          device_id: deviceId,
          device_name: 'Device Not Found',
          device_type: 'unknown',
          status: 'not_found',
          is_active: false,
          is_configured: false,
          location: {
            campus: { id: null, name: 'N/A', code: null },
            building: { id: null, name: 'N/A', code: null },
            floor: { id: null, name: 'N/A', number: null },
            zone: { id: null, name: 'N/A', code: null }
          },
          hardware_info: {
            sno: 'N/A',
            mac_address: 'N/A',
            firmware: 'N/A'
          },
          group_channels: [],
          all_installed_channels: [],
          channel_summary: {
            total_group_channels: 0,
            total_installed_channels: 0,
            active_channels: 0,
            by_type: { led: 0, shade: 0, sensor: 0, other: 0 }
          },
          status_message: 'Device not found or has been deleted'
        });
        continue;
      }

      // Check device status
      const isActive = device.status === 'active' || device.status === 1 || device.status === '1';
      const isConfigured = device.configure_flag === 1 || device.configure_flag === '1' || device.configure_flag === true;
      
      if (isActive) activeDevices++;
      if (isConfigured) configuredDevices++;

      // Add to unique locations
      if (device.campus?._id) uniqueLocations.campuses.add(String(device.campus._id));
      if (device.building?._id) uniqueLocations.buildings.add(String(device.building._id));
      if (device.floor?._id) uniqueLocations.floors.add(String(device.floor._id));
      if (device.zone?._id) uniqueLocations.zones.add(String(device.zone._id));

      // Get group channels for this device
      const groupChannelMap = groupDeviceChannels.get(deviceId) || new Map();
      
      // Get all installed capabilities
      const allInstalledChannels = (device.capabilities || [])
        .filter(cap => cap.properties?.installed === true || cap.installed === true)
        .map(cap => {
          const channelType = cap.type || 'other';
          if (channelsByType[channelType] !== undefined) {
            channelsByType[channelType]++;
          } else {
            channelsByType.other++;
          }
          totalInstalledChannels++;

          return {
            id: cap.channelId,
            name: cap.name || 'Unnamed Channel',
            type: cap.type || 'unknown',
            status: cap.status || 'unknown',
            properties: cap.properties || {}
          };
        });

      // Get group channels with validation
      const groupChannels = Array.from(groupChannelMap.values()).map(groupChannel => {
        const deviceCapability = (device.capabilities || []).find(
          cap => cap.channelId === groupChannel.channelId
        );
        
        const isInstalled = deviceCapability?.properties?.installed === true || deviceCapability?.installed === true;
        
        return {
          id: groupChannel.channelId,
          type: groupChannel.channelType,
          name: deviceCapability?.name || 'Unknown Channel',
          status: deviceCapability?.status || 'unknown',
          is_installed: isInstalled,
          is_valid: !!deviceCapability,
          properties: deviceCapability?.properties || {}
        };
      });

      // Calculate channel summary
      const channelSummary = {
        total_group_channels: groupChannels.length,
        total_installed_channels: allInstalledChannels.length,
        active_channels: allInstalledChannels.filter(ch => ch.status === 'active' || ch.status === 'on').length,
        by_type: {
          led: allInstalledChannels.filter(ch => ch.type === 'led').length,
          shade: allInstalledChannels.filter(ch => ch.type === 'shade').length,
          sensor: allInstalledChannels.filter(ch => ch.type === 'sensor').length,
          other: allInstalledChannels.filter(ch => !['led', 'shade', 'sensor'].includes(ch.type)).length
        }
      };

      // Generate status message
      let statusMessage = '';
      if (!isActive) {
        statusMessage = 'Device is inactive';
      } else if (!isConfigured) {
        statusMessage = 'Device is active but not configured';
      } else if (allInstalledChannels.length === 0) {
        statusMessage = 'Device has no installed channels';
      } else {
        statusMessage = 'Device is operational';
      }

      processedDevices.push({
        device_id: device.device_id,
        device_name: device.name || 'Unnamed Device',
        device_type: device.type || 'unknown',
        status: device.status,
        is_active: isActive,
        is_configured: isConfigured,
        location: {
          campus: {
            id: device.campus?._id || null,
            name: device.campus?.name || 'N/A',
            code: device.campus?.code || null,
            description: device.campus?.description || null
          },
          building: {
            id: device.building?._id || null,
            name: device.building?.name || 'N/A',
            code: device.building?.code || null,
            description: device.building?.description || null
          },
          floor: {
            id: device.floor?._id || null,
            name: device.floor?.name || 'N/A',
            number: device.floor?.number || null,
            description: device.floor?.description || null
          },
          zone: {
            id: device.zone?._id || null,
            name: device.zone?.name || 'N/A',
            code: device.zone?.code || null,
            description: device.zone?.description || null
          }
        },
        hardware_info: {
          sno: device.SNO || 'N/A',
          mac_address: device.Mac_addr || 'N/A',
          firmware: device.firmware || 'N/A',
          port_primary: device.port_primary || null,
          port_secondary: device.port_secondary || null
        },
        group_channels: groupChannels,
        all_installed_channels: allInstalledChannels,
        channel_summary: channelSummary,
        status_message: statusMessage,
        created_at: device.createdAt,
        updated_at: device.updatedAt
      });
    }

    // Build final response
    return {
      group: {
        id: group._id,
        name: group.name,
        description: null, // Group model doesn't have description field
        created_at: group.createdAt,
        updated_at: group.updatedAt,
        created_by: null, // Group model doesn't have createdBy field
        updated_by: null  // Group model doesn't have updatedBy field
      },
      devices: processedDevices,
      summary: {
        total_devices: processedDevices.length,
        active_devices: activeDevices,
        configured_devices: configuredDevices,
        total_installed_channels: totalInstalledChannels,
        channels_by_type: channelsByType,
        unique_locations: {
          campuses: uniqueLocations.campuses.size,
          buildings: uniqueLocations.buildings.size,
          floors: uniqueLocations.floors.size,
          zones: uniqueLocations.zones.size
        }
      }
    };

  } catch (error) {
    throw new Error(`Error fetching group view data: ${error.message}`);
  }
};

// Get all active groups with device details for authorized users (when allowedResources is null)
export const getAllActiveGroupsWithDeviceDetails = async (params = {}) => {
  try {
    const { search = '', filters = {}, user = null } = params;
    
    // Build query for groups
    const groupQuery = { isDeleted: { $ne: true } };
    
    // Add search by group name
    if (search && search.trim()) {
      groupQuery.name = { $regex: search.trim(), $options: 'i' };
    }

    // Get total count
    const totalGroups = await Group.countDocuments(groupQuery);

    // Find all non-deleted groups and sort by latest first (createdAt descending)
    const groups = await Group.find(groupQuery)
      .sort({ createdAt: -1 })
      .lean();

    if (groups.length === 0) {
      return {
        data: [],
        summary: {
          total_groups: totalGroups,
          total_devices: 0,
          total_channels: 0
        },
        filters_applied: {
          search: search || null,
          campus: filters.campus || null,
          building: filters.building || null,
          floor: filters.floor || null,
          zone: filters.zone || null
        }
      };
    }

    // Extract all unique device IDs from all groups
    const allDeviceIds = [...new Set(
      groups.flatMap(group => 
        group.devices?.map(d => d.deviceId) || []
      )
    )];

    // Build device query with location filters
    const deviceQuery = {
      device_id: { $in: allDeviceIds },
      deletedAt: null
    };

    // Add zone filtering based on user's campus data
    if (user && user.campusData && Array.isArray(user.campusData)) {
      // If campusData is empty, show all data (no zone filtering)
      if (user.campusData.length === 0) {
        // No zone filtering - show all devices
      } else {
        const zoneIds = [];
        user.campusData.forEach(campus => {
          if (campus.buildings && Array.isArray(campus.buildings)) {
            campus.buildings.forEach(building => {
              if (building.floors && Array.isArray(building.floors)) {
                building.floors.forEach(floor => {
                  if (floor.zones && Array.isArray(floor.zones)) {
                    floor.zones.forEach(zone => {
                      if (zone.zone_id) {
                        zoneIds.push(zone.zone_id);
                      }
                    });
                  }
                });
              }
            });
          }
        });
        
        if (zoneIds.length > 0) {
          deviceQuery.zone = { $in: zoneIds };
        } else {
          // If no zones found in user's campus data, return empty result
          deviceQuery.zone = { $in: [] };
        }
      }
    }

    // Add location filters if provided (these will override zone filtering from user's campus data)
    if (filters.campus) {
      deviceQuery.campus = filters.campus;
    }
    if (filters.building) {
      deviceQuery.building = filters.building;
    }
    if (filters.floor) {
      deviceQuery.floor = filters.floor;
    }
    if (filters.zone) {
      deviceQuery.zone = filters.zone;
    }

    // Fetch all devices with populated location information
    const devices = await Device.find(deviceQuery)
      .populate('campus', 'name code description')
      .populate('building', 'name code description')
      .populate('floor', 'name number description')
      .populate('zone', 'name code description')
      .lean();

    // Create a map of devices for easy lookup
    const deviceMap = new Map(devices.map(d => [d.device_id, d]));

    // Process each group and filter out groups with no matching devices
    const processedGroups = [];
    let totalDevicesCount = 0;
    let totalChannelsCount = 0;

    for (const group of groups) {
      const groupDevices = [];
      let groupChannelsCount = 0;

      for (const groupDevice of group.devices || []) {
        const device = deviceMap.get(groupDevice.deviceId);
        
        if (!device) {
          // Device not found, deleted, or doesn't match location filters
          continue;
        }

        // Get group channels for this device
        const groupChannelIds = new Set(groupDevice.channels?.map(ch => ch.channelId) || []);
        
        // Show all installed channels of the device (not just group channels)
        const deviceChannels = (device.capabilities || [])
          .filter(cap => cap.properties?.installed === true || cap.installed === true)
          .map(cap => ({
            channel_id: cap.channelId,
            channel_name: cap.name,
            channel_type: cap.type,
            status: cap.status,
            is_active: cap.properties?.installed === true || cap.installed === true,
            is_in_group: groupChannelIds.has(cap.channelId),
            properties: cap.properties
          }));

        groupChannelsCount += deviceChannels.length;

        groupDevices.push({
          device_id: device.device_id,
          device_name: device.name,
          device_type: device.type,
          device_status: device.status,
          sno: device.SNO,
          mac_address: device.Mac_addr,
          firmware: device.firmware,
          location: {
            campus: device.campus ? {
              _id: device.campus._id,
              name: device.campus.name,
              description: device.campus.description
            } : null,
            building: device.building ? {
              _id: device.building._id,
              name: device.building.name,
              description: device.building.description
            } : null,
            floor: device.floor ? {
              _id: device.floor._id,
              name: device.floor.name
            } : null,
            zone: device.zone ? {
              _id: device.zone._id,
              name: device.zone.name,
              description: device.zone.description
            } : null
          },
          channels: deviceChannels
        });
      }

      // Only include groups that have at least one device after filtering
      if (groupDevices.length > 0) {
        processedGroups.push({
          group_id: group._id,
          group_name: group.name,
          isDeleted: group.isDeleted,
          createdBy: group.createdBy,
          updatedBy: group.updatedBy,
          createdAt: group.createdAt,
          updatedAt: group.updatedAt,
          devices: groupDevices,
          device_count: groupDevices.length,
          channel_count: groupChannelsCount
        });

        totalDevicesCount += groupDevices.length;
        totalChannelsCount += groupChannelsCount;
      }
    }

    return {
      data: processedGroups,
      summary: {
        total_groups: totalGroups,
        returned_groups: processedGroups.length,
        total_devices: totalDevicesCount,
        total_channels: totalChannelsCount
      },
      filters_applied: {
        search: search || null,
        campus: filters.campus || null,
        building: filters.building || null,
        floor: filters.floor || null,
        zone: filters.zone || null
      }
    };

  } catch (error) {
    console.error('Error in getAllActiveGroupsWithDeviceDetails:', error);
    throw new Error(`Error fetching all active groups with device details: ${error.message}`);
  }
};

// Clean up sensor scene references when groups are deleted - prevents orphaned scene links
const updateSensorScenesForDeletedGroup = async (groupId, user) => {
  try {
    console.log(`Updating sensor scenes for deleted group ${groupId}...`);
    
    // Find scenes that contain the deleted group
    const scenesWithDeletedGroup = await Scene.find({
      'Groups.groupId': groupId,
      isDeleted: false
    }).select('_id').lean();
    
    const sceneIds = scenesWithDeletedGroup.map(scene => scene._id);
    
    if (sceneIds.length > 0) {
      // Import Sensor model
      const { Sensor } = await import('../models/Sensor.js');
      
      // Update sensors that reference these scenes - set motionScene to null
      const motionSceneUpdate = await Sensor.updateMany(
        {
          motionScene: { $in: sceneIds },
          isDelete: false
        },
        {
          $set: {
            motionScene: null,
            updatedBy: {
              userId: user._id,
              fullName: user.fullName,
              email: user.email
            },
            updatedAt: new Date()
          }
        }
      );
      
      // Update sensors that reference these scenes - set NoMotionScene to null
      const noMotionSceneUpdate = await Sensor.updateMany(
        {
          NoMotionScene: { $in: sceneIds },
          isDelete: false
        },
        {
          $set: {
            NoMotionScene: null,
            updatedBy: {
              userId: user._id,
              fullName: user.fullName,
              email: user.email
            },
            updatedAt: new Date()
          }
        }
      );
      
      console.log(`Updated ${motionSceneUpdate.modifiedCount} sensors - set motionScene to null`);
      console.log(`Updated ${noMotionSceneUpdate.modifiedCount} sensors - set NoMotionScene to null`);
    }
    
  } catch (error) {
    console.error(`Error updating sensor scenes for deleted group ${groupId}:`, error);
    // Don't throw - this is a cleanup operation
  }
};
