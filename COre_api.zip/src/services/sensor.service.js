
/**
 * Sensor Service - IoT sensor configuration and automation management
 * 
 * Handles motion sensor setup with scene-based automation triggers
 * Manages MQTT device commands and sensor-to-scene relationships
 * Provides permission assignment and zone-based access control
 */
import mongoose from 'mongoose';
import { Sensor } from '../models/Sensor.js';
import Device from '../models/Device.js';
import { Group } from '../models/Group.js';
import { Scene } from '../models/Scene.js';
import DeviceConfig from '../utils/deviceConfig.js';
import { getConfig } from '../config/env.js';
import axios from 'axios';
import { sendCommand } from './mqtt.service.js';

// Create sensor configuration with scene validation and MQTT device setup
export const addSensor = async (sensorData, user) => {
  // Validate that both motion and no-motion scenes exist before sensor creation
  const motionScene = await Scene.findById(sensorData.motionScene);
  if (!motionScene) {
    throw new Error('Motion scene not found');
  }

  // Verify no motion scene exists
  const noMotionScene = await Scene.findById(sensorData.NoMotionScene);
  if (!noMotionScene) {
    throw new Error('No motion scene not found');
  }

  // Verify device exists
  const device = await Device.findOne({ device_id: sensorData.device });
  if (!device) {
    throw new Error('Device not found');
  }
  
  const sensorSceneCount = await Sensor.countDocuments();

  // Check if sensor event with same name already exists for this device
  const existingSensor = await Sensor.findOne({
    sensorEvent: sensorData.sensorEvent,
    device: sensorData.device,
    isDelete: { $ne: true }
  });
  if (existingSensor) {
    throw new Error('Sensor event with this name already exists for this device');
  }

  // Create sensor with user information
  const sensor = new Sensor({
    ...sensorData,
    createdBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    },
    updatedBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    },
    sensorGroupId : sensorSceneCount + 1
  });

  // Configure PIR sensor trigger duration via MQTT command to device
  const sensorIds = [];
  sensorData.sensor.map((sensor) => {
    const config = sensor.split('_');
    const port = config[1];
    sensorIds.push(Number(port));
  });
  await sendCommand({ ch_t: 'PIR', ch_addr: sensorIds, cmd: DeviceConfig.GRP_PIR_TIMER, cmd_m: (sensorSceneCount +1).toString() + ":" + sensorData.Trigger_duration.toString() }, sensorData.device);

  await sensor.save();

  // Populate references
  await sensor.populate([
    { path: 'motionScene', select: 'name type' },
    { path: 'NoMotionScene', select: 'name type' },
    { path: 'createdBy.userId', select: 'fullName email' }
  ]);

  // Auto-assign sensor permissions to admin and technician roles for immediate access
  // Superadmin: Always has allowedResources: null, don't update anything
  // Admin & Technician: Add to intelligentControl.sensors
  try {
    const { default: Role } = await import('../models/Role.js');
    const { User } = await import('../models/User.js');
    
    // Find roles for admin and technician (case insensitive)
    const adminTechRoles = await Role.find({ 
      roleName: { 
        $in: ['admin', 'technician'].map(name => new RegExp(`^${name}$`, 'i')) 
      },
      isDelete: { $ne: true },
      isActive: true
    });
    
    console.log(`Found ${adminTechRoles.length} admin/technician roles for sensor access`);
    
    const adminTechRoleIds = adminTechRoles.map(r => r._id);
    
    // Update admin and technician users (add to intelligentControl.sensors)
    if (adminTechRoleIds.length > 0) {
      const adminTechUsers = await User.find({ 
        role_id: { $in: adminTechRoleIds },
        allowedResources: { $ne: null },
        isDeleted: { $ne: true },
        isActive: true
      });
      
      console.log(`Found ${adminTechUsers.length} admin/technician users to update with sensor access`);
      
      for (const u of adminTechUsers) {
        // Initialize structures if needed
        if (!u.allowedResources.intelligentControl) {
          u.allowedResources.intelligentControl = {};
        }
        if (!Array.isArray(u.allowedResources.intelligentControl.sensors)) {
          u.allowedResources.intelligentControl.sensors = [];
        }
        
        // Add to intelligentControl.sensors if not already present
        if (!u.allowedResources.intelligentControl.sensors.includes(sensor._id.toString())) {
          u.allowedResources.intelligentControl.sensors.push(sensor._id.toString());
        }
        
        await u.save();
        console.log(`Updated admin/technician user ${u.email} with sensor ID: ${sensor._id}`);
      }
      
      console.log(`Successfully updated ${adminTechUsers.length} admin/technician users with new sensor access`);
    }
    
  } catch (userUpdateError) {
    console.error('Error updating users with new sensor access:', userUpdateError);
    // Don't throw the error here - we still want to return the created sensor
    // The sensor was created successfully, user updates are a bonus feature
  }

  return sensor;
};

// Get paginated sensor list with device and scene population
export const listSensors = async (query = {}) => {
  const {
    status,
    device,
    search,
    limit = 50,
    page = 1
  } = query;

  const pageNum = Number(page) > 0 ? Number(page) : 1;
  const limitNum = Number(limit) > 0 ? Number(limit) : 50;

  // Build match conditions
  const matchConditions = {
    isDelete: { $ne: true }
  };

  if (status) {
    matchConditions.status = status;
  }

  if (device) {
    matchConditions.device = device;
  }

  if (search && search.trim()) {
    const searchRegex = { $regex: search.trim(), $options: 'i' };
    matchConditions.$or = [
      { sensorEvent: searchRegex },
      { device: searchRegex },
      { sensor: { $elemMatch: { $regex: search.trim(), $options: 'i' } } }
    ];
  }

  // Get total count
  const total = await Sensor.countDocuments(matchConditions);

  // Get paginated data
  const sensors = await Sensor.find(matchConditions)
    .populate('motionScene', 'name type')
    .populate('NoMotionScene', 'name type')
    .populate('createdBy.userId', 'fullName email')
    .sort({ createdAt: -1 })
    .skip((pageNum - 1) * limitNum)
    .limit(limitNum)
    .lean();

  return {
    data: sensors,
    total,
    page: pageNum,
    limit: limitNum,
    totalPages: Math.ceil(total / limitNum)
  };
};

// Get sensor by ID with populated scene and user details
export const getSensorById = async (sensorId) => {
  const sensor = await Sensor.findOne({
    _id: sensorId,
    isDelete: { $ne: true }
  })
    .populate('motionScene', 'name type')
    .populate('NoMotionScene', 'name type')
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email');

  if (!sensor) {
    throw new Error('Sensor not found');
  }

  return sensor;
};

// Update sensor configuration with scene validation and MQTT command updates
export const updateSensor = async (sensorId, updateData, user) => {
  try {
    // Find the existing sensor
    const sensor = await Sensor.findOne({
      _id: sensorId,
      isDelete: { $ne: true }
    });

    if (!sensor.sensorGroupId) {
      const sensorSceneCount = await Sensor.find({}, { _id: 1 });
      const findIndex = sensorSceneCount.findIndex((ele) => ele._id.toString() === sensor._id.toString());
      sensor.sensorGroupId = findIndex + 1;
      updateData.sensorGroupId = findIndex + 1;
    }

    if (!sensor) {
      throw new Error('Sensor not found');
    }

    // Verify motion scene exists if provided
    if (updateData.motionScene) {
      const motionScene = await Scene.findById(updateData.motionScene);
      if (!motionScene) {
        throw new Error('Motion scene not found');
      }
    }

    // Verify no motion scene exists if provided
    if (updateData.NoMotionScene) {
      const noMotionScene = await Scene.findById(updateData.NoMotionScene);
      if (!noMotionScene) {
        throw new Error('No motion scene not found');
      }
    }

    // Verify device exists if device is being updated
    if (updateData.device) {
      const device = await Device.findOne({ device_id: updateData.device });
      if (!device) {
        throw new Error('Device not found');
      }
    }

    // Send command for each sensor to set trigger duration
    if (updateData.sensor || updateData.Trigger_duration) {
      const sensorIds = [];
      if (updateData.sensor) {
        updateData.sensor.map((sensor) => {
          const config = sensor.split('_');
          const port = config[1];
          sensorIds.push(Number(port));
        });
        await sendCommand({ ch_t: 'PIR', ch_addr: sensorIds, cmd: DeviceConfig.GRP_PIR_TIMER, cmd_m: sensor.sensorGroupId.toString() + ":" + updateData.Trigger_duration.toString() }, updateData.device);
      }
    }

    // Check for duplicate sensor event name if updating sensorEvent or device
    if (updateData.sensorEvent || updateData.device) {
      const checkDevice = updateData.device || sensor.device;
      const checkSensorEvent = updateData.sensorEvent || sensor.sensorEvent;
      
      const existingSensor = await Sensor.findOne({
        _id: { $ne: sensorId },
        sensorEvent: checkSensorEvent,
        device: checkDevice,
        isDelete: { $ne: true }
      });
      
      if (existingSensor) {
        throw new Error('Sensor event with this name already exists for this device');
      }
    }

    // Prepare update object with the fields from the payload
    const updateFields = {};

    // Handle direct field mappings from the payload
    if (updateData.sensorEvent !== undefined) {
      updateFields.sensorEvent = updateData.sensorEvent;
    }

    if (updateData.device !== undefined) {
      updateFields.device = updateData.device;
    }

    if (updateData.sensor !== undefined) {
      updateFields.sensor = updateData.sensor;
    }

    if (updateData.motionScene !== undefined) {
      updateFields.motionScene = updateData.motionScene;
    }

    if (updateData.NoMotionScene !== undefined) {
      updateFields.NoMotionScene = updateData.NoMotionScene;
    }
    if (updateData.sensorGroupId !== undefined) {
        updateFields.sensorGroupId = updateData.sensorGroupId;
    }

    if (updateData.Trigger_duration !== undefined) {
      // Validate trigger duration
      if (updateData.Trigger_duration < 0) {
        throw new Error('Trigger duration must be greater than or equal to 0');
      }
      updateFields.Trigger_duration = updateData.Trigger_duration;
    }

    if (updateData.status !== undefined) {
      if (!['Active', 'Inactive'].includes(updateData.status)) {
        throw new Error('Status must be either Active or Inactive');
      }
      updateFields.status = updateData.status;
    }

    // Handle alternative field name mappings for backward compatibility
    if (updateData.sensorName !== undefined) {
      updateFields.sensorEvent = updateData.sensorName;
    }

    if (updateData.deviceId !== undefined) {
      updateFields.device = updateData.deviceId;
    }

    if (updateData.sensorId !== undefined) {
      updateFields.sensor = updateData.sensorId;
    }

    if (updateData.noMotionScene !== undefined) {
      updateFields.NoMotionScene = updateData.noMotionScene;
    }

    if (updateData.triggerMotion !== undefined) {
      if (updateData.triggerMotion < 0 || updateData.triggerMotion > 600) {
        throw new Error('Trigger motion duration must be between 0 and 600 seconds');
      }
      updateFields.Trigger_duration = updateData.triggerMotion;
    }

    // Add user tracking information
    updateFields.updatedBy = {
      userId: user._id,
      fullName: user.fullName || user.name,
      email: user.email
    };

    // Update the sensor
    const updatedSensor = await Sensor.findByIdAndUpdate(
      sensorId,
      updateFields,
      { 
        new: true, 
        runValidators: true 
      }
    )
    .populate('motionScene', 'name type')
    .populate('NoMotionScene', 'name type')
    .populate('updatedBy.userId', 'fullName email');

    if (!updatedSensor) {
      throw new Error('Failed to update sensor');
    }

    return updatedSensor;

  } catch (error) {
    throw new Error(`Error updating sensor: ${error.message}`);
  }
};

// Soft delete sensor configuration and maintain audit trail
export const deleteSensor = async (sensorId, user) => {
  try {
    const sensor = await Sensor.findOneAndUpdate(
      { _id: sensorId, isDelete: false },
      { 
        isDelete: true, 
        updatedBy: user._id, 
        updatedAt: new Date() 
      },
      { new: true }
    )
      .lean();

    if (!sensor) {
      throw new Error('Sensor not found');
    }

    return sensor;
  } catch (error) {
    throw new Error(`Error deleting sensor: ${error.message}`);
  }
};

// Get comprehensive sensor list with zone-based filtering and device/scene details
export const getSensorList = async (params = {}) => {
  const {
    filter = {},
    search = '',
    page = 1,
    limit = 10,
    user = null
  } = params;

  const query = {
    isDelete: { $ne: true } // Add soft delete filter
  };

  // Apply location-based access control - filter sensors by user's zone permissions
  if (user && user.campusData && Array.isArray(user.campusData) && user.campusData.length > 0) {
    // Extract zone IDs from user's campus data
    const zoneIds = [];
    user.campusData.forEach(campus => {
      if (campus.buildings && Array.isArray(campus.buildings)) {
        campus.buildings.forEach(building => {
          if (building.floors && Array.isArray(building.floors)) {
            building.floors.forEach(floor => {
              if (floor.zones && Array.isArray(floor.zones)) {
                floor.zones.forEach(zone => {
                  if (zone.zone_id) {
                    zoneIds.push(zone.zone_id);
                  }
                });
              }
            });
          }
        });
      }
    });

    if (zoneIds.length > 0) {
      // Get devices that are in allowed zones
      const allowedDevices = await Device.find({
        zone: { $in: zoneIds },
        deletedAt: null
      }, { device_id: 1 }).lean();

      const allowedDeviceIds = allowedDevices.map(d => d.device_id);
      
      if (allowedDeviceIds.length > 0) {
        // Filter sensors to only include those with devices in allowed zones
        query.device = { $in: allowedDeviceIds };
      } else {
        // No devices in allowed zones, return empty result
        return {
          data: [],
          pagination: {
            total: 0,
            page,
            limit,
            totalPages: 0,
            hasNextPage: false,
            hasPrevPage: false
          },
          summary: {
            totalSensors: 0,
            currentPageCount: 0,
            filters: {
              deviceId: filter.deviceId || null,
              groupId: filter.groupId || null,
              sensorName: filter.sensorName || null,
              search: search || null
            }
          }
        };
      }
    } else {
      // No zones in user's campus data, return empty result
      return {
        data: [],
        pagination: {
          total: 0,
          page,
          limit,
          totalPages: 0,
          hasNextPage: false,
          hasPrevPage: false
        },
        summary: {
          totalSensors: 0,
          currentPageCount: 0,
          filters: {
            deviceId: filter.deviceId || null,
            groupId: filter.groupId || null,
            sensorName: filter.sensorName || null,
            search: search || null
          }
        }
      };
    }
  }

  // Filter by allowedSensorIds if provided (skip for superadmin)
  if (params.allowedSensorIds && Array.isArray(params.allowedSensorIds) && user?.role_id?.roleName?.toLowerCase() !== 'superadmin') {
    if (params.allowedSensorIds.length > 0) {
      query._id = { $in: params.allowedSensorIds.map(id => new mongoose.Types.ObjectId(id)) };
    } else {
      // Empty array means no sensors allowed - return no results
      query._id = { $in: [] };
    }
  }

  // Apply filters based on your actual schema
  if (filter.deviceId) {
    query.device = filter.deviceId; // Use 'device' field from your schema
  }

  if (filter.groupId && /^[0-9a-fA-F]{24}$/.test(filter.groupId)) {
    // If you have groupId in sensor schema, otherwise remove this filter
    query.groupId = new mongoose.Types.ObjectId(filter.groupId);
  }

  if (filter.sensorName) {
    query.sensorEvent = { $regex: filter.sensorName, $options: 'i' }; // Use 'sensorEvent' field
  }

  // Search functionality across multiple fields
  if (search && search.trim()) {
    const searchRegex = { $regex: search.trim(), $options: 'i' };
    
    // Get device IDs that match the search term
    const matchingDevices = await Device.find(
      { device_id: searchRegex },
      { device_id: 1 }
    ).lean();
    const deviceIds = matchingDevices.map(d => d.device_id);

    // Get group IDs that match the search term (if groups are referenced in sensors)
    const matchingGroups = await Group.find(
      { name: searchRegex },
      { _id: 1 }
    ).lean();
    const groupIds = matchingGroups.map(g => g._id);

    query.$or = [
      { sensorEvent: searchRegex }, // Search by sensor event name
      { device: { $in: deviceIds } }, // Search by device ID
      { device: searchRegex }, // Direct device search
      // Only include group search if your sensor schema has groupId field
      ...(groupIds.length > 0 ? [{ groupId: { $in: groupIds } }] : [])
    ];
  }

  const skip = (page - 1) * limit;

  // Execute the query - no population since device is stored as string
  const sensors = await Sensor.find(query)
    .skip(skip)
    .limit(limit)
    .sort({ createdAt: -1 })
    .lean();

  // Get total count for pagination
  const total = await Sensor.countDocuments(query);

  // Get device information separately for the sensors
  const deviceIds = [...new Set(sensors.map(s => s.device).filter(Boolean))];
  const devices = await Device.find(
    { device_id: { $in: deviceIds } },
    { device_id: 1, name: 1, type: 1, status: 1 }
  ).lean();
  const deviceMap = new Map(devices.map(d => [d.device_id, d]));

  // Get group information if sensors have groupId field
  const groupIds = [...new Set(sensors.map(s => s.groupId).filter(Boolean))];
  let groupMap = new Map();
  if (groupIds.length > 0) {
    const groups = await Group.find(
      { _id: { $in: groupIds } },
      { _id: 1, name: 1 }
    ).lean();
    groupMap = new Map(groups.map(g => [String(g._id), g]));
  }


  // Collect all unique motionScene and NoMotionScene IDs
  const motionSceneIds = [...new Set(sensors.map(s => s.motionScene).filter(Boolean))];
  const noMotionSceneIds = [...new Set(sensors.map(s => s.NoMotionScene).filter(Boolean))];

  // Fetch all referenced scenes in one go
  const allSceneIds = Array.from(new Set([...motionSceneIds, ...noMotionSceneIds]));
  let sceneMap = new Map();
  if (allSceneIds.length > 0) {
    const scenes = await Scene.find({ _id: { $in: allSceneIds } }, { _id: 1, name: 1 }).lean();
    sceneMap = new Map(scenes.map(scene => [String(scene._id), scene.name]));
  }

  // Format the response with motionScene and noMotionScene as names
  const formattedSensors = sensors.map(sensor => {
    const device = deviceMap.get(sensor.device);
    const group = sensor.groupId ? groupMap.get(String(sensor.groupId)) : null;
    const motionScene = sensor.motionScene ? sceneMap.get(String(sensor.motionScene)) || null : null;
    const NoMotionScene = sensor.NoMotionScene ? sceneMap.get(String(sensor.NoMotionScene)) || null : null;

    return {
      _id: sensor._id,
      sensorEvent: sensor.sensorEvent,
      device: sensor.device,
      deviceInfo: device ? {
        device_id: device.device_id,
        name: device.name,
        type: device.type,
        status: device.status
      } : null,
      groupId: sensor.groupId,
      groupInfo: group ? {
        _id: group._id,
        name: group.name
      } : null,
      sensor: sensor.sensor || [],
      status: sensor.status,
      motionScene,
      NoMotionScene,
      Trigger_duration: sensor.Trigger_duration, // Added Trigger_duration
      createdAt: sensor.createdAt,
      updatedAt: sensor.updatedAt,
      createdBy: sensor.createdBy,
      updatedBy: sensor.updatedBy
    };
  });

  // Calculate pagination metadata
  const totalPages = Math.ceil(total / limit);
  const hasNextPage = page < totalPages;
  const hasPrevPage = page > 1;

  return {
    data: formattedSensors,
    pagination: {
      total,
      page,
      limit,
      totalPages,
      hasNextPage,
      hasPrevPage
    },
    summary: {
      totalSensors: total,
      currentPageCount: formattedSensors.length,
      filters: {
        deviceId: filter.deviceId || null,
        groupId: filter.groupId || null,
        sensorName: filter.sensorName || null,
        search: search || null
      }
    }
  };
};
