import cron from 'node-cron';
import * as widgetService from '../services/widget.service.js';
import * as TemplateService from '../services/template.service.js';
import { User } from '../models/User.js';
import { socketManager } from '../utils/socketManager.js';
import { getConfig } from '../config/env.js';
import axios from 'axios';


export function startHourlyTask() {
    // Runs every hour (12:00, 1:00, 2:00, etc.)
    //Stopped cron
    // cron.schedule('0 0 * * * *', async () => {
    //     console.log('Running hourly task at', new Date().toISOString());
    //     console.log('Server timezone:', Intl.DateTimeFormat().resolvedOptions().timeZone);
    //     await callWeatherApi();
    // }, {
    //     timezone: "UTC" // Force UTC to ensure consistent timing
    // });
}

async function callWeatherApi() {
  // your actual logic
    console.log('Cron started...');
    
    // Call the weather refresh API endpoint
    console.log('Calling weather refresh API endpoint...');
    try {
        const config = getConfig();
        const baseUrl = config.reset.appUrl || process.env.APP_URL || `http://localhost:${config.port}`;
        const apiUrl = `${baseUrl}/widgets/weather/refresh-all`;
        
        console.log('Making API call to:', apiUrl);
        
        const response = await axios.post(apiUrl, {}, {
            timeout: 120000, // 2 minutes timeout for weather API calls
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': 'MPS-Cron/1.0'
            }
        });
        
        console.log('Weather refresh API called successfully:', response.data?.message);
    } catch (error) {
        console.error('Error calling weather refresh API:', error.message);
        
        // Fallback: Call service method directly if API call fails
        console.log('Falling back to direct service call...');
        try {
            const result = await widgetService.refreshAllWeatherData(null);
            console.log('Fallback weather data refreshed successfully');
            
            // Emit weatherDataRefreshed socket event
            socketManager.emitEvent('weatherDataRefreshed', {
                message: `Weather data refreshed for ${result.successCount}/${result.totalCount} locations`,
                successCount: result.successCount,
                totalCount: result.totalCount,
                timestamp: new Date().toISOString(),
                result: result,
                source: 'cron-fallback'
            });
        } catch (fallbackError) {
            console.error('Fallback weather refresh also failed:', fallbackError.message);
        }
    }
    
    const widgetsWeather = await widgetService.getAllWeatherData();
        socketManager.emitEvent('allWeatherData', widgetsWeather );
    const widgets = await widgetService.getAllWidgets();
        socketManager.emitEvent('allWidgetData', widgets );
    const users = await User.find({ isDeleted: false },{_id:1});
    users.map(async (user) => {
        const result = await TemplateService.getAllCompleteTemplatesWithWidgetData(user);
        if(result.length)
            socketManager.emitEvent('widgetTemplateData', { ...result, user: user._id });
    });    
}
