/**
 * Dashboard Service - Comprehensive real-time analytics and monitoring backend
 * 
 * Flow: dashboard.controller.js → dashboard.service.js → MongoDB (Multiple Collections)
 * 
 * Provides enterprise dashboard capabilities:
 * - Campus hierarchy analytics with device aggregation and filtering
 * - Zone-level device statistics with type-specific status tracking
 * - Device information with scene associations and channel analytics
 * - Group memberships for operational context and management
 * - Alert monitoring with pagination for proactive system management
 * - Real-time performance metrics and system health monitoring
 */

import mongoose from 'mongoose';
import { Campus } from '../models/Campus.js';
import { CampusBuilding } from '../models/CampusBuilding.js';
import { CampusFloor } from '../models/CampusFloor.js';
import { CampusZone } from '../models/CampusZone.js';
import Device from '../models/Device.js';
import { Scene } from '../models/Scene.js';
import { Alert } from '../models/Alert.js';
import Log from '../models/Log.js';
import { Group } from '../models/Group.js';

const toObjectIdArray = (ids = []) => {
  if (!Array.isArray(ids) || ids.length === 0) return [];
  return ids
    .filter(Boolean)
    .map((id) => {
      try { return new mongoose.Types.ObjectId(id); } catch { return null; }
    })
    .filter(Boolean);
};

/**
 * Get comprehensive dashboard data with campus hierarchy analytics
 * 
 * Builds filtered dashboard view with:
 * - Campus hierarchy: campus → building → floor → zone structure
 * - Device aggregation with status filtering (Active/Inactive only)
 * - Multi-level filtering by campus/building/floor/zone IDs
 * - Active entity validation (status=1, isDelete≠true) across all levels
 * - Zone device listings with campus lineage for contextual navigation
 * - Optimized aggregation pipelines for performance at scale
 */
export async function getDashboardData(payload) {
  const campusIds = toObjectIdArray(payload.campus_ids);
  const buildingIds = toObjectIdArray(payload.building_ids);
  const floorIds = toObjectIdArray(payload.floor_ids);
  const zoneIds = toObjectIdArray(payload.zone_ids);

  // Only show data for active, non-deleted entities
  const baseCampusFilter = { isDelete: { $ne: true }, status: 1 };
  if (campusIds.length) baseCampusFilter._id = { $in: campusIds };

  // Get active campuses first to ensure we only work with active entities
  const activeCampuses = await Campus.find(baseCampusFilter).select('_id').lean();
  const activeCampusIds = activeCampuses.map(c => c._id);
  
  if (activeCampusIds.length === 0) {
    return { campusCounts: [] };
  }

  // Filter buildings - only active ones from active campuses
  const buildingsFilter = { 
    isDelete: { $ne: true }, 
    status: 1,
    campusId: { $in: activeCampusIds }
  };
  if (buildingIds.length) buildingsFilter._id = { $in: buildingIds };

  const activeBuildings = await CampusBuilding.find(buildingsFilter).select('_id').lean();
  const activeBuildingIds = activeBuildings.map(b => b._id);

  // Filter floors - only active ones from active buildings
  const floorsFilter = { 
    isDelete: { $ne: true }, 
    deleted: { $ne: true }, 
    status: 1
  };
  if (activeBuildingIds.length > 0) {
    floorsFilter.buildingId = { $in: activeBuildingIds };
  } else {
    floorsFilter.buildingId = { $in: [] }; // No active buildings, no floors
  }
  if (floorIds.length) floorsFilter._id = { $in: floorIds };

  const activeFloors = await CampusFloor.find(floorsFilter).select('_id').lean();
  const activeFloorIds = activeFloors.map(f => f._id);

  // Filter zones - only active ones from active floors
  const zonesFilter = { 
    isDelete: { $ne: true }, 
    status: 1
  };
  if (activeFloorIds.length > 0) {
    zonesFilter.floorId = { $in: activeFloorIds };
  } else {
    zonesFilter.floorId = { $in: [] }; // No active floors, no zones
  }
  if (zoneIds.length) zonesFilter._id = { $in: zoneIds };

  // Aggregations for counts per campus - only for active entities
  const [campuses, buildingCounts, floorCounts, zoneCounts] = await Promise.all([
    Campus.find(baseCampusFilter).select('_id name').lean(),
    CampusBuilding.aggregate([
      { $match: buildingsFilter },
      { $group: { _id: '$campusId', count: { $sum: 1 } } }
    ]),
    CampusFloor.aggregate([
      { $match: floorsFilter },
      { $lookup: { 
          from: 'campusbuildings', 
          localField: 'buildingId', 
          foreignField: '_id', 
          as: 'building',
          pipeline: [{ $match: { isDelete: { $ne: true }, status: 1 } }]
        } 
      },
      { $unwind: '$building' },
      { $match: { 'building.campusId': { $in: activeCampusIds } } },
      { $group: { _id: '$building.campusId', count: { $sum: 1 } } }
    ]),
    CampusZone.aggregate([
      { $match: zonesFilter },
      { $lookup: { 
          from: 'campusfloors', 
          localField: 'floorId', 
          foreignField: '_id', 
          as: 'floor',
          pipeline: [{ $match: { isDelete: { $ne: true }, deleted: { $ne: true }, status: 1 } }]
        } 
      },
      { $unwind: '$floor' },
      { $lookup: { 
          from: 'campusbuildings', 
          localField: 'floor.buildingId', 
          foreignField: '_id', 
          as: 'building',
          pipeline: [{ $match: { isDelete: { $ne: true }, status: 1 } }]
        } 
      },
      { $unwind: '$building' },
      { $match: { 'building.campusId': { $in: activeCampusIds } } },
      { $group: { _id: '$building.campusId', count: { $sum: 1 } } }
    ])
  ]);

  const campusIdToCounts = new Map();
  for (const c of campuses) {
    campusIdToCounts.set(String(c._id), { campusId: c._id, campusName: c.name, buildings: 0, floors: 0, zones: 0 });
  }
  for (const bc of buildingCounts) {
    const key = String(bc._id);
    if (!campusIdToCounts.has(key)) campusIdToCounts.set(key, { campusId: bc._id, campusName: null, buildings: 0, floors: 0, zones: 0 });
    campusIdToCounts.get(key).buildings = bc.count || 0;
  }
  for (const fc of floorCounts) {
    const key = String(fc._id);
    if (!campusIdToCounts.has(key)) campusIdToCounts.set(key, { campusId: fc._id, campusName: null, buildings: 0, floors: 0, zones: 0 });
    campusIdToCounts.get(key).floors = fc.count || 0;
  }
  for (const zc of zoneCounts) {
    const key = String(zc._id);
    if (!campusIdToCounts.has(key)) campusIdToCounts.set(key, { campusId: zc._id, campusName: null, buildings: 0, floors: 0, zones: 0 });
    campusIdToCounts.get(key).zones = zc.count || 0;
  }

  // Zone listing with devices - only from active zones
  const zones = await CampusZone.find(zonesFilter)
    .select('_id name floorId')
    .lean();

  const zoneIdsAll = zones.map((z) => z._id);
  const devices = zoneIdsAll.length
    ? await Device.find({ zone: { $in: zoneIdsAll }, is_delete: { $ne: true }, status: { $in: ['Active', 'Inactive'] } })
        .select('device_id name zone status')
        .lean()
    : [];

  const zoneIdToDevices = new Map();
  for (const d of devices) {
    const key = String(d.zone);
    if (!zoneIdToDevices.has(key)) zoneIdToDevices.set(key, []);
    zoneIdToDevices.get(key).push({ deviceId: d.device_id, deviceName: d.name, status: d.status });
  }

  // Attach building/floor/campus lineage - only for active entities
  const floorIdsAll = [...new Set(zones.map((z) => String(z.floorId)))].map((id) => new mongoose.Types.ObjectId(id));
  const floorDocs = floorIdsAll.length ? await CampusFloor.find({ 
    _id: { $in: floorIdsAll }, 
    isDelete: { $ne: true }, 
    deleted: { $ne: true }, 
    status: 1 
  }).select('_id buildingId').lean() : [];
  
  const floorIdToBuildingId = new Map(floorDocs.map((f) => [String(f._id), String(f.buildingId)]));
  const buildingIdsAll = [...new Set(floorDocs.map((f) => String(f.buildingId)))].map((id) => new mongoose.Types.ObjectId(id));
  const buildingDocs2 = buildingIdsAll.length ? await CampusBuilding.find({ 
    _id: { $in: buildingIdsAll }, 
    isDelete: { $ne: true }, 
    status: 1,
    campusId: { $in: activeCampusIds } // Only buildings from active campuses
  }).select('_id campusId name').lean() : [];
  
  const buildingIdToCampusId = new Map(buildingDocs2.map((b) => [String(b._id), String(b.campusId)]));
  const campusIdToName = new Map(campuses.map((c) => [String(c._id), c.name]));

  const zoneList = zones.map((z) => {
    const devicesForZone = zoneIdToDevices.get(String(z._id)) || [];
    const buildingId = floorIdToBuildingId.get(String(z.floorId));
    const campusId = buildingId ? buildingIdToCampusId.get(String(buildingId)) : null;
    
    // Only include zones that belong to active campuses
    if (!campusId || !activeCampusIds.some(id => String(id) === String(campusId))) {
      return null;
    }
    
    return {
      zoneId: z._id,
      zoneName: z.name,
      devices: devicesForZone,
      campusId: campusId ? new mongoose.Types.ObjectId(campusId) : null,
      campusName: campusId ? campusIdToName.get(String(campusId)) || null : null
    };
  }).filter(Boolean); // Remove null entries

  // Attach per-campus zone lists
  const campusCountsWithZones = Array.from(campusIdToCounts.values()).map((entry) => {
    const zonesForCampus = zoneList.filter((z) => String(z.campusId || '') === String(entry.campusId));
    return { ...entry, zonesList: zonesForCampus };
  });

  return {
    campusCounts: campusCountsWithZones
  };
}

/**
 * Get zone-level device statistics aggregated by type and status
 * 
 * Analyzes device capabilities to provide:
 * - LED statistics: installed/on/off counts based on status and brightness
 * - Shade statistics: installed/open/closed counts based on openLevel property
 * - Sensor statistics: installed/active/inactive counts for all sensor types
 * - Smart type detection for LEDs, shades, and various sensor categories
 * - Status analysis from device capabilities with fallback handling
 */
export async function getZoneStats(payload) {
  const zoneIds = toObjectIdArray(payload.zone_ids);
  
  let deviceFilter = { is_delete: { $ne: true } };
  
  if (zoneIds.length > 0) {
    // Filter by specific zone IDs provided
    deviceFilter.zone = { $in: zoneIds };
  } else {
    // If no zone IDs provided, only include devices from active, non-deleted zones
    const activeZones = await CampusZone.find({
      status: 1, // active zones only
      isDelete: { $ne: true } // non-deleted zones only
    })
    .select('_id')
    .lean();
    
    const activeZoneIds = activeZones.map(zone => zone._id);
    if (activeZoneIds.length > 0) {
      deviceFilter.zone = { $in: activeZoneIds };
    } else {
      // If no active zones exist, return empty stats
      deviceFilter.zone = { $in: [] };
    }
  }

  const devices = await Device.find(deviceFilter)
    .select('_id name capabilities')
    .lean();

  const result = {
    leds: { installed: 0, on: 0, off: 0 },
    shades: { installed: 0, open: 0, closed: 0 },
    sensors: { installed: 0, active: 0, inactive: 0 }
  };

  const isLedType = (t) => ['led', 'expansion_led', 'expansion_color_lights'].includes(String(t || '').toLowerCase());
  const isShadeType = (t) => String(t || '').toLowerCase() === 'shade';
  const isSensorType = (t) => String(t || '').toLowerCase().includes('sensor') || ['io_pir', 'rtu_co2', 'rtu_hmi'].includes(String(t || '').toLowerCase());

  for (const device of devices) {
    for (const cap of device.capabilities || []) {
      const type = String(cap.type || '').toLowerCase();
      const status = String(cap.status || '').toLowerCase();
      const installed = cap.installed === true || cap.properties?.installed === true;

      if (isLedType(type)) {
        if (installed) {
          result.leds.installed += 1;
          // LEDs with status 'on' or 'brightness' are considered 'on'
          if (status === 'on' || status === 'brightness') {
            result.leds.on += 1;
          } else {
            result.leds.off += 1;
          }
        }
      } else if (isShadeType(type)) {
        if (installed) {
          result.shades.installed += 1;
          // Check openLevel property to determine if shade is open or closed
          const openLevel = cap.properties?.openLevel || '0%';
          const isOpen = openLevel !== '0%' && openLevel !== '0';
          if (isOpen) result.shades.open += 1; else result.shades.closed += 1;
        }
      } else if (isSensorType(type)) {
        if (installed) {
          result.sensors.installed += 1;
          if (status === 'on' || status === 'active') result.sensors.active += 1; else result.sensors.inactive += 1;
        }
      }
    }
  }

  return result;
}

/**
 * Get comprehensive device information with scene associations
 * 
 * Retrieves detailed device context including:
 * - Scene associations (both device-type and group-type scenes)
 * - Channel analytics with LED/shade counts per scene
 * - Scene execution history and metadata (lastExecuted, executedBy, createdBy)
 * - Operational flags (invert_flag, operateType, status)
 * - Chronological sorting by creation date for operational context
 */
export async function getDeviceInfo(deviceId) {
  // Validate device ID is provided and is a string
  if (!deviceId || typeof deviceId !== 'string' || deviceId.trim().length === 0) {
    throw new Error('Valid device ID is required');
  }

  // Find the device by device_id field (e.g., "BAM-D71534")
  const device = await Device.findOne({ 
    device_id: deviceId.trim(), 
    is_delete: { $ne: true } 
  })
  .select('device_id _id')
  .lean();

  if (!device) {
    throw new Error('Device not found or has been deleted');
  }



  // Find all active scenes associated with this device
  const scenes = await Scene.find({
    isDeleted: false,
    status: 1, // active scenes only
    $or: [
      // Device-type scenes where this device is directly referenced
      {
        type: 'device',
        'Devices.deviceId': device.device_id
      },
      // Group-type scenes where this device is part of a group
      {
        type: 'group',
        'Groups.devices.deviceId': device.device_id
      }
    ]
  })
  .select('_id name type operateType status lastExecuted executedBy createdBy invert_flag Devices Groups createdAt')
  .lean();

  const sceneInfo = scenes.map(scene => {
    let ledCount = 0;
    let shadeCount = 0;

    // Count channels based on scene type
    if (scene.type === 'device' && scene.Devices) {
      // For device-type scenes, count channels in all devices
      scene.Devices.forEach(deviceEntry => {
        // Only count channels from the specific device we're querying for
        if (deviceEntry.deviceId === device.device_id) {
          deviceEntry.channels?.forEach(channel => {
            const channelType = String(channel.channelType || '').toLowerCase();
            if (channelType === 'led') {
              ledCount++;
            } else if (channelType === 'shade') {
              shadeCount++;
            }
          });
        }
      });
    } else if (scene.type === 'group' && scene.Groups) {
      // For group-type scenes, count channels in all devices within all groups
      scene.Groups.forEach(groupEntry => {
        groupEntry.devices?.forEach(deviceEntry => {
          // Only count channels from the specific device we're querying for
          if (deviceEntry.deviceId === device.device_id) {
            deviceEntry.channels?.forEach(channel => {
              const channelType = String(channel.channelType || '').toLowerCase();
              if (channelType === 'led') {
                ledCount++;
              } else if (channelType === 'shade') {
                shadeCount++;
              }
            });
          }
        });
      });
    }

    return {
      sceneId: scene._id,
      name: scene.name,
      type: scene.type,
      operateType: scene.operateType,
      status: scene.status,
      lastExecuted: scene.lastExecuted,
      executedBy: scene.executedBy,
      createdBy: scene.createdBy,
      invert_flag: scene.invert_flag || false,
      channelCounts: {
        leds: ledCount,
        shades: shadeCount
      },
      sceneLastExecuted: scene.lastExecuted,
      createdAt: scene.createdAt
    };
  });
 
  // Sort scenes by createdAt: newest created scene first (latest created at top)
  sceneInfo.sort((a, b) => {
    const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
    const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
    
    // Sort by createdAt (newest first - higher timestamp first)
    return dateB - dateA;
  });
 
  return {
    scenes: sceneInfo
  };
}

/**
 * Get all active groups containing a specific device
 * 
 * Provides device group context by:
 * - Finding all active groups containing the specified device
 * - Leveraging group.service.js getGroupViewData for consistent structure
 * - Removing location information for streamlined dashboard response
 * - Error handling for group processing failures
 * - Maintaining operational context for device management
 */
export async function getDeviceGroups(deviceId) {
  if (!deviceId || typeof deviceId !== 'string' || deviceId.trim().length === 0) {
    throw new Error('Valid device ID is required');
  }

  // Find the device to ensure it exists and is not deleted
  const device = await Device.findOne({ 
    device_id: deviceId.trim(), 
    is_delete: { $ne: true } 
  })
  .select('device_id')
  .lean();

  if (!device) {
    throw new Error('Device not found or has been deleted');
  }

  // Find all active groups that contain this device
  const groups = await Group.find({
    isDeleted: { $ne: true },
    'devices.deviceId': deviceId.trim()
  })
  .select('_id')
  .lean();

  // Use getGroupViewData for each group to get the same structure
  const { getGroupViewData } = await import('./group.service.js');
  
  const result = [];
  for (const group of groups) {
    try {
      const groupData = await getGroupViewData(group._id);
      // Remove location from devices
      if (groupData.devices) {
        groupData.devices = groupData.devices.map(device => {
          const { location, ...deviceWithoutLocation } = device;
          return deviceWithoutLocation;
        });
      }
      result.push(groupData);
    } catch (error) {
      console.error(`Error fetching group view data for group ${group._id}:`, error);
      // Skip groups that can't be processed
    }
  }

  return result;
}

/**
 * Get device-specific alerts with pagination for monitoring
 * 
 * Retrieves alert history with:
 * - Device-specific filtering (handles both device and deviceId fields)
 * - Type filtering for "Device" alerts only
 * - Chronological sorting (latest alerts first) for operational relevance
 * - Pagination with metadata for UI navigation
 * - Field normalization for consistent device reference
 */
export async function getAlerts(queryParams) {
  const page = parseInt(queryParams.page) || 1;
  const limit = parseInt(queryParams.limit) || 50;
  const skip = (page - 1) * limit;
  const { deviceId } = queryParams;

  // Filter for type "Device" and handle both device and deviceId fields
  const filter = {
    type: 'Device',
    $or: [
      { device: deviceId },
      { deviceId: deviceId }
    ]
  };

  // Get total count for pagination info
  const totalCount = await Log.countDocuments(filter);
  
  // Fetch logs with pagination, sorted by timestamp descending (latest first)
  const logs = await Log.find(filter)
    .sort({ timestamp: -1 })
    .skip(skip)
    .limit(limit)
    .select('action name timestamp type userId userName device deviceId deviceName')
    .lean();

  // Normalize logs to always use 'device' field
  const alerts = logs.map(log => ({
    ...log,
    device: log.device || log.deviceId
  }));

  // Calculate pagination metadata
  const totalPages = Math.ceil(totalCount / limit);
  const hasNextPage = page < totalPages;
  const hasPrevPage = page > 1;

  return {
    alerts,
    pagination: {
      currentPage: page,
      totalPages,
      totalCount,
      limit,
      hasNextPage,
      hasPrevPage
    }
  };
}


