import nodemailer from 'nodemailer';
import sgMail from '@sendgrid/mail';
import axios from 'axios';
import qs from 'querystring';
import { getConfig } from '../config/env.js';
import { emailSubject } from '../constants/emailSubjects.js';

class EmailService {
  constructor() {
    this.transporter = null;
    this.emailProvider = 'graph'; // Default to Microsoft Graph API
    this.initialized = false;
  }

  initializeTransporter() {
    if (this.initialized) return;
    
    console.log('📧 Initializing email service...');
    
    const config = getConfig();
    
    // Determine email provider based on configuration
    this.emailProvider = config.email.provider || 'smtp';
    
    console.log(`📧 Email provider configured: ${this.emailProvider}`);
    
    if (this.emailProvider === 'sendgrid') {
      this.initializeSendGrid(config);
    } else {
      this.initializeSMTP(config);
    }
    
    this.initialized = true;
    console.log('✅ Email service initialization completed');
  }

  initializeSMTP(config) {
    // Skip email setup in development if credentials not provided
    if (config.nodeEnv === 'development' && (!config.email.user || !config.email.pass)) {
      console.log('⚠️  Email service disabled - no SMTP credentials provided');
      return;
    }

    this.transporter = nodemailer.createTransport({
      host: config.email.host,
      port: config.email.port,
      secure: config.email.secure,
      auth: {
        user: config.email.user,
        pass: config.email.pass
      }
    });
    
    console.log('📧 Email service initialized with SMTP');
  }

  initializeSendGrid(config) {
    if (!config.sendgrid.apiKey) {
      console.log('⚠️  Email service disabled - no SendGrid API key provided');
      return;
    }

    sgMail.setApiKey(config.sendgrid.apiKey);
    console.log('📧 Email service initialized with SendGrid');
  }

  async sendPasswordResetEmail(email, resetToken, otp) {
    console.log(`📧 Preparing to send password reset email to: ${email}`);
    const config = getConfig();
    const resetUrl = `${config.reset.appUrl}/auth/reset-password?otp=${otp}&email=${encodeURIComponent(email)}`;
    
    console.log(`🔗 Reset URL generated for ${email}: ${resetUrl.replace(otp, '***OTP***')}`);

    const payload = {
      emailSubject: emailSubject.EMAIL_VERIFICATION_OTP,
      email_id: email,
      cc_email_id: email,
      otp: otp,
      resetUrl: resetUrl
    };

    console.log(`📨 Sending password reset email to ${email} using Microsoft Graph API`);
    console.log(`🔗 Reset URL: ${resetUrl}`);
    console.log(`🔢 OTP Code: ${otp}`);
    
    return this.sendMailFromGraphAPI(payload);
  }

  async sendPasswordChangedEmail(email) {
    const payload = {
      emailSubject: emailSubject.PASSWORD_CHANGED,
      email_id: email,
      cc_email_id: email
    };

    return this.sendMailFromGraphAPI(payload);
  }

  async sendMailFromGraphAPI(payload) {
    try {
      const tokenGraphAPI = await this.getGraphAPIToken();
      const authToken = tokenGraphAPI['token_type'] + " " + tokenGraphAPI['access_token'];
      const TOKEN_ENDPOINT = `https://graph.microsoft.com/v1.0/users/support@smartaxiom.com/sendMail`;

      let html = '';
      
      switch (payload.emailSubject) {
        case emailSubject.EMAIL_VERIFICATION_OTP:
          html = this.renderPasswordResetTemplate(payload);
          break;
        case emailSubject.PASSWORD_CHANGED:
          html = this.renderPasswordChangedTemplate(payload);
          break;
        case emailSubject.TRACKER_HUMIDITY_ALERT:
        case emailSubject.TRACKER_TEMPERATURE_ALERT:
        case emailSubject.GEOFENCE_ALERT:
          html = this.renderAlertTemplate(payload);
          break;
        default:
          throw new Error("Invalid email subject");
      }

      const data = {
        "message": {
          "subject": payload.emailSubject,
          "body": {
            "contentType": "HTML",
            "content": html
          },
          "toRecipients": [
            {
              "emailAddress": {
                "address": payload.email_id
              }
            }
          ],
          "ccRecipients": [
            {
              "emailAddress": {
                "address": payload.cc_email_id ? payload.cc_email_id : payload.email_id
              }
            }
          ]
        }
      };

      const headers = {
        'Content-Type': 'application/json',
        'Authorization': authToken,
        'Accept': 'application/json'
      };

      const response = await axios.post(TOKEN_ENDPOINT, data, { headers });
      console.log("Email has been sent via Graph API", response.status);
      return { success: true, messageId: response.headers['x-ms-request-id'] || 'graph-api' };
    } catch (error) {
      const errorMessage = error.response?.data?.error?.message || error.message || "An unknown error occurred while sending email via Graph API.";
      console.log("Error while sending email via Graph API:", errorMessage);
      throw new Error(errorMessage);
    }
  }

  renderPasswordResetTemplate(payload) {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #227EEB; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #f9f9f9; }
          .otp { font-size: 24px; font-weight: bold; color: #227EEB; text-align: center; margin: 20px 0; }
          .button { display: inline-block; padding: 12px 24px; background: #E6F0FC; color: white; text-decoration: none; border-radius: 4px; font-weight: bold; }
          .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #227EEB; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Password Reset Request</h1>
          </div>
          <div class="content">
            <p>Hello,</p>
            <p>We received a request to reset your password for your Smart Axiom account.</p>
            
            <h3>Reset Your Password</h3>
            <p>Click the button below to reset your password:</p>
            <p style="text-align: center;">
              <a href="${payload.resetUrl}" class="button">Reset Password</a>
            </p>
            
            <p><strong>Your OTP Code:</strong></p>
            <div class="otp">${payload.otp}</div>
            
            <p><strong>Important:</strong></p>
            <ul>
              <li>This reset link and OTP will expire in 15 minutes</li>
              <li>If you didn't request this, please ignore this email</li>
              <li>Never share your OTP with anyone</li>
            </ul>
          </div>
          <div class="footer">
            <p>This is an automated message from Smart Axiom. Please do not reply to this email.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  renderPasswordChangedTemplate(payload) {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #28a745; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #f9f9f9; }
          .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Password Changed Successfully</h1>
          </div>
          <div class="content">
            <p>Hello,</p>
            <p>Your password has been successfully changed for your Smart Axiom account.</p>
            <p><strong>Security Notice:</strong></p>
            <ul>
              <li>Time: ${new Date().toLocaleString()}</li>
              <li>If you didn't make this change, please contact support immediately</li>
              <li>All active sessions have been invalidated for security</li>
            </ul>
            <p>For your security, you'll need to log in again with your new password.</p>
          </div>
          <div class="footer">
            <p>This is an automated message from Smart Axiom. Please do not reply to this email.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  renderAlertTemplate(payload) {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #dc3545; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #f9f9f9; }
          .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Alert Notification</h1>
          </div>
          <div class="content">
            <p>Hello,</p>
            <p>This is an alert notification from your Smart Axiom system.</p>
            <p>Alert details: ${payload.alertMessage || 'Alert triggered'}</p>
          </div>
          <div class="footer">
            <p>This is an automated message from Smart Axiom. Please do not reply to this email.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  async getGraphAPIToken() {
    try {
      const config = getConfig();
      const TOKEN_ENDPOINT = `${config.graph.tokenUrl}dae58b99-869f-4890-a068-4fa6602bbfae/oauth2/v2.0/token`;

      const postData = {
        client_id: config.graph.appId,
        scope: config.graph.scope,
        client_secret: config.graph.appSecret,
        grant_type: "client_credentials"
      };

      const response = await axios.post(TOKEN_ENDPOINT, qs.stringify(postData), {
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
      });

      return response.data;
    } catch (error) {
      const errorMessage = error.response?.data?.error_description || error.response?.data?.error?.message || error.message || "An unknown error occurred while fetching Graph API token.";
      console.log("Error while fetching Graph API token:", errorMessage);
      throw new Error(errorMessage);
    }
  }

  async sendEmail(emailTemplate) {
    if (!this.initialized) this.initializeTransporter();
    
    if (this.emailProvider === 'sendgrid') {
      return this.sendEmailWithSendGrid(emailTemplate);
    } else {
      return this.sendEmailWithSMTP(emailTemplate);
    }
  }

  async sendEmailWithSMTP(emailTemplate) {
    if (!this.transporter) {
      console.log(`📧 SMTP Email service disabled in development for: ${emailTemplate.to}`);
      return { success: true, message: 'Email service disabled in development' };
    }

    try {
      console.log(`📤 Sending SMTP email to: ${emailTemplate.to}, Subject: ${emailTemplate.subject}`);
      const info = await this.transporter.sendMail(emailTemplate);
      console.log(`✅ SMTP Email sent successfully to: ${emailTemplate.to}, MessageId: ${info.messageId}`);
      return { success: true, messageId: info.messageId };
    } catch (error) {
      console.error(`❌ SMTP Email error for ${emailTemplate.to}:`, error);
      throw new Error('Failed to send email via SMTP');
    }
  }

  async sendEmailWithSendGrid(emailTemplate) {
    try {
      console.log(`📤 Sending SendGrid email to: ${emailTemplate.to}, Subject: ${emailTemplate.subject}`);
      
      const msg = {
        to: emailTemplate.to,
        from: emailTemplate.from,
        subject: emailTemplate.subject,
        text: emailTemplate.text,
        html: emailTemplate.html,
      };

      const response = await sgMail.send(msg);
      console.log(`✅ SendGrid Email sent successfully to: ${emailTemplate.to}, MessageId: ${response[0].headers['x-message-id']}, StatusCode: ${response[0].statusCode}`);
      
      return { 
        success: true, 
        messageId: response[0].headers['x-message-id'],
        statusCode: response[0].statusCode 
      };
    } catch (error) {
      console.error(`❌ SendGrid Email error for ${emailTemplate.to}:`, error);
      if (error.response) {
        console.error('SendGrid Error Details:', error.response.body);
      }
      throw new Error('Failed to send email via SendGrid');
    }
  }

  async verifyConnection() {
    try {
      await this.getGraphAPIToken();
      return { success: true, message: 'Microsoft Graph API connection verified' };
    } catch (error) {
      return { success: false, message: `Graph API connection failed: ${error.message}` };
    }
  }

  async verifySMTPConnection() {
    if (!this.transporter) {
      return { success: false, message: 'SMTP Email service not configured' };
    }

    try {
      await this.transporter.verify();
      return { success: true, message: 'SMTP Email service connected' };
    } catch (error) {
      return { success: false, message: error.message };
    }
  }

  async verifySendGridConnection() {
    try {
      const config = getConfig();
      if (!config.sendgrid.apiKey) {
        return { success: false, message: 'SendGrid API key not configured' };
      }
      
      return { success: true, message: 'SendGrid Email service configured' };
    } catch (error) {
      return { success: false, message: error.message };
    }
  }
}

export const emailService = new EmailService();
