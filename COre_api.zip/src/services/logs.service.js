import Message from '../models/Message.js';
import { Campus } from '../models/Campus.js';
import { CampusBuilding } from '../models/CampusBuilding.js';
import { CampusFloor } from '../models/CampusFloor.js';
import { CampusZone } from '../models/CampusZone.js';
import readXlsxFile from 'read-excel-file/node';
import fs from 'fs';
import path from 'path';
import * as XLSX from 'xlsx';

/**
 * Logs Service - Comprehensive system audit and monitoring backend
 * 
 * Flow: logs.controller.js → logs.service.js → MongoDB (Message/Log Collections)
 * 
 * Provides enterprise-grade logging capabilities:
 * - MQTT device communication tracking with payload analysis
 * - Event audit trails for compliance and security monitoring  
 * - Advanced filtering: device, topic, channel, date/time ranges
 * - Excel export for offline analysis and regulatory reporting
 * - Campus hierarchy integration for contextual log filtering
 * - Real-time system health monitoring and troubleshooting
 */

/**
 * Helper function to format date with timezone
 * @param {Date} date - Date to format
 * @param {string} timezone - Timezone to convert to (optional)
 * @returns {string} Formatted date string
 */
const formatDateWithTimezone = (date, timezone) => {
  if (!date) return '';
  
  if (timezone) {
    try {
      // Convert to specified timezone and format as DD/MM/YYYY, HH:mm:ss
      return new Date(date).toLocaleString("en-GB", {
        timeZone: timezone,
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
      });
    } catch (error) {
      console.warn(`Invalid timezone ${timezone}, falling back to default format`);
      // Fall back to default format if timezone is invalid
      return new Date(date).toLocaleString("en-GB", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
      });
    }
  }
  
  // Default format without timezone conversion
  return new Date(date).toLocaleString("en-GB", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });
};

/**
 * Get MQTT logs with comprehensive filtering and pagination
 * 
 * Retrieves device communication logs from Message collection with:
 * - Device-specific filtering (device_id, topic, channeltype)
 * - Advanced search across multiple fields (id, control_topic, message)
 * - Date range and time slot filtering for precise analysis
 * - Pagination with configurable sorting (createdAt default)
 * - Payload parsing for structured command data
 * 
 * @param {Object} queryParams - Query parameters for filtering and pagination
 * @param {Object} user - The authenticated user object
 * @returns {Object} MQTT logs with pagination info
 */
export const getMqttLogs = async (queryParams, user) => {
  try {
    // Removed user permission check - return all data

    const {
      device_id,
      topic,
      channeltype,
      page = 1,
      limit = 10,
      sort = 'createdAt',
      order = 'desc',
      status,
      search,
      startDate,
      endDate,
      startTime,
      endTime
    } = queryParams;

    // Build query object
    const query = {};

    // Filter by device_id if provided
    if (device_id) {
      query.id = device_id;
    }

    // Filter by topic if provided
    if (topic) {
      query.control_topic = { $regex: topic, $options: 'i' };
    }

    // Filter by channeltype if provided
    if (channeltype) {
      query['message.channeltype'] = { $regex: channeltype, $options: 'i' };
    }

    // Global search functionality - searches across multiple fields
    if (search && search.trim()) {
      const searchRegex = { $regex: search.trim(), $options: 'i' };
      query.$or = [
        { id: searchRegex },
        { 'control_topic': searchRegex },
        { 'message': searchRegex },
      ];
    }

    // Date range filter
    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) {
        query.createdAt.$gte = new Date(startDate);
      }
      if (endDate) {
        query.createdAt.$lte = new Date(endDate);
      }
    }

    // Time slot filter - filter by specific time ranges within days
    if (startTime && endTime) {
      const timeQuery = {
        $expr: {
          $and: [
            {
              $gte: [
                {
                  $dateToString: {
                    format: "%H:%M",
                    date: "$createdAt"
                  }
                },
                startTime
              ]
            },
            {
              $lte: [
                {
                  $dateToString: {
                    format: "%H:%M",
                    date: "$createdAt"
                  }
                },
                endTime
              ]
            }
          ]
        }
      };
      
      if (query.$and) {
        query.$and.push(timeQuery);
      } else {
        query.$and = [timeQuery];
      }
    }

    // Pagination
    const pageNum = parseInt(page, 10);
    const pageSize = parseInt(limit, 10);
    const skip = (pageNum - 1) * pageSize;

    // Sort configuration
    const sortField = sort === 'createdAt' ? 'createdAt' : sort;
    const sortOrder = order === 'desc' ? -1 : 1;
    const sortObj = { [sortField]: sortOrder };

    // Execute query with pagination
    const [logs, total] = await Promise.all([
      Message.find(query)
        .sort(sortObj)
        .skip(skip)
        .limit(pageSize)
        .lean(),
      Message.countDocuments(query)
    ]);

    // Transform data to match required output format
    const transformedLogs = logs.map(log =>
    {
      const payloadObj = JSON.parse(JSON.parse(log.message)?.payload);
      
      if (payloadObj.cmd_m) {
        payloadObj.cmd_m = JSON.stringify(payloadObj.cmd_m);
        if(!payloadObj.cmd_m.includes('LED_BRIGHTNESS')) 
          payloadObj.cmd_m = JSON.parse(payloadObj.cmd_m);
        
      }
      return {
        id: log._id,
        id: log.id,
        control_topic: log.control_topic || '',
        cmd: JSON.parse(log.message)?.cmd || '',
        messageId: JSON.parse(log.message)?.messageId || '',
        payload: payloadObj,
        status: log.status || 1,
        createdAt: log.createdAt
      }
    });

    // Pagination info
    const totalPages = Math.ceil(total / pageSize);
    const hasNextPage = pageNum < totalPages;
    const hasPrevPage = pageNum > 1;

    return {
      logs: transformedLogs,
      pagination: {
        current_page: pageNum,
        total_pages: totalPages,
        total_records: total,
        per_page: pageSize,
        has_next_page: hasNextPage,
        has_prev_page: hasPrevPage
      },
      summary: {
        total_logs: total,
        current_page_count: transformedLogs.length
      }
    };
  } catch (error) {
    console.error('Error in getMqttLogs service:', error);
    throw new Error(`Failed to fetch MQTT logs: ${error.message}`);
  }
};

/**
 * Get event logs for audit trail and compliance tracking
 * 
 * Retrieves system event logs from Log collection with:
 * - Audit-focused fields: _id, type, name, action, timestamp
 * - Device and action-based filtering for investigation
 * - Global search across type, name, and action fields
 * - Unix timestamp handling for consistent time representation
 * - Compliance-ready data structure for regulatory requirements
 * 
 * @param {Object} queryParams - Query parameters for filtering and pagination
 * @param {Object} user - The authenticated user object
 * @returns {Object} Event logs with pagination info
 */
export const getEventLogs = async (queryParams, user) => {
  try {
    // Removed user permission check - return all data

    const {
      device_id,
      type,
      action,
      page = 1,
      limit = 10,
      sort = 'timestamp',
      order = 'desc',
      search,
      startDate,
      endDate,
      startTime,
      endTime
    } = queryParams;

    // Build query object for Log collection
    const query = {};

    // Filter by device_id (userId) if provided
    if (device_id) {
      query.userId = device_id;
    }

    // Filter by type if provided
    if (type) {
      query.type = { $regex: type, $options: 'i' };
    }

    // Filter by action if provided
    if (action) {
      query.action = { $regex: action, $options: 'i' };
    }

    // Global search functionality - searches only in type, name, and action fields
    if (search && search.trim()) {
      const searchRegex = { $regex: search.trim(), $options: 'i' };
      query.$or = [
        { type: searchRegex },
        { name: searchRegex },
        { action: searchRegex }
      ];
    }

    // Date range filter (timestamp is a number in seconds, not milliseconds)
    if (startDate || endDate) {
      query.timestamp = {};
      if (startDate) {
        // Convert to Unix timestamp (seconds)
        query.timestamp.$gte = Math.floor(new Date(startDate).getTime() / 1000);
      }
      if (endDate) {
        // Convert to Unix timestamp (seconds) and add 24 hours to include the entire end date
        const endDateTime = new Date(endDate);
        endDateTime.setHours(23, 59, 59, 999);
        query.timestamp.$lte = Math.floor(endDateTime.getTime() / 1000);
      }
    }

    // Time slot filter - filter by specific time ranges within days
    if (startTime && endTime) {
      const timeQuery = {
        $expr: {
          $and: [
            {
              $gte: [
                {
                  $dateToString: {
                    format: "%H:%M",
                    date: { $toDate: { $multiply: ["$timestamp", 1000] } }
                  }
                },
                startTime
              ]
            },
            {
              $lte: [
                {
                  $dateToString: {
                    format: "%H:%M",
                    date: { $toDate: { $multiply: ["$timestamp", 1000] } }
                  }
                },
                endTime
              ]
            }
          ]
        }
      };
      
      if (query.$and) {
        query.$and.push(timeQuery);
      } else {
        query.$and = [timeQuery];
      }
    }


    // Pagination
    const pageNum = parseInt(page, 10);
    const pageSize = parseInt(limit, 10);
    const skip = (pageNum - 1) * pageSize;

    // Sort configuration - use timestamp and _id for consistent ordering
    const sortField = sort === 'timestamp' ? 'timestamp' : sort;
    const sortOrder = order === 'desc' ? -1 : 1;
    const sortObj = { [sortField]: sortOrder, _id: sortOrder };

    // Execute query with pagination on Log collection
    const Log = (await import('../models/Log.js')).default;
    const [logs, total] = await Promise.all([
      Log.find(query)
        .select('_id type name action timestamp userId userName')
        .sort(sortObj)
        .skip(skip)
        .limit(pageSize)
        .lean(),
      Log.countDocuments(query)
    ]);

    // Transform data to match required output format (_id, type, name, action, timestamp)
    const transformedLogs = logs.map(log => ({
      _id: log._id,
      type: log.type || '',
      name: log.name || '',
      action: log.action || '',
      timestamp: log.timestamp, // Return raw Unix timestamp for frontend to handle
      userId: log.userId,
      userName: log.userName
    }));

    // Pagination info
    const totalPages = Math.ceil(total / pageSize);
    const hasNextPage = pageNum < totalPages;
    const hasPrevPage = pageNum > 1;

    return {
      logs: transformedLogs,
      pagination: {
        current_page: pageNum,
        total_pages: totalPages,
        total_records: total,
        per_page: pageSize,
        has_next_page: hasNextPage,
        has_prev_page: hasPrevPage
      },
      summary: {
        total_logs: total,
        current_page_count: transformedLogs.length
      }
    };
  } catch (error) {
    console.error('Error in getEventLogs service:', error);
    throw new Error(`Failed to fetch event logs: ${error.message}`);
  }
};

/**
 * Get campus hierarchy for log filtering context
 * 
 * Builds nested hierarchy structure: campus → building → floor → zone
 * with user-specific access control:
 * - Filters by status=1 and isDelete=false across all levels
 * - Applies user allowedResources permissions for data scoping
 * - Includes isChecked based on user's campusData for UI state
 * - Supports both unrestricted (admin) and filtered (user) access modes
 * - Optimized aggregation for efficient hierarchy construction
 * 
 * @param {Object} user - The authenticated user object
 * @returns {Array} Campus hierarchy data with isChecked properties
 */
export const getCampusHierarchy = async (user) => {
  try {
    const allowed = user?.allowedResources?.campusManagement;
    let campuses, buildings, floors, zones;
    if (!allowed) {
      // Show all if allowedResources is null or missing
      campuses = await Campus.find({ status: 1, isDelete: false })
        .select('_id name location')
        .sort({ createdAt: -1 })
        .lean();
      if (!campuses || campuses.length === 0) return [];
      const campusIds = campuses.map(c => c._id);
      buildings = await CampusBuilding.find({ campusId: { $in: campusIds }, status: 1, isDelete: false })
        .select('_id name campusId')
        .lean();
      const buildingIds = buildings.map(b => b._id);
      floors = await CampusFloor.find({ buildingId: { $in: buildingIds }, status: 1, isDelete: false })
        .select('_id name buildingId')
        .lean();
      const floorIds = floors.map(f => f._id);
      zones = await CampusZone.find({ floorId: { $in: floorIds }, status: 1, isDelete: false })
        .select('_id name floorId')
        .lean();
      // Group zones by floor
      const zonesByFloor = zones.reduce((acc, zone) => {
        const floorId = zone.floorId.toString();
        if (!acc[floorId]) acc[floorId] = [];
        acc[floorId].push({
          id: zone._id.toString(),
          name: zone.name,
          isChecked: isEntityChecked(zone._id.toString(), [], user, 'zone')
        });
        return acc;
      }, {});
      // Group floors by building
      const floorsByBuilding = floors.reduce((acc, floor) => {
        const buildingId = floor.buildingId.toString();
        if (!acc[buildingId]) acc[buildingId] = [];
        acc[buildingId].push({
          id: floor._id.toString(),
          name: floor.name,
          isChecked: isEntityChecked(floor._id.toString(), [], user, 'floor'),
          zones: zonesByFloor[floor._id.toString()] || []
        });
        return acc;
      }, {});
      // Group buildings by campus
      const buildingsByCampus = buildings.reduce((acc, building) => {
        const campusId = building.campusId.toString();
        if (!acc[campusId]) acc[campusId] = [];
        acc[campusId].push({
          id: building._id.toString(),
          name: building.name,
          isChecked: isEntityChecked(building._id.toString(), [], user, 'building'),
          floors: floorsByBuilding[building._id.toString()] || []
        });
        return acc;
      }, {});
      // Build final result
      const result = campuses.map(campus => ({
        id: campus._id.toString(),
        name: campus.name,
        location: campus.location,
        isChecked: isEntityChecked(campus._id.toString(), [], user, 'campus'),
        buildings: buildingsByCampus[campus._id.toString()] || []
      }));
      return result;
    }
    // Filtered mode (as before)
    const allowedCampuses = allowed.campuses || [];
    const allowedBuildings = allowed.buildings || [];
    const allowedFloors = allowed.floors || [];
    const allowedZones = allowed.zones || [];
    campuses = await Campus.find({ _id: { $in: allowedCampuses }, status: 1, isDelete: false })
      .select('_id name location')
      .sort({ createdAt: -1 })
      .lean();
    if (!campuses || campuses.length === 0) return [];
    const campusIds = campuses.map(campus => campus._id);
    buildings = await CampusBuilding.find({ _id: { $in: allowedBuildings }, campusId: { $in: campusIds }, status: 1, isDelete: false })
      .select('_id name campusId')
      .lean();
    if (!buildings || buildings.length === 0) {
      return campuses.map(campus => ({
        id: campus._id.toString(),
        name: campus.name,
        location: campus.location,
        isChecked: isEntityChecked(campus._id.toString(), [], user, 'campus'),
        buildings: []
      }));
    }
    const buildingIds = buildings.map(building => building._id);
    floors = await CampusFloor.find({ _id: { $in: allowedFloors }, buildingId: { $in: buildingIds }, status: 1, isDelete: false })
      .select('_id name buildingId')
      .lean();
    if (!floors || floors.length === 0) {
      const buildingsByCampus = buildings.reduce((acc, building) => {
        const campusId = building.campusId.toString();
        if (!acc[campusId]) acc[campusId] = [];
        acc[campusId].push({
          id: building._id.toString(),
          name: building.name,
          isChecked: isEntityChecked(building._id.toString(), [], user, 'building'),
          floors: []
        });
        return acc;
      }, {});
      return campuses.map(campus => ({
        id: campus._id.toString(),
        name: campus.name,
        location: campus.location,
        isChecked: isEntityChecked(campus._id.toString(), [], user, 'campus'),
        buildings: buildingsByCampus[campus._id.toString()] || []
      }));
    }
    const floorIds = floors.map(floor => floor._id);
    zones = await CampusZone.find({ _id: { $in: allowedZones }, floorId: { $in: floorIds }, status: 1, isDelete: false })
      .select('_id name floorId')
      .lean();
    const zonesByFloor = zones.reduce((acc, zone) => {
      const floorId = zone.floorId.toString();
      if (!acc[floorId]) acc[floorId] = [];
      acc[floorId].push({
        id: zone._id.toString(),
        name: zone.name,
        isChecked: isEntityChecked(zone._id.toString(), [], user, 'zone')
      });
      return acc;
    }, {});
    const floorsByBuilding = floors.reduce((acc, floor) => {
      const buildingId = floor.buildingId.toString();
      if (!acc[buildingId]) acc[buildingId] = [];
      acc[buildingId].push({
        id: floor._id.toString(),
        name: floor.name,
        isChecked: isEntityChecked(floor._id.toString(), [], user, 'floor'),
        zones: zonesByFloor[floor._id.toString()] || []
      });
      return acc;
    }, {});
    const buildingsByCampus = buildings.reduce((acc, building) => {
      const campusId = building.campusId.toString();
      if (!acc[campusId]) acc[campusId] = [];
      acc[campusId].push({
        id: building._id.toString(),
        name: building.name,
        isChecked: isEntityChecked(building._id.toString(), [], user, 'building'),
        floors: floorsByBuilding[building._id.toString()] || []
      });
      return acc;
    }, {});
    const result = campuses.map(campus => ({
      id: campus._id.toString(),
      name: campus.name,
      location: campus.location,
      isChecked: isEntityChecked(campus._id.toString(), [], user, 'campus'),
      buildings: buildingsByCampus[campus._id.toString()] || []
    }));
    return result;
  } catch (error) {
    console.error('Error in getCampusHierarchy service:', error);
    throw new Error(`Failed to fetch campus hierarchy: ${error.message}`);
  }
};

/**
 * Helper function to check if an entity is in the user's campusData
 * isChecked will be true only for items that exist in campusData
 * @param {string} entityId - The ID of the entity to check
 * @param {Array} allowedIds - Array of allowed IDs for this entity type from allowedResources (kept for backward compatibility, not used)
 * @param {Object} user - The user object containing campusData
 * @param {string} entityType - Type of entity: 'campus', 'building', 'floor', 'zone'
 * @returns {boolean} True if entity is in campusData, false otherwise
 */
const isEntityChecked = (entityId, allowedIds = [], user = null, entityType = '') => {
  // Only check in campusData
  if (user && user.campusData && Array.isArray(user.campusData) && user.campusData.length > 0) {
    switch (entityType) {
      case 'campus':
        return user.campusData.some(campus => campus.campus_id === entityId);
      
      case 'building':
        return user.campusData.some(campus => 
          campus.buildings && campus.buildings.some(building => building.building_id === entityId)
        );
      
      case 'floor':
        return user.campusData.some(campus => 
          campus.buildings && campus.buildings.some(building => 
            building.floors && building.floors.some(floor => floor.floor_id === entityId)
          )
        );
      
      case 'zone':
        return user.campusData.some(campus => 
          campus.buildings && campus.buildings.some(building => 
            building.floors && building.floors.some(floor => 
              floor.zones && floor.zones.some(zone => zone.zone_id === entityId)
            )
          )
        );
      
      default:
        return false;
    }
  }
  
  return false;
};

/**
 * Export MQTT logs to Excel for offline analysis
 * 
 * Generates comprehensive Excel report with:
 * - Device communication details (DeviceID, Topic, Command)
 * - Structured payload data (Channel Type/Address, Command Number)
 * - Timezone-aware timestamp formatting for global teams
 * - Auto-sized columns and proper alignment for readability
 * - Configurable data limit (10,000 records) for performance
 * 
 * @param {Object} queryParams - Query parameters for filtering
 * @param {Object} user - The authenticated user object
 * @returns {Buffer} Excel file buffer
 */
export const exportMqttLogsToExcel = async (queryParams, user) => {
  try {
    const { logs } = await getMqttLogs({ ...queryParams, limit: 10000, page: 1 }, user);
    const { timezone } = queryParams;
    
    const data = [
      ['Sno', 'DeviceID', 'Control Topic', 'Command', 'Command Message', 'Channel Type', 'Channel Address', 'Command Number', 'Message Id', 'Created At'],
      ...logs.map((log, index) => {
        const payload = log.payload || {};
        const channelAddress = Array.isArray(payload.ch_addr)
          ? payload.ch_addr.join(', ') // ✅ join array values
          : payload.ch_addr || '';     // fallback if it's not an array

        return [
          index + 1, // Serial number
          log.id || '',
          log.control_topic || '',
          payload.cmd || log.cmd || '',
          payload.cmd_m || '',
          payload.ch_t || '',
          channelAddress,
          payload.cmd || '',
          log.messageId || '',
          formatDateWithTimezone(log.createdAt, timezone)
        ];
      })
    ];

    const ws = XLSX.utils.aoa_to_sheet(data);

    // Column widths
    ws['!cols'] = [
      { width: 8 },
      { width: 15 },
      { width: 35 },
      { width: 12 },
      { width: 18 },
      { width: 15 },
      { width: 18 },
      { width: 15 },
      { width: 15 },
      { width: 20 }
    ];

    // Alignment
    const range = XLSX.utils.decode_range(ws['!ref']);
    for (let R = range.s.r; R <= range.e.r; ++R) {
      for (let C = range.s.c; C <= range.e.c; ++C) {
        const cellAddress = XLSX.utils.encode_cell({ r: R, c: C });
        if (!ws[cellAddress]) continue;
        if (!ws[cellAddress].s) ws[cellAddress].s = {};
        ws[cellAddress].s.alignment = { horizontal: 'left' };
      }
    }

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'MQTT Logs');
    return XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  } catch (error) {
    console.error('Error in exportMqttLogsToExcel service:', error);
    throw new Error(`Failed to export MQTT logs: ${error.message}`);
  }
};

/**
 * Export Event logs to Excel
 * @param {Object} queryParams - Query parameters for filtering
 * @param {Object} user - The authenticated user object
 * @returns {Buffer} Excel file buffer
 */
export const exportEventLogsToExcel = async (queryParams, user) => {
  try {
    const { logs } = await getEventLogs({ ...queryParams, limit: 10000, page: 1 }, user);
    const { timezone } = queryParams;
    
    const data = [
      ['S No', 'Type', 'Name', 'Action', 'Event Time'],
      ...logs.map((log, index) => [
        index + 1, // Serial number starting from 1
        log.type || '',
        log.name || '',
        log.action || '',
        log.timestamp ? formatDateWithTimezone(new Date(log.timestamp * 1000), timezone) : '' // Convert Unix timestamp (seconds) to milliseconds and format with timezone
      ])
    ];
    
    const ws = XLSX.utils.aoa_to_sheet(data);
    
    // Auto-size columns
    const colWidths = [
      { width: 10 }, // S No
      { width: 15 }, // Type
      { width: 25 }, // Name
      { width: 20 }, // Action
      { width: 20 }  // Event Time
    ];
    ws['!cols'] = colWidths;
    
    // Set left alignment for all cells
    const range = XLSX.utils.decode_range(ws['!ref']);
    for (let R = range.s.r; R <= range.e.r; ++R) {
      for (let C = range.s.c; C <= range.e.c; ++C) {
        const cellAddress = XLSX.utils.encode_cell({ r: R, c: C });
        if (!ws[cellAddress]) continue;
        if (!ws[cellAddress].s) ws[cellAddress].s = {};
        ws[cellAddress].s.alignment = { horizontal: 'left' };
      }
    }
    
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Event Logs');
    
    return XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  } catch (error) {
    console.error('Error in exportEventLogsToExcel service:', error);
    throw new Error(`Failed to export Event logs: ${error.message}`);
  }
};

/**
 * Read Excel file utility
 * @param {Object} path - File path object
 * @returns {Promise} Rows from Excel file
 */
export const readXlsx2 = function (path) {
  return new Promise((resolve, reject) => {
    try {
      readXlsxFile(path.path).then((rows) => {
        fs.unlinkSync(path.path);
        return resolve(rows);
      });
    } catch (err) {
      return reject(err);
    }
  });
};

// /**
//  * Get MQTT log statistics
//  * @param {Object} queryParams - Query parameters for filtering
//  * @returns {Object} Log statistics
//  */
// export const getMqttLogStats = async (queryParams) => {
//   try {
//     const { device_id, startDate, endDate } = queryParams;

//     // Build match stage for aggregation
//     const matchStage = {};
    
//     if (device_id) {
//       matchStage.id = device_id;
//     }

//     if (startDate || endDate) {
//       matchStage.createdAt = {};
//       if (startDate) {
//         matchStage.createdAt.$gte = new Date(startDate);
//       }
//       if (endDate) {
//         matchStage.createdAt.$lte = new Date(endDate);
//       }
//     }

//     // Aggregation pipeline for statistics
//     const pipeline = [
//       { $match: matchStage },
//       {
//         $group: {
//           _id: null,
//           total_logs: { $sum: 1 },
//           unique_devices: { $addToSet: '$id' },
//           unique_topics: { $addToSet: '$message.topic' },
//           latest_log: { $max: '$createdAt' },
//           earliest_log: { $min: '$createdAt' }
//         }
//       },
//       {
//         $project: {
//           _id: 0,
//           total_logs: 1,
//           unique_devices_count: { $size: '$unique_devices' },
//           unique_topics_count: { $size: '$unique_topics' },
//           latest_log: 1,
//           earliest_log: 1
//         }
//       }
//     ];

//     const stats = await Message.aggregate(pipeline);

//     return stats.length > 0 ? stats[0] : {
//       total_logs: 0,
//       unique_devices_count: 0,
//       unique_topics_count: 0,
//       latest_log: null,
//       earliest_log: null
//     };
//   } catch (error) {
//     console.error('Error in getMqttLogStats service:', error);
//     throw new Error(`Failed to fetch MQTT log statistics: ${error.message}`);
//   }
// };
