import mongoose from 'mongoose';
import { Campus } from '../models/Campus.js';
import { CampusBuilding } from '../models/CampusBuilding.js';
import { CampusFloor } from '../models/CampusFloor.js';
import { CampusZone } from '../models/CampusZone.js';

/**
 * Optimized Service - High-performance database queries with user access control
 * 
 * Provides optimized database operations for campus hierarchy with efficient filtering.
 * Used by controllers for paginated listings with user access control at database level.
 * 
 * Key Features:
 * - Database-level user access filtering (no post-query filtering)
 * - Parallel count queries for statistics (active/inactive/deleted)
 * - Efficient pagination with proper sorting
 * - Minimal data transfer with selective population
 * - Consistent response format across all entity types
 */

// Get optimized campuses list with database-level user filtering and statistics
export const getOptimizedCampuses = async (queryParams = {}) => {
  const {
    page = 1,
    limit = 20,
    status,
    type,
    organization,
    search,
    name,
    location,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    userFilter
  } = queryParams;

  // Start with user filter if provided, otherwise build base filter
  let filter = userFilter ? { ...userFilter } : {
    isDelete: { $ne: true },
    status: 1
  };

  // Apply additional filters
  const additionalFilters = [];

  if (status !== undefined) {
    additionalFilters.push({ status });
  }

  if (type) {
    additionalFilters.push({ type });
  }

  if (organization) {
    additionalFilters.push({ organization: { $regex: organization, $options: 'i' } });
  }

  // Enhanced search functionality
  const searchConditions = [];

  if (search) {
    searchConditions.push({
      $or: [
        { name: { $regex: search, $options: 'i' } },
        { location: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { accessId: { $regex: search, $options: 'i' } }
      ]
    });
  }

  if (name) {
    searchConditions.push({
      name: { $regex: name, $options: 'i' }
    });
  }

  if (location) {
    searchConditions.push({
      location: { $regex: location, $options: 'i' }
    });
  }

  // Combine all filters
  const allFilters = [...additionalFilters, ...searchConditions];
  if (allFilters.length > 0) {
    if (!filter.$and) filter.$and = [];
    filter.$and.push(...allFilters);
  }

  // Calculate skip value for pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);

  // Get sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // Create deep copies of the filter for calculating totals based on user access
  const activeFilter = JSON.parse(JSON.stringify(filter));
  const inactiveFilter = JSON.parse(JSON.stringify(filter));
  
  // Add status filters for totals calculation
  if (!activeFilter.$and) activeFilter.$and = [];
  if (!inactiveFilter.$and) inactiveFilter.$and = [];
  
  // Remove any existing status filters and add the specific ones we need
  activeFilter.$and = activeFilter.$and.filter(condition => !condition.status);
  inactiveFilter.$and = inactiveFilter.$and.filter(condition => !condition.status);
  
  activeFilter.$and.push({ status: 1 });
  inactiveFilter.$and.push({ status: 0 });

  // Execute query with pagination and get total counts in parallel
  const [campuses, total, totalActive, totalInactive] = await Promise.all([
    Campus.find(filter)
      .populate('createdBy.userId', 'fullName email')
      .populate('updatedBy.userId', 'fullName email')
      .sort(sort)
      .skip(skip)
      .limit(parseInt(limit))
      .lean(),
    Campus.countDocuments(filter),
    // Total active campuses based on user filter
    Campus.countDocuments(activeFilter),
    // Total inactive campuses based on user filter
    Campus.countDocuments(inactiveFilter)
  ]);

  // Calculate totalNonDeleted as sum of active and inactive
  const totalNonDeleted = totalActive + totalInactive;

  // Add building, floor, and zone counts for each campus in parallel
  const campusesWithCounts = await Promise.all(
    campuses.map(async (campus) => {
      const [buildingCount, floorCount, zoneCount] = await Promise.all([
        CampusBuilding.countDocuments({
          campusId: campus._id,
          isDelete: { $ne: true },
          status: 1
        }),
        CampusFloor.countDocuments({
          buildingId: { $in: await CampusBuilding.find({ campusId: campus._id, isDelete: { $ne: true } }).distinct('_id') },
          deleted: { $ne: true },
          status: 1
        }),
        CampusZone.countDocuments({
          floorId: { $in: await CampusFloor.find({
            buildingId: { $in: await CampusBuilding.find({ campusId: campus._id, isDelete: { $ne: true } }).distinct('_id') },
            deleted: { $ne: true }
          }).distinct('_id') },
          isDelete: { $ne: true },
          status: 1
        })
      ]);

      return {
        ...campus,
        buildingCount,
        floorCount,
        zoneCount,
        imageUrl: null // Add image logic if needed
      };
    })
  );

  // Create pagination object
  const pagination = {
    currentPage: parseInt(page),
    totalPages: Math.ceil(total / parseInt(limit)),
    totalCampuses: total,
    hasNextPage: skip + campuses.length < total,
    hasPrevPage: parseInt(page) > 1,
    totalNonDeleted,
    totalActive,
    totalInactive
  };

  return {
    campuses: campusesWithCounts,
    pagination
  };
};

// Get optimized buildings list with user access control and floor/zone counts
// - Applies userFilter at database level for performance
// - Calculates building statistics (floor count, zone count) in parallel
// - Supports campus-scoped filtering and comprehensive search
export const getOptimizedBuildings = async (queryParams = {}) => {
  const {
    page = 1,
    limit = 20,
    status,
    campusId,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    userFilter
  } = queryParams;

  // Start with user filter if provided, otherwise build base filter
  let filter = userFilter ? { ...userFilter } : {
    isDelete: { $ne: true }
  };

  // Apply additional filters
  const additionalFilters = [];

  if (status !== undefined) {
    additionalFilters.push({ status });
  }

  if (campusId) {
    additionalFilters.push({ campusId: new mongoose.Types.ObjectId(campusId) });
  }

  if (search) {
    additionalFilters.push({
      $or: [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ]
    });
  }

  // Combine all filters
  if (additionalFilters.length > 0) {
    if (!filter.$and) filter.$and = [];
    filter.$and.push(...additionalFilters);
  }

  // Calculate skip value for pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);

  // Get sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // Create deep copies of the filter for calculating totals based on user access
  const activeFilter = JSON.parse(JSON.stringify(filter));
  const inactiveFilter = JSON.parse(JSON.stringify(filter));
  
  // Add status filters for totals calculation
  if (!activeFilter.$and) activeFilter.$and = [];
  if (!inactiveFilter.$and) inactiveFilter.$and = [];
  
  // Remove any existing status filters and add the specific ones we need
  activeFilter.$and = activeFilter.$and.filter(condition => !condition.status);
  inactiveFilter.$and = inactiveFilter.$and.filter(condition => !condition.status);
  
  activeFilter.$and.push({ status: 1 });
  inactiveFilter.$and.push({ status: 0 });

  // Execute query with pagination and get total counts in parallel
  const [buildings, total, totalActive, totalInactive] = await Promise.all([
    CampusBuilding.find(filter)
      .populate('campusId', 'name accessId')
      .populate('createdBy.userId', 'fullName email')
      .populate('updatedBy.userId', 'fullName email')
      .sort(sort)
      .skip(skip)
      .limit(parseInt(limit))
      .lean(),
    CampusBuilding.countDocuments(filter),
    // Total active buildings based on user filter
    CampusBuilding.countDocuments(activeFilter),
    // Total inactive buildings based on user filter
    CampusBuilding.countDocuments(inactiveFilter)
  ]);

  // Calculate totalNonDeleted as sum of active and inactive
  const totalNonDeleted = totalActive + totalInactive;

  // Add floor and zone counts for each building
  const buildingsWithCounts = await Promise.all(
    buildings.map(async (building) => {
      const [floorCount, zoneCount] = await Promise.all([
        CampusFloor.countDocuments({
          buildingId: building._id,
          deleted: { $ne: true }
        }),
        CampusZone.countDocuments({
          floorId: { $in: await CampusFloor.find({ buildingId: building._id, deleted: { $ne: true } }).distinct('_id') },
          isDelete: { $ne: true }
        })
      ]);

      return {
        ...building,
        floorCount,
        zoneCount
      };
    })
  );

  // Create pagination object
  const pagination = {
    currentPage: parseInt(page),
    totalPages: Math.ceil(total / parseInt(limit)),
    totalBuildings: total,
    hasNextPage: skip + buildings.length < total,
    hasPrevPage: parseInt(page) > 1,
    totalNonDeleted,
    totalActive,
    totalInactive
  };

  return {
    buildings: buildingsWithCounts,
    pagination
  };
};

// Get optimized floors list with building/campus context and zone counts
// - Supports includeDeleted parameter for administrative views
// - Calculates zone counts and device statistics per floor
// - Maintains building → campus population chain for context
export const getOptimizedFloors = async (queryParams = {}) => {
  const {
    page = 1,
    limit = 20,
    status,
    buildingId,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    userFilter,
    includeDeleted = false // New parameter to include deleted floors
  } = queryParams;

  // Start with user filter if provided, otherwise build base filter
  let filter = userFilter ? { ...userFilter } : {};
  
  // Only exclude deleted floors if includeDeleted is false
  if (!includeDeleted) {
    filter.deleted = { $ne: true };
  }

  // Apply additional filters
  const additionalFilters = [];

  if (status !== undefined) {
    additionalFilters.push({ status });
  }

  if (buildingId) {
    additionalFilters.push({ buildingId: new mongoose.Types.ObjectId(buildingId) });
  }

  if (search) {
    additionalFilters.push({
      $or: [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ]
    });
  }

  // Combine all filters
  if (additionalFilters.length > 0) {
    if (!filter.$and) filter.$and = [];
    filter.$and.push(...additionalFilters);
  }

  // Calculate skip value for pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);

  // Get sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // Create deep copies of the filter for calculating totals based on user access
  const activeFilter = JSON.parse(JSON.stringify(filter));
  const inactiveFilter = JSON.parse(JSON.stringify(filter));
  const deletedFilter = JSON.parse(JSON.stringify(filter));
  
  // Add status filters for totals calculation
  if (!activeFilter.$and) activeFilter.$and = [];
  if (!inactiveFilter.$and) inactiveFilter.$and = [];
  if (!deletedFilter.$and) deletedFilter.$and = [];
  
  // Remove any existing status filters and add the specific ones we need
  activeFilter.$and = activeFilter.$and.filter(condition => !condition.status);
  inactiveFilter.$and = inactiveFilter.$and.filter(condition => !condition.status);
  
  // For active and inactive, always exclude deleted floors
  activeFilter.$and.push({ status: 1, deleted: { $ne: true } });
  inactiveFilter.$and.push({ status: 0, deleted: { $ne: true } });
  
  // For deleted floors count
  deletedFilter.$and.push({ deleted: true });

  // Execute query with pagination and get total counts in parallel
  const queryPromises = [
    CampusFloor.find(filter)
      .populate({
        path: 'buildingId',
        select: 'name campusId region',
        populate: {
          path: 'campusId',
          select: 'name location'
        }
      })
      .populate('createdBy.userId', 'fullName email')
      .sort(sort)
      .skip(skip)
      .limit(parseInt(limit))
      .lean(),
    CampusFloor.countDocuments(filter),
    CampusFloor.countDocuments(activeFilter),
    CampusFloor.countDocuments(inactiveFilter)
  ];
  
  // Add deleted count only if includeDeleted is true
  if (includeDeleted) {
    queryPromises.push(CampusFloor.countDocuments(deletedFilter));
  }

  const results = await Promise.all(queryPromises);
  const [floors, total, totalActive, totalInactive] = results;
  const totalDeleted = includeDeleted ? results[4] : 0;

  // Calculate totalNonDeleted as sum of active and inactive
  const totalNonDeleted = totalActive + totalInactive;

  // Add zone counts for each floor
  const floorsWithCounts = await Promise.all(
    floors.map(async (floor) => {
      const zoneCount = await CampusZone.countDocuments({
        floorId: floor._id,
        isDelete: { $ne: true },
        status: 1
      });

      return {
        _id: floor._id,
        floorName: floor.name,
        campusName: floor.buildingId?.campusId?.name || '',
        buildingName: floor.buildingId?.name || '',
        location: floor.buildingId?.campusId?.location || '',
        region: floor.buildingId?.region || '',
        floorLevel: floor.floorLevel,
        status: floor.status,
        addedOn: floor.createdAt,
        zoneCount,
        description: floor.description,
        floorImage: floor.floorImage || "",
        isDeleted: floor.deleted === true,
        deletedAt: floor.deletedAt || null,
        deletedBy: floor.deletedBy || null,
        createdBy: floor.createdBy?.userId ? {
          userId: {
            _id: floor.createdBy.userId._id,
            fullName: floor.createdBy.userId.fullName,
            email: floor.createdBy.userId.email
          },
          fullName: floor.createdBy.userId.fullName,
          email: floor.createdBy.userId.email
        } : null
      };
    })
  );

  // Create pagination object
  const pagination = {
    currentPage: parseInt(page),
    totalPages: Math.ceil(total / parseInt(limit)),
    totalFloors: total,
    hasNextPage: skip + floors.length < total,
    hasPrevPage: parseInt(page) > 1,
    totalNonDeleted,
    totalActive,
    totalInactive,
    ...(includeDeleted && { totalDeleted })
  };

  return {
    floors: floorsWithCounts,
    pagination
  };
};

// Get optimized zones list with full hierarchy context and device counts
// - Populates complete hierarchy (zone → floor → building → campus)
// - Calculates device counts per zone for capacity planning
// - Provides formatted zone data with proper status mapping
export const getOptimizedZones = async (queryParams = {}) => {
  const {
    page = 1,
    limit = 20,
    status,
    floorId,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    userFilter
  } = queryParams;

  // Start with user filter if provided, otherwise build base filter
  let filter = userFilter ? { ...userFilter } : {
    isDelete: { $ne: true }
  };

  // Apply additional filters
  const additionalFilters = [];

  if (status !== undefined) {
    if (status === 'active') {
      additionalFilters.push({ status: 1 });
    } else if (status === 'inactive') {
      additionalFilters.push({ status: 0 });
    }
  }

  if (floorId) {
    additionalFilters.push({ floorId: new mongoose.Types.ObjectId(floorId) });
  }

  if (search) {
    additionalFilters.push({
      $or: [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ]
    });
  }

  // Combine all filters
  if (additionalFilters.length > 0) {
    if (!filter.$and) filter.$and = [];
    filter.$and.push(...additionalFilters);
  }

  // Calculate skip value for pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);

  // Get sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // Create deep copies of the filter for calculating totals based on user access
  const activeFilter = JSON.parse(JSON.stringify(filter));
  const inactiveFilter = JSON.parse(JSON.stringify(filter));
  
  // Add status filters for totals calculation
  if (!activeFilter.$and) activeFilter.$and = [];
  if (!inactiveFilter.$and) inactiveFilter.$and = [];
  
  // Remove any existing status filters and add the specific ones we need
  activeFilter.$and = activeFilter.$and.filter(condition => !('status' in condition));
  inactiveFilter.$and = inactiveFilter.$and.filter(condition => !('status' in condition));
  
  activeFilter.$and.push({ status: 1 });
  inactiveFilter.$and.push({ status: 0 });

  // Execute query with pagination and get total counts in parallel
  const [zones, total, totalActive, totalInactive] = await Promise.all([
    CampusZone.find(filter)
      .populate({
        path: 'floorId',
        select: 'name buildingId',
        populate: {
          path: 'buildingId',
          select: 'name campusId',
          populate: {
            path: 'campusId',
            select: 'name location'
          }
        }
      })
      .sort(sort)
      .skip(skip)
      .limit(parseInt(limit))
      .lean(),
    CampusZone.countDocuments(filter),
    // Total active zones based on user filter
    CampusZone.countDocuments(activeFilter),
    // Total inactive zones based on user filter
    CampusZone.countDocuments(inactiveFilter)
  ]);

  // Calculate totalNonDeleted as sum of active and inactive
  const totalNonDeleted = totalActive + totalInactive;

  // Format zones with proper structure and calculate deviceCount
  const Device = (await import('../models/Device.js')).default;
  const formattedZones = await Promise.all(zones.map(async zone => {
    // Format date as DD MM YYYY
    const formatDate = (date) => {
      const d = new Date(date);
      const day = String(d.getDate()).padStart(2, '0');
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const year = d.getFullYear();
      return `${day} ${month} ${year}`;
    };

    // Count only non-deleted and configured devices for this zone
    const deviceCount = await Device.countDocuments({ 
      zone: new mongoose.Types.ObjectId(zone._id),
      is_delete: { $ne: true },
      configure_flag: true
    });

    return {
      _id: zone._id,
      type: zone.type,
      description: zone.description,
      createdAt: zone.createdAt,
      zoneName: zone.name,
      buildingName: zone.floorId?.buildingId?.name || '',
      floorName: zone.floorId?.name || '',
      deviceCount,
      status: zone.status === 1 ? 'active' : 'inactive',
      createdOn: formatDate(zone.createdAt)
    };
  }));

  // Create pagination object
  const pagination = {
    currentPage: parseInt(page),
    totalPages: Math.ceil(total / parseInt(limit)),
    totalRecords: total,
    perPage: parseInt(limit),
    hasNextPage: skip + zones.length < total,
    hasPrevPage: parseInt(page) > 1,
    totalNonDeleted,
    totalActive,
    totalInactive
  };

  return {
    zones: formattedZones,
    pagination
  };
};
