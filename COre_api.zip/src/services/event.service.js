import { getConfig } from '../config/env.js';
import axios from 'axios';
import DeviceConfig from '../utils/deviceConfig.js';
import Device from '../models/Device.js';
import { Group } from '../models/Group.js';
import { Scene } from '../models/Scene.js';
import { Sensor } from '../models/Sensor.js';
import { defaultBA200Capabilities, defaultCapabilities } from '../utils/deviceCapabilities.js';
import { socketManager } from '../utils/socketManager.js';
import Message from '../models/Message.js';
import { addLog } from './log.service.js';
import { sendCommand } from './mqtt.service.js';
import { getLutronClient, shadeCommands } from './device.lutron.js';


// Automatic device discovery from MQTT broadcasts
// - Detects new devices by MAC address and creates database entries
// - Auto-assigns device capabilities based on serial number (BA-100/BA-200)
// - Emits real-time socket events for UI updates and logs discovery
export const discoverDevice = async (data) => {
    const { device_id, SNO, Firmware, MacAddr } = data;

    const findDevice = await Device.find({ Mac_addr: MacAddr, is_delete: false  });

    if (findDevice.length === 0) {
        const deviceData = { device_id, SNO, firmware : Firmware, Mac_addr: MacAddr };
        deviceData.status = 'Active';
        if (deviceData.SNO.includes('BA200')) {
            deviceData.type = 'BA-200';
            deviceData.capabilities = defaultBA200Capabilities;
        } else {
            deviceData.type = 'BA-100';
            deviceData.capabilities = defaultCapabilities;
        }
        deviceData.name = deviceData.device_id;
        deviceData.description = "";
        socketManager.emitEvent("deviceStatusChanged", {uiType: "", message:` New Device(${deviceData.device_id}) Discovered`});
        await addLog({
            action: 'Discovered',
            name: deviceData.device_id,
            deviceId: deviceData.device_id,
            timestamp: Math.floor(Date.now() / 1000),
            type: 'Device',
            device: deviceData.device_id,
            userId: '-',
            userName: '-',
            });
        return await Device.insertOne(deviceData);
    }
}

export const getStoredDevices = async () => {
    return await Device.find({"is_delete":false,"type":{$in:['BA-100','BA-200']}},{device_id: 1});
}

export const storeDeviceMessage = async (data) => {
    await Message.insertOne(data);
    socketManager.emitEvent('mqttLogAdded', data);
    return {"message": "Stored Successfully"};
};

//{ ch_t: 'CO2', ch_addr: 'CO2_1', cmd: 100, cmd_m: '542' }
export const getSensorData = async (data) => {
    const { sensorData, deviceId } = data;
    console.log("Sensor Data Received in Service:", sensorData, deviceId);
    const device = await Device.findOne({ device_id: deviceId, is_delete: false });
    if (!device) {
        console.error(`Device not found ${deviceId}`);
    }
    const sensorDataObj = {
        "type": "sensor",
        "name": sensorData.ch_addr,
        "channelId": sensorData.ch_addr,
        "status": "active",
        "properties": {
            "sensorType": sensorData.ch_t,
            "installed": true,
            "value": sensorData.cmd_m,
            "lastSeen": Date.now()/1000
        }
    };
    const findSensor = device.capabilities.find(ch => ( ch.channelId === sensorData.ch_addr && ch.properties?.sensorType === sensorData.ch_t ) );
    console.log("found sensor", sensorData.ch_addr, sensorData.ch_t, findSensor);
    
    if(findSensor){
        const updateResult = await updateDeviceData(device.device_id, sensorData.ch_addr, { "properties": { "value": sensorData.cmd_m, "lastSeen": Date.now()/1000 } });    
        if (updateResult) {
            socketManager.emitEvent("deviceStatusChanged", {uiType: "", deviceId:device.device_id,chAddr:sensorData.ch_addr,properties:{"value":sensorData.cmd_m,"lastSeen": Date.now()/1000}});
            return `Sensor data updated for ${sensorData.ch_addr} on device ${deviceId}`;
        }
        else
            return "Error in updating sensor data";
    } else {
        device.capabilities.push(sensorDataObj);
        console.log("--pushed capabilities", device.capabilities.length);
        
        const updateDevice = await Device.findOneAndUpdate({ device_id: deviceId, is_delete: false }, { capabilities: device.capabilities });
        if (!updateDevice) {
            console.error(`Error in updating ${deviceId}`);
        }
        await addLog({
            action: 'Discovered',
            name: sensorDataObj.name,
            deviceId: deviceId,
            deviceName: updateDevice.name,
            channelId: sensorDataObj.channelId,
            timestamp: Math.floor(Date.now() / 1000),
            type: 'Sensor',
            userId: '-',
            userName: '-',
        });
        socketManager.emitEvent("sensorStatusChanged", {uiType: "", message:`Detected a new sensor(${sensorData.ch_addr}) on device ${deviceId}`});
        return `Detected a new sensor(${sensorData.ch_addr}) on device ${deviceId}`;
    }   
};

// Update hmi channels data
export const hmiUpdate = async (data) => {
    const { statusData, deviceId } = data;
    const device = await Device.findOne({ device_id: deviceId, is_delete: false });
    if (!device) {
        return `Device not found ${deviceId}`;
    }
    
    const channelAddress = statusData.cmd_m.split(':')[0];
    const channelProperties = statusData.cmd_m.split(':')[1].split(',');
    const channelType = channelAddress?.replace(/[0-9]/g, "")?.toLowerCase();
    const findChannel = device.capabilities.find(ch => ch.channelId === channelAddress);
    if (findChannel) {
        switch (channelType) {
            case 'led':
                const updateResult = await updateDeviceData(device.device_id, channelAddress, { "status": Number(channelProperties[0]) === 1 ? 'on' : 'off', "properties": { "brightness": channelProperties[1] ? Number(channelProperties[1]) : 0, "installed": true } });
                if (updateResult) {
                    socketManager.emitEvent("deviceStatusChanged", { uiType: "", deviceId: device.device_id, chAddr: channelAddress, properties: { "status": channelProperties[0] ? 'on' : 'off', "brightness": channelProperties[1] ? Number(channelProperties[1]) : 0 } });
                    return `HMI data updated for ${channelAddress} on device ${deviceId}`;
                }
                else
                    return "Error in updating HMI data";
            case 'shade':
                let shadeStatus = 'stop';
                if (Number(channelProperties[0]) === 1)
                    shadeStatus = 'open';
                else if (Number(channelProperties[0]) === 0)
                    shadeStatus = 'close';
                const shadeUpdateResult = await updateDeviceData(device.device_id, channelAddress, { "status": shadeStatus, "properties": { "openLevel": channelProperties[1] ? `${channelProperties[1]}%` : '0%', "installed": true } });
                if (shadeUpdateResult) {
                    socketManager.emitEvent("deviceStatusChanged", { uiType: "", deviceId: device.device_id, chAddr: channelAddress, properties: { "status": shadeStatus, "openLevel": channelProperties[1] ? `${channelProperties[1]}%` : '0%' } });
                    return `HMI data updated for ${channelAddress} on device ${deviceId}`;
                }
                else
                    return "Error in updating HMI data";
            default:
                return `Channel type ${channelType} not implemented for HMI update`;
        }
    } else {
        switch (channelType) {
            case 'led':
                device.capabilities.push({
                    "type": channelType,
                    "name": channelAddress,
                    "channelId": channelAddress,
                    "status": channelProperties[0] ? 'on' : 'off',
                    "properties": {
                        "brightness": channelProperties[1] ? Number(channelProperties[1]) : 0,
                        "installed": true
                    }
                });
                await device.save();
                break; 
            case 'shade':
                device.capabilities.push({
                    "type": channelType,
                    "name": channelAddress,
                    "channelId": channelAddress,
                    "status": channelProperties[0] ? 'open' : 'close',
                    "properties": {
                        "openLevel": channelProperties[1] ? channelProperties[1]+'%' : '0%',
                        "installed": true
                    }
                });
                await device.save();
                break; 
            default:
                return `Channel type ${channelType} not implemented for HMI update`;
        }
        socketManager.emitEvent("deviceStatusChanged", { uiType: "", deviceId: device.device_id, chAddr: channelAddress, properties: { "status": channelProperties[2] ? 'on' : 'off', "brightness": channelProperties[1] ? Number(channelProperties[1]) : 0 } });
    }
    return `HMI data updated for ${channelAddress} on device ${deviceId}`;
}

export const sendChannelConfigurations = async (device_id) => {
    const device = await Device.findOne({ device_id, is_delete: false },{capabilities:1});
    if (!device) {
        console.error(`Device not found ${device_id}`);
    }
    device.capabilities.map(async (channel) => {
        if (channel.type === 'led' && channel.properties?.installed === true) {
            await sendCommand(
                { ch_t: channel.type.toUpperCase(), ch_addr: channel.channelId, cmd: DeviceConfig.LED_MAX_CUR, cmd_m: [Number(channel.properties.powerMin), Number(channel.properties.powerMax)] },
                device_id
            );    
        }
    });
};

// Device reboot with channel state reset and MQTT command
// - Resets all channel capabilities to default state
// - Sends MQTT reboot command and sets device status to inactive
// - Logs reboot action and emits real-time socket updates
export const rebootDevice = async (data, userDetials) => {
    const {device_id} = data;
    try {
        const device = await Device.find({device_id : device_id, is_delete: false});
        if (device.length) {
            device[0].capabilities.map((channel) => {
                if (channel.type === 'led')
                    channel.status = "off";
                if (channel.type === 'shade')
                    channel.status = "close";
                if (channel.type === 'sensor')
                    channel.status = "inactive";
            });
            const updateDevice = await Device.findOneAndUpdate({ device_id: device_id, is_delete: false }, { capabilities: device[0].capabilities, status: "Inactive" });
        }
        await addLog({
            action: 'Reboot',
            name: device[0].name,
            timestamp: Math.floor(Date.now() / 1000),
            type: 'Device',
            deviceId: device_id,
            deviceName: device[0].name,
            userId: userDetials.id || '-',
            userName: userDetials.name || '-',
            });
        const conf = {
            MQTT_HOST: getConfig().mqttHost,
            MQTT_PORT: getConfig().mqttPort
        };
        const response = await axios.post(`http://${conf.MQTT_HOST}:${conf.MQTT_PORT}/mqtt/reboot`, { "deviceId": device_id  });
        socketManager.emitEvent("deviceStatusChanged", {uiType: "", message:` Device(${device_id}) Rebooted`});
        return response.data;
    } catch (error) {
        console.error(`Failed to send command: ${error.message}`);
    }
}

export const updateDeviceStatus = async (data) => {
    const { deviceData, status } = data;
    if(deviceData && deviceData.device_id){
        const update = await Device.findOne({ device_id: deviceData.device_id, is_delete: false });
        if (!update) {
            console.error(`Error in updating:${deviceData.device_id}`);
        }
        
        if (update?.configure_flag === false && status === 'Inactive') {
            socketManager.emitEvent("deviceStatusChanged", { uiType: "" });
            setTimeout(async() => {
                const conf = {
                    MQTT_HOST: getConfig().mqttHost,
                    MQTT_PORT: getConfig().mqttPort
                };
            const response = await axios.post(`http://${conf.MQTT_HOST}:${conf.MQTT_PORT}/mqtt/deleteDevice`, { "deviceId": deviceData.device_id });

            }, 2000);
            await Device.deleteOne({ device_id: deviceData.device_id });
        } else {
            if (status === 'Active' && update?.status === 'Inactive') {
                const sensorScenes = await Sensor.find({ device: deviceData.device_id, isDelete:false },{sensor:1, Trigger_duration:1, sensorGroupId: 1});
                sensorScenes.map(async(scene) => {
                    const sensorIds = [];
                    scene.sensor.map((sensor) => {
                        const config = sensor.split('_');
                        const port = config[1];
                        sensorIds.push(Number(port));
                    });
                    if(scene.sensorGroupId && sensorIds.length)
                        await sendCommand({ ch_t: 'PIR', ch_addr: sensorIds, cmd: DeviceConfig.GRP_PIR_TIMER, cmd_m: scene.sensorGroupId + ":" + scene.Trigger_duration.toString() }, deviceData.device_id);
                });
            }
            socketManager.emitEvent("deviceStatusChanged", {uiType: "", message:` Device(${deviceData.device_id}) is now ${status}`});
            if (update) {
                if (deviceData.Firmware && update.firmware != deviceData.Firmware) {
                    update.firmware = deviceData.Firmware;
                }
                await Device.updateOne({ device_id: deviceData.device_id, is_delete: false }, { status: status, firmware: update.firmware });
            }
        }
        return {};
    } else {
        const devices = await Device.find({
            type: { $in: ['BA-100', 'BA-200'] },
            is_delete: false
        });
        for (const device of devices) {
            device.status = 'Inactive';
            await device.save();
        }
        return {};
    }  
};

// Process sensor data updates and handle automation triggers
// - Auto-discovers new sensors and adds them to device capabilities
// - Executes automation scenes when sensor events are received
// - Logs sensor discovery and triggers real-time UI updates
export const updateSensorData = async (data) => {
    const { statusData, deviceId } = data;
    const device = await Device.findOne({ device_id: deviceId, is_delete: false });
    if (!device) {
        console.error(`Device not found ${deviceId}`);
    }
    const sensorData = {
        "type": "sensor",
        "name": statusData.ch_addr,
        "channelId": statusData.ch_addr,
        "status": "active",
        "properties": {
            "sensorType": "pir",
            "installed": false,
            "lastSeen": Date.now()/1000
        }
    };
    // Check if sensor channel already exists
    if (!device.capabilities.some(ch => ch.channelId === statusData.ch_addr)) {
        device.capabilities.push(sensorData);
        const updateDevice = await Device.findOneAndUpdate({ device_id: deviceId, is_delete: false }, { capabilities: device.capabilities });
        if (!updateDevice) {
            console.error(`Error in updating ${deviceId}`);
        }
        await addLog({
            action: 'Discovered',
            name: sensorData.name,
            deviceId: deviceId,
            deviceName: updateDevice.name,
            channelId: sensorData.channelId,
            timestamp: Math.floor(Date.now() / 1000),
            type: 'Sensor',
            userId: '-',
            userName: '-',
            });
        socketManager.emitEvent("sensorStatusChanged", {uiType: "", message:`Detected a new sensor(${statusData.ch_addr}) on device ${deviceId}`});
        return `Detected a new sensor(${statusData.ch_addr}) on device ${deviceId}`;
    } else {    //If aldreay exists check for event on sensor
        const sensorEvent = await Sensor.find({ sensor: statusData.ch_addr, device: deviceId, isDelete: false });
        
        //Update sensor last seen time
        const updatedDevice = await Device.findOneAndUpdate(
            { device_id: deviceId, is_delete: false, "capabilities.channelId": statusData.ch_addr },
            { $set: { "capabilities.$.properties.lastSeen": Date.now() / 1000 } }
        );

        if (sensorEvent.length) {
            sensorEvent
                .filter(event => !event.isDelete) // Filter out events where isDeleted is true
                .map(async (event) => {
                    if (statusData.cmd_m.includes(1)) {
                        await sendChannelEvent({ "deviceData": event.motionScene, "command": "SCENE_EXECUTE" }, {});
                        socketManager.emitEvent("sensorStatusChanged", {uiType: "", message:`Update from ${deviceId} (${statusData.ch_addr}) sensor, ${event.sensorEvent} executed`});
                        return `Update from ${deviceId} (${statusData.ch_addr}) ->Scene: ${event.motionScene} executed.`;
                    } else if (statusData.cmd_m.includes(0)) {
                        if (event.motionScene.toString() === event.NoMotionScene.toString())
                            await sendChannelEvent({ "deviceData": event.NoMotionScene, "command": "SCENE_EXECUTE", "invertFlag": true }, {});
                        else
                            await sendChannelEvent({ "deviceData": event.NoMotionScene, "command": "SCENE_EXECUTE" }, {});
                        socketManager.emitEvent("sensorStatusChanged", {uiType: "", message:`Update from ${deviceId} (${statusData.ch_addr}) sensor, ${event.sensorEvent} executed`});
                        return `Update from ${deviceId} (${statusData.ch_addr}) ->Scene: ${event.NoMotionScene} executed.`;
                    }
                });
        } else {
            socketManager.emitEvent("sensorStatusChanged", {uiType: "", message:`Event recieved from ${deviceId}'s sensor ${statusData.ch_addr} - Please create an event for sensor`});
            return { "message": `Event recieved from ${deviceId}'s sensor ${statusData.ch_addr} - Please create an event for sensor` };
        }
    }
};

// Execute device/channel commands with comprehensive protocol support
// - Handles LED, shade, group, and scene operations with MQTT communication
// - Routes third-party device commands to appropriate integration handlers
// - Logs all operations and updates device state in real-time
export const sendChannelEvent = async (data, userDetails) => {
    const { username, device_id, deviceData, channelType, channelAddress, command, invertFlag, uiType, groupId } = data;

    if (deviceData?.properties?.numberOfCmds) {
        return await thirdPartyEvent(device_id,command, channelAddress);
    }

    const device = await Device.findOne({ device_id: device_id,is_delete: false });
    if (!device) {
        console.error(`Device not found ${device_id}`);
    }

    // Build groupChannels if GROUP operation
    let groupChannels = [];
    if (command.includes("GROUP_LED_BRIGHTNESS")) {
        const brightness = Number(command.split("LED_BRIGHTNESS")[1]);
        groupChannels = await extractGroupChannels(command, deviceData, brightness, username);
    } else
        groupChannels= await extractGroupChannels(command, deviceData, undefined, username);

    const chAddr = channelAddress?.replace(/\W+/g, '').toUpperCase();
    const chType = channelType?.toUpperCase();

    switch (command) {
        case "SHADE_UPPER_LIMIT": case "SHADE_LOWER_LIMIT": case "SHADE_MIDDLE_LIMIT": case 'SHADE_DELETE_LIMIT':
            await sendCommand({ ch_t: chType, ch_addr: chAddr, cmd: DeviceConfig.SHADE_LIMIT, cmd_m: command.toLowerCase() }, device.device_id);
            const data = await Device.findOne({ device_id: device.device_id, is_delete: false, "capabilities.channelId": chAddr }, { "capabilities.$": 1 });
            const name = data.capabilities[0].name || '-';
            
            await addLog({
                        action: 'Shade Limit Set: ' + command.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, c => c.toUpperCase()),
                        name: name || '-',
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Device',
                        deviceId : device.device_id,
                        deviceName: device.name,
                        channelId: chAddr,
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
            });
            break;
        case "LED_ON": {
            const brightness = calcBrightness(100, deviceData.properties.powerMax);
            const result = await sendCommand({ ch_t: chType, ch_addr: chAddr, cmd: DeviceConfig.LED_BRIGHTNESS, cmd_m: brightness }, device.device_id);
            const result2 = await sendCommand({ ch_t: chType, ch_addr: chAddr, cmd: DeviceConfig.LED_ON_OFF, cmd_m: command }, device.device_id);
            if (result === true && result2 === true) {
                const updateResult = await updateDeviceData(device.device_id, chAddr, { "status": "on" });
                if (updateResult) {
                    await addLog({
                        action: 'Led On',
                        name: updateResult.name || '-',
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Device',
                        deviceId: device.device_id,
                        deviceName: device.name,
                        channelId: chAddr,
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
                        });
                    socketManager.emitEvent("deviceStatusChanged", {uiType, deviceId:device.device_id,chAddr,properties:{"status":"on"}});
                    return `${command} on ${chAddr} executed successfully`;
                }
                else
                    return "Command sent but error in updating status";
            } else {
                return "Error in sending command to service";
            }
        }
        case "LED_OFF":
            const result = await sendCommand({ ch_t: chType, ch_addr: chAddr, cmd: DeviceConfig.LED_ON_OFF, cmd_m: command }, device.device_id);
            if (result === true) {
                const updateResult = await updateDeviceData(device.device_id, chAddr, { "status": "off" });
                if (updateResult) {
                    await addLog({
                        action: 'Led Off',
                        name: updateResult.name || '-',
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Device',
                        deviceId: device.device_id,
                        deviceName: device.name,
                        channelId: chAddr,
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
                    });
                    socketManager.emitEvent("deviceStatusChanged", { uiType, deviceId: device.device_id, chAddr, properties: { "status": "off" } });
                    return `${command} on ${chAddr} executed successfully`;
                }
                else
                    return "Command sent but error in updating status";
            } else {
                return "Error in sending command to service";
            }
        case "LED_BRIGHTNESS": {
            const brightness = calcBrightness(deviceData.properties.brightness, deviceData.properties.powerMax);
            const result = await sendCommand({ ch_t: chType, ch_addr: chAddr, cmd: DeviceConfig.LED_BRIGHTNESS, cmd_m: brightness }, device.device_id);
            if (result === true) {
                const updateResult = await updateDeviceData(device.device_id, chAddr, { "properties": { "brightness": deviceData.properties.brightness } });
                if (updateResult) {
                    await addLog({
                        action: 'Led Brightness to ' + deviceData.properties.brightness + '%',
                        name: updateResult.name || '-',
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Device',
                        deviceId: device.device_id,
                        deviceName: device.name,
                        channelId: chAddr,
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
                    });
                    socketManager.emitEvent("deviceStatusChanged", { uiType, deviceId: device.device_id, chAddr, properties: { "brightness": deviceData.properties.brightness } });
                    return `${command} on ${chAddr} executed successfully`;
                } else
                    return "Command sent but error in updating status";
            } else {
                return "Error in sending command to service";

            }
        }
        case "LED_POWER_MIN_MAX": {
            const result = await sendCommand(
                { ch_t: chType, ch_addr: chAddr, cmd: DeviceConfig.LED_MAX_CUR, cmd_m: [Number(deviceData.properties.powerMin), Number(deviceData.properties.powerMax)] },
                device.device_id
            );
            if (result === true) {
                const updateResult = await updateDeviceData(device.device_id, chAddr, { "properties": { "powerMin": deviceData.properties.powerMin, "powerMax": deviceData.properties.powerMax } });
                if (updateResult) {
                    await addLog({
                        action: 'Led Power Change',
                        name: updateResult.name || '-',
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Device',
                        deviceId: device.device_id,
                        deviceName: device.name,
                        channelId: chAddr,
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
                        });
                    socketManager.emitEvent("deviceStatusChanged", {uiType, deviceId:device.device_id,chAddr,properties:{"powerMin":deviceData.properties.powerMin,"powerMax":deviceData.properties.powerMax}});
                    return `${command} on ${chAddr} executed successfully`;
                } else
                    return "Command sent but error in updating status";
            } else {
                return "Error in sending command to service";

            }
        }
        case "SHADE_DOWN":{
            const result = await sendCommand({ ch_t: chType, ch_addr: chAddr, cmd: DeviceConfig.SHADE_CLOSE, cmd_m: "shade_close" }, device.device_id);
            if (result === true) {
                let updateResult;
                    updateResult = await updateDeviceData(device.device_id, chAddr, { "status": "open","properties":{"openLevel": '0%'} });
                if (updateResult) {
                    await addLog({
                        action: 'Shade Down',
                        name: updateResult.name || '-',
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Device',
                        deviceId: device.device_id,
                        deviceName: device.name,
                        channelId: chAddr,
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
                    });
                    socketManager.emitEvent("deviceStatusChanged", { uiType, deviceId: device.device_id, chAddr, properties: { "status": "close" } });
                    return `${command} on ${chAddr} executed successfully`;
                } else
                    return "Command sent but error in updating status";
            } else {
                return "Error in sending command to service";

            }
        }
        case "SHADE_UP": {
            const result = await sendCommand({ ch_t: chType, ch_addr: chAddr, cmd: DeviceConfig.SHADE_OPEN, cmd_m: "shade_open" }, device.device_id);
            if (result === true) {
                const updateResult = await updateDeviceData(device.device_id, chAddr, { "status": "open","properties":{"openLevel": '100%'} });
                if (updateResult) {
                    await addLog({
                        action: 'Shade Up',
                        name:updateResult.name || '-',
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Device',
                        deviceId: device.device_id,
                        deviceName: device.name,
                        channelId: chAddr,
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
                    });
                    socketManager.emitEvent("deviceStatusChanged", { uiType, deviceId: device.device_id, chAddr, properties: { "status": "open" } });
                    return `${command} on ${chAddr} executed successfully`;
                } else
                    return "Command sent but error in updating status";
            } else {
                return "Error in sending command to service";

            }
        }
        case "SHADE_STOP":{
            const result = await sendCommand({ ch_t: chType, ch_addr: chAddr, cmd: DeviceConfig.SHADE_SET_CONF, cmd_m: "shade_stop" }, device.device_id);
            const data = await Device.findOne({ device_id: device.device_id, is_delete: false, "capabilities.channelId": chAddr }, { "capabilities.$": 1 });
            const name = data.capabilities[0].name || '-';
            if (result === true) {
                await addLog({
                        action: 'Shade Stop',
                        name: name,
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Device',
                        deviceId : device.device_id,
                        deviceName: device.name,
                        channelId: chAddr,
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
                });
                return `${command} on ${chAddr} executed successfully`;
            } else {
                return "Error in sending command to service";

            }
        }
        case "SHADE_SET_MOVEMENT": {
            const result = await sendCommand({ ch_t: chType, ch_addr: chAddr, cmd: DeviceConfig.SHADE_CONFIG, cmd_m: Number(deviceData.properties.openLevel) }, device.device_id);
            if (result === true) {
                const updateResult = await updateDeviceData(device.device_id, chAddr, { "properties": { "openLevel": deviceData.properties.openLevel } });
                if (updateResult) {
                    socketManager.emitEvent("deviceStatusChanged", {uiType, deviceId:device.device_id,chAddr,properties:{"openLevel":deviceData.properties.openLevel}});
                    return `${command} on ${chAddr} executed successfully`;
                } else
                    return "Command sent but error in updating status";
            } else {
                return "Error in sending command to service";

            }
        }
        case "GROUP_LED_ON":      
            const club_led_on_ids = {};
            groupChannels.forEach(async (g) => {
                if(!club_led_on_ids[g.device_id])
                    club_led_on_ids[g.device_id] = g.channels;
                else
                    club_led_on_ids[g.device_id].push(...g.channels);
                await sendCommand({ ch_t: "LED", ch_addr: g.channels, cmd: DeviceConfig.SCENE_CMD, cmd_m: { "LED_BRIGHTNESS": g.brightness } }, g.device_id);
            });
            Object.entries(club_led_on_ids).forEach(async([deviceId, values]) => {
                await sendCommand({ ch_t: "LED", ch_addr: values, cmd: DeviceConfig.SCENE_CMD, cmd_m: "LED_ON" }, deviceId);
            });
            
            deviceData.devices.map(async (device) => {
                device.channels.map(async (channel) => {
                    await Device.findOneAndUpdate({
                        device_id: device.deviceId, is_delete: false, "capabilities.channelId": channel.channelId
                    }, { $set: { "capabilities.$.status": "on" } });
                });
            });
            let groupledon = await Group.findOne({ _id: groupId, isDeleted: false }, { name: 1 });
            await addLog({
                        action: 'Group Led On',
                        name: `${(groupledon.name || '')}`,
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Group',
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
            });
            socketManager.emitEvent("deviceStatusChanged", { uiType, groupId });
            return true;
        case "GROUP_LED_OFF":
            groupChannels.forEach(async (g) => {
                await sendCommand({ ch_t: "LED", ch_addr: g.channels, cmd: DeviceConfig.SCENE_CMD, cmd_m: "LED_OFF" }, g.device_id);
            });
            deviceData.devices.map(async (device) => {
                device.channels.map(async (channel) => {
                    await Device.findOneAndUpdate({
                        device_id: device.deviceId, is_delete:false, "capabilities.channelId": channel.channelId
                    }, { $set: { "capabilities.$.status": "off" } });
                });
            });
            let groupledoff = await Group.findOne({ _id: groupId, isDeleted: false }, { name: 1 });
            
            await addLog({
                action: 'Group Led Off',
                name: `${(groupledoff.name || '')}`,
                timestamp: Math.floor(Date.now() / 1000),
                type: 'Group',
                userId: userDetails?.id || '-',
                userName: userDetails?.name || '-'
            });
            socketManager.emitEvent("deviceStatusChanged", { uiType, groupId });
            return true;
        case "GROUP_SHADE_UP": {
            groupChannels.forEach(async (g) => {
                if (g.channels[0].toString().includes('SHADE')) {
                    const shadeCommand = command.split("GROUP_")[1];
                    g.channels.map((ch) => {
                        thirdPartyEvent(g.device_id, shadeCommand, ch, true);
                    });
                }
                else {
                    await sendCommand({ ch_t: "SHADE", ch_addr: g.channels, cmd: DeviceConfig.SCENE_CMD, cmd_m: "shade_open" }, g.device_id);
                }
            });
            deviceData.devices.map(async (device) => {
                device.channels.map(async (channel) => {
                    if (!channel.numberOfCmds)
                        await Device.findOneAndUpdate({
                            device_id: device.deviceId, is_delete: false, "capabilities.channelId": channel.channelId
                        }, { $set: { "capabilities.$.status": "open","capabilities.$.properties.openLevel": (channel.openLevel + "%") } });
                });
            });
            const groupshadeup = await Group.findOne({ _id: groupId, isDeleted: false }, { name: 1 });
            await addLog({
                            action: 'Group Shade Up',
                            name: `${(groupshadeup.name || '')}`,
                            timestamp: Math.floor(Date.now() / 1000),
                            type: 'Group',
                            userId: userDetails?.id || '-',
                            userName: userDetails?.name || '-'
                });
        socketManager.emitEvent("deviceStatusChanged", { uiType, groupId });
        return true;
        }
        case "GROUP_SHADE_DOWN": {
            groupChannels.forEach(async (g) => {
                if (g.channels[0].toString().includes('SHADE')) {
                    const shadeCommand = command.split("GROUP_")[1];
                    g.channels.map((ch) => {
                        thirdPartyEvent(g.device_id, shadeCommand, ch, true);
                    });
                }
                else
                    await sendCommand({ ch_t: "SHADE", ch_addr: g.channels, cmd: DeviceConfig.SCENE_CMD, cmd_m: "shade_close" }, g.device_id);
            });
            deviceData.devices.map(async (device) => {
                device.channels.map(async (channel) => {
                    if (channel.openLevel === 0)
                        channel.status = "close";
                    else
                        channel.status = "open";
                    if (!channel.numberOfCmds)
                        await Device.findOneAndUpdate({
                            device_id: device.deviceId, is_delete:false, "capabilities.channelId": channel.channelId
                        }, { $set: { "capabilities.$.status": channel.status,"capabilities.$.properties.openLevel": (channel.openLevel + "%")  } });
                });
            });
            const groupshadedown = await Group.findOne({ _id: groupId, isDeleted: false }, { name: 1 });
            await addLog({
                action: 'Group Shade Down',
                name: `${(groupshadedown.name || '')}`,
                timestamp: Math.floor(Date.now() / 1000),
                type: 'Group',
                userId: userDetails?.id || '-',
                userName: userDetails?.name || '-'
                });
            socketManager.emitEvent("deviceStatusChanged", { uiType, groupId });
        return true;
        }
        case "GROUP_SHADE_STOP":
            groupChannels.forEach(async (g) => {
                if (g.channels[0].toString().includes('SHADE')) {
                    const shadeCommand = command.split("GROUP_")[1];
                    g.channels.map((ch) => {
                        thirdPartyEvent(g.device_id, shadeCommand, ch, true);
                    });
                }
                else
                    await sendCommand({ ch_t: "SHADE", ch_addr: g.channels, cmd: DeviceConfig.SCENE_CMD, cmd_m: "shade_stop" }, g.device_id);
            });
            const groupshadestop = await Group.findOne({ _id: groupId, isDeleted: false }, { name: 1 });
            await addLog({
                        action: 'Group Shade Stop',
                        name: `${(groupshadestop.name || '')}`,
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Group',
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
            });
        return true;
        case "GROUP_SHADE_33":
            groupChannels.forEach(async (g) => {
                if (g.channels[0].toString().includes('SHADE')) {
                    const shadeCommand = command.split("GROUP_")[1];
                    g.channels.map((ch) => {
                        thirdPartyEvent(g.device_id, shadeCommand, ch, true);
                    });
                }
            });
            const groupshade33 = await Group.findOne({ _id: groupId, isDeleted: false }, { name: 1 });
            await addLog({
                        action: 'Group Shade 33',
                        name: `${(groupshade33.name || '')}`,
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Group',
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
            });
            socketManager.emitEvent("deviceStatusChanged", { uiType, groupId });
        return true;
        case "GROUP_SHADE_66":
            groupChannels.forEach(async (g) => {
                if (g.channels[0].toString().includes('SHADE')) {
                    const shadeCommand = command.split("GROUP_")[1];
                    g.channels.map((ch) => {
                        thirdPartyEvent(g.device_id, shadeCommand, ch, true);
                    });
                }
            });
            const groupshade66 = await Group.findOne({ _id: groupId, isDeleted: false }, { name: 1 });
            await addLog({
                        action: 'Group Shade 66',
                        name: `${(groupshade66.name || '')}`,
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Group',
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
            });
            socketManager.emitEvent("deviceStatusChanged", { uiType, groupId });
        return true;
        case "SCENE_EXECUTE":
            const sceneData = await Scene.findOne({ _id: deviceData, isDeleted: false });

            if (sceneData.name.toLowerCase().includes('lutron')) {
                if (sceneData.Devices && sceneData.Devices.length) {
                    sceneData.Devices = sceneData.Devices.map(async(device) => {
                        device.channels = device.channels.map(async (channel) => {
                            if (channel.command === 'close')
                                channel.command = 'SHADE_CLOSE';
                            else if (channel.command === 'open')
                                channel.command = 'SHADE_OPEN';
                            else if (channel.command === 'stop')
                                channel.command = 'SHADE_STOP';
                            await thirdPartyEvent(device.deviceId, channel.command, channel.channelId, true);
                            return channel;
                        });
                        return device;
                    });
                } else if (sceneData.Groups && sceneData.Groups.length) {
                    sceneData.Groups = sceneData.Groups.map(async(group) => {
                        group.devices = group.devices.map(async(device) => {
                            device.channels = device.channels.map(async(channel) => {
                                if (channel.command === 'close')
                                    channel.command = 'SHADE_CLOSE';
                                else if (channel.command === 'open')
                                    channel.command = 'SHADE_OPEN';
                                else if (channel.command === 'stop')
                                    channel.command = 'SHADE_STOP';
                                await thirdPartyEvent(device.deviceId, channel.command, channel.channelId, true);
                                return channel;
                                });
                            return device;
                        });
                        return group;
                    });
                }
                // Log and return after Lutron command execution
                await addLog({
                    action: 'Execute',
                    name: sceneData.name,
                    timestamp: Math.floor(Date.now() / 1000),
                    type: 'Scene',
                    userId: userDetails?.id || '-',
                    userName: userDetails?.name || '-'
                });
                return;
            }
            
            if (invertFlag) {
            // Invert the commands for devices and groups in sceneData
                if (sceneData.Devices && sceneData.Devices.length) {
                    sceneData.Devices = sceneData.Devices.map((device) => {
                    device.channels = device.channels.map((channel) => {
                        if (channel.channelType === "led") {
                                if (channel.command === "on") {
                                    channel.command = "off";
                                    channel.brightness = 0;
                                } else {
                                    channel.command = "on";
                                    if (channel.brightness === 0 || !channel.brightness) {
                                    channel.brightness = 100; // default brightness
                                    }
                                }
                        } else if (channel.channelType === "shade") {
                            if (channel.command === "open") {
                                channel.command = "close";
                            } else if (channel.command === "close") {
                                channel.command = "open";
                            }
                        }
                        return channel;
                    });
                    return device;
                    });
                } else if (sceneData.Groups && sceneData.Groups.length) {
                    sceneData.Groups = sceneData.Groups.map((group) => {
                    group.devices = group.devices.map((device) => {
                        device.channels = device.channels.map((channel) => {
                        if (channel.channelType === "led") {
                            if (channel.command === "on") {
                            channel.command = "off";
                            channel.brightness = 0;
                            } else {
                            channel.command = "on";
                            if (channel.brightness === 0 || !channel.brightness) {
                                channel.brightness = 100; // default brightness
                            }
                            }
                        } else if (channel.channelType === "shade") {
                            if (channel.command === "open") {
                            channel.command = "close";
                            } else if (channel.command === "close") {
                            channel.command = "open";
                            }
                        }
                        return channel;
                        });
                        return device;
                    });
                    return group;
                    });
                }
            }

            // Update lastExecuted time for all scene executions
            const updateData = { lastExecuted: new Date().toISOString() };
            
            // Only update invert_flag if invertFlag is explicitly provided (true or false)
            if (invertFlag === true || invertFlag === false) {
                updateData.invert_flag = invertFlag;
                if (invertFlag === true)
                    await addLog({
                        action: 'Set off',
                        name: sceneData.name,
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Scene',
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
                    });
                else
                    await addLog({
                        action: 'Set on',
                        name: sceneData.name,
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Scene',
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
                    });
            } else {
                    await addLog({
                        action: 'Execute',
                        name: sceneData.name,
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Scene',
                        userId: userDetails?.id || '-',
                        userName: userDetails?.name || '-'
                    });
            }

            await Scene.findOneAndUpdate({ _id: deviceData, isDeleted: false }, { $set: updateData });
           
            if (sceneData?.Devices) {
                sceneData.Devices.map(async (deviceData) => {
                    const deviceID = deviceData.deviceId;
                    const groupedChannels = await groupCommands(deviceData.channels, deviceID, device_id, username);
                    const led_on_ids = [];
                    groupedChannels.map(async (data) => {
                        if (data.command === "LED_BRIGHTNESS") {
                            await sendCommand({ ch_t: data.channelType, ch_addr: data.channelIds, cmd:DeviceConfig.SCENE_CMD,cmd_m: {"LED_BRIGHTNESS":device_id} }, deviceID);
                        } else if(data.command === "LED_ON"){
                            led_on_ids.push(...data.channelIds);
                            await sendCommand({ ch_t: data.channelType, ch_addr: data.channelIds, cmd:DeviceConfig.SCENE_CMD,cmd_m: {"LED_BRIGHTNESS":data.brightness} }, deviceID);
                        }
                        else if(data.command.includes('LED'))
                            await sendCommand({ ch_t: data.channelType, ch_addr: data.channelIds, cmd: DeviceConfig.SCENE_CMD, cmd_m: data.command } , deviceID);
                        else if(data.command.includes('SHADE'))
                            await sendCommand({ ch_t: data.channelType, ch_addr: data.channelIds, cmd: DeviceConfig.SCENE_CMD, cmd_m: data.command.toLowerCase() } , deviceID);
                    });
                    if (led_on_ids.length) {
                        await sendCommand({ ch_t: "LED", ch_addr: led_on_ids, cmd: DeviceConfig.SCENE_CMD, cmd_m: "LED_ON" } , deviceID);
                    }
                });
            } else {
                sceneData?.Groups.map(async(groupData) => {
                    groupData.devices.map(async(deviceData) => {
                        const deviceID = deviceData.deviceId;
                            const groupedChannels = await groupCommands(deviceData.channels, deviceID, device_id, username);
                            const led_on_ids = [];
                        groupedChannels.map(async (data) => {
                                if (data.command === "LED_BRIGHTNESS") {
                                    await sendCommand({ ch_t: data.channelType, ch_addr: data.channelIds, cmd:DeviceConfig.SCENE_CMD,cmd_m: {"LED_BRIGHTNESS":data.brightness} }, deviceID);
                                } else if (data.command === "LED_ON") {
                                    led_on_ids.push(...data.channelIds);                                    
                                    await sendCommand({ ch_t: data.channelType, ch_addr: data.channelIds, cmd:DeviceConfig.SCENE_CMD,cmd_m: {"LED_BRIGHTNESS":data.brightness} }, deviceID);
                                }
                                else if(data.command.includes('LED'))
                                    await sendCommand({ ch_t: data.channelType, ch_addr: data.channelIds, cmd: DeviceConfig.SCENE_CMD, cmd_m: data.command } , deviceID);
                                else if(data.command.includes('SHADE'))
                                    await sendCommand({ ch_t: data.channelType, ch_addr: data.channelIds, cmd: DeviceConfig.SCENE_CMD, cmd_m: data.command.toLowerCase() } , deviceID);
                            });
                            if (led_on_ids.length) {
                                await sendCommand({ ch_t: "LED", ch_addr: led_on_ids, cmd: DeviceConfig.SCENE_CMD, cmd_m: "LED_ON" } , deviceID);
                            }
                    });
                });
            }
            socketManager.emitEvent("deviceStatusChanged", { uiType, sceneId: deviceData });
        return true;
        default:
            if (command.includes("GROUP_LED_BRIGHTNESS")) {
                const brightness = Number(command.split("LED_BRIGHTNESS")[1]);
                groupChannels.forEach(async (g) => {
                    await sendCommand({ ch_t: "LED", ch_addr: g.channels, cmd: DeviceConfig.SCENE_CMD, cmd_m: {"LED_BRIGHTNESS" : g.brightness} }, g.device_id);
                });
                deviceData.devices.map(async (device) => {
                    device.channels.map(async (channel) => {
                        await Device.findOneAndUpdate({
                            device_id: device.deviceId, is_delete:false, "capabilities.channelId": channel.channelId
                        }, { $set: { "capabilities.$.properties.brightness": Number(brightness) } });
                    });
                });
                socketManager.emitEvent("deviceStatusChanged", { uiType, id: deviceData });
                return true;
            }
    }
}

export const sendHmiCommands = async (device_id, command) => {
    const payload = { "ch_t": "HMI", "ch_addr": "hmi_config_id", "cmd": 124, "cmd_m": "1,100,100,1" };
    const topic = device_id;
    console.log("-payload", payload, topic);
    const conf = {
        MQTT_HOST: getConfig().mqttHost,
        MQTT_PORT: getConfig().mqttPort
    };
    try {
        const response = await axios.post(`http://${conf.MQTT_HOST}:${conf.MQTT_PORT}/mqtt/sendHMICommands`, { payload, topic });
        return true;
    } catch (error) {
        console.log({ payload, topic })
        console.error(`Failed to send command: ${error.message}`);
        return error.message;
    }
};

export const thirdPartyEvent = async (device_id,command, channel, hideToaster) => {
    console.log("-command", device_id,command, channel);
    let lutron_client = await getLutronClient(device_id);
    if (lutron_client === undefined) {
        return 'Lutron client not found';
    }
    
    const commands = shadeCommands[channel];
    commands[command]?.map(async (cmd) => {
        lutron_client.send(cmd);
    });

    const channelDetails = await Device.findOne({ device_id: device_id, is_delete: false, "capabilities.channelId": channel }, { "capabilities.$": 1, Mac_addr:1 });
    
    await addLog({
            action: command.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, c => c.toUpperCase()),
            name: channelDetails.capabilities[0].name || '-',
            deviceId: device_id,
            deviceName: device_id,
            channelId: channelDetails.capabilities[0].channelId || '-',
            timestamp: Math.floor(Date.now() / 1000),
            type: 'Device',
            userId: '-',
            userName: '-'
    }, hideToaster);
    if (command === 'SHADE_UP')
        await Device.updateOne({ device_id: device_id, is_delete: false, "capabilities.channelId": channel }, { $set: { "capabilities.$.status": "open","capabilities.$.properties.openLevel": "100%" } });
    else if (command === 'SHADE_DOWN')
        await Device.updateOne({ device_id: device_id, is_delete: false, "capabilities.channelId": channel }, { $set: { "capabilities.$.status": "close", "capabilities.$.properties.openLevel": "0%" } });
    else if (command === 'SHADE_33')
        await Device.updateOne({ device_id: device_id, is_delete: false, "capabilities.channelId": channel }, { $set: { "capabilities.$.status": "open","capabilities.$.properties.openLevel": "33%" } });
    else if (command === 'SHADE_66')
        await Device.updateOne({ device_id: device_id, is_delete: false, "capabilities.channelId": channel }, { $set: { "capabilities.$.status": "open","capabilities.$.properties.openLevel": "66%" } });
    return true;
}

async function groupCommands(devices, device_id, brightness, username) {
    const deviceData = await Device.findOne({ device_id, is_delete: false });
    if (!deviceData) {
        console.error(`Device config not found for ${device_id}`);
        return [];
    }

    const setChannelQuery = {};
    const acc = {};

    for (const item of devices) {
        const obj = item._doc ? item._doc : item;
        const channelIndex = deviceData.capabilities.findIndex(
        (ch) => ch.channelId === obj.channelId
        );

        if (obj.channelType === "led") {
        if (brightness >= 0) {
            obj.brightness = brightness;
            obj.command = "brightness";
        }

        if (obj.brightness >= 0) {
            let bness = calcBrightness(
            Number(obj.brightness),
            deviceData.capabilities[channelIndex].properties.powerMax
            );

            const basePath = `capabilities.${channelIndex}`;

            if (obj.command === "brightness") {
            setChannelQuery[`${basePath}.properties.brightness`] = obj.brightness;
            } else if (obj.command === "on") {
            bness = calcBrightness(
                100,
                deviceData.capabilities[channelIndex].properties.powerMax
            );
            setChannelQuery[`${basePath}.properties.brightness`] = 100;
            setChannelQuery[`${basePath}.status`] = "on";
            } else if (obj.command === "off") {
            setChannelQuery[`${basePath}.status`] = "off";
            }

            obj.brightness = bness;
        }

        deviceData.capabilities[channelIndex].status = obj.command;
        } else if (obj.channelType === "shade") {
        const basePath = `capabilities.${channelIndex}`;
        setChannelQuery[`${basePath}.status`] = obj.command;

        if (obj.command === "open") {
            setChannelQuery[`${basePath}.properties.openLevel`] = "100%";
        } else if (obj.command === "close") {
            setChannelQuery[`${basePath}.properties.openLevel`] = "0%";
        }
        }

        await addLog({
            action:
                obj.command === "on"
                ? "Led On"
                : obj.command === "off"
                ? "Led Off"
                : obj.command === "brightness"
                ? `Led Brightness ${obj.brightness}`
                : obj.command === "open"
                ? "Shade Open"
                : "Shade Close",
            name: deviceData.capabilities[channelIndex].name || "",
            timestamp: Math.floor(Date.now() / 1000),
            type: "Device",
            deviceId: deviceData.device_id,
            deviceName: deviceData.name,
            channelId: obj.channelId,
            userId: "-",
            userName: username,
        }, true);

        const key =
        obj.channelType === "led"
            ? `${obj.channelType}-${obj.command}-${obj.brightness}`
            : `${obj.channelType}-${obj.command}`;

        if (!acc[key]) {
        acc[key] = {
            channelType: obj.channelType.toUpperCase(),
            channelId: obj.channelId,
            command: convertCommand(
            obj.channelType,
            obj.command,
            obj.brightness,
            obj.openLevel
            ),
            brightness: obj.brightness,
            openLevel: obj.openLevel,
            channelIds: [],
        };
        }

        // Extract numeric channel ID
        const num = parseInt(obj.channelId.replace(/\D+/g, ""), 10);
        if (!isNaN(num)) acc[key].channelIds.push(num);
    }

    await Device.updateOne(
        { device_id, is_delete: false },
        { $set: setChannelQuery }
    );

    return Object.values(acc);
}

function convertCommand(channelType, command,brightness,openLevel) {
    if (command === 'brightness') {
        return "LED_BRIGHTNESS";
    } 
    else {
        return channelType.toUpperCase() + '_' + command.toUpperCase();
    }
}

async function extractGroupChannels(type, deviceData, brightness, username) {
    const command =
        type === "GROUP_LED_ON" ? "Led On" :
        type === "GROUP_LED_OFF" ? "Led Off" :
        type.includes("GROUP_LED_BRIGHTNESS") ? "Led Brightness to " + brightness + "%" :
        type === "GROUP_SHADE_UP" ? "Shade Up" :
        type === "GROUP_SHADE_DOWN" ? "Shade Down" :
        type === "GROUP_SHADE_STOP" ? "Shade Stop" :
        type === "GROUP_SHADE_33" ? "Shade 33" :
        type === "GROUP_SHADE_66" ? "Shade 66" :
        null;

    if (type === "GROUP_LED_ON" || type.includes("GROUP_LED_BRIGHTNESS")) {
        const groupChannels = [];

        for (const device of deviceData?.devices ?? []) {
        const channelData = await Device.findOne({
            device_id: device.deviceId,
            is_delete: false
        });

        if (!channelData) continue;

        const acc = {};

        for (const ch of device.channels) {
            const channelInfo = channelData.capabilities.find(
            (cap) => cap.channelId === ch.channelId
            );
            if (!channelInfo) continue;

            const bness = brightness
            ? calcBrightness(Number(brightness), channelInfo?.properties?.powerMax)
            : calcBrightness(100, channelInfo?.properties?.powerMax);

            ch.brightness = bness;

            const key =
            ch.channelType === "LED"
                ? `${ch.channelType}-${ch.brightness}`
                : `${ch.channelType}-${ch.openLevel}`;

            if (!acc[key]) {
            acc[key] = {
                channelType: ch.channelType.toUpperCase(),
                brightness: ch.brightness,
                openLevel: ch.openLevel,
                channelIds: []
            };
            }

            // Extract numeric part of channelId
            const num = parseInt(ch.channelId?.replace(/\D+/g, ""), 10);
            if (!isNaN(num)) acc[key].channelIds.push(num);

            await addLog({
            action: command,
            name: channelInfo?.name || '-',
            timestamp: Math.floor(Date.now() / 1000),
            deviceId: channelData.device_id || '-',
            deviceName: channelData.name || '-',
            channelId: channelInfo?.channelId || '-',
            type: 'Device',
            userId: '-',
            userName: username
            }, true);
        }

        for (const d of Object.values(acc)) {
            if (d?.channelIds?.length) {
            groupChannels.push({
                device_id: device.deviceId,
                channels: d.channelIds,
                brightness: d.brightness
            });
            }
        }
        }

        return groupChannels;
    }

    else if (type.includes("GROUP")) {
        const groupChannels = [];

        await Promise.all(
            (deviceData?.devices ?? []).map(async (device) => {
            // Filter relevant channels (LED or SHADE)
            const filteredChannels = device.channels.filter((ch) =>
            type.includes("LED")
                ? ch.channelType === "LED"
                : ch.channelType === "SHADE"
            );

            const channels = await Promise.all(
                filteredChannels.map(async (ch) => {
                    const deviceDetails = await Device.findOne(
                        {
                            device_id: device.deviceId,
                            is_delete: false,
                            "capabilities.channelId": ch.channelId
                        },
                        { name: 1, "capabilities.$": 1 }
                    );

                    await addLog({
                        action: command,
                        name: deviceDetails?.capabilities?.[0]?.name || '',
                        deviceId: device.deviceId || '-',
                        deviceName: deviceDetails?.name || '-',
                        channelId: ch.channelId || '-',
                        timestamp: Math.floor(Date.now() / 1000),
                        type: 'Device',
                        userId: '-',
                        userName: username
                    }, true);

                    if ("numberOfCmds" in ch) {
                    // Keep full channelId (e.g. "SHADE1")
                        return ch.channelId;
                    } else {
                    // Extract numeric part (e.g. "1" from "LED1")
                        return Number(ch.channelId.replace(/^\D+/g, ""));
                    }
                })
            );
                
            const shadeOpenLevel =
                type === "Shade Up" ? 100 :
                type === "Shade Down" ? 0 :
                type === "Shade Stop" ? 100 :
                type === "Shade 33" ? 33 :
                type === "Shade 66" ? 66 :
                null;

            groupChannels.push({
                device_id: device.deviceId,
                channels,
                openLevel: shadeOpenLevel
            });
        })
        );

        return groupChannels;
    }

    // Default fallback
    return [];
}


async function updateDeviceData(deviceId, channelAddress, data) {
    const setObj = { "capabilities.$.lastUpdated": new Date() };

  if (data.status) {
    setObj["capabilities.$.status"] = data.status;
  }

  if (data.properties) {
    for (const [key, value] of Object.entries(data.properties)) {
      setObj[`capabilities.$.properties.${key}`] = value;
    }
  } 
    const update = await Device.findOneAndUpdate({
        device_id: deviceId, is_delete: false,
        "capabilities.channelId": channelAddress
    }, { $set: setObj });
    
     if (!update)
         return { message :"Error in updating", deviceId, channelAddress };
     else {
         const data = update.capabilities.find(ch => ch.channelId === channelAddress);
        return data;
    }    
}

function calcBrightness(brightness, powerMax) {
 let bness1 = Math.round(Number(powerMax) * (brightness / 100));
    if (bness1 === 0) {
        bness1 = 1;
    }
    return bness1;
}
