import axios from "axios";
import { getConfig } from "../config/env.js";

export async function sendCommand(payload, topic) {
    console.log("---payload", payload, "------", topic);
    
//    return true;
//     To be uncommented before merging
    const conf = {
        MQTT_HOST: getConfig().mqttHost,
        MQTT_PORT: getConfig().mqttPort
    };
    try {
        const response = await axios.post(`http://${conf.MQTT_HOST}:${conf.MQTT_PORT}/mqtt/control`, { payload, topic });
        return true;
    } catch (error) {
        console.log({payload,topic})
        console.error(`Failed to send command: ${error.message}`);
        return error.message;
    }
}
