import mongoose from 'mongoose';
import { CampusZone } from '../models/CampusZone.js';
import { CampusFloor } from '../models/CampusFloor.js';
import { CampusBuilding } from '../models/CampusBuilding.js';
import { Campus } from '../models/Campus.js';

// Get zones for specific floor with device counts and pagination
// - Filters zones by floor with active device count calculation
// - Supports search, status filtering, and flexible sorting
// - Returns zones with populated floor information
export const getZonesByFloor = async (floorId, queryParams = {}) => {
  const {
    page = 1,
    limit = 20,
    status,
    type,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc'
  } = queryParams;

  // Build filter object
  const filter = { floorId, isDelete: { $ne: true } };
  
  if (status) {
    filter.status = status;
  }
  
  if (type) {
    filter.type = type;
  }
  
  if (search) {
    filter.$or = [
      { name: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } }
    ];
  }

  // Calculate skip value for pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);

  // Get sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // Execute query with pagination
  let zones = await CampusZone.find(filter)
    .populate('floorId', 'name floorLevel')
    .populate('devices')
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email')
    .sort(sort)
    .skip(skip)
    .limit(parseInt(limit))
    .lean();

  // Add active device count for each zone
  for (const zone of zones) {
    // Count active devices for this zone
    const deviceCount = zone.devices 
      ? zone.devices.filter(device => device.status === 'Active').length
      : 0;
    
    // Add counts to zone object
    zone.deviceCount = zone.devices ? zone.devices.length : 0; // Total devices (for backward compatibility)
    zone.deviceCount = deviceCount; // Active devices only
  }

  // Get total count for pagination
  const total = await CampusZone.countDocuments(filter);

  return {
    zones,
    pagination: {
      currentPage: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit)),
      totalZones: total,
      hasNextPage: skip + zones.length < total,
      hasPrevPage: parseInt(page) > 1
    }
  };
};

// Create zone with floor validation and user access setup
// - Validates floor existence and zone name uniqueness
// - Updates floor's zones array for relationship management
// - Populates response with floor and user information
export const addZone = async (zoneData, user) => {
  // Verify floor exists
  const floor = await CampusFloor.findById(zoneData.floorId);
  if (!floor) {
    throw new Error('Floor not found');
  }

  // Check if zone with same name already exists in this floor
  const existingZone = await CampusZone.findOne({ 
    name: zoneData.name, 
    floorId: zoneData.floorId,
    isDelete: { $ne: true }
  });
  if (existingZone) {
    throw new Error('Zone with this name already exists in the floor');
  }

  // Create zone with user information
  const zone = new CampusZone({
    ...zoneData,
    createdBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    },
    updatedBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    }
  });

  await zone.save();

  // Add zone to floor zones array
  await CampusFloor.findByIdAndUpdate(
    zoneData.floorId,
    { $push: { zones: zone._id } },
    { new: true }
  );

  await zone.populate([
    { path: 'floorId', select: 'name floorLevel' },
    { path: 'createdBy.userId', select: 'fullName email' }
  ]);
  
  return zone;
};

// Create zone with direct floor ID and comprehensive user access management
// - Validates floor existence and zone name uniqueness within floor
// - Updates user allowedResources and campusData for immediate access
// - Populates full hierarchy chain for response context
export const addZoneWithIds = async (zoneData, user) => {
  const { floorId, zoneName, description, type, status, zoneImage } = zoneData;

  // Verify floor exists
  const floor = await CampusFloor.findById(floorId);
  if (!floor) {
    throw new Error('Floor not found');
  }

  // Check if zone with same name already exists in this floor
  const existingZone = await CampusZone.findOne({ 
    name: zoneName, 
    floorId: floorId,
    isDelete: { $ne: true }
  });
  if (existingZone) {
    throw new Error('Zone with this name already exists in the floor');
  }

  // Convert status string to number if provided
  let statusValue = 1; // default to active
  if (status) {
    statusValue = status === 'active' ? 1 : 0;
  }

  // Create zone with user information
  const zone = new CampusZone({
    name: zoneName,
    description,
    type: type || 'other',
    status: statusValue,
    zoneImage: zoneImage || '',
    floorId,
    createdBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    },
    updatedBy: {
      userId: user._id,
      fullName: user.fullName,
      email: user.email
    }
  });

  await zone.save();

  // Add zone to floor zones array
  await CampusFloor.findByIdAndUpdate(
    floorId,
    { $push: { zones: zone._id } },
    { new: true }
  );

  // Populate zone with related data for response
  await zone.populate([
    { 
      path: 'floorId', 
      select: 'name floorLevel buildingId',
      populate: {
        path: 'buildingId',
        select: 'name campusId',
        populate: {
          path: 'campusId',
          select: 'name organization'
        }
      }
    },
    { path: 'createdBy.userId', select: 'fullName email' }
  ]);

  // --- Add zone._id to allowedResources.campusManagement.zones for all users who have the array ---
  const { User } = await import('../models/User.js');
  if (zone && zone._id) {
    await User.updateMany(
      { 'allowedResources.campusManagement.zones': { $exists: true, $type: 'array' } },
      { $addToSet: { 'allowedResources.campusManagement.zones': zone._id } }
    );
  }

  // --- Append this zone into the requesting user's campusData under the correct campus/building/floor ---
  try {
    // We have floorId, and through population we can access names and parent ids
    const floorDoc = zone.floorId; // populated
    const buildingDoc = floorDoc?.buildingId;
    const campusDoc = buildingDoc?.campusId;

    const campusIdStr = String(campusDoc?._id || '');
    const buildingIdStr = String(buildingDoc?._id || '');
    const floorIdStr = String(floorId);

    const zoneForUser = {
      zone_id: zone._id.toString(),
      zone_name: zone.name
    };

    // 1) Try push by strict ids using arrayFilters
    const byIds = await User.updateOne(
      { _id: user._id },
      {
        $push: { 'campusData.$[c].buildings.$[b].floors.$[f].zones': zoneForUser },
        $set: {
          updatedBy: { userId: user._id, fullName: user.fullName, email: user.email },
          updatedDate: new Date().toISOString()
        }
      },
      {
        arrayFilters: [
          { 'c.campus_id': campusIdStr },
          { 'b.building_id': buildingIdStr },
          { 'f.floor_id': floorIdStr }
        ]
      }
    );

    if (!byIds || (byIds.modifiedCount === 0 && byIds.matchedCount === 0)) {
      // 2) Try by names (case-insensitive)
      const byNames = await User.updateOne(
        { _id: user._id },
        {
          $push: { 'campusData.$[c].buildings.$[b].floors.$[f].zones': zoneForUser },
          $set: {
            updatedBy: { userId: user._id, fullName: user.fullName, email: user.email },
            updatedDate: new Date().toISOString()
          }
        },
        {
          arrayFilters: [
            { 'c.campus_name': { $regex: new RegExp(`^${campusDoc?.name || ''}$`, 'i') } },
            { 'b.building_name': { $regex: new RegExp(`^${buildingDoc?.name || ''}$`, 'i') } },
            { 'f.floor_name': { $regex: new RegExp(`^${floorDoc?.name || ''}$`, 'i') } }
          ]
        }
      );

      if (!byNames || (byNames.modifiedCount === 0 && byNames.matchedCount === 0)) {
        // 3) If floor entry missing, try to append a new floor with this zone under existing building
        const pushFloorByIds = await User.updateOne(
          { _id: user._id, 'campusData.campus_id': campusIdStr, 'campusData.buildings.building_id': buildingIdStr },
          {
            $push: {
              'campusData.$[c].buildings.$[b].floors': {
                floor_id: floorIdStr,
                floor_name: floorDoc?.name || '',
                zones: [zoneForUser]
              }
            },
            $set: {
              updatedBy: { userId: user._id, fullName: user.fullName, email: user.email },
              updatedDate: new Date().toISOString()
            }
          },
          {
            arrayFilters: [
              { 'c.campus_id': campusIdStr },
              { 'b.building_id': buildingIdStr }
            ]
          }
        );

        if (!pushFloorByIds || (pushFloorByIds.modifiedCount === 0 && pushFloorByIds.matchedCount === 0)) {
          // 4) If building entry missing, append a new building with this floor+zone under campus
          const pushBuildingById = await User.updateOne(
            { _id: user._id, 'campusData.campus_id': campusIdStr },
            {
              $push: {
                'campusData.$.buildings': {
                  building_id: buildingIdStr,
                  building_name: buildingDoc?.name || '',
                  floors: [{
                    floor_id: floorIdStr,
                    floor_name: floorDoc?.name || '',
                    zones: [zoneForUser]
                  }]
                }
              },
              $set: {
                updatedBy: { userId: user._id, fullName: user.fullName, email: user.email },
                updatedDate: new Date().toISOString()
              }
            }
          );

          if (!pushBuildingById || (pushBuildingById.modifiedCount === 0 && pushBuildingById.matchedCount === 0)) {
            // 5) Last fallback by campus name (do not create campus entry if campusData missing entirely)
            await User.updateOne(
              { _id: user._id, 'campusData.campus_name': { $regex: new RegExp(`^${campusDoc?.name || ''}$`, 'i') } },
              {
                $push: {
                  'campusData.$.buildings': {
                    building_id: buildingIdStr,
                    building_name: buildingDoc?.name || '',
                    floors: [{
                      floor_id: floorIdStr,
                      floor_name: floorDoc?.name || '',
                      zones: [zoneForUser]
                    }]
                  }
                },
                $set: {
                  updatedBy: { userId: user._id, fullName: user.fullName, email: user.email },
                  updatedDate: new Date().toISOString()
                }
              }
            );
          }
        }
      }
    }
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error('Failed to update requesting user campusData with new zone:', e);
  }

  return zone;
};

// Get zone by ID
export const getZoneById = async (zoneId) => {
  const zone = await CampusZone.findOne({ _id: zoneId, isDelete: { $ne: true } })
    .populate('floorId', 'name floorLevel')
    .populate('devices')
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email')
    .lean();

  if (!zone) {
    throw new Error('Zone not found');
  }

  // Add active device count
  const activeDeviceCount = zone.devices 
    ? zone.devices.filter(device => device.status === 'Active').length
    : 0;
  
  // Add counts to zone object
  zone.deviceCount = zone.devices ? zone.devices.length : 0; // Total devices (for backward compatibility)
  zone.activeDeviceCount = activeDeviceCount; // Active devices only

  return zone;
};

// Get comprehensive zone details using MongoDB aggregation pipeline
// - Joins zone with complete hierarchy (campus → building → floor)
// - Calculates configured device count and provides formatted dates
// - Returns structured data with all hierarchy levels and device statistics
export const getZoneDetails = async (zoneId) => {
  const pipeline = [
    {
      $match: {
        _id: new mongoose.Types.ObjectId(zoneId),
        isDelete: { $ne: true }   // ✅ fixed field
      }
    },
    {
      $lookup: {
        from: 'campusfloors',
        localField: 'floorId',
        foreignField: '_id',
        as: 'floor'
      }
    },
    { $unwind: { path: '$floor', preserveNullAndEmptyArrays: true } },
    {
      $lookup: {
        from: 'campusbuildings',
        localField: 'floor.buildingId',
        foreignField: '_id',
        as: 'building'
      }
    },
    { $unwind: { path: '$building', preserveNullAndEmptyArrays: true } },
    {
      $lookup: {
        from: 'campuses',
        localField: 'building.campusId',
        foreignField: '_id',
        as: 'campus'
      }
    },
    { $unwind: { path: '$campus', preserveNullAndEmptyArrays: true } },
    {
      $lookup: {
        from: 'devices',
        localField: '_id',
        foreignField: 'zone',
        as: 'deviceDetails'
      }
    },
    {
      $project: {
        zoneId: '$_id',
        zoneName: '$name',
        zoneType: '$type',
        zoneDescription: '$description',
        zoneImage: '$zoneImage',
        campusName: '$campus.name',
        campusId: '$campus._id',
        buildingName: '$building.name',
        buildingId: '$building._id',
        floorName: '$floor.name',
        floorLevel: '$floor.floorLevel',
        floorId: '$floor._id',
        deviceCount: {
          $size: {
            $filter: {
              input: '$deviceDetails',
              as: 'device',
              cond: { 
                $and: [
                  { $eq: ['$$device.status', 'Active'] },
                  { $ne: ['$$device.is_delete', true] }
                ]
              }
            }
          }
        },
        devices: '$devices',
        status: {
          $cond: {
            if: { $eq: ['$status', 1] },
            then: 'active',
            else: 'inactive'
          }
        },
        statusCode: '$status',
        createdAt: 1,
        updatedAt: 1,
        createdOn: {
          $dateToString: { format: '%d/%m/%Y', date: '$createdAt' }
        },
        updatedOn: {
          $dateToString: { format: '%d/%m/%Y', date: '$updatedAt' }
        },
        createdBy: {
          userId: '$createdBy.userId',
          fullName: '$createdBy.fullName',   // ✅ already stored
          email: '$createdBy.email'
        },
        updatedBy: {
          userId: '$updatedBy.userId',
          fullName: '$updatedBy.fullName',
          email: '$updatedBy.email'
        }
      }
    }
  ];

  const result = await CampusZone.aggregate(pipeline);

  if (!result || result.length === 0) {
    throw new Error('Zone not found');
  }

  // Add configuredDeviceCount (devices with configure_flag:true and not deleted)
  const zone = result[0];
  const Device = (await import('../models/Device.js')).default;
  const configuredDeviceCount = await Device.countDocuments({
    zone: zone.zoneId,
    configure_flag: true,
    is_delete: { $ne: true }
  });
  zone.configuredDeviceCount = configuredDeviceCount;

  return zone;
};


export const getZoneList = async (queryParams = {}) => {
  const {
    page = 1,
    limit = 20,
    status,
    type,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    campusId,
    buildingId,
    floorId
  } = queryParams;

  const pageNum = parseInt(page, 10);
  const limitNum = parseInt(limit, 10);
  const skip = (pageNum - 1) * limitNum;
  const order = sortOrder === 'asc' ? 1 : -1;

  // 1) Root-level match FIRST
  const rootMatch = { isDelete: { $ne: true } };

  if (status) {
    // 'active' | 'inactive'
    rootMatch.status = status === 'active' ? 1 : 0;
  }

  if (type) {
    rootMatch.type = type;
  }

  if (floorId) {
    try {
      rootMatch.floorId = new mongoose.Types.ObjectId(floorId);
    } catch {
      // impossible to match an invalid id; force empty
      rootMatch.floorId = new mongoose.Types.ObjectId('000000000000000000000000');
    }
  }

  // 2) Base pipeline (root match + lookups with preserve)
  const basePipeline = [
    { $match: rootMatch },

    {
      $lookup: {
        from: 'campusfloors', // ensure this is the actual collection name
        localField: 'floorId',
        foreignField: '_id',
        as: 'floor'
      }
    },
    { $unwind: { path: '$floor', preserveNullAndEmptyArrays: true } },

    {
      $lookup: {
        from: 'campusbuildings',
        localField: 'floor.buildingId',
        foreignField: '_id',
        as: 'building'
      }
    },
    { $unwind: { path: '$building', preserveNullAndEmptyArrays: true } },

    {
      $lookup: {
        from: 'campuses',
        localField: 'building.campusId',
        foreignField: '_id',
        as: 'campus'
      }
    },
    { $unwind: { path: '$campus', preserveNullAndEmptyArrays: true } }
  ];

  // 3) Joined-field filters AFTER lookups (only if provided)
  const joinedFilters = [];

  if (campusId) {
    try {
      joinedFilters.push({
        $match: { 'campus._id': new mongoose.Types.ObjectId(campusId) }
      });
    } catch {
      // force no match
      joinedFilters.push({
        $match: { 'campus._id': new mongoose.Types.ObjectId('000000000000000000000000') }
      });
    }
  }

  if (buildingId) {
    try {
      joinedFilters.push({
        $match: { 'building._id': new mongoose.Types.ObjectId(buildingId) }
      });
    } catch {
      joinedFilters.push({
        $match: { 'building._id': new mongoose.Types.ObjectId('000000000000000000000000') }
      });
    }
  }

  if (search && String(search).trim()) {
    const s = String(search).trim();
    joinedFilters.push({
      $match: {
        $or: [
          { 'floor.name':   { $regex: s, $options: 'i' } },
          { 'campus.name':  { $regex: s, $options: 'i' } },
          { name:           { $regex: s, $options: 'i' } }
        ]
      }
    });
  }

  // 4) Add device lookup and count configured devices
  const deviceLookupStage = {
    $lookup: {
      from: 'devices',
      localField: '_id',
      foreignField: 'zone',
      as: 'deviceDetails'
    }
  };

  // 5) Projection for final fields (zoneName, campusName, etc.)
  const projectionStage = {
    $project: {
      _id: 1,
      zoneName: '$name',
      campusName: '$campus.name',
      buildingName: '$building.name',
      floorName: '$floor.name',
      deviceCount: {
        $size: {
          $filter: {
            input: '$deviceDetails',
            as: 'device',
            cond: {
              $and: [
                { $ne: ['$$device.is_delete', true] },
                { $eq: ['$$device.configure_flag', true] }
              ]
            }
          }
        }
      },
      status: { $cond: [{ $eq: ['$status', 1] }, 'active', 'inactive'] },
      createdAt: 1,
      createdOn: { $dateToString: { format: '%d %m %Y', date: '$createdAt' } },
      type: 1,
      description: 1
    }
  };

  // 6) Build pipelines
  const pipelineForCount = [
    ...basePipeline,
    ...joinedFilters,
    deviceLookupStage,
    projectionStage,
    { $count: 'total' }
  ];

  const sortStage = (() => {
    const s = {};
    if (sortBy === 'createdAt') s.createdAt = order;
    else if (sortBy === 'zoneName') s.zoneName = order;
    else if (sortBy === 'campusName') s.campusName = order;
    else if (sortBy === 'buildingName') s.buildingName = order;
    else if (sortBy === 'floorName') s.floorName = order;
    else s.createdAt = -1;
    return { $sort: s };
  })();

  const pipelineForData = [
    ...basePipeline,
    ...joinedFilters,
    deviceLookupStage,
    projectionStage,
    sortStage,
    { $skip: skip },
    { $limit: limitNum }
  ];

  // 7) Execute
  const [totalResult, zones] = await Promise.all([
    CampusZone.aggregate(pipelineForCount),
    CampusZone.aggregate(pipelineForData)
  ]);

  const total = totalResult?.[0]?.total ?? 0;
  const totalPages = Math.ceil(total / limitNum);

  // 8) Stats (same filters, no pagination; counts from numeric status on root docs)
  const pipelineForStats = [
    ...basePipeline,
    ...joinedFilters,
    deviceLookupStage,
    {
      $group: {
        _id: null,
        totalZones: { $sum: 1 },
        activeZones: { $sum: { $cond: [{ $eq: ['$status', 1] }, 1, 0] } },
        inactiveZones: { $sum: { $cond: [{ $eq: ['$status', 0] }, 1, 0] } },
        totalDevices: {
          $sum: {
            $size: {
              $filter: {
                input: '$deviceDetails',
                as: 'device',
                cond: {
                  $and: [
                    { $ne: ['$$device.is_delete', true] },
                    { $eq: ['$$device.configure_flag', true] }
                  ]
                }
              }
            }
          }
        },
        totalActiveDevices: {
          $sum: {
            $size: {
              $filter: {
                input: '$deviceDetails',
                as: 'device',
                cond: {
                  $and: [
                    { $ne: ['$$device.is_delete', true] },
                    { $eq: ['$$device.configure_flag', true] }
                  ]
                }
              }
            }
          }
        }
      }
    }
  ];

  const stats = (await CampusZone.aggregate(pipelineForStats))?.[0] ?? {
    totalZones: 0,
    activeZones: 0,
    inactiveZones: 0,
    totalDevices: 0,
    totalActiveDevices: 0
  };

  return {
    zones,
    pagination: {
      currentPage: pageNum,
      totalPages,
      totalRecords: total,
      perPage: limitNum,
      hasNextPage: pageNum < totalPages,
      hasPrevPage: pageNum > 1
    },
    totals: {
      totalZones: stats.totalZones || 0,
      totalActive: stats.activeZones || 0,
      totalInactive: stats.inactiveZones || 0,
      totalDevices: stats.totalDevices || 0,
      totalActiveDevices: stats.totalActiveDevices || 0
    }
  };
};

// Update zone information
export const updateZone = async (zoneId, updateData, user) => {
  // Verify zone exists
  const existingZone = await CampusZone.findOne({ _id: zoneId, isDelete: { $ne: true } });
  if (!existingZone) {
    throw new Error('Zone not found');
  }

  // Map zoneName to name if provided
  if (updateData.zoneName) {
    updateData.name = updateData.zoneName;
    delete updateData.zoneName;
  }
  
  // Map zoneDescription to description if provided
  if (updateData.zoneDescription !== undefined) {
    updateData.description = updateData.zoneDescription;
    delete updateData.zoneDescription;
  }

  // If name is being updated, check if it already exists in the same floor
  if (updateData.name && updateData.name !== existingZone.name) {
    const existingZoneWithName = await CampusZone.findOne({ 
      name: updateData.name, 
      floorId: existingZone.floorId,
      isDelete: { $ne: true },
      _id: { $ne: zoneId } // Exclude current zone from the check
    });
    if (existingZoneWithName) {
      throw new Error('Zone with this name already exists in the floor');
    }
  }

  // Convert status string to number if provided
  if (updateData.status) {
    if (updateData.status === 'inactive') updateData.status = 0;
    else if (updateData.status === 'active') updateData.status = 1;
  }

  // Update zone with user information
  const updatedZone = await CampusZone.findByIdAndUpdate(
    zoneId,
    {
      ...updateData,
      updatedBy: {
        userId: user._id,
        fullName: user.fullName,
        email: user.email
      },
      updatedAt: new Date()
    },
    { 
      new: true, // Return the updated document
      runValidators: true // Run schema validations
    }
  ).populate([
    { 
      path: 'floorId', 
      select: 'name floorLevel buildingId',
      populate: {
        path: 'buildingId',
        select: 'name campusId',
        populate: {
          path: 'campusId',
          select: 'name organization'
        }
      }
    },
    { path: 'createdBy.userId', select: 'fullName email' },
    { path: 'updatedBy.userId', select: 'fullName email' }
  ]);

  return updatedZone;
};

// Update zone status
export const updateZoneStatus = async (zoneId, status, user) => {
  // Verify zone exists and is not deleted
  const existingZone = await CampusZone.findOne({ _id: zoneId, isDelete: { $ne: true } });
  if (!existingZone) {
    throw new Error('Zone not found');
  }

  // Convert status string to number
  let statusValue;
  if (typeof status === 'string') {
    statusValue = status === 'active' ? 1 : 0;
  } else if (typeof status === 'number') {
    statusValue = status === 1 ? 1 : 0;
  } else {
    throw new Error('Invalid status value. Must be "active", "inactive", 1, or 0');
  }

  // Update zone status with user information
  const updatedZone = await CampusZone.findByIdAndUpdate(
    zoneId,
    {
      status: statusValue,
      updatedBy: {
        userId: user._id,
        fullName: user.fullName,
        email: user.email
      },
      updatedAt: new Date()
    },
    { 
      new: true, // Return the updated document
      runValidators: true // Run schema validations
    }
  ).populate([
    { 
      path: 'floorId', 
      select: 'name floorLevel buildingId',
      populate: {
        path: 'buildingId',
        select: 'name campusId',
        populate: {
          path: 'campusId',
          select: 'name organization'
        }
      }
    },
    { path: 'createdBy.userId', select: 'fullName email' },
    { path: 'updatedBy.userId', select: 'fullName email' }
  ]);

  return updatedZone;
};

// Delete zone with complete device state management and intelligent control cleanup
// - Moves zone devices to 'Discovered' state (preserves hardware for reconfiguration)
// - Removes devices from groups, scenes, sensors, templates via device service
// - Returns deletion statistics for audit logging
export const deleteZone = async (zoneId, user) => {
  const existingZone = await CampusZone.findOne({ _id: zoneId, isDelete: { $ne: true } });
  if (!existingZone) {
    throw new Error('Zone not found');
  }

  // Import required models and functions
  const Device = (await import('../models/Device.js')).default;
  const { removeDeviceFromRelatedCollections } = await import('./device.service.js');

  // Get devices in zone and move them to 'Discovered' state
  const devices = await Device.find({ zone: zoneId }).select('device_id');
  
  // Update devices to 'Discovered' state (same as device deletion)
  await Device.updateMany(
    { zone: zoneId },
    { 
      is_delete: false,
      configure_flag: false
    }
  );

  // Remove each device from related collections (same as device deletion)
  for (const device of devices) {
    await removeDeviceFromRelatedCollections(device.device_id, user);
  }

  // Delete zone
  await CampusZone.deleteOne({ _id: zoneId });

  return {
    success: true,
    message: 'Zone deleted successfully. All devices moved to Discovered state and intelligent control data permanently deleted.',
    zone: { _id: zoneId },
    deletedCounts: {
      devicesMovedToDiscovered: devices.length
    }
  };
};

// Get all zones without pagination for UI components (dropdowns, multi-select)
// - Uses aggregation pipeline for hierarchy filtering and device counts
// - Supports campus/building/floor scoping for contextualized zone selection
// - Optimized for UI components requiring complete zone lists
export const getAllZones = async (queryParams = {}) => {
  const {
    status,
    type,
    search,
    sortBy = 'name',
    sortOrder = 'asc',
    campusId,
    buildingId,
    floorId
  } = queryParams;

  // 1) Root-level match for zones that are not deleted
  const rootMatch = { isDelete: { $ne: true } };

  if (status) {
    // 'active' | 'inactive'
    rootMatch.status = status === 'active' ? 1 : 0;
  }

  if (type) {
    rootMatch.type = type;
  }

  if (floorId) {
    try {
      rootMatch.floorId = new mongoose.Types.ObjectId(floorId);
    } catch {
      // Invalid ObjectId, force no match
      rootMatch.floorId = new mongoose.Types.ObjectId('000000000000000000000000');
    }
  }

  // 2) Base pipeline with lookups
  const basePipeline = [
    { $match: rootMatch },

    {
      $lookup: {
        from: 'campusfloors',
        localField: 'floorId',
        foreignField: '_id',
        as: 'floor'
      }
    },
    { $unwind: { path: '$floor', preserveNullAndEmptyArrays: true } },

    {
      $lookup: {
        from: 'campusbuildings',
        localField: 'floor.buildingId',
        foreignField: '_id',
        as: 'building'
      }
    },
    { $unwind: { path: '$building', preserveNullAndEmptyArrays: true } },

    {
      $lookup: {
        from: 'campuses',
        localField: 'building.campusId',
        foreignField: '_id',
        as: 'campus'
      }
    },
    { $unwind: { path: '$campus', preserveNullAndEmptyArrays: true } }
  ];

  // 3) Joined-field filters AFTER lookups
  const joinedFilters = [];

  if (campusId) {
    try {
      joinedFilters.push({
        $match: { 'campus._id': new mongoose.Types.ObjectId(campusId) }
      });
    } catch {
      // Invalid ObjectId, force no match
      joinedFilters.push({
        $match: { 'campus._id': new mongoose.Types.ObjectId('000000000000000000000000') }
      });
    }
  }

  if (buildingId) {
    try {
      joinedFilters.push({
        $match: { 'building._id': new mongoose.Types.ObjectId(buildingId) }
      });
    } catch {
      joinedFilters.push({
        $match: { 'building._id': new mongoose.Types.ObjectId('000000000000000000000000') }
      });
    }
  }

  if (search && String(search).trim()) {
    const s = String(search).trim();
    joinedFilters.push({
      $match: {
        $or: [
          { name: { $regex: s, $options: 'i' } },
          { description: { $regex: s, $options: 'i' } },
          { 'floor.name': { $regex: s, $options: 'i' } },
          { 'building.name': { $regex: s, $options: 'i' } },
          { 'campus.name': { $regex: s, $options: 'i' } }
        ]
      }
    });
  }

  // 4) Add device lookup for count
  const deviceLookupStage = {
    $lookup: {
      from: 'devices',
      localField: '_id',
      foreignField: 'zone',
      as: 'deviceDetails'
    }
  };

  // 5) Projection for clean output
  const projectionStage = {
    $project: {
      _id: 1,
      zoneId: '$_id',
      zoneName: '$name',
      name: '$name', // Keep both for compatibility
      description: 1,
      type: 1,
      zoneImage: 1,
      campusId: '$campus._id',
      campusName: '$campus.name',
      buildingId: '$building._id',
      buildingName: '$building.name',
      floorId: '$floor._id',
      floorName: '$floor.name',
      floorLevel: '$floor.floorLevel',
      deviceCount: {
        $size: {
          $filter: {
            input: '$deviceDetails',
            as: 'device',
            cond: {
              $and: [
                { $ne: ['$$device.is_delete', true] },
                { $eq: ['$$device.configure_flag', true] }
              ]
            }
          }
        }
      },
      status: { $cond: [{ $eq: ['$status', 1] }, 'active', 'inactive'] },
      statusCode: '$status',
      createdAt: 1,
      updatedAt: 1
    }
  };

  // 6) Sorting
  const order = sortOrder === 'asc' ? 1 : -1;
  const sortStage = (() => {
    const s = {};
    if (sortBy === 'name' || sortBy === 'zoneName') s.name = order;
    else if (sortBy === 'campusName') s.campusName = order;
    else if (sortBy === 'buildingName') s.buildingName = order;
    else if (sortBy === 'floorName') s.floorName = order;
    else if (sortBy === 'createdAt') s.createdAt = order;
    else if (sortBy === 'type') s.type = order;
    else if (sortBy === 'status') s.statusCode = order;
    else s.name = 1; // Default to name ascending
    return { $sort: s };
  })();

  // 7) Build final pipeline
  const finalPipeline = [
    ...basePipeline,
    ...joinedFilters,
    deviceLookupStage,
    projectionStage,
    sortStage
  ];

  // 8) Execute query
  const zones = await CampusZone.aggregate(finalPipeline);

  return {
    zones,
    totalCount: zones.length,
    message: `Retrieved ${zones.length} zones successfully`
  };
};
