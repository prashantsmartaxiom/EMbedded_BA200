import bcrypt from 'bcryptjs';
import { User } from '../models/User.js';
import { emailService } from './emailService.js';
import { generateSecureToken, generateOTP, createHash } from '../config/crypto.js';
import { getConfig } from '../config/env.js';

class ResetService {
  async requestPasswordReset(email) {
    console.log(`🔐 Password reset request initiated for email: ${email}`);
    
    // Check if user exists
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      console.log(`❌ Password reset failed - User not found for email: ${email}`);
      // Return explicit status that user doesn't exist and no email sent
      return {
        success: false,
        code: 404, // add explicit code
        message: 'No user found with this email',
        data: {
          email: email,
          emailSent: false,
          emailStatus: 'No user found with this email',
          requestTime: new Date().toISOString()
        }
      };
    }

    console.log(`✅ User found for email: ${email}, UserId: ${user._id}`);
    

    // Check if user has recent reset request (rate limiting)
    const now = new Date();
    if (user.resetPassword?.requestedAt) {
      const timeDiff = now - new Date(user.resetPassword.requestedAt);
      const cooldownPeriod = 60 * 1000; // 1 minute cooldown
      
      if (timeDiff < cooldownPeriod) {
        const remainingTime = Math.ceil((cooldownPeriod - timeDiff) / 1000);
        console.log(`⏰ Rate limit exceeded for email: ${email}. Remaining cooldown: ${remainingTime} seconds`);
        // Return success response indicating OTP already sent instead of throwing error
        return {
          success: true,
          message: 'OTP already sent',
          data: {
            email: email,
            emailSent: true,
            emailStatus: 'OTP already sent - please check your email',
            requestTime: new Date(user.resetPassword.requestedAt).toISOString(),
            remainingCooldown: remainingTime,
            expiryTime: user.resetPassword.expiresAt?.toISOString()
          }
        };
      }
    }

    console.log(`🔑 Generating reset token and OTP for email: ${email}`);
    

    // Generate secure reset token and OTP
    const resetToken = generateSecureToken(32);
    const otp = generateOTP();
    
    // Hash the reset token and OTP for storage
    const hashedResetToken = createHash(resetToken);
    const hashedOTP = createHash(otp);

    // Calculate expiry time (15 minutes from now)
    const expiryTime = new Date(now.getTime() + getConfig().reset.tokenExpiryMinutes * 60 * 1000);

    console.log(`💾 Updating user reset data for email: ${email}, expires at: ${expiryTime.toISOString()}`);
    
    // Update user with reset information
    await User.findByIdAndUpdate(user._id, {
      $set: {
        'resetPassword.token': hashedResetToken,
        'resetPassword.otp': hashedOTP,
        'resetPassword.expiresAt': expiryTime,
        'resetPassword.requestedAt': now,
        'resetPassword.attempts': 0,
        'resetPassword.verified': false
      }
    });

    console.log(`📧 Attempting to send password reset email to: ${email}`);
    

    // Send password reset email
    let emailSent = false;
    let emailMessage = 'Mail not sent';
    let emailError = null;
    
    try {
      const emailResult = await emailService.sendPasswordResetEmail(email, resetToken, otp);
      emailSent = emailResult.success;
      emailMessage = emailSent ? 'Mail sent' : 'Mail not sent';
      
      if (emailSent) {
        console.log(`✅ Password reset email sent successfully to: ${email}, MessageId: ${emailResult.messageId || 'N/A'}`);
      } else {
        console.error(`❌ Email service returned failure for: ${email}`, emailResult);
      }
    } catch (emailSendError) {
      console.error(`🚨 Failed to send reset email to: ${email}`, emailSendError);
      emailSent = false;
      emailMessage = 'Mail not sent';
      emailError = emailSendError.message;
    }

    // If email failed to send, clean up the reset data from database
    if (!emailSent) {
      console.log(`🧹 Cleaning up reset data due to email failure for: ${email}`);
      await User.findByIdAndUpdate(user._id, {
        $unset: { resetPassword: 1 }
      });
    }

    console.log(`🔐 Password reset request completed for: ${email}, Email sent: ${emailSent}`);
    

    return {
      success: emailSent,
      message: emailMessage,
      data: {
        email: email,
        emailSent: emailSent,
        emailStatus: emailMessage,
        requestTime: now.toISOString(),
        expiryMinutes: emailSent ? getConfig().reset.tokenExpiryMinutes : null,
        error: emailError
      }
    };
  }

  async verifyResetOTP(email, otp) {
    console.log(`🔢 OTP verification request for email: ${email}`);
    
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      console.log(`❌ OTP verification failed - User not found for email: ${email}`);
      throw Object.assign(new Error('Invalid email or OTP'), { status: 400 });
    }

    console.log(`✅ User found for OTP verification: ${email}, UserId: ${user._id}`);
    

    const resetData = user.resetPassword;
    if (!resetData || !resetData.otp || !resetData.expiresAt) {
      console.log(`❌ OTP verification failed - No active reset request for email: ${email}`);
      throw Object.assign(new Error('No active password reset request'), { status: 400 });
    }

    // Check if OTP has expired
    if (new Date() > resetData.expiresAt) {
      console.log(`⏰ OTP verification failed - OTP expired for email: ${email}, Expired at: ${resetData.expiresAt}`);
      // Clean up expired reset data
      await User.findByIdAndUpdate(user._id, {
        $unset: { resetPassword: 1 }
      });
      throw Object.assign(new Error('OTP has expired. Please request a new password reset'), { status: 400 });
    }

    // Check attempt limit
    if (resetData.attempts >= getConfig().reset.maxAttempts) {
      console.log(`🚫 OTP verification failed - Too many attempts for email: ${email}, Attempts: ${resetData.attempts}`);
      throw Object.assign(new Error('Too many failed attempts. Please request a new password reset'), { status: 429 });
    }

    // Verify OTP
    const hashedInputOTP = createHash(otp);
    if (hashedInputOTP !== resetData.otp) {
      console.log(`❌ OTP verification failed - Invalid OTP for email: ${email}, Attempts: ${resetData.attempts + 1}`);
      // Increment failed attempts
      await User.findByIdAndUpdate(user._id, {
        $inc: { 'resetPassword.attempts': 1 }
      });
      
      const remainingAttempts = getConfig().reset.maxAttempts - (resetData.attempts + 1);
      throw Object.assign(new Error(`Invalid OTP. ${remainingAttempts} attempts remaining`), { status: 400 });
    }

    console.log(`✅ OTP verified successfully for email: ${email}`);
    

    // Mark OTP as verified
    await User.findByIdAndUpdate(user._id, {
      $set: { 'resetPassword.verified': true }
    });

    return {
      success: true,
      message: 'OTP verified successfully. You can now reset your password',
      data: {
        email: email,
        verified: true,
        expiresAt: resetData.expiresAt
      }
    };
  }

async resetPassword(email, token, newPassword, otpVerified = false) {
  console.log(`🔄 Password reset request for email: ${email}, Using token: ${!!token}, OTP verified: ${otpVerified}`);
  
  // ⬇️ IMPORTANT: include +password
  const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
  if (!user) {
    console.log(`❌ Password reset failed - User not found for email: ${email}`);
    throw Object.assign(new Error('Invalid reset request'), { status: 400 });
  }

  console.log(`✅ User found for password reset: ${email}, UserId: ${user._id}`);

  const resetData = user.resetPassword;
  if (!resetData || !resetData.expiresAt) {
    throw Object.assign(new Error('No active password reset request'), { status: 400 });
  }

  // expiry
  if (new Date() > resetData.expiresAt) {
    await User.findByIdAndUpdate(user._id, { $unset: { resetPassword: 1 } });
    throw Object.assign(new Error('Reset request has expired. Please request a new password reset'), { status: 400 });
  }

  // token path
  if (token) {
    const hashedInputToken = createHash(String(token)); // ⬅ defensive
    if (!resetData.token || hashedInputToken !== resetData.token) {
      throw Object.assign(new Error('Invalid reset token'), { status: 400 });
    }
  }
  // OTP path
  else if (!otpVerified && !resetData.verified) {
    throw Object.assign(new Error('OTP verification required before password reset'), { status: 400 });
  }

  // Validate strength
  if (!this.isValidPassword(newPassword)) {
    throw Object.assign(
      new Error('Password must be at least 8 characters long and contain uppercase, lowercase, number, and special character'),
      { status: 400 }
    );
  }

  // Don’t allow same password
  const isSamePassword = await bcrypt.compare(newPassword, user.password);
  if (isSamePassword) {
    console.log(`❌ Password reset failed - New password same as current for email: ${email}`);
    throw Object.assign(new Error('New password must be different from current password'), { status: 400 });
  }

  console.log(`🔐 Password reset successful for email: ${email} - updating database`);

  // Hash new password (you could also set user.password=newPassword; await user.save();)
  const saltRounds = 12;
  const hashedPassword = await bcrypt.hash(newPassword, saltRounds);

  await User.findByIdAndUpdate(
    user._id,
    {
      $set: {
        password: hashedPassword,
        updatedAt: new Date()
      },
      $unset: { resetPassword: 1 }
    }
  );

  //commenting for now
  // try {
  //   await emailService.sendPasswordChangedEmail(email);
  // } catch (e) {
  //   console.error(`❌ Failed to send confirmation email to: ${email}`, e);
  // }

  return {
    success: true,
    message: 'Password has been reset successfully. Please log in with your new password',
    data: { email, resetTime: new Date().toISOString() }
  };
}


  async cleanupExpiredResets() {
    try {
      const result = await User.updateMany(
        {
          'resetPassword.expiresAt': { $lt: new Date() }
        },
        {
          $unset: { resetPassword: 1 }
        }
      );
      
      return result.modifiedCount;
    } catch (error) {
      console.error('Error cleaning up expired resets:', error);
      return 0;
    }
  }

  isValidPassword(password) {
    // Password requirements:
    // - At least 8 characters long
    // - Contains uppercase letter
    // - Contains lowercase letter  
    // - Contains number
    // - Contains special character
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/;
    return passwordRegex.test(password);
  }

  async getResetStatus(email) {
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user || !user.resetPassword) {
      return { hasActiveReset: false };
    }

    const resetData = user.resetPassword;
    const now = new Date();
    
    if (now > resetData.expiresAt) {
      return { hasActiveReset: false, expired: true };
    }

    return {
      hasActiveReset: true,
      requestedAt: resetData.requestedAt,
      expiresAt: resetData.expiresAt,
      attempts: resetData.attempts || 0,
      maxAttempts: getConfig().reset.maxAttempts,
      verified: resetData.verified || false
    };
  }
}

export const resetService = new ResetService();
