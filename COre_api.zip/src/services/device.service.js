import Device from '../models/Device.js';
import { socketManager } from '../utils/socketManager.js';
import { Template } from '../models/Template.js';
import { deleteTemplate } from './template.service.js';
import { Group } from '../models/Group.js';
import { Scene } from '../models/Scene.js';
import { Sensor } from '../models/Sensor.js';
import DeviceConfig from '../utils/deviceConfig.js';
import { sendCommand } from './mqtt.service.js';
import { setLutronClient } from './device.lutron.js';
import { defaultLutronCapabilities } from '../utils/deviceCapabilities.js';
import mongoose from 'mongoose';

/**
 * Device Service - IoT Device Management & Control Layer
 * 
 * Flow: routes → controller → SERVICE → database/MQTT
 * 
 * Core Responsibilities:
 * - Device discovery and configuration management
 * - Channel control system (LED, shade, sensor)
 * - Device lifecycle management (discovered → configured → controlled)
 * - Location-based device organization
 * - Real-time MQTT communication
 * - Relationship management (groups, scenes, sensors, templates)
 * - Cascade cleanup operations
 * 
 * Device Architecture:
 * - Own Devices: BA-series smart building controllers
 * - Third-party: External IoT devices with custom capabilities
 * - Channels: Individual control points (lights, shades, sensors)
 * - Configuration: Assignment to building locations and communication setup
 * 
 * Key Features:
 * - Permission-based device filtering
 * - Complex channel state management
 * - Automated relationship cleanup
 * - Real-time status synchronization
 * - Advanced search and pagination
 */

/**
 * Update channel configuration including install/uninstall operations
 * Handles complex state transitions and relationship cleanup
 */
export const updateDeviceChannelName = async (deviceId, channelId, updateData, user) => {
  try {
    // Check if channelId is provided and not empty
    if (!channelId || channelId === '' || channelId === 'undefined' || channelId === 'null') {
      console.log('Channel ID validation failed:', {
        channelId,
        isEmpty: channelId === '',
        isUndefined: channelId === 'undefined',
        isNull: channelId === 'null',
        isFalsy: !channelId
      });
      throw new Error('Channel ID is required and cannot be empty');
    }

    const device = await Device.findOne({ device_id: deviceId, is_delete: false });
    if (!device) {
      throw new Error('Device not found');
    }
    // Ensure we have capabilities array
    if (!device.capabilities || !Array.isArray(device.capabilities)) {
      throw new Error('Device has no capabilities');
    }

    // Try exact match first
    let channelIndex = device.capabilities.findIndex(c => c.channelId === channelId);

    if (channelIndex === -1) {
      // Try case-insensitive match only if both values are strings
      channelIndex = device.capabilities.findIndex(c =>
        c.channelId &&
        typeof c.channelId === 'string' &&
        typeof channelId === 'string' &&
        c.channelId.toLowerCase() === channelId.toLowerCase()
      );
    }

    if (channelIndex === -1) {
      console.log('Channel not found. Available channelIds:');
      device.capabilities.forEach((cap, idx) => {
        console.log(`  [${idx}] channelId: "${cap.channelId}" (type: ${typeof cap.channelId})`);
      });
      throw new Error(`Channel '${channelId}' not found in device '${deviceId}'`);
    }

    
    const channel = device.capabilities[channelIndex];
    const { type, name, properties, status, installed } = updateData;

    // Track the old installed status to detect changes
    const oldInstalledStatus = channel.properties?.installed;
    let newInstalledStatus = oldInstalledStatus;
    
    console.log(`Channel ${deviceId}/${channelId} - Initial status check:`, {
      oldInstalledStatus,
      newInstalledStatus,
      channelProperties: channel.properties
    });

    // Update based on channel type
    switch (type) {
      case 'shade':
        if (name) channel.name = name;
        if (!channel.properties) channel.properties = {};

        //logic to update shade channel id
        // if (channelId === 'SHADE1') {
        //   console.log("---update---");
          
        //   const devices = await Device.find({ is_delete: false });
        //   devices.map(async(device) => {
        //     device.capabilities[12].channelId = 'SHADE12_ID1';
        //     device.capabilities[13].channelId = 'SHADE12_ID2';
        //     device.capabilities[14].channelId = 'SHADE12_ID3';
        //     device.capabilities[15].channelId = 'SHADE12_ID4';
        //     const newObjects = [
        //       {
        //         type: 'shade',
        //         name: 'Unnamed',
        //         channelId: 'SHADE34_ID1',
        //         status: 'closed',
        //         installed: false,
        //         properties: { openLevel: '0%', maxMovement: '4' }
        //       },
        //       {
        //         type: 'shade',
        //         name: 'Unnamed',
        //         channelId: 'SHADE34_ID2',
        //         status: 'closed',
        //         installed: false,
        //         properties: { openLevel: '0%', maxMovement: '4' }

        //       },
        //       {
        //         type: 'shade',
        //         name: 'Unnamed',
        //         channelId: 'SHADE34_ID3',
        //         status: 'closed',
        //         installed: false,
        //         properties: { openLevel: '0%', maxMovement: '4' }
        //       },
        //       {
        //         type: 'shade',
        //         name: 'Unnamed',
        //         channelId: 'SHADE34_ID4',
        //         status: 'closed',
        //         installed: false,
        //         properties: { openLevel: '0%', maxMovement: '4' }
        //       }
        //     ];
        //     const a =[
        //         ...device.capabilities.slice(0, 16),
        //         ...newObjects,
        //         ...device.capabilities.slice(16)
        //       ];
        //       device.capabilities.splice(16, 0, ...newObjects);
        //     console.log("----updated", device.capabilities.length, a);
        //     const res = await Device.findOneAndUpdate({ device_id: device.device_id }, { $set: { capabilities: device.capabilities } });
        //     // console.log("--res", res);
            
        //   });
        // }

        //send shade id setup cmd to mqtt
        if ((channel.properties?.installed ===undefined || channel.properties?.installed === false) && installed === true) {
          sendCommand({ "ch_t": 'SHADE', "ch_addr": channelId, "cmd": DeviceConfig.SHADE_CONFIG, "cmd_m": "shade_idsetup" }, deviceId);
        }

        // mark installed either from top-level flag or properties.installed
        if (installed !== undefined) {
          channel.properties.installed = !!installed;
          newInstalledStatus = !!installed;
        } else if (properties?.installed !== undefined) {
          channel.properties.installed = !!properties.installed;
          newInstalledStatus = !!properties.installed;
        } else {
          if (channel.properties.installed === undefined) {
            channel.properties.installed = true;
            newInstalledStatus = true;
          }
        }

        // openLevel
        if (properties?.openLevel !== undefined) {
          channel.properties.openLevel = properties.openLevel;
        }

        // movementControl: set from payload if provided; if not provided but missing in DB, create with null
        if (properties?.movementControl !== undefined) {
          channel.properties.movementControl = properties.movementControl;
        } else if (channel.properties.movementControl === undefined) {
          channel.properties.movementControl = null;
        }

        // openLevel: same logic as movementControl
        if (properties?.openLevel !== undefined) {
          channel.properties.openLevel = properties.openLevel;
        } else if (channel.properties.openLevel === undefined) {
          channel.properties.openLevel = null;
        }

        if (status) channel.status = status;
        break;

      case 'led':
        if (name) channel.name = name;
        if (!channel.properties) channel.properties = {};
        

        //send power config cmd
        if ((channel.properties.powerMax !== properties.powerMax) || (channel.properties.powerMin !== properties.powerMin)) {
            await sendCommand(
              { ch_t: channel.type.toUpperCase(), ch_addr: channel.channelId, cmd: DeviceConfig.LED_MAX_CUR, cmd_m: [Number(properties.powerMin), Number(properties.powerMax)] },
              deviceId
          );
        }
        
        // Handle installed flag for LED channels like we do for other types
        if (installed !== undefined) {
          channel.properties.installed = !!installed;
          newInstalledStatus = !!installed;
        } else if (properties?.installed !== undefined) {
          channel.properties.installed = !!properties.installed;
          newInstalledStatus = !!properties.installed;
        } else if (channel.properties.installed === undefined) {
          channel.properties.installed = true; // Default to true for LEDs
          newInstalledStatus = true;
        }
        
        if (properties?.powerMin) {
          channel.properties.powerMin = properties.powerMin;
        }
        if (properties?.powerMax) {
          channel.properties.powerMax = properties.powerMax;
        }
        if (properties?.color) {
          channel.properties.color = properties.color;
        }
        if (properties?.brightness !== undefined) {
          channel.properties.brightness = properties.brightness;
        }
        if (status) channel.status = status;
        break;

      case 'sensor':
        if (name) channel.name = name;
        if (!channel.properties) channel.properties = {};

        // installed pref: top-level -> properties -> preserve/create default true
        if (installed !== undefined) {
          channel.properties.installed = !!installed;
          newInstalledStatus = !!installed;
        } else if (properties?.installed !== undefined) {
          channel.properties.installed = !!properties.installed;
          newInstalledStatus = !!properties.installed;
        } else if (channel.properties.installed === undefined) {
          channel.properties.installed = true;
          newInstalledStatus = true;
        }

        // Copy known sensor fields from payload if present; otherwise ensure keys exist (null default)
        if (properties?.sensorType !== undefined) {
          channel.properties.sensorType = properties.sensorType;
        } else if (channel.properties.sensorType === undefined) {
          channel.properties.sensorType = null;
        }

        if (properties?.port !== undefined) {
          channel.properties.port = properties.port;
        } else if (channel.properties.port === undefined) {
          channel.properties.port = null;
        }

        if (properties?.sensorAddress !== undefined) {
          channel.properties.sensorAddress = properties.sensorAddress;
        } else if (channel.properties.sensorAddress === undefined) {
          channel.properties.sensorAddress = null;
        }

        if (properties?.commType !== undefined) {
          channel.properties.commType = properties.commType;
        } else if (channel.properties.commType === undefined) {
          channel.properties.commType = null;
        }

        if (status) channel.status = status;
        break;

      default:
        throw new Error('Invalid channel type');
    }

    console.log('Updated channel:', {
      channelId: channel.channelId,
      name: channel.name,
      type: channel.type,
      properties: channel.properties,
      oldInstalledStatus,
      newInstalledStatus
    });

    // Mark the capabilities array as modified for Mongoose
    device.markModified('capabilities');

    if (!device.createdBy) {
      device.createdBy = user._id;
    }
    device.updatedBy = user._id;
    device.updatedAt = new Date();

    // Save the device
    await device.save();

    console.log('Device saved successfully');
    socketManager.emitEvent("deviceStatusChanged", {uiType: ""});

    // Handle installed status changes
    console.log(`🔍 Status change check for ${deviceId}/${channelId}:`, {
      oldInstalledStatus,
      newInstalledStatus,
      willTriggerCleanup: oldInstalledStatus !== newInstalledStatus
    });
    
    if (oldInstalledStatus !== newInstalledStatus) {
      try {
        // Update templates based on installed status change
        await updateTemplatesForInstalledStatusChange(
          deviceId, 
          channelId, 
          channel, 
          oldInstalledStatus, 
          newInstalledStatus
        );

        // If channel is being uninstalled (marked as not installed), 
        // remove it from all related collections
        // Handle cases where oldInstalledStatus might be undefined (default true) or true
        if ((oldInstalledStatus === true || oldInstalledStatus === undefined) && newInstalledStatus === false) {
          console.log(`🗑️ Channel ${deviceId}/${channelId} marked as not installed, cleaning up related collections...`);
          await removeChannelFromRelatedCollections(deviceId, channelId, user);
        }
        
        // If channel is being installed (marked as installed),
        // add it to related collections where the device already exists
        if (oldInstalledStatus === false && newInstalledStatus === true) {
          console.log(`Channel ${deviceId}/${channelId} marked as installed, adding to related collections...`);
          await addChannelToRelatedCollections(deviceId, channelId, channel, user);
        }
      } catch (error) {
        console.error('Error updating templates or cleaning up related collections:', error);
        // Don't throw - channel update was successful, cleanup is secondary
      }
    }

    // Always try to remove uninstalled channels from group scenes
    if (newInstalledStatus === false) {
      try {
        console.log(`🗑️ Force removing channel ${deviceId}/${channelId} from group scenes (installed=false)...`);
        await removeChannelFromGroupScenes(deviceId, channelId, user);
      } catch (error) {
        console.error('Error force removing channel from group scenes:', error);
      }
    }

    // Return the updated channel
    return {
      channelId: channel.channelId,
      name: channel.name,
      type: channel.type,
      properties: channel.properties || {},
      status: channel.status || null,
      description: channel.description || null,
      updated_at: new Date()
    };

  } catch (error) {
    console.error('Error in updateDeviceChannelName:', error.message);
    console.error('Stack trace:', error.stack);
    throw new Error(`Error updating channel: ${error.message}`);
  }
};

/**
 * Remove related sensor data when a sensor channel is uninstalled
 */
export const deleteDeviceChannel = async (deviceId, channelId) => {
  try {
    const device = await Device.updateOne(
      { device_id: deviceId, is_delete: false },
      {
        $pull: {
          capabilities: {
            channelId: channelId,
            type: "sensor"
          }
        }
      }
    );
    removeRelatedSensorData(deviceId, channelId);
    console.log(`Related sensor data removed for device ${deviceId}, channel ${channelId}`);
    socketManager.emitEvent("deviceStatusChanged", {uiType: ""});
    return device;
  } catch (error) {
    console.error(`Error removing related sensor data for device ${deviceId}, channel ${channelId}:`, error);
    throw error;
  }
};

/**
 * Get channel data by device ID
 * @param {string} deviceId - Device ID
 * @returns {Array} List of all channels for the device
 */
export const getDeviceChannels = async (deviceId) => {
  try {
    const device = await Device.findOne({ device_id: deviceId, is_delete: false })
      .select('capabilities')
      .lean();
    if (!device) {
      throw new Error('Device not found');
    }
    //Remove uninstalled sensors
    const now = Date.now()/1000;
    const TWO_HOURS = 2 * 60 * 60;
    const allCapabilities = device.capabilities.filter(channel => {
      if (channel.type === 'sensor' && channel.properties.lastSeen && (now - channel.properties.lastSeen) > TWO_HOURS && (channel.properties.installed === false || channel.properties.installed === undefined)) {
        removeRelatedSensorData(deviceId, channel.channelId);
        return false;
      }
      return true;
    });
    if (allCapabilities.length !== device.capabilities.length) {
      const updateDevice = await Device.findOneAndUpdate(
        { device_id: deviceId, is_delete: false },
        { $set: { capabilities: allCapabilities } },
      );
    }
    
    return allCapabilities;
  } catch (error) {
    throw new Error(`Error fetching device channels: ${error.message}`);
  }
};
/**
 * Change device status (Active/Inactive)
 * @param {string} deviceId - Device ID
 * @param {string} status - New status ('Active' or 'Inactive')
 * @param {Object} user - User object
 * @returns {Object} Updated device
 */
export const changeDeviceStatus = async (deviceId, status, user) => {
  try {
    const device = await Device.findOneAndUpdate(
      { device_id: deviceId, is_delete: false },
      { status, updatedBy: user._id, updatedAt: new Date() },
      { new: true }
    )
      .populate('campus', 'name code description')
      .populate('building', 'name code description')
      .populate('floor', 'name number description')
      .populate('zone', 'name code description')
      .lean();
    if (!device) {
      throw new Error('Device not found');
    }
    return device;
  } catch (error) {
    throw new Error(`Error updating device status: ${error.message}`);
  }
};

/**
 * Get devices organized by ownership with location data
 * 
 * Features:
 * - Separates BA-series (own) from third-party devices
 * - Location population (campus/building/floor/zone)
 * - Status and type filtering
 * - Search by device ID
 * - Comprehensive summary statistics
 */
export const getDeviceList = async (query = {}) => {
  try {
    // Build the base query
    const baseQuery = { is_delete: false };

    // Add status filter if provided
    if (query.status) {
      baseQuery.status = query.status;
    }

    // Add campus filter if provided
    if (query.campusId) {
      baseQuery.campus = query.campusId;
    }

    // Add building filter if provided
    if (query.buildingId) {
      baseQuery.building = query.buildingId;
    }

    // Add floor filter if provided
    if (query.floorId) {
      baseQuery.floor = query.floorId;
    }

    // Add zone filter if provided
    if (query.zoneId) {
      baseQuery.zone = query.zoneId;
    }

    // Add search functionality - only by device ID
    if (query.search) {
      const searchRegex = new RegExp(query.search, 'i');
      baseQuery.device_id = searchRegex;
    }

    // Fetch all devices with populated location information
    const devices = await Device.find(baseQuery)
      .populate({
        path: 'campus',
        select: 'name code description'
      })
      .populate({
        path: 'building',
        select: 'name code description'
      })
      .populate({
        path: 'floor',
        select: 'name number description'
      })
      .populate({
        path: 'zone',
        select: 'name code description'
      })
      .sort({ createdAt: -1 })
      .lean();

    // Separate devices into own devices and third-party devices
    const ownDevices = [];
    const thirdPartyDevices = [];

    devices.forEach(device => {
      // Format device data
      const formattedDevice = {
        device_id: device.device_id,
        device_type: device.type,
        campus: device.campus ? device.campus.name : 'N/A',
        building: device.building ? device.building.name : 'N/A',
        floor: device.floor ? device.floor.name : 'N/A',
        zone: device.zone ? device.zone.name : 'N/A',
        device_name: device.name,
        serial_number: device.SNO,
        port: device.port || 'N/A',
        port_primary: device.port_primary || null,
        port_secondary: device.port_secondary || null,
        description: device.description || 'N/A',
        status: device.status,
        firmware: device.firmware,
        mac_address: device.Mac_addr,
        configure_flag: device.configure_flag,
        capabilities: device.capabilities || [],
        location_details: {
          campus_id: device.campus ? device.campus._id : null,
          building_id: device.building ? device.building._id : null,
          floor_id: device.floor ? device.floor._id : null,
          zone_id: device.zone ? device.zone._id : null,
          campus_code: device.campus ? device.campus.code : null,
          building_code: device.building ? device.building.code : null,
          floor_number: device.floor ? device.floor.number : null,
          zone_code: device.zone ? device.zone.code : null
        },
        created_at: device.createdAt,
        updated_at: device.updatedAt
      };

      // Check if device type contains "BA" (case insensitive)
      if (/^BA-\d{3,4}$/i.test(device.type || "")) {
        ownDevices.push(formattedDevice);
      } else {
        thirdPartyDevices.push(formattedDevice);
      }
    });

    // Calculate summary statistics
    const summary = {
      total_devices: devices.length,
      own_devices_count: ownDevices.length,
      third_party_devices_count: thirdPartyDevices.length,
      active_devices: devices.filter(d => d.status === 'Active').length,
      inactive_devices: devices.filter(d => d.status === 'Inactive').length,
      device_types: [...new Set(devices.map(d => d.type))],
      locations: {
        campuses: [...new Set(devices.map(d => d.campus?.name).filter(Boolean))],
        buildings: [...new Set(devices.map(d => d.building?.name).filter(Boolean))],
        floors: [...new Set(devices.map(d => d.floor?.name).filter(Boolean))],
        zones: [...new Set(devices.map(d => d.zone?.name).filter(Boolean))]
      }
    };

    return {
      own_devices: ownDevices,
      third_party_devices: thirdPartyDevices,
      summary
    };

  } catch (error) {
    throw new Error(`Error fetching device list: ${error.message}`);
  }
};

/**
 * Get unconfigured devices available for setup
 * 
 * Process:
 * - Filters devices with configure_flag = false
 * - Advanced aggregation pipeline for performance
 * - User permission scoping
 * - Pagination with metadata
 * - Separates own vs third-party devices
 * - Comprehensive search capabilities
 */
export const getDeviceDiscoveryList = async (query = {}) => {
  try {
    const asObjectId = (v) => (typeof v === 'string' && /^[0-9a-fA-F]{24}$/.test(v) ? new mongoose.Types.ObjectId(v) : v);

    // Build a tolerant $match for aggregation (avoid direct "configure_flag: 'false'")
    const match = {
      $and: [
        { $or: [{ is_delete: false }, { is_delete: { $exists: false } }] },
        // Unconfigured: boolean false, number 0, string "false"/"0"/empty, null, or missing
        {
          $or: [
            { configure_flag: { $in: [false, 0, null] } },
            { configure_flag: { $exists: false } },
            {
              $expr: {
                $in: [
                  { $toLower: { $toString: "$configure_flag" } },
                  ["false", "0", ""]
                ]
              }
            }
          ]
        }
      ]
    };

    // Additional filters (cast IDs when they look like ObjectIds)
    if (query.status) match.$and.push({ status: query.status });
    if (query.campusId) match.$and.push({ campus: asObjectId(query.campusId) });
    if (query.buildingId) match.$and.push({ building: asObjectId(query.buildingId) });
    if (query.floorId) match.$and.push({ floor: asObjectId(query.floorId) });
    if (query.zoneId) match.$and.push({ zone: asObjectId(query.zoneId) });

    // Search by device_id or name (regex, case-insensitive)
    if (query.search && query.search.trim()) {
      const searchRegex = { $regex: query.search.trim(), $options: 'i' };
      match.$and.push({
        $or: [
          { device_id: searchRegex },
          { name: searchRegex }
        ]
      });
    }
    if (query.deviceId && query.deviceId.trim()) {
      // deviceId param takes priority
      match.$and.push({ device_id: { $regex: query.deviceId.trim(), $options: 'i' } });
    }

    const page = parseInt(query.page, 10) || 1;
    const limit = parseInt(query.limit, 10) || 100;
    const skip = (page - 1) * limit;

    // Filter by allowedDiscoveredDeviceIds if provided
    if (query.allowedDiscoveredDeviceIds && Array.isArray(query.allowedDiscoveredDeviceIds) && query.allowedDiscoveredDeviceIds.length > 0) {
      const objectIds = [];
      const deviceIds = [];
      
      query.allowedDiscoveredDeviceIds.forEach(id => {
        if (mongoose.Types.ObjectId.isValid(id)) {
          objectIds.push(new mongoose.Types.ObjectId(id));
        }
        deviceIds.push(id);
      });
      
      const deviceFilters = [];
      if (objectIds.length > 0) {
        deviceFilters.push({ _id: { $in: objectIds } });
      }
      if (deviceIds.length > 0) {
        deviceFilters.push({ device_id: { $in: deviceIds } });
      }
      
      if (deviceFilters.length > 0) {
        match.$and.push({ $or: deviceFilters });
      }
    }

    // Aggregate to get total and paged ids (avoids cast errors on configure_flag)
    const facet = await Device.aggregate([
      { $match: match },
      { $sort: { createdAt: -1 } },
      {
        $facet: {
          ids: [
            { $skip: skip },
            { $limit: limit },
            { $project: { _id: 1 } }
          ],
          total: [{ $count: 'n' }]
        }
      }
    ]);

    const ids = (facet[0]?.ids || []).map(d => d._id);
    const totalCount = facet[0]?.total?.[0]?.n || 0;

    if (ids.length === 0) {
      return {
        own_devices: [],
        third_party_devices: [],
        summary: {
          total_devices_found: totalCount,
          devices_on_current_page: 0,
          own_devices_count: 0,
          third_party_devices_count: 0,
          active_devices: 0,
          inactive_devices: 0,
          pagination: {
            current_page: page,
            per_page: limit,
            total_pages: Math.ceil(totalCount / limit),
            has_next_page: page < Math.ceil(totalCount / limit),
            has_previous_page: page > 1
          },
          search_criteria: {
            search_term: query.search || null,
            device_id_filter: query.deviceId || null,
            status_filter: query.status || null,
            location_filters: {
              campus_id: query.campusId || null,
              building_id: query.buildingId || null,
              floor_id: query.floorId || null,
              zone_id: query.zoneId || null
            }
          },
          device_types_found: [],
          locations_found: { campuses: [], buildings: [], floors: [], zones: [] }
        }
      };
    }

    // Fetch full docs with populate, then reorder to match aggregation order
    const docs = await Device.find({ _id: { $in: ids } })
      .populate({ path: 'campus', select: 'name code description' })
      .populate({ path: 'building', select: 'name code description' })
      .populate({ path: 'floor', select: 'name number description' })
      .populate({ path: 'zone', select: 'name code description' })
      .populate({ path: 'createdBy', select: 'name email' })
      .lean();

    const order = new Map(ids.map((id, i) => [String(id), i]));
    docs.sort((a, b) => (order.get(String(a._id)) ?? 0) - (order.get(String(b._id)) ?? 0));

    // Build response
    const ownDevices = [];
    const thirdPartyDevices = [];

    docs.forEach(device => {
      const isOwn = /^BA-\d{3,4}$/i.test(device.type || "");

      const formatted = {
        device_id: device.device_id,
        device_name: device.name,
        device_type: device.type,
        serial_number: device.SNO,
        mac_address: device.Mac_addr,
        firmware: device.firmware,
        status: device.status,
        port: device.port || 'N/A',
        port_primary: device.port_primary || null,
        port_secondary: device.port_secondary || null,
        description: device.description || 'N/A',
        configure_flag: device.configure_flag,
        capabilities: device.capabilities || [],
        location: {
          campus: { id: device.campus?._id || null, name: device.campus?.name || 'N/A', code: device.campus?.code || null },
          building: { id: device.building?._id || null, name: device.building?.name || 'N/A', code: device.building?.code || null },
          floor: { id: device.floor?._id || null, name: device.floor?.name || 'N/A', number: device.floor?.number || null },
          zone: { id: device.zone?._id || null, name: device.zone?.name || 'N/A', code: device.zone?.code || null }
        },
        ownership_type: isOwn ? 'own' : 'third-party',
        created_by: device.createdBy ? device.createdBy.name : 'Unknown',
        created_at: device.createdAt,
        updated_at: device.updatedAt
      };

      (isOwn ? ownDevices : thirdPartyDevices).push(formatted);
    });

    const summary = {
      total_devices_found: totalCount,
      devices_on_current_page: docs.length,
      own_devices_count: ownDevices.length,
      third_party_devices_count: thirdPartyDevices.length,
      active_devices: docs.filter(d => d.status === 'Active').length,
      inactive_devices: docs.filter(d => d.status === 'Inactive').length,
      pagination: {
        current_page: page,
        per_page: limit,
        total_pages: Math.ceil(totalCount / limit),
        has_next_page: page < Math.ceil(totalCount / limit),
        has_previous_page: page > 1
      },
      search_criteria: {
        search_term: query.search || null,
        device_id_filter: query.deviceId || null,
        status_filter: query.status || null,
        location_filters: {
          campus_id: query.campusId || null,
          building_id: query.buildingId || null,
          floor_id: query.floorId || null,
          zone_id: query.zoneId || null
        }
      },
      device_types_found: [...new Set(docs.map(d => d.type).filter(Boolean))],
      locations_found: {
        campuses: [...new Set(docs.map(d => d.campus?.name).filter(Boolean))],
        buildings: [...new Set(docs.map(d => d.building?.name).filter(Boolean))],
        floors: [...new Set(docs.map(d => d.floor?.name).filter(Boolean))],
        zones: [...new Set(docs.map(d => d.zone?.name).filter(Boolean))]
      }
    };

    return { own_devices: ownDevices, third_party_devices: thirdPartyDevices, summary };

  } catch (error) {
    throw new Error(`Error fetching device discovery list: ${error.message}`);
  }
};

/**
 * Get device by ID with full details
 * @param {string} deviceId - Device ID
 * @returns {Object} Device details
 */
export const getDeviceById = async (deviceId) => {
  try {
    console.log(`Fetching device with ID: ${deviceId}`);
    const device = await Device.findOne({
      device_id: deviceId,
      is_delete: false
    })
      .populate({ path: 'campus', select: '_id name code description' })
      .populate({ path: 'building', select: '_id name code description' })
      .populate({ path: 'floor', select: '_id name number description' })
      .populate({ path: 'zone', select: '_id name code description' })
      .lean();

    if (!device) {
      throw new Error('Device not found');
    }

    // Helper: collect active channels by type (installed === true)
    const getActiveChannels = (type) => {
      const caps = Array.isArray(device.capabilities) ? device.capabilities : [];
      return caps
        .filter(c => c?.type === type && c?.properties?.installed === true)
        .map(c => c.channelId)
        .filter(Boolean);
    };

    const activeLedChannels = getActiveChannels('led');
    const activeShadeChannels = getActiveChannels('shade');
    const activeSensorChannels = getActiveChannels('sensor');

    // Build a readable "port" field while still returning primary/secondary
    const port =
      device.port ||
      [device.port_primary, device.port_secondary].filter(Boolean).join(', ') ||
      'N/A';

    return {
      device_id: device.device_id ?? null,
      device_name: device.name ?? 'N/A',
      type: device.type ?? 'N/A',
      status: device.status ?? 'N/A',
      firmware: device.firmware ?? 'N/A',

      // identifiers
      serial_number: device.SNO ?? 'N/A',
      mac_address: device.Mac_addr ?? 'N/A',

      // location information in nested format
      location: {
        campus: {
          id: device.campus?._id?.toString() ?? null,
          name: device.campus?.name ?? 'N/A'
        },
        building: {
          id: device.building?._id?.toString() ?? null,
          name: device.building?.name ?? 'N/A'
        },
        floor: {
          id: device.floor?._id?.toString() ?? null,
          name: device.floor?.name ?? 'N/A'
        },
        zone: {
          id: device.zone?._id?.toString() ?? null,
          name: device.zone?.name ?? 'N/A'
        }
      },

      // ports
      port,
      port_primary: device.port_primary ?? null,
      port_secondary: device.port_secondary ?? null,

      // misc
      description: device.description ?? 'N/A',

      // active channel summary
      active_channels: {
        leds: {
          count: activeLedChannels.length,
          channels: activeLedChannels
        },
        shades: {
          count: activeShadeChannels.length,
          channels: activeShadeChannels
        },
        sensors: {
          count: activeSensorChannels.length,
          channels: activeSensorChannels
        }
      }
    };
  } catch (error) {
    throw new Error(`Error fetching device: ${error.message}`);
  }
};

/**
 * Add a new device
 * @param {Object} deviceData - Device data
 * @param {Object} user - User object
 * @returns {Object} Created device
 */
export const addDevice = async (deviceData, user) => {
  try {
    // Parse port information if provided as single string
    if (deviceData.port && typeof deviceData.port === 'string') {
      const portParts = deviceData.port.split('/');
      if (portParts.length >= 2) {
        deviceData.port_primary = `${portParts[0]}/${portParts[1]}`;
        if (portParts.length > 2) {
          deviceData.port_secondary = portParts.slice(2).join('/');
        }
      }
    }

    const device = new Device({
      ...deviceData,
      configure_flag: 0, // Explicitly set to 0 initially
      createdBy: user._id
    });

    await device.save();

    // Populate the device with location information
    const populatedDevice = await Device.findById(device._id)
      .populate('campus', 'name code description')
      .populate('building', 'name code description')
      .populate('floor', 'name number description')
      .populate('zone', 'name code description')
      .lean();

    return populatedDevice;

  } catch (error) {
    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern)[0];
      throw new Error(`Device with this ${field} already exists`);
    }
    throw new Error(`Error creating device: ${error.message}`);
  }
};


/**
 * Add third party device
 * @param {Object} deviceData - Device data
 * @param {Object} user - User object
 * @returns {Object} Created device
 */
export const addThirdPartyDevice = async (deviceData, user) => {
  try {

    const device = new Device({
      ...deviceData,
      configure_flag: 1, // Explicitly set to 0 initially
      createdBy: user._id,
      status: 'Active'
    });

    if (deviceData.Mac_addr) {
      // Initialize Lutron connection
      const connectionDetails = deviceData.Mac_addr.split('_');
      const host = connectionDetails[0]; //'192.168.0.24'
      const port = connectionDetails[1] //23
      console.log("--connecting to lutron", host, port);
      await setLutronClient(deviceData.device_id, host, Number(port));
    }

    device.capabilities = defaultLutronCapabilities;
    // If HMI device, set  capabilities
    if (deviceData.name && deviceData.name.toLowerCase().includes("hmi")) {
      const hmiCapabilities = [];
      for (let i = 1; i <= 60; i++) {
        hmiCapabilities.push({
          type: 'led',
          name: 'Unnamed',
          channelId: 'LED' + i,
          status: 'off',
          properties: {
            installed: false,
            brightness: 0,
            powerMin: '10',
            powerMax: '100'
          }
        });
      }
      for(let i = 1; i <= 60; i++) {
        hmiCapabilities.push({
          type: 'shade',
          name: 'Unnamed',
          channelId: 'SHADE' + i,
          status: 'closed',
          properties: {
            installed: false,
            openLevel: 0,
            movementControl: null
          }
        });
      }
      for(let i = 1; i <= 20; i++) {
        hmiCapabilities.push({
          type: 'sensor',
          name: 'Unnamed',
          channelId: 'Port-1_' + i,
          status: 'off',
          properties: {
            installed: false,
            sensorType: 'pir',
            port: null,
            sensorAddress: null,
            commType: null
          }
        });
      }
      for(let i = 1; i <= 20; i++) {
        hmiCapabilities.push({
          type: 'expansion_led',
          name: 'Unnamed',
          channelId: 'Port-1_' + i,
          status: 'off',
          properties: {
            installed: false,
            sensorType: 'pir',
            port: null,
            sensorAddress: null,
            commType: null
          }
        });
      }
      for(let i = 1; i <= 20; i++) {
        hmiCapabilities.push({
          type: 'expansion_color_lights',
          name: 'Unnamed',
          channelId: 'Port-1_' + i,
          status: 'off',
          properties: {
            installed: false,
            sensorType: 'pir',
            port: null,
            sensorAddress: null,
            commType: null
          }
        });
      }
      for(let i = 1; i <= 20; i++) {
        hmiCapabilities.push({
          type: 'rtu_light_sensor',
          name: 'Unnamed',
          channelId: 'Port-1_' + i,
          status: 'off',
          properties: {
            installed: false,
            sensorType: 'pir',
            port: null,
            sensorAddress: null,
            commType: null
          }
        });
      }
      for(let i = 1; i <= 20; i++) {
        hmiCapabilities.push({
          type: 'rtu_CO2',
          name: 'Unnamed',
          channelId: 'Port-1_' + i,
          status: 'off',
          properties: {
            installed: false,
            sensorType: 'pir',
            port: null,
            sensorAddress: null,
            commType: null
          }
        });
      }
      for(let i = 1; i <= 20; i++) {
        hmiCapabilities.push({
          type: 'rtu_HMI',
          name: 'Unnamed',
          channelId: 'Port-1_' + i,
          status: 'off',
          properties: {
            installed: false,
            sensorType: 'pir',
            port: null,
            sensorAddress: null,
            commType: null
          }
        });
      }
      device.capabilities = hmiCapabilities;
    }

    const savedDevice = await device.save();
    
    // Update users' allowedResources with the new device ID
    try {
      const { default: Role } = await import('../models/Role.js');
      const { User } = await import('../models/User.js');
      
      // Find roles for admin, technician, and operator (case insensitive)
      const adminTechRoles = await Role.find({ 
        roleName: { 
          $in: ['admin', 'technician'].map(name => new RegExp(`^${name}$`, 'i')) 
        },
        isDelete: { $ne: true },
        isActive: true
      });
      
      const operatorRoles = await Role.find({ 
        roleName: { 
          $in: [new RegExp('^operator$', 'i')] 
        },
        isDelete: { $ne: true },
        isActive: true
      });
      
      console.log(`Found ${adminTechRoles.length} admin/technician roles and ${operatorRoles.length} operator roles for device access`);
      
      const adminTechRoleIds = adminTechRoles.map(r => r._id);
      const operatorRoleIds = operatorRoles.map(r => r._id);
      
      // Update admin and technician users (add to both deviceManagement.configuredDevices and controlSection.deviceTab)
      if (adminTechRoleIds.length > 0) {
        const adminTechUsers = await User.find({ 
          role_id: { $in: adminTechRoleIds },
          allowedResources: { $ne: null },
          isDeleted: { $ne: true },
          isActive: true
        });
        
        console.log(`Found ${adminTechUsers.length} admin/technician users to update with configured device access`);
        
        for (const user of adminTechUsers) {
          // Initialize structures if needed
          if (!user.allowedResources.deviceManagement) {
            user.allowedResources.deviceManagement = {};
          }
          if (!Array.isArray(user.allowedResources.deviceManagement.configuredDevices)) {
            user.allowedResources.deviceManagement.configuredDevices = [];
          }
          if (!user.allowedResources.controlSection) {
            user.allowedResources.controlSection = {};
          }
          if (!Array.isArray(user.allowedResources.controlSection.deviceTab)) {
            user.allowedResources.controlSection.deviceTab = [];
          }
          
          // Add to deviceManagement.configuredDevices if not already present
          if (!user.allowedResources.deviceManagement.configuredDevices.includes(savedDevice._id.toString())) {
            user.allowedResources.deviceManagement.configuredDevices.push(savedDevice._id.toString());
          }
          
          // Add to controlSection.deviceTab if not already present
          if (!user.allowedResources.controlSection.deviceTab.includes(savedDevice._id.toString())) {
            user.allowedResources.controlSection.deviceTab.push(savedDevice._id.toString());
          }
          
          await user.save();
          console.log(`Updated admin/technician user ${user.email} with configured device ID: ${savedDevice._id}`);
        }
      }
      
      // Update operator users (add only to controlSection.deviceTab)
      if (operatorRoleIds.length > 0) {
        const operatorUsers = await User.find({ 
          role_id: { $in: operatorRoleIds },
          allowedResources: { $ne: null },
          isDeleted: { $ne: true },
          isActive: true
        });
        
        console.log(`Found ${operatorUsers.length} operator users to update with configured device access`);
        
        for (const user of operatorUsers) {
          // Initialize controlSection if needed
          if (!user.allowedResources.controlSection) {
            user.allowedResources.controlSection = {};
          }
          if (!Array.isArray(user.allowedResources.controlSection.deviceTab)) {
            user.allowedResources.controlSection.deviceTab = [];
          }
          
          // Add to controlSection.deviceTab if not already present
          if (!user.allowedResources.controlSection.deviceTab.includes(savedDevice._id.toString())) {
            user.allowedResources.controlSection.deviceTab.push(savedDevice._id.toString());
          }
          
          await user.save();
          console.log(`Updated operator user ${user.email} with configured device ID: ${savedDevice._id} (controlSection only)`);
        }
      }
      
      console.log(`Successfully updated users with new third-party device access permissions`);
    } catch (userUpdateError) {
      console.error('Error updating users with new third-party device access:', userUpdateError);
      // Don't throw the error here - we still want to return the created device
      // The device was created successfully, user updates are a bonus feature
    }

    return savedDevice;
  } catch (error) {
    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern)[0];
      throw new Error(`Device with this ${field} already exists`);
    }
    throw new Error(`Error creating device: ${error.message}`);
  }
};

/**
 * Update device
 * @param {string} deviceId - Device ID
 * @param {Object} updateData - Update data
 * @param {Object} user - User object
 * @returns {Object} Updated device
 */
export const updateDevice = async (deviceId, updateData, user) => {
  try {
    // Only allow updates to specific fields
    const allowedFields = [
      'port', 'port_primary', 'port_secondary', 'description', 'name', 'device_name', 'campus', 'building', 'floor', 'zone', 'is_delete'
    ];
    const updateObj = {};
    for (const key of allowedFields) {
      if (Object.prototype.hasOwnProperty.call(updateData, key)) {
        updateObj[key] = updateData[key];
      }
    }

    // Map device_name to name field
    if (updateData.device_name) {
      updateObj.name = updateData.device_name;
    }
    // Parse port string if provided
    if (updateObj.port && typeof updateObj.port === 'string') {
      const portParts = updateObj.port.split('/');
      if (portParts.length >= 2) {
        updateObj.port_primary = `${portParts[0]}/${portParts[1]}`;
        if (portParts.length > 2) {
          updateObj.port_secondary = portParts.slice(2).join('/');
        }
      }
    }
    updateObj.updatedBy = user._id;
    updateObj.updatedAt = new Date();

    const device = await Device.findOneAndUpdate(
      { device_id: deviceId, is_delete: false },
      updateObj,
      { new: true, runValidators: true }
    )
      .populate('campus', 'name code description')
      .populate('building', 'name code description')
      .populate('floor', 'name number description')
      .populate('zone', 'name code description')
      .lean();

    if (!device) {
      throw new Error('Device not found');
    }
    return device;
  } catch (error) {
    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern)[0];
      throw new Error(`Device with this ${field} already exists`);
    }
    throw new Error(`Error updating device: ${error.message}`);
  }
};

/**
 * Delete device (soft delete)
 * @param {string} deviceId - Device ID
 * @param {Object} user - User object
 * @returns {Object} Deleted device
 */
/**
 * Soft delete device by setting configure_flag to 0
 * @param {string} deviceId - Device ID
 * @param {Object} user - User object
 * @returns {Object} Updated device
 */
export const deleteDevice = async (deviceId, user) => {
  try {
    await Device.deleteOne({ device_id: deviceId });
    // let device = await Device.findOneAndUpdate(
    //   { device_id: deviceId, is_delete: false },
    //   { is_delete: true, updatedBy: user._id, updatedAt: new Date() },
    //   { new: true }
    // )
    //   .populate('campus', 'name code description')
    //   .populate('building', 'name code description')
    //   .populate('floor', 'name number description')
    //   .populate('zone', 'name code description')
    //   .lean();
    // if (!device) {
    //   // If not found, create device with is_delete true
    //   const deviceData = { device_id: deviceId, is_delete: true };
    //   device = new Device({ ...deviceData, createdBy: user._id });
    //   await device.save();
    //   device = await Device.findById(device._id)
    //     .populate('campus', 'name code description')
    //     .populate('building', 'name code description')
    //     .populate('floor', 'name number description')
    //     .populate('zone', 'name code description')
    //     .lean();
    // }
    socketManager.emitEvent("deviceStatusChanged", {uiType: ""});
    return true;
  } catch (error) {
    throw new Error(`Error deleting device: ${error.message}`);
  }
};

/**
 * Transform discovered device into configured production device
 * 
 * Configuration Process:
 * 1. Assign to campus/building/floor/zone hierarchy
 * 2. Set communication ports (primary/secondary)
 * 3. Initialize channel capabilities
 * 4. Set configure_flag = true
 * 5. Update user tracking information
 * 
 * Makes device available for channel management and control operations
 */
export const configureDevice = async (configData, user) => {
  try {
    const {
      device_id,
      campus_id,
      building_id,
      floor_id,
      zone_id,
      device_name,
      serial_name,
      description,
      port
    } = configData;

    // 1) Find the device (handle cases where is_delete field might not exist)
    console.log(`Looking for device with device_id: ${device_id}`);
    
    const existingDevice = await Device.findOne({
      device_id: device_id,
      $or: [
        { is_delete: false },
        { is_delete: { $exists: false } },
        { is_delete: null }
      ]
    });

    console.log(`Device found: ${existingDevice ? 'Yes' : 'No'}`);
    if (existingDevice) {
      console.log(`Device details: ID=${existingDevice.device_id}, configure_flag=${existingDevice.configure_flag}, is_delete=${existingDevice.is_delete}`);
    }

    if (!existingDevice) {
      throw new Error('Device not found');
    }

    // 2) Parse port info
    let port_primary = null;
    let port_secondary = null;

    if (port) {
      if (typeof port === 'object' && port !== null) {
        port_primary = port.primary || null;
        port_secondary = port.secondary || null;
      } else if (typeof port === 'string') {
        const parts = port.split('/');
        if (parts.length >= 2) {
          port_primary = `${parts[0]}/${parts[1]}`;
          if (parts.length > 2) {
            port_secondary = parts.slice(2).join('/');
          }
        }
      }
    }

    // 3) Build sensor capability name
    let sensorCapName = null;
    if (port_primary || port_secondary) {
      const primaryPart = port_primary ? String(port_primary) : '';
      const secondaryPart = port_secondary ? String(port_secondary) : '';
      const portLabel = secondaryPart
        ? `Port-${primaryPart}_${secondaryPart}`
        : `Port-${primaryPart || secondaryPart}`;
      sensorCapName = `${existingDevice.device_id}_${portLabel}`;
    }

    // 4) Update sensor capabilities
    let updatedCapabilities;
    if (sensorCapName && Array.isArray(existingDevice.capabilities)) {
      updatedCapabilities = existingDevice.capabilities.map((cap) => {
        const capObj = typeof cap.toObject === 'function' ? cap.toObject() : { ...cap };
        if ((capObj.type || '').toLowerCase() === 'sensor') {
          return {
            ...capObj,
            name: sensorCapName,
            // channelId: sensorCapName NEVER UPDATE SENSOR CHANNEL ID
          };
        }
        return capObj;
      });
    }

    // 5) Prepare update payload
    const updateData = {
      campus: campus_id,
      building: building_id,
      floor: floor_id,
      zone: zone_id,
      name: device_name,
      SNO: serial_name,
      configure_flag: 1,
      updatedBy: user._id
    };

    if (description !== undefined) updateData.description = description;
    if (port_primary) updateData.port_primary = port_primary;
    if (port_secondary) updateData.port_secondary = port_secondary;
    if (updatedCapabilities) updateData.capabilities = updatedCapabilities;

    // 6) Update and populate (use the same query logic as the initial find)
    console.log(`Updating device ${device_id} with configure_flag: 1`);
    
    const configuredDevice = await Device.findOneAndUpdate(
      { 
        device_id: device_id,
        $or: [
          { is_delete: false },
          { is_delete: { $exists: false } },
          { is_delete: null }
        ]
      },
      updateData,
      { new: true, runValidators: true }
    )
      .populate('campus', 'name code description')
      .populate('building', 'name code description')
      .populate('floor', 'name number description')
      .populate('zone', 'name code description')
      .populate('updatedBy', 'name email')
      .lean();

    console.log(`Device update result: ${configuredDevice ? 'Success' : 'Failed'}`);
    if (configuredDevice) {
      console.log(`Updated device configure_flag: ${configuredDevice.configure_flag}`);
    }

    if (!configuredDevice) {
      throw new Error('Failed to configure device');
    }
    socketManager.emitEvent("deviceStatusChanged", {uiType: ""});

    // 7) Add device _id to allowedResources based on user roles
    // Superadmin: Always has allowedResources: null, don't update anything
    // Admin & Technician: Add to both deviceManagement.configuredDevices and controlSection.deviceTab
    // Operator: Add only to controlSection.deviceTab
    try {
      const { default: Role } = await import('../models/Role.js');
      const { User } = await import('../models/User.js');
      
      // Find roles for admin, technician, and operator (case insensitive)
      const adminTechRoles = await Role.find({ 
        roleName: { 
          $in: ['admin', 'technician'].map(name => new RegExp(`^${name}$`, 'i')) 
        },
        isDelete: { $ne: true },
        isActive: true
      });
      
      const operatorRoles = await Role.find({ 
        roleName: { 
          $in: [new RegExp('^operator$', 'i')] 
        },
        isDelete: { $ne: true },
        isActive: true
      });
      
      console.log(`Found ${adminTechRoles.length} admin/technician roles and ${operatorRoles.length} operator roles for device access`);
      
      const adminTechRoleIds = adminTechRoles.map(r => r._id);
      const operatorRoleIds = operatorRoles.map(r => r._id);
      
      // Update admin and technician users (add to both deviceManagement.configuredDevices and controlSection.deviceTab)
      if (adminTechRoleIds.length > 0) {
        const adminTechUsers = await User.find({ 
          role_id: { $in: adminTechRoleIds },
          allowedResources: { $ne: null },
          isDeleted: { $ne: true },
          isActive: true
        });
        
        console.log(`Found ${adminTechUsers.length} admin/technician users to update with configured device access`);
        
        for (const user of adminTechUsers) {
          // Initialize structures if needed
          if (!user.allowedResources.deviceManagement) {
            user.allowedResources.deviceManagement = {};
          }
          if (!Array.isArray(user.allowedResources.deviceManagement.configuredDevices)) {
            user.allowedResources.deviceManagement.configuredDevices = [];
          }
          if (!user.allowedResources.controlSection) {
            user.allowedResources.controlSection = {};
          }
          if (!Array.isArray(user.allowedResources.controlSection.deviceTab)) {
            user.allowedResources.controlSection.deviceTab = [];
          }
          
          // Add to deviceManagement.configuredDevices if not already present
          if (!user.allowedResources.deviceManagement.configuredDevices.includes(configuredDevice._id.toString())) {
            user.allowedResources.deviceManagement.configuredDevices.push(configuredDevice._id.toString());
          }
          
          // Add to controlSection.deviceTab if not already present
          if (!user.allowedResources.controlSection.deviceTab.includes(configuredDevice._id.toString())) {
            user.allowedResources.controlSection.deviceTab.push(configuredDevice._id.toString());
          }
          
          await user.save();
          console.log(`Updated admin/technician user ${user.email} with configured device ID: ${configuredDevice._id}`);
        }
      }
      
      // Update operator users (add only to controlSection.deviceTab)
      if (operatorRoleIds.length > 0) {
        const operatorUsers = await User.find({ 
          role_id: { $in: operatorRoleIds },
          allowedResources: { $ne: null },
          isDeleted: { $ne: true },
          isActive: true
        });
        
        console.log(`Found ${operatorUsers.length} operator users to update with configured device access`);
        
        for (const user of operatorUsers) {
          // Initialize controlSection if needed
          if (!user.allowedResources.controlSection) {
            user.allowedResources.controlSection = {};
          }
          if (!Array.isArray(user.allowedResources.controlSection.deviceTab)) {
            user.allowedResources.controlSection.deviceTab = [];
          }
          
          // Add to controlSection.deviceTab if not already present
          if (!user.allowedResources.controlSection.deviceTab.includes(configuredDevice._id.toString())) {
            user.allowedResources.controlSection.deviceTab.push(configuredDevice._id.toString());
          }
          
          await user.save();
          console.log(`Updated operator user ${user.email} with configured device ID: ${configuredDevice._id} (controlSection only)`);
        }
      }
      
      console.log(`Successfully updated users with new configured device access permissions`);
    } catch (userUpdateError) {
      console.error('Error updating users with new configured device access:', userUpdateError);
      // Don't throw the error here - we still want to return the configured device
      // The device was configured successfully, user updates are a bonus feature
    }

    // 8) Return the configured device data directly
    return {
      _id: configuredDevice._id,
      device_id: configuredDevice.device_id,
      name: configuredDevice.name,
      type: configuredDevice.type,
      serial_number: configuredDevice.SNO,
      mac_address: configuredDevice.Mac_addr,
      firmware: configuredDevice.firmware,
      status: configuredDevice.status,
      port: configuredDevice.port || 'N/A',
      port_primary: configuredDevice.port_primary || null,
      port_secondary: configuredDevice.port_secondary || null,
      description: configuredDevice.description || 'N/A',
      configure_flag: configuredDevice.configure_flag,
      capabilities: configuredDevice.capabilities || [],
      location: {
        campus: configuredDevice.campus || null,
        building: configuredDevice.building || null,
        floor: configuredDevice.floor || null,
        zone: configuredDevice.zone || null
      },
      ownership_type: /^BA-\d{3,4}$/i.test(configuredDevice.type || "") ? 'own' : 'third-party',
      configured_by: {
        userId: configuredDevice.updatedBy?._id || null,
        fullName: configuredDevice.updatedBy?.name || 'Unknown',
        email: configuredDevice.updatedBy?.email || 'N/A'
      },
      configured_at: configuredDevice.updatedAt,
      created_at: configuredDevice.createdAt,
      updated_at: configuredDevice.updatedAt
    };

  } catch (error) {
    throw new Error(`Error configuring device: ${error.message}`);
  }
};

/**
 * Get configured devices with comprehensive channel analysis
 * 
 * Features:
 * - Only devices with configure_flag = true
 * - Detailed channel counts (total, installed, LED, shade, sensor)
 * - Location hierarchy population
 * - User permission filtering
 * - Advanced search and pagination
 * - Performance-optimized aggregation pipeline
 */
export const getConfiguredDevicesList = async (query = {}, user = null) => {
  try {
  // Base query - handle is_delete field flexibility like in configureDevice
  const baseQuery = {
    $or: [
      { is_delete: false },
      { is_delete: { $exists: false } },
      { is_delete: null }
    ]
  };

    // Make configure_flag filter default to true, but allow override via query
    if (typeof query.configure_flag !== 'undefined') {
      // accept boolean or string 'true'/'false'
      baseQuery.configure_flag = (query.configure_flag === true || String(query.configure_flag).toLowerCase() === 'true');
    } else {
      // default behaviour: only show configured devices
      baseQuery.configure_flag = true;
    }

    // Add zone filtering based on user's campusData
    if (user && user.campusData && Array.isArray(user.campusData) && user.campusData.length > 0) {
      // Extract zone IDs from user's campusData
      const zoneIds = [];
      user.campusData.forEach(campus => {
        campus.buildings?.forEach(building => {
          building.floors?.forEach(floor => {
            floor.zones?.forEach(zone => {
              if (zone.zone_id) {
                zoneIds.push(zone.zone_id);
              }
            });
          });
        });
      });
      
      // Add zone filter if user has specific zones in campusData
      if (zoneIds.length > 0) {
        baseQuery.zone = { $in: zoneIds };
      }
    }
    // If user has no campusData or is admin (allowedResources null), show all configured devices

    // Filters - include all devices (both active and inactive) unless specific status is requested
    if (query.status) {
      baseQuery.status = query.status;
    } else if (query.active === '1' || query.active === 1) {
      // If active=1 is specified, show only active devices
      baseQuery.status = 'Active';
    }
    // No default status filter - show both active and inactive devices unless filtered
    if (query.device_type) baseQuery.type = new RegExp(query.device_type, 'i');
    if (query.campus_id) baseQuery.campus = query.campus_id;
    if (query.building_id) baseQuery.building = query.building_id;
    if (query.floor_id) baseQuery.floor = query.floor_id;
    
    // Handle zone_id filter carefully - if user has zone restrictions, intersect with query zone_id
    if (query.zone_id) {
      if (baseQuery.zone && baseQuery.zone.$in) {
        // User has zone restrictions, intersect with query zone_id
        const userZoneIds = baseQuery.zone.$in;
        if (userZoneIds.includes(query.zone_id)) {
          baseQuery.zone = query.zone_id; // Use specific zone if it's in user's allowed zones
        } else {
          baseQuery.zone = { $in: [] }; // No match - return no results
        }
      } else {
        // No user zone restrictions, use query zone_id directly
        baseQuery.zone = query.zone_id;
      }
    }

    // Handle device_id filter (exact match)
    if (query.device_id && query.device_id.trim()) {
      baseQuery.device_id = query.device_id.trim();
    }
    
    // Search - be careful not to overwrite existing $or conditions
    if (query.search && query.search.trim()) {
      const searchRegex = new RegExp(query.search.trim(), 'i');
      // If $or already exists (from is_delete conditions), we need to merge properly
      if (baseQuery.$or) {
        // Move existing $or conditions to $and and add search as new $or
        const existingOr = baseQuery.$or;
        delete baseQuery.$or;
        baseQuery.$and = [
          { $or: existingOr },
          {
            $or: [
              { device_id: searchRegex },
              { name: searchRegex },
              { SNO: searchRegex },
              { type: searchRegex }
            ]
          }
        ];
      } else {
        baseQuery.$or = [
          { device_id: searchRegex },
          { name: searchRegex },
          { SNO: searchRegex },
          { type: searchRegex }
        ];
      }
    }

    // Pagination setup
    const page = query.page ? parseInt(query.page) : null;
    const limit = query.limit ? parseInt(query.limit) : null;
    const skip = page && limit ? (page - 1) * limit : 0;

    // Filter by allowedConfiguredDeviceIds only if array is non-empty and no specific device_id is requested
    if (query.allowedConfiguredDeviceIds && Array.isArray(query.allowedConfiguredDeviceIds) && !query.device_id) {
      if (query.allowedConfiguredDeviceIds.length > 0) {
        // Try to match both _id and device_id fields since allowedResources might contain either
        const objectIds = [];
        const deviceIds = [];
        
        query.allowedConfiguredDeviceIds.forEach(id => {
          if (mongoose.Types.ObjectId.isValid(id)) {
            objectIds.push(new mongoose.Types.ObjectId(id));
          }
          deviceIds.push(id); // Also try as device_id string
        });
        
        // Handle existing $or conditions properly
        const deviceFilters = [];
        if (objectIds.length > 0) {
          deviceFilters.push({ _id: { $in: objectIds } });
        }
        if (deviceIds.length > 0) {
          deviceFilters.push({ device_id: { $in: deviceIds } });
        }
        
        if (deviceFilters.length > 0) {
          if (baseQuery.$or) {
            // If $or already exists, wrap it with $and
            const existingOr = baseQuery.$or;
            delete baseQuery.$or;
            baseQuery.$and = [
              { $or: existingOr },
              { $or: deviceFilters }
            ];
          } else {
            baseQuery.$or = deviceFilters;
          }
        }
      }
      // If array is empty, do NOT add device_id filter (return all configured devices)
    }

    // Count
    const totalCount = await Device.countDocuments(baseQuery);

    // Query builder
    let deviceQuery = Device.find(baseQuery)
      .populate({ path: 'campus', select: 'name code description' })
      .populate({ path: 'building', select: 'name code description' })
      .populate({ path: 'floor', select: 'name number description' })
      .populate({ path: 'zone', select: 'name code description' })
      .sort({ createdAt: -1 })
      .lean();

    // Apply pagination only if page & limit are provided
    if (page && limit) {
      deviceQuery = deviceQuery.skip(skip).limit(limit);
    }

    // Execute query
    const devices = await deviceQuery;

    // Process devices
    const configuredDevices = devices.map(device => {
      const capabilities = device.capabilities || [];
      const shadeCounts = capabilities.filter(cap => cap.type === 'shade').length;
      const ledCounts = capabilities.filter(cap => cap.type === 'led').length;
      const sensorCounts = capabilities.filter(cap => cap.type === 'sensor').length;
      const totalChannels = shadeCounts + ledCounts;

      return {
        device_id: device.device_id,
        device_name: device.name,
        serial_number: device.SNO,
        device_type: device.type,
        mac_address: device.Mac_addr,
        status: device.status,
        firmware: device.firmware,
        channel_counts: {
          total_channels: totalChannels,
          shades: shadeCounts,
          leds: ledCounts,
          sensors: sensorCounts
        },
        location: {
          campus: {
            id: device.campus ? device.campus._id : null,
            name: device.campus ? device.campus.name : 'N/A',
            code: device.campus ? device.campus.code : null
          },
          building: {
            id: device.building ? device.building._id : null,
            name: device.building ? device.building.name : 'N/A',
            code: device.building ? device.building.code : null
          },
          floor: {
            id: device.floor ? device.floor._id : null,
            name: device.floor ? device.floor.name : 'N/A',
            number: device.floor ? device.floor.number : null
          },
          zone: {
            id: device.zone ? device.zone._id : null,
            name: device.zone ? device.zone.name : 'N/A',
            code: device.zone ? device.zone.code : null
          }
        },
        port_info: {
          port_primary: device.port_primary || null,
          port_secondary: device.port_secondary || null,
          full_port: device.port || 'N/A'
        },
        description: device.description || 'N/A',
        ownership_type: /^BA-\d{3,4}$/i.test(device.type || "") ? 'own' : 'third-party',
        configured_at: device.updatedAt,
        created_at: device.createdAt
      };
    });

    // Summaries
    const totalShades = configuredDevices.reduce((sum, d) => sum + d.channel_counts.shades, 0);
    const totalLeds = configuredDevices.reduce((sum, d) => sum + d.channel_counts.leds, 0);
    const totalSensors = configuredDevices.reduce((sum, d) => sum + d.channel_counts.sensors, 0);
    const totalChannels = totalShades + totalLeds;

    const summary = {
      total_configured_devices: totalCount,
      devices_on_current_page: configuredDevices.length,
      device_status_breakdown: {
        active: configuredDevices.filter(d => d.status === 'Active').length,
        inactive: configuredDevices.filter(d => d.status === 'Inactive').length
      },
      channel_summary: {
        total_channels: totalChannels,
        total_shades: totalShades,
        total_leds: totalLeds,
        total_sensors: totalSensors
      },
      device_types: [...new Set(configuredDevices.map(d => d.device_type))],
      ownership_breakdown: {
        own_devices: configuredDevices.filter(d => d.ownership_type === 'own').length,
        third_party_devices: configuredDevices.filter(d => d.ownership_type === 'third-party').length
      },
      locations: {
        campuses: [...new Set(configuredDevices.map(d => d.location.campus.name).filter(name => name !== 'N/A'))],
        buildings: [...new Set(configuredDevices.map(d => d.location.building.name).filter(name => name !== 'N/A'))],
        floors: [...new Set(configuredDevices.map(d => d.location.floor.name).filter(name => name !== 'N/A'))],
        zones: [...new Set(configuredDevices.map(d => d.location.zone.name).filter(name => name !== 'N/A'))]
      },
      pagination: page && limit ? {
        current_page: page,
        per_page: limit,
        total_pages: Math.ceil(totalCount / limit),
        has_next_page: page < Math.ceil(totalCount / limit),
        has_previous_page: page > 1
      } : null,
      filters_applied: {
        status: query.status || null,
        device_type: query.device_type || null,
        search_term: query.search || null,
        location_filters: {
          campus_id: query.campus_id || null,
          building_id: query.building_id || null,
          floor_id: query.floor_id || null,
          zone_id: query.zone_id || null
        }
      }
    };

    return {
      configured_devices: configuredDevices,
      summary
    };

  } catch (error) {
    throw new Error(`Error fetching configured devices list: ${error.message}`);
  }
};


export const getTabCounter = async () => {
  try {
    // Handle docs without deletedAt as well
    const deletedFilter = { $or: [{ is_delete: false }, { is_delete: { $exists: false } }] };

    const [row = { discovered: 0, configured: 0 }] = await Device.aggregate([
      { $match: deletedFilter },
      {
        $group: {
          _id: null,
          configured: {
            $sum: {
              $cond: [{ $eq: ["$configure_flag", true] }, 1, 0]
            }
          },
          discovered: {
            $sum: {
              $cond: [{ $eq: ["$configure_flag", false] }, 1, 0]
            }
          }
        }
      },
      { $project: { _id: 0, discovered: 1, configured: 1 } }
    ]);

    return {
      discovered_devices: row.discovered,
      configured_devices: row.configured
    };
  } catch (error) {
    throw new Error(`Error fetching tab counter: ${error.message}`);
  }
};

/**
 * Get sensors list by device ID
 * @param {string} deviceId - Device ID
 * @returns {Array} List of sensors for the device
 */
export const getDeviceSensors = async (deviceId) => {
  try {
    const device = await Device.findOne({ device_id: deviceId, is_delete: false })
      .select('device_id name type capabilities')
      .lean();

    if (!device) {
      throw new Error('Device not found');
    }

    const deviceSensorScenes = await Sensor.find({ device: deviceId, isDelete: false },{sensor:1});
    
    const usedSensorIds = deviceSensorScenes.flatMap(s => s.sensor);
    
    // Filter capabilities to get only sensors
    const sensors = (device.capabilities || [])
      .filter(capability => capability.type === 'sensor')
      .map(sensor => ({
        channelId: sensor.channelId,
        name: sensor.name,
        type: sensor.type,
        properties: sensor.properties || {},
        installed: sensor.properties?.installed || false,
        description: sensor.description || 'N/A',
        disabled: usedSensorIds.includes(sensor.channelId)
      }));

    return {
      device_id: device.device_id,
      device_name: device.name,
      device_type: device.type,
      total_sensors: sensors.length,
      active_sensors: sensors.filter(s => s.installed).length,
      sensors: sensors
    };

  } catch (error) {
    throw new Error(`Error fetching device sensors: ${error.message}`);
  }
};

/**
 * Get devices list with installed channels - supports search and filters
 * @param {Object} queryParams - Query parameters
 * @returns {Object} Devices list with channels and pagination info
 */
export const getDevicesListWithChannels = async (queryParams = {}, user = null) => {
  try {
    const {
      search = '',
      campus,
      building,
      floor,
      zone,
      status,
      limit = 50,
      page = 1
    } = queryParams;

    // Build filter object
    const filter = { 
      is_delete: false,
      configure_flag: true  // Only get devices with configure_flag set to true
    };

    console.log('=== DEVICES API DEBUG ===');
    console.log('Initial filter:', JSON.stringify(filter, null, 2));
    console.log('User campusData:', user?.campusData);
    console.log('User allowedResources:', user?.allowedResources?.controlSection?.deviceTab);

    // Add status filter - exclude inactive devices by default unless explicitly requested
    if (status) {
      filter.status = status;
    } else {
      // By default, only show active devices (exclude inactive)
      filter.status = 'Active';
    }

    // Add zone filtering based on user's campusData
    if (user && user.campusData && Array.isArray(user.campusData)) {
      console.log('User has campusData, length:', user.campusData.length);
      // If campusData is empty, show all data (no zone filtering)
      if (user.campusData.length === 0) {
        console.log('CampusData is empty, showing all configured devices');
        // No zone filtering - show all configured devices
      } else {
        console.log('CampusData has content, extracting zones...');
        // Extract zone IDs from user's campusData
        const zoneIds = [];
        user.campusData.forEach(campus => {
          campus.buildings?.forEach(building => {
            building.floors?.forEach(floor => {
              floor.zones?.forEach(zone => {
                if (zone.zone_id) {
                  zoneIds.push(zone.zone_id);
                }
              });
            });
          });
        });
        
        console.log('Extracted zoneIds:', zoneIds);
        
        // Add zone filter if user has specific zones in campusData
        if (zoneIds.length > 0) {
          filter.zone = { $in: zoneIds };
          console.log('Applied zone filter with zoneIds:', zoneIds);
        } else {
          // If no zones found in user's campus data, return empty result
          filter.zone = { $in: [] };
          console.log('No zones found in campusData, setting empty zone filter');
        }
      }
    } else {
      console.log('User has no campusData or campusData is not an array');
    }

    // Add location filters (these will override zone filtering from user's campus data)
    if (campus) {
      filter.campus = campus;
    }
    if (building) {
      filter.building = building;
    }
    if (floor) {
      filter.floor = floor;
    }
    if (zone) {
      filter.zone = zone;
    }

    // Add search filter (only by device name)
    if (search && search.trim() !== '') {
      filter.name = { $regex: search.trim(), $options: 'i' };
    }

    // Filter by allowed device _ids from the authenticated user's permissions
    const allowedDeviceObjectIds = new Set();
    if (user && user.allowedResources && user.allowedResources.controlSection && user.allowedResources.controlSection.deviceTab) {
      const deviceTab = user.allowedResources.controlSection.deviceTab;
      if (Array.isArray(deviceTab)) {
        deviceTab.forEach(id => allowedDeviceObjectIds.add(id));
      }
    }
    
    console.log(`User ${user?._id} has allowedResources:`, !!user?.allowedResources);
    console.log(`DeviceTab size:`, allowedDeviceObjectIds.size);
    
    // TEMPORARY: Comment out device ID filtering to test if this is the issue
    // if (allowedDeviceObjectIds.size > 0) {
    //   filter._id = { $in: Array.from(allowedDeviceObjectIds) };
    //   console.log('Applied device _id filter:', Array.from(allowedDeviceObjectIds));
    // }
    
    console.log(`User ${user?._id} has access to ${allowedDeviceObjectIds.size} devices (by _id).`);
    console.log('TEMPORARY: Device ID filtering is DISABLED for debugging');
    console.log('Final filter before query:', JSON.stringify(filter, null, 2));

    // Calculate skip value for pagination
    const skip = (page - 1) * limit;

    // Debug: Check how many devices exist with basic filter
    const basicFilter = { is_delete: false, configure_flag: true };
    const basicCount = await Device.countDocuments(basicFilter);
    console.log('Devices with basic filter (is_delete: false, configure_flag: true):', basicCount);
    
    // Debug: Check how many devices exist without any filter
    const allDevicesCount = await Device.countDocuments({});
    console.log('Total devices in database:', allDevicesCount);
    
    // Get total count for pagination
    const totalDevices = await Device.countDocuments(filter);
    console.log('Total devices found with full filter:', totalDevices);

    // Fetch devices with populated location data
    const devices = await Device.find(filter)
      .populate('campus', 'name')
      .populate('building', 'name')
      .populate('floor', 'name')
      .populate('zone', 'name')
      .select('device_id name type status capabilities campus building floor zone port_primary port_secondary createdAt updatedAt')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .lean();

    // Process devices to include installed channels summary
    const processedDevices = devices.map(device => {
      const capabilities = device.capabilities || [];
      
      // Count installed channels by type
      const installedChannels = {
        total: capabilities.length,
        installed: capabilities.filter(cap => cap.properties?.installed === true).length,
        led: capabilities.filter(cap => cap.type === 'led').length,
        shade: capabilities.filter(cap => cap.type === 'shade').length,
        sensor: capabilities.filter(cap => cap.type === 'sensor').length,
        installed_led: capabilities.filter(cap => cap.type === 'led' && cap.properties?.installed === true).length,
        installed_shade: capabilities.filter(cap => cap.type === 'shade' && cap.properties?.installed === true).length,
        installed_sensor: capabilities.filter(cap => cap.type === 'sensor' && cap.properties?.installed === true).length
      };

      // Format port information
      let port = null;
      if (device.port_primary && device.port_secondary) {
        port = `${device.port_primary}/${device.port_secondary}`;
      } else if (device.port_primary) {
        port = device.port_primary;
      } else if (device.port_secondary) {
        port = device.port_secondary;
      }

      // Get all installed channels details
      const installedChannelsList = capabilities
        .filter(cap => cap.properties?.installed === true)
        .map(cap => ({
          _id: cap._id,
          channelId: cap.channelId,
          name: cap.name,
          type: cap.type,
          status: cap.status,
          properties: cap.properties
        }));

      return {
        _id: device._id,
        device_id: device.device_id,
        name: device.name,
        type: device.type,
        status: device.status,
        port: port,
        location: {
          campus: device.campus ? {
            _id: device.campus._id,
            name: device.campus.name
          } : null,
          building: device.building ? {
            _id: device.building._id,
            name: device.building.name
          } : null,
          floor: device.floor ? {
            _id: device.floor._id,
            name: device.floor.name
          } : null,
          zone: device.zone ? {
            _id: device.zone._id,
            name: device.zone.name
          } : null
        },
        channels_summary: installedChannels,
        installed_channels: installedChannelsList,
        createdAt: device.createdAt,
        updatedAt: device.updatedAt
      };
    });

    // Calculate pagination info
    const totalPages = Math.ceil(totalDevices / limit);
    const hasNextPage = page < totalPages;
    const hasPrevPage = page > 1;

    // Generate summary statistics
    const summary = {
      total_devices: totalDevices,
      current_page_devices: processedDevices.length,
      active_devices: processedDevices.filter(d => d.status === 'Active').length,
      inactive_devices: processedDevices.filter(d => d.status === 'Inactive').length,
      total_installed_channels: processedDevices.reduce((sum, d) => sum + d.channels_summary.installed, 0),
      devices_with_installed_channels: processedDevices.filter(d => d.channels_summary.installed > 0).length
    };

    return {
      devices: processedDevices,
      pagination: {
        current_page: page,
        total_pages: totalPages,
        total_devices: totalDevices,
        devices_per_page: limit,
        has_next_page: hasNextPage,
        has_prev_page: hasPrevPage
      },
      summary
    };

  } catch (error) {
    throw new Error(`Error fetching devices list with channels: ${error.message}`);
  }
};

/**
 * Get sensors with devices
 */
export const getDeviceSensorList = async () => {
  try {
    const devices = await Device.find({ is_delete: false, configure_flag: true })
      .select('device_id name type capabilities')
      .lean();

    const deviceSensors = devices.map(device => {
      const sensors = (device.capabilities || [])
        .filter(cap => cap.type === 'sensor')
        .reduce((acc, sensor) => {
          if (sensor.properties.sensorType !== 'pir') {
            acc[sensor.channelId] = sensor.properties?.value;
          }
          return acc;   // must always return acc
        }, {});

      return {
        sensor_id: device.device_id,
        sensor_id: device.device_id,
        sensor_name: device.name,
        currentData: sensors,
      };
    });

  return deviceSensors;

  } catch (error) {
    throw new Error(`Error fetching device sensor list: ${error.message}`);
  }
}


/**
 * Update templates when a channel's installed status changes
 * @param {string} deviceId - Device ID
 * @param {string} channelId - Channel ID
 * @param {Object} channel - Channel object with updated data
 * @param {boolean} oldInstalledStatus - Previous installed status
 * @param {boolean} newInstalledStatus - New installed status
 */
const updateTemplatesForInstalledStatusChange = async (
  deviceId, 
  channelId, 
  channel, 
  oldInstalledStatus, 
  newInstalledStatus
) => {
  try {
    console.log(`Updating templates for ${deviceId}/${channelId}: ${oldInstalledStatus} -> ${newInstalledStatus}`);

    if (oldInstalledStatus === newInstalledStatus) {
      console.log(`No change in installed status for ${deviceId}/${channelId}, skipping template updates`);
      return;
    }

    const templates = await Template.find({ 
      status: { $regex: /^active$/i }
    }).lean();
    
    if (templates.length === 0) {
      console.log('No active templates found to update');
      return;
    }

    let templatesUpdated = 0;
    
    for (const template of templates) {
      let templateUpdated = false;
      const layoutStructure = { ...template.layoutStructure } || {};
      const rows = layoutStructure.rows || [];

      for (const row of rows) {
        const columns = row.columns || [];
        for (const col of columns) {
          if (!col.elements) {
            col.elements = [];
          }
          
          if (newInstalledStatus === true && (oldInstalledStatus === false || oldInstalledStatus === undefined)) {
            // Only update for group or scene element types
            if (['group', 'scene'].includes(col.type)) {
              const hasDeviceInGroup = elements.some(el => el.deviceId === deviceId);
              
              if (hasDeviceInGroup) {
                const existingElement = elements.find(el => 
                  el.deviceId === deviceId && el.channelId === channelId
                );
                
                if (!existingElement) {
                  const newElement = {
                    id: channelId,
                    name: channel.name || 'Unknown Channel',
                    deviceId: deviceId,
                    channelId: channelId,
                    type: channel.type,
                    status: channel.status || 'off',
                    properties: { ...channel.properties } || {},
                    capabilityId: channel._id ? channel._id.toString() : null
                  };
                  
                  col.elements.push(newElement);
                  templateUpdated = true;
                  console.log(`Added element to ${col.type} in template ${template._id}: ${deviceId}/${channelId}`);
                }
              }
            }
          } else if (newInstalledStatus === false && oldInstalledStatus === true) {
            const originalLength = col.elements.length;
            col.elements = col.elements.filter(el => 
              !(el.deviceId === deviceId && el.channelId === channelId)
            );
            
            if (col.elements.length < originalLength) {
              templateUpdated = true;
              console.log(`Removed element from template ${template._id}: ${deviceId}/${channelId}`);
            }
          }
        }
      }

      if (templateUpdated) {
        await Template.findByIdAndUpdate(
          template._id,
          { 
            layoutStructure,
            updatedAt: new Date()
          },
          { new: true }
        );
        templatesUpdated++;
        console.log(`Updated template ${template._id} for channel ${deviceId}/${channelId}`);
      }
    }

    console.log(`Updated ${templatesUpdated} out of ${templates.length} templates for ${deviceId}/${channelId}`);

  } catch (error) {
    console.error('Error updating templates for installed status change:', error);
    throw error;
  }
};

/**
 * Remove device from group-type scenes
 * @param {string} deviceId - Device ID to remove
 * @param {Object} user - User object for audit trail
 * @returns {Object} Summary of deletions
 */
export const removeDeviceFromGroupScenes = async (deviceId, user) => {
  try {
    console.log(`Removing device ${deviceId} from group-type scenes...`);
    
    const groupScenes = await Scene.find({
      type: 'group',
      'Groups.devices.deviceId': deviceId,
      isDeleted: false
    });

    let scenesUpdated = 0;
    let scenesRemoved = 0;

    for (const scene of groupScenes) {
      let sceneUpdated = false;
      let totalDevicesRemaining = 0;
      
      for (const groupEntry of scene.Groups) {
        const originalLength = groupEntry.devices.length;
        groupEntry.devices = groupEntry.devices.filter(device => device.deviceId !== deviceId);
        
        if (groupEntry.devices.length < originalLength) {
          sceneUpdated = true;
          console.log(`Device ${deviceId} removed from group scene ${scene._id} (${scene.name}), group ${groupEntry.groupId}`);
        }
        
        totalDevicesRemaining += groupEntry.devices.length;
      }
      
      // Remove group entries that have no devices left
      const originalGroupsLength = scene.Groups.length;
      scene.Groups = scene.Groups.filter(groupEntry => groupEntry.devices.length > 0);
      
      if (scene.Groups.length === 0 || totalDevicesRemaining === 0) {
        // If no groups left or no devices in any groups, soft delete the scene
        scene.isDeleted = true;
        scene.deletedAt = new Date();
        scene.deletedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        scenesRemoved++;
        console.log(`Group scene ${scene._id} (${scene.name}) soft deleted - no functional groups/devices left after removing ${deviceId}`);
      } else if (sceneUpdated || scene.Groups.length < originalGroupsLength) {
        scene.updatedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        scenesUpdated++;
        console.log(`Group scene ${scene._id} (${scene.name}) updated - ${scene.Groups.length} groups with ${totalDevicesRemaining} total devices remaining`);
      }
      
      await scene.save();
    }

    console.log(`Group scenes cleanup for device ${deviceId}: ${scenesUpdated} updated, ${scenesRemoved} removed`);
    return { updated: scenesUpdated, removed: scenesRemoved };

  } catch (error) {
    console.error(`Error removing device ${deviceId} from group scenes:`, error);
    throw new Error(`Failed to remove device from group scenes: ${error.message}`);
  }
};

/**
 * Cascade cleanup when device is deleted
 * 
 * Cleanup Operations:
 * 1. Remove device from all groups
 * 2. Delete device-specific scenes
 * 3. Remove from group-type scenes
 * 4. Update/delete related sensors
 * 5. Remove from templates
 * 6. Update sensor scene references
 * 
 * Maintains data integrity across the entire system
 */
export const removeDeviceFromRelatedCollections = async (deviceId, user) => {
  try {
    const deletionSummary = {
      groups: { updated: 0, removed: 0 },
      scenes: { updated: 0, removed: 0 },
      sensors: { updated: 0, removed: 0 },
      templates: { updated: 0, removed: 0, deleted: 0 }
    };

    // 1. Remove device from Groups and soft delete empty groups
    console.log(`Removing device ${deviceId} from groups...`);
    const groupsWithDevice = await Group.find({
      'devices.deviceId': deviceId,
      isDeleted: false
    });

    for (const group of groupsWithDevice) {
      // Remove the device from the devices array
      const originalLength = group.devices.length;
      group.devices = group.devices.filter(device => device.deviceId !== deviceId);
      
      if (group.devices.length === 0) {
        // If no devices left, soft delete the group completely
        group.isDeleted = true;
        group.updatedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        deletionSummary.groups.removed++;
        console.log(`Group ${group._id} (${group.name}) soft deleted - no devices left after removing ${deviceId}`);
      } else if (group.devices.length < originalLength) {
        // Update the group if device was removed but other devices remain
        group.updatedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        deletionSummary.groups.updated++;
        console.log(`Device ${deviceId} removed from group ${group._id} (${group.name}) - ${group.devices.length} devices remaining`);
      }
      
      await group.save();
    }

    // 2. Remove device from Scenes and soft delete empty scenes
    console.log(`Removing device ${deviceId} from scenes...`);
    
    // Handle device-type scenes
    const deviceScenes = await Scene.find({
      type: 'device',
      'Devices.deviceId': deviceId,
      isDeleted: false
    });

    for (const scene of deviceScenes) {
      const originalLength = scene.Devices.length;
      scene.Devices = scene.Devices.filter(device => device.deviceId !== deviceId);
      
      if (scene.Devices.length === 0) {
        // If no devices left, soft delete the scene completely
        scene.isDeleted = true;
        scene.deletedAt = new Date();
        scene.deletedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        deletionSummary.scenes.removed++;
        console.log(`Device scene ${scene._id} (${scene.name}) soft deleted - no devices left after removing ${deviceId}`);
      } else if (scene.Devices.length < originalLength) {
        scene.updatedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        deletionSummary.scenes.updated++;
        console.log(`Device ${deviceId} removed from device scene ${scene._id} (${scene.name}) - ${scene.Devices.length} devices remaining`);
      }
      // /*
      // Ensure all remaining channels have required command field before saving
      for (const device of scene.Devices) {
        for (const channel of device.channels) {
          if (!channel.command) {
            channel.command = channel.channelType === 'shade' ? 'close' : 'off';
          }
        }
      }
      // */
      
      await scene.save();
    }

    // Handle group-type scenes
    const groupScenes = await Scene.find({
      type: 'group',
      'Groups.devices.deviceId': deviceId,
      isDeleted: false
    });

    for (const scene of groupScenes) {
      let sceneUpdated = false;
      let totalDevicesRemaining = 0;
      
      for (const groupEntry of scene.Groups) {
        const originalLength = groupEntry.devices.length;
        groupEntry.devices = groupEntry.devices.filter(device => device.deviceId !== deviceId);
        
        if (groupEntry.devices.length < originalLength) {
          sceneUpdated = true;
          console.log(`Device ${deviceId} removed from group scene ${scene._id} (${scene.name}), group ${groupEntry.groupId}`);
        }
        
        totalDevicesRemaining += groupEntry.devices.length;
      }
      
      // Remove group entries that have no devices left
      const originalGroupsLength = scene.Groups.length;
      scene.Groups = scene.Groups.filter(groupEntry => groupEntry.devices.length > 0);
      
      if (scene.Groups.length === 0 || totalDevicesRemaining === 0) {
        // If no groups left or no devices in any groups, soft delete the scene completely
        scene.isDeleted = true;
        scene.deletedAt = new Date();
        scene.deletedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        deletionSummary.scenes.removed++;
        console.log(`Group scene ${scene._id} (${scene.name}) soft deleted - no functional groups/devices left after removing ${deviceId}`);
      } else if (sceneUpdated || scene.Groups.length < originalGroupsLength) {
        scene.updatedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        deletionSummary.scenes.updated++;
        console.log(`Group scene ${scene._id} (${scene.name}) updated - ${scene.Groups.length} groups with ${totalDevicesRemaining} total devices remaining`);
      }
      // /*
      // Ensure all remaining channels have required command field before saving
      for (const groupEntry of scene.Groups) {
        for (const device of groupEntry.devices) {
          for (const channel of device.channels) {
            if (!channel.command) {
              channel.command = channel.channelType === 'shade' ? 'close' : 'off';
            }
          }
        }
      }
      // */
      await scene.save();
    }

    // 3. Handle sensors that reference the device and update sensor scenes with deleted devices
    console.log(`Handling sensors that reference device ${deviceId}...`);
    
    // Update sensors that directly reference the device
    const sensorsDirectUpdate = await Sensor.updateMany(
      {
        device: deviceId,
        isDelete: false
      },
      {
        $set: {
          isDelete: true,
          updatedBy: {
            userId: user._id,
            fullName: user.fullName,
            email: user.email
          },
          updatedAt: new Date()
        }
      },
      { runValidators: false }
    );
    
    deletionSummary.sensors.removed += sensorsDirectUpdate.modifiedCount;
    console.log(`${sensorsDirectUpdate.modifiedCount} sensors soft deleted - directly referenced device ${deviceId}`);

    // Update sensors that have device in sensor array
    const sensorsArrayUpdate = await Sensor.updateMany(
      {
        sensor: { $regex: new RegExp(`^${deviceId}_`, 'i') },
        isDelete: false
      },
      {
        $set: {
          isDelete: true,
          updatedBy: {
            userId: user._id,
            fullName: user.fullName,
            email: user.email
          },
          updatedAt: new Date()
        }
      },
      { runValidators: false }
    );
    
    deletionSummary.sensors.removed += sensorsArrayUpdate.modifiedCount;
    console.log(`${sensorsArrayUpdate.modifiedCount} sensors soft deleted - sensor array contains reference to ${deviceId}`);

    // Update sensor scenes that reference deleted devices/groups/scenes - set motionScene and NoMotionScene to null
    await updateSensorScenesForDeletedEntities(deviceId, groupsWithDevice, [...deviceScenes, ...groupScenes], user);

    // 4. Remove device, deleted groups, and deleted scenes from Templates
    console.log(`Removing device ${deviceId}, deleted groups, and deleted scenes from templates...`);
    
    // Get IDs of scenes that were deleted due to device removal
    const deletedSceneIds = [...deviceScenes, ...groupScenes]
      .filter(scene => scene.isDeleted)
      .map(scene => scene._id.toString());
    
    // Get IDs of groups that were deleted due to device removal
    const deletedGroupIds = groupsWithDevice
      .filter(group => group.isDeleted)
      .map(group => group._id.toString());
    
    const templates = await Template.find({ 
      status: { $ne: 'Inactive' } // Only check active templates
    });

    for (const template of templates) {
      let templateUpdated = false;
      let totalElementsRemaining = 0;
      let hasNonEmptyColumns = false;
      const layoutStructure = template.layoutStructure || { rows: [] };
      
      // Navigate through the layout structure
      if (layoutStructure.rows && Array.isArray(layoutStructure.rows)) {
        for (const row of layoutStructure.rows) {
          if (row.columns && Array.isArray(row.columns)) {
            for (const col of row.columns) {
              // Remove group columns that reference deleted groups
              if (col.type === 'group' && col.id && deletedGroupIds.includes(col.id.toString())) {
                col.type = 'empty';
                delete col.id;
                delete col.group_name;
                templateUpdated = true;
                console.log(`Group column removed from template ${template._id} due to deleted group`);
              }
              
              // Remove scene columns that reference deleted scenes
              if (col.type === 'scene' && col.id && deletedSceneIds.includes(col.id.toString())) {
                col.type = 'empty';
                delete col.id;
                delete col.scene_name;
                templateUpdated = true;
                console.log(`Scene column removed from template ${template._id} due to deleted scene`);
              }
              
              if (col.elements && Array.isArray(col.elements)) {
                const originalLength = col.elements.length;
                col.elements = col.elements.filter(element => {
                  // Remove device elements
                  if (element.deviceId === deviceId) return false;
                  // Remove scene elements that reference deleted scenes
                  if (element.type === 'scene' && element.id && deletedSceneIds.includes(element.id.toString())) return false;
                  if (element.sceneId && deletedSceneIds.includes(element.sceneId.toString())) return false;
                  return true;
                });
                
                if (col.elements.length < originalLength) {
                  templateUpdated = true;
                  console.log(`Elements removed from template ${template._id} (${template.name})`);
                }
                
                totalElementsRemaining += col.elements.length;
              }
              
              // Check if column has content (not empty type and has elements or is a valid type)
              if (col.type !== 'empty' && (col.elements?.length > 0 || ['group', 'scene'].includes(col.type))) {
                hasNonEmptyColumns = true;
              }
            }
          }
        }
      }
      
      if (templateUpdated) {
        if (totalElementsRemaining === 0 && !hasNonEmptyColumns) {
          // If no elements left and no non-empty columns, delete the template completely
          await Template.findByIdAndDelete(template._id);
          deletionSummary.templates.deleted++;
          console.log(`Template ${template._id} (${template.name}) deleted completely - no content left after removing device ${deviceId}`);
        } else {
          // Update template normally (keep active if it has other content)
          await Template.findByIdAndUpdate(
            template._id,
            { 
              layoutStructure,
              updatedAt: new Date()
            },
            { new: true }
          );
          deletionSummary.templates.updated++;
          console.log(`Template ${template._id} (${template.name}) updated - ${totalElementsRemaining} elements remaining after removing device ${deviceId}`);
        }
      }
    }

    console.log(`Device ${deviceId} removal summary:`, deletionSummary);
    return deletionSummary;

  } catch (error) {
    console.error(`Error removing device ${deviceId} from related collections:`, error);
    throw new Error(`Failed to remove device from related collections: ${error.message}`);
  }
};

/**
 * Remove channel references from all related collections (groups, scenes, sensors, templates)
 * @param {string} deviceId - Device ID
 * @param {string} channelId - Channel ID to remove
 * @param {Object} user - User object for audit trail
 * @returns {Object} Summary of deletions
 */
export const removeChannelFromRelatedCollections = async (deviceId, channelId, user) => {
  try {
    const deletionSummary = {
      groups: { updated: 0, removed: 0 },
      scenes: { updated: 0, removed: 0 },
      sensors: { updated: 0, removed: 0 },
      templates: { updated: 0, removed: 0 }
    };

    console.log(`Removing channel ${deviceId}/${channelId} from related collections...`);

    // 1. Remove channel from Groups
    console.log(`Removing channel ${deviceId}/${channelId} from groups...`);
    const groupsWithChannel = await Group.find({
      'devices.deviceId': deviceId,
      'devices.channels.channelId': channelId,
      isDeleted: false
    });

    for (const group of groupsWithChannel) {
      let groupUpdated = false;
      
      for (const device of group.devices) {
        if (device.deviceId === deviceId) {
          const originalLength = device.channels.length;
          device.channels = device.channels.filter(channel => channel.channelId !== channelId);
          
          if (device.channels.length < originalLength) {
            groupUpdated = true;
            console.log(`Channel ${channelId} removed from device ${deviceId} in group ${group._id} (${group.name})`);
          }
        }
      }
      
      // Remove devices that have no channels left
      const originalDevicesLength = group.devices.length;
      group.devices = group.devices.filter(device => device.channels.length > 0);
      
      if (group.devices.length === 0) {
        // If no devices left, soft delete the group
        group.isDeleted = true;
        group.updatedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        deletionSummary.groups.removed++;
        console.log(`Group ${group._id} (${group.name}) soft deleted - no devices with channels left after removing ${deviceId}/${channelId}`);
      } else if (groupUpdated || group.devices.length < originalDevicesLength) {
        group.updatedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        deletionSummary.groups.updated++;
      }
      
      await group.save();
    }

    // 2. Remove channel from Scenes
    console.log(`Removing channel ${deviceId}/${channelId} from scenes...`);
    
    // Handle device-type scenes
    const deviceScenes = await Scene.find({
      type: 'device',
      'Devices.deviceId': deviceId,
      'Devices.channels.channelId': channelId,
      isDeleted: false
    });

    for (const scene of deviceScenes) {
      let sceneUpdated = false;
      
      for (const device of scene.Devices) {
        if (device.deviceId === deviceId) {
          const originalLength = device.channels.length;
          device.channels = device.channels.filter(channel => channel.channelId !== channelId);
          
          if (device.channels.length < originalLength) {
            sceneUpdated = true;
            console.log(`Channel ${channelId} removed from device ${deviceId} in device scene ${scene._id} (${scene.name})`);
          }
        }
      }
      
      // Remove devices that have no channels left
      const originalDevicesLength = scene.Devices.length;
      scene.Devices = scene.Devices.filter(device => device.channels.length > 0);
      
      if (scene.Devices.length === 0) {
        // If no devices left, soft delete the scene
        scene.isDeleted = true;
        scene.deletedAt = new Date();
        scene.deletedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        deletionSummary.scenes.removed++;
        console.log(`Device scene ${scene._id} (${scene.name}) soft deleted - no devices with channels left after removing ${deviceId}/${channelId}`);
      } else if (sceneUpdated || scene.Devices.length < originalDevicesLength) {
        scene.updatedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        deletionSummary.scenes.updated++;
      }
      
      await scene.save();
    }

    // Handle group-type scenes
    const groupScenes = await Scene.find({
      type: 'group',
      'Groups.devices.deviceId': deviceId,
      'Groups.devices.channels.channelId': channelId,
      isDeleted: false
    });

    for (const scene of groupScenes) {
      let sceneUpdated = false;
      let totalDevicesRemaining = 0;
      
      for (const groupEntry of scene.Groups) {
        for (const device of groupEntry.devices) {
          if (device.deviceId === deviceId) {
            const originalLength = device.channels.length;
            device.channels = device.channels.filter(channel => channel.channelId !== channelId);
            
            if (device.channels.length < originalLength) {
              sceneUpdated = true;
              console.log(`Channel ${channelId} removed from device ${deviceId} in group scene ${scene._id} (${scene.name}), group ${groupEntry.groupId}`);
            }
          }
        }
        
        // Remove devices that have no channels left
        groupEntry.devices = groupEntry.devices.filter(device => device.channels.length > 0);
        totalDevicesRemaining += groupEntry.devices.length;
      }
      
      // Remove group entries that have no devices left
      const originalGroupsLength = scene.Groups.length;
      scene.Groups = scene.Groups.filter(groupEntry => groupEntry.devices.length > 0);
      
      if (scene.Groups.length === 0 || totalDevicesRemaining === 0) {
        // If no groups left or no devices in any groups, soft delete the scene
        scene.isDeleted = true;
        scene.deletedAt = new Date();
        scene.deletedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        deletionSummary.scenes.removed++;
        console.log(`Group scene ${scene._id} (${scene.name}) soft deleted - no functional groups/devices left after removing ${deviceId}/${channelId}`);
      } else if (sceneUpdated || scene.Groups.length < originalGroupsLength) {
        scene.updatedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        deletionSummary.scenes.updated++;
      }
      
      // Ensure all remaining channels have required command field before saving
      for (const groupEntry of scene.Groups) {
        for (const device of groupEntry.devices) {
          for (const channel of device.channels) {
            if (!channel.command) {
              channel.command = channel.channelType === 'shade' ? 'close' : 'off';
            }
          }
        }
      }
      
      await scene.save();
    }

    // 3. Remove sensors that reference the specific channel
    console.log(`Removing sensors that reference channel ${deviceId}/${channelId}...`);
    const sensorsChannelUpdate = await Sensor.updateMany(
      {
        sensor: { $regex: new RegExp(`^${deviceId}_.*_${channelId}$`, 'i') },
        isDelete: false
      },
      {
        $set: {
          isDelete: true,
          updatedBy: {
            userId: user._id,
            fullName: user.fullName,
            email: user.email
          },
          updatedAt: new Date()
        }
      },
      { runValidators: false }
    );
    
    deletionSummary.sensors.removed += sensorsChannelUpdate.modifiedCount;
    console.log(`${sensorsChannelUpdate.modifiedCount} sensors soft deleted - referenced channel ${deviceId}/${channelId}`);

    // 4. Remove channel from Templates
    console.log(`Removing channel ${deviceId}/${channelId} from templates...`);
    const templates = await Template.find({ 
      status: { $ne: 'Inactive' } // Only check active templates
    });

    for (const template of templates) {
      let templateUpdated = false;
      let totalElementsRemaining = 0;
      const layoutStructure = template.layoutStructure || { rows: [] };
      
      // Navigate through the layout structure
      if (layoutStructure.rows && Array.isArray(layoutStructure.rows)) {
        for (const row of layoutStructure.rows) {
          if (row.columns && Array.isArray(row.columns)) {
            for (const col of row.columns) {
              if (col.elements && Array.isArray(col.elements)) {
                const originalLength = col.elements.length;
                col.elements = col.elements.filter(element => 
                  !(element.deviceId === deviceId && element.channelId === channelId)
                );
                
                if (col.elements.length < originalLength) {
                  templateUpdated = true;
                  console.log(`Channel ${deviceId}/${channelId} removed from template ${template._id} (${template.name})`);
                }
                
                totalElementsRemaining += col.elements.length;
              }
            }
          }
        }
      }
      
      if (templateUpdated) {
        if (totalElementsRemaining === 0) {
          // If no elements left in the entire template, soft delete it
          await Template.findByIdAndUpdate(
            template._id,
            { 
              status: 'Inactive',
              layoutStructure,
              updatedAt: new Date()
            },
            { new: true }
          );
          deletionSummary.templates.removed++;
          console.log(`Template ${template._id} (${template.name}) marked as Inactive - no elements left after removing channel ${deviceId}/${channelId}`);
        } else {
          // Update template normally
          await Template.findByIdAndUpdate(
            template._id,
            { 
              layoutStructure,
              updatedAt: new Date()
            },
            { new: true }
          );
          deletionSummary.templates.updated++;
          console.log(`Template ${template._id} (${template.name}) updated - ${totalElementsRemaining} elements remaining after removing channel ${deviceId}/${channelId}`);
        }
      }
    }

    console.log(`Channel ${deviceId}/${channelId} removal summary:`, deletionSummary);
    return deletionSummary;

  } catch (error) {
    console.error(`Error removing channel ${deviceId}/${channelId} from related collections:`, error);
    throw new Error(`Failed to remove channel from related collections: ${error.message}`);
  }
};

/**
 * Remove specific channel from group-type scenes
 * @param {string} deviceId - Device ID
 * @param {string} channelId - Channel ID to remove
 * @param {Object} user - User object for audit trail
 * @returns {Object} Summary of deletions
 */
export const removeChannelFromGroupScenes = async (deviceId, channelId, user) => {
  try {
    console.log(`🔍 Removing channel ${deviceId}/${channelId} from group-type scenes...`);
    
    const groupScenes = await Scene.find({
      type: 'group',
      'Groups.devices.deviceId': deviceId,
      'Groups.devices.channels.channelId': channelId,
      isDeleted: false
    });

    console.log(`📊 Found ${groupScenes.length} group scenes containing device ${deviceId} and channel ${channelId}`);

    let scenesUpdated = 0;
    let scenesRemoved = 0;

    for (const scene of groupScenes) {
      let sceneUpdated = false;
      let totalDevicesRemaining = 0;
      
      for (const groupEntry of scene.Groups) {
        for (const device of groupEntry.devices) {
          if (device.deviceId === deviceId) {
            const originalLength = device.channels.length;
            device.channels = device.channels.filter(channel => channel.channelId !== channelId);
            
            if (device.channels.length < originalLength) {
              sceneUpdated = true;
              console.log(`Channel ${channelId} removed from device ${deviceId} in group scene ${scene._id} (${scene.name})`);
            }
          }
        }
        
        // Remove devices that have no channels left
        groupEntry.devices = groupEntry.devices.filter(device => device.channels.length > 0);
        totalDevicesRemaining += groupEntry.devices.length;
      }
      
      // Remove group entries that have no devices left
      const originalGroupsLength = scene.Groups.length;
      scene.Groups = scene.Groups.filter(groupEntry => groupEntry.devices.length > 0);
      
      if (scene.Groups.length === 0 || totalDevicesRemaining === 0) {
        // If no groups left or no devices in any groups, soft delete the scene
        scene.isDeleted = true;
        scene.deletedAt = new Date();
        scene.deletedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        scenesRemoved++;
        console.log(`Group scene ${scene._id} (${scene.name}) soft deleted - no functional groups/devices left after removing ${deviceId}/${channelId}`);
      } else if (sceneUpdated || scene.Groups.length < originalGroupsLength) {
        scene.updatedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        scenesUpdated++;
        console.log(`Group scene ${scene._id} (${scene.name}) updated - ${scene.Groups.length} groups with ${totalDevicesRemaining} total devices remaining`);
      }
      
      // Ensure all remaining channels have required command field before saving
      for (const groupEntry of scene.Groups) {
        for (const device of groupEntry.devices) {
          for (const channel of device.channels) {
            if (!channel.command) {
              channel.command = channel.channelType === 'shade' ? 'close' : 'off';
            }
          }
        }
      }
      
      await scene.save();
    }

    console.log(`Group scenes cleanup for channel ${deviceId}/${channelId}: ${scenesUpdated} updated, ${scenesRemoved} removed`);
    return { updated: scenesUpdated, removed: scenesRemoved };

  } catch (error) {
    console.error(`Error removing channel ${deviceId}/${channelId} from group scenes:`, error);
    throw new Error(`Failed to remove channel from group scenes: ${error.message}`);
  }
};

/**
 * Add channel references to related collections (groups, scenes, templates) when a channel is installed
 * @param {string} deviceId - Device ID
 * @param {string} channelId - Channel ID to add
 * @param {Object} channelData - Channel data (type, properties, etc.)
 * @param {Object} user - User object for audit trail
 * @returns {Object} Summary of additions
 */
export const addChannelToRelatedCollections = async (deviceId, channelId, channelData, user) => {
  try {
    const additionSummary = {
      groups: { updated: 0, created: 0 },
      scenes: { updated: 0, created: 0 },
      templates: { updated: 0, created: 0 }
    };

    console.log(`Adding channel ${deviceId}/${channelId} to related collections...`);

    // 1. Add channel to existing Groups that contain this device
    console.log(`Adding channel ${deviceId}/${channelId} to existing groups...`);
    const groupsWithDevice = await Group.find({
      'devices.deviceId': deviceId,
      isDeleted: false
    });

    for (const group of groupsWithDevice) {
      let groupUpdated = false;
      
      for (const device of group.devices) {
        if (device.deviceId === deviceId) {
          // Check if channel already exists
          const existingChannel = device.channels.find(ch => ch.channelId === channelId);
          
          if (!existingChannel) {
            // Add the new channel to the device
            device.channels.push({
              channelId: channelId,
              channelType: channelData.type || 'unknown'
            });
            groupUpdated = true;
            console.log(`Channel ${channelId} added to device ${deviceId} in group ${group._id} (${group.name})`);
          }
        }
      }
      
      if (groupUpdated) {
        group.updatedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        await group.save();
        additionSummary.groups.updated++;
      }
    }

    // 2. Add channel to existing Device-type Scenes that contain this device
    console.log(`Adding channel ${deviceId}/${channelId} to existing device scenes...`);
    const deviceScenes = await Scene.find({
      type: 'device',
      'Devices.deviceId': deviceId,
      isDeleted: false
    });

    for (const scene of deviceScenes) {
      let sceneUpdated = false;
      
      for (const device of scene.Devices) {
        if (device.deviceId === deviceId) {
          // Check if channel already exists
          const existingChannel = device.channels.find(ch => ch.channelId === channelId);
          
          if (!existingChannel) {
            // Add the new channel with appropriate default settings
            const newChannelConfig = {
              channelType: channelData.type,
              channelId: channelId,
              command: 'off' // Default command
            };

            // Add type-specific properties
            if (channelData.type === 'led') {
              newChannelConfig.brightness = channelData.properties?.brightness || 0;
            } else if (channelData.type === 'shade') {
              newChannelConfig.openLevel = channelData.properties?.openLevel || 0;
            }

            device.channels.push(newChannelConfig);
            sceneUpdated = true;
            console.log(`Channel ${channelId} added to device ${deviceId} in device scene ${scene._id} (${scene.name})`);
          }
        }
      }
      
      if (sceneUpdated) {
        scene.updatedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        await scene.save();
        additionSummary.scenes.updated++;
      }
    }

    // 3. Add channel to existing Group-type Scenes that contain groups with this device
    console.log(`Adding channel ${deviceId}/${channelId} to existing group scenes...`);
    const groupScenes = await Scene.find({
      type: 'group',
      'Groups.devices.deviceId': deviceId,
      isDeleted: false
    });

    for (const scene of groupScenes) {
      let sceneUpdated = false;
      
      for (const groupEntry of scene.Groups) {
        for (const device of groupEntry.devices) {
          if (device.deviceId === deviceId) {
            // Check if channel already exists
            const existingChannel = device.channels.find(ch => ch.channelId === channelId);
            
            if (!existingChannel) {
              // Add the new channel with appropriate default settings
              const newChannelConfig = {
                channelType: channelData.type,
                channelId: channelId,
                command: 'off' // Default command
              };

              // Add type-specific properties
              if (channelData.type === 'led') {
                newChannelConfig.brightness = channelData.properties?.brightness || 0;
              } else if (channelData.type === 'shade') {
                newChannelConfig.openLevel = channelData.properties?.openLevel || 0;
              }

              device.channels.push(newChannelConfig);
              sceneUpdated = true;
              console.log(`Channel ${channelId} added to device ${deviceId} in group scene ${scene._id} (${scene.name}), group ${groupEntry.groupId}`);
            }
          }
        }
      }
      
      if (sceneUpdated) {
        scene.updatedBy = {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        };
        await scene.save();
        additionSummary.scenes.updated++;
      }
    }

    // 4. Add channel to existing Templates that contain this device
    console.log(`Adding channel ${deviceId}/${channelId} to existing templates...`);
    const templates = await Template.find({ 
      status: { $ne: 'Inactive' } // Only check active templates
    });

    for (const template of templates) {
      let templateUpdated = false;
      const layoutStructure = template.layoutStructure || { rows: [] };
      
      // Navigate through the layout structure to find elements with this deviceId
      if (layoutStructure.rows && Array.isArray(layoutStructure.rows)) {
        for (const row of layoutStructure.rows) {
          if (row.columns && Array.isArray(row.columns)) {
            for (const col of row.columns) {
              if (col.elements && Array.isArray(col.elements)) {
                // Check if there are already elements for this device
                const deviceElements = col.elements.filter(element => element.deviceId === deviceId);
                
                if (deviceElements.length > 0) {
                  // Check if this specific channel already exists
                  const existingChannelElement = col.elements.find(element => 
                    element.deviceId === deviceId && element.channelId === channelId
                  );
                  
                  if (!existingChannelElement) {
                    // Add new element for this channel
                    const newElement = {
                      id: channelId,
                      name: channelData.name || `${deviceId} ${channelId}`,
                      deviceId: deviceId,
                      channelId: channelId,
                      type: channelData.type || 'unknown',
                      status: channelData.status || 'off',
                      properties: {
                        ...channelData.properties,
                        installed: true
                      },
                      capabilityId: channelData._id ? channelData._id.toString() : null
                    };
                    
                    col.elements.push(newElement);
                    templateUpdated = true;
                    console.log(`Channel ${deviceId}/${channelId} added to template ${template._id} (${template.name})`);
                  }
                }
              }
            }
          }
        }
      }
      
      if (templateUpdated) {
        await Template.findByIdAndUpdate(
          template._id,
          { 
            layoutStructure,
            updatedAt: new Date()
          },
          { new: true }
        );
        additionSummary.templates.updated++;
        console.log(`Template ${template._id} (${template.name}) updated - added channel ${deviceId}/${channelId}`);
      }
    }

    console.log(`Channel ${deviceId}/${channelId} addition summary:`, additionSummary);
    return additionSummary;

  } catch (error) {
    console.error(`Error adding channel ${deviceId}/${channelId} to related collections:`, error);
    throw new Error(`Failed to add channel to related collections: ${error.message}`);
  }
};

/**
 * Update sensor scenes when devices/groups/scenes are deleted
 * Sets motionScene and NoMotionScene to null if they reference deleted entities
 * @param {string} deviceId - Device ID that was deleted
 * @param {Array} deletedGroups - Array of groups that were deleted
 * @param {Array} deletedScenes - Array of scenes that were deleted
 * @param {Object} user - User object for audit trail
 */
const updateSensorScenesForDeletedEntities = async (deviceId, deletedGroups, deletedScenes, user) => {
  try {
    console.log(`Updating sensor scenes for deleted device ${deviceId}...`);
    
    // Find all scenes that contain the deleted device (including those that might be deleted)
    const scenesWithDeletedDevice = await Scene.find({
      $or: [
        { 'Devices.deviceId': deviceId },
        { 'Groups.devices.deviceId': deviceId }
      ]
    }).select('_id').lean();
    
    // Get IDs of all affected scenes (including the ones we just deleted)
    const affectedSceneIds = [
      ...scenesWithDeletedDevice.map(scene => scene._id),
      ...deletedScenes.map(scene => scene._id)
    ];
    
    if (affectedSceneIds.length > 0) {
      // Update sensors that reference these scenes - set motionScene to null
      const motionSceneUpdate = await Sensor.updateMany(
        {
          motionScene: { $in: affectedSceneIds },
          isDelete: false
        },
        {
          $set: {
            motionScene: null,
            updatedBy: {
              userId: user._id,
              fullName: user.fullName,
              email: user.email
            },
            updatedAt: new Date()
          }
        }
      );
      
      // Update sensors that reference these scenes - set NoMotionScene to null
      const noMotionSceneUpdate = await Sensor.updateMany(
        {
          NoMotionScene: { $in: affectedSceneIds },
          isDelete: false
        },
        {
          $set: {
            NoMotionScene: null,
            updatedBy: {
              userId: user._id,
              fullName: user.fullName,
              email: user.email
            },
            updatedAt: new Date()
          }
        }
      );
      
      console.log(`Updated ${motionSceneUpdate.modifiedCount} sensors - set motionScene to null`);
      console.log(`Updated ${noMotionSceneUpdate.modifiedCount} sensors - set NoMotionScene to null`);
    }
    
  } catch (error) {
    console.error(`Error updating sensor scenes for deleted device ${deviceId}:`, error);
    // Don't throw - this is a cleanup operation
  }
};

const removeRelatedSensorData = async (deviceId, sensorId) => {
  try {
    const relatedSensorScenes = await Sensor.find({
      device: deviceId,
      sensor: { $in: [sensorId] }
    });
    console.log("--relatedSensorScenes--", relatedSensorScenes);
    
    relatedSensorScenes.map((scene) => {
      if(scene.sensor.length === 1){
        scene.isDelete = true;
      } else {
        scene.sensor = scene.sensor.filter(s => s !== sensorId);
      }
      scene.save();
    });
  } catch (error) {
    console.error(`Error removing sensors related to device ${deviceId}:`, error);
    throw new Error(`Failed to remove related sensors: ${error.message}`);
  }
};

