import mongoose from 'mongoose';
import { Campus } from '../models/Campus.js';
import { CampusBuilding } from '../models/CampusBuilding.js';
import { CampusFloor } from '../models/CampusFloor.js';
import { CampusZone } from '../models/CampusZone.js';
import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import dotenv from 'dotenv';
import { saveImage } from '../utils/catchAsync.js';
import { addLog } from './log.service.js';
import { User } from '../models/User.js';

/**
 * Campus Service - Data Access Layer
 * 
 * Flow: routes → controller → SERVICE → database
 * 
 * Responsibilities:
 * - Database queries and operations
 * - Business logic implementation
 * - Data transformation and validation
 * - File system operations (images)
 * - Complex multi-model operations
 * 
 * Key operations:
 * - CRUD operations with user filtering
 * - Image management (upload/attach URLs)
 * - Cascade operations (create buildings with campus)
 * - Soft delete with device cleanup
 * - Hierarchical data retrieval
 */
dotenv.config();
const imagesDir = process.env.IMAGES_DIR || path.join(process.cwd(), 'images');

const IMAGES_DIR = process.env.IMAGES_DIR || '';
/**
 * Get campuses with advanced filtering, search, and pagination
 * 
 * Features:
 * - User permission filtering
 * - Multi-field search (name, location, description)
 * - Status/type/organization filters
 * - Building/floor/zone counts
 * - Image URL attachment from filesystem
 * - Pagination with metadata
 */
export const getAllCampuses = async (queryParams = {}) => {
  const {
    page = 1,
    limit = 20,
    status,
    type,
    organization,
    search,
    name,
    location,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    userFilter
  } = queryParams;

  // Start with user filter if provided, otherwise build base filter
  const filter = userFilter ? { ...userFilter } : {};

  // If no userFilter provided, add basic filters
  if (!userFilter) {
    // Filter out deleted records
    filter.isDelete = { $ne: true };
    // Always filter for active records only (status = 1)
    filter.status = 1;
  } else {
    // Add status filter to user filter
    if (!filter.$and) filter.$and = [];
    filter.$and.push({ status: status !== undefined ? status : 1 });
  }

  if (type) {
    if (!filter.$and) filter.$and = [];
    filter.$and.push({ type });
  }

  if (organization) {
    if (!filter.$and) filter.$and = [];
    filter.$and.push({ organization: { $regex: organization, $options: 'i' } });
  }

  // Enhanced search functionality
  const searchConditions = [];

  // General search across multiple fields
  if (search) {
    searchConditions.push({
      $or: [
        { name: { $regex: search, $options: 'i' } },
        { location: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { accessId: { $regex: search, $options: 'i' } }
      ]
    });
  }

  // Specific name search
  if (name) {
    searchConditions.push({
      name: { $regex: name, $options: 'i' }
    });
  }

  // Specific location search
  if (location) {
    searchConditions.push({
      location: { $regex: location, $options: 'i' }
    });
  }

  // Apply search conditions
  if (searchConditions.length > 0) {
    filter.$and = searchConditions;
  }

  // Calculate skip value for pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);

  // Get sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // Execute query with pagination
  let campuses = await Campus.find(filter)
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email')
    .sort(sort)
    .skip(skip)
    .limit(parseInt(limit))
    .lean();

  // Add building, floor, and zone counts for each campus
  for (const campus of campuses) {
    // Get active building count for this campus (isDelete: false and status: 1)
    const buildingCount = await CampusBuilding.countDocuments({
      campusId: campus._id,
      isDelete: { $ne: true },
      status: 1
    });

    // Get active building IDs for floor and zone count queries
    const buildingIds = await CampusBuilding.find({
      campusId: campus._id,
      isDelete: { $ne: true },
      status: 1
    }).distinct('_id');

    // Get active floor count for all buildings in this campus (deleted: false and status: 1)
    const floorCount = buildingIds.length > 0 ? await CampusFloor.countDocuments({
      buildingId: { $in: buildingIds },
      deleted: { $ne: true },
      status: 1
    }) : 0;

    // Get active floor IDs for zone count query
    const floorIds = buildingIds.length > 0 ? await CampusFloor.find({
      buildingId: { $in: buildingIds },
      deleted: { $ne: true },
      status: 1
    }).distinct('_id') : [];

    // Get active zone count for all floors in this campus (deleted: false and status: 1)
    const zoneCount = floorIds.length > 0 ? await CampusZone.countDocuments({
      floorId: { $in: floorIds },
      deleted: { $ne: true },
      status: 1
    }) : 0;

    // Add counts to campus object
    campus.buildingCount = buildingCount;
    campus.floorCount = floorCount;
    campus.zoneCount = zoneCount;
  }

  // Attach image URLs from filesystem only if campus.name === image filename
  campuses = campuses.map((campus) => {
    const campusName = campus._id;
    console.log(`Checking images for campus: ${campusName}, ${campus.name}`);
    let matchedImage = null;

    // check for multiple extensions
    const possibleExtensions = ['.jpg', '.jpeg', '.png', '.webp'];

    for (const ext of possibleExtensions) {
      const imagePath = path.join(IMAGES_DIR, `${campusName}${ext}`);
      if (fs.existsSync(imagePath)) {
        matchedImage = `/images/${campusName}${ext}`;
        break;
      }
    }
    console.log(`Matched image for campus - ${campus.name}:`, matchedImage);

    campus.imageUrl = matchedImage; // null if no match
    return campus;
  });

  // Get total count for pagination
  const total = await Campus.countDocuments(filter);

  return {
    campuses,
    pagination: {
      currentPage: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit)),
      totalCampuses: total,
      hasNextPage: skip + campuses.length < total,
      hasPrevPage: parseInt(page) > 1
    },
    searchInfo: {
      searchTerm: search || null,
      nameFilter: name || null,
      locationFilter: location || null,
      resultsFound: campuses.length,
      totalMatches: total
    }
  };
};

// export const getAllCampuses = async (queryParams = {}) => {
//   const {
//     page = 1,
//     limit = 20,
//     status,
//     type,
//     organization,
//     search,
//     name,
//     location,
//     sortBy = 'createdAt',
//     sortOrder = 'desc'
//   } = queryParams;

//   // Build filter object
//   const filter = {};
//   filter.status = 1;

//   if (status !== undefined) {
//     filter.status = status;
//   }

//   if (type) {
//     filter.type = type;
//   }

//   if (organization) {
//     filter.organization = { $regex: organization, $options: 'i' };
//   }

//   // Enhanced search functionality
//   const searchConditions = [];

//   if (search) {
//     searchConditions.push({
//       $or: [
//         { name: { $regex: search, $options: 'i' } },
//         { location: { $regex: search, $options: 'i' } },
//         { description: { $regex: search, $options: 'i' } },
//         { accessId: { $regex: search, $options: 'i' } }
//       ]
//     });
//   }

//   if (name) {
//     searchConditions.push({
//       name: { $regex: name, $options: 'i' }
//     });
//   }

//   if (location) {
//     searchConditions.push({
//       location: { $regex: location, $options: 'i' }
//     });
//   }

//   if (searchConditions.length > 0) {
//     filter.$and = searchConditions;
//   }

//   // Pagination + sorting
//   const skip = (parseInt(page) - 1) * parseInt(limit);
//   const sort = {};
//   sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

//   // Query campuses
//   const campuses = await Campus.find(filter)
//     .populate('createdBy.userId', 'fullName email')
//     .populate('updatedBy.userId', 'fullName email')
//     .sort(sort)
//     .skip(skip)
//     .limit(parseInt(limit))
//     .lean();

//   const total = await Campus.countDocuments(filter);

//   // --- Attach image URL ---
//   const imagesDir = process.env.IMAGES_DIR?.replace('$HOME', process.env.HOME);
//   let imageFiles = [];

//   if (imagesDir && fs.existsSync(imagesDir)) {
//     imageFiles = fs.readdirSync(imagesDir);
//   }

//   const campusesWithImage = campuses.map((campus) => {
//     const matchedImage = imageFiles.find(
//       (img) => path.parse(img).name.toLowerCase() === campus.name.toLowerCase()
//     );

//     return {
//       ...campus,
//       imageUrl: matchedImage ? `/images/${matchedImage}` : null
//     };
//   });

//   return {
//     campuses: campusesWithImage,
//     pagination: {
//       currentPage: parseInt(page),
//       totalPages: Math.ceil(total / parseInt(limit)),
//       totalCampuses: total,
//       hasNextPage: skip + campuses.length < total,
//       hasPrevPage: parseInt(page) > 1
//     },
//     searchInfo: {
//       searchTerm: search || null,
//       nameFilter: name || null,
//       locationFilter: location || null,
//       resultsFound: campuses.length,
//       totalMatches: total
//     }
//   };
// };

/**
 * Create new campus with buildings and image processing
 * 
 * Process:
 * 1. Validate unique accessId and name
 * 2. Process and save campus image (base64 → file)
 * 3. Create campus document
 * 4. Create associated buildings if provided
 * 5. Handle rollback on errors
 * 
 * Supports:
 * - Base64 image upload
 * - Nested building creation
 * - Transaction-like cleanup on failure
 */
export const addCampus = async (campusData, user) => {
  // If accessId provided, check for conflicts only among non-deleted campuses
  if (campusData.accessId) {
    const existingCampus = await Campus.findOne({
      accessId: campusData.accessId,
      isDelete: { $ne: true }, // ignore soft-deleted records
    });
    if (existingCampus) {
      throw new Error('Campus with this access ID already exists');
    }
  }

  // Check if campus with same name and organization already exists among non-deleted records
  const existingCampusByName = await Campus.findOne({
    name: campusData.name,
    organization: campusData.organization,
    isDelete: { $ne: true }, // ignore soft-deleted records
  });
  if (existingCampusByName) {
    throw new Error('Campus with this name already exists in the organization');
  }

  // Separate buildings and image
  const { buildings: buildingsData, campusImage, ...campusInfo } = campusData;

  let campus;
  const createdBuildings = []; // track created building docs for cleanup
  try {
    // Create campus first without image
    campus = new Campus({
      ...campusInfo,
      campusImage: null,
      buildings: [],
      createdBy: {
        userId: user._id,
        fullName: user.fullName,
        email: user.email
      },
      updatedBy: {
        userId: user._id,
        fullName: user.fullName,
        email: user.email
      }
    });

    await campus.save();

    // Handle campus image if provided
    if (campusImage) {
      try {
        const imagePublicPath = await saveImage(campusImage, campus._id.toString(), 'campus')
        campus.campusImage = imagePublicPath;
        await campus.save();
      } catch (imgErr) {
        // cleanup campus if image processing fails
        try {
          await Campus.findByIdAndDelete(campus._id);
        } catch (cleanupErr) {
          console.error('Failed to cleanup campus after image error:', cleanupErr.message);
        }
        throw new Error(`Failed to process campus image: ${imgErr.message}`);
      }
    }

    // Handle buildings creation if provided
    const createdBuildingIds = [];

    if (buildingsData && Array.isArray(buildingsData) && buildingsData.length > 0) {
      for (const buildingData of buildingsData) {
        try {
          if (typeof buildingData === 'object') {
            const building = new CampusBuilding({
              ...buildingData,
              campusId: campus._id,
              createdBy: {
                userId: user._id,
                fullName: user.fullName,
                email: user.email
              },
              updatedBy: {
                userId: user._id,
                fullName: user.fullName,
                email: user.email
              }
            });

            await building.save();
            createdBuildings.push(building);
            createdBuildingIds.push(building._id);
            
            // Add log for building creation
            await addLog({
              action: 'Created',
              name: `${building.name || 'Unnamed Building'} in campus "${campus.name}"`,
              timestamp: Math.floor(Date.now() / 1000), // UNIX timestamp in seconds
              type: 'Building',
              userId: user._id.toString(),
              userName: user.fullName || user.email || 'Unknown User'
            });
          } else if (typeof buildingData === 'string') {
            const existingBuilding = await CampusBuilding.findById(buildingData);
            if (!existingBuilding) {
              throw new Error(`Building with ID ${buildingData} not found`);
            }
            createdBuildingIds.push(buildingData);
          } else {
            throw new Error('Invalid building data format');
          }
        } catch (buildingError) {
          console.error('Building creation failed:', buildingError.message);

          // cleanup any created buildings
          if (createdBuildings.length > 0) {
            try {
              await CampusBuilding.deleteMany({
                _id: { $in: createdBuildings.map(b => b._id) }
              });
            } catch (delErr) {
              console.error('Failed to cleanup created buildings:', delErr.message);
            }
          }

          // cleanup campus record
          try {
            await Campus.findByIdAndDelete(campus._id);
          } catch (cleanupErr) {
            console.error('Cleanup failed:', cleanupErr.message);
          }

          throw new Error(`Failed to create building: ${buildingError.message}`);
        }
      }
    }

    if (createdBuildingIds.length > 0) {
      campus.buildings = createdBuildingIds;
      await campus.save();
    }

    await campus.populate('createdBy.userId', 'fullName email');
    const { default: Role } = await import('../models/Role.js');
    const { User } = await import('../models/User.js');
    // Find admin role with roleName 'Admin' and byDefault true
    const adminRole = await Role.findOne({ roleName: { $regex: /^admin$/i }, byDefault: "true" });

    if (adminRole) {
      // Find all users with this role (role_id field)
      const adminUsers = await User.find({ role_id: adminRole._id });
      for (const adminUser of adminUsers) {
        // Ensure allowedResources structure exists
        if (!adminUser.allowedResources) adminUser.allowedResources = { campusManagement: { campuses: [], buildings: [] } };
        if (!adminUser.allowedResources.campusManagement) adminUser.allowedResources.campusManagement = { campuses: [], buildings: [] };
        if (!Array.isArray(adminUser.allowedResources.campusManagement.campuses)) {
          adminUser.allowedResources.campusManagement.campuses = [];
        }
        if (!Array.isArray(adminUser.allowedResources.campusManagement.buildings)) {
          adminUser.allowedResources.campusManagement.buildings = [];
        }
        // Add campus._id to campuses array if not present
        if (!adminUser.allowedResources.campusManagement.campuses.includes(campus._id.toString())) {
          adminUser.allowedResources.campusManagement.campuses.push(campus._id.toString());
        }
        // Add created building IDs to buildings array if not present
        if (createdBuildingIds && createdBuildingIds.length > 0) {
          for (const bId of createdBuildingIds) {
            const bIdStr = bId.toString();
            if (!adminUser.allowedResources.campusManagement.buildings.includes(bIdStr)) {
              adminUser.allowedResources.campusManagement.buildings.push(bIdStr);
            }
          }
        }
        await adminUser.save();
      }
    }

    // Append campus to requesting user's campusData if not already present
    try {
      await User.updateOne(
        {
          _id: user._id,
          'campusData.0': { $exists: true }, // do nothing if campusData is empty
          'campusData.campus_id': { $ne: campus._id.toString() }
        },
        {
          $push: {
            campusData: {
              campus_id: campus._id.toString(),
              campus_name: campus.name,
              buildings: []
            }
          },
          $set: {
            updatedBy: {
              userId: user._id,
              fullName: user.fullName,
              email: user.email
            },
            updatedDate: new Date().toISOString()
          }
        }
      );
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error('Failed to append campus to user campusData:', e);
    }

    return campus;
  } catch (error) {
    // final cleanup: if campus exists but something else failed
    if (campus && campus._id) {
      try {
        // remove campus doc
        await Campus.findByIdAndDelete(campus._id);
      } catch (cleanupError) {
        console.error('Cleanup failed:', cleanupError.message);
      }

      // try to remove any buildings created
      if (createdBuildings.length > 0) {
        try {
          await CampusBuilding.deleteMany({
            _id: { $in: createdBuildings.map(b => b._id) }
          });
        } catch (cleanupError) {
          console.error('Cleanup buildings failed:', cleanupError.message);
        }
      }

      // Attempt to remove image file if saved (best-effort)
      try {
        const imagesDir = process.env.IMAGES_DIR || path.join(process.cwd(), 'public', 'images');
        const publicPathBase = process.env.IMAGES_PUBLIC_PATH || 'images';
        if (campus.campusImage && campus.campusImage.startsWith(publicPathBase)) {
          const fileName = campus.campusImage.split('/').pop();
          const filePath = path.join(imagesDir, fileName);
          if (fs.existsSync(filePath)) {
            await fs.promises.unlink(filePath);
          }
        }
      } catch (err) {
        console.error('Cleanup image file failed:', err.message);
      }
    }

    throw error;
  }
};

// export const addCampus = async (campusData, user) => {
//   // Check if campus with same accessId already exists
//   if (campusData.accessId) {
//     const existingCampus = await Campus.findOne({ accessId: campusData.accessId });
//     if (existingCampus) {
//       throw new Error('Campus with this access ID already exists');
//     }
//   }

//   // Check if campus with same name and organization already exists
//   const existingCampusByName = await Campus.findOne({
//     name: campusData.name,
//     organization: campusData.organization
//   });
//   if (existingCampusByName) {
//     throw new Error('Campus with this name already exists in the organization');
//   }

//   // Separate buildings and image
//   const { buildings: buildingsData, campusImage, ...campusInfo } = campusData;

//   let campusImagePath = null;

//   // Handle campus image if provided
//   if (campusImage) {
//     try {
//       // Decode base64
//       const base64Data = campusImage.replace(/^data:image\/\w+;base64,/, '');
//       const buffer = Buffer.from(base64Data, 'base64');

//       // Ensure images folder exists
//       const imagesDir = path.join(process.cwd(), 'images');
//       if (!fs.existsSync(imagesDir)) {
//         fs.mkdirSync(imagesDir, { recursive: true });
//       }

//       // Generate unique file name
//       const fileName = `${uuidv4()}.png`;
//       const filePath = path.join(imagesDir, fileName);

//       // Save image to folder
//       fs.writeFileSync(filePath, buffer);

//       // Store relative path
//       campusImagePath = `images/${fileName}`;
//     } catch (err) {
//       throw new Error('Failed to process campus image');
//     }
//   }

//   let campus;

//   try {
//     // Create campus with user information
//     campus = new Campus({
//       ...campusInfo,
//       campusImage: campusImagePath, // save image path (optional)
//       buildings: [],
//       createdBy: {
//         userId: user._id,
//         fullName: user.fullName,
//         email: user.email
//       },
//       updatedBy: {
//         userId: user._id,
//         fullName: user.fullName,
//         email: user.email
//       }
//     });

//     await campus.save();

//     // Handle buildings creation if provided
//     const createdBuildingIds = [];
//     const createdBuildings = [];

//     if (buildingsData && buildingsData.length > 0) {
//       for (const buildingData of buildingsData) {
//         try {
//           if (typeof buildingData === 'object') {
//             const building = new CampusBuilding({
//               ...buildingData,
//               campusId: campus._id,
//               createdBy: {
//                 userId: user._id,
//                 fullName: user.fullName,
//                 email: user.email
//               },
//               updatedBy: {
//                 userId: user._id,
//                 fullName: user.fullName,
//                 email: user.email
//               }
//             });

//             await building.save();
//             createdBuildingIds.push(building._id);
//             createdBuildings.push(building);
//           } else if (typeof buildingData === 'string') {
//             const existingBuilding = await CampusBuilding.findById(buildingData);
//             if (!existingBuilding) {
//               throw new Error(`Building with ID ${buildingData} not found`);
//             }
//             createdBuildingIds.push(buildingData);
//           }
//         } catch (buildingError) {
//           console.error('Building creation failed:', buildingError.message);

//           if (createdBuildings.length > 0) {
//             await CampusBuilding.deleteMany({
//               _id: { $in: createdBuildings.map(b => b._id) }
//             });
//           }

//           await Campus.findByIdAndDelete(campus._id);

//           throw new Error(`Failed to create building: ${buildingError.message}`);
//         }
//       }
//     }

//     if (createdBuildingIds.length > 0) {
//       campus.buildings = createdBuildingIds;
//       await campus.save();
//     }

//     await campus.populate('createdBy.userId', 'fullName email');

//     return campus;
//   } catch (error) {
//     if (campus && campus._id) {
//       try {
//         await Campus.findByIdAndDelete(campus._id);
//       } catch (cleanupError) {
//         console.error('Cleanup failed:', cleanupError.message);
//       }
//     }
//     throw error;
//   }
// };

/**
 * Update campus with validation and cascade updates
 * 
 * Features:
 * - Validates unique accessId/name constraints
 * - Updates campus type → building type mapping
 * - Image processing for updates
 * - User tracking (updatedBy)
 */
export const updateCampus = async (campusId, updateData, user) => {
  // Validate campusId format
  if (!campusId.match(/^[0-9a-fA-F]{24}$/)) {
    throw new Error('Invalid campus ID format');
  }

  // Find the campus first
  const campus = await Campus.findById(campusId);
  if (!campus) {
    throw new Error('Campus not found');
  }

  // Check if accessId is being updated and if it already exists
  if (updateData.accessId && updateData.accessId !== campus.accessId) {
    const existingCampus = await Campus.findOne({
      accessId: updateData.accessId,
      _id: { $ne: campusId },
      isDelete: { $ne: true }
    });
    if (existingCampus) {
      throw new Error('Campus with this access ID already exists');
    }
  }

  // Check if name and organization combination is being updated and if it already exists
  if ((updateData.name && updateData.name !== campus.name) ||
    (updateData.organization && updateData.organization !== campus.organization)) {
    const nameToCheck = updateData.name || campus.name;
    const organizationToCheck = updateData.organization || campus.organization;

    const existingCampusByName = await Campus.findOne({
      name: nameToCheck,
      organization: organizationToCheck,
      _id: { $ne: campusId }
    });
    if (existingCampusByName) {
      throw new Error('Campus with this name already exists in the organization');
    }
  }

  // Campus type to building type mapping - keep the same type
  const campusTypeToBuildingTypeMapping = {
    'Residential Apartment': 'Residential Apartment',
    'Commercial': 'Commercial', 
    'Hotel & Resort': 'Hotel & Resort'
  };

  try {
    // Update campus with user information
    const updatedCampus = await Campus.findByIdAndUpdate(
      campusId,
      {
        ...updateData,
        updatedBy: {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        },
        updatedAt: new Date()
      },
      {
        new: true,
        runValidators: true
      }
    ).populate('createdBy.userId', 'fullName email')
      .populate('updatedBy.userId', 'fullName email');

    if (!updatedCampus) {
      throw new Error('Campus not found or could not be updated');
    }

    // If campus type was updated, update all corresponding buildings' types
    if (updateData.type && updateData.type !== campus.type) {
      const newBuildingType = campusTypeToBuildingTypeMapping[updateData.type];
      
      if (newBuildingType) {
        // Update all buildings under this campus to have the new type
        await CampusBuilding.updateMany(
          {
            campusId: campusId,
            isDelete: { $ne: true } // Only update non-deleted buildings
          },
          {
            type: newBuildingType,
            updatedBy: {
              userId: user._id,
              fullName: user.fullName,
              email: user.email
            },
            updatedAt: new Date()
          }
        );

        console.log(`Updated building types to '${newBuildingType}' for campus '${updatedCampus.name}' (type: ${updateData.type})`);
      }
    }

    return updatedCampus;
  } catch (error) {
    // Handle mongoose validation errors
    if (error.name === 'ValidationError') {
      const validationErrors = Object.values(error.errors).map(err => err.message);
      throw new Error(`Validation failed: ${validationErrors.join(', ')}`);
    }

    // Handle duplicate key errors
    if (error.code === 11000) {
      const field = Object.keys(error.keyValue)[0];
      throw new Error(`Campus with this ${field} already exists`);
    }

    throw error;
  }
};

/**
 * Get campus with complete nested hierarchy
 * 
 * Structure: Campus → Buildings → Floors → Zones
 * Only returns active items (status = 1)
 * Includes counts at each level
 */
export const getCampusWithHierarchy = async (campusId) => {
  // First get the campus (only active)
  const campus = await Campus.findOne({ _id: campusId, status: 1 })
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email')
    .lean();

  if (!campus) {
    throw new Error('Campus not found or inactive');
  }

  // Get all active buildings for this campus with their floors and zones
  const buildings = await CampusBuilding.find({ 
    campusId: campusId, 
    isDelete: { $ne: true },
    status: 1 
  })
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email')
    .lean();

  // For each building, get its active floors and zones
  for (const building of buildings) {
    const floors = await CampusFloor.find({ 
      buildingId: building._id, 
      deleted: { $ne: true },
      status: 1 
    })
      .populate('createdBy.userId', 'fullName email')
      .populate('updatedBy.userId', 'fullName email')
      .lean();

    // For each floor, get its active zones
    for (const floor of floors) {
      const zones = await CampusZone.find({ 
        floorId: floor._id, 
        deleted: { $ne: true },
        status: 1 
      })
        .populate('createdBy.userId', 'fullName email')
        .populate('updatedBy.userId', 'fullName email')
        .lean();

      floor.zones = zones;
      floor.zoneCount = zones.length;
    }

    building.floors = floors;
    building.floorCount = floors.length;
  }

  campus.buildings = buildings;
  campus.buildingCount = buildings.length;

  // Calculate totals (only active items)
  const totalFloors = buildings.reduce((sum, building) => sum + building.floorCount, 0);
  const totalZones = buildings.reduce((sum, building) =>
    sum + building.floors.reduce((floorSum, floor) => floorSum + floor.zoneCount, 0), 0
  );

  return {
    ...campus,
    hierarchy: {
      buildingCount: buildings.length,
      totalFloors,
      totalZones
    }
  };
};

// Get campus by ID (simple version without full hierarchy)
export const getCampusById = async (campusId) => {
  // Get the campus (both active and inactive)
  const campus = await Campus.findOne({ _id: campusId })
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email')
    .lean();

  if (!campus) {
    throw new Error('Campus not found');
  }

  // Get all non-deleted buildings for this campus
  const buildings = await CampusBuilding.find({
    campusId: campusId,
    $or: [
      { isDelete: { $exists: false } },
      { isDelete: false },
      { isDelete: { $ne: true } }
    ]
  })
    .populate('createdBy.userId', 'fullName email')
    .populate('updatedBy.userId', 'fullName email')
    .lean();

  let totalFloorCount = 0;
  let totalZoneCount = 0;

  for (const building of buildings) {
    // Get all non-deleted floors for this building
    const floors = await CampusFloor.find({
      buildingId: building._id,
      $or: [
        { deleted: { $exists: false } },
        { deleted: false },
        { deleted: { $ne: true } }
      ]
    })
      .populate('createdBy.userId', 'fullName email')
      .populate('updatedBy.userId', 'fullName email')
      .lean();

    totalFloorCount += floors.length;

    for (const floor of floors) {
      // Count all non-deleted zones for this floor
      const zoneCount = await CampusZone.countDocuments({
        floorId: floor._id,
        $or: [
          { isDelete: { $exists: false } },
          { isDelete: false },
          { isDelete: { $ne: true } }
        ]
      });
      floor.zoneCount = zoneCount;
      totalZoneCount += zoneCount;
    }
    building.floors = floors;
  }

  campus.buildings = buildings;
  campus.buildingCount = buildings.length; // Count of non-deleted buildings
  campus.floorCount = totalFloorCount;     // Count of non-deleted floors
  campus.zoneCount = totalZoneCount;       // Count of non-deleted zones

  return campus;
};

/**
 * Soft delete campus with cascade cleanup
 * 
 * Cleanup process:
 * 1. Mark campus/buildings/floors/zones as deleted
 * 2. Move all devices to 'Discovered' state
 * 3. Remove devices from groups, scenes, templates
 * 4. Delete intelligent control data permanently
 * 5. Preserve device history for audit
 */
export const deleteCampus = async (campusId, user) => {
  if (!/^[0-9a-fA-F]{24}$/.test(campusId)) {
    throw new Error('Invalid campus ID format');
  }

  // Ensure campus exists
  const campus = await Campus.findById(campusId);
  if (!campus) throw new Error('Campus not found');

  // Import required models and functions
  const Device = (await import('../models/Device.js')).default;
  const { removeDeviceFromRelatedCollections } = await import('./device.service.js');

  // Get all buildings, floors, and zones under this campus
  const buildings = await CampusBuilding.find({ campusId });
  const buildingIds = buildings.map(b => b._id);
  
  const floors = buildingIds.length > 0 ? await CampusFloor.find({ buildingId: { $in: buildingIds } }) : [];
  const floorIds = floors.map(f => f._id);
  
  const zones = floorIds.length > 0 ? await CampusZone.find({ floorId: { $in: floorIds } }) : [];
  const zoneIds = zones.map(z => z._id);

  // Get devices in campus and move them to 'Discovered' state
  const devices = await Device.find({ campus: campusId }).select('device_id');
  
  // Update devices to 'Discovered' state (same as device deletion)
  await Device.updateMany(
    { campus: campusId },
    { 
      is_delete: false,
      configure_flag: false
    }
  );

  // Remove each device from related collections (same as device deletion)
  for (const device of devices) {
    await removeDeviceFromRelatedCollections(device.device_id, user);
  }

  // Delete zones, floors, and buildings
  if (zoneIds.length > 0) {
    await CampusZone.deleteMany({ _id: { $in: zoneIds } });
  }
  if (floorIds.length > 0) {
    await CampusFloor.deleteMany({ _id: { $in: floorIds } });
  }
  if (buildingIds.length > 0) {
    await CampusBuilding.deleteMany({ _id: { $in: buildingIds } });
  }

  // Remove campus image file(s)
  const fs = await import('fs');
  const path = await import('path');
  const extensions = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'];
  for (const ext of extensions) {
    const imageFilePath = path.resolve('public/images/campus', `${campusId}.${ext}`);
    if (fs.existsSync(imageFilePath)) {
      try { fs.unlinkSync(imageFilePath); } catch (e) { /* ignore */ }
    }
  }

  // Delete campus from MongoDB
  await Campus.deleteOne({ _id: campusId });

  return {
    success: true,
    message: 'Campus deleted successfully. All devices moved to Discovered state and intelligent control data permanently deleted.',
    campus: { _id: campusId },
    deletedCounts: {
      buildings: buildingIds.length,
      floors: floorIds.length,
      zones: zoneIds.length,
      devicesMovedToDiscovered: devices.length
    }
  };
};


// Reactivate campus and all associated data (set status to 1 for active)
export const reactivateCampus = async (campusId, user) => {
  // Validate campusId format
  if (!campusId.match(/^[0-9a-fA-F]{24}$/)) {
    throw new Error('Invalid campus ID format');
  }

  // Find the campus first to ensure it exists and is inactive
  const campus = await Campus.findById(campusId);
  if (!campus) {
    throw new Error('Campus not found');
  }

  if (campus.status === 1) {
    throw new Error('Campus is already active');
  }

  try {
    // Step 1: Reactivate the campus (set status to 1)
    const reactivatedCampus = await Campus.findByIdAndUpdate(
      campusId,
      {
        status: 1,
        updatedBy: {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        },
        updatedAt: new Date()
      },
      {
        new: true
      }
    );

    // Step 2: Get all buildings associated with this campus
    const buildings = await CampusBuilding.find({
      campusId: campusId,
      status: 0 // Only inactive buildings
    });
    const buildingIds = buildings.map(building => building._id);

    // Step 3: Reactivate all buildings associated with this campus (set status to 1)
    const reactivatedBuildings = await CampusBuilding.updateMany(
      {
        campusId: campusId,
        status: 0 // Only update inactive buildings
      },
      {
        status: 1,
        updatedBy: {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        },
        updatedAt: new Date()
      }
    );

    // Step 4: Get all floors associated with these buildings
    const floors = await CampusFloor.find({
      buildingId: { $in: buildingIds },
      status: 0 // Only inactive floors
    });
    const floorIds = floors.map(floor => floor._id);

    // Step 5: Reactivate all floors associated with these buildings (set status to 1)
    const reactivatedFloors = await CampusFloor.updateMany(
      {
        buildingId: { $in: buildingIds },
        status: 0 // Only update inactive floors
      },
      {
        status: 1,
        updatedBy: {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        },
        updatedAt: new Date()
      }
    );

    // Step 6: Reactivate all zones associated with these floors (set status to 1)
    const reactivatedZones = await CampusZone.updateMany(
      {
        floorId: { $in: floorIds },
        status: 0 // Only update inactive zones
      },
      {
        status: 1,
        updatedBy: {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        },
        updatedAt: new Date()
      }
    );

    if (!reactivatedCampus) {
      throw new Error('Failed to reactivate campus');
    }

    // Log the reactivation counts
    console.log(`Reactivation completed for campus ${campusId}:`);
    console.log(`- Reactivated ${reactivatedBuildings.modifiedCount} buildings`);
    console.log(`- Reactivated ${reactivatedFloors.modifiedCount} floors`);
    console.log(`- Reactivated ${reactivatedZones.modifiedCount} zones`);
    console.log(`- Reactivated campus: ${reactivatedCampus.name}`);

    return {
      success: true,
      reactivatedCampus: {
        _id: campus._id,
        name: campus.name,
        organization: campus.organization,
        accessId: campus.accessId,
        previousStatus: 0,
        newStatus: 1
      },
      reactivatedBy: {
        userId: user._id,
        fullName: user.fullName,
        email: user.email
      },
      reactivatedAt: new Date(),
      restoration: {
        message: 'Campus and all associated data reactivated successfully',
        note: 'This action set the status to 1 (active) for the campus and all its buildings, floors, and zones.'
      }
    };

  } catch (error) {
    console.error('Error during campus reactivation:', error);

    // Handle specific database errors
    if (error.name === 'MongoError' || error.name === 'MongoServerError') {
      throw new Error('Database error occurred during reactivation. Please try again.');
    }

    throw error;
  }
};

// Update campus status only
export const updateCampusStatus = async (campusId, status, user) => {
  // Validate campusId format
  if (!campusId.match(/^[0-9a-fA-F]{24}$/)) {
    throw new Error('Invalid campus ID format');
  }

  // Find the campus first
  const campus = await Campus.findById(campusId);
  if (!campus) {
    throw new Error('Campus not found');
  }

  try {
    const updatedCampus = await Campus.findByIdAndUpdate(
      campusId,
      {
        status,
        updatedBy: {
          userId: user._id,
          fullName: user.fullName,
          email: user.email
        },
        updatedAt: new Date()
      },
      {
        new: true,
        runValidators: true
      }
    ).populate('createdBy.userId', 'fullName email')
      .populate('updatedBy.userId', 'fullName email');

    if (!updatedCampus) {
      throw new Error('Campus not found or could not be updated');
    }

    return updatedCampus;
  } catch (error) {
    // Handle mongoose validation errors
    if (error.name === 'ValidationError') {
      const validationErrors = Object.values(error.errors).map(err => err.message);
      throw new Error(`Validation failed: ${validationErrors.join(', ')}`);
    }

    throw error;
  }
};

// Get campus view with detailed information including buildings, floors and zones
export const getCampusView = async (queryParams = {}) => {
  const {
    page = 1,
    limit = 20,
    status,
    type,
    organization,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc'
  } = queryParams;

  // Build filter object
  const filter = {};

  // Always filter for active records only (status = 1) unless specifically overridden
  filter.status = status !== undefined ? status : 1;

  if (type) {
    filter.type = type;
  }

  if (organization) {
    filter.organization = { $regex: organization, $options: 'i' };
  }

  // Enhanced search functionality
  if (search) {
    filter.$or = [
      { name: { $regex: search, $options: 'i' } },
      { location: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } },
      { accessId: { $regex: search, $options: 'i' } }
    ];
  }

  // Calculate skip value for pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);

  // Get sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // Execute query to get campuses
  const campuses = await Campus.find(filter)
    .sort(sort)
    .skip(skip)
    .limit(parseInt(limit))
    .lean();

  // Get total count for pagination
  const total = await Campus.countDocuments(filter);

  // For each campus, get detailed building, floor, and zone information
  const campusViews = [];

  for (const campus of campuses) {
    // Get all buildings for this campus
    const buildings = await CampusBuilding.find({
      campusId: campus._id
    }).lean();

    if (buildings.length === 0) {
      // If no buildings, still show campus info
      campusViews.push({
        campusId: campus._id,
        campusName: campus.name,
        campusLocation: campus.location,
        campusType: campus.type,
        campusStatus: campus.status === 1 ? 'Active' : 'Inactive',
        campusAccessId: campus.accessId,
        campusOrganization: campus.organization,
        campusCreatedAt: campus.createdAt,
        buildingName: null,
        buildingStatus: null,
        floorLevel: null,
        floorStatus: null,
        zoneName: null,
        zoneType: null,
        zoneAddedOn: null,
        zoneStatus: null
      });
    } else {
      // Process each building
      for (const building of buildings) {
        // Get all floors for this building
        const floors = await CampusFloor.find({
          buildingId: building._id
        }).lean();

        if (floors.length === 0) {
          // If no floors, show building info without floor/zone details
          campusViews.push({
            campusId: campus._id,
            campusName: campus.name,
            campusLocation: campus.location,
            campusType: campus.type,
            campusStatus: campus.status === 1 ? 'Active' : 'Inactive',
            campusAccessId: campus.accessId,
            campusOrganization: campus.organization,
            campusCreatedAt: campus.createdAt,
            buildingName: building.name,
            buildingStatus: building.status === 1 ? 'Active' : 'Inactive',
            floorLevel: null,
            floorStatus: null,
            zoneName: null,
            zoneType: null,
            zoneAddedOn: null,
            zoneStatus: null
          });
        } else {
          // Process each floor
          for (const floor of floors) {
            // Get all zones for this floor
            const zones = await CampusZone.find({
              floorId: floor._id
            }).lean();

            if (zones.length === 0) {
              // If no zones, show floor info without zone details
              campusViews.push({
                campusId: campus._id,
                campusName: campus.name,
                campusLocation: campus.location,
                campusType: campus.type,
                campusStatus: campus.status === 1 ? 'Active' : 'Inactive',
                campusAccessId: campus.accessId,
                campusOrganization: campus.organization,
                campusCreatedAt: campus.createdAt,
                buildingName: building.name,
                buildingStatus: building.status === 1 ? 'Active' : 'Inactive',
                floorLevel: floor.floorLevel,
                floorStatus: floor.status === 1 ? 'Active' : 'Inactive',
                zoneName: null,
                zoneType: null,
                zoneAddedOn: null,
                zoneStatus: null
              });
            } else {
              // Process each zone
              for (const zone of zones) {
                campusViews.push({
                  campusId: campus._id,
                  campusName: campus.name,
                  campusLocation: campus.location,
                  campusType: campus.type,
                  campusStatus: campus.status === 1 ? 'Active' : 'Inactive',
                  campusAccessId: campus.accessId,
                  campusOrganization: campus.organization,
                  campusCreatedAt: campus.createdAt,
                  buildingName: building.name,
                  buildingStatus: building.status === 1 ? 'Active' : 'Inactive',
                  floorLevel: floor.floorLevel,
                  floorStatus: floor.status === 1 ? 'Active' : 'Inactive',
                  zoneName: zone.name,
                  zoneType: zone.type,
                  zoneAddedOn: zone.createdAt,
                  zoneStatus: zone.status === 1 ? 'Active' : 'Inactive'
                });
              }
            }
          }
        }
      }
    }
  }

  return {
    campusViews,
    pagination: {
      currentPage: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit)),
      totalCampuses: total,
      totalRecords: campusViews.length,
      hasNextPage: skip + campuses.length < total,
      hasPrevPage: parseInt(page) > 1
    },
    searchInfo: {
      searchTerm: search || null,
      resultsFound: campusViews.length,
      totalCampusesMatched: total
    }
  };
};

// Get all active campuses only (status = 1) - filtered by user's campusData
export const getActiveCampuses = async (queryParams = {}) => {
  const {
    page = 1,
    limit = 20,
    type,
    organization,
    search,
    name,
    location,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    userFilter
  } = queryParams;

  // Start with user filter if provided, otherwise build base filter
  // Always filter for campuses in allowedResources.campusManagement.campuses (intersection with campusData)
  let filter;
  if (userFilter) {
    filter = { ...userFilter };
    if (!filter.$and) filter.$and = [];
    filter.$and.push({ status: 1 });
  } else {
    // If no userFilter, restrict to active and non-deleted
    filter = {
      $and: [
        { $or: [{ isDelete: { $exists: false } }, { isDelete: { $ne: true } }] },
        { status: 1 }
      ]
    };
  }

  if (type) {
    if (!filter.$and) filter.$and = [];
    filter.$and.push({ type });
  }

  if (organization) {
    if (!filter.$and) filter.$and = [];
    filter.$and.push({ organization: { $regex: organization, $options: 'i' } });
  }

  // Enhanced search functionality
  const searchConditions = [];

  // General search across multiple fields
  if (search) {
    searchConditions.push({
      $or: [
        { name: { $regex: search, $options: 'i' } },
        { location: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { accessId: { $regex: search, $options: 'i' } }
      ]
    });
  }

  // Specific name search
  if (name) {
    searchConditions.push({
      name: { $regex: name, $options: 'i' }
    });
  }

  // Specific location search
  if (location) {
    searchConditions.push({
      location: { $regex: location, $options: 'i' }
    });
  }

  // Apply search conditions - need to merge with existing $and conditions
  if (searchConditions.length > 0) {
    if (!filter.$and) filter.$and = [];
    filter.$and.push(...searchConditions);
  }

  // Calculate skip value for pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);

  // Get sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // Execute query with pagination
  const campuses = await Campus.find(filter)
    .select('_id name')
    .sort(sort)
    .skip(skip)
    .limit(parseInt(limit))
    .lean();

  // Get total count for pagination
  const total = await Campus.countDocuments(filter);

  return {
    activeCampuses: campuses,
    pagination: {
      currentPage: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit)),
      totalActiveCampuses: total,
      hasNextPage: skip + campuses.length < total,
      hasPrevPage: parseInt(page) > 1
    },
    searchInfo: {
      searchTerm: search || null,
      nameFilter: name || null,
      locationFilter: location || null,
      resultsFound: campuses.length,
      totalMatches: total
    }
  };
};

/**
 * Get available campus types for dropdown selection
 * Static list of predefined campus categories
 */
export const getCampusTypes = () => {
  return [
    "Residential Apartment",
    "Commercial",
    "Hotel & Resort"
  ];
};
