/**
 * Middleware collection for the Smart Axiom MPS API
 * Contains authentication, authorization, validation, encryption, and rate limiting middleware
 */

// External dependencies
import jwt from 'jsonwebtoken';
import rateLimit from 'express-rate-limit';

// Internal dependencies
import { User } from '../models/User.js';
import { UserAuth } from '../models/UserAuth.js';
import { getConfig } from '../config/env.js';
import { aesEncrypt, aesDecrypt } from '../config/crypto.js';

// =====================
// AUTHENTICATION MIDDLEWARE
// =====================

/**
 * Authentication middleware to protect routes
 * Validates JWT tokens and ensures user session is active
 * Supports multi-device login by tracking active sessions in UserAuth collection
 * 
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
export const protect = async (req, res, next) => {
  try {
    // Step 1: Extract Bearer token from Authorization header
    let token;
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }

    // Return error if no token provided
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Access denied. No token provided.'
      });
    }

    // Step 2: Verify JWT token signature and decode payload
    const decoded = jwt.verify(token, getConfig().jwt.secret);

    // Step 3: Verify user still exists and populate role information
    const user = await User.findById(decoded.sub).populate('role_id', 'roleName permissions isActive');
    // Return error if user no longer exists
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'The user belonging to this token no longer exists.'
      });
    }

    // Step 4: Multi-device login support - validate session via UserAuth collection
    // Note: We don't check user.token to allow multiple concurrent sessions

    // Step 5: Find the active session for this specific token
    const userAuth = await UserAuth.findOne({ 
      userId: user._id, 
      jwtToken: token,
      status: 'active' 
    });

    if (!userAuth) {
      return res.status(401).json({
        success: false,
        message: 'Token has been deactivated or is invalid.'
      });
    }

    // 6. Check if token has expired
    if (userAuth.expiry && new Date() > userAuth.expiry) {
      // Mark as expired
      await UserAuth.findByIdAndUpdate(userAuth._id, { 
        status: 'expired',
        updatedOn: new Date()
      });
      
      return res.status(401).json({
        success: false,
        message: 'Token has expired.'
      });
    }

    // 7. Update last use timestamp
    await UserAuth.findByIdAndUpdate(userAuth._id, {
      lastUse: new Date(),
      updatedOn: new Date()
    });

    // 8. Grant access to protected route
    req.user = user;
    req.userAuth = userAuth;
    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        message: 'Invalid token.'
      });
    }
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Token has expired.'
      });
    }
    return res.status(401).json({
      success: false,
      message: 'Token verification failed.'
    });
  }
};// Middleware to check user roles
export const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Access denied. Please authenticate first.'
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Access denied. Required role: ${roles.join(' or ')}`
      });
    }

    next();
  };
};

// =====================
// VALIDATION MIDDLEWARE
// =====================

/**
 * Request body validation middleware using Joi schemas
 * Validates and sanitizes request body data
 * 
 * @param {Object} schema - Joi validation schema
 * @returns {Function} Express middleware function
 */
export const validate = (schema) => (req, res, next) => {
  const { error, value } = schema.validate(req.body, { abortEarly: false, stripUnknown: true });
  if (error) {
    return res.status(422).json({ 
      message: 'Validation failed', 
      details: error.details.map(d => d.message) 
    });
  }
  req.body = value; // Replace body with validated/sanitized data
  next();
};

/**
 * URL parameters validation middleware using Joi schemas
 * Validates and sanitizes route parameters (e.g., :id, :userId)
 * 
 * @param {Object} schema - Joi validation schema
 * @returns {Function} Express middleware function
 */
export const validateParams = (schema) => (req, res, next) => {
  const { error, value } = schema.validate(req.params, { abortEarly: false, stripUnknown: true });
  if (error) {
    return res.status(422).json({ 
      message: 'Parameter validation failed', 
      details: error.details.map(d => d.message) 
    });
  }
  req.params = value; // Replace params with validated data
  next();
};

/**
 * Query string validation middleware using Joi schemas
 * Validates and sanitizes query parameters (e.g., ?page=1&limit=10)
 * 
 * @param {Object} schema - Joi validation schema
 * @returns {Function} Express middleware function
 */
export const validateQuery = (schema) => (req, res, next) => {
  const { error, value } = schema.validate(req.query, { abortEarly: false, stripUnknown: true });
  if (error) {
    return res.status(422).json({ 
      message: 'Query validation failed', 
      details: error.details.map(d => d.message) 
    });
  }
  req.query = value; // Replace query with validated data
  next();
};

// =====================
// ENCRYPTION MIDDLEWARE
// =====================

/**
 * Request payload decryption middleware
 * If client sends header `x-encrypted: 1`, expects body: { encrypted: "<iv.tag.ct>" }
 * Replaces req.body with the decrypted JSON object
 * 
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
export const decryptPayload = (req, res, next) => {
  try {
    const encrypted = req.headers['x-encrypted'] == '1';
    if (encrypted) {
      const payload = req.body?.encrypted;
      if (!payload) return res.status(400).json({ message: 'Missing encrypted payload' });
      req.body = aesDecrypt(payload);
    }
    return next();
  } catch (err) {
    return res.status(400).json({ message: 'Invalid encrypted payload', detail: err.message });
  }
};

/**
 * Response encryption middleware
 * If client sends header `x-accept-encrypted: 1`, wraps JSON responses
 * as { encrypted: "<iv.tag.ct>" } using AES-256-GCM encryption
 * 
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
export const encryptResponse = (req, res, next) => {
  const wantsEncrypted = req.headers['x-accept-encrypted'] == '1';
  const skipEncryption = res.getHeader('x-skip-encryption') == '1';

  if (!wantsEncrypted || skipEncryption) return next();

  const originalJson = res.json.bind(res);
  res.json = (data) => {
    const encrypted = aesEncrypt(data);
    return originalJson({ encrypted });
  };
  next();
};

// =====================
// RATE LIMITING MIDDLEWARE
// =====================

/**
 * Rate limiting middleware for authentication routes
 * Prevents brute force attacks by limiting requests per IP
 * Allows 100 requests per 10-minute window
 */
export const authLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, // 10 minutes
  limit: 100, // Maximum 100 requests per window
  standardHeaders: true, // Include rate limit info in response headers
  legacyHeaders: false // Don't include legacy X-RateLimit headers
  // Trust proxy setting should match Express app configuration
  // In production behind a proxy/load balancer, this should be properly configured
  // trustProxy: process.env.NODE_ENV === 'production' ? 1 : false
});

// =====================
// ERROR HANDLING MIDDLEWARE
// =====================

/**
 * 404 Not Found middleware for undefined routes
 * Should be placed after all route definitions
 */
export const notFound = (req, res) => res.status(404).json({ message: 'Route not found' });

/**
 * Global error handling middleware
 * Catches all unhandled errors and returns appropriate response
 * Should be the last middleware in the chain
 */
export const errorHandler = (err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return; // Response already sent
  res.status(err.status || 500).json({ message: err.message || 'Internal Server Error' });
};
