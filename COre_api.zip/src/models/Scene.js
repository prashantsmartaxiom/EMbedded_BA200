
/**
 * Scene Model
 * Represents lighting and device control scenes for coordinated automation
 * Supports both device-based and group-based scenes with complex channel configurations
 * Handles LED brightness control, shade positioning, and scene execution tracking
 */

import mongoose from 'mongoose';

// Schema for individual device channels within a scene
const ChannelSchema = new mongoose.Schema({
  // Type of channel (led, shade, sensor)
  channelType: { type: String, required: true },
  // Unique identifier for the channel within its device
  channelId:   { type: String, required: true },
  // Command to execute (on/off for LEDs, open/close for shades)
  command:     { type: String, required: true },
  // Brightness level for LED channels (0-100, used when channelType='led')
  brightness:  { type: Number, min: 0, max: 100 },
  // Open level for shade channels (0-100, used when channelType='shade')
  openLevel:   { type: Number, min: 0, max: 100 }
}, { _id: false }); // Disable _id for embedded subdocuments

// Schema for device entries within a scene
const DeviceEntrySchema = new mongoose.Schema({
  // Device identifier
  deviceId: { type: String, required: true, trim: true },
  // Array of channels from this device included in the scene
  channels: { type: [ChannelSchema], required: true }
}, { _id: false }); // Disable _id for embedded subdocuments

// Schema for group entries within a scene
const GroupEntrySchema = new mongoose.Schema({
  // Reference to a device group
  groupId: { type: mongoose.Schema.Types.ObjectId, ref: 'Group', required: true },
  // Array of devices and their channels from the group
  devices: { type: [DeviceEntrySchema], required: true }
}, { _id: false }); // Disable _id for embedded subdocuments

// Main scene schema for lighting and device automation
const SceneSchema = new mongoose.Schema({
  // Human-readable scene name
  name:  { type: String, required: true, trim: true },
  // Scene type: 'device' for individual devices, 'group' for device groups
  type:  { type: String, enum: ['device', 'group'], required: true },

  // Device configurations (present when type="device")
  // Note: Capitalized field names match API specification
  Devices: { type: [DeviceEntrySchema], default: undefined },
  // Group configurations (present when type="group")
  Groups:  { type: [GroupEntrySchema],  default: undefined },

  // ISO timestamp string of last scene execution
  lastExecuted: { type: String, default: null },
  // User ID who last executed this scene
  executedBy:   { type: String, default: null },
  // Operation type: 'normal' for standard execution, 'invert' for opposite action
  operateType: {
    type: String,
    enum: ['invert', 'normal'],
    default: 'normal',
    required: true
  },
  
  // Scene activation status (1 = active, 0 = inactive)
  status: { 
    type: Number, 
    enum: [0, 1], 
    default: 1,
    required: true 
  },

  // Flag for invert scene operations
  invert_flag: {
    type: Boolean,
    default: false
  },
  
  // Soft delete flag (true = deleted, false = active)
  isDeleted: { 
    type: Boolean, 
    default: false, 
    index: true 
  },
  // Timestamp when scene was deleted
  deletedAt: {
    type: Date,
    default: null
  },
  // User who deleted this scene (audit trail)
  deletedBy: {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    fullName: { type: String },
    email: { type: String }
  },
  
  // User who created this scene (audit trail)
  createdBy: {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    fullName: { type: String, required: true },
    email: { type: String, required: true }
  },
  // User who last updated this scene (audit trail)
  updatedBy: {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    fullName: { type: String },
    email: { type: String }
  },

}, { 
  timestamps: true, // Automatically add createdAt and updatedAt
  toJSON: { virtuals: true }, // Include virtual fields in JSON output
  toObject: { virtuals: true } // Include virtual fields in object output
});

// Database index for fast scene name lookups
SceneSchema.index({ name: 1 });

// Export the Scene model for use in controllers and services
export const Scene = mongoose.model('Scene', SceneSchema);
