/**
 * CampusBuilding Model
 * Represents buildings within a campus in the hierarchical structure
 * Each building belongs to a campus and contains multiple floors
 * Tracks building metadata, floor count, and organizational information
 */

import mongoose from 'mongoose';

// Schema definition for campus buildings
const campusBuildingSchema = new mongoose.Schema(
  {
    // Building display name
    name: {
      type: String,
      required: [true, 'Building name is required'],
      trim: true,
      maxlength: [100, 'Building name cannot exceed 100 characters']
    },
    // Building operational status (1 = active, 0 = inactive)
    status: {
      type: Number,
      enum: [0, 1], // 0 = inactive, 1 = active
      default: 1
    },
    // Reference to the parent campus
    campusId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Campus',
      required: [true, 'Campus ID is required']
    },
    // Soft delete flag (true = deleted, false = active)
    isDelete: { type: Boolean, default: false, index: true },
    // Building category/purpose (flexible enum)
    type: {
      type: String,
      required: [true, 'Building type is required'],
      // Enum commented out for flexibility across different campus types
      // enum: ['academic', 'administrative', 'residential', 'recreational', 'parking', 'utility', 'other'],
      trim: true
    },
    // Optional detailed description of the building
    description: {
      type: String,
      trim: true,
      maxlength: [500, 'Description cannot exceed 500 characters']
    },
    // URL or path to building image/photo
    buildingImage: {
      type: String,
      default: ''
    },
    // Array of floor references within this building
    floors: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CampusFloor'
    }],
    // Expected or planned number of floors (can differ from actual floor count)
    floor_count: {
      type: Number,
      min: [1, 'Floor count must be at least 1'],
      max: [100, 'Floor count cannot exceed 100'],
      default: null
    },
    createdAt: {
      type: Date,
      default: Date.now
    },
    updatedAt: {
      type: Date,
      default: Date.now
    },
    createdBy: {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
      fullName: { type: String, required: true },
      email: { type: String, required: true }
    },
    updatedBy: {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      fullName: { type: String },
      email: { type: String }
    }
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
  }
);

// Database indexes for optimized query performance
// Fast lookups by parent campus
campusBuildingSchema.index({ campusId: 1 });
// Filter by building status
campusBuildingSchema.index({ status: 1 });
// Filter by building type
campusBuildingSchema.index({ type: 1 });

// Virtual property to get actual floor count from floors array
campusBuildingSchema.virtual('floorCount').get(function () {
  return this.floors ? this.floors.length : 0;
});

// Middleware to automatically update the updatedAt timestamp on save
campusBuildingSchema.pre('save', function (next) {
  this.updatedAt = new Date();
  next();
});

// Export the CampusBuilding model for use in controllers and services
export const CampusBuilding = mongoose.model('CampusBuilding', campusBuildingSchema);
