/**
 * CampusFloor Model
 * Represents floors within buildings in the hierarchical structure
 * Each floor belongs to a building and contains multiple zones
 * Handles floor numbering, status management, and soft deletion
 */

import mongoose from 'mongoose';

// Schema definition for campus floors
const campusFloorSchema = new mongoose.Schema(
  {
    // Floor display name
    name: {
      type: String,
      required: [true, 'Floor name is required'],
      trim: true,
      maxlength: [100, 'Floor name cannot exceed 100 characters']
    },
    // Floor operational status with flexible input handling
    status: {
      type: Number,
      enum: [0, 1], // 0 = inactive, 1 = active
      default: 1,
      // Custom setter to handle various input formats
      set: function (value) {
        // Convert string values to numbers for consistent storage
        if (typeof value === 'string') {
          if (value === 'active') return 1;
          if (value === 'inactive') return 0;
          // Handle string numbers from form inputs
          if (value === '1') return 1;
          if (value === '0') return 0;
        }
        return value;
      }
    },
    // Primary soft delete flag (consistent with other models)
    isDelete: { type: Boolean, default: false, index: true },
    // Secondary deletion flag (legacy/redundant)
    deleted: {
      type: Boolean,
      default: false
    },
    // Timestamp when floor was deleted
    deletedAt: {
      type: Date,
      default: null
    },
    // User who deleted this floor (audit trail)
    deletedBy: {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      fullName: { type: String },
      email: { type: String }
    },
    // Floor identifier/number (e.g., "1", "2", "B1", "Ground")
    floorLevel: {
      type: String,
      required: [true, 'Floor level is required'],
      trim: true,
      maxlength: [20, 'Floor level cannot exceed 20 characters']
    },
    // Reference to the parent building
    buildingId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CampusBuilding',
      required: [true, 'Building ID is required']
    },
    description: {
      type: String,
      trim: true,
      maxlength: [500, 'Description cannot exceed 500 characters']
    },
    floorImage: {
      type: String,
      default: ''
    },
    zones: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CampusZone'
    }],
    createdAt: {
      type: Date,
      default: Date.now
    },
    updatedAt: {
      type: Date,
      default: Date.now
    },
    createdBy: {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
      fullName: { type: String, required: true },
      email: { type: String, required: true }
    },
    updatedBy: {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      fullName: { type: String },
      email: { type: String }
    }
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
  }
);

// Index for better query performance
campusFloorSchema.index({ buildingId: 1 });
campusFloorSchema.index({ status: 1 });
campusFloorSchema.index({ floorLevel: 1 });
// campusFloorSchema.index({ isDelete: 1 });

// Virtual for zone count
campusFloorSchema.virtual('zoneCount').get(function () {
  return this.zones ? this.zones.length : 0;
});

// Middleware to automatically update the updatedAt timestamp on save
campusFloorSchema.pre('save', function (next) {
  this.updatedAt = new Date();
  next();
});

// Export the CampusFloor model for use in controllers and services
export const CampusFloor = mongoose.model('CampusFloor', campusFloorSchema);
