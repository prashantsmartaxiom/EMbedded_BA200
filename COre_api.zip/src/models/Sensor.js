
/**
 * Sensor Model
 * Represents motion sensor configurations and automation rules
 * Links sensor events to scene executions for automated lighting control
 * Handles motion detection triggers and duration-based scene switching
 */

import mongoose from 'mongoose';

// Schema for sensor event automation configuration
const sensorSchema = new mongoose.Schema({
  // Type of sensor event (e.g., 'motion_detected', 'no_motion')
  sensorEvent: {
    type: String,
    required: true,
    trim: true
  },
  // Device identifier containing the sensor
  device: {
    type: String,
    required: true,
    trim: true
  },
  // Array of sensor channel IDs within the device
  sensor: [{
    type: String,
    required: true,
    trim: true
  }],
  // Optional group identifier for sensor grouping
  sensorGroupId: {
    type: String
  },
  // Scene to execute when motion is detected
  motionScene: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Scene',
    required: true
  },
  // Scene to execute when no motion is detected
  NoMotionScene: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Scene',
    required: true
  },
  // Duration in seconds before triggering no-motion scene
  Trigger_duration: {
    type: Number,
    required: true,
    min: 0
  },
  // Current operational status of the sensor automation
  status: {
    type: String,
    enum: ['Active', 'Inactive'],
    default: 'Active'
  },
  // User who created this sensor configuration (audit trail)
  createdBy: {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    fullName: {
      type: String,
      required: true
    },
    email: {
      type: String,
      required: true
    }
  },
  // User who last updated this sensor configuration (audit trail)
  updatedBy: {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    fullName: {
      type: String
    },
    email: {
      type: String
    }
  },
  // Soft delete flag (true = deleted, false = active)
  isDelete: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true // Automatically add createdAt and updatedAt
});

// Database indexes for optimized query performance
// Compound index for device and sensor event filtering
sensorSchema.index({ device: 1, sensorEvent: 1 });
// Filter by sensor status
sensorSchema.index({ status: 1 });
// Filter by deletion status
sensorSchema.index({ isDelete: 1 });

// Export the Sensor model for use in controllers and services
export const Sensor = mongoose.model('Sensor', sensorSchema);
