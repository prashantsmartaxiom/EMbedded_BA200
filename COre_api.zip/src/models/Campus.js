/**
 * Campus Model
 * Represents the top-level entity in the hierarchical structure: Campus -> Building -> Floor -> Zone
 * A campus is a physical location containing multiple buildings for an organization
 * Supports different campus types (Residential, Commercial, Hotel & Resort)
 */

import mongoose from 'mongoose';

// Schema definition for campus entities
const campusSchema = new mongoose.Schema(
  {
    // Campus display name
    name: {
      type: String,
      required: [true, 'Campus name is required'],
      trim: true,
      maxlength: [100, 'Campus name cannot exceed 100 characters']
    },
    // Campus operational status (1 = active, 0 = inactive)
    status: {
      type: Number,
      enum: [0, 1], // 0 = inactive, 1 = active
      default: 1
    },
    // Unique access identifier (auto-generated if not provided)
    accessId: {
      type: String,
      trim: true
    },
    // Physical address or location description
    location: {
      type: String,
      required: [true, 'Campus location is required'],
      trim: true,
      maxlength: [200, 'Location cannot exceed 200 characters']
    },
    // Campus category/type for business classification
    type: {
      type: String,
      required: [true, 'Campus type is required'],
      enum: ["Residential Apartment", "Commercial", "Hotel & Resort"],
      trim: true
    },
    // Optional detailed description of the campus
    description: {
      type: String,
      trim: true,
      maxlength: [500, 'Description cannot exceed 500 characters']
    },
    // URL or path to campus image/photo
    campusImage: {
      type: String,
      default: ''
    },
    // Organization that owns/manages this campus
    organization: {
      type: String,
      required: [true, 'Organization is required'],
      trim: true
    },
    // Array of building references within this campus
    buildings: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CampusBuilding'
    }],
    // Timestamp when campus was created
    createdAt: {
      type: Date,
      default: Date.now
    },
    // Timestamp when campus was last updated
    updatedAt: {
      type: Date,
      default: Date.now
    },
    // User who created this campus (audit trail)
    createdBy: {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
      fullName: { type: String, required: true },
      email: { type: String, required: true }
    },
    // User who last updated this campus (audit trail)
    updatedBy: {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      fullName: { type: String },
      email: { type: String }
    },
    // Soft delete flag (true = deleted, false = active)
    isDelete: { type: Boolean, default: false, index: true }
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
  }
);

// Database indexes for optimized query performance
// Single field indexes for common filters
campusSchema.index({ organization: 1 });
campusSchema.index({ status: 1 });
campusSchema.index({ type: 1 });
// Full-text search index for name, location, and description
campusSchema.index({ name: 'text', location: 'text', description: 'text' });
// Compound indexes for common query combinations
campusSchema.index({ name: 1, status: 1 });
campusSchema.index({ location: 1, status: 1 });
campusSchema.index({ organization: 1, status: 1 });

// Virtual property to get building count without populating buildings array
campusSchema.virtual('buildingCount').get(function () {
  return this.buildings ? this.buildings.length : 0;
});

// Middleware to automatically update the updatedAt timestamp on save
campusSchema.pre('save', function (next) {
  this.updatedAt = new Date();
  next();
});

// Middleware to auto-generate unique accessId for new campuses
campusSchema.pre('save', async function (next) {
  if (this.isNew && !this.accessId) {
    // Find the campus with the highest numerical accessId
    const lastCampus = await this.constructor.findOne({ accessId: /^CAMPUS_\d{4}$/ })
      .sort({ accessId: -1 })
      .lean();
    let nextNumber = 1;
    if (lastCampus && lastCampus.accessId) {
      // Extract number from format CAMPUS_0001
      const match = lastCampus.accessId.match(/CAMPUS_(\d{4})/);
      if (match) {
        nextNumber = parseInt(match[1], 10) + 1;
      }
    }
    // Generate accessId with zero-padded 4-digit number
    this.accessId = `CAMPUS_${String(nextNumber).padStart(4, '0')}`;
  }
  next();
});

// Export the Campus model for use in controllers and services
export const Campus = mongoose.model('Campus', campusSchema);