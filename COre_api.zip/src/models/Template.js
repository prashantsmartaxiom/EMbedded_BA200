/**
 * Template Model
 * Represents UI layout templates for dashboard widget arrangements
 * Defines grid-based layouts with rows, columns, and structural configurations
 * Used for creating reusable dashboard layouts across different user interfaces
 */

import mongoose from 'mongoose';

// Schema for dashboard layout templates
const templateSchema = new mongoose.Schema(
  {
    // Human-readable template name
    name: {
      type: String,
      required: [true, 'Template name is required'],
      trim: true,
      maxlength: [100, 'Template name cannot exceed 100 characters']
    },
    // Layout type or identifier
    layout: {
      type: String,
      required: [true, 'Layout is required'],
      trim: true,
      maxlength: [100, 'Layout cannot exceed 100 characters']
    },
    // Current status of the template (active, inactive, draft)
    status: {
      type: String,
      required: [true, 'Status is required'],
      trim: true,
      maxlength: [20, 'Status cannot exceed 20 characters']
    },
    // Number of rows in the grid layout
    rows: {
      type: Number,
    },
    // Number of columns in the grid layout
    columns: {
      type: Number,
      // Note: trim and maxlength don't apply to Number types
    },
    // Complex layout structure object containing widget positions and configurations
    layoutStructure: {
      type: Object,
      default: ''
    }
  },
  {
    timestamps: true, // Automatically add createdAt and updatedAt
    toJSON: { virtuals: true }, // Include virtual fields in JSON output
    toObject: { virtuals: true } // Include virtual fields in object output
  }
);

// Database indexes for optimized query performance
// Fast lookups by template name
templateSchema.index({ name: 1 });
// Filter by template status
templateSchema.index({ status: 1 });

// Pre-save middleware to ensure updatedAt is current
// Note: This is redundant with timestamps: true option
templateSchema.pre('save', function (next) {
  this.updatedAt = new Date();
  next();
});

// Export the Template model for use in controllers and services
export const Template = mongoose.model('Template', templateSchema);
