/**
 * CampusZone Model
 * Represents the lowest level in the hierarchical structure: Campus -> Building -> Floor -> Zone
 * Zones are functional areas within floors where devices are deployed
 * Supports different zone types (classroom, office, laboratory, etc.)
 */

import mongoose from 'mongoose';

// Schema definition for campus zones
const campusZoneSchema = new mongoose.Schema(
  {
    // Zone display name
    name: {
      type: String,
      required: [true, 'Zone name is required'],
      trim: true,
      maxlength: [100, 'Zone name cannot exceed 100 characters']
    },
    // Zone operational status (1 = active, 0 = inactive)
    status: {
      type: Number,
      enum: [0, 1], // 0 = inactive, 1 = active
      default: 1
    },
    // Soft delete flag (true = deleted, false = active)
    isDelete: { 
      type: Boolean, 
      default: false, 
      index: true
    },
    // Timestamp when zone was deleted
    deletedAt: {
      type: Date,
      default: null
    },
    // User who deleted this zone (audit trail)
    deletedBy: {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      fullName: { type: String },
      email: { type: String }
    },
    // Reference to the parent floor
    floorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CampusFloor',
      required: [true, 'Floor ID is required']
    },
    // Functional category of the zone
    type: {
      type: String,
      enum: ['classroom', 'laboratory', 'office', 'meeting-room', 'library', 'cafeteria', 'restroom', 'corridor', 'lobby', 'other'],
      default: 'other',
      trim: true
    },
    // Optional detailed description of the zone
    description: {
      type: String,
      trim: true,
      maxlength: [500, 'Description cannot exceed 500 characters']
    },
    // URL or path to zone image/photo
    zoneImage: {
      type: String,
      default: ''
    },
    // Array of device references deployed in this zone
    devices: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Device' // References the Device model for IoT device management
    }],
    createdAt: {
      type: Date,
      default: Date.now
    },
    updatedAt: {
      type: Date,
      default: Date.now
    },
    createdBy: {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
      fullName: { type: String, required: true },
      email: { type: String, required: true }
    },
    updatedBy: {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      fullName: { type: String },
      email: { type: String }
    }
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
  }
);

// Database indexes for optimized query performance
// Fast lookups by parent floor
campusZoneSchema.index({ floorId: 1 });
// Filter by zone operational status
campusZoneSchema.index({ status: 1 });
// Filter by zone functional type
campusZoneSchema.index({ type: 1 });
// Soft delete index is handled by the field definition

// Virtual property to get device count without populating devices array
campusZoneSchema.virtual('deviceCount').get(function () {
  return this.devices ? this.devices.length : 0;
});

// Middleware to automatically update the updatedAt timestamp on save
campusZoneSchema.pre('save', function (next) {
  this.updatedAt = new Date();
  next();
});

// Export the CampusZone model for use in controllers and services
export const CampusZone = mongoose.model('CampusZone', campusZoneSchema);
