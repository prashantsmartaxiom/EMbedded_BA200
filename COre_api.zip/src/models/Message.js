/**
 * Message Model
 * Represents MQTT messages and communication data
 * Stores control topics, message payloads, and timestamps for device communication
 * Used for tracking MQTT message flow and debugging communication issues
 */

import mongoose from 'mongoose';

// Schema for MQTT message storage and tracking
const messageSchema = new mongoose.Schema({
  // Unique identifier for the message
  id: {
    type: String,
    required: true,
    trim: true
  },
  // MQTT topic for device control commands
  control_topic: {
    type: String,
    required: true,
    trim: true
  },
  // Flexible message payload (can be JSON object, string, or other formats)
  message: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  }
}, {
  timestamps: true, // Automatically add createdAt and updatedAt
  collection: 'messages' // Explicitly specify the collection name
});

// Export the Message model for use in controllers and services
const Message = mongoose.model('Message', messageSchema);

export default Message;
