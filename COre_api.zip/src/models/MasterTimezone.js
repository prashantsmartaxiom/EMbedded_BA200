/**
 * MasterTimezone Model
 * Manages timezone definitions for the Smart Axiom MPS system
 * Stores timezone names, values, and their activation status
 * Used for scheduling, logging, and display purposes across different geographic locations
 */

import mongoose from 'mongoose';

const { Schema } = mongoose;

// Schema for timezone master data management
const masterTimezoneSchema = new Schema(
  {
    // Human-readable timezone name (e.g., "Eastern Time", "Pacific Time")
    timeZoneName: { 
      type: String, 
      required: true, 
      trim: true,
      unique: true // Ensure no duplicate timezone names
    },
    // Timezone identifier/value (e.g., "America/New_York", "UTC-5")
    timeZoneValue: { 
      type: String, 
      required: true, 
      trim: true 
    },
    // Whether this timezone is currently active/available for use
    isActive: { 
      type: Boolean, 
      default: false 
    },
    // Soft delete flag (true = deleted, false = active)
    isDeleted: { 
      type: Boolean, 
      default: false 
    },
    // Flag indicating if timezone has been added to the system
    is_added: {
      type: Boolean,
      default: false
    },
    // User who created this timezone entry (audit trail)
    createdBy: {
      userId: { type: Schema.Types.ObjectId },
      fullName: { type: String },
      email: { type: String }
    },
    // User who last updated this timezone entry (audit trail)
    updatedBy: {
      userId: { type: Schema.Types.ObjectId },
      fullName: { type: String },
      email: { type: String }
    },
    // User who deleted this timezone entry (audit trail)
    deletedBy: {
      userId: { type: Schema.Types.ObjectId },
      fullName: { type: String },
      email: { type: String }
    },
    // ISO string representation of creation date
    createdDate: { 
      type: String, 
      default: () => new Date().toISOString() 
    },
    // ISO string representation of last update date
    updatedDate: { type: String },
    // ISO string representation of deletion date
    deletedDate: { type: String }
  },
  { timestamps: true } // Automatically add createdAt and updatedAt
);

// Database indexes for optimized query performance
// Fast lookups by timezone name
masterTimezoneSchema.index({ timeZoneName: 1 });
// Fast lookups by timezone value/identifier
masterTimezoneSchema.index({ timeZoneValue: 1 });
// Filter by deletion status
masterTimezoneSchema.index({ isDeleted: 1 });
// Filter by active status
masterTimezoneSchema.index({ isActive: 1 });
// Filter by addition status
masterTimezoneSchema.index({ is_added: 1 });

// Export the MasterTimezone model for use in controllers and services
export const MasterTimezone = mongoose.model('MasterTimezone', masterTimezoneSchema);