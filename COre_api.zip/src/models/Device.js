/**
 * Device Model
 * Represents IoT devices deployed throughout the campus infrastructure
 * Handles device identification, capabilities, location tracking, and port configurations
 * Supports various device types (dimmers, switches, sensors) with flexible capability definitions
 */

import mongoose from 'mongoose';

// Schema for individual device capabilities (LED, shade, sensor channels)
const capabilitySchema = new mongoose.Schema({
  // Type of capability (led, shade, sensor)
  type: {
    type: String,
    required: true,
  },
  // Unique identifier for this channel within the device
  channelId: {
    type: String,
    required: true
  },
  // Human-readable name for this capability
  name: {
    type: String,
    required: true
  },
  // Current operational status of the capability
  status: {
    type: String,
    required: true
  },
  // Flexible properties object for capability-specific settings
  properties: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  }
});

// Main device schema for IoT device management
const deviceSchema = new mongoose.Schema({
  // Unique device identifier from manufacturer
  device_id: {
    type: String,
    required: true,
    trim: true
  },
  // Serial number of the device
  SNO: {
    type: String,
    required: true,
    trim: true
  },
  // Firmware version installed on the device
  firmware: {
    type: String,
    required: true,
    trim: true
  },
  // MAC address for network identification
  Mac_addr: {
    type: String,
    required: true,
    trim: true
  },
  // Current operational status of the device
  status: {
    type: String,
    required: true,
    enum: ['Active', 'Inactive'],
    default: 'Active'
  },
  // Optional description of the device
  description: {
    type: String,
    trim: true
  },
  // Human-readable device name
  name: {
    type: String,
    required: true,
    trim: true
  },
  // Flag indicating if device has been configured (false = discovered, true = configured)
  configure_flag: {
    type: Boolean,
    default: false
  },
  // Soft delete flag (true = deleted, false = active)
  is_delete: {
    type: Boolean,
    default: false
  },
  // Device type/category (e.g., 'dimmer', 'switch', 'sensor')
  type: {
    type: String,
    required: true,
    trim: true
  },
  // Array of device capabilities (LED channels, shade controls, sensors)
  capabilities: [capabilitySchema],

  // Hierarchical location information - references to campus structure
  // Campus where the device is deployed
  campus: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Campus'
  },
  // Building within the campus
  building: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'CampusBuilding'
  },
  // Floor within the building
  floor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'CampusFloor'
  },
  // Zone within the floor where device is installed
  zone: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'CampusZone'
  },

  // Physical port configuration for device connections
  // Primary port configuration (e.g., "1/2" for main connections)
  port_primary: {
    type: String,
    trim: true
  },
  // Secondary port configuration (e.g., "3/4/5" for additional connections)
  port_secondary: {
    type: String,
    trim: true
  },

  // Audit trail fields for tracking device lifecycle
  // User who created/added this device
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  // User who last updated this device
  updatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  // User who deleted this device
  deletedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  // Timestamp when device was deleted
  deletedAt: {
    type: Date
  }
}, {
  timestamps: true // Automatically add createdAt and updatedAt
});

// Database indexes for optimized query performance
// Filter by device operational status
deviceSchema.index({ status: 1 });
// Filter by device type/category
deviceSchema.index({ type: 1 });
// Compound index for location-based queries (hierarchical filtering)
deviceSchema.index({ campus: 1, building: 1, floor: 1, zone: 1 });
// Note: Unique indexes on device_id, SNO, and Mac_addr would be added if needed

// Virtual for full port information
// deviceSchema.virtual('port').get(function () {
//   if (this.port_primary && this.port_secondary) {
//     return `${this.port_primary}/${this.port_secondary}`;
//   } else if (this.port_primary) {
//     return this.port_primary;
//   } else if (this.port_secondary) {
//     return this.port_secondary;
//   }
//   return null;
// });

// Ensure virtual fields are serialized
deviceSchema.set('toJSON', { virtuals: true });
deviceSchema.set('toObject', { virtuals: true });

// Pre-save middleware to validate port format
deviceSchema.pre('save', function (next) {
  // Validate port_primary format (should be like 1/2)
  // if (this.port_primary && !/^\d+\/\d+$/.test(this.port_primary)) {
  //   return next(new Error('port_primary must be in format "number/number" (e.g., "1/2")'));
  // }

  // // Validate port_secondary format (should be like 3/4/5)
  // if (this.port_secondary && !/^\d+(\/\d+)*$/.test(this.port_secondary)) {
  //   return next(new Error('port_secondary must be in format "number/number/number" (e.g., "3/4/5")'));
  // }

  next();
});

// Export the Device model for use in controllers and services
const Device = mongoose.model('Device', deviceSchema);

export default Device;
