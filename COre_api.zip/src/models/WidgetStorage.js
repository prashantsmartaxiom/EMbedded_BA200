/**
 * WidgetStorage Model
 * Stores user-specific dashboard widget configurations and layouts
 * Manages personalized widget arrangements, settings, and preferences
 * Used for persisting dashboard customizations across user sessions
 */

import mongoose from 'mongoose';

const { Schema } = mongoose;

// Schema for storing user dashboard widget configurations
const widgetStorageSchema = new Schema(
  {
    // Reference to user who owns this widget configuration
    userId: { 
      type: Schema.Types.ObjectId, 
      ref: 'User',
      required: true 
    },
    // Flexible widget structure object containing layout and configuration data
    structure: { type: Schema.Types.Mixed },
    // Whether this widget configuration is currently active
    isActive: { 
      type: Boolean, 
      default: true 
    },
    // Soft delete flag
    isDeleted: { 
      type: Boolean, 
      default: false 
    },
    // User who created this widget configuration (audit trail)
    createdBy: {
      userId: { type: Schema.Types.ObjectId },
      fullName: { type: String },
      email: { type: String }
    },
    // User who last updated this widget configuration (audit trail)
    updatedBy: {
      userId: { type: Schema.Types.ObjectId },
      fullName: { type: String },
      email: { type: String }
    }
  },
  { timestamps: true } // Automatically add createdAt and updatedAt
);

// Database indexes for optimized query performance
// Fast lookups by user
widgetStorageSchema.index({ userId: 1 });
// Filter by deletion status
widgetStorageSchema.index({ isDeleted: 1 });

// Export the WidgetStorage model with custom collection name 'widgets'
export const WidgetStorage = mongoose.model('widgets', widgetStorageSchema);