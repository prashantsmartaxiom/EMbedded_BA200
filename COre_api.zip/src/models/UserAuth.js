/**
 * UserAuth Model
 * Manages user authentication sessions and JWT token tracking
 * Stores device information, IP addresses, and session expiration details
 * Supports multi-device login sessions with detailed audit trails
 */

import mongoose from 'mongoose';

// Schema for user authentication session management
const userAuthSchema = new mongoose.Schema({
  // Reference to the authenticated user
  userId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true,
    index: true // Indexed for fast user session lookups
  },
  // Timestamp of user's last login
  lastLoginDateTime: { type: Date },
  // IP address from which user logged in
  ipAddress: { type: String },
  // Device and browser information for session tracking
  deviceDetails: {
    device: { type: String }, // Device type (e.g., "Apple Mac", "Windows PC")
    browser: { type: String }, // Browser version (e.g., "Chrome 91.0")
    userAgent: { type: String } // Complete user agent string for detailed tracking
  },
  // JWT token (hidden from queries by default for security)
  jwtToken: { type: String, select: false },
  // JWT expiration timestamp (optional - no limit if not set)
  expiry: { type: Date },
  // Current session status
  status: { 
    type: String, 
    enum: ['active', 'expired'], 
    default: 'active' 
  },
  // Timestamp of last token usage
  lastUse: { type: Date },
  // User who created this session record (audit trail)
  createdBy: {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    fullName: { type: String },
    email: { type: String }
  },
  // Timestamp when session record was created
  createdOn: { type: Date, default: Date.now },
  // User who last updated this session record (audit trail)
  updatedBy: {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    fullName: { type: String },
    email: { type: String }
  },
  // Timestamp when session record was last updated
  updatedOn: { type: Date, default: Date.now }
}, { 
  timestamps: true, // Automatically add createdAt and updatedAt
  versionKey: false // Disable __v version key
});

// Database indexes for optimized query performance
// Compound index for user session filtering
userAuthSchema.index({ userId: 1, status: 1 });
// Index for session expiry cleanup
userAuthSchema.index({ expiry: 1 });

// Export the UserAuth model for use in controllers and services
export const UserAuth = mongoose.model('UserAuth', userAuthSchema);