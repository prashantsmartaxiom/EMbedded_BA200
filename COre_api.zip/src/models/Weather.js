/**
 * Weather Model
 * Stores weather data and location information for users
 * Manages weather API data caching and user-specific location preferences
 * Used for weather-based automation and dashboard weather widgets
 */

import mongoose from 'mongoose';

const { Schema } = mongoose;

// Schema for weather data storage and user location tracking
const weatherSchema = new Schema(
  {
    // Reference to user who owns this weather data
    userId: { 
      type: Schema.Types.ObjectId, 
      ref: 'User',
      required: true 
    },
    // Latitude coordinate for weather location
    lat: { 
      type: Number, 
      required: true 
    },
    // Longitude coordinate for weather location
    long: { 
      type: Number, 
      required: true 
    },
    // Human-readable place name
    placeName: { 
      type: String, 
      required: true, 
      trim: true 
    },
    // Date string of last weather data fetch
    lastWeatherDate: { 
      type: String, 
      required: true 
    },
    // Flexible weather data object from external API
    weatherData: { 
      type: Schema.Types.Mixed, 
      required: true 
    },
    // Whether this weather location is active
    isActive: { 
      type: Boolean, 
      default: true 
    },
    // Soft delete flag
    isDeleted: { 
      type: Boolean, 
      default: false 
    },
    // User who created this weather record (audit trail)
    createdBy: {
      userId: { type: Schema.Types.ObjectId },
      fullName: { type: String },
      email: { type: String }
    },
    // User who last updated this weather record (audit trail)
    updatedBy: {
      userId: { type: Schema.Types.ObjectId },
      fullName: { type: String },
      email: { type: String }
    },
    // User who deleted this weather record (audit trail)
    deletedBy: {
      userId: { type: Schema.Types.ObjectId },
      fullName: { type: String },
      email: { type: String }
    },
    // ISO string representation of creation date
    createdDate: { 
      type: String, 
      default: () => new Date().toISOString() 
    },
    // ISO string representation of last update date
    updatedDate: { type: String },
    // ISO string representation of deletion date
    deletedDate: { type: String }
  },
  { timestamps: true } // Automatically add createdAt and updatedAt
);

// Database indexes for optimized query performance
// Compound index for geographic coordinate lookups
weatherSchema.index({ lat: 1, long: 1 });
// Fast lookups by user
weatherSchema.index({ userId: 1 });
// Filter by deletion status
weatherSchema.index({ isDeleted: 1 });
// Filter by active status
weatherSchema.index({ isActive: 1 });
// Search by place name
weatherSchema.index({ placeName: 1 });

// Export the Weather model for use in controllers and services
export const Weather = mongoose.model('Weather', weatherSchema);