/**
 * Group Model
 * Represents logical groupings of device channels for coordinated control
 * Allows users to control multiple device channels simultaneously
 * Supports grouping of LED channels, shade controls, and sensors across different devices
 */

import mongoose from 'mongoose';

// Schema for individual channels within a device group
const ChannelSchema = new mongoose.Schema({
	// Unique identifier for the channel within its device
	channelId: { type: String, required: true },
	// Type of channel (led, shade, sensor)
	channelType: { type: String, required: true }
}, { _id: false }); // Disable _id for embedded subdocuments

// Schema for devices included in a group
const DeviceSchema = new mongoose.Schema({
	// Device identifier
	deviceId: { type: String, required: true },
	// Array of channels from this device that are part of the group
	channels: [{ type: ChannelSchema, required: true }]
}, { _id: false }); // Disable _id for embedded subdocuments

// Main group schema for device channel groupings
const GroupSchema = new mongoose.Schema({
	// Human-readable group name
	name: { type: String, required: true },
	// Array of devices and their channels included in this group
	devices: [{ type: DeviceSchema, required: true }],
	// Soft delete flag (true = deleted, false = active)
	isDeleted: { type: Boolean, default: false },
	// User who created this group (audit trail)
	createdBy: {
		userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
		fullName: { type: String },
		email: { type: String }
	},
	// User who last updated this group (audit trail)
	updatedBy: {
		userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
		fullName: { type: String },
		email: { type: String }
	}
}, { timestamps: true }); // Automatically add createdAt and updatedAt

// Export the Group model for use in controllers and services
export const Group = mongoose.model('Group', GroupSchema);
