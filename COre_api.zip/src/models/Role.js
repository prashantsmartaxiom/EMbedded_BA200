

/**
 * Role Model
 * Defines user roles and their associated permissions within the Smart Axiom MPS system
 * Supports flexible permission structures for access control and authorization
 * Manages role-based access to different system modules and functionalities
 */

import mongoose from 'mongoose';

// Schema for user roles and permission management
const roleSchema = new mongoose.Schema({
  // Unique name for the role (e.g., "Admin", "Manager", "User")
  roleName: {
    type: String,
    required: true,
    unique: true, // Ensure no duplicate role names
    trim: true,
    maxlength: 100
  },
  // Flexible permissions object - can contain nested or flat permission structures
  permissions: {
    type: mongoose.Schema.Types.Mixed, // Allows complex nested permission objects
    default: {}
  },
  // Soft delete flag (true = deleted, false = active)
  isDelete: { type: Boolean, default: false },
  // Whether the role is currently active and available for assignment
  isActive: { type: Boolean, default: true },
  // Flag indicating if this is a default system role (string for legacy compatibility)
  byDefault: { type: String, default: "false" }
}, {
  timestamps: true // Automatically add createdAt and updatedAt
});

// Note: roleName already has unique index from schema definition
// Additional indexes could be added here if needed for filtering by isActive, isDelete, etc.

// Export the Role model for use in controllers and services
const Role = mongoose.model("Role", roleSchema);

export default Role;