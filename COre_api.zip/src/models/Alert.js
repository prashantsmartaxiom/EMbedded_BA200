/**
 * Alert Model
 * Represents system alerts and notifications from IoT devices
 * Tracks device states, alarms, and system events for monitoring and troubleshooting
 */

import mongoose from 'mongoose';

// Schema definition for device alerts and system notifications
const alertSchema = new mongoose.Schema({
  // Human-readable device name or description
  device: {
    type: String,
    required: true,
    trim: true
  },
  // Current state or alert type (e.g., 'alarm', 'warning', 'info')
  state: {
    type: String,
    required: true,
    trim: true
  },
  // Device manufacturer or system code identifier
  deviceCode: {
    type: String,
    required: true,
    trim: true
  },
  // Unique device identifier for tracking
  deviceID: {
    type: String,
    required: true,
    trim: true
  },
  // When the alert occurred
  timestamp: {
    type: Date,
    required: true
  },
  // Numeric value associated with the alert (optional)
  stateValue: {
    type: Number,
    required: false // Optional field as not all alerts have stateValue
  }
}, {
  timestamps: true, // Automatically add createdAt and updatedAt fields
  collection: 'alerts' // Explicitly specify collection name in MongoDB
});

// Database indexes for optimized query performance
// Most recent alerts first (common query pattern)
alertSchema.index({ timestamp: -1 });
// Fast lookups by device identifiers
alertSchema.index({ deviceID: 1 });
alertSchema.index({ deviceCode: 1 });
alertSchema.index({ device: 1 });

// Export the Alert model for use in controllers and services
export const Alert = mongoose.model('Alert', alertSchema);