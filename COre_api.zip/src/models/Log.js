/**
 * Log Model
 * Represents system event logs for user actions and device operations
 * Tracks user interactions, device commands, and system events for audit and debugging
 * Used for activity monitoring and troubleshooting system issues
 */

import mongoose from 'mongoose';

// Schema for system and user action logs
const logSchema = new mongoose.Schema({
  // Action performed (e.g., 'create', 'update', 'delete', 'control')
  action: {
    type: String,
  },
  // Name of the entity or resource affected
  name: {
    type: String,
  },
  // Unix timestamp when the action occurred
  timestamp: {
    type: Number,
  },
  // Type of log entry (e.g., 'user_action', 'device_command', 'system_event')
  type: {
    type: String,
  },
  // ID of the user who performed the action
  userId: {
    type: String,
  },
  // Name of the user who performed the action
  userName: {
    type: String,
  },
  // ID of the device involved in the action (if applicable)
  deviceId: {
    type: String
  },
  // Name of the device involved in the action (if applicable)
  deviceName: {
    type: String
  },
  // Channel ID within the device (if applicable) - Note: typo in original 'channnelId'
  channnelId: {
    type: String
  }
}, {
  collection: 'logs', // Explicitly specify the collection name
});

// Export the Log model for use in controllers and services
const Log = mongoose.model('Log', logSchema);

export default Log;
