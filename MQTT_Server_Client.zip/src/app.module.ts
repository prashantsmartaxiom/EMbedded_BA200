import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MqttModule } from './mqtt/mqtt.module';
const appRoot = require('app-root-path');
const conf = JSON.parse(require("fs").readFileSync(appRoot.path + "/env-config.json"));

@Module({
  imports: [
    MongooseModule.forRoot(`mongodb://${conf.MONGO_HOST}:${conf.MONGO_PORT}/mps`),MqttModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
