import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

class deviceEntities {
  type: string; //" 'led' | 'shade' | 'sensor' "
  nickname: string;
  name: string;
  status: string;
  macAddress?: string;
  properties: {
      brightness?: number;  // Optional
      color?: string;  // Optional
      powerMin?: number;  // Optional
      powerMax?: number;  // Optional
      maxMovement?: number;  // Optional
      openLevel?: string;  // Optional
      installShade?: boolean;  // Optional
      shadeId?: boolean;  // Optional
      sensorType?: string;  // Optional
      sensorState?: string;  // Optional
  };
}

@Schema({ timestamps: true })
export class Devices extends Document {
  @Prop({ required: true })
  device_id: string;

  @Prop({ required: true })
  SNO: string;

  @Prop({ required: true })
  Firmware: string;

  @Prop({ required: true })
  MacAddr: string;

  @Prop()
  capabilities: deviceEntities[];

  @Prop()
  status: string;
}

export const DevicesSchema = SchemaFactory.createForClass(Devices);
