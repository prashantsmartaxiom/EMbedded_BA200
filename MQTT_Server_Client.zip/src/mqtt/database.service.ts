import { Injectable, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { lastValueFrom } from 'rxjs';
const appRoot = require('app-root-path');
const conf = JSON.parse(require("fs").readFileSync(appRoot.path + "/env-config.json"));


@Injectable()
export class DatabaseService implements OnModuleInit, OnModuleDestroy {
    constructor(private httpService: HttpService) { }
    
    onModuleInit() {
        
    }

    async getDevices() {
        console.log("Fetch device list");
        let devices;
        try {
            devices = await lastValueFrom(
                this.httpService.get(`http://${conf.MPS_HOST}:${conf.MPS_PORT}/events/getDevices`)
            );
        } catch {
            console.log("Couldn't connect api");
            devices = [];
        }
        return devices?.data?.data || [];
    }

    async storeMessage(id:string,control_topic: string, message: any) {
        console.log(`Storing message: ${control_topic} - ${message}`);
        const messageData = { id, control_topic, message }
        try {
            this.httpService.post(`http://${conf.MPS_HOST}:${conf.MPS_PORT}/events/devicesMessage`, messageData).subscribe((response:any)=>{
                console.log("Response from store message api",response?.data?.data);
            });
        } catch {
            console.log("Couldn't connect devices message api");
        }
    }

    async updateDeviceData(id: string, updateData) {
        console.log("Update device: ", id, "with ", updateData);
        try {
            this.httpService.post(`http://${conf.MPS_HOST}:${conf.MPS_PORT}/events/update`, updateData);
        } catch {
            console.log("Couldn't connect update device data api");
        }
    }

    onModuleDestroy() {
        
    }
}
