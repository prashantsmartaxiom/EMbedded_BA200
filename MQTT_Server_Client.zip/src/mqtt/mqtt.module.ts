import { Module } from '@nestjs/common';
import { MqttService } from './mqtt.service';
import { MqttController } from './mqtt.controller';
import { DatabaseService } from './database.service';
import { HttpModule } from '@nestjs/axios';

@Module({
  imports: [ HttpModule ],
  providers: [MqttService, DatabaseService],
  controllers: [MqttController],
  exports: [MqttService, DatabaseService],
})
export class MqttModule {}
