import { Injectable, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import * as mqtt from 'mqtt';
import { DatabaseService } from './database.service';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
import { deviceConfig, mqttMessageTypes } from './mqtt.enum';
const appRoot = require('app-root-path');
const conf = JSON.parse(require("fs").readFileSync(appRoot.path + "/env-config.json"));


@Injectable()
export class MqttService implements OnModuleInit, OnModuleDestroy {
  constructor(
    private databaseService: DatabaseService,
    private httpService: HttpService,
  ) { }

  private client: mqtt.MqttClient;
  private devices: Record<string, any> = {};

  async onModuleInit() {
    this.connectToBroker();
    try {
      await firstValueFrom(
        this.httpService.post(`http://${conf.MPS_HOST}:${conf.MPS_PORT}/events/updateDeviceStatus`, {deviceData: [], status: 'Inactive'})
      );
    } catch {
      console.log("Couldn't connect update device status api");
    }
    this.client.on('connect', async () => {
      console.log('Connected to MQTT Broker');
  });
  }
 


  private async connectToBroker() {
    console.log("Mqtt connected");
    this.client = mqtt.connect(`mqtt://${conf.brokerUrl}:${conf.brokerPort}`, {
      username: conf.mqttUsername,
      password: conf.mqttPassword,
      keepalive: 120,
      clean: true
    });

    this.client.on('connect', async () => {
      console.log('Connected to MQTT Broker');
      //Subscribe to already existing devices
      await this.loadDevicesFromDatabase();
      await this.checkDeviceHeartbeat();
      // Subscribe to the global discovery topic
      this.client.subscribe(mqttMessageTypes.discovery, async(err) => {
        if (err) console.error('Failed to subscribe:', err.message);
        else {
          console.log(`Subscribed to  ${mqttMessageTypes.discovery}`);
        }
      });
    });

    this.client.on('message', async (topic, message) => {
      console.log("Message received on topic:", topic);
      
      if (topic === mqttMessageTypes.discovery) {
        this.handleDeviceDiscovery(message.toString());
      } else if (topic.includes('/config')) {
        this.handleDeviceConfig(message.toString(), topic);
      }  else if (topic.includes('/status')) {
        this.handleDeviceStatus(message.toString(), topic);
      }
      else if (topic.includes('/sessionPing')) {
        this.handleSessionPing(message.toString(), topic);
      }
      else if (topic.includes('/control')) {
        // this.handleDeviceControl(message.toString(), topic);
      } else {
        console.error(`Unexpected topic received: ${topic}`);
      }
    });

    this.client.on('error', (error) => {
      console.error('MQTT Error:', error.message);
    });
  }

// Extract device_id from topic
  private extractDeviceId (topic) {
    const topicParts = topic.split('/');
    return topicParts.length > 3 ? topicParts[3] : null;
  };

 private async checkDeviceHeartbeat() {
  setInterval(async () => {
    console.log("Checking device heartbeat...");

    // Send heartbeat request
    for (const deviceId of Object.keys(this.devices)) {
      if (this.devices[deviceId].status) {
        this.client.publish(`${mqttMessageTypes.global}${deviceId}/status`, JSON.stringify({ deviceId: "status" }), { qos: 1 }, (err, msg) => {
        console.log('Sent Status Request to', deviceId);
        if (msg) {
          // console.log("Message Received:", msg);
        }
        else if(err)
          console.log("Error:", err);
        });
      }
    }

    const now = Date.now();

    // Check for inactive devices
    for (const [deviceId, device] of Object.entries(this.devices)) {
      const lastSeen = device.lastSeen || 0;

      console.log("---last seen---", lastSeen, deviceId);

      if (now - lastSeen > 60 * 1000) {
        console.log(`Device ${deviceId} is inactive. Last seen: ${new Date(lastSeen).toISOString()}`);

        device.status = "Inactive";

        await firstValueFrom(
          this.httpService.post(
            `http://${conf.MPS_HOST}:${conf.MPS_PORT}/events/updateDeviceStatus`,
            { deviceData: { device_id: deviceId }, status: "Inactive" }
          )
        );
      }
    }
  }, 60 * 1000);
}


  private handleSessionPing(message, topic) {
    console.log("Device Session Ping Received:", message, topic);
    
    // this.client.publish(mqttMessageTypes.sessonPing, JSON.stringify(message), { qos: 1 }, (err, msg) => {
    //   console.log('Sent Config Request', JSON.stringify(message));
    //   if (msg) {
    //     console.log("Message Received:", msg);
        
    //   }
    //   else if(err)
    //     console.log("Error:", err);
    // });
  }

  handlesensorTriggerTimer(deviceId, sensorData) {
    this.client.publish(`${mqttMessageTypes.global}${deviceId}/timer`, JSON.stringify(sensorData), { qos: 1 }, (err, msg) => {
      console.log('Sent Sensor Trigger Timer', JSON.stringify(sensorData));
      if (msg)
        console.log("Message Received:", msg);
      else if(err)
        console.log("Error:", err);
    });
  }

  private async handleDeviceDiscovery(payload: string) {
    try {
      let deviceInfo;
      try {
        deviceInfo = JSON.parse(payload);
      } catch (error) {
        console.error('Failed to parse payload as JSON:', error.message);
        return;
      }
      const { device_id, SNO, Firmware, MacAddr } = deviceInfo;
      console.log(`Device Info------ID: ${device_id}\nSNO: ${SNO}\nMAC: ${MacAddr}\nFirmware: ${Firmware}\n`);
      if (deviceInfo.Firmware === '')
        deviceInfo.Firmware = 'v1.0.0.1';
      
      // Subscribe to device-specific topics
      const configTopics = mqttMessageTypes.globalUp + device_id + '/config';
      console.log(configTopics);
      this.client.subscribe(configTopics);

      const controlTopics = mqttMessageTypes.globalUp + device_id + '/control';
      console.log(controlTopics);
      this.client.subscribe(controlTopics);

      const statusTopics= mqttMessageTypes.globalUp + device_id + '/status';
      console.log(statusTopics);
      this.client.subscribe(statusTopics);

      console.log(`Subscribed to topics for device ${device_id}`);

      // Request full config
      const requestConfig = { ch_t : "LED", ch_addr : "LED1", cmd: deviceConfig.LED_CONFIG, cmd_m: "config"};
      this.client.publish(`${mqttMessageTypes.global}${device_id}/config`, JSON.stringify(requestConfig), { qos: 1 }, (err, msg) => {
        console.log('Sent Config Request', JSON.stringify(requestConfig));
        if (msg)
          console.log("Message Received:", msg);
        else if(err)
          console.log("Error:", err);
      });

      if (!this.devices[device_id]) {
        console.log(`Discovered device: ${device_id}`);
        this.devices[device_id] = { device_id, SNO, Firmware, MacAddr };
        console.log("call save ")        
        this.devices[device_id].lastSeen = Date.now();
        this.devices[device_id].status = "Active";
        console.log("Update last seen and status", this.devices[device_id]);
        try {
          await firstValueFrom(
            this.httpService.post(`http://${conf.MPS_HOST}:${conf.MPS_PORT}/events/storeDevice`, deviceInfo)
          );
        } catch {
          console.log("Couldn't connect store device api", deviceInfo);
        }
        console.log(`Subscribed to topics for device ${device_id}`);
      } else {
        try {
          this.devices[device_id].lastSeen = Date.now();
          this.devices[device_id].status = "Active";
          console.log("Update last seen and status", this.devices[device_id]);
          await firstValueFrom(
            this.httpService.post(`http://${conf.MPS_HOST}:${conf.MPS_PORT}/events/updateDeviceStatus`, {deviceData: deviceInfo, status: 'Active'})
          );
        } catch {
          console.log("Couldn't update device status data");
        }
        console.log(`Device ${device_id} is already registered.`);
      }

    } catch (error) {
      console.error('Failed to decode discovery payload:', error.message);
    }
  }

  // HMI config function
  // scan: { ch_t: "HMI", ch_addr: null, cmd: deviceConfig.HMI_SCAN, cmd_m: true }
  // {"ch_t":"HMI","ch_addr":"Port-1_2","cmd":123,"cmd_m":"PIR State = 0"}
  // {"ch_t":"HMI","ch_addr":"hmi_config_id","cmd":124,"cmd_m":"channelid(1),brightness(100),powerMax(100),on(1)/off(0)"}
  // {"ch_t":"HMI","ch_addr":"hmi_config_id","cmd":125,"cmd_m":"shadeid(1),openLevel(100),open(1)/close(0)"}
  // {"ch_t":"HMI","ch_addr":"Port-1_2","cmd":122,"cmd_m":"Array of channels"}

  // Received device status {"ch_t":"HMI","ch_addr":"PORT1_0","cmd":126,"cmd_m":"LED11:1,100,0"}

  sendHMICommands(payload, topic) {
    const controlData = payload;
    const deviceId = topic;
    console.log("HMI Command Data:", payload, topic);
    
    this.client.publish(`${mqttMessageTypes.global}${mqttMessageTypes.hmi}${deviceId}`, JSON.stringify(controlData), { qos: 1 }, (err, msg) => {
      console.log('Sent HMI Config Command', JSON.stringify(controlData));
      if (msg)
        console.log("Message Received:", msg);
      else if(err)
        console.log("Error:", err);
    });
  }

  // Handle device Status 
  async handleDeviceStatus(payload, topic) {
    try {
      console.log('Received Device Status', payload);
      const statusData = JSON.parse(payload);
      const deviceId = this.extractDeviceId(topic);  // Extract correct device ID from topic
      // device activation on status cmd
      if (this.devices.hasOwnProperty(deviceId)) {
        this.devices[deviceId].lastSeen = Date.now();
        console.log("Update last seen", this.devices[deviceId]);
        console.log("Device status", this.devices[deviceId].status);
        
        if (this.devices[deviceId].status !== "Active") {
          console.log("Updating device status to Active", deviceId);
          this.devices[deviceId].status = "Active";
          firstValueFrom(
            this.httpService.post(`http://${conf.MPS_HOST}:${conf.MPS_PORT}/events/updateDeviceStatus`, {deviceData: {device_id:deviceId}, status: 'Active'})
          );
        }
        console.log(`✅ Received device status`, JSON.stringify(statusData));
        // {"ch_t":"PIR","ch_addr":"Port-1_2","cmd":115,"cmd_m":"PIR State = 0"}       
        switch (statusData.cmd) {
          case deviceConfig.PIR_STATE:  try {
            await firstValueFrom(
              this.httpService.post(`http://${conf.MPS_HOST}:${conf.MPS_PORT}/events`, { statusData, deviceId })
            );
          } catch {
            console.log("Couldn't connect events api");
          }  break;
          default : 
        }

      } else {
        console.error(`❌ Device ID ${deviceId} not found in devices list!`);
      }
    } catch (error) {
      console.error(`❌ Failed to parse control command from topic ${topic}:`, error.message);
    }
  };

  // Handle device control commands
  //payload : { ch_t: 'LED', ch_addr: 'LED6', cmd: 104, cmd_m: 'LED_OFF' }
  // For scene : { ch_t: 'LED', ch_addr: [2, 7, 8, 11], cmd: 117, cmd_m: 'LED_OFF' },
  //  { ch_t: 'SHADE', ch_addr: [ 1,3 ], cmd: 117, cmd_m: 'shade_open' } 
  // topic: device_id
  handleDeviceControl(payload, topic) {
    try {
      console.log('Received Control Command', payload);
      console.log('Received Topic', topic);
      const controlData = payload;
      const deviceId = topic;  // Extract correct device ID from topic

      if (this.devices.hasOwnProperty(deviceId)) {
      console.log(`✅ Control Command Processed`, `Device: ${deviceId}\nCommand: ${JSON.stringify(controlData)}`);
        if (payload.cmd === 117) {
          this.client.publish(`${mqttMessageTypes.global}${deviceId}/scene`, JSON.stringify(controlData), { qos: 1 }, (err, msg:any) => {
            if (msg) {
              console.log("Message Received:", msg);
              this.databaseService.storeMessage(deviceId,`${mqttMessageTypes.global}${deviceId}/scene`, JSON.stringify(msg));
            }
            else if(err)
              console.log("Error:", err);
          });
        } else {
          this.client.publish(`${mqttMessageTypes.global}${deviceId}/control`, JSON.stringify(controlData), { qos: 1 }, (err, msg:any) => {
            if (msg) {
              console.log("Message Received:", msg);
              this.databaseService.storeMessage(deviceId,`${mqttMessageTypes.global}${deviceId}/control`, JSON.stringify(msg));              
            }
            else if(err)
              console.log("Error:", err);
          });
        }
      } else {
        console.error(`❌ Device ID ${deviceId} not found in devices list!`);
        console.error(`📌 Available devices: ${Object.keys(this.devices).join(', ')}`);
      }
    } catch (error) {
      console.error(`❌ Failed to parse control command from topic ${topic}:`, error.message);
    }
  };

  handleDeviceReboot(deviceId: string) {
    this.client.publish(`${mqttMessageTypes.global}${deviceId}/reboot`, JSON.stringify({deviceId:"reboot"}), { qos: 1 }, (err, msg:any) => {
      if (msg) {
        console.log("Message Received:", msg);
        this.databaseService.storeMessage(deviceId,`${mqttMessageTypes.global}${deviceId}/reboot`, JSON.stringify(msg));
      }
      else if(err)
        console.log("Error:", err);
    });
  }

  // Handle full device config
  private handleDeviceConfig(payload, topic) {
    try {
      const configData = JSON.parse(payload);
      const device_id = this.extractDeviceId(topic);

      this.devices[device_id].lastSeen = Date.now();
      console.log("Update last seen", this.devices[device_id]);
      if (this.devices[device_id].status !== "Active") {
        this.devices[device_id].status = "Active";
        firstValueFrom(
          this.httpService.post(`http://${conf.MPS_HOST}:${conf.MPS_PORT}/events/updateDeviceStatus`, {deviceData: {device_id}, status: 'Active'})
        );
      }

      if (!device_id) {
          console.error(`❌ Invalid topic format: ${topic}`);
          return;
      }

      if (this.devices[device_id]) {
        this.devices[device_id].config = configData;
        // this.databaseService.updateDeviceData(device_id, configData);
      } else {
        console.error(`❌ Device ID ${device_id} not found in devices list!`);
      }

      //const requestConfig = { ch_t : "LED", ch_addr : "LED1", cmd: 104, cmd_m: "LED_ON" };
      //this.client.publish(`${mqttMessageTypes.global}${device_id}/control`, JSON.stringify(requestConfig));
      //console.log('🔄 Sent Config Request', JSON.stringify(requestConfig));

    } catch (error) {
      console.error(`❌ Failed to parse device config from topic ${topic}:`, error.message);
    }
  };

  private unsubscribeDevice(deviceId) {
    const configTopics = mqttMessageTypes.globalUp + deviceId + '/config';
    console.log(configTopics);
    this.client.unsubscribe(configTopics);

    const controlTopics = mqttMessageTypes.globalUp + deviceId + '/control';
    console.log(controlTopics);
    this.client.unsubscribe(controlTopics);

    const statusTopics= mqttMessageTypes.globalUp + deviceId + '/status';
    console.log(statusTopics);
    this.client.unsubscribe(statusTopics);
    console.log(`Unsubscribed to topics for device ${deviceId}`);
  }

  handleDeleteDevice(deviceId) {
    // Unsubscribe to device-specific topics
    this.unsubscribeDevice(deviceId);
    delete this.devices[deviceId];
  }

  getDevices() {
    this.connectToBroker();
  }

  private async loadDevicesFromDatabase() {
    const storedDevices: any = await this.databaseService.getDevices();
    console.log('Stored Devices:', storedDevices);
    
    storedDevices.forEach((device: any) => {
      console.log("Loading device:", device.device_id);
        this.devices[device.device_id] = device;
      this.subscribeToDeviceTopics(device.device_id);
      // this.handleDeviceReboot(device.device_id);
    });
    console.log('Loaded devices from database:', Object.keys(this.devices));
}

  private subscribeToDeviceTopics(deviceId: string) {
    try {
      const topics = [
        `${mqttMessageTypes.globalUp}${deviceId}/config`,
        `${mqttMessageTypes.globalUp}${deviceId}/control`,
        `${mqttMessageTypes.globalUp}${deviceId}/status`
      ];  
      topics.forEach((topic: any) => this.client.subscribe(topic));
      console.log(`Subscribed to topics for device ${deviceId}`);
    } catch(error) {
      console.log("Couldn't connect, connecting again...", error);
    }
}
  onModuleDestroy() {
    if (this.client) {
      this.client.end();
      console.log('Disconnected from MQTT Broker');
    }
  }
}
