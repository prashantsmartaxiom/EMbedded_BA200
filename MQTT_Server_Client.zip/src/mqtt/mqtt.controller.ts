import { Body, Controller, Get, Post } from '@nestjs/common';
import { MqttService } from './mqtt.service';

@Controller('mqtt')
export class MqttController {
  constructor(private readonly mqttService: MqttService) {}

  @Get('devices')
  getDevices() {
    return this.mqttService.getDevices();
  }

  @Post('control')
  sendControl(@Body() body: { payload: any; topic: any }) {
    return this.mqttService.handleDeviceControl(body.payload, body.topic);
  }

  @Post('sendHMICommands')
  sendHMICommands(@Body() body: { payload: any; topic: any }) {
    return this.mqttService.sendHMICommands(body.payload, body.topic);
  }

  @Post('reboot')
  deviceReboot(@Body() body: { deviceId: any; }) {
    return this.mqttService.handleDeviceReboot(body.deviceId);
  }

  @Post('sensorTriggerTimer')
  sensorTriggerTimer(@Body() body: { deviceId: any; sensorData: any }) {
    return this.mqttService.handlesensorTriggerTimer(body.deviceId, body.sensorData);
  }

  @Post('deleteDevice')
  deleteDevice(@Body() body: { deviceId: any; }) {
    return this.mqttService.handleDeleteDevice(body.deviceId);
  }

  @Post('status')
  getStatus(@Body() body: { payload: any; topic: any }) {
    return this.mqttService.handleDeviceControl(body.payload, body.topic);
  }
}
