export enum mqttMessageTypes {
    global = 'MPS/global/',
    hmi = 'hmi/',
    discovery = 'MPS/global/discovery',
    globalUp = 'MPS/global/UP/',
    sessonPing = 'MPS/global/sessionPing',
}

export enum deviceConfig {
    LED_STATUS  = 101, 
    LED_BRIGHTNESS  = 102, //control msgs
    LED_COLOR  = 103,
    LED_ON_OFF  = 104,//control msgs
    LED_MAX_CUR  = 105,//control msgs
    LED_CONFIG  = 106, //control msgs
    LED_CONFIG_CH  = 107,
    SHADE_CONTROL  = 108,
    SHADE_DOWN  = 109,
    SHADE_CONFIG  = 110,
    SHADE_STOP  = 111,
    SHADE_STATUS  = 112,
    SHADE_OPEN  = 113, 
    SHADE_CLOSE  = 114,
    PIR_STATE  = 115,
    TEMP_HUM = 116,
    SCENE_CMD = 117,
    PIR_CONFIG = 118,
    SHADE_LIMIT = 119,
    SHADE_MOVE = 120,
    GRP_PIR_TIMER = 121,
    HMI_SCAN = 122,
    HMI_CONFIG_ID = 123,
    HMI_CONFIG_LED = 124,
    HMI_CONFIG_SHADE = 125,
    HMI_LED_STATUS = 126,
    HMI_SHADE_STATUS = 127,
    HMI_CONFIG = 128
}

// ch_t:"HMI", "ch_addr":null, "cmd": 122, "cmd_m": true
// Response: ch_t:"HMI", "ch_addr":<port_no>, "cmd": 122, "cmd_m": [24,25,26,27....]
// ch_t: "HMI", "ch_addr":"1/2/3/4","cmd":"123",cmd_m:"24-48"
//hmi control msg -> get all shade led id
//hmi config in status -> user value set for hmi, id ledChannel shadeChannel 
// ch_t:"HMI", "ch_addr":'Port-1_24', "cmd": 128, "cmd_m": id,ledChannel:<chNumber>,shadeChannel:<chNumber>
