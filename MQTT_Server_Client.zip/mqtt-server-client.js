const express = require('express');
const mqtt = require('mqtt');
const cors = require('cors');
const chalk = require('chalk');
const { timeStamp } = require('console');

const app = express();
app.use(cors()); // Enable CORS
app.use(express.json()); // Parse JSON requests

// MQTT Broker details
const BROKER = '10.4.1.10'; // Replace with your MQTT broker IP
const PORT = 1883;
const client = mqtt.connect(`mqtt://${BROKER}:${PORT}`, {
    username: 'mps-bam100', // Replace with your MQTT username
    password: 'bam100'  // Replace with your MQTT password
});

// Global devices object
const devices = {};

// Function to log messages with color
const log = (title, message, color = 'green') => {
    console.log(chalk[color](`\n==== ${title} ====`));
    console.log(chalk[color](message));
    console.log(chalk[color](`===================\n`));
};

// Extract device_id from topic
const extractDeviceId = (topic) => {
    const topicParts = topic.split('/');
    return topicParts.length > 3 ? topicParts[3] : null;
};

// Handle device discovery
const handleDeviceDiscovery = async (payload) => {
    try {
        log('Received Discovery Payload', payload, 'blue');
        const deviceInfo = JSON.parse(payload);
        const { device_id, SNO, Firmware, MacAddr } = deviceInfo;
        log('Device Info', `ID: ${device_id}\nSNO: ${SNO}\nMAC: ${MacAddr}\nFirmware: ${Firmware}\n`, 'yellow');
        
        // Subscribe Client to all events
        client.subscribe(`MPS/global/UP/${device_id}/#`);
        log('Subscribed Topics', `MPS/global/UP/${device_id}/#`, 'yellow');
        
        if (!devices[device_id]) {
            log('Discovered New Device', `ID: ${device_id}\nMAC: ${MacAddr}\nFirmware: ${Firmware}`, 'cyan');
            devices[device_id] = { MacAddr, SNO, Firmware, status: 'offline' };

            // Publish send_config for the device
            const requestConfig = { ch_t: "LED", ch_addr: "LED1", cmd: 106, cmd_m: [1, 50, 150] };
            const config_topic = `MPS/global/${device_id}/config`;
            await client.publishAsync(config_topic, JSON.stringify(requestConfig));
            log('🔄 Sent Config Request', JSON.stringify(requestConfig), 'blue');
        } else {
            log('Device Already Discovered', `ID: ${device_id}\nMAC: ${MacAddr}\nFirmware: ${Firmware}`, 'cyan');
        }

     
    } catch (error) {
        console.error(chalk.red('❌ Failed to decode discovery payload:'), error.message);
    }
};

// Handle full device config
const handleDeviceConfig = async (payload, topic) => {
    log('Received Device Config', payload, 'cyan');
    const configData = JSON.parse(payload);
    const device_id = extractDeviceId(topic);
    if (!device_id) {
        console.error(`❌ Invalid topic format: ${topic}`);
        return;
    }
    try {
        if (devices[device_id]) {
            devices[device_id].config = configData;
            log('✅ Device Configuration Updated', `Device: ${device_id}\nConfig: ${JSON.stringify(configData, null, 2)}`, 'green');
        } else {
            console.error(chalk.red(`❌ Device ID ${device_id} not found in devices list!`));
        }
    } catch (error) {
        console.error(chalk.red(`❌ Failed to parse device config from topic ${topic}:`), error.message);
    }

     // Publish send_config for the device
     const requestLEDOn = { ch_t: "LED", ch_addr: "LED0",cmd: 104, cmd_m: "LED_ON"}
     const control = `MPS/global/${device_id}/control`;
     await client.publishAsync(control, JSON.stringify(requestLEDOn));
     log('🔄 Sent Request for LED ON', JSON.stringify(requestLEDOn), 'blue');
};

const handleDeviceStatus = (payload, topic) => {
    try {
        log('Received Device Config', payload, 'cyan');
        const statusData = JSON.parse(payload);
        const device_id = extractDeviceId(topic);
        if (!device_id) {
            console.error(`❌ Invalid topic format: ${topic}`);
            return;
        }

        if (devices[device_id]) {
            devices[device_id].status = statusData;
            log('✅ Device Status', `Device: ${device_id}\nstatus: ${JSON.stringify(statusData, null, 2)}`, 'green');            
        } else {
            console.error(chalk.red(`❌ Device ID ${device_id} not found in devices list!`));
        }
    } catch (error) {
        console.error(chalk.red(`❌ Failed to parse device status from topic ${topic}:`), error.message);
    }
};


// Handle incoming MQTT messages
client.on('message', (topic, message) => {
    console.log(chalk.magenta(`📩 Message received on topic ${topic}:`), message.toString());
    
    if (topic === 'MPS/global/discovery') {
        handleDeviceDiscovery(message.toString());
    } else {
        const device_id = extractDeviceId(topic);
        if (!device_id) {
            console.error(`❌ Invalid topic format: ${topic}`);
            return;
        } else {
            console.log(chalk.magenta(`📩 Device ID: ${device_id}`));
        }

        if (topic.includes(`MPS/global/UP/${device_id}/config`)) {
            handleDeviceConfig(message.toString(), topic);
        } else if (topic.includes(`MPS/global/UP/${device_id}/status`)) { 
            handleDeviceStatus(message.toString(), topic);// Add a valid condition here if needed
        } else if (topic.includes(`MPS/global/UP/${device_id}/control`)) {     
        } else {
            console.error(chalk.red(`❌ Unexpected topic received: ${topic}`));
        }
    }
});

// Handle MQTT connection
client.on('connect', () => {
    console.log(chalk.green('✅ Connected to MQTT Broker!'));
    client.subscribe('MPS/global/discovery');
    log('🔍 Subscribed to Discovery Topic', 'MPS/global/discovery', 'blue');
});

// Handle MQTT errors
client.on('error', (error) => {
    console.error(chalk.red(`❌ MQTT Connection Error: ${error.message}`));
});

// API to fetch devices for frontend
app.get('/devices', (req, res) => {
    res.json(devices);
});

// Start the Express server
const port = 3000;
app.listen(port, () => {
    console.log(chalk.green(`🚀 Server running on http://localhost:${port}`));
});
