import { toast } from "react-toastify";

// Custom toaster configuration with theme colors
const toastConfig = {
  position: "top-right",
  autoClose: 4000,
  hideProgressBar: false,
  closeOnClick: true,
  pauseOnHover: true,
  draggable: true,
  style: {
    fontFamily: '"Noto Sans", sans-serif',
    fontSize: "14px",
    borderRadius: "10px",
    boxShadow: "0px 4px 12px rgba(34, 34, 34, 0.1)",
  },
};

export const toaster = {
  success: (message, options = {}) => {
    toast.success(message, {
      ...toastConfig,
      style: {
        ...toastConfig.style,
        background: "#ffffff",
        color: "#222222",
        border: "1px solid #E6F0FC",
      },
      progressStyle: {
        background: "#227EEB",
      },
      ...options,
    });
  },

  error: (message, options = {}) => {
    toast.error(message, {
      ...toastConfig,
      style: {
        ...toastConfig.style,
        background: "#ffffff",
        color: "#222222",
        border: "1px solid #ffe6e6",
      },
      progressStyle: {
        background: "#ff4d4f",
      },
      ...options,
    });
  },

  warning: (message, options = {}) => {
    toast.warning(message, {
      ...toastConfig,
      style: {
        ...toastConfig.style,
        background: "#ffffff",
        color: "#222222",
        border: "1px solid #fff7e6",
      },
      progressStyle: {
        background: "#faad14",
      },
      ...options,
    });
  },

  info: (message, options = {}) => {
    toast.info(message, {
      ...toastConfig,
      style: {
        ...toastConfig.style,
        background: "#ffffff",
        color: "#222222",
        border: "1px solid #E6F0FC",
      },
      progressStyle: {
        background: "#227EEB",
      },
      ...options,
    });
  },

  // For custom styling or longer messages
  custom: (message, type = "default", options = {}) => {
    toast(message, {
      ...toastConfig,
      type,
      style: {
        ...toastConfig.style,
        background: "#ffffff",
        color: "#222222",
        border: "1px solid #E7E8E8",
      },
      progressStyle: {
        background: "#227EEB",
      },
      ...options,
    });
  },
};

export default toaster;
