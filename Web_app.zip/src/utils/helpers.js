import toaster from "./toaster";

export const parseJSON = (data) => {
  try {
    return JSON.parse(data);
  } catch (error) {
    console.error("Failed to parse JSON:", error);
    return null;
  }
};

export function formatDatev1(dateString) {
  const date = new Date(dateString);

  const day = date.getUTCDate(); // getUTCDate to avoid timezone shifts
  const month = date.toLocaleString("en-US", {
    month: "short",
    timeZone: "UTC",
  });
  const year = date.getUTCFullYear();

  return `${day} ${month}, ${year}`;
}

export function percentToNumber(str) {
  try {
    return parseInt(str.replace?.("%", ""), 10);
  } catch {
    console.error("could parse value in percent to number");
    return str;
  }
}

export function formatTimev2(isoString, sep = " at ") {
  const date = new Date(isoString);

  const options = {
    hour12: true,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    day: "2-digit",
    month: "short",
    year: "numeric",
  };

  const formatted = date.toLocaleString("en-IN", options);

  // toLocaleString gives "04 Sept 2024, 07:30:25 pm"
  const [dayPart, timePart] = formatted.split(", ");

  // We want => "07:30:25 PM - 04 Sep, 2024"
  const parts = formatted.match(
    /(\d{2}) (\w+)\.? (\d{4}), (\d{2}):(\d{2}):(\d{2}) (\w{2})/i
  );

  if (!parts) return formatted; // fallback

  const [_, day, month, year, hour, minute, second, ampm] = parts;
  return `${day} ${month}, ${year}${sep}${hour}:${minute} ${ampm.toUpperCase()}`;
}

export function apiLayoutsDataMapper(layouts) {
  return (
    layouts?.map((item) => {
      let row = item?.rows;
      let col = item?.columns;
      let layout = item?.layout?.toLowerCase()?.includes("landscape")
        ? "landscape"
        : "portrait";
      if (layout === "portrait")
        return {
          ...item,
          row: col,
          col: row,
          layout: layout,
        };

      return {
        ...item,
        row: row,
        col: col,
        layout: layout,
      };
    }) || []
  );
}

export const payloadGeneratorForControlPanel = (
  channelData,
  deviceId,
  channelId
) => {
  if (
    channelData.type === "sensor" ||
    channelData.type === "rtu_light_sensor" ||
    channelData.type === "rtu_CO2" ||
    channelData.type === "rtu_HMI" ||
    channelData.type === "io_pir"
  ) {
    return {
      // type: channelData.type,
      type: "sensor",
      name: channelData.name,
      installed: channelData.installed,
      properties: {
        ...channelData.properties,
        installed: channelData.installed,
      },
    };
  }
  if (
    channelData.type === "led" ||
    channelData.type === "expansion_led" ||
    channelData.type === "expansion_color_lights"
  ) {
    return {
      // type: channelData.type,
      type: "led",
      name: channelData.name,
      properties: {
        ...channelData.properties,
        installed: channelData.installed,
      },
      status: channelData.status,
      installed: channelData.installed,
    };
  }
  if (channelData.type === "shade") {
    return {
      // type: channelData.type,
      type: "shade",
      name: channelData.name,
      properties: {
        ...channelData.properties,
        installed: channelData.installed,
      },
      installed: channelData.installed,
    };
  }
  return {};
};

export function findTemplateById(templates, templateId) {
  if (!Array.isArray(templates)) return null;

  const template = templates.find((t) => t._id === templateId);
  return template || null;
}

// Transform permissions data for API payload
export function transformPermissionsForAPI(permissions) {
  const transformedPermissions = {};

  Object.entries(permissions).forEach(([moduleKey, moduleData]) => {
    transformedPermissions[moduleKey] = {};

    // Go through each category and extract the checked accesses
    if (moduleData?.permissions?.categories) {
      moduleData.permissions.categories.forEach((category) => {
        if (category?.accesses && category?.name) {
          const categoryKey = category.name
            .replace?.(/\s+/g, "_")
            .toLowerCase();
          transformedPermissions[moduleKey][categoryKey] = {};
          category.accesses.forEach((access) => {
            if (access?.value) {
              transformedPermissions[moduleKey][categoryKey][access.value] =
                Boolean(access.checked);
            }
          });
        }
      });
    }
  });

  return transformedPermissions;
}

export function transformPermissionsForUI(data) {
  const result = {};

  for (const [section, subSections] of Object.entries(data)) {
    let access = false;
    const newSubSections = {};

    for (const [subSection, permissions] of Object.entries(subSections)) {
      const transformed = {
        addModify: permissions["Add/Update"],
        delete: permissions["Delete"],
        readOnly: permissions["View"],
      };

      // if any permission is true, section gets access
      if (
        permissions["Add/Update"] ||
        permissions["Delete"] ||
        permissions["View"]
      ) {
        access = true;
      }

      newSubSections[subSection] = transformed;
    }

    result[section] = {
      access,
      ...newSubSections,
    };
  }

  return result;
}

// Transform role data permissions to match the categories format for viewing
export function mapRoleDataToPermissions(rolePermissions, categoriesData) {
  if (!rolePermissions || !categoriesData) return categoriesData;

  const mappedPermissions = JSON.parse(JSON.stringify(categoriesData)); // Deep copy

  Object.keys(mappedPermissions).forEach((moduleKey) => {
    if (
      rolePermissions[moduleKey] &&
      mappedPermissions[moduleKey]?.permissions?.categories
    ) {
      mappedPermissions[moduleKey].permissions.categories.forEach(
        (category) => {
          const categoryKey = category.name
            .replace?.(/\s+/g, "_")
            .toLowerCase();
          const roleCategory = rolePermissions[moduleKey][categoryKey];

          if (roleCategory && category.accesses) {
            category.accesses.forEach((access) => {
              switch (access.value) {
                case "fullAccess":
                  // Full access is true when all permissions are true
                  access.checked =
                    roleCategory["View"] &&
                    roleCategory["Add/Update"] &&
                    roleCategory["Delete"];
                  break;
                case "readOnly":
                  access.checked = roleCategory["View"] || false;
                  break;
                case "addModify":
                  access.checked = roleCategory["Add/Update"] || false;
                  break;
                default:
                  access.checked = false;
              }
            });
          }
        }
      );
    }
  });

  return mappedPermissions;
}

export function extractPortAndSensorFromSensorId(str) {
  const regex = /_Port-(\d+)_(\d+)/;
  const match = str.match(regex);

  if (match) {
    return {
      port: match[1],
      sensorAddress: match[2],
    };
  }

  return null; // if pattern doesn't match
}

export function padStart(string, targetLength = 2, padString = "0") {
  if (string === undefined || string === null) return "NaN";
  return String(string).padStart(targetLength, padString);
}

export const sceneGroupToTemplateGroup = (sceneGroup) => {
  const data = {
    id: sceneGroup.groupId,
    group_name: sceneGroup.groupName,
    type: "group",
    elements: [],
  };
  return data;
};

export const convertNormalChannelToElementInScene = (channel) => {
  if (channel?.channelType === "led")
    return {
      deviceId: channel?.deviceId,
      type: "led",
      name: channel?.channelName,
      channelId: channel?.channelId,
      status: channel?.channelStatus,
      properties: {
        brightness: channel?.brightness,
        powerMin: channel?.properties?.powerMin,
        powerMax: channel?.properties?.powerMax,
      },
      deviceName: channel?.deviceName,
      channelType: "led",
      isMainChannel: channel?.isMainChannel ? true : false,
    };
};

export const convertGroupChannelToElementInScene = (groupData) => {
  const elements = [];
  groupData?.devices?.forEach((device) => {
    device?.sceneChannels?.forEach((channel) => {
      const {
        channelId,
        channelName,
        channelStatus,
        channelType,
        ...remaining
      } = channel;
      elements.push({
        deviceId: device?.deviceId,
        deviceName: device?.deviceName,
        deviceType: device?.deviceType,
        id: channelId,
        channelId: channelId,
        channelName: channelName,
        channelType: channelType,
        channelStatus: channelStatus,
        name: channelName,
        type: channelType,
        status: channelStatus,
        properties: {
          ...remaining,
        },
      });
    });
  });
  return {
    group_name: groupData?.groupName,
    id: groupData?.groupId,
    type: "group",
    elements: elements,
    ...groupData,
  };
};

export const getWidgetLayout = (templateLayout, realRow, realCol) => {
  if (realRow === 1 && realCol === 1)
    if (templateLayout === "landscape") return "portrait";
    else return "landscape";
  return templateLayout;
};

export const showToasterFromSocketAlerts = (data, permissions) => {
  if (!data?.type || !data?.message || !permissions) return;

  const map = {
    Device: permissions?.DEVICE_MANAGEMENT?.device_control,
    Group: permissions?.INTELLIGENT_CONTROL?.group_management,
    Scene: permissions?.INTELLIGENT_CONTROL?.scene_management,
    Template: permissions?.INTELLIGENT_CONTROL?.template_management,
    Campus: permissions?.CAMPUS_MANAGEMENT?.campus_management,
    Building: permissions?.CAMPUS_MANAGEMENT?.building_management,
    Floor: permissions?.CAMPUS_MANAGEMENT?.floor_management,
    Zone: permissions?.CAMPUS_MANAGEMENT?.zone_management,
    User: permissions?.USER_MANAGEMENT?.user_accounts,
    Role: permissions?.USER_MANAGEMENT?.role_management,
  };

  const target = map?.[data.type];
  if (target?.readOnly) {
    toaster.info(data.message);
  }
};

export const getGaugeColor = (value, items) => {
  let cumulative = 0;

  for (let item of items) {
    cumulative += item.length;
    if (value <= cumulative) {
      return item.color;
    }
  }

  return items[items.length - 1]?.color || null; // fallback
};

export const createWidgetsStructure = (selectedWidgets, layout) => {
  const weatherWidget = selectedWidgets.find((w) => w.type === "weather");

  const mergeIfTwo = (mainTypeWidget) => {
    if (!mainTypeWidget) return null;
    if (layout === "portrait" && mainTypeWidget.type === "sensor") {
      return null;
    }

    if (selectedWidgets.length !== 2) return null;

    const other = selectedWidgets.find((w) => w !== mainTypeWidget);

    return [
      {
        ...mainTypeWidget,
        midElement: other,
      },
    ];
  };

  const weatherMerged = mergeIfTwo(weatherWidget);
  if (weatherMerged)
    return {
      widgets: weatherMerged,
      isWeather: true,
      isSensor: false,
    };

  const sensorWidget = selectedWidgets.find((w) => w.type === "sensor");
  if (sensorWidget) {
    selectedWidgets = [...selectedWidgets].sort((a, b) => {
      if (a.type === "sensor" && b.type !== "sensor") return 1;
      if (a.type !== "sensor" && b.type === "sensor") return -1;
      return 0;
    });
  }
  const sensorMerged = mergeIfTwo(sensorWidget);
  if (sensorMerged)
    return { widgets: sensorMerged, isWeather: false, isSensor: true };

  return {
    widgets: selectedWidgets,
    isWeather: weatherWidget ? true : false,
    isSensor: sensorWidget ? true : false,
  };
};

export function getAmphereMultipler(device_type, typeTypeMatters=true) {
  if (!typeTypeMatters) return 100;
  switch (device_type) {
    case "ba-200":
      return 160;
    default:
      return 100;
  }
}
