export const countryCodes = [
  // US/Canada (NANP) — 10 digits, area & exchange can’t start with 0 or 1
  { id: "1", iso: "US", phonecode: "+1", regex: "^[2-9]\\d{2}[2-9]\\d{6}$" },

  // India — 10 digits, starts with 6/7/8/9
  { id: "2", iso: "IN", phonecode: "+91", regex: "^[6-9]\\d{9}$" },

  // China — 11 digits, starts with 13–19
  { id: "3", iso: "CN", phonecode: "+86", regex: "^1[3-9]\\d{9}$" },
];
