// ./hooks/useAuth.js
import {
  useInfiniteQuery,
  useMutation,
  useQuery,
  useQueryClient,
} from "react-query";
import {
  createBuilding,
  createCampus,
  createFloor,
  forgotPassword,
  verifyCode,
  resetPassword,
  exportMqttLogs,
  exportEventLogs,
  getCampusOptions,
  getBuildingById,
  getBuildings,
  getBuildingOptionsByCampus,
  getCampusById,
  getCampuses,
  getCampusTypes,
  getFloors,
  getFloorsOptionsByBuilding,
  getFloorById,
  signIn,
  signUp,
  createZone,
  getZones,
  deleteCampus,
  deleteBuilding,
  deleteFloor,
  updateCampus,
  updateBuilding,
  updateFloor,
  getZoneById,
  updateZone,
  deleteZone,
  getDiscoveryDevices,
  getConfiguredDevices,
  getDeviceControlDCCount,
  getDeviceDetails,
  getDeviceChannelsByDeviceId,
  getZonesOptionsByFloor,
  configureDevice,
  addDevice,
  getActiveDevicesForGroup,
  getDeviceChannelsForGroup,
  createGroup,
  getGroupById,
  updateGroup,
  deleteGroup,
  getGroups,
  getAllGroupOptions,
  getConfiguredDevicesOptions,
  getGroupDetails,
  getMultipleGroupDetails,
  getDeviceSceneDetails,
  createScene,
  getScenes,
  getSceneById,
  updateScene,
  deleteScene,
  updateCampusStatus,
  updateBuildingStatus,
  updateFloorStatus,
  updateZoneStatus,
  deleteConfiguredDevice,
  deleteThirdPartyDevice,
  updateConfiguredDevice,
  updateThirdPartyDevice,
  updateDeviceChannel,
  getDeviceOptionsForSensors,
  getSensorsByDevice,
  getMotions,
  getNoMotions,
  createSensor,
  getSensorById,
  updateSensor,
  getTemplateList,
  getLayoutList,
  createTemplate,
  updateTemplate,
  deleteTemplate,
  getSensors,
  deleteSensor,
  triggerEvent,
  createUser,
  createRole,
  updateRole,
  getAllDevices,
  getUsers,
  getTemplateById,
  getRolesCategories,
  getRoleById,
  getRoles,
  getRolesOptions,
  getDeviceIdControlSystem,
  getAllDevicesInControlSystem,
  getAllGroupsInControlSystem,
  getAllScenesInControlSystem,
  getUserInfo,
  changeUserPassword,
  updateUser,
  updateUserStatus,
  deleteUser,
  deleteRole,
  updateRoleStatus,
  getMqttLogs,
  getEventLogs,
  getCampusHierarchy,
  getRoleBasedTabs,
  getRoleTabControlData,
  updateUserLocation,
  getTemplateListInControlSystem,
  getDashboardSummary,
  getDashboardZoneStats,
  getDashboardDeviceInfo,
  getDashboardAlerts,
  initializeTimezones,
  createTimezone,
  getTimezones,
  getAllTimezoneOptions,
  updateTimezone,
  deleteTimezone,
  createWeatherLocation,
  getWeatherLocations,
  updateWeatherLocation,
  deleteWeatherLocation,
  createWidget,
  getWidgetById,
  updateWidget,
  deleteWidget,
  getWeatherData,
  getAQIData,
  getWeatherAndAQI,
  getOpenMeteoWeather,
  getCreatedWidgets,
  getFirstWeatherLocation,
  getDashboardDeviceGroups,
  resendOTP,
  getSensorsForWidgetCreation,
  deleteChannelFromControlPanel,
} from "./queryFunctions";
import QUERY_KEYS from "./queryKeys";
import CONFIG from "../config";

export const useSignUp = ({ ...config }) => {
  return useMutation(signUp, {
    ...config,
  });
};

// Add to ./hooks/useAuth.js
export const useSignIn = ({ ...config }) => {
  return useMutation(signIn, {
    ...config,
  });
};

// Add to ./hooks/useAuth.js
export const useForgotPassword = ({ ...config }) => {
  return useMutation(forgotPassword, {
    ...config,
  });
};

export const useResendOTP = ({ ...config }) => {
  return useMutation(resendOTP, {
    ...config,
  });
};

export const useVerifyCode = ({ ...config }) => {
  return useMutation(verifyCode, {
    ...config,
  });
};

export const useResetPassword = ({ ...config }) => {
  return useMutation(resetPassword, {
    ...config,
  });
};

export const useGetCampusTypes = () => {
  return useQuery([QUERY_KEYS.CAMPUSTYPES], getCampusTypes, {
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
  });
};

export const useCreateCampus = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(createCampus, {
    onSuccess: (data, { campusId }) => {
      queryClient.invalidateQueries([QUERY_KEYS.ALL_CAMPUS_OPTIONS]);
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useGetCampuses = ({ search, status, limit = 10 }) => {
  return useInfiniteQuery(
    [QUERY_KEYS.CAMPUSES, search, status],
    ({ pageParam = 1 }) =>
      getCampuses({ page: pageParam, limit, search, status }),
    {
      getNextPageParam: (lastPage, pages) => {
        const pagination = lastPage?.data?.pagination;

        if (pagination && pagination.hasNextPage) {
          return pagination.currentPage + 1;
        }
        return undefined;
      },
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetCampusOptions = () => {
  return useQuery([QUERY_KEYS.ALL_CAMPUS_OPTIONS], () => getCampusOptions(), {
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
  });
};

export const useGetCampusById = (campusId) => {
  return useQuery(
    [QUERY_KEYS.CAMPUS, campusId],
    () => getCampusById(campusId),
    {
      enabled: !!campusId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useUpdateCampus = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ campusId, campusData }) => updateCampus({ campusId, campusData }),
    {
      onSuccess: (data, { campusId }) => {
        queryClient.invalidateQueries([QUERY_KEYS.CAMPUSES]);
        queryClient.invalidateQueries([QUERY_KEYS.CAMPUS, campusId]);
        queryClient.invalidateQueries([QUERY_KEYS.ALL_CAMPUS_OPTIONS]);
        onSuccess && onSuccess(data);
      },
      ...config,
    }
  );
};

export const useCreateBuilding = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();

  return useMutation(
    ({ campusId, payload }) => createBuilding(campusId, payload),
    {
      onSuccess: (data, { campusId }) => {
        queryClient.invalidateQueries({
          queryKey: [QUERY_KEYS.BUILDINGS],
          exact: false,
        });
        queryClient.invalidateQueries([
          QUERY_KEYS.ALL_BUILDING_OPTIONS,
          campusId,
        ]);

        onSuccess && onSuccess(data);
      },
      ...config,
    }
  );
};

export const useGetBuildings = ({ search, status, limit = 10 }) => {
  return useInfiniteQuery(
    [QUERY_KEYS.BUILDINGS, search, status],
    ({ pageParam = 1 }) =>
      getBuildings({ page: pageParam, limit, search, status }),
    {
      getNextPageParam: (lastPage, pages) => {
        const pagination = lastPage?.data?.pagination;

        if (pagination && pagination.hasNextPage) {
          return pagination.currentPage + 1;
        }
        return undefined;
      },
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetBuildingById = (buildingId) => {
  return useQuery(
    [QUERY_KEYS.BUILDING, buildingId],
    () => getBuildingById(buildingId),
    {
      enabled: !!buildingId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useUpdateBuilding = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ buildingId, buildingData }) =>
      updateBuilding({ buildingId, buildingData }),
    {
      onSuccess: (data, { buildingId }) => {
        queryClient.invalidateQueries([QUERY_KEYS.BUILDINGS]);
        queryClient.invalidateQueries([QUERY_KEYS.BUILDING, buildingId]);
        queryClient.invalidateQueries([QUERY_KEYS.ALL_BUILDING_OPTIONS]);
        onSuccess && onSuccess(data);
      },
      ...config,
    }
  );
};

export const useUpdateFloor = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ floorId, floorData }) => updateFloor({ floorId, floorData }),
    {
      onSuccess: (data, { floorId }) => {
        queryClient.invalidateQueries([QUERY_KEYS.FLOORS]);
        queryClient.invalidateQueries([QUERY_KEYS.FLOOR, floorId]);
        queryClient.invalidateQueries([QUERY_KEYS.ALL_FLOOR_OPTIONS]);
        onSuccess && onSuccess(data);
      },
      ...config,
    }
  );
};

export const useUpdateZone = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ zoneId, zoneData }) => updateZone({ zoneId, zoneData }),
    {
      onSuccess: (data, { zoneId }) => {
        queryClient.invalidateQueries([QUERY_KEYS.ZONES]);
        queryClient.invalidateQueries([QUERY_KEYS.ZONE, zoneId]);
        onSuccess && onSuccess(data);
      },
      ...config,
    }
  );
};

export const useDeleteZone = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteZone, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.ZONES]);
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useGetBuildingOptionsByCampus = (campusId) => {
  return useQuery(
    [QUERY_KEYS.ALL_BUILDING_OPTIONS, campusId],
    () => getBuildingOptionsByCampus(campusId),
    {
      enabled: !!campusId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useCreateFloor = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ buildingId, floorData }) => createFloor(buildingId, floorData),
    {
      onSuccess: (data, variables) => {
        queryClient.invalidateQueries([QUERY_KEYS.FLOORS]);
        queryClient.invalidateQueries([QUERY_KEYS.CAMPUS]);
        onSuccess?.(data, variables);
      },
      ...config,
    }
  );
};

export const useGetFloors = ({ search, status, limit = 10 }) => {
  return useInfiniteQuery(
    [QUERY_KEYS.FLOORS, search, status],
    ({ pageParam = 1 }) =>
      getFloors({ page: pageParam, limit, search, status }),
    {
      getNextPageParam: (lastPage, pages) => {
        const pagination = lastPage?.data?.pagination;

        if (pagination && pagination.hasNextPage) {
          return pagination.currentPage + 1;
        }
        return undefined;
      },
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetFloorsOptionsByBuilding = (buildingId) => {
  return useQuery(
    [QUERY_KEYS.ALL_FLOOR_OPTIONS, buildingId],
    () => getFloorsOptionsByBuilding(buildingId),
    {
      enabled: !!buildingId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetFloorById = (floorId) => {
  return useQuery([QUERY_KEYS.FLOOR, floorId], () => getFloorById(floorId), {
    enabled: !!floorId,
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
  });
};

export const useCreateZone = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(({ floorId, zoneData }) => createZone(floorId, zoneData), {
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries([QUERY_KEYS.ZONES]);
      queryClient.invalidateQueries([
        QUERY_KEYS.ALL_ZONE_OPTIONS,
        variables.floorId,
      ]);
      onSuccess?.(data, variables);
    },
    ...config,
  });
};

export const useGetZones = ({ search, status, limit = 10 }) => {
  return useInfiniteQuery(
    [QUERY_KEYS.ZONES, search, status],
    ({ pageParam = 1 }) => getZones({ page: pageParam, limit, search, status }),
    {
      getNextPageParam: (lastPage, pages) => {
        const pagination = lastPage?.data?.pagination;

        if (pagination && pagination.hasNextPage) {
          return pagination.currentPage + 1;
        }
        return undefined;
      },
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useDeleteCampus = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteCampus, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.CAMPUSES]);
      queryClient.invalidateQueries([QUERY_KEYS.ALL_CAMPUS_OPTIONS]);
      onSuccess?.(data);
    },
    ...config,
  });
};

export const useDeleteBuilding = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteBuilding, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.BUILDINGS]);
      queryClient.invalidateQueries([QUERY_KEYS.ALL_BUILDING_OPTIONS]);
      onSuccess?.(data);
    },
    ...config,
  });
};

export const useDeleteFloor = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteFloor, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.FLOORS]);
      queryClient.invalidateQueries([QUERY_KEYS.ALL_FLOOR_OPTIONS]);
      onSuccess?.(data);
    },
    ...config,
  });
};

export const useGetZoneById = (zoneId) => {
  return useQuery([QUERY_KEYS.ZONE, zoneId], () => getZoneById(zoneId), {
    enabled: !!zoneId,
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
  });
};

export const useGetZonesOptionsByFloor = (floorId) => {
  return useQuery(
    [QUERY_KEYS.ALL_ZONE_OPTIONS, floorId],
    () => getZonesOptionsByFloor(floorId),
    {
      enabled: !!floorId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetDiscoveryDevices = (search, device_id) => {
  return useQuery(
    [QUERY_KEYS.DISCOVERY_DEVICES, search, device_id],
    () => getDiscoveryDevices({ search, device_id: device_id || undefined }),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetConfiguredDevices = (search, device_id, active = true) => {
  return useQuery(
    [QUERY_KEYS.CONFIGURED_DEVICES, search, device_id, active],
    () =>
      getConfiguredDevices({
        search,
        device_id: device_id || undefined,
        active,
      }),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetDeviceControlDCCount = () => {
  return useQuery(QUERY_KEYS.DEVICE_CONTROL_DC_COUNT, getDeviceControlDCCount, {
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
  });
};

export const useGetDeviceDetails = (deviceId) => {
  return useQuery(
    [QUERY_KEYS.DEVICE_DETAILS, deviceId],
    () => getDeviceDetails(deviceId),
    {
      enabled: !!deviceId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetDeviceChannelsByDeviceId = (deviceId, onSuccess) => {
  return useQuery(
    [QUERY_KEYS.DEVICE_CHANNELS, deviceId],
    () => getDeviceChannelsByDeviceId(deviceId),
    {
      enabled: !!deviceId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
      onSuccess: onSuccess,
    }
  );
};

export const useConfigureDevice = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(configureDevice, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.DISCOVERY_DEVICES]);
      queryClient.invalidateQueries([QUERY_KEYS.CONFIGURED_DEVICES]);
      queryClient.invalidateQueries([QUERY_KEYS.DEVICE_CONTROL_DC_COUNT]);
      onSuccess?.(data);
    },
    ...config,
  });
};

export const useAddDevice = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(addDevice, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.CONFIGURED_DEVICES]);
      queryClient.invalidateQueries([QUERY_KEYS.DEVICE_CONTROL_DC_COUNT]);
      onSuccess?.(data);
    },
    ...config,
  });
};

export const useGetActiveDevicesOptionsForGroup = ({ type }) => {
  return useQuery(
    QUERY_KEYS.GET_ACTIVE_DEVICES_OPTIONS_FOR_GROUP,
    () => getActiveDevicesForGroup(type),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetDeviceChannelsForGroup = (deviceIds) => {
  return useQuery(
    [QUERY_KEYS.GET_DEVICE_CHANNELS_FOR_GROUP, deviceIds],
    () => getDeviceChannelsForGroup(deviceIds),
    {
      enabled: !!deviceIds?.length,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useCreateGroup = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(createGroup, {
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.GROUPS],
        exact: false,
      });
      onSuccess?.(data);
    },
    ...config,
  });
};

export const useGetGroupById = (groupId, config = {}) => {
  return useQuery([QUERY_KEYS.GROUPS, groupId], () => getGroupById(groupId), {
    enabled: !!groupId,
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
    ...config,
  });
};

export const useUpdateGroup = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(updateGroup, {
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.GROUPS],
        exact: false,
      });
      queryClient.invalidateQueries([QUERY_KEYS.ALL_GROUP_OPTIONS]);
      onSuccess?.(data);
    },
    ...config,
  });
};

export const useDeleteGroup = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteGroup, {
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.GROUPS],
        exact: false,
      });
      queryClient.invalidateQueries([QUERY_KEYS.ALL_GROUP_OPTIONS]);
      onSuccess?.(data);
    },
    ...config,
  });
};

export const useGetGroups = ({
  page = 1,
  limit = 10,
  search = "",
  device_id,
} = {}) => {
  return useQuery(
    [QUERY_KEYS.GROUPS, page, limit, search, device_id],
    () => getGroups({ page, limit, search, device_id: device_id || undefined }),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetAllGroupOptions = () => {
  return useQuery([QUERY_KEYS.ALL_GROUP_OPTIONS], getAllGroupOptions, {
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
  });
};

export const useGetConfiguredDevicesOptions = () => {
  return useQuery(
    [QUERY_KEYS.CONFIGURED_DEVICES_OPTIONS],
    getConfiguredDevicesOptions,
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetGroupDetails = (groupId) => {
  return useQuery(
    [QUERY_KEYS.GROUP_DETAILS, groupId],
    () => getGroupDetails(groupId),
    {
      enabled: !!groupId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetMultipleGroupDetails = (groupIds) => {
  return useQuery(
    [QUERY_KEYS.MULTIPLE_GROUP_DETAILS, groupIds],
    () => getMultipleGroupDetails(groupIds),
    {
      enabled: !!groupIds && groupIds.length > 0,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetDeviceSceneDetails = (deviceId) => {
  return useQuery(
    [QUERY_KEYS.DEVICE_SCENE_DETAILS, deviceId],
    () => getDeviceSceneDetails(deviceId),
    {
      enabled: !!deviceId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useCreateScene = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(createScene, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.SCENES]);
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useGetSceneById = (sceneId, config = {}) => {
  return useQuery([QUERY_KEYS.SCENES, sceneId], () => getSceneById(sceneId), {
    enabled: !!sceneId,
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
    ...config,
  });
};

export const useUpdateScene = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(updateScene, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.SCENES]);
      onSuccess?.(data);
    },
    ...config,
  });
};

export const useDeleteScene = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteScene, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.SCENES]);
      onSuccess?.(data);
    },
    ...config,
  });
};

export const useGetScenes = ({ search, limit = 10 }) => {
  return useInfiniteQuery(
    [QUERY_KEYS.SCENES, search],
    ({ pageParam = 1 }) => getScenes({ page: pageParam, limit, search }),
    {
      getNextPageParam: (lastPage, pages) => {
        const pagination = lastPage?.data?.pagination;
        if (pagination) {
          return pagination.page < pagination.pages
            ? pagination.page + 1
            : undefined;
        }
        // Fallback pagination logic
        const currentPage = pages.length;
        const totalItems = lastPage?.data?.total || 0;
        const hasMore = currentPage * limit < totalItems;
        return hasMore ? currentPage + 1 : undefined;
      },
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useUpdateCampusStatus = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ campusId, status }) => updateCampusStatus({ campusId, status }),
    {
      onSuccess: (data, variables) => {
        queryClient.invalidateQueries([QUERY_KEYS.CAMPUSES]);
        queryClient.invalidateQueries([QUERY_KEYS.CAMPUS, variables.campusId]);
        onSuccess?.(data);
      },
      ...config,
    }
  );
};

export const useUpdateBuildingStatus = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ buildingId, status }) => updateBuildingStatus({ buildingId, status }),
    {
      onSuccess: (data, variables) => {
        queryClient.invalidateQueries([QUERY_KEYS.BUILDINGS]);
        queryClient.invalidateQueries([
          QUERY_KEYS.BUILDING,
          variables.buildingId,
        ]);
        onSuccess?.(data);
      },
      ...config,
    }
  );
};

export const useUpdateFloorStatus = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ floorId, status }) => updateFloorStatus({ floorId, status }),
    {
      onSuccess: (data, variables) => {
        queryClient.invalidateQueries([QUERY_KEYS.FLOORS]);
        queryClient.invalidateQueries([QUERY_KEYS.FLOOR, variables.floorId]);
        onSuccess?.(data);
      },
      ...config,
    }
  );
};

export const useUpdateZoneStatus = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ zoneId, status }) => updateZoneStatus({ zoneId, status }),
    {
      onSuccess: (data, variables) => {
        queryClient.invalidateQueries([QUERY_KEYS.ZONES]);
        queryClient.invalidateQueries([QUERY_KEYS.ZONE, variables.zoneId]);
        onSuccess?.(data);
      },
      ...config,
    }
  );
};

export const useDeleteConfiguredDevice = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteConfiguredDevice, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.CONFIGURED_DEVICES]);
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useDeleteThirdPartyDevice = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteThirdPartyDevice, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.CONFIGURED_DEVICES]);
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useUpdateConfiguredDevice = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ deviceId, deviceData }) =>
      updateConfiguredDevice({ deviceId, deviceData }),
    {
      onSuccess: (data, { deviceId }) => {
        queryClient.invalidateQueries([QUERY_KEYS.CONFIGURED_DEVICES]);
        queryClient.invalidateQueries([QUERY_KEYS.DEVICE_DETAILS, deviceId]);
        onSuccess && onSuccess(data);
      },
      ...config,
    }
  );
};

export const useUpdateThirdPartyDevice = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ deviceId, deviceData }) =>
      updateThirdPartyDevice({ deviceId, deviceData }),
    {
      onSuccess: (data, { deviceId }) => {
        queryClient.invalidateQueries([QUERY_KEYS.CONFIGURED_DEVICES]);
        queryClient.invalidateQueries([QUERY_KEYS.DEVICE_DETAILS, deviceId]);
        onSuccess && onSuccess(data);
      },
      ...config,
    }
  );
};

export const useUpdateDeviceChannel = ({ onSuccess, ...config }) => {
  // const queryClient = useQueryClient();
  return useMutation(
    ({ deviceId, channelId, channelData }) =>
      updateDeviceChannel({ deviceId, channelId, channelData }),
    {
      onSuccess: (data, { deviceId, channelId }) => {
        // queryClient.invalidateQueries([QUERY_KEYS.DEVICE_CHANNELS, deviceId]);
        // queryClient.invalidateQueries([QUERY_KEYS.DEVICE_DETAILS, deviceId]);
        onSuccess && onSuccess(data);
      },
      ...config,
    }
  );
};

export const useGetDeviceOptionsForSensors = () => {
  return useQuery(
    [QUERY_KEYS.DEVICE_OPTIONS_FOR_SENSORS],
    getDeviceOptionsForSensors,
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetSensorsByDevice = (deviceId) => {
  return useQuery(
    [QUERY_KEYS.SENSORS_BY_DEVICE, deviceId],
    () => getSensorsByDevice(deviceId),
    {
      enabled: !!deviceId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetMotions = () => {
  return useQuery([QUERY_KEYS.MOTIONS], getMotions, {
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
  });
};

export const useGetNoMotions = () => {
  return useQuery([QUERY_KEYS.NO_MOTIONS], getNoMotions, {
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
  });
};

export const useCreateSensor = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(createSensor, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.SENSORS_BY_DEVICE]);
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.SENSORS],
        exact: false,
      });
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useGetSensorById = (sensorId) => {
  return useQuery(
    [QUERY_KEYS.SENSOR_BY_ID, sensorId],
    () => getSensorById(sensorId),
    {
      enabled: !!sensorId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useUpdateSensor = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(updateSensor, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.SENSORS_BY_DEVICE]);
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.SENSORS],
        exact: false,
      });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.SENSOR_BY_ID],
        exact: false,
      });
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useGetTemplates = ({
  page = 1,
  limit = 10,
  search = "",
  layout,
} = {}) => {
  return useQuery(
    [QUERY_KEYS.TEMPLATE_LIST, page, limit, search, layout],
    () => getTemplateList({ page, limit, search, layout: layout || undefined }),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetTemplatesInControlSystem = (search = "") => {
  return useQuery(
    [QUERY_KEYS.TEMPLATES_IN_CONTROL_SYSTEM, search],
    () => getTemplateListInControlSystem(search),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetTemplatesById = ({ id, ...config }) => {
  return useQuery([QUERY_KEYS.TEMPLATE_BY_ID, id], () => getTemplateById(id), {
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
    retry: 0,
    ...config,
  });
};

export const useGetLayoutList = () => {
  return useQuery([QUERY_KEYS.LAYOUT_LIST], getLayoutList, {
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
  });
};

export const useCreateTemplate = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(createTemplate, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.TEMPLATE_LIST]);
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useUpdateTemplate = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ templateId, templateData }) =>
      updateTemplate({ templateId, templateData }),
    {
      onSuccess: (data, { templateId }) => {
        queryClient.invalidateQueries([QUERY_KEYS.TEMPLATE_LIST]);
        onSuccess && onSuccess(data);
      },
      ...config,
    }
  );
};

export const useDeleteTemplate = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteTemplate, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.TEMPLATE_LIST]);
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useGetSensors = ({
  page = 1,
  limit = 10,
  search = "",
  deviceFilter,
} = {}) => {
  return useQuery(
    [QUERY_KEYS.SENSORS, page, limit, search, deviceFilter],
    () => getSensors({ page, limit, search, deviceFilter }),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useDeleteSensor = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteSensor, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.SENSORS]);
      queryClient.invalidateQueries([QUERY_KEYS.SENSORS_BY_DEVICE]);
      onSuccess?.(data);
    },
    ...config,
  });
};

// User Management Hooks
export const useCreateUser = ({ onSuccess, ...config }) => {
  return useMutation(createUser, {
    onSuccess: (data) => {
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

// Role Management Hooks
export const useCreateRole = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(createRole, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.ROLES_CATEGORIES]);
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useUpdateRole = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(updateRole, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.ROLES]);
      queryClient.invalidateQueries([QUERY_KEYS.ROLE_BY_ID]);
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useGetAllDevices = () => {
  return useQuery([QUERY_KEYS.ALL_DEVICES], getAllDevices, {
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
  });
};

export const useGetUsers = ({
  page = 1,
  limit = 10,
  status,
  search = "",
  filterData,
  sortBy,
  sortOrder,
} = {}) => {
  return useQuery(
    [
      QUERY_KEYS.USERS,
      page,
      limit,
      status,
      search,
      filterData,
      sortBy,
      sortOrder,
    ],
    () =>
      getUsers({ page, limit, status, search, filterData, sortBy, sortOrder }),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useTriggerEvent = ({ onSuccess, onError, ...config } = {}) => {
  const queryClient = useQueryClient();
  return useMutation(triggerEvent, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([
        QUERY_KEYS.GET_ALL_GROUPS_IN_CONTROL_SYSTEM,
      ]);
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.GROUPS],
        exact: false,
      });
      onSuccess && onSuccess(data);
    },
    onError: (error) => {
      onError && onError(error);
    },
    ...config,
  });
};

export const useGetRolesCategories = () => {
  return useQuery([QUERY_KEYS.ROLES_CATEGORIES], getRolesCategories, {
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
  });
};

export const useGetRoleById = (roleId) => {
  return useQuery([QUERY_KEYS.ROLE_BY_ID, roleId], () => getRoleById(roleId), {
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
    enabled: !!roleId,
  });
};

export const useGetRoles = ({
  status,
  page = 1,
  limit = 10,
  search = "",
  sortBy,
  sortOrder,
} = {}) => {
  return useQuery(
    [QUERY_KEYS.ROLES, page, limit, search, sortBy, sortOrder, status],
    () => getRoles({ page, limit, search, sortBy, sortOrder, status }),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetRolesOptions = ({ check }) => {
  return useQuery([QUERY_KEYS.ROLES_OPTIONS], () => getRolesOptions(check), {
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
  });
};

export const useGetDeviceByIdInControlSystem = (deviceId, onSuccess) => {
  return useQuery(
    [QUERY_KEYS.DEVICE_IN_CONTROL_SYSTEM, deviceId],
    () => getDeviceIdControlSystem(deviceId),
    {
      enabled: !!deviceId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
      refetchInterval: CONFIG.REFETCH_INTERVAL,
      onSuccess: onSuccess,
    }
  );
};

export const useGetDeviceListInControlSystem = (search = "") => {
  return useQuery(
    [QUERY_KEYS.GET_ALL_DEIVICES_IN_CONTROL_SYSTEM, search],
    () => getAllDevicesInControlSystem(search),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetAllGroupsInControlSystem = (search = "", onSuccess) => {
  return useQuery(
    [QUERY_KEYS.GET_ALL_GROUPS_IN_CONTROL_SYSTEM, search],
    () => getAllGroupsInControlSystem(search),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
      refetchInterval: CONFIG.REFETCH_INTERVAL,
      onSuccess: onSuccess,
    }
  );
};

export const useGetScenesInControlSystem = (search = "", config = {}) => {
  return useQuery(
    [QUERY_KEYS.GET_ALL_SCENES_IN_CONTROL_SYSTEM, search],
    () => getAllScenesInControlSystem(search),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
      refetchInterval: CONFIG.REFETCH_INTERVAL,
      ...config,
    }
  );
};

export const useGetUserInfo = (userId) => {
  return useQuery([QUERY_KEYS.USER_INFO, userId], () => getUserInfo(userId), {
    enabled: !!userId,
    staleTime: 0,
    cacheTime: 0,
    refetchOnWindowFocus: false,
  });
};

export const useChangeUserPassword = (options = {}) => {
  return useMutation(
    ({ userId, passwordData }) => changeUserPassword(userId, passwordData),
    {
      ...options,
    }
  );
};

export const useUpdateUser = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(({ userId, userData }) => updateUser(userId, userData), {
    onSuccess: (data, { userId }) => {
      queryClient.invalidateQueries([QUERY_KEYS.USERS]);
      queryClient.invalidateQueries([QUERY_KEYS.USER_INFO, userId]);
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useUpdateUserStatus = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ userId, statusData }) => updateUserStatus(userId, statusData),
    {
      onSuccess: (data, { userId }) => {
        queryClient.invalidateQueries([QUERY_KEYS.USERS]);
        queryClient.invalidateQueries([QUERY_KEYS.USER_INFO, userId]);
        onSuccess && onSuccess(data);
      },
      ...config,
    }
  );
};

export const useDeleteUser = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteUser, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.USERS]);
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useDeleteRole = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteRole, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.ROLES]);
      queryClient.invalidateQueries([QUERY_KEYS.ROLES_OPTIONS]);
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};

export const useUpdateRoleStatus = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ roleId, statusData }) => updateRoleStatus(roleId, statusData),
    {
      onSuccess: (data, { roleId }) => {
        queryClient.invalidateQueries([QUERY_KEYS.ROLES]);
        queryClient.invalidateQueries([QUERY_KEYS.ROLES_OPTIONS]);
        onSuccess && onSuccess(data);
      },
      ...config,
    }
  );
};

// Logs Management Hooks
export const useGetMqttLogs = ({
  page = 1,
  limit = 10,
  search = "",
  sortBy,
  sortOrder,
  startDate,
  endDate,
  device_id,
} = {}) => {
  return useQuery(
    [
      QUERY_KEYS.MQTT_LOGS,
      page,
      limit,
      search,
      sortBy,
      sortOrder,
      startDate,
      endDate,
      device_id,
    ],
    () =>
      getMqttLogs({
        page,
        limit,
        search,
        sortBy,
        sortOrder,
        startDate,
        endDate,
        device_id,
      }),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

export const useGetEventLogs = ({
  page = 1,
  limit = 10,
  search = "",
  sortBy,
  sortOrder,
  startDate,
  endDate,
} = {}) => {
  return useQuery(
    [
      QUERY_KEYS.EVENT_LOGS,
      page,
      limit,
      search,
      sortBy,
      sortOrder,
      startDate,
      endDate,
    ],
    () =>
      getEventLogs({
        page,
        limit,
        search,
        sortBy,
        sortOrder,
        startDate,
        endDate,
      }),
    {
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

// Export hooks
export const useExportMqttLogs = ({ ...config }) => {
  return useMutation(exportMqttLogs, {
    ...config,
  });
};

export const useExportEventLogs = ({ ...config }) => {
  return useMutation(exportEventLogs, {
    ...config,
  });
};

// Campus Hierarchy Hook
export const useGetCampusHierarchy = () => {
  return useQuery([QUERY_KEYS.CAMPUS_HIERARCHY], getCampusHierarchy, {
    staleTime: 0, // 5 minutes
    cacheTime: 0, // 10 minutes
    refetchOnWindowFocus: false,
  });
};

export const useGetRoleBasedTabs = (roleId, onSuccess) => {
  return useQuery(
    [QUERY_KEYS.ROLE_BASED_TABS, roleId],
    () => getRoleBasedTabs(roleId),
    {
      enabled: !!roleId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
      onSuccess: (data) => {
        onSuccess && onSuccess(data);
      },
    }
  );
};

export const useGetRoleTabControlData = (roleId, userId = null, type) => {
  return useQuery(
    [QUERY_KEYS.ROLE_TAB_CONTROL_DATA, roleId, userId, type],
    () => getRoleTabControlData(roleId, type, userId),
    {
      enabled: !!roleId,
      staleTime: 0,
      cacheTime: 0,
      refetchOnWindowFocus: false,
    }
  );
};

// Update User Location Hook
export const useUpdateUserLocation = ({ onSuccess, onError, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ userId, locationData }) => updateUserLocation(userId, locationData),
    {
      onSuccess: (data, variables) => {
        // You can invalidate related queries here if needed
        queryClient.invalidateQueries([QUERY_KEYS.USERS]);
        if (onSuccess) {
          onSuccess(data, variables);
        }
      },
      onError: (error, variables) => {
        if (onError) {
          onError(error, variables);
        }
      },
      ...config,
    }
  );
};

// Dashboard Summary Hook
export const useGetDashboardSummary = (locationData = {}, options = {}) => {
  return useQuery(
    [QUERY_KEYS.DASHBOARD_SUMMARY, locationData],
    () => getDashboardSummary(locationData),
    {
      staleTime: 0, // 5 minutes
      cacheTime: 0, // 10 minutes
      refetchOnWindowFocus: false,
      ...options,
    }
  );
};

// Dashboard Zone Stats Hook
export const useGetDashboardZoneStats = (zoneData = {}, options = {}) => {
  return useQuery(
    [QUERY_KEYS.DASHBOARD_ZONE_STATS, zoneData],
    () => getDashboardZoneStats(zoneData),
    {
      staleTime: 0, // 5 minutes
      cacheTime: 0, // 10 minutes
      refetchOnWindowFocus: false,
      ...options,
    }
  );
};

// Dashboard Device Info Hook
export const useGetDashboardDeviceInfo = (deviceData = {}, options = {}) => {
  return useQuery(
    [QUERY_KEYS.DASHBOARD_DEVICE_INFO, deviceData],
    () => getDashboardDeviceInfo(deviceData),
    {
      enabled: !!deviceData.deviceId, // Only run when deviceId is provided
      staleTime: 0, // 5 minutes
      cacheTime: 0, // 10 minutes
      refetchOnWindowFocus: false,
      ...options,
    }
  );
};

export const useGetDashboardDeviceGetGroups = (
  deviceData = {},
  options = {}
) => {
  return useQuery(
    [QUERY_KEYS.DASHBOARD_DEVICE_GROUPS, deviceData],
    () => getDashboardDeviceGroups(deviceData),
    {
      enabled: !!deviceData.deviceId, // Only run when deviceId is provided
      staleTime: 0, // 5 minutes
      cacheTime: 0, // 10 minutes
      refetchOnWindowFocus: false,
      ...options,
    }
  );
};

// Dashboard Alerts Hook
export const useGetDashboardAlerts = ({
  device_id,
  page = 1,
  limit = 20,
} = {}) => {
  return useQuery(
    [QUERY_KEYS.DASHBOARD_ALERTS, page, limit, device_id],
    () => getDashboardAlerts({ page, limit, device_id }),
    {
      staleTime: 0, // 2 minutes
      cacheTime: 0, // 5 minutes
      refetchOnWindowFocus: false,
      keepPreviousData: true, // Keep previous data while fetching new page
    }
  );
};

// Widgets - Timezones Hooks
export const useInitializeTimezones = () => {
  const queryClient = useQueryClient();
  return useMutation(initializeTimezones, {
    onSuccess: () => {
      queryClient.invalidateQueries(QUERY_KEYS.TIMEZONE_OPTIONS);
    },
  });
};

export const useCreateTimezone = () => {
  const queryClient = useQueryClient();
  return useMutation(createTimezone, {
    onSuccess: () => {
      queryClient.invalidateQueries(QUERY_KEYS.TIMEZONES);
    },
  });
};

export const useGetTimezones = (options = {}) => {
  return useQuery([QUERY_KEYS.TIMEZONES], getTimezones, {
    staleTime: 0, // 5 minutes
    cacheTime: 0, // 10 minutes
    refetchOnWindowFocus: false,
    ...options,
  });
};

export const useGetAllTimezoneOptions = (options = {}) => {
  return useQuery([QUERY_KEYS.TIMEZONE_OPTIONS], getAllTimezoneOptions, {
    staleTime: 0, // 10 minutes
    cacheTime: 0, // 30 minutes
    refetchOnWindowFocus: false,
    ...options,
  });
};

export const useUpdateTimezone = () => {
  const queryClient = useQueryClient();
  return useMutation(updateTimezone, {
    onSuccess: () => {
      queryClient.invalidateQueries(QUERY_KEYS.TIMEZONES);
    },
  });
};

export const useDeleteTimezone = () => {
  const queryClient = useQueryClient();
  return useMutation(deleteTimezone, {
    onSuccess: () => {
      queryClient.invalidateQueries(QUERY_KEYS.TIMEZONES);
    },
  });
};

// Widgets - Weather Locations Hooks
export const useCreateWeatherLocation = () => {
  const queryClient = useQueryClient();
  return useMutation(createWeatherLocation, {
    onSuccess: () => {
      queryClient.invalidateQueries(QUERY_KEYS.WEATHER_LOCATIONS);
    },
  });
};

export const useGetWeatherLocations = (options = {}) => {
  return useQuery([QUERY_KEYS.WEATHER_LOCATIONS], getWeatherLocations, {
    staleTime: 0, // 5 minutes
    cacheTime: 0, // 10 minutes
    refetchOnWindowFocus: false,
    ...options,
  });
};

export const useGetSensorsForWidgetCreation = (options = {}) => {
  return useQuery(
    [QUERY_KEYS.SENSORS_FOR_WIDGET_CREATION],
    getSensorsForWidgetCreation,
    {
      staleTime: 0, // 5 minutes
      cacheTime: 0, // 10 minutes
      refetchOnWindowFocus: false,
      ...options,
    }
  );
};

export const useUpdateWeatherLocation = () => {
  const queryClient = useQueryClient();
  return useMutation(updateWeatherLocation, {
    onSuccess: () => {
      queryClient.invalidateQueries(QUERY_KEYS.WEATHER_LOCATIONS);
    },
  });
};

export const useDeleteWeatherLocation = () => {
  const queryClient = useQueryClient();
  return useMutation(deleteWeatherLocation, {
    onSuccess: () => {
      queryClient.invalidateQueries(QUERY_KEYS.WEATHER_LOCATIONS);
    },
  });
};

// Widgets - General Hooks
export const useCreateWidget = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(createWidget, {
    onSuccess: (data) => {
      onSuccess?.(data);
      queryClient.invalidateQueries(QUERY_KEYS.GET_CREATED_WIDGETS);
    },
  });
};

export const useGetWidgetById = (widgetId, options = {}) => {
  return useQuery(
    [QUERY_KEYS.GET_WIDGET_BY_ID, widgetId],
    () => getWidgetById(widgetId),
    {
      enabled: !!widgetId,
      staleTime: 0, // 5 minutes
      cacheTime: 0, // 10 minutes
      refetchOnWindowFocus: false,
      ...options,
    }
  );
};

export const useUpdateWidget = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(updateWidget, {
    onSuccess: (data) => {
      onSuccess?.(data);
      queryClient.invalidateQueries(QUERY_KEYS.GET_CREATED_WIDGETS);
    },
    ...config,
  });
};

export const useDeleteWidget = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteWidget, {
    onSuccess: (data) => {
      queryClient.invalidateQueries(QUERY_KEYS.GET_CREATED_WIDGETS);
      onSuccess?.(data);
    },
    ...config,
  });
};

// Weather and AQI hooks
export const useWeatherData = ({ lat, long, ...config }) => {
  return useQuery(
    [QUERY_KEYS.WEATHER_DATA, lat, long],
    () => getWeatherData({ lat, long }),
    {
      staleTime: 0, // 10 minutes
      cacheTime: 0, // 30 minutes
      refetchOnWindowFocus: false,
      retry: 2,
      enabled: Boolean(lat && long),
      ...config,
    }
  );
};

export const useAQIData = ({ lat, long, ...config }) => {
  return useQuery(
    [QUERY_KEYS.AQI_DATA, lat, long],
    () => getAQIData({ lat, long }),
    {
      staleTime: 0, // 10 minutes
      cacheTime: 0, // 30 minutes
      refetchOnWindowFocus: false,
      retry: 2,
      enabled: Boolean(lat && long),
      ...config,
    }
  );
};

export const useWeatherAndAQI = ({ lat, long, ...config }) => {
  return useQuery(
    [QUERY_KEYS.WEATHER_AND_AQI, lat, long],
    () => getWeatherAndAQI({ lat, long }),
    {
      staleTime: 0, // 1 hour (data stays fresh for 1h)
      cacheTime: 0, // 2 hours (kept in cache)
      refetchInterval: 60 * 60 * 1000, // refetch every 1h
      refetchOnWindowFocus: false,
      retry: 2,
      enabled: Boolean(lat && long),
      ...config,
    }
  );
};

export const useOpenMeteoWeather = ({ lat, long, ...config }) => {
  return useQuery(
    [QUERY_KEYS.OPEN_METEO_WEATHER, lat, long],
    () => getOpenMeteoWeather({ lat, long }),
    {
      staleTime: 0, // 30 minutes (data stays fresh for 30min)
      cacheTime: 0, // 1 hour (kept in cache)
      refetchInterval: 30 * 60 * 1000, // refetch every 30min
      refetchOnWindowFocus: false,
      retry: 2,
      enabled: Boolean(lat && long),
      ...config,
    }
  );
};

export const useGetCreatedWidgets = () => {
  return useQuery([QUERY_KEYS.GET_CREATED_WIDGETS], getCreatedWidgets, {
    staleTime: 0, // 5 minutes
    cacheTime: 0, // 10 minutes
    refetchOnWindowFocus: false,
  });
};

export const useGetFirstWeatherLocation = () => {
  return useQuery(
    [QUERY_KEYS.GET_FIRST_WEATHER_LOCATION],
    getFirstWeatherLocation,
    {
      staleTime: 0, // 5 minutes
      cacheTime: 0, // 10 minutes
      refetchOnWindowFocus: false,
    }
  );
};

export const useDeleteChannelFromControlPanel = ({ onSuccess, ...config }) => {
  const queryClient = useQueryClient();
  return useMutation(deleteChannelFromControlPanel, {
    onSuccess: (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.DEVICE_DETAILS], {
        exact: false,
      });
      queryClient.invalidateQueries([QUERY_KEYS.DEVICE_CHANNELS], {
        exact: false,
      });
      onSuccess && onSuccess(data);
    },
    ...config,
  });
};
