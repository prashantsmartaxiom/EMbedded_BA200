import api from ".";
import { ROLE_BASED_TABS } from "../consts";
import useUserStore from "../store/useUserStore";
import {
  findTemplateById,
  payloadGeneratorForControlPanel,
} from "../utils/helpers";
import dummyData from "./dummyData";
import ENDPOINTS from "./endpoint";

export const signUp = async (userData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.SIGN_UP,
    data: userData,
  });
  return data;
};

// Add to ./queryFunctions.js
export const signIn = async (credentials) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.SIGN_IN,
    data: credentials,
  });
  return data;
};

// Add to ./queryFunctions.js
export const forgotPassword = async (email) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.FORGOT_PASSWORD,
    data: { email },
  });
  return data;
};

export const resendOTP = async (email) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.FORGOT_PASSWORD,
    data: { email },
    params: { resend: "1" },
  });
  return data;
};

export const verifyCode = async ({ email, otp }) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.VERIFY_CODE,
    data: { email, otp },
  });
  return data;
};

export const resetPassword = async ({ email, newPassword }) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.RESET_PASSWORD,
    data: { email, newPassword },
  });
  return data;
};

export const getCampusTypes = async () => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_CAMPUS_TYPES,
  });

  return data?.data?.types.map((item) => ({
    label: item,
    value: item,
  }));
};

export const createCampus = async (campusData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.CREATE_CAMPUS,
    data: campusData,
  });
  return data;
};

export const getCampuses = async ({
  page = 1,
  limit = 10,
  search = "",
  status = null,
}) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_CAMPUSES,
    params: { page, limit, search, status },
  });
  return data;
};

export const deleteCampus = async (campusId) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_CAMPUS(campusId),
  });
  return data;
};

export const deleteBuilding = async (buildingId) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_BUILDING(buildingId),
  });
  return data;
};

export const getCampusOptions = async () => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_CAMPUS_OPTIONS,
  });
  return data?.data?.campuses?.map((item) => ({
    value: item?._id,
    label: item?.name,
  }));
};

export const getCampusById = async (campusId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_CAMPUS_BY_ID(campusId),
  });
  return data;
};

export const updateCampus = async ({ campusId, campusData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_CAMPUS(campusId),
    data: campusData,
  });
  return data;
};

export const createBuilding = async (campusId, payload) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.CREATE_BUILDING(campusId),
    data: payload,
  });
  return data;
};

export const getBuildings = async ({
  page = 1,
  limit = 10,
  search = "",
  status = null,
}) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ALL_BUILDINGS,
    params: { page, limit, search, status },
  });
  return data;
};

export const getBuildingById = async (buildingId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_BUILDING_BY_ID(buildingId),
  });
  return data;
};

export const updateBuilding = async ({ buildingId, buildingData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_BUILDING(buildingId),
    data: buildingData,
  });
  return data;
};

export const getBuildingOptionsByCampus = async (campusId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_BUILDING_OPTIONS_BY_CAMPUS(campusId),
  });
  return data?.data?.buildings?.map((item) => ({
    value: item?._id,
    label: item?.name,
  }));
};

export const createFloor = async (buildingId, floorData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.CREATE_FLOOR(buildingId),
    data: floorData,
  });
  return data;
};

export const getFloors = async ({
  page = 1,
  limit = 10,
  search = "",
  status = null,
}) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ALL_FLOORS,
    params: { page, limit, search, status },
  });
  return data;
};

export const getFloorsOptionsByBuilding = async (buildingId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_FLOORS_OPTIONS_BY_BUILDING(buildingId),
  });
  return data?.data?.floors?.map((item) => ({
    value: item?._id,
    label: item?.name,
  }));
};

export const getFloorById = async (floorId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_FLOOR_BY_ID(floorId),
  });
  return data;
};

export const deleteFloor = async (floorId) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_FLOOR(floorId),
  });
  return data;
};

export const updateFloor = async ({ floorId, floorData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_FLOOR(floorId),
    data: floorData,
  });
  return data;
};

export const createZone = async (floorId, zoneData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.CREATE_ZONE,
    data: zoneData,
  });
  return data;
};

export const getZones = async ({
  page = 1,
  limit = 10,
  search = "",
  status = null,
}) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ZONES,
    params: { page, limit, search, status },
  });
  return data;
};

export const getZoneById = async (zoneId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ZONE_BY_ID(zoneId),
  });
  return data;
};

export const updateZone = async ({ zoneId, zoneData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_ZONE(zoneId),
    data: zoneData,
  });
  return data;
};

export const deleteZone = async (zoneId) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_ZONE,
    data: { zoneId },
  });
  return data;
};

export const getZonesOptionsByFloor = async (floorId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ZONES_OPTIONS_BY_FLOOR(floorId),
  });
  return data?.data?.zones?.map((item) => ({
    value: item?._id,
    label: item?.name,
  }));
};

export const getDiscoveryDevices = async ({ search = "", device_id }) => {
  const params = { search };
  if (device_id) params.device_id = device_id;

  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_DISCOVERY_DEVICES,
    params,
  });
  return data;
};

export const getConfiguredDevices = async ({ search = "", device_id, active=true }) => {
  const params = { search };
  if (device_id) params.device_id = device_id;
  if (active) params.active = "1";

  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_CONFIGURED_DEVICES,
    params,
  });
  return data;
};

export const getDeviceControlDCCount = async () => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.DEVICE_CONTROL_DC_COUNT,
  });
  return data;
};

export const getDeviceDetails = async (deviceId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_DEVICE_DETAILS(deviceId),
  });
  return data;
};

export const getDeviceChannelsByDeviceId = async (deviceId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_DEVICE_CHANNELS_BY_DEVICE_ID(deviceId),
  });
  return data;
};

export const configureDevice = async (deviceData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.CONFIGURE_DEVICE,
    data: deviceData,
  });
  return data;
};

export const addDevice = async (deviceData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.ADD_DEVICE,
    data: deviceData,
  });
  return data;
};

export const getActiveDevicesForGroup = async (type = "") => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ACTIVE_DEVICES_OPTIONS_FOR_GROUP(type),
  });
  return data?.data?.map((item) => ({
    value: item?.device_id,
    label: item?.name,
    data: item,
  }));
};

export const getDeviceChannelsForGroup = async (deviceIds) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.GET_DEVICE_CHANNELS_FOR_GROUP,
    data: { deviceIds },
  });
  return data?.data;
};

export const createGroup = async (groupData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.CREATE_GROUP,
    data: groupData,
  });
  return data;
};

export const getGroupById = async (groupId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_GROUP_BY_ID(groupId),
  });
  return data;
};

export const updateGroup = async ({ groupId, groupData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_GROUP(groupId),
    data: groupData,
  });
  return data;
};

export const deleteGroup = async (groupId) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_GROUP(groupId),
  });
  return data;
};

export const getGroups = async ({
  page = 1,
  limit = 10,
  search = "",
  device_id,
}) => {
  const params = { page, limit, search };
  if (device_id) params.device_id = device_id;

  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_GROUPS,
    params,
  });
  return data;
};

export const getAllGroupOptions = async () => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ALL_GROUP_OPTIONS,
  });
  return (
    data?.data?.data?.map((group) => ({
      value: group._id,
      label: group.name,
    })) || []
  );
};

export const getConfiguredDevicesOptions = async (active=true) => {
  const params = {};
  if (active) params.active = "1";
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_CONFIGURED_DEVICES_OPTIONS,
    params,
  });
  return (
    data?.data?.configured_devices?.map((device) => ({
      value: device.device_id,
      label: device.device_name || device.device_id,
    })) || []
  );
};

export const getGroupDetails = async (groupId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_GROUP_DETAILS(groupId),
  });
  return data;
};

export const getMultipleGroupDetails = async (groupIds) => {
  if (!groupIds || groupIds.length === 0) {
    return [];
  }

  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_MULTIPLE_GROUP_DETAILS,
    params: {
      groupIds: groupIds.join(","),
    },
  });

  if (groupIds?.length === 1) {
    return {
      ...data,
      data: [
        {
          data: data.data,
          groupId: groupIds?.[0],
          success: true,
        },
      ],
    };
  }
  return data;
};

export const getDeviceSceneDetails = async (deviceId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_DEVICE_SCENE_DETAILS(deviceId),
  });
  return data;
};

export const createScene = async (sceneData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.CREATE_SCENE,
    data: sceneData,
  });
  return data;
};

export const getScenes = async ({ page = 1, limit = 10, search = "" }) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_SCENES,
    params: { page, limit, search },
  });
  return data;
};

export const getSceneById = async (sceneId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_SCENE_BY_ID(sceneId),
  });
  return data;
};

export const updateScene = async ({ sceneId, sceneData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_SCENE(sceneId),
    data: sceneData,
  });
  return data;
};

export const deleteScene = async (sceneId) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_SCENE(sceneId),
  });
  return data;
};

export const updateCampusStatus = async ({ campusId, status }) => {
  const { data } = await api({
    method: "PATCH",
    url: ENDPOINTS.UPDATE_CAMPUS_STATUS(campusId),
    data: { status },
  });
  return data;
};

export const updateBuildingStatus = async ({ buildingId, status }) => {
  const { data } = await api({
    method: "PATCH",
    url: ENDPOINTS.UPDATE_BUILDING_STATUS(buildingId),
    data: { status },
  });
  return data;
};

export const updateFloorStatus = async ({ floorId, status }) => {
  const { data } = await api({
    method: "PATCH",
    url: ENDPOINTS.UPDATE_FLOOR_STATUS(floorId),
    data: { status },
  });
  return data;
};

export const updateZoneStatus = async ({ zoneId, status }) => {
  const { data } = await api({
    method: "PATCH",
    url: ENDPOINTS.UPDATE_ZONE_STATUS,
    data: { status, zoneId },
  });
  return data;
};

export const deleteConfiguredDevice = async (deviceId) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_CONFIGURED_DEVICE(deviceId),
  });
  return data;
};

export const deleteThirdPartyDevice = async (deviceId) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_THIRD_PARTY_DEVICE(deviceId),
  });
  return data;
};

export const updateConfiguredDevice = async ({ deviceId, deviceData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_CONFIGURED_DEVICE(deviceId),
    data: deviceData,
  });
  return data;
};

export const updateThirdPartyDevice = async ({ deviceId, deviceData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_THIRD_PARTY_DEVICE(deviceId),
    data: deviceData,
  });
  return data;
};

export const updateDeviceChannel = async ({
  deviceId,
  channelId,
  channelData,
}) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_DEVICE_CHANNEL(deviceId, channelId),
    data: payloadGeneratorForControlPanel(channelData, deviceId, channelId),
  });
  return data;
};

export const getDeviceOptionsForSensors = async (active=true) => {
  const params = {};
  if (active) params.active = "1";
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_DEVICE_OPTIONS_FOR_SENSORS,
    params,
  });
  return data?.data?.configured_devices?.map((device) => ({
    value: device.device_id,
    label: device.device_name,
    data: device,
  }));
};

export const getSensorsByDevice = async (deviceId) => {
  // TODO: Replace with actual API call when available
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_SENSORS_BY_DEVICE(deviceId),
  });
  return data?.data?.sensors?.map((sensor) => ({
    value: sensor.channelId,
    label: `${sensor.name}${
      sensor?.properties?.port && sensor?.properties?.sensorAddress
        ? ` (Port-${sensor.properties.sensorAddress}_${sensor.properties.port})`
        : ""
    }`,
    shouldRemoveFromSelection: sensor?.disabled,
  }));
};

export const getMotions = async () => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_MOTIONS,
  });

  return data?.data?.scenes?.map((item) => ({
    value: item._id,
    label: item.name,
    operateType: item?.operateType,
  }));
};

export const getNoMotions = async () => {
  // TODO: Replace with actual API call when available
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_NO_MOTIONS,
  });

  return data?.data?.scenes?.map((item) => ({
    value: item._id,
    label: item.name,
    operateType: item?.operateType,
  }));
};

export const createSensor = async (sensorData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.CREATE_SENSOR,
    data: sensorData,
  });
  return data;
};

export const getSensorById = async (sensorId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_SENSOR_BY_ID(sensorId),
  });
  return data;
};

export const updateSensor = async ({ sensorId, sensorData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_SENSOR(sensorId),
    data: sensorData,
  });
  return data;
};

// Template Management Functions
export const getTemplateList = async ({
  page = 1,
  limit = 10,
  search = "",
  layout,
} = {}) => {
  const params = { page, limit, search };
  if (layout) params.layout = layout;

  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_TEMPLATE_LIST,
    params,
  });
  return data;
};

export const getTemplateListInControlSystem = async (search = "") => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_TEMPLATES_IN_CONTROL_SYSTEM,
    params: {
      ...(search && { search }),
    },
  });
  return data;
};

export const getTemplateById = async (templateId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_TEMPLATE_BY_ID(templateId),
  });
  return data;
};

export const getLayoutList = async () => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_LAYOUT_LIST,
  });
  return data;
};

export const createTemplate = async (templateData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.CREATE_TEMPLATE,
    data: templateData,
  });
  return data;
};

export const updateTemplate = async ({ templateId, templateData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_TEMPLATE,
    data: { id: templateId, ...templateData },
  });
  return data;
};

export const deleteTemplate = async (templateId) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_TEMPLATE,
    data: { id: templateId },
  });
  return data;
};

export const getSensors = async ({
  page = 1,
  limit = 10,
  search = "",
  deviceFilter,
}) => {
  const params = { page, limit, search, device_id: deviceFilter };

  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_SENSORS,
    params,
  });
  return data;
};

export const deleteSensor = async (sensorId) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_SENSOR(sensorId),
  });
  return data;
};

// User Management Functions
export const createUser = async (userData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.CREATE_USER,
    data: userData,
  });
  return data;
};

// Role Management Functions
export const createRole = async (roleData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.CREATE_ROLE,
    data: roleData,
  });
  return data;
};

export const updateRole = async ({ roleId, roleData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_ROLE(roleId),
    data: roleData,
  });
  return data;
};

export const getAllDevices = async () => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ALL_DEVICES,
  });
  return data;
};

export const triggerEvent = async (eventData) => {
  const user = useUserStore.getState().user;
  if (eventData.type === "reboot") {
    const { data } = await api({
      method: "POST",
      url: ENDPOINTS.REBOOT_DEVICE,
      data: {
        device_id: eventData.device_id,
        username: user?.fullName
      },
    });
    return data;
  } else {
    const { data } = await api({
      method: "POST",
      url: ENDPOINTS.EVENT_TRIGGER,
      data: {
        ...eventData,
        username: user?.fullName
      },
    });
    return data;
  }
};

export const getUsers = async ({
  page = 1,
  limit = 10,
  status,
  search = "",
  filterData,
  sortBy,
  sortOrder,
}) => {
  const params = { page, limit, status, search, filterRole: filterData };

  // Add sorting parameters if provided
  if (sortBy) {
    params.sortBy = sortBy;
  }
  if (sortOrder) {
    params.sortOrder = sortOrder;
  }

  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.USERS,
    params,
  });
  return data;
};

export const getRolesCategories = async () => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ROLES_CATEGORIES,
  });
  return data;
};

export const getRoles = async ({
  status,
  page = 1,
  limit = 10,
  search = "",
  sortBy,
  sortOrder,
} = {}) => {
  const params = { page, limit, search, status };

  // Add sorting parameters if provided
  // if (sortBy) {
  //   params.sortBy = sortBy;
  // }
  if (sortOrder) {
    params.sort = sortOrder;
  }

  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ROLES,
    params,
  });
  return data;
};

export const getRolesOptions = async (check) => {
  const params = {};
  if (check) params.check = check;
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ROLES_OPTIONS,
    params,
  });
  return data?.data?.roles?.map((role) => ({
    value: role._id,
    label: role.roleName,
  }));
};

export const getRoleById = async (roleId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ROLE_BY_ID(roleId),
  });
  return data;
};

export const getDeviceIdControlSystem = async (deviceId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_DEVICE_ID_CONTROL_SYSTEM(deviceId),
  });
  return data;
};
export const getAllDevicesInControlSystem = async (search = "") => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ALL_DEIVICES_IN_CONTROL_SYSTEM,
    params: {
      limit: 500,
      page: 1,
      ...(search && { search }),
    },
  });
  return data;
};

export const getAllGroupsInControlSystem = async (search = "") => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ALL_GROUPS_IN_CONTROL_SYSTEM,
    params: {
      limit: 100,
      page: 1,
      ...(search && { search }),
    },
  });
  return data;
};

export const getAllScenesInControlSystem = async (search = "") => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_ALL_SCENES_IN_CONTROL_SYSTEM,
    params: {
      ...(search && { search }),
    },
  });
  return data;
};

export const getUserInfo = async (userId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_USER_INFO(userId),
  });
  return data;
};

export const changeUserPassword = async (userId, passwordData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.CHANGE_USER_PASSWORD,
    data: passwordData,
  });
  return data;
};

export const updateUser = async (userId, userData) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_USER(userId),
    data: userData,
  });
  return data;
};

export const updateUserStatus = async (userId, statusData) => {
  const { data } = await api({
    method: "PATCH",
    url: ENDPOINTS.UPDATE_USER_STATUS(userId),
    data: statusData,
  });
  return data;
};

export const deleteUser = async (userId) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_USER(userId),
    data: { isDeleted: true },
  });
  return data;
};

export const deleteRole = async (roleId) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_ROLE(roleId),
  });
  return data;
};

export const updateRoleStatus = async (roleId, statusData) => {
  const { data } = await api({
    method: "PATCH",
    url: ENDPOINTS.UPDATE_ROLE_STATUS(roleId),
    data: statusData,
  });
  return data;
};

// Logs Management Functions
export const getMqttLogs = async ({
  page = 1,
  limit = 10,
  search = "",
  sortBy,
  sortOrder,
  startDate,
  endDate,
  device_id,
} = {}) => {
  const params = { page, limit };

  // Add optional parameters if provided
  if (search) {
    params.search = search;
  }
  if (sortBy) {
    params.sort = sortBy;
  }
  if (sortOrder) {
    params.order = sortOrder;
  }
  if (startDate) {
    params.startDate = startDate;
  }
  if (endDate) {
    params.endDate = endDate;
  }
  if (device_id) {
    params.device_id = device_id;
  }

  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_MQTT_LOGS,
    params,
  });
  return data;
};

export const getEventLogs = async ({
  page = 1,
  limit = 10,
  search = "",
  sortBy,
  sortOrder,
  startDate,
  endDate,
} = {}) => {
  const params = { page, limit };

  // Add optional parameters if provided
  if (search) {
    params.search = search;
  }
  if (sortBy) {
    params.sort = sortBy;
  }
  if (sortOrder) {
    params.order = sortOrder;
  }
  if (startDate) {
    params.startDate = startDate;
  }
  if (endDate) {
    params.endDate = endDate;
  }

  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_EVENT_LOGS,
    params,
  });
  return data;
};

// Export functions for logs
export const exportMqttLogs = async ({
  page = 1,
  limit = 10,
  search = "",
  sortBy,
  sortOrder,
  startDate,
  endDate,
  device_id,
} = {}) => {
  // const params = { page, limit, download: 1 };
  const params = { download: 1 };

  // Add optional parameters if provided
  if (search) {
    params.search = search;
  }
  if (sortBy) {
    params.sort = sortBy;
  }
  if (sortOrder) {
    params.order = sortOrder;
  }
  if (startDate) {
    params.startDate = startDate;
  }
  if (endDate) {
    params.endDate = endDate;
  }
  if (device_id) {
    params.device_id = device_id;
  }

  // Get user's timezone code
  params.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  const response = await api({
    method: "GET",
    url: ENDPOINTS.GET_MQTT_LOGS,
    params,
    responseType: 'blob',
  });
  
  // Create blob and download file
  const blob = new Blob([response.data], { 
    type: response.headers['content-type'] || 'application/octet-stream' 
  });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  
  // Extract filename from response headers or use default
  const contentDisposition = response.headers['content-disposition'];
  let filename = 'mqtt-logs.csv';
  if (contentDisposition) {
    const filenameMatch = contentDisposition.match(/filename="?(.+?)"?$/);
    if (filenameMatch) {
      filename = filenameMatch[1];
    }
  }
  
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
  
  return { success: true, message: 'File downloaded successfully' };
};

export const exportEventLogs = async ({
  page = 1,
  limit = 10,
  search = "",
  sortBy,
  sortOrder,
  startDate,
  endDate,
} = {}) => {
  // const params = { page, limit, download: 1 };
  const params = { download: 1 };

  // Add optional parameters if provided
  if (search) {
    params.search = search;
  }
  if (sortBy) {
    params.sort = sortBy;
  }
  if (sortOrder) {
    params.order = sortOrder;
  }
  if (startDate) {
    params.startDate = startDate;
  }
  if (endDate) {
    params.endDate = endDate;
  }

  // Get user's timezone code
  params.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  const response = await api({
    method: "GET",
    url: ENDPOINTS.GET_EVENT_LOGS,
    params,
    responseType: 'blob',
  });
  
  // Create blob and download file
  const blob = new Blob([response.data], { 
    type: response.headers['content-type'] || 'application/octet-stream' 
  });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  
  // Extract filename from response headers or use default
  const contentDisposition = response.headers['content-disposition'];
  let filename = 'event-logs.csv';
  if (contentDisposition) {
    const filenameMatch = contentDisposition.match(/filename="?(.+?)"?$/);
    if (filenameMatch) {
      filename = filenameMatch[1];
    }
  }
  
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
  
  return { success: true, message: 'File downloaded successfully' };
};

// Campus Hierarchy Functions
export const getCampusHierarchy = async () => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_CAMPUS_HIERARCHY,
  });
  return data;
};

export const getRoleBasedTabs = async (roleId) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.ROLE_BASED_TABS,
    data: { role_id: roleId },
  });

  return data;
};

export const getRoleTabControlData = async (role_id, type, userId) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.ROLE_TAB_CONTROL_DATA,
    // data: { role_id, type },
    data: { role_id, user_id: userId },
  });

  // const formattedData = [];
  // const keysData = data.data;

  // for (const key in keysData) {
  //   if (key === "tabs") continue;
  //   const item = {
  //     id: key,
  //     name: key,
  //     data: keysData[key].map((subItem) => ({
  //       id: subItem?._id,
  //       name:
  //         subItem?.name ||
  //         subItem?.fullName ||
  //         subItem?.roleName ||
  //         subItem?.sensorEvent ||
  //         "N/A",
  //       ...subItem,
  //     })),
  //   };
  //   formattedData.push(item);
  // }
  // return formattedData;

  const tabsData = [];
  for (let item of data.data) {
    const formattedData = [];
    if (item.id === "logsMonitoring") {
      for (const key in item.data) {
        const subitemMain = {
          id: key,
          name: key,
          data: item.data[key],
        };
        formattedData.push(subitemMain);
      }
    } else {
      for (const key in item.data) {
        const subitemMain = {
          id: key,
          name: key,
          data: item.data[key].map((subItem) => ({
            id: subItem?._id,
            name:
              subItem?.name ||
              subItem?.fullName ||
              subItem?.roleName ||
              subItem?.sensorEvent ||
              "N/A",
            ...subItem,
          })),
        };
        formattedData.push(subitemMain);
      }
    }

    if (Object.keys(item.data).length > 0) {
      tabsData.push({
        id: item.id,
        tab_name: item.label,
        data: formattedData,
      });
    }
  }
  return tabsData;
};

// Update User Location Function
export const updateUserLocation = async (userId, locationData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.UPDATE_USER_LOCATION(userId),
    data: locationData,
  });
  return data;
};

// Dashboard Summary Function
export const getDashboardSummary = async (locationData = {}) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.DASHBOARD_SUMMARY,
    data: locationData,
  });
  return data;
};

// Dashboard Zone Stats Function
export const getDashboardZoneStats = async (zoneData = {}) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.DASHBOARD_ZONE_STATS,
    data: zoneData,
  });
  return data;
};

// Dashboard Device Info Function
export const getDashboardDeviceInfo = async (deviceData = {}) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.DASHBOARD_DEVICE_INFO,
    data: deviceData,
  });
  return data;
};

// Dashboard Device Info Function
export const getDashboardDeviceGroups = async (deviceData = {}) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.DASHBOARD_DEVICE_GROUPS(deviceData.deviceId),
    data: deviceData,
  });
  return data;
  // return dummyData.dashboardDeviceGroups;
};

// Dashboard Alerts Function
export const getDashboardAlerts = async ({
  device_id,
  page = 1,
  limit = 20,
} = {}) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.DASHBOARD_ALERTS(device_id),
    params: { page, limit },
  });
  return data;
};

// Widgets - Timezones Functions
export const initializeTimezones = async () => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.WIDGETS_TIMEZONES_INITIALIZE,
  });
  return data;
};

export const createTimezone = async (timezoneData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.WIDGETS_TIMEZONES_CREATE,
    data: timezoneData,
  });
  return data;
};

export const getTimezones = async () => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.WIDGETS_TIMEZONES_GET,
  });
  return data;
};

export const getAllTimezoneOptions = async () => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.WIDGETS_TIMEZONES_ALL,
  });
  return data;
};

export const updateTimezone = async ({ id, timezoneData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.WIDGETS_TIMEZONES_UPDATE(id),
    data: timezoneData,
  });
  return data;
};

// Widgets - Weather Locations Functions
export const createWeatherLocation = async (locationData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.WIDGETS_WEATHER_CREATE,
    data: locationData,
  });
  return data;
};

export const getWeatherLocations = async () => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.WIDGETS_WEATHER_GET,
  });
  return data;
};

export const getSensorsForWidgetCreation = async () => {
  // const { data } = await api({
  //   method: "GET",
  //   url: ENDPOINTS.WIDGETS_SENSORS_GET,
  // });
  // return data;
  return dummyData.sensorsForWidgetCreation;
};

export const updateWeatherLocation = async ({ id, locationData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.WIDGETS_WEATHER_UPDATE(id),
    data: locationData,
  });
  return data;
};

export const deleteWeatherLocation = async (id) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.WIDGETS_WEATHER_DELETE(id),
  });
  return data;
};

export const deleteTimezone = async (id) => {
  const { data } = await api({
    method: "PATCH",
    url: ENDPOINTS.WIDGETS_TIMEZONES_DELETE(id),
    data: {
      isActive: false,
    },
  });
  return data;
};

// Widgets - General Functions
export const createWidget = async (widgetsData) => {
  const { data } = await api({
    method: "POST",
    url: ENDPOINTS.WIDGETS_ADD,
    data: widgetsData,
  });
  return data;
};

export const getWidgetById = async (widgetId) => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_WIDGET_BY_ID(widgetId),
  });
  return data;
};

export const updateWidget = async ({ widgetId, widgetsData }) => {
  const { data } = await api({
    method: "PUT",
    url: ENDPOINTS.UPDATE_WIDGET(widgetId),
    data: widgetsData,
  });
  return data;
};

export const deleteWidget = async (widgetId) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_WIDGET(widgetId),
  });
  return data;
};

// Weather API Functions
export const getWeatherData = async ({ lat, long }) => {
  const today = new Date().toISOString().split("T")[0];
  const timezone = "UTC";
  const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${long}&hourly=temperature_2m&timezone=${timezone}&start_date=${today}&end_date=${today}`;

  const response = await fetch(weatherUrl);
  if (!response.ok) {
    throw new Error(`Weather API error: ${response.status}`);
  }

  const data = await response.json();
  const tempArr = data?.hourly?.temperature_2m || [];

  return {
    temperature: tempArr.length > 0 ? tempArr[tempArr.length - 1] : null,
    rawData: data,
  };
};

export const getAQIData = async ({ lat, long }) => {
  const today = new Date().toISOString().split("T")[0];
  const timezone = "UTC";
  const aqiUrl = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${long}&hourly=us_aqi&timezone=${timezone}&start_date=${today}&end_date=${today}`;

  const response = await fetch(aqiUrl);
  if (!response.ok) {
    throw new Error(`AQI API error: ${response.status}`);
  }

  const data = await response.json();
  const aqiArr = data?.hourly?.us_aqi || [];

  return {
    aqi: aqiArr.length > 0 ? aqiArr[aqiArr.length - 1] : null,
    rawData: data,
  };
};

export const getWeatherAndAQI = async ({ lat, long }) => {
  try {
    const [weatherData, aqiData] = await Promise.all([
      getWeatherData({ lat, long }),
      getAQIData({ lat, long }),
    ]);

    return {
      temperature: weatherData.temperature,
      aqi: aqiData.aqi,
      weatherData: weatherData.rawData,
      aqiData: aqiData.rawData,
    };
  } catch (error) {
    console.error("⚠️ Failed to fetch weather/AQI:", error);
    throw error;
  }
};

export const getOpenMeteoWeather = async ({ lat, long }) => {
  try {
    const response = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${long}&current=temperature_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,surface_pressure,cloud_cover,relative_humidity_2m,dew_point_2m`
    );

    if (!response.ok) {
      throw new Error(`Weather API error: ${response.status}`);
    }

    const data = await response.json();

    return {
      current: data.current,
      current_units: data.current_units,
      latitude: data.latitude,
      longitude: data.longitude,
      timezone: data.timezone,
      elevation: data.elevation,
    };
  } catch (error) {
    console.error("⚠️ Failed to fetch Open-Meteo weather:", error);
    throw error;
  }
};

export async function getCreatedWidgets() {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_CREATED_WIDGETS,
  });
  return data;
}

export const getFirstWeatherLocation = async () => {
  const { data } = await api({
    method: "GET",
    url: ENDPOINTS.GET_FIRST_WEATHER_LOCATION,
  });
  return data;
};

export const deleteChannelFromControlPanel = async (payload) => {
  const { data } = await api({
    method: "DELETE",
    url: ENDPOINTS.DELETE_SENSOR_FROM_CONTROL_PANEL(payload.deviceId, payload.channelId),
  });
  return data;
};
