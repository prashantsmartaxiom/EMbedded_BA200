import axios from "axios";
import { QueryClient, QueryClientProvider } from "react-query";
import CONFIG from "../config";
import useUserStore from "../store/useUserStore";

export const baseURL = CONFIG.API_BASE_URL;

const api = (config) => {
  const axiosInstance = axios.create({
    baseURL: baseURL,
  });

  // set headers if local storage have token (Bearer)
  const token = localStorage.getItem("token");
  if (token) {
    axiosInstance.defaults.headers.common["Authorization"] = `Bearer ${token}`;
  }

  // if 401 Unauthorized, redirect to login
  axiosInstance.interceptors.response.use(
    (response) => response,
    (error) => {
      if (error.response && error.response.status === 401) {
        useUserStore.getState().logout();
      }
      return Promise.reject(error);
    }
  );

  return axiosInstance(config);
};

export const ApiProvider = ({ children }) => {
  const queryClient = new QueryClient();
  return (
    <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
  );
};

export default api;
