const ENDPOINTS = {
  SIGN_UP: "/auth/signup",
  SIGN_IN: "/auth/login",
  FORGOT_PASSWORD: "/auth/forgot-password",
  VERIFY_CODE: "/auth/verify-code",
  RESET_PASSWORD: "/auth/reset-password",

  GET_CAMPUS_TYPES: "/campus/types",
  CREATE_CAMPUS: "/campus",
  GET_CAMPUSES: "/campus",
  GET_CAMPUS_OPTIONS: "/campus/active_campuses",
  GET_CAMPUS_BY_ID: (id) => `/campus/${id}`,
  UPDATE_CAMPUS: (id) => `/campus/${id}`,
  DELETE_CAMPUS: (id) => `campus/${id}/delete`,
  UPDATE_CAMPUS_STATUS: (id) => `/campus/${id}/status`,

  CREATE_BUILDING: (id) => `/buildings/campus/${id}`,
  GET_ALL_BUILDINGS: "/buildings",
  GET_BUILDING_OPTIONS_BY_CAMPUS: (campusId) =>
    `/buildings/campus/${campusId}/active`,
  GET_BUILDING_BY_ID: (id) => `/buildings/${id}`,
  UPDATE_BUILDING: (id) => `/buildings/${id}`,
  DELETE_BUILDING: (id) => `/buildings/${id}`,
  UPDATE_BUILDING_STATUS: (id) => `/buildings/${id}/status`,

  CREATE_FLOOR: (buildingId) => `/floors/building/${buildingId}`,
  GET_ALL_FLOORS: "/floors/floor-list",
  GET_FLOORS_OPTIONS_BY_BUILDING: (buildingId) =>
    `/floors/building/${buildingId}`,
  GET_FLOOR_BY_ID: (id) => `/floors/${id}`,
  UPDATE_FLOOR: (id) => `/floors/${id}/update-floor`,
  DELETE_FLOOR: (id) => `/floors/${id}/delete-floor`,
  UPDATE_FLOOR_STATUS: (id) => `/floors/${id}/change-status`,

  CREATE_ZONE: "/zones/create-zone",
  GET_ZONE_BY_ID: (id) => `/zones/${id}/view-zone-details`,
  GET_ZONES: "/zones/zone-list",
  UPDATE_ZONE: (id) => `/zones/${id}/update-zone`,
  DELETE_ZONE: "/zones/delete-zone",
  GET_ZONES_OPTIONS_BY_FLOOR: (floorId) => `/zones/zones-by-floor/${floorId}`,
  UPDATE_ZONE_STATUS: `/zones/update-status`,

  GET_DISCOVERY_DEVICES: "/devices/discovery-list",
  GET_CONFIGURED_DEVICES: "/devices/configured-list",
  DEVICE_CONTROL_DC_COUNT: "/devices/tab-counter",
  CONFIGURE_DEVICE: "/devices/configure",

  GET_DEVICE_DETAILS: (id) => `/devices/${id}`,
  GET_DEVICE_CHANNELS_BY_DEVICE_ID: (id) => `/devices/${id}/channels`,
  UPDATE_DEVICE_CHANNEL: (deviceId, channelId) =>
    `/devices/${deviceId}/channels/${channelId}`,
  GET_CONFIGURED_DEVICES_OPTIONS: "/devices/configured-list",
  DELETE_CONFIGURED_DEVICE: (id) => `/devices/${id}`,
  DELETE_THIRD_PARTY_DEVICE: (id) => `/devices/delete-third-party-device/${id}`,
  UPDATE_CONFIGURED_DEVICE: (id) => `/devices/update-device/${id}`,
  UPDATE_THIRD_PARTY_DEVICE: (id) => `/devices/update-third-party-device/${id}`,
  ADD_DEVICE: "/devices/add-third-party-device",
  REBOOT_DEVICE: "/events/reboot",
  DELETE_SENSOR_FROM_CONTROL_PANEL: (deviceId, channelId) =>
    `/devices/${deviceId}/channels/${channelId}`,

  GET_ACTIVE_DEVICES_OPTIONS_FOR_GROUP: (type = "") =>
    `/groups/active-devices?${type}`,
  GET_DEVICE_CHANNELS_FOR_GROUP: "/groups/device-channels",
  CREATE_GROUP: "/groups/add",
  GET_GROUPS: "/groups/list",
  GET_ALL_GROUP_OPTIONS: "/groups/all",
  GET_GROUP_BY_ID: (id) => `/groups/${id}/view`,
  UPDATE_GROUP: (id) => `/groups/${id}`,
  DELETE_GROUP: (id) => `/groups/${id}`,

  GET_GROUP_DETAILS: (id) => `/groups/${id}/details`,
  GET_MULTIPLE_GROUP_DETAILS: `/groups/details`,
  GET_DEVICE_SCENE_DETAILS: (id) => `/scenes/${id}/details`,

  CREATE_SCENE: "/scenes/add-scene",
  GET_SCENES: "/scenes",
  GET_SCENE_BY_ID: (id) => `/scenes/view/${id}`,
  UPDATE_SCENE: (id) => `/scenes/${id}`,
  DELETE_SCENE: (id) => `/scenes/${id}`,

  GET_DEVICE_OPTIONS_FOR_SENSORS: "/devices/configured-list",
  GET_SENSORS_BY_DEVICE: (deviceId) => `/devices/${deviceId}/sensors-by-device`,
  GET_MOTIONS: "/scenes/all",
  GET_NO_MOTIONS: "/scenes/all",
  CREATE_SENSOR: "/sensors",
  GET_SENSORS: "/sensors/sensor-list",
  GET_SENSOR_BY_ID: (id) => `/sensors/${id}`,
  UPDATE_SENSOR: (id) => `/sensors/update-sensor/${id}`,
  DELETE_SENSOR: (id) => `/sensors/delete/${id}`,

  // Template Management
  GET_TEMPLATE_LIST: "/template/list",
  GET_LAYOUT_LIST: "/template/layout",
  CREATE_TEMPLATE: "/template/add",
  UPDATE_TEMPLATE: "/template/update",
  DELETE_TEMPLATE: "/template/delete",
  GET_TEMPLATE_BY_ID: (id) => `/template/id/${id}`,

  GET_ALL_DEVICES: "/template/hierarchy",
  GET_DEVICE_ID_CONTROL_SYSTEM: (id) => `/groups/device/${id}/details`,
  GET_ALL_DEIVICES_IN_CONTROL_SYSTEM: "/devices/devices-list",
  GET_ALL_GROUPS_IN_CONTROL_SYSTEM: "/groups/groups-list",
  GET_ALL_SCENES_IN_CONTROL_SYSTEM: "/scenes/scenes-list",

  // Event Trigger
  EVENT_TRIGGER: "/events/trigger",

  // User Management
  CREATE_USER: "/users/add-user",
  USERS: "/users/users-list",
  GET_USER_INFO: (id) => `/users/${id}`,
  UPDATE_USER: (id) => `/users/update-user/${id}`,
  UPDATE_USER_STATUS: (id) => `/users/${id}/status`,
  DELETE_USER: (id) => `/users/${id}`,
  // CHANGE_USER_PASSWORD: (id) => `/users/${id}/change-password`,
  CHANGE_USER_PASSWORD: "/auth/change-password",
  UPDATE_USER_LOCATION: (id) => `/users/${id}/update_location`,

  // Role Management
  GET_ROLES_CATEGORIES: "/roles/sections",
  CREATE_ROLE: "/roles/add-role",
  GET_ROLES: "/roles/list",
  GET_ROLES_OPTIONS: "/roles/list",
  GET_ROLE_BY_ID: (id) => `/roles/${id}`,
  UPDATE_ROLE: (id) => `/roles/${id}`,
  UPDATE_ROLE_STATUS: (id) => `/roles/${id}/activate`,
  DELETE_ROLE: (id) => `/roles/${id}`,

  // Logs Management
  GET_MQTT_LOGS: "/logs/get-mqtt-logs",
  GET_EVENT_LOGS: "/logs/get-event-logs",

  // Campus Hierarchy
  GET_CAMPUS_HIERARCHY: "/logs/campus-hierarchy",

  ROLE_BASED_TABS: "/users/tab-names",
  ROLE_TAB_CONTROL_DATA: "/users/module-data-by-role",
  GET_TEMPLATES_IN_CONTROL_SYSTEM: "/template/templates-list",

  // Dashboard
  DASHBOARD_SUMMARY: "/dashboard/summary",
  DASHBOARD_ZONE_STATS: "/dashboard/zone-stats",
  DASHBOARD_DEVICE_INFO: "/dashboard/device-info",
  DASHBOARD_DEVICE_GROUPS: (device_id) => `/dashboard/device-groups/${device_id}`,
  DASHBOARD_ALERTS: (device_id) => `/dashboard/alerts/${device_id}`,

  // Widgets - Timezones
  WIDGETS_TIMEZONES_INITIALIZE: "/widgets/timezones/initialize",
  WIDGETS_TIMEZONES_CREATE: "/widgets/timezones",
  WIDGETS_TIMEZONES_GET: "/widgets/timezones",
  WIDGETS_TIMEZONES_ALL: "/widgets/timezones/all",
  WIDGETS_TIMEZONES_UPDATE: (id) => `/widgets/timezones/${id}`,
  WIDGETS_TIMEZONES_DELETE: (id) => `/widgets/timezones/${id}/status`,

  // Widgets - Weather Locations
  WIDGETS_WEATHER_CREATE: "/widgets/weather",
  WIDGETS_WEATHER_GET: "/widgets/weather/all",
  WIDGETS_WEATHER_UPDATE: (id) => `/widgets/weather/${id}`,
  WIDGETS_WEATHER_DELETE: (id) => `/widgets/weather/${id}`,

  // Widgets - Sensors
  WIDGETS_SENSORS_GET: "/widgets/sensors",

  // Widgets - General
  WIDGETS_ADD: "/widgets/add",
  GET_CREATED_WIDGETS: "/widgets/list",
  GET_WIDGET_BY_ID: (id) => `/widgets/view/${id}`,
  UPDATE_WIDGET: (id) => `/widgets/update-widget/${id}`,
  DELETE_WIDGET: (id) => `/widgets/delete/${id}`,

  GET_FIRST_WEATHER_LOCATION: "/widgets/weather/first",
};

export default ENDPOINTS;
