import { id } from "date-fns/locale";

export const TEMPLATE_LAYOUTS = {
  "1x1_landscape": {
    row: 1,
    col: 1,
    layout: "landscape",
  },
  "1x2_landscape": {
    row: 1,
    col: 2,
    layout: "landscape",
  },
  "1x3_landscape": {
    row: 1,
    col: 3,
    layout: "landscape",
  },
  "1x1_portrait": {
    row: 1,
    col: 1,
    layout: "portrait",
  },
  "1x2_portrait": {
    row: 2,
    col: 1,
    layout: "portrait",
  },
  "1x3_portrait": {
    row: 3,
    col: 1,
    layout: "portrait",
  },
};

export const CAMPUS_TYPES = [
  {
    value: "Residential Apartment",
    label: "Residential Apartment",
  },
  {
    value: "Commercial",
    label: "Commercial",
  },
  {
    value: "Hotel & Resort",
    label: "Hotel & Resort",
  },
];

export const BUILDING_TYPES = [
  {
    value: "Residential Apartment",
    label: "Residential Apartment",
  },
  {
    value: "Commercial",
    label: "Commercial",
  },
  {
    value: "Hotel & Resort",
    label: "Hotel & Resort",
  },
];

export const UNUSED_API_VARIABLES = {
  ORGANIZATION: "MPS - Monolithic Power Systems, Inc.",
  CAMPUSIMAGE: "",
  STATUS: 1,
  TYPE: "academic",
  DESCRIPTION: "",
};

export const MAX_FILE_SIZE_TO_UPLOAD_IMAGE = 1024 * 1024 * 2;
export const VALID_IMAGE_FILE_TYPES = ["image/jpeg", "image/png", "image/jpg"];

export const DUMMY_PERMISSIONS = {
  CAMPUS_MANAGEMENT: {
    campus_management: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
    building_management: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
    floor_management: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
    zone_management: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
  },
  INTELLIGENT_CONTROL: {
    group_management: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
    scene_management: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
    sensor_management: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
    template_management: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
  },
  DEVICE_MANAGEMENT: {
    device_configuration: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
    device_control: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
  },
  USER_MANAGEMENT: {
    user_accounts: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
    role_management: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
  },
  LOGS_MONITORING: {
    system_logs: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
    activity_logs: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
  },
  CONTROL_SECTION: {
    system_control: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
    access_control: {
      fullAccess: true,
      readOnly: true,
      addModify: true,
    },
  },
};

export const ROLE_BASED_TABS = [
  {
    id: "campusManagement",
    name: "Campus Management",
  },
  {
    id: "IntelligentControl",
    name: "Intelligent Control",
  },
  {
    id: "deviceManagement",
    name: "Device Management",
  },
  {
    id: "userManagement",
    name: "User Management",
  },
  {
    id: "logsMonitoring",
    name: "Logs & Monitoring",
  },
  {
    id: "controlSection",
    name: "Control Section",
  },
];

export const TIMEZONES = [
  {
    id: "ist",
    value: "ist",
    label: "India Standard Time (IST)",
    location: "Kolkata, India",
  },
  {
    id: "est",
    value: "est",
    label: "Eastern Standard Time (EST)",
    location: "New York, USA",
  },
  {
    id: "pst",
    value: "pst",
    label: "Pacific Standard Time (PST)",
    location: "Los Angeles, USA",
  },
  {
    id: "cet",
    value: "cet",
    label: "Central European Time (CET)",
    location: "Berlin, Germany",
  },
  {
    id: "cst",
    value: "cst",
    label: "China Standard Time (CST)",
    location: "Beijing, China",
  },
];

export const REGEX = {
  email: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
};
