import { BrowserRouter, Route, Routes } from "react-router-dom";
import { AuthLayout, CheckLogin, MainLayout } from "../layouts";
import {
  AccountManagementCreateRole,
  AccountManagementCreateUser,
  AccountManagementManageRole,
  AccountManagementManageUser,
  AccountManagementViewRole,
  AccountManagementEditRole,
  BMSControl,
  BuildingManagement,
  CampusManagement,
  ControlSystem,
  CreateIntelligentControlTemplate,
  Dashboard,
  DeviceControl,
  EditIntelligentControlTemplate,
  EditCampus,
  FloorManagement,
  ForgotPassword,
  IntelligentControlGroup,
  IntelligentControlScenes,
  IntelligentControlSensors,
  IntelligentControlTemplate,
  LogsMonitoring,
  NewCampus,
  ResetPassword,
  SignIn,
  SignUp,
  VerifyAccount,
  ViewBuildingDetails,
  ViewCampusDetails,
  ViewConfiguredDevice,
  ViewFloorDetails,
  UserProfile,
  EditUserProfile,
  ZoneManagement,
  Widgets,
} from "../pages";
import ViewZoneDetails from "../pages/ViewZoneDetails";
import GeneralWidgets from "../pages/GeneralWidgets";
import CreateWidget from "../pages/CreateWidget";
import EditMyProfile from "../pages/EditMyProfile";

const ROUTES = {
  SIGN_IN: "/auth/sign-in",
  SIGN_UP: "/auth/sign-up",
  FORGOT_PASSWORD: "/auth/forgot-password",
  RESET_PASSWORD: "/auth/reset-password",
  VERIFY_ACCOUNT: "/auth/verify-account",

  DASHBOARD: "/",
  CAMPUS_MANAGEMENT: "/campus-management/campus",
  NEW_CAMPUS: "/campus-management/campus/new",
  EDIT_CAMPUS: "/campus-management/campus/edit/:campusId",
  GET_EDIT_CAMPUS: (campusId) => `/campus-management/campus/edit/${campusId}`,

  BUILDING_MANAGEMENT: "/campus-management/building",
  FLOOR_MANAGEMENT: "/campus-management/floor",
  ZONE_MANAGEMENT: "/campus-management/zone",
  DEVICE_CONTROL: "/device-control",

  INTELLIGENT_CONTROLS_GROUP: "/intelligent-controls/group",
  INTELLIGENT_CONTROLS_SCENES: "/intelligent-controls/scenes",
  INTELLIGENT_CONTROLS_SENSORS: "/intelligent-controls/sensors",
  INTELLIGENT_CONTROLS_TEMPLATE: "/intelligent-controls/template",
  CREATE_INTELLIGENT_CONTROLS_TEMPLATE: "/intelligent-controls/template/create",
  EDIT_INTELLIGENT_CONTROLS_TEMPLATE: "/intelligent-controls/template/edit/:id",
  GET_EDIT_INTELLIGENT_CONTROLS_TEMPLATE: (id) =>
    `/intelligent-controls/template/edit/${id}`,

  MANAGE_USER: "/account-management/manage-user",
  MANAGE_ROLES: "/account-management/manage-roles",
  ROLE_PERMISSIONS: "/account-management/manage-roles", // Alias for consistency

  CREATE_NEW_USER: "/account-management/create-user",
  CREATE_NEW_ROLE: "/account-management/create-role",
  VIEW_ROLE: "/account-management/view-role/:roleId",
  GET_VIEW_ROLE: (roleId) => `/account-management/view-role/${roleId}`,
  EDIT_ROLE: "/account-management/edit-role/:roleId",
  GET_EDIT_ROLE: (roleId) => `/account-management/edit-role/${roleId}`,

  LOGS_MONITORING: "/logs-monitoring",

  VIEW_CAMPUS_DETAILS: "/campus-management/campus/:id",
  GET_VIEW_CAMPUS_DETAILS: (id) => `/campus-management/campus/${id}`,

  VIEW_BUILDING_DETAILS: "/campus-management/building/:id",
  GET_VIEW_BUILDING_DETAILS: (id) => `/campus-management/building/${id}`,

  VIEW_FLOOR_DETAILS: "/campus-management/floor/:id",
  GET_VIEW_FLOOR_DETAILS: (id) => `/campus-management/floor/${id}`,

  VIEW_ZONE_DETAILS: "/campus-management/zone/:id",
  GET_VIEW_ZONE_DETAILS: (id) => `/campus-management/zone/${id}`,

  VIEW_CONFIGURED_DEVICE: "/device-control/configured-device/:id",
  GET_VIEW_CONFIGURED_DEVICE: (id) => `/device-control/configured-device/${id}`,

  // control routes
  CONTROL_DASHBOARD: "/control-dashboard",
  CONTROL_SYSTEM: "/control-system",

  // user routes
  USER_PROFILE: "/user/:userId",
  EDIT_PROFILE: "/edit-profile/:userId",
  GET_USER_PROFILE: (userId) => `/user/${userId}`,
  GET_EDIT_PROFILE: (userId) => `/edit-profile/${userId}`,

  EDIT_USER_PROFILE: "/user/:userId/edit",
  GET_EDIT_USER_PROFILE: (userId) => `/user/${userId}/edit`,

  UTILITIES_WIDGETS: "/utilities/widgets",
  UTILITIES_GENERAL: "/utilities/general",
  UTILITIES_WIDGETS_CREATE: "/utilities/widgets/create",
  UTILITIES_WIDGETS_EDIT: "/utilities/widgets/edit/:widgetId",
  GET_UTILITIES_WIDGETS_EDIT: (widgetId) => `/utilities/widgets/edit/${widgetId}`,

  BMS_CONTROL: "/bms-control",
  VIEW_BMS_CONFIGURED_DEVICE: "/bms-control/configured-device/:id",
  GET_VIEW_BMS_CONFIGURED_DEVICE: (id) => `/bms-control/configured-device/${id}`,
};

export const MODES = {
  CONFIGURATION: "configuration",
  CONTROL: "CONTROL",
};

const Router = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<CheckLogin />}>
          <Route element={<MainLayout mode={MODES.CONTROL} />}>
            <Route
              path={ROUTES.CONTROL_DASHBOARD}
              element={<Dashboard />}
            />
            <Route path={ROUTES.CONTROL_SYSTEM} element={<ControlSystem />} />
          </Route>
          <Route element={<MainLayout mode={MODES.CONFIGURATION} />}>
            <Route path={ROUTES.DASHBOARD} element={<Dashboard />}></Route>
            <Route
              path={ROUTES.CAMPUS_MANAGEMENT}
              element={<CampusManagement />}
            />
            <Route
              path={ROUTES.VIEW_CAMPUS_DETAILS}
              element={<ViewCampusDetails />}
            />
            <Route
              path={ROUTES.BUILDING_MANAGEMENT}
              element={<BuildingManagement />}
            />
            <Route
              path={ROUTES.VIEW_BUILDING_DETAILS}
              element={<ViewBuildingDetails />}
            />
            <Route
              path={ROUTES.FLOOR_MANAGEMENT}
              element={<FloorManagement />}
            />
            <Route
              path={ROUTES.VIEW_FLOOR_DETAILS}
              element={<ViewFloorDetails />}
            />
            <Route path={ROUTES.ZONE_MANAGEMENT} element={<ZoneManagement />} />
            <Route
              path={ROUTES.VIEW_ZONE_DETAILS}
              element={<ViewZoneDetails />}
            />

            <Route path={ROUTES.DEVICE_CONTROL} element={<DeviceControl />} />
            <Route path={ROUTES.BMS_CONTROL} element={<BMSControl />} />
            <Route
              path={ROUTES.VIEW_CONFIGURED_DEVICE}
              element={<ViewConfiguredDevice />}
            />
            <Route
              path={ROUTES.VIEW_BMS_CONFIGURED_DEVICE}
              element={<ViewConfiguredDevice />}
            />

            <Route path={ROUTES.NEW_CAMPUS} element={<NewCampus />} />
            <Route path={ROUTES.EDIT_CAMPUS} element={<EditCampus />} />

            <Route
              path={ROUTES.INTELLIGENT_CONTROLS_GROUP}
              element={<IntelligentControlGroup />}
            />

            <Route
              path={ROUTES.INTELLIGENT_CONTROLS_SCENES}
              element={<IntelligentControlScenes />}
            />

            <Route
              path={ROUTES.INTELLIGENT_CONTROLS_SENSORS}
              element={<IntelligentControlSensors />}
            />

            <Route
              path={ROUTES.INTELLIGENT_CONTROLS_TEMPLATE}
              element={<IntelligentControlTemplate />}
            />
            <Route
              path={ROUTES.CREATE_INTELLIGENT_CONTROLS_TEMPLATE}
              element={<CreateIntelligentControlTemplate />}
            />
            <Route
              path={ROUTES.EDIT_INTELLIGENT_CONTROLS_TEMPLATE}
              element={<EditIntelligentControlTemplate />}
            />

            <Route
              path={ROUTES.MANAGE_USER}
              element={<AccountManagementManageUser />}
            />
            <Route
              path={ROUTES.CREATE_NEW_USER}
              element={<AccountManagementCreateUser />}
            />
            <Route
              path={ROUTES.MANAGE_ROLES}
              element={<AccountManagementManageRole />}
            />
            <Route
              path={ROUTES.CREATE_NEW_ROLE}
              element={<AccountManagementCreateRole />}
            />
            <Route
              path={ROUTES.VIEW_ROLE}
              element={<AccountManagementViewRole />}
            />
            <Route
              path={ROUTES.EDIT_ROLE}
              element={<AccountManagementEditRole />}
            />
            <Route path={ROUTES.LOGS_MONITORING} element={<LogsMonitoring />} />
            <Route path={ROUTES.USER_PROFILE} element={<UserProfile />} />
            <Route path={ROUTES.EDIT_PROFILE} element={<EditMyProfile />} />
            <Route
              path={ROUTES.EDIT_USER_PROFILE}
              element={<EditUserProfile />}
            />
            <Route
              path={ROUTES.UTILITIES_GENERAL}
              element={<GeneralWidgets />}
            />
            <Route path={ROUTES.UTILITIES_WIDGETS} element={<Widgets />} />
            <Route path={ROUTES.UTILITIES_WIDGETS_CREATE} element={<CreateWidget />} />
            <Route path={ROUTES.UTILITIES_WIDGETS_EDIT} element={<CreateWidget mode="edit" />} />
          </Route>
        </Route>

        <Route element={<AuthLayout />}>
          <Route path={ROUTES.SIGN_IN} element={<SignIn />} />
          <Route path={ROUTES.SIGN_UP} element={<SignUp />} />
          <Route path={ROUTES.FORGOT_PASSWORD} element={<ForgotPassword />} />
          <Route path={ROUTES.RESET_PASSWORD} element={<ResetPassword />} />
          <Route path={ROUTES.VERIFY_ACCOUNT} element={<VerifyAccount />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export default Router;
export { ROUTES };
