import { Navigate, Outlet } from "react-router-dom";
import { ROUTES } from "../../router";
import useUserStore from "../../store/useUserStore";
import { connectSocket } from "../../socket";

const CheckLogin = () => {
  const user = useUserStore((state) => state.user);
  const token = useUserStore((state) => state.token);

  if (user) {
    connectSocket(token);
    return <Outlet />;
  } else return <Navigate to={ROUTES.SIGN_IN} />;
};

export default CheckLogin;
