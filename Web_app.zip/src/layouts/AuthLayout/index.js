import { Outlet } from "react-router-dom";
import CBuilding from "../../assets/images/CBuilding.png";
import { LightBuldHeroSvg } from "../../assets/svg";

function TheLeftSide() {
  return (
    <div className="hidden lg:flex w-1/2 bg-white shadow-[1px_0px_6px_#6666661A] rounded-r-[20px] flex-col items-center justify-center">
      <img
        src={CBuilding}
        alt="Building"
        className="w-full max-w-[380px] object-cover"
      />
      <div className="mt-[50px] flex flex-col items-center">
        <h2 className="text-[32px] leading-[40px] font-bold text-[#222222] text-center max-w-[330px]">
          <span>Easy living with your smart devices <LightBuldHeroSvg className="inline h-[30px] mb-2" /></span>
        </h2>
        <p className="text-[18px] leading-[24px] font-normal text-[#7A838E] text-center max-w-[450px] mt-5">
          Get you smart devices in one place and manage all of these with a few
          taps.
        </p>
      </div>
    </div>
  );
}

function AuthLayout() {
  return (
    <div className="w-screen min-h-screen flex bg-[#F3F5F9]">
      <TheLeftSide />
      <div className="w-full lg:w-1/2">
        <Outlet />
      </div>
    </div>
  );
}

export default AuthLayout;
