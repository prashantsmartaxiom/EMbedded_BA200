// MainLayout.jsx
import { Outlet } from "react-router-dom";
import { Header, Sidebar } from "../../components";
import useSidebarStore from "../../store/useSidebarStore";
import { SensorStatusChanged } from "../../components/SocketComponents/SensorStatusChanged";
import { useQueryClient } from "react-query";
import { showToasterFromSocketAlerts } from "../../utils/helpers";
import useUserStore from "../../store/useUserStore";
import QUERY_KEYS from "../../api/queryKeys";
import { LogsStatusChanged } from "../../components/SocketComponents/LogsStatusChanged";

const ContentWrapper = () => {
  const isOpen = useSidebarStore((state) => state.isOpen);
  const isMobile = useSidebarStore((state) => state.isMobile);

  return (
    <div
      className={`flex-1 transition-all duration-300 ${
        !isMobile && isOpen
          ? "ml-0 w-[calc(100vw-245px)]"
          : isMobile
          ? "ml-0"
          : "ml-[-245px] w-[calc(100vw)]"
      }`}
    >
      <Outlet />
    </div>
  );
};

function MainLayout({ mode }) {
  const userPermissions = useUserStore((state) => state.permissions);

  const queryClient = useQueryClient();
  const realTimeChangeCallback = (data) => {
    if (data?.message && !data?.hideToaster)
      showToasterFromSocketAlerts(data, userPermissions);
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DASHBOARD_ALERTS],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.EVENT_LOGS],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.MQTT_LOGS],
      exact: false,
    });
  };

  return (
    <div className="w-screen min-h-screen bg-[#F3F5F9]">
      <SensorStatusChanged />
      <LogsStatusChanged callback={realTimeChangeCallback} />
      <Header mode={mode} />
      <div className="flex relative">
        <Sidebar mode={mode} />
        <ContentWrapper />
      </div>
    </div>
  );
}

export default MainLayout;
