import React from "react";
import {
  AnalogClockSvg,
  CloudSunSvg,
  CloudSvg,
  TemperatureSvg,
} from "../../assets/svg";

// Mini widget content components for smaller displays
const MiniDigitalClockContent = ({ data, ...props }) => {
  // Get time in the specified timezone (simplified for mini version)
  const getTimeInTimezone = () => {
    try {
      const timeInZone = new Date().toLocaleTimeString("en-US", {
        timeZone: data?.timeZoneValue || "UTC",
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      return timeInZone;
    } catch (error) {
      return "00:00";
    }
  };

  // Get day name in the specified timezone
  const getDayInTimezone = () => {
    try {
      return new Date().toLocaleDateString("en-US", {
        timeZone: data?.timeZoneValue || "UTC",
        weekday: "short",
      });
    } catch (error) {
      return "Thu";
    }
  };

  const timeString = getTimeInTimezone();
  const dayName = getDayInTimezone();

  return (
    <div className="flex flex-col items-center justify-center h-full p-1">
      <div className="text-[#222222] font-medium text-[8px] truncate max-w-full mb-1">
        {data?.timeZoneValue || "UTC"}
      </div>
      <div className="text-[#222222] font-semibold text-[14px]">
        {timeString}
      </div>
      <div className="text-[#939CA7] font-medium text-[8px] mt-0.5">
        {dayName}
      </div>
    </div>
  );
};

const MiniAnalogClockContent = ({ data, ...props }) => {
  // Get day name in the specified timezone
  const getDayInTimezone = () => {
    try {
      return new Date().toLocaleDateString("en-US", {
        timeZone: data?.timeZoneValue || "UTC",
        weekday: "short",
      });
    } catch (error) {
      return "Wed";
    }
  };

  const dayName = getDayInTimezone();

  return (
    <div className="flex flex-col items-center justify-center w-full h-full p-1">
      <div className="text-[#222222] font-medium text-[8px] truncate max-w-full mb-1">
        {data?.timeZoneValue || "UTC"}
      </div>
      
      <div className="flex-1 flex items-center justify-center">
        <AnalogClockSvg className="w-[24px] h-[24px] aspect-square" />
      </div>
      
      <div className="text-[#939CA7] font-medium text-[8px] mt-1">
        {dayName}
      </div>
    </div>
  );
};

const MiniWeatherContent = ({ data }) => {
  // Extract basic weather data (simplified version for mini display)
  const temperature = data?.currentHourData?.temperature_2m || 23;
  const placeName = data?.placeName || "Location";
  const aqi = data?.currentHourData?.us_aqi;
  const feelsLike = data?.currentHourData?.apparent_temperature;
  const selectedProperties = data?.selectedProperties || [];
  
  // Show AQI if selected and available
  const showAQI = selectedProperties.includes("aqi") && aqi;
  // Show feels like if selected and available
  const showFeelsLike = selectedProperties.includes("feelsLike") && feelsLike;

  return (
    <div className="flex flex-col items-center justify-center h-full p-1">
      <div className="text-[#222222] text-[8px] font-medium truncate mb-1 max-w-full">
        {placeName}
      </div>
      
      <CloudSunSvg className="w-3 h-3 mb-1" />
      
      <div className="text-[#222222] text-[12px] font-semibold">
        {Math.round(temperature)}°
      </div>
      
      {/* Show additional properties if selected */}
      <div className="flex flex-col items-center mt-1 gap-0.5">
        {showFeelsLike && (
          <div className="text-[#939CA7] text-[8px]">
            Feel {Math.round(feelsLike)}°
          </div>
        )}
        {showAQI && (
          <div className="text-[#939CA7] text-[8px]">
            AQI {aqi}
          </div>
        )}
      </div>
    </div>
  );
};



const renderMiniWidgetContent = (widget) => {
  switch (widget.type) {
    case "digital-clock":
      return <MiniDigitalClockContent data={widget.data} />;
    case "analog-clock":
      return <MiniAnalogClockContent data={widget.data} />;
    case "weather":
      return <MiniWeatherContent data={widget.data} />;
    default:
      return (
        <div className="flex items-center justify-center h-full text-[#939CA7] text-[10px]">
          {widget.type || "Unknown"}
        </div>
      );
  }
};

export const MiniLandscapeLayout = ({
  selectedWidgets,
  className = "w-[320px] h-[140px] border border-[#C1DBF9] bg-[#F5F9FD] rounded-[6px]",
}) => {
  const widgets = selectedWidgets;

  return (
    <div className={`relative ${className} flex`}>
      {widgets.map((widget, index) => (
        <React.Fragment key={widget.id}>
          <div className="p-1 overflow-hidden flex-1">
            {renderMiniWidgetContent(widget)}
          </div>
          {/* Add vertical separator line between widgets (not after last widget) */}
          {index < widgets.length - 1 && (
            <div className="w-[1px] bg-[#C1DBF9] my-2"></div>
          )}
        </React.Fragment>
      ))}
    </div>
  );
};

export const MiniPortraitLayout = ({
  selectedWidgets,
  className = "w-[140px] h-[234px] border border-[#C1DBF9] bg-[#F5F9FD] rounded-[6px]",
}) => {
  const widgets = selectedWidgets;

  return (
    <div className={`relative ${className} flex flex-col`}>
      {widgets.map((widget, index) => (
        <React.Fragment key={widget.id}>
          <div className="p-1 overflow-hidden flex-1">
            {renderMiniWidgetContent(widget)}
          </div>
          {/* Add horizontal separator line between widgets (not after last widget) */}
          {index < widgets.length - 1 && (
            <div className="h-[1px] bg-[#C1DBF9] mx-2"></div>
          )}
        </React.Fragment>
      ))}
    </div>
  );
};
