import { useEffect, useState } from "react";
import { FiUpload, FiX, SearchSvg } from "../../assets/svg";
import toaster from "../../utils/toaster";

function Input({ className = "", ...props }) {
  return (
    <input
      className={`text-[#222222] font-medium placeholder:font-normal placeholder:text-[#939CA7] rounded-[10px] block border border-[#E7E8E8] bg-[ffffff] p-[10px] text-xs focus:outline-[#227EEB] ${className}`}
      {...props}
    />
  );
}

export function PrimaryInput({ className = "", ...props }) {
  return (
    <input
      className={`disabled:bg-[#F5F5F5] font-medium placeholder:font-normal h-[42px] text-[#222222] bg-[#F6F8FF] placeholder:text-[#939CA7] rounded-[10px] block border border-[#E7E8E8] bg-[ffffff] p-[10px] text-xs focus:outline-[#227EEB] ${className}`}
      {...props}
    />
  );
}

export function PrimaryTextarea({ className = "", ...props }) {
  return (
    <textarea
      className={`text-[#222222] bg-[#F6F8FF] placeholder:text-[#939CA7] font-medium placeholder:font-normal rounded-[10px] block border border-[#E7E8E8] bg-[ffffff] p-[10px] text-xs focus:outline-[#227EEB] ${className}`}
      {...props}
    />
  );
}

export const SearchInput = ({ className = "", ...props }) => {
  return (
    <div
      className={`h-[36px] flex items-center rounded-[10px] border border-[#E7E8E8] bg-[ffffff] p-[10px] text-xs focus-within:border-[#227EEB] ${className}`}
    >
      <SearchSvg className="h-[14px] w-[14px] text-[#939CA7]" />
      <input
        type="text"
        className="ml-2 text-xs w-full border-none bg-transparent font-medium placeholder:font-normal text-[#222222] placeholder:text-[#939CA7] focus:outline-none"
        {...props}
      />
    </div>
  );
};

export const PrimaryFileInput = ({
  type="image",
  label = "Upload File",
  description = "Please upload a file",
  accept = "image/*",
  maxSizeMB = 2,
  onFileSelect,
  value, // Add this prop
  imageUrl,
}) => {
  const [file, setFile] = useState(value); // Initialize with prop value
  const [localImagePreview, setLocalImagePreview] = useState(null); // For local file preview

  // Use useEffect to update internal state when the 'value' prop changes
  useEffect(() => {
    setFile(value);
    // If value is cleared, also clear the local preview
    if (!value) {
      setLocalImagePreview(null);
    }
  }, [value]);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (!selectedFile) {
      setFile(null);
      setLocalImagePreview(null);
      if (onFileSelect) onFileSelect(null);
      return;
    }
    if (selectedFile.size > maxSizeMB * 1024 * 1024) {
      toaster.error(`File size should be less than ${maxSizeMB}MB`);
      setFile(null);
      setLocalImagePreview(null);
      if (onFileSelect) onFileSelect(null);
      return;
    }
    
    // Create preview URL for local file
    const previewUrl = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setLocalImagePreview(previewUrl);
    if (onFileSelect) onFileSelect(selectedFile);
  };

  const handleRemoveFile = () => {
    // Revoke the object URL to prevent memory leaks
    if (localImagePreview) {
      URL.revokeObjectURL(localImagePreview);
    }
    setFile(null);
    setLocalImagePreview(null);
    if (onFileSelect) onFileSelect(null);
    // Also clear the input element's value to allow re-selection of the same file
    const inputElement = document.querySelector(
      `input[type="file"][accept="${accept}"]`
    );
    if (inputElement) {
      inputElement.value = "";
    }
  };

  // Clean up object URL when component unmounts or local preview changes
  useEffect(() => {
    return () => {
      if (localImagePreview) {
        URL.revokeObjectURL(localImagePreview);
      }
    };
  }, [localImagePreview]);

  // Determine which image to show: local preview first, then imageUrl prop
  const displayImageUrl = localImagePreview || imageUrl;

  return (
    <div className="flex items-center space-x-4 h-full">
      <label className="relative max-h-[138px] flex flex-col items-center justify-center border-2 border-dashed border-[#227EEB] rounded-lg cursor-pointer bg-[#F6F8FF] h-full aspect-square flex-shrink-0">
        <FiUpload className="text-[#227EEB]" size={32} />
        <input
          type="file"
          accept={accept}
          className="hidden"
          onChange={handleFileChange}
          // The value prop on file inputs should generally be uncontrolled or set to an empty string
          // to allow re-selection of the same file.
          value={""}
        />
        {displayImageUrl ? (
          <div className="absolute w-full h-full pointer-events-none left-0 top-0 rounded-lg overflow-hidden opacity-45">
            <img
              className="w-full h-full object-cover"
              src={displayImageUrl}
              alt="image preview"
            />
          </div>
        ) : null}
      </label>
      <div className="truncate">
        <p className="font-medium text-[#222222]">{label}</p>
        <p className="text-[10px] text-[#888888]">{description}</p>
        <p className="text-[10px] text-[#888888]">Accepted format: JPEG, PNG</p>
        {file && (
          <div className="truncate flex items-center mt-2 text-xs text-[#227EEB] font-semibold">
            <p className="mr-1 truncate">{file.name} </p>
            <button
              onClick={handleRemoveFile}
              className="text-red-500 hover:text-red-700 focus:outline-none"
              title="Remove file"
              type="button"
            >
              <FiX size={18} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Input;
