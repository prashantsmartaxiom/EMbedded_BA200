import { useState, useEffect, useRef } from "react";
import { LocationDropdown } from "../Dropdowns";
import { getWeatherSvg } from "../../pages/Dashboard/WeatherCard";

const WeatherWidget = ({ 
  location, 
  onLocationChange, 
  onDelete, 
  isNewLocation = false 
}) => {
  const [selectedLocation, setSelectedLocation] = useState(location || null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const dropdownRef = useRef(null);

  const handleLocationChange = (locationData) => {
    setIsLoadingLocation(true);
    setSelectedLocation(locationData);
    
    // Simulate a small delay for UX
    setTimeout(() => {
      setIsLoadingLocation(false);
      if (onLocationChange) {
        onLocationChange(locationData);
      }
    }, 300);
  };

  // Fetch weather data for the current location
  // const { data: weatherData, isLoading: isLoadingWeather } = useOpenMeteoWeather({
  //   lat: selectedLocation?.lat,
  //   long: selectedLocation?.long,
  //   enabled: Boolean(selectedLocation?.lat && selectedLocation?.long),
  // });

  const getTemperatureDisplay = () => {
    if (location?.currentHourData?.temperature_2m)
      return `${location.currentHourData.temperature_2m.toFixed(1)} °c`;
    return "-- °c";
  };

  const getLocationName = () => {
    if (isLoadingLocation) {
      return "Loading...";
    }
    if (selectedLocation?.placeName) {
      return selectedLocation.placeName.length > 25 
        ? selectedLocation.placeName.substring(0, 25) + "..."
        : selectedLocation.placeName;
    }
    return "Select Location";
  };

  const getLocationForWeather = () => {
    return selectedLocation?.lat && selectedLocation?.long ? selectedLocation : null;
  };

  // Auto-focus dropdown when isNewLocation is true
  useEffect(() => {
    if (isNewLocation && dropdownRef.current) {
      // Small delay to ensure the component is fully rendered
      setTimeout(() => {
        const trigger = dropdownRef.current.querySelector('button');
        if (trigger) {
          trigger.click();
        }
      }, 100);
    }
  }, [isNewLocation]);

  // Get weather data from location
  const weatherCode = location?.currentHourData?.weather_code;
  const isDay = location?.currentHourData?.is_day;
  
  // Get the appropriate weather SVG component
  const WeatherSvgComponent = getWeatherSvg(weatherCode, isDay);

  return (
    <div className="flex-shrink-0 w-[280px] h-[160px] border border-[#DDDDDD] rounded-[10px] p-[10px] relative">
      {/* {onDelete && !isNewLocation && (
        <button
          onClick={() => onDelete(location._id)}
          className="absolute top-2 right-2 text-red-500 hover:text-red-700 font-bold text-sm z-10"
        >
          ×
        </button>
      )} */}
      
      <div className="h-[85px] w-full border border-[#C1DBF9] bg-[#F5F9FD] rounded-[10px] flex items-center justify-between px-4">
        <WeatherSvgComponent className="" />
        <div className="text-right">
          <div className="text-[#222222] text-xl font-semibold">
            {getTemperatureDisplay()}
          </div>
          <div className="text-[#7A838E] text-xs mt-1 flex items-center gap-1">
            {isLoadingLocation && (
              <div className="w-3 h-3 border border-gray-400 border-t-transparent rounded-full animate-spin"></div>
            )}
            <span>{isNewLocation ? "New Location" : getLocationName()}</span>
          </div>
        </div>
      </div>
      
      <div className="mt-[10px]" ref={dropdownRef}>
        <LocationDropdown
          value={selectedLocation}
          onValueChange={handleLocationChange}
          placeholder="Select Location"
          className="text-sm"
        />
      </div>
    </div>
  );
};

export default WeatherWidget;