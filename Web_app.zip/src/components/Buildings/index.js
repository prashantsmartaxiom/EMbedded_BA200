export { default as DeleteBuildingButton } from "./DeleteBuildingButton";
