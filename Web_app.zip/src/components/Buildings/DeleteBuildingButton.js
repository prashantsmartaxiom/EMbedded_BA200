import { useState } from "react";
import { DeleteSvg } from "../../assets/svg";
import DeleteBuildingPopup from "../../pages/ViewBuildingDetails/DeleteBuildingPopup";

const DeleteBuildingButton = ({ building_id, className = "", children }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <button
        type="button"
        className={`text-[#FF1212] flex items-center gap-[4px] ${className}`}
        onClick={toggleModal}
      >
        <DeleteSvg className="fill-[#ff1212]" /> 
        {children || "Delete"}
      </button>
      {open ? (
        <DeleteBuildingPopup toggleModal={toggleModal} buildingId={building_id} />
      ) : null}
    </>
  );
};

export default DeleteBuildingButton;
