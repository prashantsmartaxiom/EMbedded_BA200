import { NavLink } from "react-router-dom";
import { MODES, ROUTES } from "../../router";
import useUserStore from "../../store/useUserStore";

export default function SystemSelector({ mode }) {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="inline-flex rounded-full bg-[#EEEEEE] p-1">
      {userPermissions?.CONTROL_SECTION?.access ? (
        <NavLink
          // to={ROUTES.CONTROL_DASHBOARD}
          to={ROUTES.CONTROL_SYSTEM}
          className={`px-[15px] py-[5px] text-xs font-semibold rounded-full transition-colors ${
            mode === MODES.CONTROL
              ? "bg-white text-[#227EEB] [box-shadow:0px_1px_3px_#22222226]"
              : "text-[#7A838E]"
          }`}
        >
          Controls
        </NavLink>
      ) : null}

      <NavLink
        to={ROUTES.DASHBOARD}
        // to={ROUTES.CAMPUS_MANAGEMENT}
        className={`px-[15px] py-[5px] text-xs font-semibold rounded-full transition-colors ${
          mode === MODES.CONFIGURATION
            ? "bg-white text-[#227EEB] [box-shadow:0px_1px_3px_#22222226]"
            : "text-[#7A838E]"
        }`}
      >
        Configurations
      </NavLink>
    </div>
  );
}
