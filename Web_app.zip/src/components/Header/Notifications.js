import { NotificationSvg } from "../../assets/svg";

function Notifications() {
  return (
    <div className="hidden 800:block">
      <NotificationSvg />
    </div>
  );
}

export default Notifications;
