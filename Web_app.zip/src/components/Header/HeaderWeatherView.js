import { HeaderAQISvg, HeaderTemperatureSvg } from "../../assets/svg";
import Seperator from "./Seperator";
import { useWeatherAndAQI } from "../../api/queryHooks";

export default function HeaderWeatherView() {
  const lat = 37.3382;
  const long = -121.8863;
  // const lat = 22.719568;
  // const long = 75.857727;

  const {
    data: weatherData,
    isLoading,
    isError,
    error,
  } = useWeatherAndAQI({ lat, long });

  // Extract temperature and AQI from the response
  const temperature = weatherData?.temperature;
  const aqi = weatherData?.aqi;

  // Log errors for debugging
  if (isError) {
    console.error("⚠️ Failed to fetch weather/AQI:", error);
  }

  return (
    <div className="inline-flex rounded-full bg-[#F5F9FD] border border-[#C0DAF9] px-[10px] py-[6px]">
      {/* Temperature */}
      <div className={`text-xs text-[#222222] font-medium flex items-center`}>
        <span>
          <HeaderTemperatureSvg />
        </span>
        <span className="ml-1 text-[#227EEB]">:</span>
        <span className="ml-[6px]">
          {isLoading
            ? "..."
            : temperature !== null
            ? `${temperature.toFixed(1)}°c`
            : "—"}
        </span>
      </div>

      <Seperator
        className="mx-[10px] h-[20px] hidden 800:block"
        borderClassName="border-[#C0DAF9]"
      />

      {/* AQI */}
      <div className={`text-xs text-[#222222] font-medium flex items-center`}>
        <span>
          <HeaderAQISvg />
        </span>
        <span className="ml-1 text-[#227EEB]">:</span>
        <span className="ml-[6px]">
          {isLoading ? "..." : aqi !== null ? aqi : "—"}
        </span>
      </div>
    </div>
  );
}
