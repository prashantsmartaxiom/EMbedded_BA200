import * as Popover from "@radix-ui/react-popover";
import useUserStore from "../../store/useUserStore";
import { LockSvg, LogoutSvg, UserSvg } from "../../assets/svg";
import { Link } from "react-router-dom";
import { ROUTES } from "../../router";
import { useGetRoleById } from "../../api/queryHooks";
import { disconnectSocket } from "../../socket";

function UserProfile() {
  const user = useUserStore((state) => state.user);
  const role = useGetRoleById(user?.roleId)?.data?.data?.role;

  const handleLogout = () => {
    localStorage.clear();
    window.location.href = "/";
    disconnectSocket();
  };

  return (
    <Popover.Root>
      <Popover.Trigger asChild>
        <div className="flex items-center gap-2 cursor-pointer">
          <div className="max-w-[150px] truncate hidden lg:block">
            <h3 className="text-xs text-[#222222] truncate">{user.fullName}</h3>
            <p className="text-xs text-[#227EEB]">
              <span title={user?.id}>
                {user?.id ? user.id.slice(-4)?.toUpperCase() : "UID"},{" "}
              </span>
              <span>{role?.roleName ? role?.roleName : "--"}</span>
            </p>
          </div>
          {user?.profileImage ? (
            <div className="w-8 h-8 rounded-full border">
              <img
                src={user.profileImage}
                alt="Profile"
                className="w-full h-full object-cover rounded-full"
              />
            </div>
          ) : (
            <div className="w-8 h-8 rounded-full border flex items-center justify-center">
              <UserSvg className="w-4 h-4 object-cover fill-[#aaa]" />
            </div>
          )}
        </div>
      </Popover.Trigger>

      <Popover.Portal>
        <Popover.Content
          className="bg-white rounded-lg shadow-lg  p-1 w-48 z-50"
          align="end"
        >
          <div className="flex flex-col gap-1">
            <Link
              to={ROUTES.GET_USER_PROFILE(user?.id)}
              className="flex items-center gap-3 px-3 py-2 text-xs text-[#222222] focus:outline-none"
            >
              <UserSvg className="w-4 h-4 fill-[#222222]" />
              View Profile
            </Link>

            <div className="h-px bg-[#CCCCCC]" />

            <Link
              to={ROUTES.GET_USER_PROFILE(user?.id)}
              className="flex items-center gap-3 px-3 py-2 text-xs text-[#222222] focus:outline-none"
            >
              <LockSvg className="w-4 h-4" />
              Change Password
            </Link>

            <div className="h-px bg-[#CCCCCC]" />

            <button
              onClick={handleLogout}
              className="flex items-center gap-3 px-3 py-2 text-xs text-[#222222] focus:outline-none"
            >
              <LogoutSvg className="w-4 h-4" />
              Logout
            </button>
          </div>
          <Popover.Arrow className="fill-white" />
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
}

export default UserProfile;
