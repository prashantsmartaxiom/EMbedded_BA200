import { useState, useEffect, useMemo } from "react";
import { LocationSvg } from "../../assets/svg";
import useLocationSelectedStore from "../../store/useLocationSelectedStore";
import useUserStore from "../../store/useUserStore";
import { CenterModal } from "../Models";
import { PrimaryBtn2, SecondaryBtn } from "../Buttons";
import MyCheckbox from "../Checkboxs";
import {
  useGetCampusHierarchy,
  useUpdateUserLocation,
} from "../../api/queryHooks";
import toaster from "../../utils/toaster";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../api/queryKeys";

const Checkbox = ({
  checked,
  indeterminate = false,
  onChange,
  children,
  className = "",
}) => {
  return (
    <label className={`flex items-center gap-2 cursor-pointer ${className}`}>
      <MyCheckbox
        checked={checked}
        onCheckedChange={onChange}
        indeterminate={indeterminate}
      />

      <span className="text-xs text-gray-700 select-none">{children}</span>
    </label>
  );
};

// Zone component
const ZoneItem = ({ zone, floorId, isSelected, onToggle }) => {
  return (
    <div className="ml-8">
      <Checkbox checked={isSelected} onChange={() => onToggle(zone.id)}>
        {zone.name}
      </Checkbox>
    </div>
  );
};

// Floor component
const FloorItem = ({
  floor,
  buildingId,
  isSelected,
  areAllZonesSelected,
  selectedZones,
  onToggle,
  onZoneToggle,
}) => {
  const zones = floor.zones || [];

  return (
    <div className="ml-6">
      <Checkbox
        checked={isSelected}
        indeterminate={isSelected && !areAllZonesSelected && zones.length > 0}
        onChange={() => onToggle(floor.id)}
        className="font-medium text-blue-600"
      >
        {floor.name}
      </Checkbox>
      {zones.length > 0 && (
        <div className="mt-2 space-y-1">
          {zones.map((zone) => (
            <ZoneItem
              key={zone.id}
              zone={zone}
              floorId={floor.id}
              isSelected={selectedZones.has(zone.id)}
              onToggle={onZoneToggle}
            />
          ))}
        </div>
      )}
    </div>
  );
};

// Building component
const BuildingItem = ({
  building,
  campusId,
  isSelected,
  areAllFloorsSelected,
  isCollapsed,
  selectedFloors,
  selectedZones,
  areAllZonesSelectedMap,
  onToggle,
  onCollapse,
  onFloorToggle,
  onZoneToggle,
  onUnselectBuilding,
}) => {
  const floors = building.floors || [];

  return (
    <div className="border border-[#DDDDDD] rounded-lg mb-3 overflow-hidden">
      <div className="bg-[#F2F4F8] p-3">
        <div className="flex items-center justify-between">
          <Checkbox
            checked={isSelected}
            indeterminate={isSelected && !areAllFloorsSelected}
            onChange={() => onToggle(building.id)}
            className="font-semibold"
          >
            {building.name}
          </Checkbox>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onUnselectBuilding(building.id)}
              className="text-xs text-blue-600 hover:text-blue-800"
            >
              Unselect All
            </button>
            <button
              onClick={() => onCollapse(building.id)}
              className="text-gray-500 hover:text-gray-700 p-1"
            >
              <svg
                className={`w-4 h-4 transform transition-transform ${
                  isCollapsed ? "rotate-0" : "rotate-90"
                }`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5l7 7-7 7"
                />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {!isCollapsed && (
        <div className="p-3 grid grid-cols-2 gap-5">
          {floors.length > 0 ? (
            floors.map((floor) => (
              <FloorItem
                key={floor.id}
                floor={floor}
                buildingId={building.id}
                isSelected={selectedFloors.has(floor.id)}
                areAllZonesSelected={areAllZonesSelectedMap[floor.id] || false}
                selectedZones={selectedZones}
                onToggle={onFloorToggle}
                onZoneToggle={onZoneToggle}
              />
            ))
          ) : (
            <div className="col-span-2 text-center text-gray-500 py-4">
              No floors available for this building
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// Campus component
const CampusItem = ({ campus, tempSelections, tempActions }) => {
  const {
    tempSelectedCampuses,
    tempSelectedBuildings,
    tempSelectedFloors,
    tempSelectedZones,
    collapsedBuildings,
  } = tempSelections;

  const {
    toggleTempCampusSelection,
    toggleTempBuildingSelection,
    toggleTempFloorSelection,
    toggleTempZoneSelection,
    toggleBuildingCollapse,
    areAllTempBuildingsSelected,
    areAllTempFloorsSelected,
    areAllTempZonesSelected,
    unselectTempBuilding,
  } = tempActions;

  const buildings = campus.buildings || [];
  const isSelected = tempSelectedCampuses.has(campus.id);
  const areAllSelected = areAllTempBuildingsSelected(campus.id);

  // Pre-calculate areAllZonesSelected for all floors to avoid calling hooks in render
  const areAllZonesSelectedMap = {};
  buildings.forEach((building) => {
    building.floors.forEach((floor) => {
      areAllZonesSelectedMap[floor.id] = areAllTempZonesSelected(floor.id);
    });
  });

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#DDDDDD]">
        <Checkbox
          checked={isSelected}
          indeterminate={isSelected && !areAllSelected}
          onChange={() => toggleTempCampusSelection(campus.id)}
          className="font-bold text-lg"
        >
          {campus.name}
        </Checkbox>
      </div>

      <div className="space-y-3">
        {buildings.map((building) => (
          <BuildingItem
            key={building.id}
            building={building}
            campusId={campus.id}
            isSelected={tempSelectedBuildings.has(building.id)}
            areAllFloorsSelected={areAllTempFloorsSelected(building.id)}
            isCollapsed={collapsedBuildings.has(building.id)}
            selectedFloors={tempSelectedFloors}
            selectedZones={tempSelectedZones}
            areAllZonesSelectedMap={areAllZonesSelectedMap}
            onToggle={toggleTempBuildingSelection}
            onCollapse={toggleBuildingCollapse}
            onFloorToggle={toggleTempFloorSelection}
            onZoneToggle={toggleTempZoneSelection}
            onUnselectBuilding={unselectTempBuilding}
          />
        ))}
      </div>
    </div>
  );
};

const LocationChanger = () => {
  const [open, setIsOpen] = useState(false);
  const location = useLocationSelectedStore((state) => state.location);
  const user = useUserStore((state) => state.user);
  const {
    setLocationData,
    setLocationLoading,
    setLocationError,
    initializeSelections,
  } = useLocationSelectedStore();

  // Get selected data from store (for initial values only)
  const storeSelections = useLocationSelectedStore();

  // Local state for temporary selections (used in the modal)
  const [tempSelectedCampuses, setTempSelectedCampuses] = useState(new Set());
  const [tempSelectedBuildings, setTempSelectedBuildings] = useState(new Set());
  const [tempSelectedFloors, setTempSelectedFloors] = useState(new Set());
  const [tempSelectedZones, setTempSelectedZones] = useState(new Set());

  // Collapsed buildings state (can be local to modal)
  const [collapsedBuildings, setCollapsedBuildings] = useState(new Set());

  // Fetch campus hierarchy data
  const {
    data: campusHierarchyData,
    isLoading,
    error,
    refetch,
  } = useGetCampusHierarchy();

  const queryClient = useQueryClient();

  // Update user location mutation
  const updateLocationMutation = useUpdateUserLocation({
    onSuccess: () => {
      // Update the main store with the temporary selections
      initializeSelections(
        Array.from(tempSelectedCampuses),
        Array.from(tempSelectedBuildings),
        Array.from(tempSelectedFloors),
        Array.from(tempSelectedZones)
      );

      // invalidate all APIs
      queryClient.invalidateQueries();
      toaster.success("Location updated successfully!");
      setIsOpen(false);
    },
    onError: (error) => {
      const errorMessage =
        error.response?.data?.message ||
        "Failed to update location. Please try again.";
      toaster.error(errorMessage);
    },
  });

  // Update store when data changes
  useEffect(() => {
    if (isLoading) {
      setLocationLoading(true);
    } else if (error) {
      setLocationError(error.message || "Failed to fetch campus data");
    } else if (campusHierarchyData?.success && campusHierarchyData?.data) {
      setLocationData(campusHierarchyData.data);

      // Initialize selection state based on isChecked properties
      const selectedCampusIds = [];
      const selectedBuildingIds = [];
      const selectedFloorIds = [];
      const selectedZoneIds = [];

      campusHierarchyData.data.forEach((campus) => {
        if (campus.isChecked) {
          selectedCampusIds.push(campus.id);
        }

        campus.buildings?.forEach((building) => {
          if (building.isChecked) {
            selectedBuildingIds.push(building.id);
          }

          building.floors?.forEach((floor) => {
            if (floor.isChecked) {
              selectedFloorIds.push(floor.id);
            }

            floor.zones?.forEach((zone) => {
              if (zone.isChecked) {
                selectedZoneIds.push(zone.id);
              }
            });
          });
        });
      });

      // Update the selection state in the store
      initializeSelections(
        selectedCampusIds,
        selectedBuildingIds,
        selectedFloorIds,
        selectedZoneIds
      );

      // Also initialize temporary state with current selections
      setTempSelectedCampuses(new Set(selectedCampusIds));
      setTempSelectedBuildings(new Set(selectedBuildingIds));
      setTempSelectedFloors(new Set(selectedFloorIds));
      setTempSelectedZones(new Set(selectedZoneIds));
    }
  }, [
    campusHierarchyData,
    isLoading,
    error,
    setLocationData,
    setLocationLoading,
    setLocationError,
    initializeSelections,
  ]);

  const toggleModal = (value) => {
    if (value) {
      // When opening modal, initialize temp selections with current store selections
      setTempSelectedCampuses(new Set(storeSelections.selectedCampuses));
      setTempSelectedBuildings(new Set(storeSelections.selectedBuildings));
      setTempSelectedFloors(new Set(storeSelections.selectedFloors));
      setTempSelectedZones(new Set(storeSelections.selectedZones));
    }
    setIsOpen(value);
  };

  // Temporary selection management functions
  const toggleTempCampusSelection = (campusId) => {
    const newSelected = new Set(tempSelectedCampuses);
    const campus = location.data.find((c) => c.id === campusId);

    if (newSelected.has(campusId)) {
      newSelected.delete(campusId);
      // Deselect all children
      campus.buildings.forEach((building) => {
        tempSelectedBuildings.delete(building.id);
        building.floors.forEach((floor) => {
          tempSelectedFloors.delete(floor.id);
          floor.zones.forEach((zone) => {
            tempSelectedZones.delete(zone.id);
          });
        });
      });
    } else {
      newSelected.add(campusId);
      // Select all children
      campus.buildings.forEach((building) => {
        tempSelectedBuildings.add(building.id);
        building.floors.forEach((floor) => {
          tempSelectedFloors.add(floor.id);
          floor.zones.forEach((zone) => {
            tempSelectedZones.add(zone.id);
          });
        });
      });
    }

    setTempSelectedCampuses(newSelected);
    setTempSelectedBuildings(new Set(tempSelectedBuildings));
    setTempSelectedFloors(new Set(tempSelectedFloors));
    setTempSelectedZones(new Set(tempSelectedZones));
  };

  const toggleTempBuildingSelection = (buildingId) => {
    const newSelected = new Set(tempSelectedBuildings);
    let building = null;
    let campus = null;

    // Find building and its parent campus
    for (const c of location.data) {
      const b = c.buildings.find((b) => b.id === buildingId);
      if (b) {
        building = b;
        campus = c;
        break;
      }
    }

    if (!building) return;

    if (newSelected.has(buildingId)) {
      newSelected.delete(buildingId);
      // Deselect all child floors and zones
      building.floors.forEach((floor) => {
        tempSelectedFloors.delete(floor.id);
        floor.zones.forEach((zone) => {
          tempSelectedZones.delete(zone.id);
        });
      });
      // Deselect parent campus if no other buildings selected
      const otherBuildingsSelected = campus.buildings.some(
        (b) => b.id !== buildingId && newSelected.has(b.id)
      );
      if (!otherBuildingsSelected) {
        tempSelectedCampuses.delete(campus.id);
      }
    } else {
      newSelected.add(buildingId);
      // Select all child floors and zones
      building.floors.forEach((floor) => {
        tempSelectedFloors.add(floor.id);
        floor.zones.forEach((zone) => {
          tempSelectedZones.add(zone.id);
        });
      });
      // Select parent campus
      tempSelectedCampuses.add(campus.id);
    }

    setTempSelectedBuildings(newSelected);
    setTempSelectedCampuses(new Set(tempSelectedCampuses));
    setTempSelectedFloors(new Set(tempSelectedFloors));
    setTempSelectedZones(new Set(tempSelectedZones));
  };

  const toggleTempFloorSelection = (floorId) => {
    const newSelected = new Set(tempSelectedFloors);
    let floor = null;
    let building = null;
    let campus = null;

    // Find floor and its parents
    for (const c of location.data) {
      for (const b of c.buildings) {
        const f = b.floors.find((f) => f.id === floorId);
        if (f) {
          floor = f;
          building = b;
          campus = c;
          break;
        }
      }
      if (floor) break;
    }

    if (!floor) return;

    if (newSelected.has(floorId)) {
      newSelected.delete(floorId);
      // Deselect all child zones
      floor.zones.forEach((zone) => {
        tempSelectedZones.delete(zone.id);
      });
      // Check if building should be deselected
      const otherFloorsSelected = building.floors.some(
        (f) => f.id !== floorId && newSelected.has(f.id)
      );
      if (!otherFloorsSelected) {
        tempSelectedBuildings.delete(building.id);
        // Check if campus should be deselected
        const otherBuildingsSelected = campus.buildings.some(
          (b) => b.id !== building.id && tempSelectedBuildings.has(b.id)
        );
        if (!otherBuildingsSelected) {
          tempSelectedCampuses.delete(campus.id);
        }
      }
    } else {
      newSelected.add(floorId);
      // Select all child zones
      floor.zones.forEach((zone) => {
        tempSelectedZones.add(zone.id);
      });
      // Select parent building and campus
      tempSelectedBuildings.add(building.id);
      tempSelectedCampuses.add(campus.id);
    }

    setTempSelectedFloors(newSelected);
    setTempSelectedBuildings(new Set(tempSelectedBuildings));
    setTempSelectedCampuses(new Set(tempSelectedCampuses));
    setTempSelectedZones(new Set(tempSelectedZones));
  };

  const toggleTempZoneSelection = (zoneId) => {
    const newSelected = new Set(tempSelectedZones);
    let zone = null;
    let floor = null;
    let building = null;
    let campus = null;

    // Find zone and its parents
    for (const c of location.data) {
      for (const b of c.buildings) {
        for (const f of b.floors) {
          const z = f.zones.find((z) => z.id === zoneId);
          if (z) {
            zone = z;
            floor = f;
            building = b;
            campus = c;
            break;
          }
        }
        if (zone) break;
      }
      if (zone) break;
    }

    if (!zone) return;

    if (newSelected.has(zoneId)) {
      newSelected.delete(zoneId);
      // Check if floor should be deselected
      const otherZonesSelected = floor.zones.some(
        (z) => z.id !== zoneId && newSelected.has(z.id)
      );
      if (!otherZonesSelected) {
        tempSelectedFloors.delete(floor.id);
        // Check if building should be deselected
        const otherFloorsSelected = building.floors.some(
          (f) => f.id !== floor.id && tempSelectedFloors.has(f.id)
        );
        if (!otherFloorsSelected) {
          tempSelectedBuildings.delete(building.id);
          // Check if campus should be deselected
          const otherBuildingsSelected = campus.buildings.some(
            (b) => b.id !== building.id && tempSelectedBuildings.has(b.id)
          );
          if (!otherBuildingsSelected) {
            tempSelectedCampuses.delete(campus.id);
          }
        }
      }
    } else {
      newSelected.add(zoneId);
      // Select parent floor, building, and campus
      tempSelectedFloors.add(floor.id);
      tempSelectedBuildings.add(building.id);
      tempSelectedCampuses.add(campus.id);
    }

    setTempSelectedZones(newSelected);
    setTempSelectedFloors(new Set(tempSelectedFloors));
    setTempSelectedBuildings(new Set(tempSelectedBuildings));
    setTempSelectedCampuses(new Set(tempSelectedCampuses));
  };

  // Utility functions for temporary selections
  const areAllTempZonesSelected = (floorId) => {
    let floor = null;

    for (const campus of location.data) {
      for (const building of campus.buildings) {
        const f = building.floors.find((f) => f.id === floorId);
        if (f) {
          floor = f;
          break;
        }
      }
      if (floor) break;
    }

    if (!floor) return false;
    return floor.zones.every((zone) => tempSelectedZones.has(zone.id));
  };

  const areAllTempFloorsSelected = (buildingId) => {
    let building = null;

    for (const campus of location.data) {
      const b = campus.buildings.find((b) => b.id === buildingId);
      if (b) {
        building = b;
        break;
      }
    }

    if (!building) return false;
    return building.floors.every((floor) => tempSelectedFloors.has(floor.id));
  };

  const areAllTempBuildingsSelected = (campusId) => {
    const campus = location.data.find((c) => c.id === campusId);
    if (!campus) return false;
    return campus.buildings.every((building) =>
      tempSelectedBuildings.has(building.id)
    );
  };

  const unselectTempBuilding = (buildingId) => {
    let building = null;
    let campus = null;

    // Find building and its parent campus
    for (const c of location.data) {
      const b = c.buildings.find((b) => b.id === buildingId);
      if (b) {
        building = b;
        campus = c;
        break;
      }
    }

    if (!building) return;

    // Remove building
    tempSelectedBuildings.delete(building.id);

    // Remove child floors + zones
    building.floors.forEach((floor) => {
      tempSelectedFloors.delete(floor.id);
      floor.zones.forEach((zone) => {
        tempSelectedZones.delete(zone.id);
      });
    });

    // If no other building from campus is selected, unselect campus
    const otherBuildingsSelected = campus.buildings.some((b) =>
      tempSelectedBuildings.has(b.id)
    );
    if (!otherBuildingsSelected) {
      tempSelectedCampuses.delete(campus.id);
    }

    setTempSelectedBuildings(new Set(tempSelectedBuildings));
    setTempSelectedFloors(new Set(tempSelectedFloors));
    setTempSelectedZones(new Set(tempSelectedZones));
    setTempSelectedCampuses(new Set(tempSelectedCampuses));
  };

  const selectAllTempLocations = () => {
    const selectedCampuses = new Set();
    const selectedBuildings = new Set();
    const selectedFloors = new Set();
    const selectedZones = new Set();

    location.data.forEach((campus) => {
      selectedCampuses.add(campus.id);

      campus.buildings?.forEach((building) => {
        selectedBuildings.add(building.id);

        building.floors?.forEach((floor) => {
          selectedFloors.add(floor.id);

          floor.zones?.forEach((zone) => {
            selectedZones.add(zone.id);
          });
        });
      });
    });

    setTempSelectedCampuses(selectedCampuses);
    setTempSelectedBuildings(selectedBuildings);
    setTempSelectedFloors(selectedFloors);
    setTempSelectedZones(selectedZones);
  };

  const clearAllTempSelections = () => {
    setTempSelectedCampuses(new Set());
    setTempSelectedBuildings(new Set());
    setTempSelectedFloors(new Set());
    setTempSelectedZones(new Set());
  };

  const toggleBuildingCollapse = (buildingId) => {
    const newCollapsed = new Set(collapsedBuildings);
    if (newCollapsed.has(buildingId)) {
      newCollapsed.delete(buildingId);
    } else {
      newCollapsed.add(buildingId);
    }
    setCollapsedBuildings(newCollapsed);
  };

  // Transform selected data into API payload format
  const createLocationPayload = () => {
    const campusData = [];

    // Get all campus data from location.data
    const allCampuses = location.data || [];

    // Filter only selected campuses (using temp selections)
    allCampuses.forEach((campus) => {
      if (tempSelectedCampuses.has(campus.id)) {
        const campusPayload = {
          campus_id: campus.id,
          campus_name: campus.name,
          buildings: [],
        };

        // Process buildings for this campus
        campus.buildings?.forEach((building) => {
          if (tempSelectedBuildings.has(building.id)) {
            const buildingPayload = {
              building_id: building.id,
              building_name: building.name,
              floors: [],
            };

            // Process floors for this building
            building.floors?.forEach((floor) => {
              if (tempSelectedFloors.has(floor.id)) {
                const floorPayload = {
                  floor_id: floor.id,
                  floor_name: floor.name,
                  zones: [],
                };

                // Process zones for this floor
                floor.zones?.forEach((zone) => {
                  if (tempSelectedZones.has(zone.id)) {
                    floorPayload.zones.push({
                      zone_id: zone.id,
                      zone_name: zone.name,
                    });
                  }
                });

                buildingPayload.floors.push(floorPayload);
              }
            });

            campusPayload.buildings.push(buildingPayload);
          }
        });

        campusData.push(campusPayload);
      }
    });

    return { campusData };
  };

  const handleChangeLocationClick = () => {
    queryClient.invalidateQueries([QUERY_KEYS.CAMPUS_HIERARCHY])
    toggleModal(true);
  };

  const handleCancel = () => {
    toggleModal(false);
  };

  const handleSelect = () => {
    const userId = user?.id || user?._id;

    if (!userId) {
      toaster.error("User ID not found. Please log in again.");
      return;
    }

    // Check if any location is selected (using temp selections)
    // if (tempSelectedCampuses.size === 0) {
    //   toaster.error("Please select at least one campus.");
    //   return;
    // }

    const locationPayload = createLocationPayload();

    updateLocationMutation.mutate({
      userId: userId,
      locationData: locationPayload,
    });
  };

  const handleRetry = () => {
    refetch();
  };

  // Compute breadcrumb display for current location
  const breadcrumbDisplay = useMemo(() => {
    const selectedData = location.data || [];
    const selectedCampuses = selectedData.filter((campus) =>
      storeSelections.selectedCampuses.has(campus.id)
    );

    if (selectedCampuses.length === 0) {
      return { breadcrumbs: [{ text: "All Locations", showBadge: false, count: 0 }], tooltip: "All Locations" };
    }

    const breadcrumbs = [];
    let tooltip = "";

    // Campus level
    const firstCampus = selectedCampuses[0];
    const campusCount = selectedCampuses.length;
    breadcrumbs.push({
      text: firstCampus.name,
      showBadge: campusCount > 1,
      count: campusCount - 1,
    });
    tooltip = selectedCampuses.map(c => c.name).join(", ");

    // If only one campus selected, continue with buildings
    if (campusCount === 1) {
      const selectedBuildings = firstCampus.buildings?.filter((building) =>
        storeSelections.selectedBuildings.has(building.id)
      ) || [];

      if (selectedBuildings.length > 0) {
        const firstBuilding = selectedBuildings[0];
        const buildingCount = selectedBuildings.length;
        breadcrumbs.push({
          text: firstBuilding.name,
          showBadge: buildingCount > 1,
          count: buildingCount - 1,
        });

        // If only one building selected, continue with floors
        if (buildingCount === 1) {
          const selectedFloors = firstBuilding.floors?.filter((floor) =>
            storeSelections.selectedFloors.has(floor.id)
          ) || [];

          if (selectedFloors.length > 0) {
            const firstFloor = selectedFloors[0];
            const floorCount = selectedFloors.length;
            breadcrumbs.push({
              text: firstFloor.name,
              showBadge: floorCount > 1,
              count: floorCount - 1,
            });

            // If only one floor selected, continue with zones
            if (floorCount === 1) {
              const selectedZones = firstFloor.zones?.filter((zone) =>
                storeSelections.selectedZones.has(zone.id)
              ) || [];

              if (selectedZones.length > 0) {
                const firstZone = selectedZones[0];
                const zoneCount = selectedZones.length;
                breadcrumbs.push({
                  text: firstZone.name,
                  showBadge: zoneCount > 1,
                  count: zoneCount - 1,
                });
              }
            }
          }
        }
      }
    }

    return { breadcrumbs, tooltip };
  }, [location.data, storeSelections.selectedCampuses, storeSelections.selectedBuildings, storeSelections.selectedFloors, storeSelections.selectedZones]);

  return (
    <>
      <div className="flex items-center gap-3">
        <LocationSvg />
        <div
          title={breadcrumbDisplay.tooltip}
          className="text-xs text-[#222222] flex items-center gap-1"
        >
          {breadcrumbDisplay.breadcrumbs.map((item, index) => (
            <div key={index} className="flex items-center gap-1">
              {index > 0 && (
                <span className="text-[#AAAAAA] mx-1">{'>'}</span>
              )}
              <span className="text-[#222222]">{item.text}</span>
              {item.showBadge && (
                <span className="ml-1 inline-flex items-center px-2 rounded-full text-[10px] font-medium bg-[#227EEB] text-white">
                  +{item.count}
                </span>
              )}
            </div>
          ))}
        </div>
        {/* <button
          onClick={handleChangeLocationClick}
          className="text-[10px] text-[#227EEB] underline"
        >
          Change
        </button> */}
      </div>

      {open && (
        <CenterModal toggleModal={toggleModal} className="max-w-[600px] w-full">
          <div className="p-5 border-b border-[#CCCCCC] flex items-center justify-between">
            <h2 className="text-[#222222] font-semibold">Change Location</h2>
            <div className="flex items-center gap-[10px]">
              <SecondaryBtn
                className={"min-w-[80px] justify-center"}
                onClick={handleCancel}
              >
                CANCEL
              </SecondaryBtn>
              <PrimaryBtn2
                className={"min-w-[80px] justify-center"}
                onClick={handleSelect}
                disabled={updateLocationMutation.isLoading}
              >
                {updateLocationMutation.isLoading ? "UPDATING..." : "SELECT"}
              </PrimaryBtn2>
            </div>
          </div>

          {/* Select All / Unselect All Controls */}
          <div className="px-4 py-1 border-b border-[#EEEEEE]">
            <div className="flex items-center justify-between">
              <span></span>
              <div className="flex items-center gap-3">
                <button
                  onClick={selectAllTempLocations}
                  className="text-xs text-[#227EEB] hover:text-blue-700 underline font-medium"
                >
                  Select All
                </button>
                <span className="text-gray-300">|</span>
                <button
                  onClick={clearAllTempSelections}
                  className="text-xs text-red-600 hover:text-red-700 underline font-medium"
                >
                  Unselect All
                </button>
              </div>
            </div>
          </div>

          <div className="max-h-[75vh] overflow-auto p-4">
            {location.isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#227EEB] mx-auto mb-4"></div>
                  <p className="text-gray-600">Loading campus data...</p>
                </div>
              </div>
            ) : location.error ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-center">
                  <p className="text-red-600 mb-4">Error: {location.error}</p>
                  <button
                    onClick={handleRetry}
                    className="px-4 py-2 bg-[#227EEB] text-white rounded hover:bg-blue-700"
                  >
                    Retry
                  </button>
                </div>
              </div>
            ) : location.data?.length === 0 ? (
              <div className="flex items-center justify-center py-8">
                <p className="text-gray-600">No campus data available</p>
              </div>
            ) : (
              location.data.map((campus) => (
                <CampusItem
                  key={campus.id}
                  campus={campus}
                  tempSelections={{
                    tempSelectedCampuses,
                    tempSelectedBuildings,
                    tempSelectedFloors,
                    tempSelectedZones,
                    collapsedBuildings,
                  }}
                  tempActions={{
                    toggleTempCampusSelection,
                    toggleTempBuildingSelection,
                    toggleTempFloorSelection,
                    toggleTempZoneSelection,
                    toggleBuildingCollapse,
                    areAllTempBuildingsSelected,
                    areAllTempFloorsSelected,
                    areAllTempZonesSelected,
                    unselectTempBuilding,
                  }}
                />
              ))
            )}
          </div>
        </CenterModal>
      )}
    </>
  );
};

export default LocationChanger;
