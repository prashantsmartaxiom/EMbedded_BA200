function Seperator({ className = "h-[25px]", borderClassName="border-[#CCCCCC]" }) {
  return (
    <div className={`border border-l ${className} ${borderClassName}`}></div>
  );
}

export default Seperator;
