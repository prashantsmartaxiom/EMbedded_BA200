import { IndentSidebarSvg } from "../../assets/svg";
import LocationChanger from "./LocationChanger";
import Notifications from "./Notifications";
import Seperator from "./Seperator";
import SystemSelector from "./SystemSelector";
import UserProfile from "./UserProfile";
import LogoXL from "../../assets/images/LogoXL.png";
import useSidebarStore from "../../store/useSidebarStore";
import { MODES } from "../../router";
import HeaderWeatherView from "./HeaderWeatherView";
import { useGetFirstWeatherLocation } from "../../api/queryHooks";
import WeatherCard from "../../pages/Dashboard/WeatherCard";

const SidebarToggler = () => {
  const toggle = useSidebarStore((state) => state.toggle);

  return (
    <button onClick={toggle} className="p-2 hover:bg-gray-100 rounded">
      <IndentSidebarSvg />
    </button>
  );
};

function Header({ mode }) {
  const { data } = useGetFirstWeatherLocation();
  return (
    <header className="shadow-[0px_1px_6px_#2222221A] bg-[#FFFFFF] flex justify-between items-center px-5 py-[10px] sticky top-0 z-10">
      <div className="flex items-center">
        <SidebarToggler />
        <img
          src={LogoXL}
          alt="LogoXL"
          className="w-[100px] h-[27px] ml-2 md:ml-[38px]"
        ></img>
        <Seperator className="ml-5 mr-3 md:ml-[54px] md:mr-[15px] h-[25px]" />
        {/* {mode === MODES.CONFIGURATION ? <LocationChanger /> : null} */}
        <LocationChanger />
      </div>
      <div className="flex items-center">
        <div className="mr-[15px] flex items-center">
          <span className="mr-[5px] text-[#222222] text-xs font-medium">Weather:</span>
          <WeatherCard
            location={data?.data}
            placeName={data?.data?.placeName || "--"}
            uiType={"header-weather"}
          />
        </div>
        <div>
          <span className="mr-[5px] text-[#222222] text-xs font-medium">System:</span>
          <SystemSelector mode={mode} />
        </div>
        <Seperator className="mx-[15px] h-[25px] hidden 800:block" />
        <Notifications />
        <Seperator className="mx-[15px] h-[25px]" />
        <UserProfile />
      </div>
    </header>
  );
}

export default Header;
