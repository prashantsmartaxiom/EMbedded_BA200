function SuccessBadge({ title = "Connected" }) {
  return (
    <span className="text-[#1EC34A] text-xs font-semibold">• {title}</span>
  );
}

export function WarningBadge({ title = "Disconnected" }) {
  return (
    <span className="text-[#F29F1A] text-xs font-semibold">• {title}</span>
  );
}

export default SuccessBadge;
