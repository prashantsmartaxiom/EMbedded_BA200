function PermissionDenied({
  className = "h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow flex items-center justify-center",
  text = "You do not have permission to access this page.",
}) {
  return (
    <div className={className}>
      <p>{text}</p>
    </div>
  );
}

export default PermissionDenied;
