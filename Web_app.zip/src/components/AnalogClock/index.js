import React, { useState, useEffect, useRef, useCallback } from "react";
import PrimaryDropdown from "../Dropdowns";
import { useUpdateTimezone } from "../../api/queryHooks";
import { toast } from "react-toastify";
import { formatDatev1 } from "../../utils/helpers";

const AnalogClock = ({
  timezone,
  timezoneOptions = [],
  onTimezoneSelect,
  showDropdown = false,
}) => {
  const [time, setTime] = useState(new Date());
  const [selectedTimezone, setSelectedTimezone] = useState(timezone);
  const updateTimezoneMutation = useUpdateTimezone();
  const dropdownRef = useRef(null);

  // Callback ref to handle auto-focus when element is mounted
  const setDropdownRef = useCallback(
    (node) => {
      dropdownRef.current = node;
      if (showDropdown && node) {
        setTimeout(() => {
          dropdownRef.current.querySelector("button")?.focus();
        }, 100);
      }
    },
    [showDropdown]
  );

  useEffect(() => {
    let animationId;
    let lastSecond = -1;

    const updateClock = () => {
      const now = new Date();
      let currentTime = now;

      // Get time in the specified timezone if available
      if (selectedTimezone?.timeZoneValue) {
        try {
          currentTime = new Date(
            now.toLocaleString("en-US", {
              timeZone: selectedTimezone.timeZoneValue,
            })
          );
        } catch (error) {
          console.error("Invalid timezone:", selectedTimezone.timeZoneValue);
          currentTime = now;
        }
      }

      const currentSecond = currentTime.getSeconds();

      // Only update state when the second actually changes (performance optimization)
      if (currentSecond !== lastSecond) {
        setTime(currentTime);
        lastSecond = currentSecond;
      }

      animationId = requestAnimationFrame(updateClock);
    };

    // Start the animation loop
    updateClock();

    // Cleanup function
    return () => {
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
    };
  }, [selectedTimezone]);

  useEffect(() => {
    setSelectedTimezone(timezone);
  }, [timezone]);

  const formatTime = (time) => {
    const hours = time.getHours();
    const minutes = time.getMinutes();
    const seconds = time.getSeconds();
    const day = time
      .toLocaleDateString("en-US", { weekday: "short" })
      .toUpperCase();
    const date = time
      ? formatDatev1(time.toISOString(), ", ")?.toUpperCase()
      : "";

    return {
      day,
      date,
      hours: hours.toString().padStart(2, "0"),
      minutes: minutes.toString().padStart(2, "0"),
      seconds: seconds.toString().padStart(2, "0"),
    };
  };

  const handleTimeZoneChange = (value) => {
    const selectedOption = timezoneOptions.find(
      (option) => option.value === value
    );

    if (showDropdown) {
      // For new timezone creation
      onTimezoneSelect?.(selectedOption);
      setSelectedTimezone(selectedOption);
    } else if (selectedOption && timezone?._id) {
      // For existing timezone update
      const payload = {
        timeZoneName: selectedOption.timeZoneName,
        timeZoneValue: selectedOption.timeZoneValue,
      };

      updateTimezoneMutation.mutate(
        { id: timezone._id, timezoneData: payload },
        {
          onSuccess: () => {
            toast.success("Timezone updated successfully!");
            setSelectedTimezone(selectedOption);
          },
          onError: (error) => {
            console.error("Failed to update timezone:", error);
            toast.error("Failed to update timezone");
          },
        }
      );
    }
  };

  const { day, date, hours, minutes, seconds } = formatTime(time);

  // If we should show dropdown (new timezone selection)
  if (showDropdown) {
    return (
      <div className="flex-shrink-0 w-[280px] h-[160px] border border-[#DDDDDD] rounded-[10px] p-[10px]">
        <div className="h-[85px] w-full border border-[#C1DBF9] bg-[#F5F9FD] rounded-[10px] flex items-center justify-center">
          <div className="text-[#7A838E] text-sm font-semibold">
            Select a timezone
          </div>
        </div>
        <div className="mt-[10px]" ref={setDropdownRef}>
          <PrimaryDropdown
            placeholder={"Select Timezone"}
            className="w-full"
            value={selectedTimezone?._id || selectedTimezone?.id}
            onValueChange={handleTimeZoneChange}
            options={timezoneOptions}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="flex-shrink-0 w-[280px] h-[160px] border border-[#DDDDDD] rounded-[10px] p-[10px]">
      <div className="h-[85px] w-full border border-[#C1DBF9] bg-[#F5F9FD] rounded-[10px] flex flex-col items-center justify-center">
        <div className="text-[#7A838E] text-sm font-semibold">{date}</div>
        <div className="flex items-start justify-center mt-1 gap-3">
          <div className="flex flex-col items-center">
            <span className="text-base font-semibold text-[#222222]">
              {day}
            </span>
            <span className="text-[10px] font-semibold text-[#999999]">
              DAY
            </span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-base font-semibold text-[#222222]">:</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-base font-semibold text-[#222222]">
              {hours}
            </span>
            <span className="text-[10px] font-semibold text-[#999999]">
              HOURS
            </span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-base font-semibold text-[#222222]">:</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-base font-semibold text-[#222222]">
              {minutes}
            </span>
            <span className="text-[10px] font-semibold text-[#999999]">
              MIN
            </span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-base font-semibold text-[#222222]">:</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-base font-semibold text-[#222222]">
              {seconds}
            </span>
            <span className="text-[10px] font-semibold text-[#999999]">
              SEC
            </span>
          </div>
        </div>
      </div>
      <div className="mt-[10px]">
        <PrimaryDropdown
          placeholder={"Select Timezone"}
          className="w-full"
          value={selectedTimezone?._id || selectedTimezone?.id}
          onValueChange={handleTimeZoneChange}
          options={timezoneOptions}
        />
      </div>
    </div>
  );
};

export default AnalogClock;
