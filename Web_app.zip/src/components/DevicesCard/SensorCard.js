import * as Popover from "@radix-ui/react-popover";
import { useState } from "react";
import { DeleteSvg, EditSvg, SensorSvg } from "../../assets/svg";
import DevicePopoverContent from "../Popovers/DevicePopoverContent";
import DeleteSensorPopup from "./DeleteSensorPopup";

function SensorCard({
  sensor,
  isActive = false,
  channelState,
  channelStates,
  updateChannelState,
  submitChannelUpdate,
  isUpdating,
  main_device,
}) {
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);
  const [isDeletePopupOpen, setIsDeletePopupOpen] = useState(false);

  const handleSubmit = (channelId, data) => {
    submitChannelUpdate(channelId, data);
    setIsPopoverOpen(false);
  };

  const handleCancel = () => {
    setIsPopoverOpen(false);
  };

  const handleCardClick = () => {
    if (isActive) {
      setIsPopoverOpen(true);
    }
  };

  const handleEditClick = (e) => {
    e.stopPropagation();
    setIsPopoverOpen(true);
  };

  const handleDeleteClick = (e) => {
    e.stopPropagation();
    setIsDeletePopupOpen(true);
  };

  const toggleDeleteModal = () => {
    setIsDeletePopupOpen(!isDeletePopupOpen);
  };

  const card = (
    <div
      title={sensor?.name}
      onClick={handleCardClick}
      className={`w-[140px] h-[110px] flex-shrink-0 rounded-lg border flex flex-col justify-center gap-2 relative group ${
        isActive
          ? "bg-[#E9F3FC] border-[#BED9F9] cursor-pointer"
          : "bg-[#F5F5F5] border-[#DDDDDD]"
      } px-3`}
    >
      <SensorSvg className="w-8 h-8 self-center" />
      <div className="truncate">
        {isActive ? (
          <div
            className={`font-semibold truncate text-center text-[#222222] text-sm`}
          >
            {sensor?.name}
          </div>
        ) : (
          <div className={`h-[14px]`}></div>
        )}
        <div
          className={`truncate text-[10px] font-semibold text-[#939CA7] text-center`}
        >
          {channelState?.channelId?.match(/(Port-\d+_?\d*)/)?.[0] || sensor?.channelId?.match(/(Port-\d+_?\d*)/)?.[0]}
        </div>
      </div>
      {isActive ? null : (
        <div className="absolute left-0 top-0 w-full h-full flex justify-center items-center group-hover:opacity-100 opacity-0 transition-opacity duration-200 pointer-events-none">
          <div className="flex items-center gap-[10px] pointer-events-auto">
            <button
              onClick={handleEditClick}
              className="w-7 h-7 flex items-center justify-center rounded-md bg-[#227EEB] text-white fill-white cursor-pointer"
            >
              <EditSvg />
            </button>
            <button
              onClick={handleDeleteClick}
              className="w-7 h-7 flex items-center justify-center rounded-md bg-[#FF1212] text-white fill-white cursor-pointer hover:bg-[#E60000]"
            >
              <DeleteSvg />
            </button>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <>
      <Popover.Root open={isPopoverOpen} onOpenChange={setIsPopoverOpen}>
        <Popover.Anchor asChild>
          <div>{card}</div>
        </Popover.Anchor>
        <Popover.Content side="right" align="center" className="z-50 rounded-md">
          <DevicePopoverContent
            device={sensor}
            label="Sensor"
            type="sensor"
            channelState={channelState}
            channelStates={channelStates}
            updateChannelState={updateChannelState}
            submitChannelUpdate={handleSubmit}
            onCancel={handleCancel}
            isUpdating={isUpdating}
            main_device={main_device}
          />
          <Popover.Arrow className="fill-white" />
        </Popover.Content>
      </Popover.Root>
      
      {isDeletePopupOpen && (
        <DeleteSensorPopup
          toggleModal={toggleDeleteModal}
          sensor={sensor}
          main_device={main_device}
        />
      )}
    </>
  );
}

export default SensorCard;
