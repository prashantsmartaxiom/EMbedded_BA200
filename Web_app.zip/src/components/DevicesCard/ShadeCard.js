import * as Popover from "@radix-ui/react-popover";
import { useState } from "react";
import CurtainSvg from "../CurtainSvg";
import DevicePopoverContent from "../Popovers/DevicePopoverContent";
import { percentToNumber } from "../../utils/helpers";

function ShadeCard({
  shade,
  isActive = false,
  channelState,
  updateChannelState,
  submitChannelUpdate,
  isUpdating,
  main_device,
}) {
  //   {
  //     "type": "sensor",
  //     "name": "BAM-D00000_Port-1_2",
  //     "channelId": "BAM-D00000_Port-1_2",
  //     "status": "active",
  //     "installed": true,
  //     "properties": {
  //         "sensorType": "pir"
  //     }
  // }
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);

  const handleSubmit = (channelId, data) => {
    submitChannelUpdate(channelId, data);
    setIsPopoverOpen(false); // Close popover after submit
  };

  const handleCancel = () => {
    setIsPopoverOpen(false); // Close popover on cancel
  };

  // Get the current open level from channelState or shade properties
  const currentState = channelState || shade;
  const openLevel = currentState?.properties?.openLevel
    ? percentToNumber(currentState.properties.openLevel)
    : 0;

  const card = (
    <div
      title={shade?.name}
      className={`w-[140px] h-[110px] flex-shrink-0 rounded-lg border flex flex-col justify-center gap-2 ${
        isActive
          ? "bg-[#E9F3FC] border-[#BED9F9]"
          : "bg-[#F5F5F5] border-[#DDDDDD]"
      } cursor-pointer px-3`}
    >
      <CurtainSvg openValue={openLevel} className="w-8 h-8 self-center" />
      <div className="truncate">
        {isActive ? (
          <div
            className={`font-semibold truncate text-center text-[#222222] text-sm`}
          >
            {shade?.name}
          </div>
        ) : (
          <div className={`h-[14px]`}></div>
        )}
        <div
          className={`truncate text-[10px] font-semibold text-[#939CA7] text-center`}
        >
          {shade?.channelId}
        </div>
      </div>
    </div>
  );

  return (
    <Popover.Root open={isPopoverOpen} onOpenChange={setIsPopoverOpen}>
      <Popover.Trigger asChild>{card}</Popover.Trigger>
      <Popover.Content side="right" align="center" className="z-50 rounded-md">
        <DevicePopoverContent
          device={shade}
          label="Shade"
          type="shade"
          channelState={channelState}
          updateChannelState={updateChannelState}
          submitChannelUpdate={handleSubmit}
          onCancel={handleCancel}
          isUpdating={isUpdating}
          main_device={main_device}
        />
        <Popover.Arrow className="fill-white" />
      </Popover.Content>
    </Popover.Root>
  );
}

export default ShadeCard;
