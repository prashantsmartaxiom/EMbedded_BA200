const CurtainSvg = ({ openValue = 0, className = "w-16 h-20" }) => {
  // Clamp openValue between 0 and 100
  const clamped = Math.min(100, Math.max(0, openValue));

  // CurtainSvg full dimensions from SVG
  const curtainFullHeight = 74.681;
  const curtainY = 9.354;

  // Calculate current curtain height based on openValue
  const curtainHeight = curtainFullHeight * (1 - clamped / 100);

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      viewBox="0 0 67.766 90"
    >
      {/* Static frame parts */}
      <rect width="67.766" height="9.354" fill="#eff0f4" />
      <rect width="4.265" height="9.354" fill="#ccd0e0" opacity="0.4" />
      <rect
        width="4.265"
        height="9.354"
        transform="translate(67.766 9.354) rotate(180)"
        fill="#ccd0e0"
        opacity="0.4"
      />
      <path
        d="M67.766,25.55,0,26.2v3.289H67.766Z"
        transform="translate(0 -20.139)"
        fill="#ebeff5"
        style={{ mixBlendMode: "multiply", isolation: "isolate" }}
      />
      <path
        d="M67.766,1.277,0,1.929V0H67.766Z"
        fill="#ebeff5"
        style={{ mixBlendMode: "multiply", isolation: "isolate" }}
      />
      <path
        d="M67.766,36.981H0V35.7l67.766-.654Z"
        transform="translate(0 -27.627)"
        fill="#d3d7dd"
        style={{ mixBlendMode: "multiply", isolation: "isolate" }}
      />
      <path
        d="M79.3,50.021,20,46.067v-1.9H79.3Z"
        transform="translate(-15.765 -34.816)"
        fill="#ffebeb"
        style={{ mixBlendMode: "multiply", isolation: "isolate" }}
      />

      {/* CurtainSvg (animated by openValue) */}
      <rect
        width="59.296"
        height={curtainHeight}
        transform={`translate(4.235 ${curtainY})`}
        fill="#ffc854"
        style={{
          transition: 'height 0.3s ease-in-out',
          transformOrigin: 'top'
        }}
      />

      {/* Bottom bar */}
      <rect
        width="61.54"
        height="3.897"
        transform="translate(3.113 83.164)"
        fill="#eff0f4"
      />
      <rect
        width="59.296"
        height="0.65"
        transform="translate(4.235 82.512)"
        fill="#ffebeb"
        style={{ mixBlendMode: "multiply", isolation: "isolate" }}
      />

      {/* Side bars */}
      <rect
        width="3.177"
        height="80.684"
        transform="translate(0 9.316)"
        fill="#eff0f4"
      />
      <rect
        width="0.847"
        height="80.684"
        transform="translate(0 9.316)"
        fill="#ebeff5"
        style={{ mixBlendMode: "multiply", isolation: "isolate" }}
      />
      <rect
        width="0.847"
        height="80.684"
        transform="translate(2.329 9.316)"
        fill="#ebeff5"
        style={{ mixBlendMode: "multiply", isolation: "isolate" }}
      />
      <rect
        width="3.177"
        height="80.684"
        transform="translate(64.59 9.316)"
        fill="#eff0f4"
      />
      <rect
        width="0.847"
        height="80.684"
        transform="translate(64.59 9.316)"
        fill="#ebeff5"
        style={{ mixBlendMode: "multiply", isolation: "isolate" }}
      />
      <rect
        width="0.847"
        height="80.684"
        transform="translate(66.919 9.316)"
        fill="#ebeff5"
        style={{ mixBlendMode: "multiply", isolation: "isolate" }}
      />

      {/* Bottom bar */}
      <rect
        width="67.766"
        height="3.177"
        transform="translate(0 86.823)"
        fill="#eff0f4"
      />
      <rect
        width="3.121"
        height="3.121"
        transform="translate(64.645 86.879)"
        fill="#9096a5"
        opacity="0.1"
      />
      <rect
        width="3.121"
        height="3.121"
        transform="translate(0.028 86.851)"
        fill="#9096a5"
        opacity="0.1"
      />
    </svg>
  );
};

export default CurtainSvg;
