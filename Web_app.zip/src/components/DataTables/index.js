import SpinnerV1 from "../Loaders";

const DataTable = ({
  columns,
  data,
  totalItems,
  currentPage,
  onPageChange,
  rowsPerPage = 10,
  isLoading,
  sortBy,
  sortOrder,
  onSortChange,
}) => {
  const totalPages = Math.ceil(totalItems / rowsPerPage);

  const renderPageNumbers = () => {
    const pages = [];
    const showEllipsis = totalPages > 7;

    if (!showEllipsis) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      pages.push(1);

      if (currentPage > 3) {
        pages.push("...");
      }

      for (
        let i = Math.max(2, currentPage - 1);
        i <= Math.min(currentPage + 1, totalPages - 1);
        i++
      ) {
        pages.push(i);
      }

      if (currentPage < totalPages - 2) {
        pages.push("...");
      }

      if (totalPages > 1) {
        pages.push(totalPages);
      }
    }

    return pages.map((page, idx) =>
      page === "..." ? (
        <span key={`ellipsis-${idx}`} className="px-2 text-[#222222]">
          ...
        </span>
      ) : (
        <button
          key={page}
          className={`px-2 py-1 border rounded transition-colors ${
            page === currentPage
              ? "bg-[#027AFF] text-white border-[#027AFF]"
              : "hover:bg-gray-100"
          }`}
          onClick={() => onPageChange(page)}
        >
          {page}
        </button>
      )
    );
  };

  const handleSort = (columnKey) => {
    if (!onSortChange) return;
    
    let newSortOrder = 'asc';
    let newSortBy = columnKey;
    
    if (sortBy === columnKey) {
      if (sortOrder === 'asc') {
        newSortOrder = 'desc';
      } else if (sortOrder === 'desc') {
        // Clear sorting if already desc
        newSortBy = '';
        newSortOrder = '';
      }
    }
    
    onSortChange(newSortBy, newSortOrder);
  };

  const getSortIcon = (columnKey) => {
    if (!sortBy || sortBy !== columnKey) {
      return '⇅'; // Default sort icon (up-down arrows)
    }
    return sortOrder === 'asc' ? '↑' : '↓';
  };

  return (
    <div className="w-full">
      {isLoading ? (
        <div className="flex items-center justify-center h-[400px]">
          <SpinnerV1 />
        </div>
      ) : (
        <>
          <div className="overflow-hidden rounded-lg border">
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-[#F5F5F5] text-[#222222]">
                <tr style={{ height: '40px' }}>
                  {columns.map((col) => (
                    <th
                      key={col.key}
                      className={`px-4 py-2 text-xs font-semibold ${
                        col.sortable ? 'cursor-pointer hover:bg-gray-200 select-none transition-colors' : ''
                      } ${
                        col.sortable && sortBy && sortBy === col.key ? 'bg-gray-100' : ''
                      }`}
                      style={{ height: '40px' }}
                      onClick={() => col.sortable && handleSort(col.key)}
                      title={col.sortable ? 
                        (sortBy === col.key ? 
                          `Currently sorted by ${col.label} (${sortOrder === 'asc' ? 'ascending' : 'descending'}). Click to ${sortOrder === 'asc' ? 'sort descending' : 'remove sorting'}.` :
                          `Click to sort by ${col.label}`) : 
                        undefined}
                    >
                      <div className="flex items-center justify-between">
                        <span>{col.label}</span>
                        {col.sortable && (
                          <div className={`ml-2 flex items-center gap-1 text-gray-400`}>
                            <span>{getSortIcon(col.key)}</span>
                          </div>
                        )}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {!data || data.length === 0 ? (
                  <tr>
                    <td
                      colSpan={columns.length}
                      className="text-center py-8 text-[#222222]"
                    >
                      No data available
                    </td>
                  </tr>
                ) : (
                  data.map((row, idx) => (
                    <tr
                      key={idx}
                      className="hover:bg-[#F9F9F9] border-b last:border-b-0"
                      style={{ height: '40px' }}
                    >
                      {columns.map((col) => (
                        <td key={col.key} className="px-4 py-2 align-middle" style={{ height: '40px', verticalAlign: 'middle' }}>
                          {col.render
                            ? col.render(row[col.key], row)
                            : row[col.key]}
                        </td>
                      ))}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <div className="flex justify-between items-center mt-5 px-2 text-xs">
            <span className="text-[#222222]">
              {/* Page {currentPage} of {totalPages || 1} */}
            </span>
            <div className="flex gap-1 items-center">
              <button
                className="px-2 text-lg disabled:opacity-50 disabled:cursor-not-allowed hover:text-[#222222]"
                onClick={() => onPageChange(1)}
                disabled={currentPage === 1}
              >
                «
              </button>
              <button
                className="px-2 text-lg disabled:opacity-50 disabled:cursor-not-allowed hover:text-[#222222]"
                onClick={() => onPageChange(currentPage - 1)}
                disabled={currentPage === 1}
              >
                ‹
              </button>

              {renderPageNumbers()}

              <button
                className="px-2 text-lg disabled:opacity-50 disabled:cursor-not-allowed hover:text-[#222222]"
                onClick={() => onPageChange(currentPage + 1)}
                disabled={currentPage === totalPages || totalPages === 0}
              >
                ›
              </button>
              <button
                className="px-2 text-lg disabled:opacity-50 disabled:cursor-not-allowed hover:text-[#222222]"
                onClick={() => onPageChange(totalPages)}
                disabled={currentPage === totalPages || totalPages === 0}
              >
                »
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default DataTable;
