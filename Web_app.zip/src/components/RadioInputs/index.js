import * as RRadioGroup from "@radix-ui/react-radio-group";

const RadioGroup = ({
  name,
  options,
  defaultValue,
  onValueChange,
  optionClassName,
  ...props
}) => (
  <RRadioGroup.Root
    defaultValue={defaultValue}
    onValueChange={onValueChange}
    name={name}
    {...props}
  >
    {options.map((option) => (
      <div
        key={option.value}
        className={`flex items-center ${optionClassName}`}
      >
        <RRadioGroup.Item
          className="w-[16px] h-[16px] rounded-full border border-[#227EEB] flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-blue-500 data-[state=checked]:bg-white"
          value={option.value}
          id={`${name}-${option.value}`}
        >
          <RRadioGroup.Indicator className="w-[8px] h-[8px] rounded-full bg-[#227EEB]" />
        </RRadioGroup.Item>

        <label
          className="ml-2 text-[#222222] text-[12px]"
          htmlFor={`${name}-${option.value}`}
        >
          {option.label}
        </label>
      </div>
    ))}
  </RRadioGroup.Root>
);

export default RadioGroup;
