import { Link } from "react-router-dom";

function A({ children, className = "", ...props }) {
  return (
    <Link className={`text-[#227EEB] text-sm ${className}`} {...props}>
      {children}
    </Link>
  );
}

export default A;
