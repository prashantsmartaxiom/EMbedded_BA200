import { Link } from "react-router-dom";
import { AddSvg } from "../../assets/svg";

const PrimaryBtn = ({ type = "button", children, className, ...props }) => {
  return (
    <button
      type={type}
      className={`bg-[#227EEB] font-bold rounded-[10px] text-sm text-[#FFFFFF] p-[10px] ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

export const PrimaryBtn2 = ({
  type = "button",
  children,
  className,
  ...props
}) => {
  return (
    <button
      type={type}
      className={`bg-[#227EEB] text-[#FFFFFF] h-[36px] flex items-center gap-[5px] font-semibold rounded-[10px] text-xs p-[10px] disabled:opacity-50 ${className}`}
      {...props}
    >
      <span className="">{children}</span>
    </button>
  );
};

export const SecondaryBtnLink = ({ children, className, Icon, canAccess = true, ...props }) => {
  if (!canAccess) return null;
  return (
    <Link
      className={`h-[36px] flex items-center gap-[5px] border border-[#227EEB] text-[#227EEB] font-bold rounded-[10px] text-xs p-[10px] ${className}`}
      {...props}
    >
      {Icon ? <Icon className="fill-[#227EEB]" /> : null}
      <span className="">{children}</span>
    </Link>
  );
};

export const SecondaryBtn = ({
  children,
  className,
  textClassName = "",
  iconClassName = "",
  Icon,
  ...props
}) => {
  return (
    <button
      className={`h-[36px] flex items-center gap-[5px] border border-[#227EEB] text-[#227EEB] font-bold rounded-[10px] text-xs p-[10px] ${className}`}
      {...props}
    >
      {Icon ? <Icon className={iconClassName} /> : null}
      <span className={` ${textClassName}`}>{children}</span>
    </button>
  );
};

export const SecondaryBtn2 = ({
  children,
  className,
  iconClassName = "",
  Icon,
  ...props
}) => {
  return (
    <button
      className={`flex items-center gap-[5px] border bg-[#E6F0FC] text-[#227EEB] font-bold rounded-[10px] text-xs p-[10px] ${className}`}
      {...props}
    >
      {Icon ? <Icon className={iconClassName} /> : null}
      <span className="">{children}</span>
    </button>
  );
};

export const TabBtn = ({ children, isActive = false, ...props }) => {
  return (
    <button
      className={`h-[32px] p-[10px] border ${
        isActive
          ? "border-[#227EEB] bg-[#E8F2FD] font-semibold text-[#227EEB]"
          : "border-transparent bg-[#ffffff]"
      } rounded-lg flex items-center text-xs`}
      {...props}
    >
      {children}
    </button>
  );
};

export const LoadMoreDataBtn = ({ fetchNextPage, isFetchingNextPage }) => {
  return (
    <PrimaryBtn2 onClick={fetchNextPage} disabled={isFetchingNextPage}>
      {isFetchingNextPage ? "Loading..." : "Load More"}
    </PrimaryBtn2>
  );
};

export const AddMoreButton = ({
  children,
  className,
  iconClassName = "fill-[#227EEB] w-[12px] h-[12px]",
  Icon,
  ...props
}) => {
  return (
    <button
      className={`flex items-center gap-[5px] bg-[#E6F0FC] text-[#227EEB] font-bold rounded-[10px] text-xs p-[10px] ${className}`}
      {...props}
    >
      {Icon ? (
        <Icon className={iconClassName} />
      ) : (
        <AddSvg className={iconClassName} />
      )}
      <span className="">{children}</span>
    </button>
  );
};

export default PrimaryBtn;
