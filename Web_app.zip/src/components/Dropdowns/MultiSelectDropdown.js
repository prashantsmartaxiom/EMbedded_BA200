import * as Popover from "@radix-ui/react-popover";
import React, { useState, useEffect } from "react";
import { DownArrowSvg } from "../../assets/svg";
import Checkbox from "../Checkboxs";
// import Checkbox from "../../components";

const MultiSelectDropdown = ({
  options,
  placeholder,
  value = [],
  onValueChange,
  className,
  searchable = false,
  searchPlaceholder = "Search...",
}) => {
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredOptions, setFilteredOptions] = useState(options);

  // Filter options based on search term
  useEffect(() => {
    if (!searchTerm) {
      setFilteredOptions(options);
    } else {
      const filtered = options.filter(option =>
        option.label.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredOptions(filtered);
    }
  }, [searchTerm, options]);

  // Clear search when dropdown closes
  const handleOpenChange = (isOpen) => {
    setOpen(isOpen);
    if (!isOpen) {
      setSearchTerm("");
    }
  };

  const handleCheckboxChange = (itemValue, checked) => {
    const newSelectedValues = checked
      ? [...value, itemValue]
      : value.filter((val) => val !== itemValue);
    onValueChange(newSelectedValues);
  };

  // --- MODIFIED LOGIC START ---
  const getDisplayString = () => {
    if (value.length === 0) {
      return placeholder;
    }

    const selectedLabels = value
      .map((val) => options.find((opt) => opt.value === val)?.label)
      .filter(Boolean); // Remove any undefined labels if value doesn't match an option

    const joinedLabels = selectedLabels.join(", ");
    const maxLength = 25; // Adjust as needed for your UI

    if (joinedLabels.length > maxLength) {
      return joinedLabels.substring(0, maxLength) + "...";
    }
    return joinedLabels;
  };

  const displayValue = getDisplayString();
  // --- MODIFIED LOGIC END ---

  return (
    <Popover.Root open={open} onOpenChange={handleOpenChange}>
      <Popover.Trigger asChild>
        <button
          className={`text-[#222222] flex items-center justify-between bg-[#F6F8FF] border border-[#E7E8E8] rounded-[10px] h-[42px] p-[10px] text-xs ${className}`}
          aria-label="Select options"
        >
          <span>{displayValue}</span>
          <DownArrowSvg />
        </button>
      </Popover.Trigger>

      <Popover.Portal>
        <Popover.Content
          className="overflow-hidden bg-white rounded-md shadow-lg z-50 min-w-[var(--radix-popover-trigger-width)] max-h-[300px]"
          sideOffset={5}
          align="start"
        >
          {searchable && (
            <div className="p-2 border-b border-gray-200">
              <input
                type="text"
                placeholder={searchPlaceholder}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                onClick={(e) => e.stopPropagation()}
                onKeyDown={(e) => e.stopPropagation()}
              />
            </div>
          )}
          <div className="p-1 max-h-[240px] overflow-y-auto">
            {filteredOptions.length > 0 ? (
              filteredOptions.map((option) => (
                <div
                  key={option.value}
                  className="flex items-center h-7 pr-9 pl-6 rounded-sm text-sm leading-none text-gray-800 cursor-pointer hover:bg-blue-500 hover:text-white"
                >
                  <Checkbox
                    // className="flex h-4 w-4 appearance-none items-center justify-center rounded border border-gray-400 bg-white outline-none data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
                    checked={value.includes(option.value)}
                    onCheckedChange={(checked) =>
                      handleCheckboxChange(option.value, checked)
                    }
                    id={`checkbox-${option.value}`}
                  />
                  <label
                    htmlFor={`checkbox-${option.value}`}
                    className="ml-2 cursor-pointer"
                  >
                    {option.label}
                  </label>
                </div>
              ))
            ) : (
              <div className="px-6 py-2 text-sm text-gray-500 text-center">
                No options found
              </div>
            )}
          </div>
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
};

export default MultiSelectDropdown;
