import * as Select from "@radix-ui/react-select";
import React, { useState, useEffect } from "react";
import { DownArrowSvg, InvertSvg, MdArrowDownSvg } from "../../assets/svg";

const PrimaryDropdownOption = React.forwardRef(
  ({ children, className, ...props }, forwardedRef) => {
    return (
      <Select.Item
        className={`
        relative flex items-center min-h-7 pr-9 pl-6 py-2 rounded-sm text-xs leading-none text-gray-800 select-none cursor-pointer
        data-[highlighted]:outline-none data-[highlighted]:bg-blue-500 data-[highlighted]:text-white
        ${className || ""}
      `}
        {...props}
        ref={forwardedRef}
      >
        <Select.ItemText>{children}</Select.ItemText>
        <Select.ItemIndicator className="absolute left-0 w-6 inline-flex items-center justify-center">
          ✓
        </Select.ItemIndicator>
      </Select.Item>
    );
  }
);
PrimaryDropdownOption.displayName = "PrimaryDropdownOption";

const PrimaryDropdownOptionScene = React.forwardRef(
  ({ children, option, optionType, className, ...props }, forwardedRef) => {
    return (
      <Select.Item
        className={`
        relative flex items-center min-h-7 pr-9 pl-6 py-2 rounded-sm text-xs leading-none text-gray-800 fill-black select-none cursor-pointer
        data-[highlighted]:outline-none data-[highlighted]:bg-blue-500 data-[highlighted]:text-white data-[highlighted]:fill-white
        ${className || ""}
      `}
        {...props}
        ref={forwardedRef}
      >
        {option?.operateType === "invert" ? (
          <div className="flex items-start justify-between w-full">
            <Select.ItemText className="break-words text-wrap">
              {option.label} <span className="text-[10px] font-semibold">{optionType === "scene_no_motion" ? "(Set Off)" : "(Set On)"}</span>
            </Select.ItemText>
            <InvertSvg className="flex-shrink-0" />
          </div>
        ) : (
          <Select.ItemText>{option.label}</Select.ItemText>
        )}
        <Select.ItemIndicator className="absolute left-0 w-6 inline-flex items-center justify-center">
          ✓
        </Select.ItemIndicator>
      </Select.Item>
    );
  }
);
PrimaryDropdownOptionScene.displayName = "PrimaryDropdownOptionScene";

const PrimaryDropdown = ({
  options,
  placeholder,
  value,
  className = "",
  onValueChange,
  optionType = "",
  searchable = false,
  searchPlaceholder = "Search...",
  ...props
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredOptions, setFilteredOptions] = useState(options);
  const [isOpen, setIsOpen] = useState(false);

  // Filter options based on search term
  useEffect(() => {
    if (!searchTerm) {
      setFilteredOptions(options);
    } else {
      const filtered = options.filter((option) =>
        option.label.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredOptions(filtered);
    }
  }, [searchTerm, options]);

  // Clear search when dropdown closes
  const handleOpenChange = (open) => {
    setIsOpen(open);
    if (!open) {
      setSearchTerm("");
    }
  };

  return (
    <Select.Root
      value={value}
      onValueChange={onValueChange}
      onOpenChange={handleOpenChange}
      {...props}
    >
      <Select.Trigger
        className={`group text-[#222222] flex items-center justify-between bg-[#F6F8FF] border border-[#E7E8E8] rounded-[10px] h-[42px] p-[10px] text-xs ${className} data-[disabled]:opacity-50 data-[disabled]:cursor-not-allowed`}
        aria-label="Select option"
      >
        <div className="flex items-center justify-between w-full">
          <div className="truncate">
            <Select.Value placeholder={placeholder} className="truncate" />
          </div>
          <Select.Icon className="text-[#222222] flex-shrink-0 transition-transform duration-200 group-data-[state=open]:rotate-180">
            <DownArrowSvg />
          </Select.Icon>
        </div>
      </Select.Trigger>

      <Select.Portal>
        <Select.Content
          className="
            max-h-[300px] bg-white rounded-md shadow-lg z-50 [width:var(--radix-select-trigger-width)]
          "
          position="popper"
          sideOffset={5}
        >
          {searchable && (
            <div className="p-2 border-b border-gray-200">
              <input
                type="text"
                placeholder={searchPlaceholder}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                onClick={(e) => e.stopPropagation()}
                onKeyDown={(e) => e.stopPropagation()}
              />
            </div>
          )}
          <Select.Viewport className="p-1">
            {filteredOptions.length > 0 ? (
              filteredOptions.map((option) =>
                optionType === "scene_no_motion" || optionType === "scene_motion" ? (
                  <PrimaryDropdownOptionScene
                    key={option.value}
                    value={option.value}
                    option={option}
                    optionType={optionType}
                  >
                    {option.label}
                  </PrimaryDropdownOptionScene>
                ) : (
                  <PrimaryDropdownOption
                    key={option.value}
                    value={option.value}
                  >
                    {option.label}
                  </PrimaryDropdownOption>
                )
              )
            ) : (
              <div className="px-6 py-2 text-sm text-gray-500 text-center">
                No options found
              </div>
            )}
          </Select.Viewport>
        </Select.Content>
      </Select.Portal>
    </Select.Root>
  );
};

export const StatusDropdown = ({ options, value, onValueChange }) => {
  return (
    <Select.Root value={value} onValueChange={onValueChange}>
      <Select.Trigger className="group h-[29px] p-[10px] text-[11px] flex items-center bg-[#E8F2FD] border border-[#227EEB] rounded-lg text-[#227EEB] font-semibold">
        <Select.Value placeholder="Status" />
        <span className="h-[14px] border-l border-[#B6D5F9] mx-[9px]"></span>
        <Select.Icon className="transition-transform duration-200 group-data-[state=open]:rotate-180">
          <MdArrowDownSvg className="fill-[#227eeb]" />
        </Select.Icon>
      </Select.Trigger>

      <Select.Portal>
        <Select.Content className="bg-white rounded-md shadow-lg z-50 [width:var(--radix-select-trigger-width)]">
          <Select.Viewport className="p-1">
            {options.map((option) => (
              <PrimaryDropdownOption key={option.value} value={option.value}>
                {option.label}
              </PrimaryDropdownOption>
            ))}
          </Select.Viewport>
        </Select.Content>
      </Select.Portal>
    </Select.Root>
  );
};

export default PrimaryDropdown;
export { default as LocationDropdown } from "./LocationDropdown";
