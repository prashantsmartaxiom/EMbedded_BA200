import React, { useState, useEffect, useRef } from "react";
import * as Popover from "@radix-ui/react-popover";
import {
  FaChevronDown as ChevronDown,
  FaCheck as Check,
  FaMapMarkerAlt as MapPin,
} from "react-icons/fa";

export default function LocationDropdown({
  value,
  onValueChange,
  placeholder = "Select Location",
  className = "",
  disabled = false,
}) {
  const [searchQuery, setSearchQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [open, setOpen] = useState(false);
  const [scriptLoaded, setScriptLoaded] = useState(false);
  const [loading, setLoading] = useState(false);
  const autocompleteService = useRef(null);

  const selectedLocation = value?.placeName || value || "Select Location";
  const API_KEY = process.env.REACT_APP_GOOGLE_MAPS_API_KEY || "";

  // ✅ Safe Google Maps script loader
  useEffect(() => {
    const initAutocomplete = () => {
      if (
        window.google &&
        window.google.maps &&
        window.google.maps.places
      ) {
        autocompleteService.current =
          new window.google.maps.places.AutocompleteService();
        setScriptLoaded(true);
      } else {
        console.error("💀 Google Maps Places API not available");
      }
    };

    // Already loaded?
    if (window.google && window.google.maps && window.google.maps.places) {
      initAutocomplete();
      return;
    }

    const existingScript = document.getElementById("google-maps-api");
    if (existingScript) {
      existingScript.addEventListener("load", initAutocomplete);
      return;
    }

    // Load fresh script
    const script = document.createElement("script");
    script.id = "google-maps-api";
    script.src = `https://maps.googleapis.com/maps/api/js?key=${API_KEY}&libraries=places`;
    script.async = true;
    script.defer = true;

    script.onload = initAutocomplete;
    script.onerror = () =>
      console.error("😡 Failed to load Google Maps script — check API key or quota!");

    document.body.appendChild(script);
  }, [API_KEY]);

  // ✅ Fetch suggestions safely
  const fetchSuggestions = async (input) => {
    if (!input.trim() || input.length < 2) {
      setSuggestions([]);
      return;
    }

    if (!scriptLoaded || !autocompleteService.current) {
      console.warn("⚠️ Google Places not ready yet...");
      return;
    }

    try {
      autocompleteService.current.getPlacePredictions(
        { input },
        (predictions, status) => {
          if (
            status === window.google.maps.places.PlacesServiceStatus.OK &&
            predictions
          ) {
            setSuggestions(predictions);
          } else {
            setSuggestions([]);
          }
        }
      );
    } catch (err) {
      console.error("Autocomplete error 💥:", err);
      setSuggestions([]);
    }
  };

  // 🕐 Debounce input
  useEffect(() => {
    if (!scriptLoaded) return;
    const timer = setTimeout(() => {
      if (searchQuery.length >= 2) {
        fetchSuggestions(searchQuery);
      } else {
        setSuggestions([]);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery, scriptLoaded]);

  // 📍 Handle selection
  const handleSelectLocation = async (location, placeId = null) => {
    const locationData = {
      _id: placeId || `temp_${Date.now()}`,
      placeName: location,
      lat: null,
      long: null,
    };

    setOpen(false);
    setSearchQuery("");

    if (placeId || location) {
      setLoading(true);
      try {
        const params = new URLSearchParams({ address: location, key: API_KEY });
        const url = `https://maps.googleapis.com/maps/api/geocode/json?${params.toString()}`;
        const res = await fetch(url);

        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();

        if (data.status === "OK" && data.results?.[0]?.geometry?.location) {
          locationData.lat = data.results[0].geometry.location.lat;
          locationData.long = data.results[0].geometry.location.lng;
        }
      } catch (err) {
        console.error("Geocoding error 😩:", err);
      } finally {
        setLoading(false);
      }
    }

    if (onValueChange) onValueChange(locationData);
  };

  return (
    <Popover.Root open={open} onOpenChange={setOpen}>
      <Popover.Trigger asChild>
        <button
          disabled={disabled}
          className={`w-full flex items-center justify-between px-3 py-2 bg-white border border-gray-300 rounded-lg shadow-sm hover:border-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all text-sm ${
            disabled ? "opacity-50 cursor-not-allowed" : ""
          } ${className}`}
        >
          <span className="text-gray-900 font-medium truncate">
            {selectedLocation || placeholder}
          </span>
          <ChevronDown
            className={`w-4 h-4 text-gray-600 transition-transform flex-shrink-0 ml-2 ${
              open ? "rotate-180" : ""
            }`}
          />
        </button>
      </Popover.Trigger>

      <Popover.Portal>
        <Popover.Content
          className="w-[var(--radix-popover-trigger-width)] bg-white rounded-lg border border-gray-200 shadow-xl z-50 overflow-hidden"
          sideOffset={4}
          align="start"
        >
          <div className="p-3 border-b border-gray-200">
            <input
              type="text"
              placeholder="Search location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 text-sm"
              autoFocus
            />
          </div>

          <div className="max-h-60 overflow-y-auto">
            {/* Current selected */}
            {selectedLocation && selectedLocation !== placeholder && (
              <button
                onClick={() => handleSelectLocation(selectedLocation)}
                className="w-full flex items-center justify-between px-4 py-3 hover:bg-gray-50 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <Check className="w-4 h-4 text-blue-600" />
                  <span className="text-gray-900 font-medium text-sm truncate">
                    {selectedLocation}
                  </span>
                </div>
              </button>
            )}

            {suggestions.length > 0 && selectedLocation && (
              <div className="border-t border-gray-200 my-1" />
            )}

            {/* Suggestions */}
            {suggestions.map((s) => (
              <button
                key={s.place_id}
                onClick={() =>
                  handleSelectLocation(s.description, s.place_id)
                }
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors text-left"
              >
                <div className="w-4 h-4" />
                <div className="flex-1 min-w-0">
                  <div className="text-gray-900 font-medium truncate text-sm">
                    {s.structured_formatting?.main_text || s.description}
                  </div>
                  {s.structured_formatting?.secondary_text && (
                    <div className="text-xs text-gray-500 truncate">
                      {s.structured_formatting.secondary_text}
                    </div>
                  )}
                </div>
              </button>
            ))}

            {/* No results */}
            {searchQuery && suggestions.length === 0 && (
              <div className="px-4 py-6 text-center text-gray-500">
                <MapPin className="w-6 h-6 mx-auto mb-2 opacity-40" />
                <div className="text-sm">No locations found</div>
              </div>
            )}

            {/* Default options */}
            {!searchQuery && suggestions.length === 0 && !selectedLocation && (
              <>
                <button
                  onClick={() => handleSelectLocation("Los Angeles")}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors text-left"
                >
                  <div className="w-4 h-4" />
                  <span className="text-gray-900 text-sm">Los Angeles</span>
                </button>
                <button
                  onClick={() => handleSelectLocation("Vijay Nagar, Indore")}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors text-left"
                >
                  <div className="w-4 h-4" />
                  <span className="text-gray-900 text-sm">
                    Vijay Nagar, Indore
                  </span>
                </button>
              </>
            )}
          </div>
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
}
