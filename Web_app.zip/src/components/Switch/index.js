import * as RUSwitch from "@radix-ui/react-switch";

const Switch = ({
  id,
  checked,
  onCheckedChange,
  disabled = false,
  className = "",
  size = "default", // "small", "default", "large"
  variant = "primary", // "primary", "secondary"
  ...props
}) => {
  // Size configurations matching PrimaryBtn2 theme
  const sizeConfig = {
    small: {
      root: "w-[48px] h-[28px]",
      thumb:
        "w-[20px] h-[20px] translate-x-1 data-[state=checked]:translate-x-[24px] rounded-[6px]",
      borderRadius: "rounded-[8px]",
    },
    default: {
      root: "w-[60px] h-[36px]",
      thumb:
        "w-[28px] h-[28px] translate-x-1 data-[state=checked]:translate-x-[28px] rounded-[8px]",
      borderRadius: "rounded-[10px]",
    },
    large: {
      root: "w-[72px] h-[44px]",
      thumb:
        "w-[36px] h-[36px] translate-x-1 data-[state=checked]:translate-x-[32px] rounded-[10px]",
      borderRadius: "rounded-[12px]",
    },
  };

  // Variant configurations matching button themes
  const variantConfig = {
    primary: {
      checkedBg: "data-[state=checked]:bg-[#227EEB]",
      uncheckedBg: "bg-gray-300",
    },
    secondary: {
      checkedBg:
        "data-[state=checked]:bg-[#227EEB] data-[state=checked]:border-[#227EEB]",
      uncheckedBg: "bg-white border border-[#227EEB]",
    },
  };

  const currentSize = sizeConfig[size];
  const currentVariant = variantConfig[variant];

  return (
    <RUSwitch.Root
      className={`
        ${currentSize.root} ${currentSize.borderRadius}
        ${currentVariant.uncheckedBg} ${currentVariant.checkedBg}
        relative outline-none cursor-pointer
        disabled:opacity-50 disabled:cursor-not-allowed
        transition-colors duration-200 ease-in-out
        focus:ring-2 focus:ring-[#227EEB] focus:ring-opacity-50 focus:ring-offset-2
        ${className}
      `}
      id={id}
      checked={checked}
      onCheckedChange={onCheckedChange}
      disabled={disabled}
      {...props}
    >
      <RUSwitch.Thumb
        className={`
          block ${currentSize.thumb} bg-white
          transition-transform duration-200 ease-in-out
          will-change-transform 
          shadow-sm
        `}
      />
    </RUSwitch.Root>
  );
};

export default Switch;
