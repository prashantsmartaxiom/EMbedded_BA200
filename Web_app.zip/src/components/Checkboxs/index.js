import * as RCheckbox from "@radix-ui/react-checkbox";
import { CheckSvg, IndeterminateSvg } from "../../assets/svg";

const Checkbox = ({ id, label, indeterminate, checked, ...props }) => (
  <RCheckbox.Root
    className="flex h-4 w-4 flex-shrink-0 appearance-none items-center justify-center rounded border border-[#cccccc] focus:border-[#616161] bg-white outline-none data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500 data-[state=indeterminate]:bg-blue-500 data-[state=indeterminate]:border-blue-500 disabled:opacity-65 disabled:cursor-not-allowed"
    id={id}
    checked={indeterminate ? "indeterminate" : checked}
    {...props}
  >
    <RCheckbox.Indicator className="text-white">
      {indeterminate ? (
        <IndeterminateSvg className="w-2" />
      ) : (
        <CheckSvg className="w-2" />
      )}
    </RCheckbox.Indicator>
  </RCheckbox.Root>
);

export default Checkbox;
