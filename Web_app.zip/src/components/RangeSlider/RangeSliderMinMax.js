import { useState } from "react";
import * as Slider from "@radix-ui/react-slider";

const RangeSliderMinMax = ({
  renderValue = (value) => `${value}%`,
  min = 0,
  max = 100,
  defaultValues = [25, 75],
  tooltipPosition = "top",
  values: controlledValues,
  onValuesChange,
}) => {
  const [internalValues, setInternalValues] = useState(defaultValues);
  const [showTooltip, setShowTooltip] = useState([false, false]);

  const values = controlledValues !== undefined ? controlledValues : internalValues;

  const handleValueChange = (newValues) => {
    if (onValuesChange) {
      onValuesChange(newValues);
    } else {
      setInternalValues(newValues);
    }
  };

  const tooltipStyles = {
    top: {
      tooltip: "-top-8",
      arrow: "top-full",
      borderStyle: {
        borderLeft: "4px solid transparent",
        borderRight: "4px solid transparent",
        borderTop: "4px solid #227EEB",
      },
    },
    bottom: {
      tooltip: "-bottom-8",
      arrow: "bottom-full",
      borderStyle: {
        borderLeft: "4px solid transparent",
        borderRight: "4px solid transparent",
        borderBottom: "4px solid #227EEB",
      },
    },
  };

  const currentStyle = tooltipStyles[tooltipPosition];

  const handleTooltipShow = (index, show) => {
    setShowTooltip((prev) => {
      const newState = [...prev];
      newState[index] = show;
      return newState;
    });
  };

  return (
    <div className="w-full">
      <div className="relative">
        <Slider.Root
          className="relative flex items-center select-none touch-none w-full h-5"
          value={values}
          onValueChange={handleValueChange}
          min={min}
          max={max}
          step={1}
          minStepsBetweenThumbs={1}
        >
          <Slider.Track
            className="relative flex-grow h-[3px] rounded-full"
            style={{ backgroundColor: "#DDDDDD" }}
          >
            <Slider.Range
              className="absolute h-full rounded-full"
              style={{ backgroundColor: "#227EEB" }}
            />
          </Slider.Track>
          {values.map((value, index) => (
            <Slider.Thumb
              key={index}
              className="block w-[12px] h-[12px] rounded-full outline outline-[#ffffff] relative"
              style={{
                backgroundColor: "#227EEB",
                boxShadow: "0px 1px 4px #2222221A",
                border: "none",
              }}
              onMouseEnter={() => handleTooltipShow(index, true)}
              onMouseLeave={() => handleTooltipShow(index, false)}
              onPointerDown={() => handleTooltipShow(index, true)}
              onPointerUp={() => handleTooltipShow(index, false)}
            >
              {showTooltip[index] && (
                <div
                  className={`absolute ${currentStyle.tooltip} left-1/2 transform -translate-x-1/2 px-2 py-1 rounded text-white text-xs font-medium whitespace-nowrap pointer-events-none`}
                  style={{
                    backgroundColor: "#227EEB",
                    fontSize: "12px",
                  }}
                >
                  {renderValue(value)}
                  <div
                    className={`absolute ${currentStyle.arrow} left-1/2 transform -translate-x-1/2 w-0 h-0`}
                    style={currentStyle.borderStyle}
                  />
                </div>
              )}
            </Slider.Thumb>
          ))}
        </Slider.Root>
      </div>
    </div>
  );
};

export default RangeSliderMinMax;
