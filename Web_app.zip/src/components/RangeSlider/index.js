import { useState } from "react";
import * as Slider from "@radix-ui/react-slider";

const RangeSlider = ({
  renderValue = (value) => `${value}%`,
  min = 0,
  max = 100,
  tooltipPosition = "top",
  defaultValue = 85,
  value: controlledValue,
  onChange,
  onValueCommit, // New prop for when user finishes dragging
  disabled = false,
}) => {
  const [internalValue, setInternalValue] = useState([defaultValue]);
  const [showTooltip, setShowTooltip] = useState(false);

  const value =
    controlledValue !== undefined ? [controlledValue] : internalValue;

  const handleValueChange = (newValue) => {
    if (onChange) {
      onChange(newValue[0]);
    } else {
      setInternalValue(newValue);
    }
  };

  const handleValueCommit = (newValue) => {
    if (onValueCommit) {
      onValueCommit(newValue[0]);
    }
  };

  const tooltipStyles = {
    top: {
      tooltip: "-top-8",
      arrow: "top-full",
      borderStyle: {
        borderLeft: "4px solid transparent",
        borderRight: "4px solid transparent",
        borderTop: "4px solid #227EEB",
      },
    },
    bottom: {
      tooltip: "-bottom-8",
      arrow: "bottom-full",
      borderStyle: {
        borderLeft: "4px solid transparent",
        borderRight: "4px solid transparent",
        borderBottom: "4px solid #227EEB",
      },
    },
  };

  const currentStyle = tooltipStyles[tooltipPosition];

  return (
    <div className={`w-full ${disabled ? "opacity-50 cursor-not-allowed" : ""}`}>
      <div className="relative">
        <Slider.Root
          className="relative flex items-center select-none touch-none w-full h-5"
          value={value}
          onValueChange={handleValueChange}
          onValueCommit={handleValueCommit}
          min={min}
          max={max}
          step={1}
          disabled={disabled}
        >
          <Slider.Track
            className="relative flex-grow h-[3px] rounded-full"
            style={{ backgroundColor: "#DDDDDD" }}
          >
            <Slider.Range
              className="absolute h-full rounded-full"
              style={{ backgroundColor: "#227EEB" }}
            />
          </Slider.Track>
          <Slider.Thumb
            className="block w-[12px] h-[12px] rounded-full outline outline-[#ffffff] relative"
            style={{
              backgroundColor: "#227EEB",
              boxShadow: "0px 1px 4px #2222221A",
              border: "none",
            }}
            onMouseEnter={() => setShowTooltip(true)}
            onMouseLeave={() => setShowTooltip(false)}
            onPointerDown={() => setShowTooltip(true)}
            onPointerUp={() => setShowTooltip(false)}
          >
            {showTooltip && (
              <div
                className={`absolute ${currentStyle.tooltip} left-1/2 transform -translate-x-1/2 px-2 py-1 rounded text-white text-xs font-medium whitespace-nowrap pointer-events-none`}
                style={{
                  backgroundColor: "#227EEB",
                  fontSize: "12px",
                }}
              >
                {renderValue(value[0])}
                <div
                  className={`absolute ${currentStyle.arrow} left-1/2 transform -translate-x-1/2 w-0 h-0`}
                  style={currentStyle.borderStyle}
                />
              </div>
            )}
          </Slider.Thumb>
        </Slider.Root>
      </div>
    </div>
  );
};

export default RangeSlider;
