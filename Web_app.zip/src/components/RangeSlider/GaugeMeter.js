import { useEffect, useRef, useState } from "react";
import { DownArrowSvg } from "../../assets/svg";

const GaugeMeter = ({
  value = 30,
  unit = "%",
  items = [
    { label: "Low", color: "#78B4F2", length: 40 },
    { label: "Medium", color: "#56DB33", length: 20 },
    { label: "High", color: "#FA7E02", length: 60 },
  ],
}) => {
  const containerRef = useRef(null);
  const markerRef = useRef(null);
  const [containerWidth, setContainerWidth] = useState(0);

  const gradient = items
    .map((item, index) => {
      const start = items
        .slice(0, index)
        .reduce((acc, cur) => acc + cur.length, 0);
      const end = start + item.length;
      return `${item.color} ${start}% ${end}%`;
    })
    .join(", ");

  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        const width = containerRef.current.offsetWidth;
        setContainerWidth(width);
      }
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    if (containerRef.current) {
      const width = containerRef.current.offsetWidth;
      const position = (value / 100) * width;
      if (markerRef.current) {
        let leftPosition = position - 3;
        if (leftPosition < 3) leftPosition = 0;
        if (leftPosition >= width - 3) leftPosition = width - 6;
        markerRef.current.style.left = `calc(${leftPosition}px)`;
      }
    }
  }, [containerWidth, value]);

  return (
    <div ref={containerRef} className="relative">
      <div
        className="h-[6px] w-full rounded-[3px]"
        style={{
          background: `linear-gradient(to right, ${gradient})`,
        }}
      ></div>

      <div
        ref={markerRef}
        title={`${value}${unit}`}
        className="absolute w-fit h-fit top-0 flex flex-col items-center"
      >
        <div className="border w-[6px] h-[6px] rounded-full"></div>
        <DownArrowSvg className="rotate-180 text-[6px] mt-[1px]" />
      </div>
    </div>
  );
};

export default GaugeMeter;
