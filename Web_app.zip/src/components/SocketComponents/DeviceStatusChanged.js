import { useEffect } from "react";
import socket from "../../socket";

const DeviceStatusChanged = ({ callback }) => {
  useEffect(() => {
    if (!socket || !socket.connected) {
      return;
    }

    socket.on("deviceStatusChanged", (data) => {
      callback?.(data);
    });

    return () => {
      socket.off("deviceStatusChanged");
    };
  }, [socket, callback]);
  return null;
};

export { DeviceStatusChanged };
