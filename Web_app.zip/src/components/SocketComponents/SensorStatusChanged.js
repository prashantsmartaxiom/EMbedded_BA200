import { useEffect } from "react";
import socket from "../../socket";
import toaster from "../../utils/toaster";

const SensorStatusChanged = () => {
  useEffect(() => {
    const setupSensorListener = () => {
      socket.on("sensorStatusChanged", (data) => {
        if (data?.message) toaster.info(data?.message);
      });
    };

    const cleanupSensorListener = () => {
      socket.off("sensorStatusChanged");
    };

    if (!socket) {
      return;
    }

    // If socket is already connected, set up listeners immediately
    if (socket.connected) {
      setupSensorListener();
    }

    // Listen for socket connection events
    const onConnect = () => {
      setupSensorListener();
    };

    const onDisconnect = () => {
      cleanupSensorListener();
    };

    socket.on("connect", onConnect);
    socket.on("disconnect", onDisconnect);

    return () => {
      socket.off("connect", onConnect);
      socket.off("disconnect", onDisconnect);
      cleanupSensorListener();
    };
  }, []);
  return null;
};

export { SensorStatusChanged };
