import { useEffect, useRef } from "react";
import socket from "../../socket";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../api/queryKeys";

const LogsStatusChanged = ({ callback }) => {
  const queryClient = useQueryClient();
  const callbackRef = useRef(callback);

  // keep latest callback reference
  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);

  useEffect(() => {
    if (!socket) return;

    const handleTemplateUpdated = (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.TEMPLATES_IN_CONTROL_SYSTEM], {
        exact: false,
      });
      queryClient.invalidateQueries([QUERY_KEYS.TEMPLATE_BY_ID], {
        exact: false,
      });
    };

    const handleLogAdded = (data) => {
      callbackRef.current?.(data);
    };

    const handleWeatherDataUpdatedInGeneralListing = (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.TIMEZONE_OPTIONS], {
        exact: false,
      });
      queryClient.invalidateQueries([QUERY_KEYS.WEATHER_LOCATIONS], {
        exact: false,
      });
    };

    const handleWidgetsDataUpdated = (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.GET_CREATED_WIDGETS], {
        exact: false,
      });
    };

    const handleDeviceStatusChanged = (data) => {
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.DISCOVERY_DEVICES],
        exact: false,
      });

      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.CONFIGURED_DEVICES],
        exact: false,
      });
    };

    const setupListeners = () => {
      socket.on("allWeatherData", handleWeatherDataUpdatedInGeneralListing);
      socket.on("allWidgetData", handleWidgetsDataUpdated);
      socket.on("templateUpdate", handleTemplateUpdated);
      socket.on("logAdded", handleLogAdded);
      socket.on("deviceStatusChanged", handleDeviceStatusChanged);
    };

    const removeListeners = () => {
      socket.off("allWeatherData", handleWeatherDataUpdatedInGeneralListing);
      socket.off("allWidgetData", handleWidgetsDataUpdated);
      socket.off("templateUpdate", handleTemplateUpdated);
      socket.off("logAdded", handleLogAdded);
      socket.off("deviceStatusChanged", handleDeviceStatusChanged);
    };

    const handleConnect = () => setupListeners();
    const handleDisconnect = () => removeListeners();

    socket.on("connect", handleConnect);
    socket.on("disconnect", handleDisconnect);

    if (socket.connected) setupListeners();

    return () => {
      socket.off("connect", handleConnect);
      socket.off("disconnect", handleDisconnect);
      removeListeners();
    };
  }, [socket]);

  return null;
};

const MqttLogsStatusChanged = ({ callback }) => {
  const callbackRef = useRef(callback);

  // keep latest callback reference
  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);

  useEffect(() => {
    if (!socket) return;

    const handlemqttLogAdded = (data) => {
      callbackRef.current?.(data);
    };

    const setupListeners = () => {
      socket.on("mqttLogAdded", handlemqttLogAdded);
    };

    const removeListeners = () => {
      socket.off("mqttLogAdded", handlemqttLogAdded);
    };

    const handleConnect = () => setupListeners();
    const handleDisconnect = () => removeListeners();

    socket.on("connect", handleConnect);
    socket.on("disconnect", handleDisconnect);

    if (socket.connected) setupListeners();

    return () => {
      socket.off("connect", handleConnect);
      socket.off("disconnect", handleDisconnect);
      removeListeners();
    };
  }, [socket]);

  return null;
};

export { LogsStatusChanged, MqttLogsStatusChanged };