import { CheckSvg } from "../../assets/svg";

function LayoutPreview({ type, layout, isSelected = false, ...props }) {
  const config = layout;

  if (!config) return <div>Invalid layout</div>;

  // const rows = config.layout === "portrait" ? config.col : config.row;
  // const cols = config.layout === "portrait" ? config.row : config.col;

  const rows = config.row;
  const cols = config.col;

  return (
    <div
      className={`cursor-pointer relative aspect-square w-full border-2 ${
        isSelected ? "border-[#227EEB]" : "border-[#DDDDDD]"
      } bg-[#FAFAFA] rounded-[4px] p-[10px] flex items-center justify-center`}
      {...props}
    >
      {isSelected ? (
        <div className="text-[10px] text-white absolute top-2 right-2 rounded-full w-6 h-6 bg-[#227EEB] flex items-center justify-center">
          <CheckSvg />
        </div>
      ) : null}
      <div
        className={`grid border border-[#C0DAF9] bg-[#F5F9FD] rounded-[5px] 
              ${rows > 1 ? "divide-y divide-[#C0DAF9]" : ""} 
              ${cols > 1 ? "divide-x divide-[#C0DAF9]" : ""}`}
        style={{
          gridTemplateRows: `repeat(${rows}, 1fr)`,
          gridTemplateColumns: `repeat(${cols}, 1fr)`,
          aspectRatio: config.layout === "landscape" ? "16/9" : "9/16",
          width: config.layout === "landscape" ? "100%" : "auto",
          height: config.layout === "portrait" ? "100%" : "auto",
        }}
      >
        {Array.from({ length: rows * cols }).map((_, i) => (
          <div
            key={i}
            className="flex items-center justify-center text-[#939CA7]"
          >
            {config.layout === "portrait"
              ? `${cols}x${rows}`
              : `${rows}x${cols}`}
          </div>
        ))}
      </div>
    </div>
  );
}

export default LayoutPreview;
