import { useState } from "react";
import { EyeSlashSvg, EyeSvg } from "../../assets/svg";

function PasswordInput({
  className = "",
  containerClass = "",
  defaultEyeOpen = false,
  ...props
}) {
  const [showPassword, setShowPassword] = useState(defaultEyeOpen);

  return (
    <div className={`relative ${containerClass}`}>
      <input
        type={showPassword ? "text" : "password"}
        className={`text-[#222222] font-medium placeholder:font-normal placeholder:text-[#939CA7] rounded-[10px] block border border-[#E7E8E8] bg-[#ffffff] p-[10px] pr-10 text-xs focus:outline-[#227EEB] w-full ${className}`}
        {...props}
      />
      <button
        type="button"
        onClick={() => setShowPassword(!showPassword)}
        className="absolute right-2 top-1/2 -translate-y-1/2 text-[#939CA7] hover:text-[#222222] p-1"
      >
        {showPassword ? <EyeSvg /> : <EyeSlashSvg />}
      </button>
    </div>
  );
}

export default PasswordInput;
