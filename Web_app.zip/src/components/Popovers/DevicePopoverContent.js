import { useState, useEffect } from "react";
import Checkbox from "../Checkboxs";
import { PrimaryInput } from "../Input";
import { PrimaryBtn2, SecondaryBtn } from "../Buttons";
import RangeSlider from "../RangeSlider";
import {
  extractPortAndSensorFromSensorId,
  getAmphereMultipler,
  percentToNumber,
} from "../../utils/helpers";
import PrimaryDropdown from "../Dropdowns";
import RadioGroup from "../RadioInputs";
import {
  LEDonSvg,
  LEDSvg,
  MdArrowDownSvg,
  ShadeSSSvg,
  ShadeTTSvg,
  StopSvg,
} from "../../assets/svg";
import CurtainSvg from "../CurtainSvg";
import { useTriggerEvent } from "../../api/queryHooks";
import useUserStore from "../../store/useUserStore";
import toaster from "../../utils/toaster";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../api/queryKeys";

const ShadeControl = ({
  device,
  label,
  channelState,
  updateChannelState,
  submitChannelUpdate,
  onCancel,
  isUpdating,
  main_device,
}) => {
  const { user } = useUserStore();
  const main_device_type = main_device?.type?.toLowerCase();

  const triggerEventMutation = useTriggerEvent({
    onSuccess: (response) => {
      // Optionally handle success response
    },
    onError: (error) => {
      console.error("Event trigger failed:", error);
    },
  });

  const [localState, setLocalState] = useState({
    name: device?.name || "",
    installed: device?.installed || false,
    openLevel: percentToNumber(device?.properties?.openLevel) || 0,
    movementControl: device?.properties?.movementControl || 0,
    shadeLevel: device?.properties?.shadeLevel || undefined,
    status: device?.status || "off",
    port: device?.properties?.port,
    sensorAddress: device?.properties?.sensorAddress,
  });

  useEffect(() => {
    if (device) {
      setLocalState((prev) => ({
        ...prev,
        // name: device.name || "",
        // installed: device.installed || false,
        // openLevel: percentToNumber(device.properties?.openLevel) || 0,
        // movementControl: device.properties?.movementControl || 0,
        shadeLevel: device.properties?.shadeLevel || undefined,
        status: device.status || "off",
      }));

      return () => {
        // setLocalState((prev) => ({
        //   ...prev,
        //   name: device.name || "",
        //   installed: device.installed || false,
        //   openLevel: percentToNumber(device.properties?.openLevel) || 0,
        //   movementControl: device.properties?.movementControl || 0,
        //   shadeLevel: percentToNumber(device.properties?.shadeLevel) || 0,
        //   status: device.status || "off",
        // }));
      };
    }
  }, [device]);

  // Update local state when channelState changes
  // useEffect(() => {
  //   if (channelState) {
  //     setLocalState({
  //       name: channelState.name || device?.name || "",
  //       installed:
  //         channelState.installed !== undefined
  //           ? channelState.installed
  //           : device?.installed || false,
  //       openLevel: channelState.properties?.openLevel
  //         ? percentToNumber(channelState.properties.openLevel)
  //         : percentToNumber(device?.properties?.openLevel) || 0,
  //       movementControl: channelState.properties?.movementControl || 0,
  //       shadeLevel: channelState.properties?.shadeLevel
  //         ? percentToNumber(channelState.properties.shadeLevel)
  //         : percentToNumber(device?.properties?.shadeLevel) || 0,
  //       status: channelState.status || device?.status || "off",
  //     });
  //   }
  // }, [channelState, device]);

  const handleLocalChange = (field, value) => {
    setLocalState((prev) => ({ ...prev, [field]: value }));
  };

  const getUserData = () => ({
    userId: user?.id,
  });

  const handleShadeUp = () => {
    // For shade_lutron devices, set openLevel to 100 when going up
    // const newLevel =
    //   main_device?.type?.toLowerCase() === "shade_lutron"
    //     ? 100
    //     : Math.min(100, localState.openLevel + 10);

    const newLevel = 100;

    setLocalState((prev) => ({ ...prev, openLevel: newLevel }));

    // Update channel state immediately
    const updatedChannelData = {
      ...device,
      properties: {
        ...device.properties,
        openLevel: `${newLevel}%`,
      },
    };
    updateChannelState(device.channelId, updatedChannelData);

    const userData = getUserData();
    const payload = {
      ...userData,
      device_id: main_device?.device_id,
      deviceData: {
        properties: {
          // For shade_lutron, don't send openLevel in API
          ...(main_device?.type?.toLowerCase() !== "shade_lutron" &&
            {
              // openLevel: newLevel,
            }),
          numberOfCmds: device.properties.numberOfCmds || null,
        },
      },
      channelType: "SHADE",
      channelAddress: device?.channelId,
      command: "SHADE_UP",
    };

    triggerEventMutation.mutate(payload, {
      onError: (error) => {
        toaster.error(error?.response?.data?.message || "Failed");
      },
    });
  };

  const handleShadeDown = () => {
    // For shade_lutron devices, set openLevel to 0 when going down
    // const newLevel =
    //   main_device?.type?.toLowerCase() === "shade_lutron"
    //     ? 0
    //     : Math.max(0, localState.openLevel - 10);
    const newLevel = 0;

    setLocalState((prev) => ({ ...prev, openLevel: newLevel }));

    // Update channel state immediately
    const updatedChannelData = {
      ...device,
      properties: {
        ...device.properties,
        openLevel: `${newLevel}%`,
      },
    };
    updateChannelState(device.channelId, updatedChannelData);

    const userData = getUserData();
    const payload = {
      ...userData,
      device_id: main_device?.device_id,
      deviceData: {
        properties: {
          // For shade_lutron, don't send openLevel in API
          ...(main_device?.type?.toLowerCase() !== "shade_lutron" &&
            {
              // openLevel: newLevel,
            }),
          numberOfCmds: device.properties.numberOfCmds || null,
        },
      },
      channelType: "SHADE",
      channelAddress: device?.channelId,
      command: "SHADE_DOWN",
    };

    triggerEventMutation.mutate(payload, {
      onError: (error) => {
        toaster.error(error?.response?.data?.message || "Failed");
      },
    });
  };

  const handleShadeStop = () => {
    const userData = getUserData();
    const payload = {
      ...userData,
      device_id: main_device?.device_id,
      deviceData: {
        properties: {
          numberOfCmds: device.properties.numberOfCmds || null,
        },
      },
      channelType: "SHADE",
      channelAddress: device?.channelId,
      command: "SHADE_STOP",
    };

    triggerEventMutation.mutate(payload, {
      onError: (error) => {
        toaster.error(error?.response?.data?.message || "Failed");
      },
    });
  };

  const handleShade33 = () => {
    const newLevel = 33;

    setLocalState((prev) => ({ ...prev, openLevel: newLevel }));

    // Update channel state immediately
    const updatedChannelData = {
      ...device,
      properties: {
        ...device.properties,
        openLevel: `${newLevel}%`,
      },
    };
    updateChannelState(device.channelId, updatedChannelData);

    const userData = getUserData();
    const payload = {
      ...userData,
      device_id: main_device?.device_id,
      deviceData: {
        properties: {
          // For shade_lutron, don't send openLevel in API
          ...(main_device?.type?.toLowerCase() !== "shade_lutron" &&
            {
              // openLevel: newLevel,
            }),
          numberOfCmds: device.properties.numberOfCmds || null,
        },
      },
      channelType: "SHADE",
      channelAddress: device?.channelId,
      command: "SHADE_33",
    };

    triggerEventMutation.mutate(payload, {
      onError: (error) => {
        toaster.error(error?.response?.data?.message || "Failed");
      },
    });
  };

  const handleShade66 = () => {
    const newLevel = 66;

    setLocalState((prev) => ({ ...prev, openLevel: newLevel }));

    // Update channel state immediately
    const updatedChannelData = {
      ...device,
      properties: {
        ...device.properties,
        openLevel: `${newLevel}%`,
      },
    };
    updateChannelState(device.channelId, updatedChannelData);

    const userData = getUserData();
    const payload = {
      ...userData,
      device_id: main_device?.device_id,
      deviceData: {
        properties: {
          // For shade_lutron, don't send openLevel in API
          ...(main_device?.type?.toLowerCase() !== "shade_lutron" &&
            {
              // openLevel: newLevel,
            }),
          numberOfCmds: device.properties.numberOfCmds || null,
        },
      },
      channelType: "SHADE",
      channelAddress: device?.channelId,
      command: "SHADE_66",
    };

    triggerEventMutation.mutate(payload, {
      onError: (error) => {
        toaster.error(error?.response?.data?.message || "Failed");
      },
    });
  };

  const handleShadeLevelChange = (value) => {
    const userData = getUserData();
    const payload = {
      ...userData,
      device_id: main_device?.device_id,
      // deviceData: {
      //   properties: {
      //     shadeLevel: value,
      //     numberOfCmds: device.properties.numberOfCmds || null,
      //   },
      // },
      channelType: "SHADE",
      channelAddress: device?.channelId,
      command: value,
    };

    triggerEventMutation.mutate(payload, {
      onSuccess: (response) => {
        toaster.success("Shade level set successfully");
      },
      onError: (error) => {
        toaster.error(error?.response?.data?.message || "Failed");
      },
    });
  };

  const handleSubmit = () => {
    if (localState.installed) {
      const properties = {
        ...device.properties,
        movementControl: localState?.movementControl,
        openLevel: `${localState.openLevel}%`,
      };

      // Only include shadeLevel if main_device type is not "shade_lutron"
      if (main_device?.type?.toLowerCase() !== "shade_lutron") {
        properties.shadeLevel = localState.shadeLevel;
      }

      const channelData = {
        id: device?._id,
        name: localState.name,
        installed: localState.installed,
        type: device?.type,
        properties: properties,
        status: localState.status,
      };

      // Update the state optimistically (UI updates immediately)
      updateChannelState(device.channelId, channelData);

      // Submit the update to API and close popover
      submitChannelUpdate(device.channelId, channelData);
    } else {
      setLocalState({
        name: device?.name || "",
        installed: device?.installed || false,
        openLevel: percentToNumber(device?.properties?.openLevel) || 0,
        movementControl: device?.properties?.movementControl || 0,
        shadeLevel: device?.properties?.shadeLevel || undefined,
        status: device?.status || "off",
      });

      const properties = {
        ...device.properties,
        movementControl: device?.properties?.movementControl || 0,
        openLevel: percentToNumber(device?.properties?.openLevel) || 0,
      };

      // Only include shadeLevel if main_device type is not "shade_lutron"
      if (main_device?.type?.toLowerCase() !== "shade_lutron") {
        properties.shadeLevel = device?.properties?.shadeLevel || undefined;
      }

      const channelData = {
        id: device?._id,
        name: device?.name || "",
        installed: localState.installed,
        type: device?.type,
        properties: properties,
        status: device?.status || "off",
      };

      // Update the state optimistically (UI updates immediately)
      updateChannelState(device.channelId, channelData);

      // Submit the update to API and close popover
      submitChannelUpdate(device.channelId, channelData);
    }
  };

  const handleCancel = () => {
    // Reset to original values
    setLocalState({
      name: device?.name || "",
      installed: device?.installed || false,
      openLevel: percentToNumber(device?.properties?.openLevel) || 0,
      movementControl: device?.properties?.movementControl || 0,
      shadeLevel: device?.properties?.shadeLevel || undefined,
      status: device?.status || "off",
    });

    // Close the popover
    if (onCancel) {
      onCancel();
    }
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-4 w-[640px]">
      <label className="flex items-center gap-2 mb-3">
        <Checkbox
          // className="flex h-4 w-4 appearance-none items-center justify-center rounded border border-gray-400 bg-white outline-none data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
          checked={localState.installed}
          onCheckedChange={(checked) => handleLocalChange("installed", checked)}
        />
        <span className="font-semibold text-sm">{label} Enable</span>
      </label>

      <div className="min-h-[120px] grid grid-cols-2 gap-x-3 gap-y-4 mb-4">
        {localState.installed ? (
          <>
            <div className="flex items-center justify-between">
              <label className="min-w-[120px] block text-[12px] text-[#222222] mb-1">
                {label} Name:
              </label>
              <div className="w-[200px]">
                <PrimaryInput
                  className="w-full"
                  value={localState.name}
                  onChange={(e) => handleLocalChange("name", e.target.value)}
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="min-w-[120px] block text-[12px] text-[#222222] mb-1">
                {label} ID:
              </label>
              <div className="w-[200px]">
                <PrimaryInput
                  disabled
                  className="w-full"
                  value={device.channelId}
                />
              </div>
            </div>

            {main_device_type === "ba-200" ? (
              <>
                <div className="flex items-center justify-between">
                  <label className="min-w-[120px] block text-[12px] text-[#222222] mb-1">
                    Port:
                  </label>
                  <div className="w-[200px]">
                    <PrimaryDropdown
                      className="w-full"
                      placeholder={"Select Port"}
                      value={localState.port}
                      onValueChange={(value) => {}}
                      options={[
                        { value: "1", label: "1" },
                        { value: "2", label: "2" },
                        { value: "3", label: "3" },
                        { value: "4", label: "4" },
                      ]}
                      disabled={true}
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <label className="min-w-[120px] block text-[12px] text-[#222222] mb-1">
                    Channels Address:
                  </label>
                  <div className="w-[200px]">
                    <PrimaryDropdown
                      className="w-full"
                      placeholder={"Select Sensor Address"}
                      value={localState.sensorAddress}
                      onValueChange={(value) => {}}
                      options={Array.from({ length: 16 }, (_, i) => ({
                        value: String(i + 1),
                        label: String(i + 1),
                      }))}
                      disabled={true}
                    />
                  </div>
                </div>
              </>
            ) : null}

            {/* <div className="flex items-start justify-between">
              <label className="min-w-[120px] block text-[12px] text-[#222222] mb-1">
                Power Control:
              </label>
              <div className="w-[200px] relative">
                <div className="absolute left-0 -top-5 w-full flex items-center justify-between">
                  <span className="text-[12px] text-[#222222]">{0}</span>
                  <span className="text-[12px] text-[#222222]">{100}</span>
                </div>
                <RangeSlider
                  renderValue={(value) => `${value}`}
                  min={0}
                  max={100}
                  tooltipPosition="bottom"
                  value={localState.openLevel}
                  onChange={(value) => handleLocalChange("openLevel", value)}
                />
              </div>
            </div>

            <div></div> */}

            {/* <div className="flex items-start justify-between">
              <label className="min-w-[120px] block text-[12px] text-[#222222] mb-1">
                Movement Control:
              </label>
              <div className="w-[200px] relative">
                <div className="absolute left-0 -top-5 w-full flex items-center justify-between">
                  <span className="text-[12px] text-[#222222]">{0}</span>
                  <span className="text-[12px] text-[#222222]">{24}</span>
                </div>
                <RangeSlider
                  renderValue={(value) => `${value}`}
                  min={0}
                  max={24}
                  tooltipPosition="bottom"
                  value={localState.movementControl}
                  onChange={(value) =>
                    handleLocalChange("movementControl", value)
                  }
                />
              </div>
            </div>

            <div></div> */}

            {main_device?.type?.toLowerCase() !== "shade_lutron" && (
              <>
                <div className="flex items-center justify-between">
                  <label className="min-w-[120px] block text-[12px] text-[#222222] mb-1">
                    Shade Level:
                  </label>
                  <div className="w-[200px]">
                    <PrimaryDropdown
                      className="w-full"
                      value={
                        localState?.shadeLevel === "SHADE_UPPER_LIMIT" ||
                        localState?.shadeLevel === "SHADE_LOWER_LIMIT" ||
                        localState?.shadeLevel === "SHADE_MIDDLE_LIMIT" ||
                        localState?.shadeLevel === "SHADE_DELETE_LIMIT"
                          ? localState.shadeLevel
                          : undefined
                      }
                      onValueChange={(value) => {
                        handleLocalChange("shadeLevel", value);
                      }}
                      placeholder="Select Shade Level"
                      options={[
                        { value: "SHADE_UPPER_LIMIT", label: "Upper Limit" },
                        { value: "SHADE_LOWER_LIMIT", label: "Lower Limit" },
                        { value: "SHADE_MIDDLE_LIMIT", label: "Middle Limit" },
                        { value: "SHADE_DELETE_LIMIT", label: "Delete Limit" },
                      ]}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  {/* <div></div> */}
                  <div className="w-[70px]">
                    <SecondaryBtn
                      className="w-full justify-center max-w-[120px] disabled:opacity-50"
                      disabled={
                        localState?.shadeLevel === "SHADE_UPPER_LIMIT" ||
                        localState?.shadeLevel === "SHADE_LOWER_LIMIT" ||
                        localState?.shadeLevel === "SHADE_MIDDLE_LIMIT" ||
                        localState?.shadeLevel === "SHADE_DELETE_LIMIT"
                          ? false
                          : true
                      }
                      onClick={() =>
                        handleShadeLevelChange(localState.shadeLevel)
                      }
                    >
                      SET
                    </SecondaryBtn>
                  </div>
                </div>
              </>
            )}
          </>
        ) : null}
      </div>

      <div className="flex justify-between gap-2 border-t pt-3">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <CurtainSvg
              openValue={localState.openLevel}
              className="h-[20px] w-[20px]"
            />
            <span className="text-[10px] text-[#222222] truncate">
              {main_device?.type?.toLowerCase() === "shade_lutron"
                ? `${device?.properties?.numberOfCmds || 3}/4 commands`
                : ``}
            </span>
          </div>
          <div
            className="bg-[#F5F9FD] border border-[#CCCCCC] rounded-lg grid text-[#222222]"
            style={{
              gridTemplateColumns:
                device?.properties?.numberOfCmds === 4
                  ? "repeat(4, 1fr)"
                  : "repeat(3, 1fr)",
            }}
          >
            <button
              className={`flex items-center justify-center px-1 py-[2px] w-[40px] h-[36px] hover:bg-gray-100 ${
                main_device?.type?.toLowerCase() === "shade_lutron"
                  ? "cursor-pointer"
                  : localState.openLevel >= 100
                  ? "opacity-50 cursor-not-allowed"
                  : "cursor-pointer"
              }`}
              onClick={() =>
                main_device?.type?.toLowerCase() === "shade_lutron"
                  ? handleShadeUp()
                  : localState.openLevel < 100 && handleShadeUp()
              }
              disabled={
                main_device?.type?.toLowerCase() === "shade_lutron"
                  ? false
                  : localState.openLevel >= 100
              }
            >
              <MdArrowDownSvg className="rotate-180 w-[14px] h-[14px]" />
            </button>

            {device?.properties?.numberOfCmds === 4 ? (
              <>
                <button
                  className="border-l border-[#CCCCCC] flex items-center justify-center px-1 py-[2px] w-[40px] h-[36px] hover:bg-gray-100 cursor-pointer text-[8px]"
                  onClick={handleShade66}
                >
                  <ShadeSSSvg className="w-[14px] h-[14px]" />
                </button>
                <button
                  className="border-l border-[#CCCCCC] flex items-center justify-center px-1 py-[2px] w-[40px] h-[36px] hover:bg-gray-100 cursor-pointer text-[8px]"
                  onClick={handleShade33}
                >
                  <ShadeTTSvg className="w-[14px] h-[14px]" />
                </button>
              </>
            ) : (
              <button
                className="border-l border-r border-[#CCCCCC] flex items-center justify-center px-1 py-[2px] w-[40px] h-[36px] hover:bg-gray-100 cursor-pointer"
                onClick={handleShadeStop}
              >
                <StopSvg className="w-[20px] h-[20px]" />
              </button>
            )}

            <button
              className={`${
                device?.properties?.numberOfCmds === 4
                  ? "border-l border-[#CCCCCC]"
                  : ""
              } flex items-center justify-center px-1 py-[2px] w-[40px] h-[36px] hover:bg-gray-100 ${
                main_device?.type?.toLowerCase() === "shade_lutron"
                  ? "cursor-pointer"
                  : localState.openLevel <= 0
                  ? "opacity-50 cursor-not-allowed"
                  : "cursor-pointer"
              }`}
              onClick={() =>
                main_device?.type?.toLowerCase() === "shade_lutron"
                  ? handleShadeDown()
                  : localState.openLevel > 0 && handleShadeDown()
              }
              disabled={
                main_device?.type?.toLowerCase() === "shade_lutron"
                  ? false
                  : localState.openLevel <= 0
              }
            >
              <MdArrowDownSvg className="w-[14px] h-[14px]" />
            </button>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <SecondaryBtn onClick={handleCancel} disabled={isUpdating}>
            CANCEL
          </SecondaryBtn>
          <PrimaryBtn2 onClick={handleSubmit} disabled={isUpdating}>
            {isUpdating ? "UPDATING..." : "SUBMIT"}
          </PrimaryBtn2>
        </div>
      </div>
    </div>
  );
};

const LEDControl = ({
  device,
  label,
  channelState,
  updateChannelState,
  submitChannelUpdate,
  main_device,
  onCancel,
  isUpdating,
}) => {
  const { user } = useUserStore();
  const main_device_type = main_device?.type?.toLowerCase();

  const triggerEventMutation = useTriggerEvent({
    onSuccess: (response) => {
      // Optionally handle success response
    },
    onError: (error) => {
      console.error("Event trigger failed:", error);
    },
  });

  const [localState, setLocalState] = useState({
    name: device?.name || "",
    installed: device?.installed || false,
    powerMin: parseInt(device?.properties?.powerMin) || 0,
    powerMax:
      parseFloat(device?.properties?.powerMax) > 200
        ? 2.0
        : parseFloat(device?.properties?.powerMax) /
          getAmphereMultipler(main_device_type, false),
    // powerMin: 0,
    // powerMax: 100,
    brightness: parseInt(device?.properties?.brightness) || 0,
    status: device?.status || "off",
  });

  const [validationErrors, setValidationErrors] = useState({
    powerMin: "",
    powerMax: "",
  });

  useEffect(() => {
    if (device) {
      setLocalState((prev) => ({
        ...prev,
        // name: device.name || "",
        // installed: device.installed || false,
        // powerMin: parseInt(device.properties?.powerMin) || 0,
        // powerMax: parseInt(device.properties?.powerMax) || 100,
        brightness: parseInt(device.properties?.brightness) || 0,
        status: device.status || "off",
      }));

      return () => {
        // setLocalState((prev) => ({
        //   ...prev,
        //   name: device.name || "",
        //   installed: device.installed || false,
        //   powerMin: parseInt(device.properties?.powerMin) || 0,
        //   powerMax: parseInt(device.properties?.powerMax) || 100,
        //   brightness: parseInt(device.properties?.brightness) || 0,
        //   status: device.status || "off",
        // }));
      };
    }
  }, [device]);

  // Update local state when channelState changes
  // useEffect(() => {
  //   if (channelState) {
  //     setLocalState({
  //       name: channelState.name || device?.name || "",
  //       installed:
  //         channelState.installed !== undefined
  //           ? channelState.installed
  //           : device?.installed || false,
  //       powerMin: channelState.properties?.powerMin
  //         ? parseInt(channelState.properties.powerMin)
  //         : parseInt(device?.properties?.powerMin) || 10,
  //       powerMax: channelState.properties?.powerMax
  //         ? parseInt(channelState.properties.powerMax)
  //         : parseInt(device?.properties?.powerMax) || 100,
  //       brightness: channelState.properties?.brightness
  //         ? parseInt(channelState.properties.brightness)
  //         : parseInt(device?.properties?.brightness) || 0,
  //       status: channelState.status || device?.status || "off",
  //     });
  //   }
  // }, [channelState, device]);

  const handleLocalChange = (field, value) => {
    setLocalState((prev) => ({ ...prev, [field]: value }));
    // Clear validation error when user starts typing
    if (field === "powerMin" || field === "powerMax") {
      setValidationErrors((prev) => ({ ...prev, [field]: "" }));
    }
  };

  const validatePowerValues = (
    currentPowerMin = localState.powerMin,
    currentPowerMax = localState.powerMax
  ) => {
    const errors = { powerMin: "", powerMax: "" };
    let isValid = true;

    // Validate powerMax
    const powerMax = parseFloat(currentPowerMax);

    if (isNaN(powerMax) || powerMax < 0.1 || powerMax > 2.0) {
      errors.powerMax = "Power Max must be between 0.1 and 2.0";
      isValid = false;
    }

    setValidationErrors(errors);
    return isValid;
  };

  const getUserData = () => ({
    userId: user?.id,
  });

  const handlePowerMinChange = (value) => {
    setLocalState((prev) => ({ ...prev, powerMin: parseInt(value || 0) }));
    // Clear validation error when user starts typing
    // setValidationErrors((prev) => ({ ...prev, powerMin: "" }));
    validatePowerValues(parseInt(value || 0), localState.powerMax);
  };

  const handlePowerMaxChange = (value) => {
    setLocalState((prev) => ({ ...prev, powerMax: value }));
    // Clear validation error when user starts typing
    // setValidationErrors((prev) => ({ ...prev, powerMax: "" }));
    validatePowerValues(localState.powerMin, parseFloat(value || 0));
  };

  const handleLEDToggle = () => {
    if (localState.powerMax < 0.1 || localState.powerMax > 2.0) {
      toaster.error("Power Max must be between 0.1 and 2.0");
      return;
    }
    const newStatus = localState.status === "on" ? "off" : "on";

    setLocalState((prev) => ({ ...prev, status: newStatus }));

    // Update channel state immediately
    const updatedChannelData = {
      ...device,
      status: newStatus,
    };
    updateChannelState(device.channelId, updatedChannelData);

    const userData = getUserData();
    const payload = {
      ...userData,
      device_id: main_device?.device_id,
      deviceData:
        newStatus === "on"
          ? {
              properties: {
                // brightness: localState.brightness,
                brightness: 100,
                powerMin: localState.powerMin,
                powerMax:
                  Math.min(parseFloat(localState.powerMax), 2.0) *
                  getAmphereMultipler(main_device_type, false),
              },
            }
          : {},
      channelType: "LED",
      channelAddress: device?.channelId,
      command: newStatus === "on" ? "LED_ON" : "LED_OFF",
    };

    triggerEventMutation.mutate(payload);
  };

  const handleBrightnessCommit = (brightness) => {
    // Update channel state immediately
    const updatedChannelData = {
      ...device,
      properties: {
        ...device.properties,
        brightness: brightness.toString(),
      },
    };
    updateChannelState(device.channelId, updatedChannelData);

    const userData = getUserData();
    const payload = {
      ...userData,
      device_id: main_device?.device_id,
      deviceData: {
        properties: {
          brightness: brightness,
          powerMin: localState.powerMin,
          powerMax: localState.powerMax,
        },
      },
      channelType: "LED",
      channelAddress: device?.channelId,
      command: "LED_BRIGHTNESS",
    };

    triggerEventMutation.mutate(payload);
  };

  const handleSubmit = () => {
    // Validate power values before submitting
    if (!validatePowerValues()) {
      return; // Stop submission if validation fails
    }

    if (localState.installed) {
      const channelData = {
        id: device?._id,
        name: localState.name,
        installed: localState.installed,
        type: device?.type,
        properties: {
          ...device.properties,
          powerMin: parseInt(localState.powerMin).toString(),
          // powerMax: parseFloat(localState.powerMax).toString(),
          powerMax:
            parseFloat(localState.powerMax) *
            getAmphereMultipler(main_device_type, false),
          brightness: "100",
        },
        status: localState.status,
      };

      // Update the state optimistically (UI updates immediately)
      updateChannelState(device.channelId, channelData);

      // Submit the update to API and close popover
      submitChannelUpdate(device.channelId, channelData);
    } else {
      setLocalState({
        name: device?.name || "",
        installed: device?.installed || false,
        powerMin: parseInt(device?.properties?.powerMin) || 10,
        powerMax: parseFloat(device?.properties?.powerMax) || 0.1,
        // powerMin: 0,
        // powerMax: 100,
        brightness: parseInt(device?.properties?.brightness) || 0,
        status: device?.status || "off",
      });
      const channelData = {
        id: device?._id,
        name: device?.name,
        installed: localState.installed,
        type: device?.type,
        properties: {
          ...device.properties,
          powerMin: parseInt(device?.properties?.powerMin) || 10,
          powerMax:
            parseFloat(device?.properties?.powerMax)?.toString() || "0.1",
          // powerMin: 0,
          // powerMax: 100,
          brightness: parseInt(device?.properties?.brightness) || 0,
        },
        status: device?.status || "off",
      };

      // Update the state optimistically (UI updates immediately)
      updateChannelState(device.channelId, channelData);

      // Submit the update to API and close popover
      submitChannelUpdate(device.channelId, channelData);
    }
  };

  const handleCancel = () => {
    // Reset to original values
    setLocalState({
      name: device?.name || "",
      installed: device?.installed || false,
      powerMin: parseInt(device?.properties?.powerMin) || 10,
      powerMax: parseFloat(device?.properties?.powerMax) || 0.1,
      // powerMin: 0,
      // powerMax: 100,
      brightness: parseInt(device?.properties?.brightness) || 0,
      status: device?.status || "off",
    });

    // Clear validation errors
    setValidationErrors({
      powerMin: "",
      powerMax: "",
    });

    // Close the popover
    if (onCancel) {
      onCancel();
    }
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-4 w-[580px]">
      <label className="flex items-center gap-2 mb-3">
        <Checkbox
          // className="flex h-4 w-4 appearance-none items-center justify-center rounded border border-gray-400 bg-white outline-none data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
          checked={localState.installed}
          onCheckedChange={(checked) => {
            if (checked) {
              handleLocalChange("brightness", 100);
              handleLocalChange("powerMin", 10);
              handleLocalChange("powerMax", 50);
            }
            handleLocalChange("installed", checked);
          }}
        />
        <span className="font-semibold text-sm">{label} Enable</span>
      </label>
      <div className="min-h-[120px] mb-5 grid grid-cols-2 gap-4">
        {localState.installed ? (
          <>
            <div className="flex items-center justify-between">
              <label className="min-w-[95px] block text-[12px] text-[#222222] mb-1">
                {label} Name:
              </label>
              <div className="w-[200px]">
                <PrimaryInput
                  className="w-full"
                  value={localState.name}
                  onChange={(e) => handleLocalChange("name", e.target.value)}
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="min-w-[95px] block text-[12px] text-[#222222] mb-1">
                {label} ID:
              </label>
              <div className="w-[200px]">
                <PrimaryInput
                  className="w-full"
                  value={device.channelId}
                  disabled
                />
              </div>
            </div>

            <div className="flex items-start justify-between">
              <label className="min-w-[95px] mt-3 block text-[12px] text-[#222222] mb-1">
                Power Max: <br />{" "}
                <span className="text-[#7A838E] text-[11px]">(0.1 to 2.0)</span>
              </label>
              <div className="w-[200px] relative">
                <PrimaryInput
                  type="number"
                  step="0.1"
                  min="0.1"
                  max="2.0"
                  className={`w-full pr-5 appearance-none [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none [moz-appearance:textfield] ${
                    validationErrors.powerMax ? "border-red-500" : ""
                  }`}
                  value={localState.powerMax?.toString()}
                  onChange={(e) => handlePowerMaxChange(e.target.value)}
                />
                {validationErrors.powerMax && (
                  <p className="text-red-500 text-[11px] mt-1">
                    {validationErrors.powerMax}
                  </p>
                )}
                <div className="absolute top-0 right-0 h-[42px] px-2 flex items-center justify-center border-l">
                  <p className="text-xs">A</p>
                </div>
              </div>
            </div>

            <div className="flex items-start justify-between">
              <label className="min-w-[95px] mt-3 block text-[12px] text-[#222222] mb-1">
                Ref. Output Value:{" "}
                <b>
                  {(
                    (localState.powerMax * 100) /
                    getAmphereMultipler(main_device_type)
                  ).toFixed(3)}{" "}
                  A
                </b>
                {/* <span className="text-[#7A838E] text-[11px]">
                  (0.1 to 2.0)
                </span> */}
              </label>
              {/* <div className="w-[200px]"> */}
              {/* <PrimaryInput
                  type="number"
                  className={`w-full ${
                  validationErrors.powerMax ? "border-red-500" : ""
                  }`}
                  value={(localState.powerMax * getAmphereMultipler(main_device_type)).toString()}
                  disabled
                /> */}
              {/* </div> */}
            </div>

            {/* <div className="flex items-start justify-between hidden">
              <label className="min-w-[95px] block text-[12px] text-[#222222] mb-1">
                Brightness:
              </label>
              <div className="w-[200px] relative">
                <div className="absolute left-0 -top-5 w-full flex items-center justify-between">
                  <span className="text-[12px] text-[#222222]">0</span>
                  <span className="text-[12px] text-[#222222]">100</span>
                </div>
                <RangeSlider
                  renderValue={(value) => `${value}`}
                  min={0}
                  max={100}
                  tooltipPosition="bottom"
                  value={localState.brightness}
                  onChange={(value) => handleLocalChange("brightness", value)}
                  onValueCommit={(value) => handleBrightnessCommit(value)}
                />
                <div className="absolute w-full top-0 left-[200px] flex items-center justify-between">
                  <span className="text-[12px] text-[#222222] font-medium">
                    ({localState.brightness})
                  </span>
                </div>
              </div>
            </div> */}
          </>
        ) : null}
      </div>

      <div className="flex justify-between gap-2 border-t pt-3">
        <button
          className="flex items-center border border-[#DDDDDD] px-3 rounded-lg gap-3"
          onClick={handleLEDToggle}
        >
          <span>
            {localState.status === "on" ? (
              <LEDonSvg className="h-[20px] w-[20px]" />
            ) : (
              <LEDSvg className="h-[20px] w-[20px]" />
            )}
          </span>
          <span className="text-[12px] text-[#222222]">
            {localState.status === "on" ? "ON" : "OFF"}
          </span>
        </button>
        <div className="flex items-center gap-2">
          <SecondaryBtn onClick={handleCancel} disabled={isUpdating}>
            CANCEL
          </SecondaryBtn>
          <PrimaryBtn2 onClick={handleSubmit} disabled={isUpdating}>
            {isUpdating ? "UPDATING..." : "SUBMIT"}
          </PrimaryBtn2>
        </div>
      </div>
    </div>
  );
};

const SensorControl = ({
  device,
  label,
  channelState,
  channelStates,
  updateChannelState,
  submitChannelUpdate,
  onCancel,
  isUpdating,
  main_device,
}) => {
  const queryClient = useQueryClient();
  const [localState, setLocalState] = useState({
    name: device?.name || "",
    installed: device?.installed || false,
    sensorType: device?.properties?.sensorType || "pir",
    port:
      device?.properties?.port ||
      device?.channelId?.match(/-(\d+)_/)?.[1] ||
      "",
    sensorAddress:
      device?.properties?.sensorAddress ||
      device?.channelId?.match(/_(\d+)/)?.[1] ||
      "",
    channelId: device?.channelId?.match(/(Port-\d+_?\d*)/)?.[0] || "",
    commType: device?.properties?.commType || "serial",
  });

  useEffect(() => {
    if (device) {
      setLocalState((prev) => ({
        ...prev,
        // name: device.name || "",
        // installed: device.installed || false,
        // sensorType: device.properties?.sensorType || "pir",
        // port:
        //   device?.properties?.port ||
        //   device?.channelId?.match(/-(\d+)_/)?.[1] ||
        //   "",
        // sensorAddress:
        //   device?.properties?.sensorAddress ||
        //   device?.channelId?.match(/_(\d+)/)?.[1] ||
        //   "",
        // channelId: device?.channelId?.match(/(Port-\d+_?\d*)/)?.[0] || "",
        // commType: device.properties?.commType || "serial",
      }));

      return () => {
        // setLocalState((prev) => ({
        //   ...prev,
        //   name: device.name || "",
        //   installed: device.installed || false,
        //   sensorType: device.properties?.sensorType || "pir",
        //   port:
        //     device?.properties?.port ||
        //     device?.channelId?.match(/-(\d+)_/)?.[1] ||
        //     "",
        //   sensorAddress:
        //     device?.properties?.sensorAddress ||
        //     device?.channelId?.match(/_(\d+)/)?.[1] ||
        //     "",
        //   channelId: device?.channelId?.match(/(Port-\d+_?\d*)/)?.[0] || "",
        //   commType: device.properties?.commType || "serial",
        // }));
      };
    }
  }, [device]);

  // Update local state when channelState changes
  // useEffect(() => {
  //   if (channelState) {
  //     setLocalState({
  //       name: channelState.name || device?.name || "",
  //       installed:
  //         channelState.installed !== undefined
  //           ? channelState.installed
  //           : device?.installed || false,
  //       sensorType:
  //         channelState.properties?.sensorType ||
  //         device?.properties?.sensorType ||
  //         "pir",
  //       primaryPort: channelState.properties?.primaryPort || device?.properties?.primaryPort || "",
  //       secondaryPort: channelState.properties?.secondaryPort || device?.properties?.secondaryPort || "",
  //       sensorAddress:
  //         channelState.properties?.sensorAddress ||
  //         device?.properties?.sensorAddress ||
  //         "",
  //       commType:
  //         channelState.properties?.commType ||
  //         device?.properties?.commType ||
  //         "serial",
  //     });
  //   }
  // }, [channelState, device]);

  const handleLocalChange = (field, value) => {
    setLocalState((prev) => {
      const newState = { ...prev, [field]: value };

      // if (field === "port") {
      //   newState.sensorAddress = "";
      // }

      // Auto-generate channelId when port and sensorAddress are selected
      if (field === "port" || field === "sensorAddress") {
        const port = field === "port" ? value : prev.port;
        const sensorAddress =
          field === "sensorAddress" ? value : prev.sensorAddress;

        if (port && sensorAddress) {
          newState.channelId = `Port-${port}_${sensorAddress}`;
        } else {
          newState.channelId = device?.channelId || "";
        }
      }

      return newState;
    });
  };

  const handleSubmit = () => {
    let canUpdate = true;
    if (
      !(
        channelState?.properties?.port === localState?.port &&
        channelState?.properties?.sensorAddress === localState?.sensorAddress
      )
    ) {
      for (let key of Object.keys(channelStates)) {
        const channel = channelStates[key];
        const data = extractPortAndSensorFromSensorId(key);
        if (
          channel?.properties?.port &&
          channel?.properties?.sensorAddress &&
          channel.properties.port === localState.port &&
          channel.properties.sensorAddress === localState.sensorAddress
        )
          canUpdate = false;
        else if (
          data?.port &&
          data?.sensorAddress &&
          data.port === localState.port &&
          data.sensorAddress === localState.sensorAddress
        )
          canUpdate = false;
      }
    }

    if (canUpdate === false) {
      toaster.error("Another sensor with same port and address exists");
      return;
    }
    if (localState.installed) {
      const channelData = {
        id: device?._id,
        name: localState.name,
        channelId: localState.channelId,
        installed: localState.installed,
        type: device?.type,
        properties: {
          ...device.properties,
          sensorType: localState.sensorType,
          port: localState.port,
          sensorAddress: localState.sensorAddress,
          commType: localState.commType,
        },
        status: device.status,
      };

      // Update the state optimistically (UI updates immediately)
      updateChannelState(device.channelId, channelData);

      // Submit the update to API and close popover
      submitChannelUpdate(device.channelId, channelData);
    } else {
      setLocalState({
        name: device?.name || "",
        installed: localState.installed,
        sensorType: device?.properties?.sensorType || "pir",
        port: device?.properties?.port || "",
        sensorAddress: device?.properties?.sensorAddress || "",
        channelId: device?.channelId || "",
        commType: device?.properties?.commType || "serial",
      });
      const channelData = {
        id: device?._id,
        name: device?.name,
        channelId: localState.channelId,
        installed: localState.installed,
        type: device?.type,
        properties: {
          ...device.properties,
          sensorType: device?.properties?.sensorType,
          port: device?.properties?.port,
          sensorAddress: device?.properties?.sensorAddress,
          commType: device?.properties?.commType,
        },
        status: device.status,
      };

      // Update the state optimistically (UI updates immediately)
      updateChannelState(device.channelId, channelData);

      // Submit the update to API and close popover
      submitChannelUpdate(device.channelId, channelData);
    }
  };

  const handleCancel = () => {
    // Reset to original values
    setLocalState({
      name: device?.name || "",
      installed: device?.installed || false,
      sensorType: device?.properties?.sensorType || "pir",
      port: device?.properties?.port || "",
      sensorAddress: device?.properties?.sensorAddress || "",
      channelId: device?.channelId || "",
      commType: device?.properties?.commType || "serial",
    });

    queryClient.invalidateQueries([
      QUERY_KEYS.DEVICE_CHANNELS,
      main_device?.device_id,
    ]);

    // Close the popover
    if (onCancel) {
      onCancel();
    }
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-4 w-[356px]">
      <label className="flex items-center gap-2 mb-3">
        <Checkbox
          // className="flex h-4 w-4 appearance-none items-center justify-center rounded border border-gray-400 bg-white outline-none data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
          checked={localState.installed}
          onCheckedChange={(checked) => handleLocalChange("installed", checked)}
        />
        <span className="font-semibold text-sm">{label} Enable</span>
      </label>

      <div className="min-h-[120px]">
        {localState.installed ? (
          <>
            <div className="mb-3 flex items-center justify-between">
              <label className="block text-[12px] text-[#222222] mb-1">
                Sensor Type:
              </label>
              <div className="w-[200px]">
                <PrimaryDropdown
                  className="w-full"
                  value={localState.sensorType}
                  onValueChange={(value) =>
                    handleLocalChange("sensorType", value)
                  }
                  options={[
                    { value: "hmi_panel", label: "HMI Panel" },
                    { value: "pir", label: "PIR" },
                    { value: "co2", label: "CO2" },
                    { value: "temp", label: "Temp" },
                    { value: "light", label: "Light Sensor" },
                  ]}
                />
              </div>
            </div>

            <div className="mb-3 flex items-center justify-between">
              <label className="block text-[12px] text-[#222222] mb-1">
                Comm Type:
              </label>
              <div className="w-[200px]">
                <PrimaryDropdown
                  className="w-full"
                  placeholder={"Select Comm Type"}
                  value={localState.commType}
                  onValueChange={(value) =>
                    handleLocalChange("commType", value)
                  }
                  options={[
                    { value: "serial", label: "Serial" },
                    { value: "io", label: "I/O" },
                    { value: "wifi_ble", label: "Wifi/BLE" },
                  ]}
                />
              </div>
            </div>

            <div className="mb-3 flex items-center justify-between">
              <label className="block text-[12px] text-[#222222] mb-1">
                Sensor Name:
              </label>
              <div className="w-[200px]">
                <PrimaryInput
                  className="w-full"
                  value={localState.name}
                  onChange={(e) => handleLocalChange("name", e.target.value)}
                />
              </div>
            </div>

            <div className="mb-3 flex items-center justify-between">
              <label className="block text-[12px] text-[#222222] mb-1">
                Port:
              </label>
              <div className="w-[200px]">
                <PrimaryDropdown
                  className="w-full"
                  placeholder={"Select Port"}
                  value={localState.port}
                  onValueChange={(value) => {
                    handleLocalChange("port", value);
                    // Clear sensor address when port changes
                    handleLocalChange("sensorAddress", "");
                  }}
                  // options={
                  //   main_device?.type?.toLowerCase() === "ba-200"
                  //     ? [
                  //         { value: "1", label: "1" },
                  //         { value: "2", label: "2" },
                  //         { value: "3", label: "3" },
                  //         { value: "4", label: "4" },
                  //       ]
                  //     : [
                  //         { value: "1", label: "1" },
                  //         { value: "2", label: "2" },
                  //       ]
                  // }
                  options={[
                    { value: "1", label: "1" },
                    { value: "2", label: "2" },
                    { value: "3", label: "3" },
                    { value: "4", label: "4" },
                  ]}
                  disabled={true}
                />
              </div>
            </div>

            <div className="mb-3 flex items-center justify-between">
              <label className="block text-[12px] text-[#222222] mb-1">
                Channels Address:
              </label>
              <div className="w-[200px]">
                <PrimaryDropdown
                  className="w-full"
                  placeholder={"Select Sensor Address"}
                  value={localState.sensorAddress}
                  onValueChange={(value) =>
                    handleLocalChange("sensorAddress", value)
                  }
                  // options={
                  //   main_device?.type?.toLowerCase() === "ba-200"
                  //     ? localState.port === "1"
                  //       ? [
                  //           { value: "1", label: "1" },
                  //           { value: "2", label: "2" },
                  //           { value: "3", label: "3" },
                  //           { value: "4", label: "4" },
                  //         ]
                  //       : localState.port === "2"
                  //       ? [
                  //           { value: "5", label: "5" },
                  //           { value: "6", label: "6" },
                  //           { value: "7", label: "7" },
                  //           { value: "8", label: "8" },
                  //         ]
                  //       : localState.port === "3"
                  //       ? [
                  //           { value: "9", label: "9" },
                  //           { value: "10", label: "10" },
                  //           { value: "11", label: "11" },
                  //           { value: "12", label: "12" },
                  //         ]
                  //       : localState.port === "4"
                  //       ? [
                  //           { value: "13", label: "13" },
                  //           { value: "14", label: "14" },
                  //           { value: "15", label: "15" },
                  //           { value: "16", label: "16" },
                  //         ]
                  //       : []
                  // : Array.from({ length: 16 }, (_, i) => ({
                  //     value: String(i + 1),
                  //     label: String(i + 1),
                  //   }))
                  // }
                  options={Array.from({ length: 16 }, (_, i) => ({
                    value: String(i + 1),
                    label: String(i + 1),
                  }))}
                  disabled={true}
                />
              </div>
            </div>

            <div className="mb-3 flex items-center justify-between">
              <label className="block text-[12px] text-[#222222] mb-1">
                Sensor Id:
              </label>
              <div className="w-[200px]">
                <PrimaryInput
                  className="w-full"
                  disabled
                  placeholder="Channel ID"
                  value={localState.channelId}
                  onChange={(e) =>
                    handleLocalChange("channelId", e.target.value)
                  }
                />
              </div>
            </div>
          </>
        ) : null}
      </div>

      <div className="flex justify-end gap-2 border-t pt-3">
        <SecondaryBtn onClick={handleCancel} disabled={isUpdating}>
          CANCEL
        </SecondaryBtn>
        <PrimaryBtn2 onClick={handleSubmit} disabled={isUpdating}>
          {isUpdating ? "UPDATING..." : "SUBMIT"}
        </PrimaryBtn2>
      </div>
    </div>
  );
};

function DevicePopoverContent({
  device,
  label,
  type,
  channelState,
  channelStates,
  updateChannelState,
  submitChannelUpdate,
  onCancel,
  isUpdating,
  main_device,
}) {
  // Use the type parameter if provided, otherwise fallback to device.type
  const userPermissions = useUserStore((state) => state.permissions);
  const deviceType = type || device?.type;

  if (
    deviceType === "led" &&
    userPermissions?.DEVICE_MANAGEMENT?.manage_channels?.addModify
  )
    return (
      <LEDControl
        device={device}
        label={label}
        channelState={channelState}
        updateChannelState={updateChannelState}
        submitChannelUpdate={submitChannelUpdate}
        onCancel={onCancel}
        isUpdating={isUpdating}
        main_device={main_device}
      />
    );
  if (
    deviceType === "shade" &&
    userPermissions?.DEVICE_MANAGEMENT?.manage_channels?.addModify
  )
    return (
      <ShadeControl
        device={device}
        label={label}
        channelState={channelState}
        updateChannelState={updateChannelState}
        submitChannelUpdate={submitChannelUpdate}
        onCancel={onCancel}
        isUpdating={isUpdating}
        main_device={main_device}
      />
    );
  if (
    deviceType === "sensor" &&
    userPermissions?.DEVICE_MANAGEMENT?.manage_sensors?.addModify
  )
    return (
      <SensorControl
        device={device}
        label={label}
        channelState={channelState}
        updateChannelState={updateChannelState}
        submitChannelUpdate={submitChannelUpdate}
        onCancel={onCancel}
        isUpdating={isUpdating}
        main_device={main_device}
        channelStates={channelStates}
      />
    );
}

export default DevicePopoverContent;
