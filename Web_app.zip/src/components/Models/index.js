import ReactDOM from "react-dom";
import { CircleCrossSvg } from "../../assets/svg";

export const BottomRightModalHeader = ({ title = "", toggleModal }) => {
  return (
    <div className="p-5 flex items-center justify-between pb-5 mb-5 border-b border-[#CCCCCC]">
      <h2 className="text-[#222222] font-semibold">{title}</h2>
      <button onClick={() => toggleModal(false)}>
        <CircleCrossSvg />
      </button>
    </div>
  );
};

function BottomRightModal({ className = "", toggleModal, children }) {
  return ReactDOM.createPortal(
    <div
      className="fixed top-0 left-0 w-screen h-screen bg-black/50 flex items-end justify-end z-50"
      onClick={() => toggleModal(false)}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className={`shadow-[-1px_0px_6px_#2222221A] bg-[#FFFFFF] rounded-tl-[10px] rounded-bl-[10px] ${className}`}
      >
        {children}
      </div>
    </div>,
    document.body
  );
}

export const CenterModalHeader = ({
  title = "",
  className = "p-5 flex items-center justify-between pb-5 mb-5 border-b border-[#CCCCCC]",
  toggleModal,
}) => {
  return (
    <div className={className}>
      <h2 className="text-[#222222] font-semibold">{title}</h2>
      <button onClick={() => toggleModal(false)}>
        <CircleCrossSvg />
      </button>
    </div>
  );
};

export function CenterModal({ className = "", toggleModal, children }) {
  return ReactDOM.createPortal(
    <div
      className="fixed top-0 left-0 w-screen h-screen bg-black/50 flex items-center justify-center z-50"
      onClick={() => toggleModal(false)}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className={`shadow-[-1px_0px_6px_#2222221A] bg-[#FFFFFF] rounded-[10px] ${className}`}
      >
        {children}
      </div>
    </div>,
    document.body
  );
}

export default BottomRightModal;
