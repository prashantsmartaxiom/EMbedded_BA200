// import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { NavLink, useLocation } from "react-router-dom";
import {
  AccountManagementSvg,
  CampusSvg,
  DashboardSvg,
  DeviceSvg,
  DownArrowSvg,
  IntelligentControlsSvg,
  LogsSvg,
  ToolSvg,
  UpArrowSvg,
  UtilitiesSvg,
} from "../../assets/svg";
import { MODES, ROUTES } from "../../router";
import { useEffect, useState } from "react";
import useSidebarStore from "../../store/useSidebarStore";
import useUserStore from "../../store/useUserStore";

const SidebarNavLink = ({
  children,
  className = "",
  canAccess = true,
  Icon = DashboardSvg,
  ...props
}) => {
  if (!canAccess) return null;
  return (
    <NavLink
      className={({ isActive }) =>
        `flex items-center px-5 py-2 h-9 border-l-4 ${
          isActive
            ? "border-[#227EEB] bg-[#E6F0FC] text-[#227EEB] fill-[#227eeb] font-semibold"
            : "hover:bg-[#e6f0fc7f] border-transparent text-[#222222] fill-[#222222]"
        } ${className}`
      }
      {...props}
    >
      <span>
        <Icon className="mr-2 w-[18px] h-[18px]" />
      </span>
      <span className="text-sm mt-[2px]">{children}</span>
    </NavLink>
  );
};

const SidebarSubNavLink = ({
  children,
  className = "",
  canAccess = true,
  ...props
}) => {
  if (!canAccess) return null;
  return (
    <NavLink
      className={({ isActive }) =>
        `flex items-center px-5 py-2 h-9 border-l-2 ${
          isActive
            ? "border-[#227EEB] text-[#227EEB] font-semibold"
            : "hover:bg-[#e6f0fc7f] border-[#DDDDDD] text-[#222222]"
        } ${className}`
      }
      {...props}
    >
      <span className="text-sm mt-[2px]">{children}</span>
    </NavLink>
  );
};

const SidebarAccordion = ({
  children,
  title = "",
  groupBy = "",
  initialRoute = "",
  className = "",
  Icon = DashboardSvg,
  onClick,
  canAccess = true,
  ...props
}) => {
  const location = useLocation();
  const isActive = location.pathname.startsWith(groupBy);
  const [open, setOpen] = useState(false || isActive);
  // const navigate = useNavigate();

  const handleClick = () => {
    // if (isActive) setOpen(!open);
    // else setOpen(true);

    // if (initialRoute && !isActive) navigate(initialRoute);
    setOpen(!open);
  };

  if (!canAccess) return null;

  return (
    <div className="w-full">
      <button
        className={`w-full flex items-center justify-between px-5 py-2 h-9 border-l-4 ${
          isActive
            ? "bg-[#E6F0FC] text-[#227EEB] font-semibold"
            : "hover:bg-[#e6f0fc7f] border-transparent text-[#222222]"
        } ${className}`}
        onClick={handleClick}
        {...props}
      >
        <div className="flex items-center">
          <span>
            <Icon className="mr-2 w-[18px] h-[18px]" />
          </span>
          <span className="text-sm mt-[2px]">{title}</span>
        </div>
        <div>
          {open ? (
            <UpArrowSvg className="w-[10px] h-[10px] text-[#222222]" />
          ) : (
            <DownArrowSvg className="w-[10px] h-[10px] text-[#222222]" />
          )}
        </div>
      </button>

      <div
        className={`flex flex-col overflow-hidden ${
          open ? "ml-[30px] mt-3" : "max-h-0"
        }`}
      >
        {children}
      </div>
    </div>
  );
};

const ConfigurationSidebarLinks = () => {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="flex w-full flex-col gap-3">
      <SidebarNavLink to={ROUTES.DASHBOARD}>Dashboard</SidebarNavLink>
      <SidebarAccordion
        Icon={CampusSvg}
        title="Campus Management"
        groupBy="/campus-management"
        canAccess={userPermissions?.CAMPUS_MANAGEMENT?.access}
        // initialRoute={ROUTES.CAMPUS_MANAGEMENT}
      >
        <SidebarSubNavLink
          to={ROUTES.CAMPUS_MANAGEMENT}
          canAccess={
            userPermissions?.CAMPUS_MANAGEMENT?.campus_management?.access
          }
        >
          Campus
        </SidebarSubNavLink>
        <SidebarSubNavLink
          to={ROUTES.BUILDING_MANAGEMENT}
          canAccess={
            userPermissions?.CAMPUS_MANAGEMENT?.building_management?.access
          }
        >
          Building
        </SidebarSubNavLink>
        <SidebarSubNavLink
          to={ROUTES.FLOOR_MANAGEMENT}
          canAccess={
            userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.access
          }
        >
          Floor
        </SidebarSubNavLink>
        <SidebarSubNavLink
          to={ROUTES.ZONE_MANAGEMENT}
          canAccess={
            userPermissions?.CAMPUS_MANAGEMENT?.zone_management?.access
          }
        >
          Zone
        </SidebarSubNavLink>
      </SidebarAccordion>
      <SidebarNavLink
        to={ROUTES.DEVICE_CONTROL}
        Icon={DeviceSvg}
        canAccess={userPermissions?.DEVICE_MANAGEMENT?.access}
      >
        Device Control
      </SidebarNavLink>
      <SidebarNavLink
        to={ROUTES.BMS_CONTROL}
        Icon={DeviceSvg}
        canAccess={userPermissions?.DEVICE_MANAGEMENT?.access}
      >
        BMS Control
      </SidebarNavLink>
      <SidebarAccordion
        Icon={IntelligentControlsSvg}
        title="Intelligent Controls"
        groupBy="/intelligent-controls"
        canAccess={userPermissions?.INTELLIGENT_CONTROL?.access}
        // initialRoute={ROUTES.INTELLIGENT_CONTROLS_GROUP}
      >
        <SidebarSubNavLink
          to={ROUTES.INTELLIGENT_CONTROLS_GROUP}
          canAccess={
            userPermissions?.INTELLIGENT_CONTROL?.group_management?.access
          }
        >
          Group
        </SidebarSubNavLink>
        <SidebarSubNavLink
          to={ROUTES.INTELLIGENT_CONTROLS_SCENES}
          canAccess={
            userPermissions?.INTELLIGENT_CONTROL?.scene_management?.access
          }
        >
          Scenes
        </SidebarSubNavLink>
        <SidebarSubNavLink
          to={ROUTES.INTELLIGENT_CONTROLS_SENSORS}
          canAccess={
            userPermissions?.INTELLIGENT_CONTROL?.sensor_management?.access
          }
        >
          Sensor Scenes
        </SidebarSubNavLink>
        <SidebarSubNavLink
          to={ROUTES.INTELLIGENT_CONTROLS_TEMPLATE}
          canAccess={
            userPermissions?.INTELLIGENT_CONTROL?.template_management?.access
          }
        >
          Template
        </SidebarSubNavLink>
      </SidebarAccordion>

      <SidebarAccordion
        Icon={AccountManagementSvg}
        title="Account Management"
        groupBy="/account-management"
        canAccess={userPermissions?.USER_MANAGEMENT?.access}
        // initialRoute={ROUTES.MANAGE_USER}
      >
        <SidebarSubNavLink
          to={ROUTES.MANAGE_USER}
          canAccess={userPermissions?.USER_MANAGEMENT?.user_accounts?.access}
        >
          Manage User
        </SidebarSubNavLink>
        <SidebarSubNavLink
          to={ROUTES.MANAGE_ROLES}
          canAccess={userPermissions?.USER_MANAGEMENT?.role_management?.access}
        >
          Manage Roles
        </SidebarSubNavLink>
      </SidebarAccordion>
      <SidebarNavLink
        to={ROUTES.LOGS_MONITORING}
        Icon={LogsSvg}
        canAccess={userPermissions?.LOGS_MONITORING?.access}
      >
        Logs Monitoring
      </SidebarNavLink>

      <SidebarAccordion
        Icon={UtilitiesSvg}
        title="Utilities"
        groupBy="/utilities"
        canAccess={true}
        // initialRoute={ROUTES.MANAGE_USER}
      >
        <SidebarSubNavLink to={ROUTES.UTILITIES_GENERAL} canAccess={true}>
          General
        </SidebarSubNavLink>
        <SidebarSubNavLink to={ROUTES.UTILITIES_WIDGETS} canAccess={true}>
          Widgets
        </SidebarSubNavLink>
      </SidebarAccordion>
    </div>
  );
};

const ControlSidebarLinks = () => {
  return (
    <div className="flex w-full flex-col gap-3">
      <SidebarNavLink to={ROUTES.CONTROL_DASHBOARD}>Dashboard</SidebarNavLink>
      <SidebarNavLink to={ROUTES.CONTROL_SYSTEM} Icon={ToolSvg}>
        Control System
      </SidebarNavLink>
    </div>
  );
};

function Sidebar({ mode }) {
  const { isOpen, isMobile, close, setMobile } = useSidebarStore();

  useEffect(() => {
    const handleResize = () => {
      setMobile(window.innerWidth < 1024);
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [setMobile]);

  return (
    <>
      {/* Overlay for mobile */}
      {isMobile && isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={close}
        />
      )}
      <div
        className={`${
          isMobile
            ? "fixed top-0 left-0 h-[100vh]"
            : "relative h-[calc(100vh-70px)] mt-[15px]"
        } py-3 shadow-[0px_1px_6px_#2222221A] hide-scrollbar min-w-[245px] rounded-r-xl rounded-l-none bg-[#ffffff] flex-shrink-0 transition-transform duration-300 z-50 flex flex-col ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex-grow overflow-auto">
          {mode === MODES.CONFIGURATION ? (
            <ConfigurationSidebarLinks />
          ) : (
            <ControlSidebarLinks />
          )}
        </div>

        {/* Version Information */}
        <div className="flex justify-center items-center pt-3 mt-4 mx-4 border-t border-[#CCCCCC]">
          <span className="text-xs text-[#AAAAAA] font-semibold">
            App Ver: v2.0.8
          </span>
        </div>
      </div>
    </>
  );
}

export default Sidebar;
