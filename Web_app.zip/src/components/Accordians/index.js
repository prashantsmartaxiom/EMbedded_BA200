import { useState } from "react";
import { DownArrowSvg, UpArrowSvg } from "../../assets/svg";

function DevicesAccordian({
  title = "Own Devices",
  className = "",
  children,
  initialOpen = false,
}) {
  const [open, setOpen] = useState(initialOpen);

  const handleClick = () => {
    setOpen(!open);
  };

  return (
    <div className={className}>
      <button
        onClick={handleClick}
        className="flex items-center gap-[5px] w-full text-[#7A838E]"
      >
        <span>
          {open ? (
            <UpArrowSvg className="w-[10px] h-[10px] text-[#7A838E]" />
          ) : (
            <DownArrowSvg className="w-[10px] h-[10px] text-[#7A838E]" />
          )}
        </span>
        <span className="font-semibold">{title}</span>
        <span className="border-b-2 flex-grow"></span>
      </button>
      {open ? children : null}
    </div>
  );
}

export default DevicesAccordian;
