import {
  DeleteSvg,
  EditSvg,
  InvertSvg,
  LEDonSvg,
  LEDSvg,
  SensorSvg,
} from "../../assets/svg";
import { formatDatev1, formatTimev2 } from "../../utils/helpers";
import { PrimaryBtn2 } from "../Buttons";
import ShadeImage from "../../assets/images/Shade.png";
import { useTriggerEvent } from "../../api/queryHooks";
import useUserStore from "../../store/useUserStore";
import toaster from "../../utils/toaster";
import CurtainSvg from "../CurtainSvg";
import { useEffect, useState } from "react";

function parseChannels(data) {
  if (data.Groups && data.Groups.length > 0) {
    return data.Groups.flatMap((group) =>
      group.devices.flatMap((device) => device.channels)
    );
  } else if (data.Devices && data.Devices.length > 0) {
    return data.Devices.flatMap((device) => device.channels);
  }
  return [];
}

const ChannelItem = ({ channel }) => {
  if (channel?.channelType === "led") {
    return (
      <div className="flex flex-col justify-center items-center truncate max-w-[54px] min-w-[42px] flex-shrink-0">
        {channel?.command === "off" ? (
          <LEDSvg className="w-[30px] h-[30px]" />
        ) : (
          <LEDonSvg className="w-[30px] h-[30px]" />
        )}
        <div className="truncate w-full">
          <h2 className="text-[10px] text-[#7A838E] truncate text-center mt-2">
            {channel?.channelName || channel?.name || channel?.channelId}
          </h2>
        </div>
      </div>
    );
  }

  if (channel?.channelType === "shade") {
    return (
      <div className="flex flex-col justify-center items-center truncate max-w-[54px] min-w-[42px] flex-shrink-0">
        <CurtainSvg className="h-[30px]" openValue={channel?.openLevel} />
        <div className="truncate w-full">
          <h2 className="text-[10px] text-[#7A838E] truncate text-center mt-2">
            {channel?.channelId}
          </h2>
        </div>
      </div>
    );
  }

  if (channel?.channelType === "sensor") {
    return (
      <div className="flex flex-col justify-center items-center truncate max-w-[54px] min-w-[42px] flex-shrink-0">
        <SensorSvg className="w-[30px] h-[30px]" />
        <div className="truncate w-full">
          <h2 className="text-[10px] text-[#7A838E] truncate text-center mt-2">
            {channel?.channelId}
          </h2>
        </div>
      </div>
    );
  }

  return null;
};

const OperateButton = ({ scene, handleExecuteScene }) => {
  const [invertFlag, setInvertFlag] = useState(scene?.invert_flag);

  useEffect(() => {
    setInvertFlag(scene?.invert_flag);
  }, [scene]);

  const handleClick = (e) => {
    setInvertFlag(invertFlag);
    handleExecuteScene(e, !invertFlag);
  };

  return (
    <button
      className={
        "text-[12px] flex items-center justify-center w-[70px] h-[32px] bg-[#227EEB] rounded-lg text-[white]"
      }
      onClick={handleClick}
    >
      {invertFlag ? "Set On" : "Set Off"}
    </button>
  );
};

function SceneCard({ scene, onEdit, onDelete, onExecute }) {
  const userPermissions = useUserStore((state) => state.permissions);

  const { mutate: triggerEvent } = useTriggerEvent({
    onSuccess: () => {
      toaster.success("Scene executed successfully");
    },
    onError: (error) => {
      toaster.error(
        error?.response?.data?.message || "Failed to execute scene"
      );
    },
  });
  const { user } = useUserStore();

  const handleExecuteScene = (e, invertFlag) => {
    e.stopPropagation(); // Prevent any unwanted propagation

    const userData = {
      user_id: user?.user_id,
    };

    const payload = {
      ...userData,
      deviceData: scene.id,
      command: "SCENE_EXECUTE",
    };

    if (scene?.operateType === "invert") payload.invertFlag = invertFlag;

    triggerEvent(payload);
  };

  const channels = parseChannels(scene);

  return (
    <div className="relative mb-[40px]">
      <div className="h-[60px] py-[10px] px-5 bg-[#F2F4F8] rounded-b-[10px] absolute -bottom-[40px] pt-[20px] left-0 right-0">
        <div className="h-full flex items-center justify-between pt-[10px]">
          <div className="text-xs text-[#7A838E] flex items-center gap-[10px] h-full">
            {scene?.lastExecuted ? (
              <button
                type="button"
                className="text-[#7A838E] flex items-center gap-[10px]"
              >
                Last Executed
                {scene?.operateType === "invert"
                  ? `${scene?.invert_flag ? " (Set Off)" : " (Set On)"}`
                  : ""}
                : {formatTimev2(scene?.lastExecuted)}
              </button>
            ) : (
              <button
                type="button"
                className="text-[#7A838E] flex items-center gap-[10px]"
              >
                Last Executed: Not Executed Yet
              </button>
            )}
          </div>

          <div className="text-xs flex items-center gap-[30px] h-full">
            {userPermissions?.INTELLIGENT_CONTROL?.scene_management
              ?.addModify ? (
              <button
                onClick={() => onEdit(scene)}
                type="button"
                className="text-[#493b3b] flex items-center gap-[5px]"
              >
                <EditSvg /> Edit
              </button>
            ) : null}
            {userPermissions?.INTELLIGENT_CONTROL?.scene_management?.delete ? (
              <button
                type="button"
                className="text-[#FF1212] flex items-center gap-[5px]"
                onClick={() => onDelete(scene)}
              >
                <DeleteSvg className="fill-[#ff1212]" /> Delete
              </button>
            ) : null}
          </div>
        </div>
      </div>
      <div title={scene?.name} className="relative min-h-[166px] px-[15px] py-[10px] bg-[#ffffff] border border-[#CCCCCC] rounded-[10px] flex items-start justify-between gap-5">
        <div className="truncate">
          <div className="flex items-center">
            <h2 className="truncate text-base text-[#222222] font-semibold mb-1 mt-2">
              {scene?.name}
            </h2>
            {scene?.operateType === "invert" ? (
              <div className="ml-2 flex-shrink-0 w-[22px] h-[20px] flex items-center justify-center bg-[#939CA7] rounded-[5px]">
                <InvertSvg className="fill-white" />
              </div>
            ) : null}
          </div>
          <div className="flex flex-col gap-1 truncate">
            <p className="text-[12px] truncate">
              <span className="text-[#7A838E]">Campus: </span>
              <span className="text-[#222222]">
                {scene?.locations?.campuses?.[0]?.name}
              </span>
            </p>
            <p className="text-[12px] truncate">
              <span className="text-[#7A838E]">Building: </span>
              <span className="text-[#222222]">
                {scene?.locations?.buildings?.[0]?.name}
              </span>
            </p>
            <p className="text-[12px] truncate">
              <span className="text-[#7A838E]">Floor: </span>
              <span className="text-[#222222]">
                {scene?.locations?.floors?.[0]?.name}
              </span>
            </p>
            <p className="text-[12px] truncate">
              <span className="text-[#7A838E]">Zone: </span>
              <span className="text-[#222222]">
                {scene?.locations?.zones?.[0]?.name}
              </span>
            </p>
          </div>
        </div>
        <div className="flex-grow max-w-[340px] w-full h-full border border-[#C0DAF9] bg-[#F5F9FD] rounded-lg pt-[10px] px-[10px]">
          <div className="flex items-center justify-between pb-[10px] border-b border-[#C0DAF9] mb-[10px]">
            <h2 className="text-[12px] text-[#222222] font-medium">
              {scene?.type?.toUpperCase()}
            </h2>
            {userPermissions?.INTELLIGENT_CONTROL?.scene_management
              ?.addModify ? (
              scene?.operateType === "invert" ? (
                <OperateButton
                  scene={scene}
                  handleExecuteScene={handleExecuteScene}
                />
              ) : (
                <button
                  className={
                    "text-[12px] flex items-center justify-center w-[70px] h-[32px] bg-[#227EEB] rounded-lg text-[white]"
                  }
                  onClick={handleExecuteScene}
                >
                  Execute
                </button>
              )
            ) : null}
          </div>

          <div className="flex items-center gap-3 overflow-x-auto w-full h-scroll pb-[10px]">
            {channels?.map((channel) => (
              <ChannelItem key={channel?.channelId} channel={channel} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default SceneCard;
