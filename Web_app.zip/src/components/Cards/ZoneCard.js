import { Link } from "react-router-dom";
import {
  DeleteSvg,
  EditSvg,
  ZoneSvg,
  PreviewSvg,
  DeviceSvg,
} from "../../assets/svg";
import { formatDatev1, padStart } from "../../utils/helpers";
import { ROUTES } from "../../router";
import { useState } from "react";
import EditZoneModal from "../../pages/ZoneManagement/EditZoneModal";
import DeleteZonePopup from "../../pages/ViewZoneDetails/DeleteZonePopup";
import { StatusDropdown } from "../Dropdowns";
import { useUpdateZoneStatus } from "../../api/queryHooks";
import toaster from "../../utils/toaster";
import useUserStore from "../../store/useUserStore";

export const ZoneUpdateStatusDropdown = ({ zone }) => {
  const [status, setStatus] = useState(zone?.status === "active" ? 1 : 0);

  const { mutate: updateStatus } = useUpdateZoneStatus({
    onSuccess: () => {
      toaster.success("Zone status updated successfully");
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || "Failed to update zone status");
      setStatus(zone?.status === "active" ? 1 : 0); // Revert on error
    },
  });

  const handleStatusChange = (newStatus) => {
    setStatus(newStatus);
    updateStatus({ zoneId: zone._id, status: newStatus });
  };

  const statusOptions = [
    { value: 1, label: "Active" },
    { value: 0, label: "Inactive" },
  ];

  return (
    <StatusDropdown
      options={statusOptions}
      value={status}
      onValueChange={handleStatusChange}
    />
  );
};

function EditZoneButton({ zoneId }) {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <button
        onClick={toggleModal}
        type="button"
        className="text-[#222222] flex items-center gap-[4px]"
      >
        <EditSvg /> Edit
      </button>

      {open && <EditZoneModal toggleModal={toggleModal} zoneId={zoneId} />}
    </>
  );
}

function DeleteZoneButton({ zoneId }) {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <button
        onClick={toggleModal}
        type="button"
        className="text-[#FF1212] flex items-center gap-[4px]"
      >
        <DeleteSvg className="fill-[#ff1212]" /> Delete
      </button>

      {open && <DeleteZonePopup toggleModal={toggleModal} zoneId={zoneId} />}
    </>
  );
}

function ZoneCard({ zone }) {
  const userPermissions = useUserStore((state) => state.permissions);

  const zone_id = zone?._id;

  return (
    <div className="relative mb-[36px]">
      <div className="p-[10px] bg-[#F2F4F8] rounded-b-[9px] absolute -bottom-[36px] pt-[18px] left-0 right-0">
        <div className="h-full flex items-center justify-between pt-[9px]">
          <div className="text-[11px] text-[#7A838E] flex items-center gap-[10px] h-full">
            <button
              type="button"
              className="text-[#7A838E] flex items-center gap-[10px]"
            >
              Added on: {formatDatev1(zone?.createdAt)}
            </button>
          </div>

          <div className="text-[11px] flex items-center gap-[27px] h-full">
            <button
              type="button"
              className="text-[#222222] flex items-center gap-[4px]"
            >
              <PreviewSvg /> Preview
            </button>
            {userPermissions?.CAMPUS_MANAGEMENT?.zone_management?.addModify ? (
              <EditZoneButton zoneId={zone_id} />
            ) : null}
            {userPermissions?.CAMPUS_MANAGEMENT?.zone_management?.delete ? (
              <DeleteZoneButton zoneId={zone_id} />
            ) : null}
          </div>
        </div>
      </div>
      <Link
        to={ROUTES.GET_VIEW_ZONE_DETAILS(zone?._id)}
        className="relative p-[10px] bg-[#ffffff] border border-[#CCCCCC] rounded-[9px] flex items-center gap-[18px]"
      >
        <div className="w-[68px] h-[124px] flex items-center justify-center bg-[#E6F0FC] rounded-[8px] flex-shrink-0">
          <ZoneSvg className="fill-[#227EEB] h-[32px] w-[32px]" />
        </div>
        <div className="w-full">
          <h2 className="text-[#222222] font-semibold text-[15px]">
            {zone?.zoneName}
          </h2>
          {/* <p className="text-[#7A838E] text-[11px]">
            Campus: <span className="text-[#222222]">{zone?.}</span>
          </p> */}
          <div className="my-[13px] flex items-center gap-[10px]">
            <div className="text-[9px] bg-[#EEEEEE] p-[5px] w-fit min-w-[76px] text-center text-[#222222] rounded-md">
              {zone?.buildingName}
            </div>
            <div className="text-[9px] bg-[#EEEEEE] p-[5px] w-fit min-w-[76px] text-center text-[#222222] rounded-md">
              {zone?.floorName}
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-[13px]">
              <button
                type="button"
                className="flex items-center gap-[4px] text-[#222222] text-[11px]"
              >
                <DeviceSvg className="text-base" /> {padStart(zone?.deviceCount)}
              </button>
            </div>
            {userPermissions?.CAMPUS_MANAGEMENT?.zone_management?.addModify ? (
              <ZoneUpdateStatusDropdown zone={zone} />
            ) : null}
          </div>
        </div>
      </Link>
    </div>
  );
}

export default ZoneCard;
