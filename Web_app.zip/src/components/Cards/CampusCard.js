import { Link } from "react-router-dom";
import {
  BuildingSvg,
  CopySvg,
  DeleteSvg,
  EditSvg,
  FloorSvg,
  ImagePlaceholderSvg,
  PreviewSvg,
  ZoneSvg,
} from "../../assets/svg";
import Seperator from "../Header/Seperator";
import { ROUTES } from "../../router";
import { formatDatev1, padStart } from "../../utils/helpers";
import DeleteCampusPopup from "../../pages/ViewCampusDetails/DeleteCampusPopup";
import { useState } from "react";
import { StatusDropdown } from "../Dropdowns";
import { useUpdateCampusStatus } from "../../api/queryHooks";
import useUserStore from "../../store/useUserStore";
import toaster from "../../utils/toaster";

export const CampusUpdateStatusDropdown = ({ campus }) => {
  const [status, setStatus] = useState(campus?.status);

  const { mutate: updateStatus } = useUpdateCampusStatus({
    onSuccess: () => {
      toaster.success("Campus status updated successfully");
    },
    onError: (error) => {
      toaster.error(
        error?.response?.data?.message || "Failed to update campus status"
      );
      setStatus(campus?.status); // Revert on error
    },
  });

  const handleStatusChange = (newStatus) => {
    setStatus(newStatus);
    updateStatus({ campusId: campus._id, status: newStatus });
  };

  const statusOptions = [
    { value: 1, label: "Active" },
    { value: 0, label: "Inactive" },
  ];

  return (
    <StatusDropdown
      options={statusOptions}
      value={status}
      onValueChange={handleStatusChange}
    />
  );
};

const DeleteCampus = ({ campus_id }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <button
        type="button"
        className="text-[#FF1212] flex items-center gap-[4px]"
        onClick={toggleModal}
      >
        <DeleteSvg className="fill-[#ff1212]" />{" "}
        <span className="hidden 1080:inline">Delete</span>
      </button>
      {open ? (
        <DeleteCampusPopup toggleModal={toggleModal} campusId={campus_id} />
      ) : null}
    </>
  );
};

function CampusCard({ campus }) {
  const campus_id = campus?._id;
  const detailsRoute = ROUTES.GET_VIEW_CAMPUS_DETAILS(campus_id);
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="relative mb-[36px]">
      <div className="p-[10px] bg-[#F2F4F8] rounded-b-[9px] absolute -bottom-[36px] pt-[18px] left-0 right-0">
        <div className="h-full flex items-center justify-between pt-[9px]">
          <div className="text-[11px] text-[#7A838E] flex items-center gap-[10px] h-full">
            {/* <button
              type="button"
              className="text-[#7A838E] flex items-center gap-[10px]"
            >
              <span className="hidden xl:inline">Unique/Access ID</span>
              <span className="inline xl:hidden">UID/AID</span> <CopySvg />
            </button>
            <Seperator className="h-[18px]" /> */}
            <button
              type="button"
              className="text-[#7A838E] flex items-center gap-[10px]"
            >
              <span>
                <span className="hidden xl:inline">Added on:</span>{" "}
                {formatDatev1(campus?.createdAt)}
              </span>
            </button>
          </div>

          <div className="text-[11px] flex items-center gap-[27px] h-full">
            {userPermissions?.CAMPUS_MANAGEMENT?.campus_management?.readOnly ? (
              <Link
                to={detailsRoute}
                className="text-[#222222] flex items-center gap-[4px]"
              >
                <PreviewSvg />{" "}
                <span className="hidden 1080:inline">Preview</span>
              </Link>
            ) : null}
            {userPermissions?.CAMPUS_MANAGEMENT?.campus_management
              ?.addModify ? (
              <Link
                to={ROUTES.GET_EDIT_CAMPUS(campus_id)}
                className="text-[#222222] flex items-center gap-[4px]"
              >
                <EditSvg /> <span className="hidden 1080:inline">Edit</span>
              </Link>
            ) : null}

            {userPermissions?.CAMPUS_MANAGEMENT?.campus_management?.delete ? (
              <DeleteCampus campus_id={campus_id} />
            ) : null}
          </div>
        </div>
      </div>
      <Link
        to={detailsRoute}
        className="relative p-[10px] bg-[#ffffff] border border-[#CCCCCC] rounded-[9px] flex items-center gap-[18px]"
      >
        {campus?.imageUrl ? (
          <div className="w-[124px] h-[124px] flex items-center justify-center bg-[#EEEEEE] rounded-[8px] flex-shrink-0 overflow-hidden">
            <img
              alt={campus?.name}
              src={campus?.imageUrl}
              className="w-full h-full object-cover"
            />
          </div>
        ) : (
          <div className="w-[124px] h-[124px] flex items-center justify-center bg-[#EEEEEE] rounded-[8px] flex-shrink-0">
            <ImagePlaceholderSvg />
          </div>
        )}
        <div className="w-full">
          <h2 className="text-[#222222] font-semibold text-[15px]">
            {campus?.name}
          </h2>
          <p className="text-[#7A838E] text-[11px]">
            Location: <span className="text-[#222222]">{campus?.location}</span>
          </p>
          <div className="my-[13px]">
            <div className="text-[9px] bg-[#EEEEEE] p-[5px] w-fit min-w-[76px] text-center text-[#222222] rounded-md">
              {campus?.type}
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="items-center gap-[13px] hidden 1210:flex">
              <button
                type="button"
                className="flex items-center gap-[4px] text-[#222222] text-[11px]"
              >
                <BuildingSvg /> {padStart(campus?.buildingCount)}
              </button>
              <button
                type="button"
                className="flex items-center gap-[4px] text-[#222222] text-[11px]"
              >
                <FloorSvg /> {padStart(campus?.floorCount)}
              </button>
              <button
                type="button"
                className="flex items-center gap-[4px] text-[#222222] text-[11px]"
              >
                <ZoneSvg /> {padStart(campus?.zoneCount)}
              </button>
            </div>
            {userPermissions?.CAMPUS_MANAGEMENT?.campus_management
              ?.addModify ? (
              <CampusUpdateStatusDropdown campus={campus} />
            ) : null}
          </div>
        </div>
      </Link>
    </div>
  );
}

export default CampusCard;
