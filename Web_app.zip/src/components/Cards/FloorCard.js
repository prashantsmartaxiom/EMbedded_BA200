import { Link } from "react-router-dom";
import {
  DeleteSvg,
  EditSvg,
  FloorSvg,
  PreviewSvg,
  ZoneSvg,
} from "../../assets/svg";
import { ROUTES } from "../../router";
import { formatDatev1, padStart } from "../../utils/helpers";
import DeleteFloorPopup from "../../pages/ViewFloorDetails/DeleteFloorPopup";
import EditFloorModal from "../../pages/FloorManagement/EditFloorModal";
import { useState } from "react";
import { useUpdateFloorStatus } from "../../api/queryHooks";
import { StatusDropdown } from "../Dropdowns";
import toaster from "../../utils/toaster";
import useUserStore from "../../store/useUserStore";

function DeleteFloorButton({ floorId }) {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <button
        onClick={toggleModal}
        type="button"
        className="text-[#FF1212] flex items-center gap-[4px]"
      >
        <DeleteSvg className="fill-[#ff1212]" /> Delete
      </button>

      {open && <DeleteFloorPopup toggleModal={toggleModal} floorId={floorId} />}
    </>
  );
}

function EditFloorButton({ floorId }) {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <button
        onClick={toggleModal}
        type="button"
        className="text-[#222222] flex items-center gap-[4px]"
      >
        <EditSvg /> Edit
      </button>

      {open && <EditFloorModal toggleModal={toggleModal} floorId={floorId} />}
    </>
  );
}

export const FloorUpdateStatusDropdown = ({ floor }) => {
  const [status, setStatus] = useState(floor?.status);

  const { mutate: updateStatus } = useUpdateFloorStatus({
    onSuccess: () => {
      toaster.success("Floor status updated successfully");
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || "Failed to update floor status");
      setStatus(floor?.status); // Revert on error
    },
  });

  const handleStatusChange = (newStatus) => {
    setStatus(newStatus);
    updateStatus({ floorId: floor._id, status: newStatus });
  };

  const statusOptions = [
    { value: 1, label: "Active" },
    { value: 0, label: "Inactive" },
  ];

  return (
    <StatusDropdown
      options={statusOptions}
      value={status}
      onValueChange={handleStatusChange}
    />
  );
};

function FloorCard({ floor }) {
  const userPermissions = useUserStore((state) => state.permissions);

  const floor_id = floor?._id;
  const detailsRoute = ROUTES.GET_VIEW_FLOOR_DETAILS(floor_id);

  return (
    <div className="relative mb-[36px]">
      <div className="p-[10px] bg-[#F2F4F8] rounded-b-[9px] absolute -bottom-[36px] pt-[18px] left-0 right-0">
        <div className="h-full flex items-center justify-between pt-[9px]">
          <div className="text-[11px] text-[#7A838E] flex items-center gap-[10px] h-full">
            <button
              type="button"
              className="text-[#7A838E] flex items-center gap-[10px]"
            >
              Added on: {formatDatev1(floor.addedOn)}
            </button>
          </div>

          <div className="text-[11px] flex items-center gap-[27px] h-full">
            <button
              type="button"
              className="text-[#222222] flex items-center gap-[4px]"
            >
              <PreviewSvg /> Preview
            </button>
            {userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.addModify ? (
              <EditFloorButton floorId={floor_id} />
            ) : null}
            {userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.delete ? (
              <DeleteFloorButton floorId={floor_id} />
            ) : null}
          </div>
        </div>
      </div>
      <Link
        to={detailsRoute}
        className="relative p-[10px] bg-[#ffffff] border border-[#CCCCCC] rounded-[9px] flex items-center gap-[18px]"
      >
        <div className="w-[68px] h-[124px] flex items-center justify-center bg-[#E6F0FC] rounded-[8px] flex-shrink-0">
          <FloorSvg className="fill-[#227EEB] h-[32px] w-[32px]" />
        </div>
        <div className="w-full">
          <h2 className="text-[#222222] font-semibold text-[15px]">
            {floor?.floorName}
          </h2>
          <p className="text-[#7A838E] text-[11px]">
            Campus: <span className="text-[#222222]">{floor?.campusName}</span>
          </p>
          <div className="my-[13px] flex items-center gap-[10px]">
            <div className="text-[9px] bg-[#EEEEEE] p-[5px] w-fit min-w-[76px] max-w-[100px] truncate text-center text-[#222222] rounded-md">
              {floor?.buildingName}
            </div>
            <div className="text-[9px] bg-[#EEEEEE] p-[5px] w-fit min-w-[76px] text-center text-[#222222] rounded-md">
              Level {floor?.floorLevel}
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-[13px]">
              <button
                type="button"
                className="flex items-center gap-[4px] text-[#222222] text-[11px]"
              >
                <ZoneSvg /> {padStart(floor?.zoneCount)}
              </button>
            </div>
            {userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.addModify ? (
              <FloorUpdateStatusDropdown floor={floor} />
            ) : null}
          </div>
        </div>
      </Link>
    </div>
  );
}

export default FloorCard;
