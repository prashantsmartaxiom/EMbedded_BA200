import { ChipSvg } from "../../assets/svg";
import { PrimaryBtn2 } from "../Buttons";

function DeviceCard({
  title = "Unknown",
  type = "Unknown",
  canControl,
  onConfigureClick,
}) {
  return (
    <div className="group cursor-pointer border border-[#CCCCCC] p-[10px] h-[72px] rounded-[9px] flex items-center justify-between gap-[13px]">
      <div className="flex items-center justify-center bg-[#E6F0FC] rounded-lg w-[54px] h-[54px] flex-shrink-0">
        <ChipSvg className="h-[29px] fill-[#227EEB]" />
      </div>
      <div className="truncate flex-grow">
        <h2 className="text-[#222222] font-semibold text-[15px] truncate">
          {title}
        </h2>
        <p className="text-[11px] text-[#7A838E] truncate">
          Type: <span className="text-[#222222]">{type}</span>
        </p>
      </div>
      {canControl ? (
        <div>
          <PrimaryBtn2 onClick={onConfigureClick} className={"text-[11px]"}>
            Configure
          </PrimaryBtn2>
        </div>
      ) : null}
    </div>
  );
}

export default DeviceCard;
