import { Link } from "react-router-dom";
import {
  DeleteSvg,
  EditSvg,
  ChipSvg,
  CopySvg,
  ChannelSvg,
  SensorSvg,
  RebootDeviceSvg,
  ControlsSvg,
  LEDSvg,
  NounLEDSvg,
  NounShadeSvg,
} from "../../assets/svg";
import SuccessBadge, { WarningBadge } from "../Badges";
import { ROUTES } from "../../router";
import { useState } from "react";
import DeleteConfiguredDevicePopup from "../../pages/ViewConfiguredDevice/DeleteConfiguredDevicePopup";
import EditConfiguredDeviceModal from "../../pages/ViewConfiguredDevice/EditConfiguredDeviceModal";
import EditExternalDeviceModal from "../../pages/ViewConfiguredDevice/EditExternalDeviceModal";
import ControlConfiguredDevicePopup from "../../pages/ViewConfiguredDevice/ControlConfiguredDevicePopup";
import { useTriggerEvent } from "../../api/queryHooks";
import { padStart } from "../../utils/helpers";
import toaster from "../../utils/toaster";
import QUERY_KEYS from "../../api/queryKeys";
import { useQueryClient } from "react-query";

const DeleteDevice = ({ device }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <button
        type="button"
        className="text-[#FF1212] flex items-center gap-[4px]"
        onClick={toggleModal}
      >
        <DeleteSvg className="fill-[#ff1212]" /> Delete
      </button>
      {open ? (
        <DeleteConfiguredDevicePopup
          toggleModal={toggleModal}
          device_id={device.device_id}
          device={device}
        />
      ) : null}
    </>
  );
};

const EditDevice = ({ device }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  // Check if device is external (shade_lutron type)
  const isExternalDevice =
    device?.device_type?.toLowerCase() === "shade_lutron";

  return (
    <>
      <button
        type="button"
        className="text-[#222222] flex items-center gap-[4px]"
        onClick={toggleModal}
      >
        <EditSvg /> Edit
      </button>
      {open ? (
        isExternalDevice ? (
          <EditExternalDeviceModal device={device} onClose={toggleModal} />
        ) : (
          <EditConfiguredDeviceModal device={device} onClose={toggleModal} />
        )
      ) : null}
    </>
  );
};

const ControlDevice = ({ device }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <button
        type="button"
        className="text-[#222222] flex items-center gap-[4px]"
        onClick={toggleModal}
      >
        <ControlsSvg /> Controls
      </button>
      {open ? (
        <ControlConfiguredDevicePopup device={device} onClose={toggleModal} />
      ) : null}
    </>
  );
};

const RebootDevice = ({ device }) => {
  const queryClient = useQueryClient();
  const { mutate: triggerEvent, isLoading } = useTriggerEvent();
  const [status, setStatus] = useState("idle");

  const handleClick = () => {
    const payload = {
      device_id: device.device_id,
      type: "reboot",
    };

    triggerEvent(payload, {
      onSuccess: () => {
        queryClient.invalidateQueries({
          queryKey: [QUERY_KEYS.DISCOVERY_DEVICES],
          exact: false,
        });

        queryClient.invalidateQueries({
          queryKey: [QUERY_KEYS.CONFIGURED_DEVICES],
          exact: false,
        });
        toaster.success("Device reboot successfully");
        setStatus("success");
        setTimeout(() => setStatus("idle"), 500);
      },
      onError: () => {
        toaster.error("Failed to reboot device");
        setStatus("error");
        setTimeout(() => setStatus("idle"), 500);
      },
    });
  };

  const textColor =
    status === "success"
      ? "text-green-600"
      : status === "error"
      ? "text-red-600"
      : "text-[#222222]";

  return (
    <button
      onClick={handleClick}
      type="button"
      disabled={isLoading}
      className={`${textColor} flex items-center gap-[4px] transition-colors duration-300`}
    >
      <RebootDeviceSvg
        className={`text-sm ${isLoading ? "animate-spin" : ""}`}
      />{" "}
      Reboot
    </button>
  );
};

function ConfiguredDeviceCard({ device, canControl, canModify, canDelete }) {
  const isExternalDevice =
    device?.device_type?.toLowerCase() === "shade_lutron";
  const deviceStatus = device?.status; // Extract status to ensure re-render on change

  return (
    <div
      className="relative mb-[36px]"
      key={`${device?.device_id}-${deviceStatus}`}
    >
      <div className="h-[54px] p-[10px] bg-[#F2F4F8] rounded-b-[9px] absolute -bottom-[36px] pt-[18px] left-0 right-0">
        <div className="h-full flex items-center justify-between pt-[9px]">
          <div className="text-[11px] text-[#7A838E] flex items-center gap-[10px] h-full">
            {canControl ? <ControlDevice device={device} /> : null}
          </div>

          <div className="text-[11px] flex items-center gap-[15px] h-full">
            {canModify ? <EditDevice device={device} /> : null}
            {canControl & !isExternalDevice ? (
              <RebootDevice device={device} />
            ) : null}
            {canDelete ? <DeleteDevice device={device} /> : null}
          </div>
        </div>
      </div>
      <Link
        title={device?.device_name}
        to={
          isExternalDevice
            ? ROUTES.GET_VIEW_BMS_CONFIGURED_DEVICE(device.device_id)
            : ROUTES.GET_VIEW_CONFIGURED_DEVICE(device.device_id)
        }
        className="relative p-[10px] bg-[#ffffff] border border-[#CCCCCC] rounded-[9px] flex items-center gap-[18px]"
      >
        <div className="w-[68px] h-[124px] flex items-center justify-center bg-[#E6F0FC] rounded-[8px] flex-shrink-0">
          <ChipSvg className="fill-[#227EEB] h-[32px] w-[32px]" />
        </div>
        <div className="w-full">
          <div className="flex items-center justify-between">
            <h2 className="text-[#222222] font-semibold text-[15px]">
              {device?.device_name}
            </h2>
            {deviceStatus === "Active" ? (
              <SuccessBadge title={deviceStatus} />
            ) : (
              <WarningBadge title={deviceStatus} />
            )}
          </div>
          <p className="text-[#7A838E] text-[11px]">
            Device ID:{" "}
            <span className="text-[#222222]">{device?.device_id}</span>
          </p>
          <p className="text-[#7A838E] text-[11px]">
            Serial No.:{" "}
            <span className="text-[#222222]">{device.serial_number}</span>
          </p>
          <p className="text-[#7A838E] text-[11px]">
            Firmware: <span className="text-[#222222]">{device.firmware}</span>
          </p>
          <div className="mt-[4px] mb-[13px] flex items-center gap-[10px]">
            <div className="text-[9px] bg-[#EEEEEE] p-[5px] w-fit min-w-[76px] text-center text-[#222222] rounded-md">
              {device?.device_type ? device.device_type : "Unknown"}
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-[13px]">
              <button
                type="button"
                className="flex items-center gap-[4px] text-[#222222] text-[11px]"
              >
                <NounLEDSvg className="text-base" />{" "}
                {padStart(device?.channel_counts?.leds)}
              </button>
              <button
                type="button"
                className="flex items-center gap-[4px] text-[#222222] text-[11px]"
              >
                <NounShadeSvg className="text-base" />{" "}
                {padStart(device?.channel_counts?.shades)}
              </button>
              <button
                type="button"
                className="flex items-center gap-[4px] text-[#222222] text-[11px]"
              >
                <SensorSvg className="text-base w-4 h-4" />{" "}
                {padStart(device?.channel_counts?.sensors)}
              </button>
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}

export default ConfiguredDeviceCard;