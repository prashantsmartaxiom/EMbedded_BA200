import { io } from "socket.io-client";
import CONFIG from "../config";

const socket = io(CONFIG.SOCKET_BASE_URL, {
  autoConnect: false,
});

function connectSocket(token) {
  if (socket.connected) return;
  if (CONFIG.SHOULD_CONNECT_SOCKET === false) return;
  socket.auth = { token };
  socket.connect();

  return socket;
}

function disconnectSocket() {
  if (socket.connected) {
    socket.disconnect();
  }
}

export { connectSocket, disconnectSocket };
export default socket;
