const CONFIG = {
  API_BASE_URL: process.env.REACT_APP_API_URL,
  // SOCKET_BASE_URL: process.env.REACT_APP_SOCKET_URL,
  SOCKET_BASE_URL: process.env.REACT_APP_API_URL,
  SHOULD_CONNECT_SOCKET: true,
  REFETCH_INTERVAL: 0,
  CAN_EDIT_DEFAULT_ROLES: true,
  SHOULD_SEND_LOGSMONITORING_ACCESS_ROLES: false,

  GET_FLAG_URL_BY_ISO: (iso, size = "h20") =>
    `https://flagcdn.com/${size}/${iso.toLowerCase()}.png`,
};

export default CONFIG;
