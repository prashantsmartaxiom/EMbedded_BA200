import { FaEye, FaEyeSlash } from "react-icons/fa";
import { ReactComponent as IndentSidebarSvg } from "./IndentSidebar.svg";
import { FaLocationDot } from "react-icons/fa6";
import { ReactComponent as NotificationSvg } from "./Notification.svg";
import { RiDashboardFill } from "react-icons/ri";
import { BiSolidDownArrow, BiSolidUpArrow } from "react-icons/bi";

import { LuBuilding } from "react-icons/lu";
import { HiDeviceTablet } from "react-icons/hi";
import { IoNewspaperOutline } from "react-icons/io5";
import { FaUserCog } from "react-icons/fa";
import { AiFillControl } from "react-icons/ai";

import { IoSearch } from "react-icons/io5";
import { ReactComponent as AddSvg } from "./Plus.svg";
import { ReactComponent as BuildingSvg } from "./Building.svg";
import { ReactComponent as FloorSvg } from "./Floor.svg";
import { ReactComponent as ZoneSvg } from "./Zone.svg";
import { ReactComponent as ImagePlaceholderSvg } from "./ImagePlaceholder.svg";
import { ReactComponent as MdArrowDownSvg } from "./MdArrowDown.svg";
import { ReactComponent as CopySvg } from "./Copy.svg";
import { ReactComponent as PreviewSvg } from "./Preview.svg";
import { ReactComponent as EditSvg } from "./Edit.svg";
import { ReactComponent as DeleteSvg } from "./Delete.svg";
import { ReactComponent as ChipSvg } from "./Chip.svg";
import { ReactComponent as ChannelSvg } from "./Channel.svg";
import { ReactComponent as SensorSvg } from "./Sensor.svg";
import { ReactComponent as CircleCrossSvg } from "./CircleCross.svg";
import { ReactComponent as MoveSvg } from "./Move.svg";
import { ReactComponent as LEDSvg } from "./LED.svg";
import { ReactComponent as LEDonSvg } from "./LEDon.svg";
import { ReactComponent as NounLEDSvg } from "./NounBulb.svg";
import { ReactComponent as NounShadeSvg } from "./NounShade.svg";
import { ReactComponent as ToolSvg } from "./Tool.svg";
import { ReactComponent as LightBuldHeroSvg } from "./LightBuldHero.svg";
import { ReactComponent as CloudSunSvg } from "./CloudSun.svg";
import { ReactComponent as InvertSvg } from "./Invert.svg";
import { ReactComponent as SceneSvg } from "./Scene.svg";
import { MdOutlineKeyboardBackspace } from "react-icons/md";
import { MdInfo } from "react-icons/md";

import { FaCheck } from "react-icons/fa6";
import { FaMinus as IndeterminateSvg } from "react-icons/fa";
import { IoWarningOutline } from "react-icons/io5";
import { BsFillStopFill as StopSvg } from "react-icons/bs";

import { FiUpload, FiX } from "react-icons/fi";
import { FiLock as LockSvg, FiLogOut as LogoutSvg } from "react-icons/fi";
import { LuRefreshCcw } from "react-icons/lu";
import { ReactComponent as ControlsSvg } from "./Controls.svg";
import { ReactComponent as SuspendSvg } from "./Suspend.svg";
import { ReactComponent as AnalogClockSvg } from "./AnalogClock.svg";
import { ReactComponent as UserSvg } from "./User.svg";
import { ReactComponent as SceneOnSvg } from "./SceneOn.svg";
import { ReactComponent as SceneOffSvg } from "./SceneOff.svg";
import { ReactComponent as ShadeSSSvg } from "./ShadeSS.svg";
import { ReactComponent as ShadeTTSvg } from "./ShadeTT.svg";
import { RiToolsLine as UtilitiesSvg } from "react-icons/ri";

import { IoMdCloudOutline as CloudSvg } from "react-icons/io";
import { PiThermometerSimpleThin as TemperatureSvg } from "react-icons/pi";

import { ReactComponent as HeaderAQISvg } from "./HeaderAQI.svg";
import { ReactComponent as HeaderTemperatureSvg } from "./HeaderTemperature.svg";

// Weather SVGs - Day
import { ReactComponent as Weather0Svg } from "./WeatherSvgs/Day/Weather_0.svg";
import { ReactComponent as Weather1_44Svg } from "./WeatherSvgs/Day/Weather_1_44.svg";
import { ReactComponent as Weather45_50Svg } from "./WeatherSvgs/Day/Weather_45_50.svg";
import { ReactComponent as Weather51_60Svg } from "./WeatherSvgs/Day/Weather_51_60.svg";
import { ReactComponent as Weather61_70Svg } from "./WeatherSvgs/Day/Weather_61_70.svg";
import { ReactComponent as Weather71_79Svg } from "./WeatherSvgs/Day/Weather_71_79.svg";
import { ReactComponent as Weather80_94Svg } from "./WeatherSvgs/Day/Weather_80_94.svg";
import { ReactComponent as Weather95Svg } from "./WeatherSvgs/Day/Weather_95.svg";

// Weather SVGs - Night
import { ReactComponent as Weather0NSvg } from "./WeatherSvgs/Night/Weather_0_N.svg";
import { ReactComponent as Weather1_44NSvg } from "./WeatherSvgs/Night/Weather_1_44_N.svg";
import { ReactComponent as Weather45_50NSvg } from "./WeatherSvgs/Night/Weather_45_50_N.svg";
import { ReactComponent as Weather51_60NSvg } from "./WeatherSvgs/Night/Weather_51_60_N.svg";
import { ReactComponent as Weather61_70NSvg } from "./WeatherSvgs/Night/Weather_61_70_N.svg";
import { ReactComponent as Weather71_79NSvg } from "./WeatherSvgs/Night/Weather_71_79_N.svg";
import { ReactComponent as Weather80_94NSvg } from "./WeatherSvgs/Night/Weather_80_94_N.svg";
import { ReactComponent as Weather95NSvg } from "./WeatherSvgs/Night/Weather_95_N.svg";

import { ReactComponent as FeelsLikeWSvg } from "./FeelsLikeW.svg";
import { ReactComponent as WindWSvg } from "./WindW.svg";
import { ReactComponent as GaugeHighWSvg } from "./GaugeHighW.svg";
import { ReactComponent as CloudWSvg } from "./CloudW.svg";
import { ReactComponent as HumidityWSvg } from "./HumidityW.svg";
import { ReactComponent as DewPointWSvg } from "./DewPointW.svg";

import { ReactComponent as IndoorTemperatureSvg } from "./IndoorTemperature.svg";
import { ReactComponent as IndoorHumiditySvg } from "./IndoorHumidity.svg";
import { ReactComponent as BrightnessShalfSvg } from "./BrightnessShalf.svg";
import { ReactComponent as PM2_5Svg } from "./PM2_5.svg";
import { ReactComponent as PM10Svg } from "./PM10.svg";
import { ReactComponent as Co2Svg } from "./Co2.svg";

export {
  PM2_5Svg,
  PM10Svg,
  Co2Svg,
  IndoorHumiditySvg,
  BrightnessShalfSvg,
  IndoorTemperatureSvg,
  WindWSvg,
  GaugeHighWSvg,
  CloudWSvg,
  HumidityWSvg,
  DewPointWSvg,
  FaEye as EyeSvg,
  FaEyeSlash as EyeSlashSvg,
  FaLocationDot as LocationSvg,
  IndentSidebarSvg,
  NotificationSvg,
  RiDashboardFill as DashboardSvg,
  LuBuilding as CampusSvg,
  BiSolidDownArrow as DownArrowSvg,
  BiSolidUpArrow as UpArrowSvg,
  HiDeviceTablet as DeviceSvg,
  IoNewspaperOutline as LogsSvg,
  FaUserCog as AccountManagementSvg,
  AiFillControl as IntelligentControlsSvg,
  IoSearch as SearchSvg,
  AddSvg,
  BuildingSvg,
  FloorSvg,
  ZoneSvg,
  ImagePlaceholderSvg,
  MdArrowDownSvg,
  CopySvg,
  PreviewSvg,
  EditSvg,
  DeleteSvg,
  ChipSvg,
  ChannelSvg,
  SensorSvg,
  MdOutlineKeyboardBackspace as BackspaceSvg,
  CircleCrossSvg,
  LEDSvg,
  LEDonSvg,
  MoveSvg,
  FaCheck as CheckSvg,
  ToolSvg,
  MdInfo as CircleInfoSvg,
  IndeterminateSvg,
  IoWarningOutline as WarningSvg,
  StopSvg,
  FiUpload,
  FiX,
  UserSvg,
  LockSvg,
  LogoutSvg,
  LightBuldHeroSvg,
  LuRefreshCcw as RebootDeviceSvg,
  ControlsSvg,
  NounLEDSvg,
  NounShadeSvg,
  UtilitiesSvg,
  AnalogClockSvg,
  SuspendSvg,
  CloudSunSvg,
  InvertSvg,
  SceneSvg,
  SceneOnSvg,
  SceneOffSvg,
  CloudSvg,
  TemperatureSvg,
  ShadeSSSvg,
  ShadeTTSvg,
  HeaderAQISvg,
  HeaderTemperatureSvg,
  // Weather SVGs - Day
  Weather0Svg,
  Weather1_44Svg,
  Weather45_50Svg,
  Weather51_60Svg,
  Weather61_70Svg,
  Weather71_79Svg,
  Weather80_94Svg,
  Weather95Svg,
  // Weather SVGs - Night
  Weather0NSvg,
  Weather1_44NSvg,
  Weather45_50NSvg,
  Weather51_60NSvg,
  Weather61_70NSvg,
  Weather71_79NSvg,
  Weather80_94NSvg,
  Weather95NSvg,
  FeelsLikeWSvg,
};
