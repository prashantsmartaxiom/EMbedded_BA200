import { useFormik } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";
import { A, Input, PasswordInput, PrimaryBtn } from "../../components";
import { ROUTES } from "../../router";
import { useSignIn } from "../../api/queryHooks";
import useUserStore from "../../store/useUserStore";
import toaster from "../../utils/toaster";
import { REGEX } from "../../consts";

const SignInForm = () => {
  const setUser = useUserStore((state) => state.setUser);
  const navigate = useNavigate();

  const { mutate: signIn, isLoading } = useSignIn({
    onSuccess: (data) => {
      setUser(data);
      const role = data?.data?.roleDetail?.roleName;
      if (role === "Tenant" || role === "Operator") 
        navigate(ROUTES.CONTROL_SYSTEM);
      else
        navigate(ROUTES.DASHBOARD); // or wherever you want to redirect
    },
    onError: (error) => {
      toaster.error(error.response?.data?.message || "Login failed. Please try again.");
    },
  });

  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    validateOnBlur: false,
    validateOnChange: false,
    validationSchema: Yup.object({
      email: Yup.string().matches(REGEX.email, "Invalid email").required("Required"),
      password: Yup.string()
        .min(8, "At least 8 characters")
        .matches(/[0-9!@#$%^&*]/, "Must contain number or symbol")
        .matches(/[a-z]/, "Must contain lowercase")
        .matches(/[A-Z]/, "Must contain uppercase")
        .required("Required"),
    }),
    onSubmit: (values) => {
      signIn(values);
    },
  });

  return (
    <form onSubmit={formik.handleSubmit}>
      <div className="mb-[15px]">
        <Input
          name="email"
          type="email"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.email}
          placeholder="Email"
          className="w-full"
        />
        {formik.touched.email && formik.errors.email && (
          <div className="text-error">{formik.errors.email}</div>
        )}
      </div>

      <div className="mb-[15px]">
        <PasswordInput
          name="password"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.password}
          placeholder="Password"
          className="w-full"
        />
        {formik.touched.password && formik.errors.password && (
          <div className="text-error">{formik.errors.password}</div>
        )}
      </div>

      <div className="text-right mb-[20px]">
        <A to={ROUTES.FORGOT_PASSWORD} className="font-semibold">Forgot Password?</A>
      </div>

      <div className="mb-[30px]">
        <PrimaryBtn className={"w-full"} type="submit" disabled={isLoading}>
          {isLoading ? "SIGNING IN..." : "SIGN IN"}
        </PrimaryBtn>
      </div>

      <div className="text-center">
        <p className="text-[#AAAAAA] text-sm">
          Don't have an account? <A to={ROUTES.SIGN_UP} className="font-semibold">Create New Account</A>
        </p>
      </div>
    </form>
  );
};

export default SignInForm;
