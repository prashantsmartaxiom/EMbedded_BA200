import { useFormik } from "formik";
import * as Yup from "yup";
import { useLocation, useNavigate } from "react-router-dom";
import { A, Input, PrimaryBtn } from "../../components";
import { ROUTES } from "../../router";
import { BackspaceSvg } from "../../assets/svg";
import { useForgotPassword } from "../../api/queryHooks";
import toaster from "../../utils/toaster";
import { REGEX } from "../../consts";

const ForgotPasswordForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email;
  
  const { mutate: sendResetEmail, isLoading } = useForgotPassword({
    onSuccess: (data) => {
      toaster.success("OTP sent successfully!");
      // Navigate to verify account page with email
      navigate(ROUTES.VERIFY_ACCOUNT, { 
        state: { email: formik.values.email } 
      });
    },
    onError: (error) => {
      toaster.error(error.response?.data?.message || "Failed to send OTP.");
    },
  });

  const formik = useFormik({
    initialValues: {
      email: email || "",
    },
    validateOnBlur: false,
    validateOnChange: false,
    validationSchema: Yup.object({
      email: Yup.string().matches(REGEX.email, "Invalid email").required("Required"),
    }),
    onSubmit: (values) => {
      sendResetEmail(values.email);
    },
  });

  return (
    <form onSubmit={formik.handleSubmit}>
      <div className="mb-[30px]">
        <Input
          name="email"
          type="email"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.email}
          placeholder="Email"
          className="w-full"
        />
        {formik.touched.email && formik.errors.email && (
          <div className="text-red-500 text-xs mt-1">{formik.errors.email}</div>
        )}
      </div>

      <div className="mb-[30px]">
        <PrimaryBtn className="w-full" type="submit" disabled={isLoading}>
          {isLoading ? "SENDING..." : "SEND"}
        </PrimaryBtn>
      </div>

      <div className="text-center">
        <A
          to={ROUTES.SIGN_IN}
          className="!text-[#222222] text-sm flex items-center justify-center gap-1"
        >
          <BackspaceSvg /> Back to sign in
        </A>
      </div>
    </form>
  );
};

export default ForgotPasswordForm;
