import { useState, useRef, useEffect } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";
import { A, PrimaryBtn } from "../../components";
import { useVerifyCode, useForgotPassword, useResendOTP } from "../../api/queryHooks";
import { ROUTES } from "../../router";
import toaster from "../../utils/toaster";
import { BackspaceSvg } from "../../assets/svg";

// Custom OTP Input Component
const OTPInput = ({ value, onChange, length = 4 }) => {
  const inputRefs = useRef([]);

  const handleChange = (index, inputValue) => {
    const newValue = value.split("");
    newValue[index] = inputValue;
    const updatedValue = newValue.join("");
    onChange(updatedValue);

    // Auto-focus next input
    if (inputValue && index < length - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index, e) => {
    // Handle backspace
    if (e.key === "Backspace" && !e.target.value && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const pastedData = e.clipboardData
      .getData("text")
      .replace?.(/\D/g, "")
      .slice(0, length);
    onChange(pastedData);

    // Focus the last filled input or next empty one
    const nextFocusIndex = Math.min(pastedData.length, length - 1);
    inputRefs.current[nextFocusIndex]?.focus();
  };

  return (
    <div className="flex gap-3">
      {Array.from({ length }, (_, index) => (
        <input
          key={index}
          ref={(el) => (inputRefs.current[index] = el)}
          type="text"
          maxLength={1}
          value={value[index] || ""}
          onChange={(e) =>
            handleChange(index, e.target.value.replace?.(/\D/g, ""))
          }
          onKeyDown={(e) => handleKeyDown(index, e)}
          onPaste={handlePaste}
          className="w-12 h-12 text-center text-lg font-semibold border border-[#E7E8E8] rounded-[10px] bg-white text-[#222222] focus:outline-none focus:border-[#227EEB] focus:ring-1 focus:ring-[#227EEB]"
        />
      ))}
    </div>
  );
};

const VerifyAccountForm = ({ email = "" }) => {
  const COOL_DOWN_TIME = 60;
  const navigate = useNavigate();
  const [otpValue, setOtpValue] = useState("");
  const [resendDisabled, setResendDisabled] = useState(true);
  const [countdown, setCountdown] = useState(COOL_DOWN_TIME);

  useEffect(() => {
    let interval;
    if (countdown > 0) {
      interval = setInterval(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
    } else if (countdown === 0 && resendDisabled) {
      setResendDisabled(false);
    }

    return () => clearInterval(interval);
  }, [countdown, resendDisabled]);

  const { mutate: verifyOtp, isLoading: isVerifying } = useVerifyCode({
    onSuccess: (data) => {
      toaster.success("OTP verified successfully!");
      // Navigate to reset password page with email
      navigate(ROUTES.RESET_PASSWORD, {
        state: { email, verified: true },
      });
    },
    onError: (error) => {
      toaster.error(
        error.response?.data?.message || "Invalid OTP. Please try again."
      );
    },
  });

  const { mutate: resendOtp, isLoading: isResending } = useResendOTP({
    onSuccess: (data) => {
      toaster.success("OTP resent successfully!");
    },
    onError: (error) => {
      setResendDisabled(true);
      setCountdown(error?.response?.data?.data?.remainingCooldown || 0);
      toaster.error(error.response?.data?.message || "Failed to resend OTP.");
    },
  });

  const formik = useFormik({
    initialValues: {
      otp: "",
    },
    validateOnBlur: false,
    validateOnChange: false,
    validationSchema: Yup.object({
      otp: Yup.string()
        .length(6, "OTP must be 6 digits")
        .matches(/^\d+$/, "OTP must contain only numbers")
        .required("Required"),
    }),
    onSubmit: (values) => {
      verifyOtp({ email, otp: values.otp });
    },
  });

  const handleOTPChange = (value) => {
    setOtpValue(value);
    formik.setFieldValue("otp", value);
  };

  const handleResendCode = () => {
    setResendDisabled(true);
    setCountdown(COOL_DOWN_TIME);
    resendOtp(email, true);
  };

  return (
    <div className="w-full">
      <form onSubmit={formik.handleSubmit}>
        {/* Email Display */}
        <div className="text-center mb-8">
          <p className="text-sm text-[#939CA7]">
            We just sent a 6-digit verification code to
          </p>
          <p className="text-sm text-[#222222] font-semibold mt-1">
            {email}.{" "}
            <span className="text-sm text-[#939CA7]">
              Enter the code in the box below to continue.
            </span>
          </p>
        </div>

        {/* OTP Input */}
        <div className="mb-8 flex justify-center">
          <OTPInput value={otpValue} onChange={handleOTPChange} length={6} />
        </div>

        {/* Error Message */}
        {formik.touched.otp && formik.errors.otp && (
          <div className="text-red-500 text-xs text-center mb-4">
            {formik.errors.otp}
          </div>
        )}

        {/* Submit Button */}
        <div className="mb-6">
          <PrimaryBtn className="w-full" type="submit" disabled={isVerifying}>
            {isVerifying ? "VERIFYING..." : "SUBMIT"}
          </PrimaryBtn>
        </div>

        {/* Resend Code */}
        <div className="text-center mb-6">
          <p className="text-sm text-[#939CA7]">
            Didn't receive a code?{" "}
            <button
              type="button"
              onClick={handleResendCode}
              disabled={resendDisabled || isResending}
              className={`${
                resendDisabled || isResending
                  ? "text-gray-400 cursor-not-allowed"
                  : "text-[#227EEB] hover:text-[#1a5bb8]"
              } underline font-semibold`}
            >
              {isResending
                ? "Resending..."
                : resendDisabled
                ? `Resend Code (${countdown}s)`
                : "Resend Code"}
            </button>
          </p>
        </div>

        <div className="text-center">
          <A
            to={ROUTES.FORGOT_PASSWORD}
            state={{ email }}
            className="!text-[#222222] text-sm flex items-center justify-center gap-1"
          >
            <BackspaceSvg /> Back
          </A>
        </div>
      </form>
    </div>
  );
};

export default VerifyAccountForm;
