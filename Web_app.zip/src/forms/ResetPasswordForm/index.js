import { useFormik } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";
import { PasswordInput, PrimaryBtn } from "../../components";
import { CheckSvg } from "../../assets/svg";
import { useResetPassword } from "../../api/queryHooks";
import { ROUTES } from "../../router";
import toaster from "../../utils/toaster";

const ResetPasswordForm = ({ email }) => {
  const navigate = useNavigate();
  
  const { mutate: resetUserPassword, isLoading } = useResetPassword({
    onSuccess: (data) => {
      toaster.success("Password reset successfully!");
      // Navigate to sign in page
      navigate(ROUTES.SIGN_IN);
    },
    onError: (error) => {
      toaster.error(error.response?.data?.message || "Failed to reset password.");
    },
  });

  const formik = useFormik({
    initialValues: {
      password: "",
      confirmPassword: "",
    },
    validateOnBlur: false,
    validateOnChange: false,
    validationSchema: Yup.object({
      password: Yup.string()
        .min(8, "At least 8 characters")
        .matches(/[0-9!@#$%^&*]/, "Must contain number or symbol")
        .matches(/[a-z]/, "Must contain lowercase")
        .matches(/[A-Z]/, "Must contain uppercase")
        .required("Required"),
      confirmPassword: Yup.string()
        .oneOf([Yup.ref("password"), null], "Passwords must match")
        .required("Required"),
    }),
    onSubmit: (values) => {
      resetUserPassword({ 
        email, 
        newPassword: values.password 
      });
    },
  });

  // Password validation helpers
  const hasMinLength = formik.values.password.length >= 8;
  const hasNumberOrSymbol = /[0-9!@#$%^&*]/.test(formik.values.password);
  const hasLowercase = /[a-z]/.test(formik.values.password);
  const hasUppercase = /[A-Z]/.test(formik.values.password);

  const ValidationItem = ({ isValid, text }) => (
    <div className="flex items-center gap-1 text-xs">
      {isValid ? (
        <CheckSvg className="w-3 h-3 text-green-500" />
      ) : (
        <div className="w-3 h-3 rounded-full border border-gray-300"></div>
      )}
      <span className={isValid ? "text-green-500" : "text-gray-500"}>
        {text}
      </span>
    </div>
  );

  return (
    <form onSubmit={formik.handleSubmit}>
      {/* New Password */}
      <div className="mb-[15px]">
        <PasswordInput
          name="password"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.password}
          placeholder="New Password"
          className="w-full"
          autoComplete="new-password"
        />

        {/* Password Strength Indicators */}
        {formik.values.password && (
          <div className="mt-3 space-y-1">
            <ValidationItem isValid={hasMinLength} text="Least 8 characters" />
            <ValidationItem
              isValid={hasNumberOrSymbol}
              text="Least one number (0-9) or symbol"
            />
            <ValidationItem
              isValid={hasLowercase && hasUppercase}
              text="Lowercase (a-z) and uppercase (A-Z)"
            />
          </div>
        )}

        {formik.touched.password && formik.errors.password && (
          <div className="text-red-500 text-xs mt-1">
            {formik.errors.password}
          </div>
        )}
      </div>

      {/* Confirm New Password */}
      <div className="mb-[30px]">
        <PasswordInput
          name="confirmPassword"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.confirmPassword}
          placeholder="Confirm New Password"
          className="w-full"
          autoComplete="off"
        />
        {formik.touched.confirmPassword && formik.errors.confirmPassword && (
          <div className="text-red-500 text-xs mt-1">
            {formik.errors.confirmPassword}
          </div>
        )}
      </div>

      {/* Submit Button */}
      <div className="mb-[30px]">
        <PrimaryBtn className="w-full" type="submit" disabled={isLoading}>
          {isLoading ? "RESETTING..." : "SUBMIT"}
        </PrimaryBtn>
      </div>
    </form>
  );
};

export default ResetPasswordForm;
