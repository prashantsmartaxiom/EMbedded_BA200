import { useFormik } from "formik";
import * as Yup from "yup";
import {
  LayoutPreview,
  PrimaryBtn2,
  PrimaryInput,
  SpinnerV1,
} from "../../components";
import { TEMPLATE_LAYOUTS } from "../../consts";
import { ROUTES } from "../../router";
import { useNavigate } from "react-router-dom";
import { useGetLayoutList } from "../../api/queryHooks";
import { apiLayoutsDataMapper } from "../../utils/helpers";

function NewTemplateForm({ onTemplateCreated }) {
  const { data, isLoading } = useGetLayoutList();
  const layouts = apiLayoutsDataMapper(data?.data || []);
  const navigate = useNavigate();
  const formik = useFormik({
    initialValues: {
      templateName: "",
      layout: null,
    },
    validationSchema: Yup.object({
      templateName: Yup.string().required("Template name is required"),
      layout: Yup.object().required("Layout is required"),
    }),
    onSubmit: (values) => {
      // Call the callback to close the modal
      onTemplateCreated && onTemplateCreated();
      // Navigate to template creation page
      navigate(ROUTES.CREATE_INTELLIGENT_CONTROLS_TEMPLATE, { state: values });
    },
  });

  const handleSelectLayout = (layout) => {
    formik.setFieldValue("layout", layout);
  };

  return (
    <form
      className="flex flex-col flex-1 min-h-0"
      onSubmit={formik.handleSubmit}
    >
      {/* Template Name */}
      <div className="px-5 pb-5 border-b border-[#DDDDDD]">
        <div className="flex items-center justify-between w-full gap-10">
          <label htmlFor="templateName" className="text-[#222222] text-[12px]">
            Template Name:
          </label>
          <div className="flex-grow">
            <PrimaryInput
              id="templateName"
              name="templateName"
              className={`w-full ${
                formik.touched.templateName && formik.errors.templateName
                  ? "!border-red-500"
                  : ""
              }`}
              placeholder="Enter template name"
              value={formik.values.templateName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
          </div>
        </div>
      </div>

      <div className="p-5 flex-1 overflow-y-auto">
        <h3
          className={`${
            formik.touched.layout && formik.errors.layout
              ? "text-red-500"
              : "text-[#222222]"
          } font-semibold text-[12px] mb-5 mt-1`}
        >
          Choose Layout:
        </h3>
        {isLoading ? (
          <div className="flex items-center justify-center p-5">
            <SpinnerV1 />
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-5">
            {/* {Object.keys(TEMPLATE_LAYOUTS).map((key) => (
              <LayoutPreview
                type={key}
                key={key}
                isSelected={formik.values.layout === key}
                onClick={() => handleSelectLayout(key)}
              />
            ))} */}

            {layouts.map((layout) => (
              <LayoutPreview
                key={layout?.id}
                layout={layout}
                isSelected={formik.values?.layout?.id === layout?.id}
                onClick={() => handleSelectLayout(layout)}
              />
            ))}
          </div>
        )}
      </div>

      <div className="p-5 flex justify-end border-t border-[#DDDDDD]">
        <PrimaryBtn2 type="submit" className="min-w-20 justify-center">
          NEXT
        </PrimaryBtn2>
      </div>
    </form>
  );
}

export default NewTemplateForm;
