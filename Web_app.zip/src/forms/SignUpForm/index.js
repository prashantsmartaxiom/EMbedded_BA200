import { useFormik } from "formik";
import * as Yup from "yup";
import { useState, useEffect } from "react";
import * as Select from "@radix-ui/react-select";
import {
  A,
  Checkbox,
  Input,
  PasswordInput,
  PrimaryBtn,
} from "../../components";
import { ROUTES } from "../../router";
import { BackspaceSvg, DownArrowSvg } from "../../assets/svg";
import { useNavigate } from "react-router-dom";
import { useSignUp } from "../../api/queryHooks";
import toaster from "../../utils/toaster";
import { countryCodes } from "../../utils/countryCodes";
import CONFIG from "../../config";
import { REGEX } from "../../consts";

const SignUpForm = () => {
  const [countryCode, setCountryCode] = useState(countryCodes[0]?.phonecode);
  const [userLocation, setUserLocation] = useState("unknown");

  const navigate = useNavigate();

  // Get user location on component mount
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation(
            `${position.coords.latitude},${position.coords.longitude}`
          );
        },
        (error) => {
          setUserLocation("unknown");
        }
      );
    }
  }, []);

  // Get selected country data for validation
  const selectedCountry = countryCodes.find(
    (country) => country.phonecode === countryCode
  );

  // Determine max length based on country regex
  const getMaxLength = () => {
    if (selectedCountry && selectedCountry.regex) {
      // Extract expected length from regex patterns
      switch (selectedCountry.iso) {
        case "US": return 10; // US/Canada: 10 digits
        case "IN": return 10; // India: 10 digits
        case "CN": return 11; // China: 11 digits
        default: return 15; // Default max length
      }
    }
    return 15; // Default max length
  };

  // Create dynamic validation for mobile number based on selected country
  const createMobileValidation = () => {
    if (selectedCountry && selectedCountry.regex) {
      return Yup.string()
        .matches(
          new RegExp(selectedCountry.regex),
          `Invalid mobile number for ${selectedCountry.iso}`
        );
    }
    return Yup.string()
      .matches(/^\d{7,15}$/, "Mobile number must be 7-15 digits");
  };

  const { mutate: signUp, isLoading } = useSignUp({
    onSuccess: () => {
      toaster.success("Account created successfully!");
      navigate(ROUTES.SIGN_IN);
    },
    onError: (error) => {
      const errorMessage =
        error.response?.data?.message || "Signup failed. Please try again.";
      toaster.error(errorMessage);
    },
  });

  const formik = useFormik({
    initialValues: {
      fullName: "",
      email: "",
      mobile: "",
      password: "",
      confirmPassword: "",
      agreeToTerms: false,
    },
    validateOnBlur: false,
    validateOnChange: false,
    validationSchema: Yup.object({
      fullName: Yup.string()
        .min(2, "Name must be at least 2 characters")
        .required("Required"),
      email: Yup.string().matches(REGEX.email, "Invalid email").required("Required"),
      mobile: createMobileValidation(),
      password: Yup.string()
        .min(8, "At least 8 characters")
        .matches(/[0-9!@#$%^&*]/, "Must contain number or symbol")
        .matches(/[a-z]/, "Must contain lowercase")
        .matches(/[A-Z]/, "Must contain uppercase")
        .required("Required"),
      confirmPassword: Yup.string()
        .oneOf([Yup.ref("password"), null], "Passwords must match")
        .required("Required"),
      agreeToTerms: Yup.boolean()
        .oneOf([true], "You must agree to the terms and conditions")
        .required("Required"),
    }),
    enableReinitialize: true, // This allows the validation schema to update when country changes
    onSubmit: (values) => {
      const submitData = {
        fullName: values.fullName,
        location: userLocation,
        email: values.email,
        password: values.password,
        role: "user",
      };
      
      // Only include contactNumber if mobile is provided
      if (values.mobile.trim()) {
        submitData.contactNumber = countryCode + " " + values.mobile.trim();
      }
      
      signUp(submitData);
    },
  });

  return (
    <form onSubmit={formik.handleSubmit}>
      {/* Full Name */}
      <div className="mb-[15px]">
        <Input
          name="fullName"
          type="text"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.fullName}
          placeholder="Full Name"
          className="w-full"
        />
        {formik.touched.fullName && formik.errors.fullName && (
          <div className="text-red-500 text-xs mt-1">
            {formik.errors.fullName}
          </div>
        )}
      </div>

      {/* Email */}
      <div className="mb-[15px]">
        <Input
          name="email"
          type="email"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.email}
          placeholder="Email"
          className="w-full"
        />
        {formik.touched.email && formik.errors.email && (
          <div className="text-red-500 text-xs mt-1">{formik.errors.email}</div>
        )}
      </div>

      {/* Mobile Number */}
      <div className="mb-[15px]">
        <div className="flex">
          <Select.Root 
            value={countryCode} 
            onValueChange={(value) => {
              setCountryCode(value);
              // Clear mobile number when country changes to trigger re-validation
              formik.setFieldValue("mobile", "");
            }}
          >
            <Select.Trigger className="group text-[#222222] placeholder:text-[#939CA7] rounded-l-[10px] border border-r-0 border-[#E7E8E8] bg-[#ffffff] p-[10px] text-xs focus:outline-[#227EEB] w-[80px] flex items-center justify-between">
              <Select.Value placeholder="Country" />
              <Select.Icon className="text-[#222222] flex-shrink-0 transition-transform duration-200 group-data-[state=open]:rotate-180">
                <DownArrowSvg />
              </Select.Icon>
            </Select.Trigger>
            
            <Select.Portal>
              <Select.Content className="max-h-[300px] bg-white rounded-md shadow-lg z-50 border border-[#E7E8E8]">
                <Select.Viewport className="p-1">
                  {countryCodes.map((country) => (
                    <Select.Item 
                      key={country.id} 
                      value={country.phonecode}
                      className="relative flex items-center min-h-7 pr-9 pl-6 py-2 rounded-sm text-xs leading-none text-gray-800 select-none cursor-pointer data-[highlighted]:outline-none data-[highlighted]:bg-blue-500 data-[highlighted]:text-white"
                    >
                      <div className="flex items-center gap-2">
                        <img 
                          src={CONFIG.GET_FLAG_URL_BY_ISO(country.iso)} 
                          alt={`${country.iso} flag`}
                          className="w-4 h-3 object-cover"
                        />
                        <Select.ItemText>{country.phonecode}</Select.ItemText>
                      </div>
                      <Select.ItemIndicator className="absolute left-0 w-6 inline-flex items-center justify-center">
                        ✓
                      </Select.ItemIndicator>
                    </Select.Item>
                  ))}
                </Select.Viewport>
              </Select.Content>
            </Select.Portal>
          </Select.Root>
          <Input
            name="mobile"
            type="tel"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.mobile}
            placeholder="Mobile Number (Optional)"
            className="flex-1 rounded-l-none border-l-0"
            maxLength={getMaxLength()}
            pattern="[0-9]*"
          />
        </div>
        {formik.touched.mobile && formik.errors.mobile && (
          <div className="text-red-500 text-xs mt-1">
            {formik.errors.mobile}
          </div>
        )}
      </div>

      {/* Create Password */}
      <div className="mb-[15px]">
        <PasswordInput
          name="password"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.password}
          placeholder="Create Password"
          className="w-full"
          autoComplete="new-password"
        />
        {formik.touched.password && formik.errors.password && (
          <div className="text-red-500 text-xs mt-1">
            {formik.errors.password}
          </div>
        )}
      </div>

      {/* Confirm Password */}
      <div className="mb-[15px]">
        <PasswordInput
          name="confirmPassword"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.confirmPassword}
          placeholder="Confirm Password"
          className="w-full"
          autoComplete="off"
        />
        {formik.touched.confirmPassword && formik.errors.confirmPassword && (
          <div className="text-red-500 text-xs mt-1">
            {formik.errors.confirmPassword}
          </div>
        )}
      </div>

      {/* Terms and Conditions */}
      <div className="mb-[20px]">
        <div className="flex items-center gap-2">
          <Checkbox
            // className="flex h-4 w-4 appearance-none items-center justify-center rounded border border-gray-400 bg-white outline-none data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
            checked={formik.values.agreeToTerms}
            onCheckedChange={(checked) =>
              formik.setFieldValue("agreeToTerms", checked)
            }
            id="agreeToTerms"
          />
          <label
            htmlFor="agreeToTerms"
            className="text-xs text-[#222222] leading-tight"
          >
            By creating this account you agree to{" "}
            <A
              to="/terms-and-conditions"
              className="text-[#227EEB] text-xs underline font-semibold"
            >
              Terms and Conditions
            </A>
            .
          </label>
        </div>
        {formik.touched.agreeToTerms && formik.errors.agreeToTerms && (
          <div className="text-red-500 text-xs mt-1">
            {formik.errors.agreeToTerms}
          </div>
        )}
      </div>

      {/* Create Account Button */}
      <div className="mb-[30px]">
        <PrimaryBtn className="w-full" type="submit" disabled={isLoading}>
          {isLoading ? "CREATING..." : "CREATE ACCOUNT"}
        </PrimaryBtn>
      </div>

      {/* Back to Sign In */}
      <div className="text-center">
        <A
          to={ROUTES.SIGN_IN}
          className="!text-[#222222] text-sm flex items-center justify-center gap-1"
        >
          <BackspaceSvg /> Back to sign in
        </A>
      </div>
    </form>
  );
};

export default SignUpForm;
