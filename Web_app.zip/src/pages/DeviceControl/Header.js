import { PrimaryDropdown, SearchInput } from "../../components";
import { useGetActiveDevicesOptionsForGroup } from "../../api/queryHooks";
import Seperator from "../../components/Header/Seperator";
import AddNewDeviceModal from "../ControlSystem/AddNewDeviceModal";

function Header({ onSearchChange, selectedDevice, onDeviceChange }) {
  const { data: devicesData, isLoading: isLoadingDevices } =
    useGetActiveDevicesOptionsForGroup({ type: "normal" });

  return (
    <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
      <h2 className="text-[#222222] font-bold">Device Controls</h2>
      <div className="flex items-center gap-[15px]">
        <SearchInput
          className="w-[260px]"
          placeholder="Search by device id"
          onChange={(e) => onSearchChange(e.target.value)}
        />
        <div className="flex items-center gap-[10px]">
          <span className="text-[#222222] text-[12px]">Filter:</span>
          <PrimaryDropdown
            className="w-[200px] !h-[36px]"
            options={[
              { value: null, label: "All Devices" },
              ...(devicesData?.map((item) => ({
                ...item,
                label: item.value,
              })) || []),
            ]}
            value={selectedDevice}
            onValueChange={onDeviceChange}
            placeholder={
              isLoadingDevices ? "Loading devices..." : "All Devices"
            }
            disabled={isLoadingDevices}
          />
        </div>
      </div>
    </div>
  );
}

export default Header;
