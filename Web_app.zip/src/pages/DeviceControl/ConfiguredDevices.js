import { useGetConfiguredDevices } from "../../api/queryHooks";
import { ConfiguredDeviceCard, SpinnerV1 } from "../../components";
import useUserStore from "../../store/useUserStore";

function ConfiguredDevices({ search, deviceFilter }) {
  const userPermissions = useUserStore((state) => state.permissions);
  const { data, isLoading, error } = useGetConfiguredDevices(search, deviceFilter, false);
  const configured_devices = data?.data?.configured_devices || [];

  // Filter out shade_lutron devices as they are now shown in BMS Control
  const filteredDevices = configured_devices.filter(device => device?.device_type?.toLowerCase() !== 'shade_lutron');

  if (isLoading)
    return (
      <div className="p-5">
        <SpinnerV1 />
      </div>
    );
  if (error) return <div>Error loading devices</div>;

  return (
    <>
      {filteredDevices.length === 0 ? (
        <div className="p-5 text-xs w-full text-center">No devices found</div>
      ) : (
        <div className="grid grid-cols-2 xl:grid-cols-3 gap-[15px] mt-[20px]">
          {filteredDevices.map((device) => (
            <ConfiguredDeviceCard
              key={device.device_id}
              device={device}
              canControl={
                userPermissions?.DEVICE_MANAGEMENT?.device_control?.addModify
              }
              canView={
                userPermissions?.DEVICE_MANAGEMENT?.device_control?.readOnly
              }
              canModify={
                userPermissions?.DEVICE_MANAGEMENT?.device_control?.addModify
              }
              canDelete={
                userPermissions?.DEVICE_MANAGEMENT?.device_control?.delete
              }
            />
          ))}
        </div>
      )}
    </>
  );
}

export default ConfiguredDevices;
