// import { useState } from "react";
// import { useGetDeviceControlDCCount } from "../../api/queryHooks";
import { useState } from "react";
import DiscoveredDevices from "./DiscoveredDevices";
import ConfiguredDevices from "./ConfiguredDevices";
import Header from "./Header";
import { DeviceStatusChanged } from "../../components";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../api/queryKeys";

// const DeviceTabBtn = ({ isActive = false, title, count, ...props }) => {
//   return (
//     <button
//       type="button"
//       className={`h-[50px] rounded-t-lg px-[15px] py-[8px] flex items-center gap-[20px] ${
//         isActive ? "bg-[#E6F0FC] border-b border-[#227EEB]" : "bg-[#ffffff]"
//       }`}
//       {...props}
//     >
//       <span
//         className={`text-base ${
//           isActive ? "text-[#227EEB]" : "text-[#222222]"
//         } font-semibold`}
//       >
//         {title}
//       </span>
//       <span
//         className={`rounded-[5px] min-w-[30px] ${
//           isActive
//             ? "bg-[#FFFFFF] text-[#227EEB]"
//             : "bg-[#E6F0FC] text-[#222222]"
//         } text-base font-semibold p-[5px]`}
//       >
//         {count}
//       </span>
//     </button>
//   );
// };

function DeviceContent({ search, onSearchChange }) {
  // const { data } = useGetDeviceControlDCCount();
  const queryClient = useQueryClient();
  const [selectedDevice, setSelectedDevice] = useState("");
  
  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DISCOVERY_DEVICES],
      exact: false,
    });

    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.CONFIGURED_DEVICES],
      exact: false,
    });
  };

  const handleDeviceChange = (deviceId) => {
    setSelectedDevice(deviceId);
  };

  return (
    <div>
      <DeviceStatusChanged callback={realTimeChangeCallback} />
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header 
          onSearchChange={onSearchChange} 
          selectedDevice={selectedDevice}
          onDeviceChange={handleDeviceChange}
        />
        <div className="flex items-center justify-between">
          <h2 className="text-[#222222] text-[14px] font-semibold">
            Discovered Devices
          </h2>
        </div>
        <DiscoveredDevices search={search} deviceFilter={selectedDevice} />
      </div>
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mt-5">
        <div className="flex items-center justify-between">
          <h2 className="text-[#222222] text-[14px] font-semibold">
            Configured Devices
          </h2>
        </div>
        <ConfiguredDevices search={search} deviceFilter={selectedDevice} />
      </div>
    </div>
  );
}

export default DeviceContent;
