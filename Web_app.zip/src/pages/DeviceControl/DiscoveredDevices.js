import { useState } from "react";
import { DeviceCard, DevicesAccordian, SpinnerV1 } from "../../components";
import ConfigureDeviceModal from "./ConfigureDeviceModal";
import { useGetDiscoveryDevices } from "../../api/queryHooks";
import useUserStore from "../../store/useUserStore";

function DiscoveredDevices({ search, deviceFilter }) {
  const userPermissions = useUserStore((state) => state.permissions);
  const { data, isLoading, error } = useGetDiscoveryDevices(search, deviceFilter);
  const [configureDeviceModalDetails, setConfigureDeviceModalDetails] =
    useState(null);

  const own_devices = data?.data?.own_devices || [];
  const third_party_devices = data?.data?.third_party_devices || [];

  if (isLoading)
    return (
      <div className="p-5">
        <SpinnerV1 />
      </div>
    );
  if (error) return <div>Error loading devices</div>;

  return (
    <>
      <ConfigureDeviceModal
        configureDeviceModalDetails={configureDeviceModalDetails}
        onClose={() => setConfigureDeviceModalDetails(null)}
      />

      {own_devices.length === 0 && third_party_devices.length === 0 ? (
        <div className="text-center p-5 text-xs">No devices found</div>
      ) : null}

      {own_devices.length === 0 ? null : ( // <div className="text-center p-5 text-xs">No devices found</div>
        <div className="grid grid-cols-2 820:grid-cols-3 gap-[15px] mt-[20px]">
          {own_devices.map((device) => (
            <DeviceCard
              key={device.device_id}
              title={device.device_name}
              type={device.device_type}
              canControl={
                userPermissions?.DEVICE_MANAGEMENT?.device_control?.addModify
              }
              onConfigureClick={() => setConfigureDeviceModalDetails(device)}
            />
          ))}
        </div>
      )}

      {third_party_devices.length === 0 ? null : ( // <div className="text-center p-5 text-xs">No devices found</div>
        <div className={`grid grid-cols-2 820:grid-cols-3 gap-[15px] ${own_devices.length ? "mt-[15px]" : ""}`}>
          {third_party_devices.map((device) => (
            <DeviceCard
              key={device.device_id}
              title={device.device_name}
              type={device.device_type}
              onConfigureClick={() => setConfigureDeviceModalDetails(device)}
              canControl={
                userPermissions?.DEVICE_MANAGEMENT?.device_control?.addModify
              }
            />
          ))}
        </div>
      )}
    </>
  );
}

export default DiscoveredDevices;
