import { useState, useEffect } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  BottomRightModal,
  BottomRightModalHeader,
  PrimaryDropdown,
  MultiSelectDropdown,
  PrimaryBtn2,
  PrimaryInput,
  RadioGroup,
  SecondaryBtnLink,
  SpinnerV1,
  RangeSlider,
  Checkbox,
} from "../../components";
import { AddSvg, CircleInfoSvg, InvertSvg, LEDSvg, LEDonSvg } from "../../assets/svg";
import { CurtainSvg } from "../../components";
import {
  useGetAllGroupOptions,
  useGetConfiguredDevicesOptions,
  useGetGroupDetails,
  useGetMultipleGroupDetails,
  useGetDeviceSceneDetails,
  useGetDeviceChannelsForGroup,
  useCreateScene,
} from "../../api/queryHooks";
import ShadeImage from "../../assets/images/Shade.png";
import toaster from "../../utils/toaster";
import { percentToNumber } from "../../utils/helpers";

const validationSchema = Yup.object({
  sceneName: Yup.string().required("Scene name is required"),
  selectionType: Yup.string().required(),
  selectedGroups: Yup.array().when("selectionType", {
    is: "group",
    then: (schema) =>
      schema
        .min(1, "At least one group must be selected")
        .required("Groups are required"),
    otherwise: (schema) => schema.notRequired(),
  }),
  selectedDevices: Yup.array().when("selectionType", {
    is: "device",
    then: (schema) =>
      schema
        .min(1, "At least one device must be selected")
        .required("Devices are required"),
    otherwise: (schema) => schema.notRequired(),
  }),
});

const Channel = ({ data, deviceId, groupId, formik }) => {
  const radioOptions = [
    { value: "on", label: "On" },
    { value: "off", label: "Off" },
  ];

  // Use group-based or device-based structure depending on groupId
  const channelState = groupId
    ? formik.values.channelStates?.[groupId]?.[deviceId]?.[data.channel_id]
    : formik.values.channelStates?.[deviceId]?.[data.channel_id];

  const isSelected = groupId
    ? formik.values.selectedChannels?.[groupId]?.[deviceId]?.[
        data.channel_id
      ] || false
    : formik.values.selectedChannels?.[deviceId]?.[data.channel_id] || false;

  const handleCheckboxChange = (checked) => {
    const fieldPath = groupId
      ? `selectedChannels.${groupId}.${deviceId}.${data.channel_id}`
      : `selectedChannels.${deviceId}.${data.channel_id}`;

    formik.setFieldValue(fieldPath, checked);
  };

  const handleRadioChange = (value) => {
    const command =
      data.channel_type === "shade"
        ? value === "on"
          ? "open"
          : "close"
        : value;

    const fieldPath = groupId
      ? `channelStates.${groupId}.${deviceId}.${data.channel_id}`
      : `channelStates.${deviceId}.${data.channel_id}`;

    formik.setFieldValue(fieldPath, {
      type: data.channel_type,
      command: command,
      ...(data.channel_type === "led" && { brightness: 100 }),
      // ...(data.channel_type === "shade" && {
      //   openLevel: value === "on" ? 100 : 0,
      // }),
    });
  };

  const handleSliderChange = (value) => {
    const key = data.channel_type === "led" ? "brightness" : "openLevel";
    const fieldPath = groupId
      ? `channelStates.${groupId}.${deviceId}.${data.channel_id}.${key}`
      : `channelStates.${deviceId}.${data.channel_id}.${key}`;

    formik.setFieldValue(fieldPath, value);
  };

  if (data?.channel_type === "sensor") return null;

  const currentValue =
    channelState?.command === "open"
      ? "on"
      : channelState?.command === "close"
      ? "off"
      : channelState?.command || "off";

  // Determine if channel is in "on" state
  const isChannelOn = currentValue === "on";

  // Get current value for slider
  const sliderValue = isChannelOn
    ? data?.channel_type === "led"
      ? channelState?.brightness || 0
      : data?.channel_type === "shade"
      ? percentToNumber(channelState?.openLevel) || 0
      : 0
    : 0;
  // Check if scene is inverted
  const isInverted = formik.values.invertScene;

  // Calculate display values (inverted if needed)
  const displayValue = isInverted ? 100 - sliderValue : sliderValue;
  const displayIsOn = isInverted ? !isChannelOn : isChannelOn;

  return (
    <div title={data.channel_name} className="flex items-start gap-5 mb-3">
      <div className="text-[#7A838E] text-xs truncate flex items-center gap-2 w-[120px]">
        <Checkbox checked={isSelected} onCheckedChange={handleCheckboxChange} />
        <p className="truncate">{data.channel_name}</p>
      </div>
      <div className="flex items-center gap-2">
        <RadioGroup
          options={radioOptions}
          className="flex items-center gap-2"
          value={currentValue}
          onValueChange={handleRadioChange}
        />
      </div>
      <div>
        {(data?.channel_type === "led") ? (
        // {(data?.channel_type === "led" || data?.channel_type === "shade") && (
          <div className="flex items-center gap-2">
            <span className="w-[150px]">
              <RangeSlider
                min={0}
                max={100}
                value={sliderValue}
                onChange={handleSliderChange}
                disabled={!isChannelOn}
              />
            </span>
            <span className="text-[10px] text-[#7A838E] w-[26px]">
              {sliderValue}%
            </span>
          </div>
        ): <div className="w-[186px]"></div>}
      </div>
      <div className="w-[108px] flex-shrink-0 flex items-center justify-evenly gap-3">
        <div>
          {data?.channel_type === "led" ? (
            isChannelOn ? (
              <LEDonSvg className="w-[16px] h-[16px] flex-shrink-0" />
            ) : (
              <LEDSvg className="w-[16px] h-[16px] flex-shrink-0" />
            )
          ) : data?.channel_type === "shade" ? (
            <CurtainSvg
              openValue={isChannelOn ? 100 : 0}
              className="w-[16px] h-[16px] flex-shrink-0"
            />
          ) : null}
        </div>
        <div className={`${isInverted ? "": "opacity-0"}`}>
          <InvertSvg className="fill-[#939ca7]" />
        </div>
        <div className={`${isInverted ? "": "opacity-0"}`}>
          {data?.channel_type === "led" ? (
            displayIsOn ? (
              <LEDonSvg className="w-[16px] h-[16px] flex-shrink-0" />
            ) : (
              <LEDSvg className="w-[16px] h-[16px] flex-shrink-0" />
            )
          ) : data?.channel_type === "shade" ? (
            <CurtainSvg
              openValue={!isChannelOn ? 100 : 0}
              className="w-[16px] h-[16px] flex-shrink-0"
            />
          ) : null}
        </div>
      </div>
    </div>
  );
};

const ChannelSelector = ({ data, type, groupId, formik }) => {
  return (
    <div
      key={data.device_id}
      className="my-[15px] border-b last:border-0 border-[#dddddd] px-5"
    >
      <div className="mb-[10px] flex items-center justify-between">
        <div className="text-[#222222] text-xs w-[120px] truncate flex-shrink-0">
          {data.device_id}
        </div>
        <div className="flex items-center justify-between w-[108px] text-xs text-[#AAAAAA] font-medium">
          <span>Action</span>
          <span className={`${formik.values.invertScene ? "" : "hidden"}`}>
            Invert
          </span>
        </div>
      </div>
      <div className="flex-grow">
        {data?.channels?.map((channel) => (
          <Channel
            key={channel.channel_id}
            data={channel}
            deviceId={data.device_id}
            groupId={groupId}
            formik={formik}
          />
        ))}
      </div>
    </div>
  );
};

function SceneForm({ onClose }) {
  const [selectedGroupIds, setSelectedGroupIds] = useState([]);
  const [selectedDeviceIds, setSelectedDeviceIds] = useState([]);

  const { data: groupOptions = [], isLoading: loadingGroups } =
    useGetAllGroupOptions();
  const { data: deviceOptions = [], isLoading: loadingDevices } =
    useGetConfiguredDevicesOptions();
  const { data: groupDetails, isLoading: loadingGroupDetails } =
    useGetMultipleGroupDetails(selectedGroupIds);
  const { data: deviceDetails, isLoading: loadingDeviceDetails } =
    useGetDeviceChannelsForGroup(selectedDeviceIds);

  const { mutate: createScene, isLoading: isCreating } = useCreateScene({
    onSuccess: () => {
      toaster.success("Scene created successfully");
      onClose();
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || "Failed to create scene");
    },
  });

  // Initialize default channel states when group details are loaded
  useEffect(() => {
    const groupsData = groupDetails?.data || groupDetails; // Handle both structures

    if (
      groupsData &&
      Array.isArray(groupsData) &&
      groupsData.length > 0 &&
      formik.values.selectionType === "group"
    ) {
      const defaultChannelStates = {};
      const defaultSelectedChannels = {};

      groupsData.forEach((groupData) => {
        if (groupData.success && groupData.data?.devices) {
          const groupId = groupData.groupId || groupData.data?.group_id;
          defaultChannelStates[groupId] = {};
          defaultSelectedChannels[groupId] = {};

          groupData.data.devices.forEach((device) => {
            defaultChannelStates[groupId][device.device_id] = {};
            defaultSelectedChannels[groupId][device.device_id] = {};
            device.channels?.forEach((channel) => {
              if (channel.channel_type !== "sensor") {
                defaultChannelStates[groupId][device.device_id][
                  channel.channel_id
                ] = {
                  type: channel.channel_type,
                  command: channel.channel_type === "shade" ? "close" : "off",
                  ...(channel.channel_type === "led" && { brightness: 0 }),
                  // ...(channel.channel_type === "shade" && { openLevel: "0%" }),
                };
                defaultSelectedChannels[groupId][device.device_id][
                  channel.channel_id
                ] = false;
              }
            });
          });
        }
      });
      formik.setFieldValue("channelStates", defaultChannelStates);
      formik.setFieldValue("selectedChannels", defaultSelectedChannels);
    }
  }, [groupDetails]);

  // Initialize default channel states when device details are loaded
  useEffect(() => {
    if (deviceDetails?.length && formik.values.selectionType === "device") {
      const defaultChannelStates = {};
      const defaultSelectedChannels = {};

      deviceDetails.forEach((deviceData) => {
        const device = deviceData;
        defaultChannelStates[device.device_id] = {};
        defaultSelectedChannels[device.device_id] = {};

        device.channels?.forEach((channel) => {
          if (channel.type !== "sensor") {
            defaultChannelStates[device.device_id][channel.channelId] = {
              type: channel.type,
              command: channel.type === "shade" ? "close" : "off",
              ...(channel.type === "led" && { brightness: 0 }),
              // ...(channel.type === "shade" && { openLevel: "0%" }),
            };
            defaultSelectedChannels[device.device_id][
              channel.channelId
            ] = false;
          }
        });
      });
      formik.setFieldValue("channelStates", defaultChannelStates);
      formik.setFieldValue("selectedChannels", defaultSelectedChannels);
    }
  }, [deviceDetails]);

  const formik = useFormik({
    initialValues: {
      sceneName: "",
      selectionType: "group",
      selectedGroups: [],
      selectedDevices: [],
      channelStates: {},
      selectedChannels: {},
      invertScene: false,
    },
    validationSchema,
    onSubmit: (values) => {
      if (values.selectionType === "group") {
        const groupsData = groupDetails?.data || groupDetails; // Handle both structures

        // Process each group individually to maintain group-specific channel selections
        const groupedDevices = [];

        if (groupsData && Array.isArray(groupsData)) {
          groupsData.forEach((groupData) => {
            if (groupData.success && groupData.data?.devices) {
              const groupId = groupData.groupId || groupData.data?.group_id;
              const groupDevices = [];

              groupData.data.devices.forEach((device) => {
                const deviceChannels = [];

                // Get all channels for this device in this specific group
                device.channels?.forEach((channel) => {
                  const channelId = channel.channel_id;
                  const isChannelSelected =
                    values.selectedChannels[groupId]?.[device.device_id]?.[
                      channelId
                    ];

                  if (isChannelSelected && channel.channel_type !== "sensor") {
                    const state =
                      values.channelStates[groupId]?.[device.device_id]?.[
                        channelId
                      ];
                    if (state) {
                      deviceChannels.push({
                        channelType: state.type,
                        channelId: channelId,
                        command: state.command,
                        ...(state.type === "led" && {
                          brightness: state.brightness,
                        }),
                        // ...(state.type === "shade" && {
                        //   openLevel: `${percentToNumber(state.openLevel)}%`,
                        // }),
                      });
                    }
                  }
                });

                // Only include device if it has selected channels
                if (deviceChannels.length > 0) {
                  groupDevices.push({
                    deviceId: device.device_id,
                    channels: deviceChannels,
                  });
                }
              });

              // Only include group if it has devices with selected channels
              if (groupDevices.length > 0) {
                groupedDevices.push({
                  groupId: groupId,
                  devices: groupDevices,
                });
              }
            }
          });
        }

        const payload = {
          name: values.sceneName,
          type: "group",
          Groups: groupedDevices,
          lastExecuted: null,
          executedBy: null,
          operateType: values.invertScene ? "invert" : "normal",
        };

        createScene(payload);
      } else {
        const devices = deviceDetails || [];
        const formattedDevices = devices
          .map((deviceData) => {
            const device = deviceData;
            const selectedChannelIds = Object.entries(
              values.selectedChannels[device.device_id] || {}
            )
              .filter(([_, isSelected]) => isSelected)
              .map(([channelId]) => channelId);

            const channels = selectedChannelIds
              .map((channelId) => {
                const state =
                  values.channelStates[device.device_id]?.[channelId];
                if (state) {
                  return {
                    channelType: state.type,
                    channelId: channelId,
                    command: state.command,
                    ...(state.type === "led" && {
                      brightness: state.brightness,
                    }),
                    // ...(state.type === "shade" && {
                    //   openLevel: `${percentToNumber(state.openLevel)}%`,
                    // }),
                  };
                }
                return null;
              })
              .filter(Boolean);

            return {
              deviceId: device.device_id,
              channels: channels,
            };
          })
          .filter((device) => device.channels.length > 0);

        const payload = {
          name: values.sceneName,
          type: "device",
          Devices: formattedDevices,
          lastExecuted: null,
          executedBy: null,
          operateType: values.invertScene ? "invert" : "normal",
        };
        createScene(payload);
      }
    },
  });

  const radioOptions = [
    { value: "group", label: "Groups" },
    { value: "device", label: "Devices" },
  ];

  const handleSelectionTypeChange = (value) => {
    formik.setFieldValue("selectionType", value);
    formik.setFieldValue("selectedGroups", []);
    formik.setFieldValue("selectedDevices", []);
    formik.setFieldValue("channelStates", {});
    formik.setFieldValue("selectedChannels", {});
    setSelectedGroupIds([]);
    setSelectedDeviceIds([]);
  };

  // Check if any channels are selected
  const hasSelectedChannels = () => {
    const selectedChannels = formik.values.selectedChannels;

    if (formik.values.selectionType === "group") {
      // For groups, check group-based structure
      for (const groupId in selectedChannels) {
        for (const deviceId in selectedChannels[groupId]) {
          for (const channelId in selectedChannels[groupId][deviceId]) {
            if (selectedChannels[groupId][deviceId][channelId]) {
              return true;
            }
          }
        }
      }
    } else {
      // For devices, check device-based structure
      for (const deviceId in selectedChannels) {
        for (const channelId in selectedChannels[deviceId]) {
          if (selectedChannels[deviceId][channelId]) {
            return true;
          }
        }
      }
    }
    return false;
  };

  return (
    <form
      className="flex-grow flex flex-col justify-between min-h-0"
      onSubmit={formik.handleSubmit}
    >
      <div className="flex items-center justify-between px-5 mb-5">
        <label htmlFor="sceneName" className="text-[#222222] text-[12px]">
          Scene Name:
        </label>
        <div className="w-[360px]">
          <PrimaryInput
            name="sceneName"
            placeholder="Enter Scene name"
            className="w-full"
            value={formik.values.sceneName}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {formik.touched.sceneName && formik.errors.sceneName && (
            <span className="text-red-500 text-xs mt-1">
              {formik.errors.sceneName}
            </span>
          )}
        </div>
      </div>

      <div className="flex items-center justify-between px-5 mb-5">
        <label className="text-[#222222] text-[12px]">Choose:</label>
        <div className="w-[360px]">
          <RadioGroup
            name="selectionType"
            options={radioOptions}
            value={formik.values.selectionType}
            className="flex items-center gap-10"
            onValueChange={handleSelectionTypeChange}
          />
        </div>
      </div>

      <div className="px-5 pb-5 mb-5 border-b border-[#DDDDDD]">
        <div className="flex items-center justify-between w-full mb-5">
          <label className="text-[#222222] text-[12px]">
            Select{" "}
            {formik.values.selectionType === "group" ? "Groups" : "Devices"}:
          </label>
          <div className="w-[360px]">
            {formik.values.selectionType === "group" ? (
              <MultiSelectDropdown
                options={groupOptions}
                placeholder={
                  loadingGroups ? "Loading groups..." : "Select groups..."
                }
                value={formik.values.selectedGroups}
                onValueChange={(groups) => {
                  formik.setFieldValue("selectedGroups", groups);
                  formik.setFieldValue("channelStates", {});
                  formik.setFieldValue("selectedChannels", {});
                  setSelectedGroupIds(groups);
                  setSelectedDeviceIds([]);
                }}
                className="w-full"
              />
            ) : (
              <MultiSelectDropdown
                options={deviceOptions}
                placeholder={
                  loadingDevices ? "Loading devices..." : "Select devices..."
                }
                value={formik.values.selectedDevices}
                onValueChange={(devices) => {
                  formik.setFieldValue("selectedDevices", devices);
                  formik.setFieldValue("channelStates", {});
                  formik.setFieldValue("selectedChannels", {});
                  setSelectedDeviceIds(devices);
                  setSelectedGroupIds([]);
                }}
                className="w-full"
              />
            )}
            {formik.values.selectionType === "group" &&
              formik.touched.selectedGroups &&
              formik.errors.selectedGroups && (
                <span className="text-red-500 text-xs mt-1">
                  {formik.errors.selectedGroups}
                </span>
              )}
            {formik.values.selectionType === "device" &&
              formik.touched.selectedDevices &&
              formik.errors.selectedDevices && (
                <span className="text-red-500 text-xs mt-1">
                  {formik.errors.selectedDevices}
                </span>
              )}
          </div>
        </div>

        <div className="flex items-center justify-between w-full">
          <label className="text-[#222222] text-[12px]">Operate Type:</label>
          <div className="w-[360px]">
            <div className="flex items-center gap-2">
              <Checkbox
                checked={formik.values.invertScene || false}
                onCheckedChange={(checked) =>
                  formik.setFieldValue("invertScene", checked)
                }
              />
              <span className="text-[#222222] text-[12px]">Invert Scene</span>
            </div>
          </div>
        </div>
      </div>

      {(loadingGroupDetails || loadingDeviceDetails) && (
        <div className="px-5 py-3">
          <SpinnerV1 />
        </div>
      )}
      <div className="flex-grow overflow-auto">
        {(groupDetails || deviceDetails) && (
          <>
            <div className="flex items-center justify-between mb-3 px-5">
              <h3 className="text-[#222222] text-xs font-semibold">
                Configure Channels
              </h3>
              <div className="text-[#F29F1A] text-[10px]">
                <CircleInfoSvg className="inline-block w-4 h-4 mr-1" />
                <span>Active channels available</span>
              </div>
            </div>
            {groupDetails && (groupDetails?.data || Array.isArray(groupDetails))
              ? (groupDetails?.data || groupDetails).map((groupData) => {
                  if (!groupData.success || !groupData.data?.devices)
                    return null;

                  const groupId = groupData.groupId || groupData.data?.group_id;

                  return (
                    <div key={groupId} className="mb-6">
                      {/* Group Name Header */}
                      <div className="px-5 pb-1 mt-3 border-b border-[#dddddd]">
                        <div className="text-[#333333] text-xs font-semibold">
                          {groupData.data?.group_name || `Group ${groupId}`}
                        </div>
                      </div>

                      {/* Devices in this group */}
                      {groupData.data.devices.map((device) => (
                        <>
                        {/* <div className="grid grid-cols-2 gap-x-2 gap-y-[10px] px-5 mt-2">
                          <h3 className="text-[#7A838E] text-xs truncate" title={device?.location?.campus?.name || "N/A"}>Campus: {device?.location?.campus?.name || "N/A"}</h3>
                          <h3 className="text-[#7A838E] text-xs truncate" title={device?.location?.building?.name || "N/A"}>Building: {device?.location?.building?.name || "N/A"}</h3>
                          <h3 className="text-[#7A838E] text-xs truncate" title={device?.location?.floor?.name || "N/A"}>Floor: {device?.location?.floor?.name || "N/A"}</h3>
                          <h3 className="text-[#7A838E] text-xs truncate" title={device?.location?.zone?.name || "N/A"}>Zone: {device?.location?.zone?.name || "N/A"}</h3>
                        </div> */}
                        <ChannelSelector
                          key={`${groupId}-${device.device_id}`}
                          data={device}
                          type="group"
                          groupId={groupId}
                          formik={formik}
                        />
                        </>
                      ))}
                    </div>
                  );
                })
              : deviceDetails?.map((deviceData) => {
                  const deviceWithChannels = {
                    ...deviceData,
                    channels: deviceData.channels?.map((channel) => ({
                      channel_id: channel.channelId,
                      channel_name: channel.name,
                      channel_type: channel.type,
                      ...channel,
                    })),
                  };
                  return (
                    <>
                    <div className="grid grid-cols-2 gap-x-2 gap-y-[10px] px-5 mt-2">
                          <h3 className="text-[#7A838E] text-xs truncate" title={deviceData?.location?.campus?.name || "N/A"}>Campus: {deviceData?.location?.campus?.name || "N/A"}</h3>
                          <h3 className="text-[#7A838E] text-xs truncate" title={deviceData?.location?.building?.name || "N/A"}>Building: {deviceData?.location?.building?.name || "N/A"}</h3>
                          <h3 className="text-[#7A838E] text-xs truncate" title={deviceData?.location?.floor?.name || "N/A"}>Floor: {deviceData?.location?.floor?.name || "N/A"}</h3>
                          <h3 className="text-[#7A838E] text-xs truncate" title={deviceData?.location?.zone?.name || "N/A"}>Zone: {deviceData?.location?.zone?.name || "N/A"}</h3>
                        </div>
                    <ChannelSelector
                      key={deviceData.device_id}
                      data={deviceWithChannels}
                      type="device"
                      groupId={null}
                      formik={formik}
                    />
                    </>
                  );
                })}
          </>
        )}
      </div>

      <div className="p-5 flex justify-end border-t border-[#DDDDDD]">
        <PrimaryBtn2
          type="submit"
          className="min-w-20 justify-center"
          disabled={isCreating || !hasSelectedChannels()}
        >
          {isCreating ? "CREATING..." : "CREATE"}
        </PrimaryBtn2>
      </div>
    </form>
  );
}

function AddNewSceneModal() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = (value) => {
    setIsOpen(value);
  };

  return (
    <>
      <SecondaryBtnLink
        onClick={() => toggleModal(true)}
        className={"w-[135px] justify-center"}
        Icon={AddSvg}
      >
        NEW SCENE
      </SecondaryBtnLink>
      {isOpen ? (
        <BottomRightModal
          toggleModal={toggleModal}
          className="max-h-[calc(100vh-56px)] h-full w-full max-w-[590px] flex flex-col"
        >
          <BottomRightModalHeader
            toggleModal={toggleModal}
            title="Add New Scene"
          />
          <SceneForm onClose={() => toggleModal(false)} />
        </BottomRightModal>
      ) : null}
    </>
  );
}

export default AddNewSceneModal;
