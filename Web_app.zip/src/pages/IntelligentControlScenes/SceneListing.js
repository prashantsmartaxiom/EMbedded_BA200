import { useState } from "react";
import { DeviceStatusChanged, LoadMoreDataBtn, SceneCard, SpinnerV1 } from "../../components";
import { useGetScenes } from "../../api/queryHooks";
import DeleteScenePopup from "./DeleteScenePopup";
import EditSceneModal from "./EditSceneModal";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../api/queryKeys";

function Header() {
  return (
    <div className="flex items-center justify-between">
      <h2 className="text-[#222222] text-[14px] font-semibold">
        Manage Scenes
      </h2>
    </div>
  );
}

function List({
  scenes,
  isLoading,
  onEdit,
  onDelete,
  onExecute,
  onLoadMore,
  hasNextPage,
  isFetchingNextPage,
}) {
  if (isLoading) {
    return (
      <div className="mt-[15px] flex justify-center items-center py-10">
        <SpinnerV1 />
      </div>
    );
  }

  if (!scenes?.length) {
    return (
      <div className="mt-[15px] flex justify-center items-center py-10">
        <div className="text-[#7A838E]">No scenes found</div>
      </div>
    );
  }

  return (
    <div className="mt-[15px]">
      <div className="grid grid-cols-2 gap-[15px]">
        {scenes.map((scene) => (
          <SceneCard
            key={scene._id}
            scene={scene}
            onEdit={onEdit}
            onDelete={onDelete}
            onExecute={onExecute}
          />
        ))}
      </div>

      {hasNextPage && (
        <div className="flex justify-center mt-8">
          <LoadMoreDataBtn onClick={onLoadMore} disabled={isFetchingNextPage} />
        </div>
      )}
    </div>
  );
}

function SceneListing({ search }) {
  const queryClient = useQueryClient();
  const [deleteModal, setDeleteModal] = useState({ isOpen: false, sceneId: null });
  const [editModal, setEditModal] = useState({ isOpen: false, sceneId: null });
  const [key, setKey] = useState(0);
  const { data, isLoading, fetchNextPage, hasNextPage, isFetchingNextPage } =
    useGetScenes({ search: search });

  // Flatten the pages data
  const scenes = data?.pages?.flatMap((page) => page?.data?.scenes || []) || [];

  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.SCENES],
      exact: false,
    });
    setKey(prev => prev + 1)
    // alert("here")
  };

  const handleEdit = (scene) => {
    setEditModal({ isOpen: true, sceneId: scene._id });
  };

  const handleDelete = (scene) => {
    setDeleteModal({ isOpen: true, sceneId: scene._id });
  };

  const handleExecute = (scene) => {
    // TODO: Implement execute functionality
  };

  const handleLoadMore = () => {
    if (hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  };

  const handleDeleteSuccess = () => {
    // refetch();
  };

  const handleEditSuccess = () => {
    // The query will be invalidated automatically by the mutation
  };

  return (
    <div>
      <DeviceStatusChanged callback={realTimeChangeCallback} />
      <Header />
      <List
        key={key}
        scenes={scenes}
        isLoading={isLoading}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onExecute={handleExecute}
        onLoadMore={handleLoadMore}
        hasNextPage={hasNextPage}
        isFetchingNextPage={isFetchingNextPage}
      />
      
      <DeleteScenePopup
        isOpen={deleteModal.isOpen}
        toggleModal={(value) => setDeleteModal({ isOpen: value, sceneId: null })}
        sceneId={deleteModal.sceneId}
        onSuccess={handleDeleteSuccess}
      />

      <EditSceneModal
        isOpen={editModal.isOpen}
        sceneId={editModal.sceneId}
        onClose={() => setEditModal({ isOpen: false, sceneId: null })}
      />
    </div>
  );
}

export default SceneListing;
