import { WarningSvg } from "../../assets/svg";
import { SecondaryBtn } from "../../components";
import { CenterModal } from "../../components/Models";
import { useDeleteScene } from "../../api/queryHooks";
import toaster from "../../utils/toaster";

function DeleteScenePopup({
  isOpen,
  toggleModal,
  sceneId,
  onSuccess,
}) {
  const { mutate: deleteScene, isLoading } = useDeleteScene({
    onSuccess: () => {
      toaster.success("Scene deleted successfully");
      toggleModal(false);
      onSuccess?.();
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || `Error deleting scene`);
    },
  });

  const handleDelete = () => {
    deleteScene(sceneId);
  };

  if (!isOpen) return null;

  return (
    <CenterModal
      toggleModal={() => toggleModal(false)}
      className="max-w-[460px] w-full p-8 flex flex-col items-center gap-6"
    >
      <div>
        <WarningSvg className="text-[54px] text-[#FF1212]" />
      </div>
      <div className="text-center">
        <h3 className="text-base font-semibold">Are you sure?</h3>
        <p className="text-sm text-[#939CA7] mt-3">
          Do you really want to delete the scene?
          <br />
          This process cannot be undone.
        </p>
      </div>

      <div className="flex items-center gap-[10px]">
        <SecondaryBtn
          onClick={() => toggleModal(false)}
          disabled={isLoading}
          className={
            "justify-center !bg-[#AAAAAA] !border-none !text-white min-w-20"
          }
        >
          CANCEL
        </SecondaryBtn>
        <SecondaryBtn
          onClick={handleDelete}
          disabled={isLoading}
          className={
            "justify-center !bg-[#FF1212] !border-none !text-white min-w-20"
          }
        >
          {isLoading ? "DELETING..." : "DELETE"}
        </SecondaryBtn>
      </div>
    </CenterModal>
  );
}

export default DeleteScenePopup;
