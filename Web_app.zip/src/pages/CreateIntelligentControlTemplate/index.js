import { useState, useRef } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { ROUTES } from "../../router";
import Header from "./Header";
import {
  CurtainSvg,
  PermissionDenied,
  RangeSlider,
  SearchInput,
} from "../../components";
import {
  CircleCrossSvg,
  LEDonSvg,
  LEDSvg,
  MdArrowDownSvg,
  MoveSvg,
  SceneSvg,
  ShadeSSSvg,
  ShadeTTSvg,
  StopSvg,
} from "../../assets/svg";
import ShadeImage from "../../assets/images/Shade.png";
import {
  useGetAllDevices,
  useCreateTemplate,
  useGetCreatedWidgets,
} from "../../api/queryHooks";
import useUserStore from "../../store/useUserStore";
import WidgetTemplateCard from "./WidgetTemplateCard";
import SceneTemplateCard from "../ControlSystem/SceneTemplateCard";
import GroupTemplateCard from "../ControlSystem/GroupTemplateCard";
import {
  MiniLandscapeLayout,
  MiniPortraitLayout,
} from "../../components/shared/MiniWidgetLayouts";
import { getWidgetLayout } from "../../utils/helpers";
import {
  LandscapeLayout,
  PortraitLayout,
} from "../CreateWidget/WidgetVisualizer";

const ShadeCard = ({ channel, handleDragStart, handleDragEnd, disabled }) => {
  return (
    <div
      title={channel?.name}
      draggable={!disabled}
      onDragStart={(e) => {
        if (disabled) {
          e.preventDefault();
          return;
        }
        handleDragStart(e, channel);
      }}
      onDragEnd={handleDragEnd}
      className={`flex flex-col gap-1 items-center w-[54px] flex-shrink-0 ${
        disabled ? "!opacity-50 cursor-not-allowed" : ""
      }`}
    >
      <div>
        <img
          src={ShadeImage}
          alt={"ShadeImage"}
          className="w-6 h-w-6 pointer-events-none"
        />
      </div>
      <div className="text-center w-full">
        <p className="text-[#7A838E] text-[10px] truncate w-full">
          {channel.name}
        </p>
      </div>
    </div>
  );
};

const LEDCard = ({ channel, handleDragStart, handleDragEnd, disabled }) => {
  return (
    <div
      title={channel?.name}
      draggable={!disabled}
      onDragStart={(e) => {
        if (disabled) {
          e.preventDefault();
          return;
        }
        handleDragStart(e, channel);
      }}
      onDragEnd={handleDragEnd}
      className={`flex flex-col gap-1 items-center w-[54px] flex-shrink-0 ${
        disabled ? "!opacity-50 cursor-not-allowed" : ""
      }`}
    >
      <div>
        <LEDonSvg />
      </div>
      <div className="text-center w-full">
        <p className="text-[#7A838E] text-[10px] truncate w-full">
          {channel.name}
        </p>
      </div>
    </div>
  );
};

const Channel = ({ channel, handleDragStart, handleDragEnd, disabled }) => {
  if (channel.type === "led")
    return (
      <LEDCard
        channel={channel}
        handleDragStart={handleDragStart}
        handleDragEnd={handleDragEnd}
        disabled={disabled}
      />
    );
  if (channel.type === "shade")
    return (
      <ShadeCard
        channel={channel}
        handleDragStart={handleDragStart}
        handleDragEnd={handleDragEnd}
        disabled={disabled}
      />
    );
};

const HorizotaList = ({
  device,
  handleDragStart,
  handleDragEnd,
  draggedItem,
}) => {
  const scrollContainerRef = useRef(null);

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -80, behavior: "smooth" });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 80, behavior: "smooth" });
    }
  };
  return (
    <div
      key={device.id}
      className="flex items-center border border-[#C0DAF9] bg-[#F5F9FD] p-[8px] rounded-lg my-[15px]"
    >
      <div className="w-[124px] mr-1 border-r border-[#C0DAF9] flex-shrink-0">
        <div
          className="text-[12px] text-[#222222] truncate"
          title={device.device_name}
        >
          {device.device_name}
        </div>
        <div className="text-[10px] text-[#7A838E] truncate" title={device.id}>
          {device.id}
        </div>
      </div>
      <div className="relative flex-grow flex gap-2 items-center overflow-x-auto hide-scrollbar h-full">
        {/* Left scroll arrow */}
        <button
          onClick={scrollLeft}
          className="absolute left-0 z-10 bg-white/80 hover:bg-white rounded-full p-2 shadow-sm border border-[#C0DAF9] transition-all duration-200 hover:shadow-md"
          title="Scroll left"
        >
          <MdArrowDownSvg className="w-2 h-2 text-[#7A838E] rotate-90" />
        </button>

        {/* Channels container */}
        <div
          ref={scrollContainerRef}
          className="flex gap-2 items-center overflow-x-auto hide-scrollbar h-full mx-8 px-2"
        >
          {device.channels.map((channel) => (
            <Channel
              key={channel.id}
              channel={channel}
              handleDragStart={handleDragStart}
              handleDragEnd={handleDragEnd}
              disabled={
                draggedItem?.[`${channel.deviceId}_${channel.id}`]
                  ? true
                  : false
              }
            />
          ))}
        </div>

        {/* Right scroll arrow */}
        <button
          onClick={scrollRight}
          className="absolute right-0 z-10 bg-white/80 hover:bg-white rounded-full p-2 shadow-sm border border-[#C0DAF9] transition-all duration-200 hover:shadow-md"
          title="Scroll right"
        >
          <MdArrowDownSvg className="w-2 h-2 text-[#7A838E] -rotate-90" />
        </button>
      </div>
    </div>
  );
};

const DevicesList = ({ data, handleDragStart, handleDragEnd, draggedItem }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const displayData = isExpanded ? data : data.slice(0, 4);

  return (
    <div className="px-5">
      <div
        className="flex items-center text-[12px] gap-[5px] font-semibold cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        Devices
        <MdArrowDownSvg
          className={`transition-transform ${
            isExpanded ? "rotate-0" : "-rotate-90"
          }`}
        />
      </div>

      {displayData.map((device) => (
        <HorizotaList
          key={device.id}
          device={device}
          handleDragStart={handleDragStart}
          handleDragEnd={handleDragEnd}
          draggedItem={draggedItem}
        />
      ))}
    </div>
  );
};

const GroupCard = ({ group, handleDragStart, handleDragEnd, draggedItem }) => {
  const disabled = draggedItem?.[group.id];

  return (
    <div
      title={group?.group_name}
      key={group.id}
      draggable={!disabled}
      onDragStart={(e) => {
        if (disabled) {
          e.preventDefault();
          return;
        }
        handleDragStart(e, { ...group, itemType: "GROUP" });
      }}
      onDragEnd={handleDragEnd}
      className={`border border-[#C0DAF9] bg-[#F5F9FD] p-[8px] rounded-lg py-4 cursor-move ${
        disabled ? "!opacity-50 cursor-not-allowed" : ""
      }`}
    >
      <div className="text-[12px] text-[#222222]">{group?.group_name}</div>
      <div className="text-[10px] text-[#7A838E]">{group?.id}</div>
    </div>
  );
};

const GroupsList = ({ data, handleDragStart, handleDragEnd, draggedItem }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const displayData = isExpanded ? data : data?.slice(0, 4);

  return (
    <div className="px-5 mb-5">
      <div
        className="flex items-center text-[12px] gap-[5px] font-semibold cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        Groups
        <MdArrowDownSvg
          className={`transition-transform ${
            isExpanded ? "rotate-0" : "-rotate-90"
          }`}
        />
      </div>

      <div className="grid grid-cols-2 gap-5 mt-5">
        {displayData?.map((group) => (
          <GroupCard
            key={group.id}
            group={group}
            handleDragStart={handleDragStart}
            handleDragEnd={handleDragEnd}
            draggedItem={draggedItem}
          />
        ))}
      </div>
    </div>
  );
};

const SceneCard = ({ scene, handleDragStart, handleDragEnd, draggedItem }) => {
  const disabled = draggedItem?.[scene.id];

  return (
    <div
      title={scene?.scene_name}
      key={scene.id}
      draggable={!disabled}
      onDragStart={(e) => {
        if (disabled) {
          e.preventDefault();
          return;
        }
        handleDragStart(e, { ...scene, itemType: "SCENE" });
      }}
      onDragEnd={handleDragEnd}
      className={`border border-[#C0DAF9] bg-[#F5F9FD] p-[8px] rounded-lg py-4 cursor-move ${
        disabled ? "!opacity-50 cursor-not-allowed" : ""
      }`}
    >
      <div className="text-[12px] text-[#222222]">{scene?.scene_name}</div>
      <div className="text-[10px] text-[#7A838E]">{scene?.id}</div>
    </div>
  );
};

const ScenesList = ({ data, handleDragStart, handleDragEnd, draggedItem }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const displayData = isExpanded ? data : data?.slice(0, 4);

  return (
    <div className="px-5">
      <div
        className="flex items-center text-[12px] gap-[5px] font-semibold cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        Scenes
        <MdArrowDownSvg
          className={`transition-transform ${
            isExpanded ? "rotate-0" : "-rotate-90"
          }`}
        />
      </div>

      <div className="grid grid-cols-2 gap-5 mt-5">
        {displayData?.map((scene) => (
          <SceneCard
            key={scene.id}
            scene={scene}
            handleDragStart={handleDragStart}
            handleDragEnd={handleDragEnd}
            draggedItem={draggedItem}
          />
        ))}
      </div>
    </div>
  );
};

const WidgetCard = ({
  widget,
  handleDragStart,
  handleDragEnd,
  draggedItem,
  layout,
  realRow,
  realCol,
}) => {
  const disabled = draggedItem?.[widget._id];

  return (
    <div
      title={`Widget ${widget._id}`}
      key={widget._id}
      draggable={!disabled}
      onDragStart={(e) => {
        if (disabled) {
          e.preventDefault();
          return;
        }
        handleDragStart(e, { ...widget, itemType: "WIDGET" });
      }}
      onDragEnd={handleDragEnd}
      className={`cursor-move ${
        disabled ? "!opacity-50 cursor-not-allowed" : ""
      }`}
    >
      {getWidgetLayout(layout?.layout, realRow, realCol) === "landscape" ? (
        <div className="relative group flex-shrink-0 h-[272px] w-[152px] overflow-hidden">
          <div className="scale-[0.4] origin-top-left">
            <PortraitLayout
              key={widget._id}
              selectedWidgets={widget?.structure}
            />
          </div>
        </div>
      ) : (
        <div className="flex-shrink-0 relative group w-[236px] h-[136px] overflow-hidden">
          <div className="scale-[0.34] origin-top-left">
            <LandscapeLayout
              key={widget._id}
              selectedWidgets={widget?.structure}
            />
          </div>
        </div>
      )}
    </div>
  );
};

const WidgetsList = ({
  data,
  handleDragStart,
  handleDragEnd,
  draggedItem,
  layout,
  realCol,
  realRow,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const displayData = isExpanded ? data : data?.slice(0, 4);

  return (
    <div className="px-5">
      <div
        className="flex items-center text-[12px] gap-[5px] font-semibold cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        Widgets
        <MdArrowDownSvg
          className={`transition-transform ${
            isExpanded ? "rotate-0" : "-rotate-90"
          }`}
        />
      </div>

      {/* <div
        className={`grid ${
          getWidgetLayout(layout?.layout, realRow, realCol) === "landscape"
            ? "grid-cols-3"
            : "grid-cols-2"
        } gap-5 mt-5`}
      > */}
      <div className="flex flex-wrap gap-3 mt-5">
        {displayData?.map((widget) => (
          <WidgetCard
            key={widget._id}
            widget={widget}
            handleDragStart={handleDragStart}
            handleDragEnd={handleDragEnd}
            draggedItem={draggedItem}
            layout={layout}
            realRow={realRow}
            realCol={realCol}
          />
        ))}
      </div>
    </div>
  );
};

const ChannelTemplateCard = ({
  data,
  onRemove,
  onDragStart,
  onDragEnd,
  index,
  layout = "portrait",
  realRow,
  realCol,
}) => {
  // Add drag and remove controls to the template cards
  const addDragRemoveControls = (Component, componentProps) => (
    <div className="w-full h-full relative">
      <div className="absolute top-3 left-3 flex w-[calc(100%-20px)] items-center justify-between z-10">
        <div
          draggable
          onDragStart={(e) => onDragStart && onDragStart(e, data, index)}
          onDragEnd={onDragEnd}
          title="Drag to reposition"
        >
          <MoveSvg className="w-6 h-6 fill-[#7a838e]" />
        </div>
        <div onClick={() => onRemove && onRemove(index)} title="Remove">
          <CircleCrossSvg className="w-6 h-6 fill-[#7a838e]" />
        </div>
      </div>
      <Component {...componentProps} />
    </div>
  );

  // Check if it's a group
  if (data?.itemType === "GROUP" || data?.type === "group") {
    return addDragRemoveControls(GroupTemplateCard, {
      data: data,
      // Mock handlers for template creation (no actual control needed)
      onLEDToggle: () => {},
      onLEDBrightnessChange: () => {},
      onLEDBrightnessCommit: () => {},
      onShadeUp: () => {},
      onShadeDown: () => {},
      onShadeStop: () => {},
      onShade33: () => {},
      onShade66: () => {},
      channelStates: {},
      canControl: false, // Template creation mode
    });
  }

  // Check if it's a scene
  if (data?.itemType === "SCENE" || data?.type === "scene") {
    return addDragRemoveControls(SceneTemplateCard, {
      data: data,
      // Mock handlers for template creation (no actual control needed)
      onSceneExecute: () => {},
      onSceneBrightnessChange: () => {},
      onSceneBrightnessCommit: () => {},
      onLEDToggle: () => {},
      onLEDBrightnessChange: () => {},
      onLEDBrightnessCommit: () => {},
      onShadeUp: () => {},
      onShadeDown: () => {},
      onShadeStop: () => {},
      canControl: false, // Template creation mode
    });
  }

  if (data?.itemType === "WIDGET" || data?.type === "widget") {
    return (
      <WidgetTemplateCard
        data={data}
        onRemove={onRemove}
        onDragStart={onDragStart}
        onDragEnd={onDragEnd}
        index={index}
        layout={layout}
        realRow={realRow}
        realCol={realCol}
      />
    );
  }

  // For individual LED channels - use simple template for creation
  if (data?.type === "led") {
    return (
      <div className="w-full h-full flex flex-col items-center justify-center p-2 relative truncate">
        <div className="absolute top-3 left-3 flex w-[calc(100%-20px)] items-center justify-between">
          <div
            draggable
            onDragStart={(e) => onDragStart && onDragStart(e, data, index)}
            onDragEnd={onDragEnd}
            title="Drag to reposition"
          >
            <MoveSvg className="w-6 h-6 fill-[#7a838e]" />
          </div>
          <div onClick={() => onRemove && onRemove(index)} title="Remove">
            <CircleCrossSvg className="w-6 h-6 fill-[#7a838e]" />
          </div>
        </div>

        <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
          {data?.name}
        </h2>
        <div className="flex-1 flex items-center justify-center w-full h-full">
          {data?.status === "on" ? (
            <LEDonSvg className="w-[100px] h-[100px] max-w-[120px] max-h-[120px]" />
          ) : (
            <LEDSvg className="w-[100px] h-[100px] max-w-[120px] max-h-[120px]" />
          )}
        </div>
        <div className="w-full max-w-[240px]">
          <RangeSlider disabled value={data?.properties?.brightness} />
        </div>
      </div>
    );
  }

  // For individual shade channels - use simple template for creation
  if (data?.type === "shade") {
    const openLevel = parseInt(
      data.properties?.openLevel?.replace?.("%", "") || 0
    );
    return (
      <div className="w-full h-full flex flex-col items-center justify-center p-2 relative truncate">
        <div className="absolute top-3 left-3 flex w-[calc(100%-20px)] items-center justify-between">
          <div
            draggable
            onDragStart={(e) => onDragStart && onDragStart(e, data, index)}
            onDragEnd={onDragEnd}
            title="Drag to reposition"
          >
            <MoveSvg className="w-6 h-6 fill-[#7a838e]" />
          </div>
          <div onClick={() => onRemove && onRemove(index)} title="Remove">
            <CircleCrossSvg className="w-6 h-6 fill-[#7a838e]" />
          </div>
        </div>

        <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
          {data?.name}
        </h2>
        <div className="flex-1 flex items-center justify-center w-full h-full">
          <CurtainSvg
            openValue={openLevel}
            className="h-[60%] max-w-[120px] max-h-[120px]"
          />
        </div>
        <div className="w-full flex items-center justify-center">
          <div
            className="h-[30px] bg-[#F5F9FD] border border-[#CCCCCC] rounded-lg w-full max-w-32 grid text-[#222222]"
            style={{
              gridTemplateColumns:
                data?.properties?.numberOfCmds === 4
                  ? "repeat(4, 1fr)"
                  : "repeat(3, 1fr)",
            }}
          >
            <button
              className={`flex items-center justify-center hover:bg-gray-100`}
            >
              <MdArrowDownSvg className="rotate-180 w-[12px] h-[12px]" />
            </button>

            {data?.properties?.numberOfCmds === 4 ? (
              <>
                <button
                  className={`border-l border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100`}
                >
                  <ShadeSSSvg className="w-[14px] h-[14px]" />
                </button>
                <button
                  className={`border-l border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100`}
                >
                  <ShadeTTSvg className="w-[14px] h-[14px]" />
                </button>
              </>
            ) : (
              <button
                className={`border-l border-r border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100`}
              >
                <StopSvg className="w-[20px] h-[20px]" />
              </button>
            )}

            <button
              className={`${
                data?.properties?.numberOfCmds === 4
                  ? "border-l border-[#CCCCCC]"
                  : ""
              } flex items-center justify-center hover:bg-gray-100 `}
            >
              <MdArrowDownSvg className="w-[12px] h-[12px]" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full flex items-center justify-center text-gray-400">
      {"Currently not available"} {data?.type}
    </div>
  );
};

const TemplateLayoutBox = ({
  index,
  rows,
  cols,
  layout,
  handleItemDrop,
  layoutBoxItem,
  handleCardRemove,
  handleCardDragStart,
  handleCardDragEnd,
  realRow,
  realCol,
}) => {
  const item = layoutBoxItem?.[`${index}`];

  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  };

  const handleDragEnter = (e) => {
    e.preventDefault();
    e.currentTarget.classList.add("bg-blue-100", "border-blue-400");
  };

  const handleDragLeave = (e) => {
    e.currentTarget.classList.remove("bg-blue-100", "border-blue-400");
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const draggedData = e.dataTransfer.getData("text/plain");
    if (draggedData) {
      const data = JSON.parse(draggedData);
      handleItemDrop(data, index, item);
    }
    e.currentTarget.classList.remove("bg-blue-100", "border-blue-400");
  };

  return (
    <div
      onDragOver={handleDragOver}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`flex items-center justify-center text-[#939CA7] ${
        item?.type === "scene" && layout === "portrait"
          ? "min-h-[500px] min-w-[320px]"
          : item?.type === "widget" && layout === "portrait"
          ? "min-h-[380px] min-w-[320px]"
          : item?.type === "widget" && layout === "landscape"
          ? "min-w-[320px] min-h-[300px]"
          : "min-w-[320px] min-h-[300px]"
      }`}
    >
      {item ? (
        <ChannelTemplateCard
          data={item}
          onRemove={handleCardRemove}
          onDragStart={handleCardDragStart}
          onDragEnd={handleCardDragEnd}
          index={index}
          layout={layout}
          realRow={realRow}
          realCol={realCol}
        />
      ) : layout === "portrait" ? (
        `${cols}x${rows}`
      ) : (
        `${rows}x${cols}`
      )}
    </div>
  );
};

function TemplateLayout({
  layout,
  realRow,
  realCol,
  handleItemDrop,
  layoutBoxItem,
  handleCardRemove,
  handleCardDragStart,
  handleCardDragEnd,
  ...props
}) {
  const config = layout;

  if (!config) return <div>Invalid layout</div>;

  const rows = config.row;
  const cols = config.col;

  return (
    <div
      className={`cursor-pointer relative flex p-5 items-start justify-center h-full w-full`}
      {...props}
    >
      <div
        className={`grid border border-[#C0DAF9] bg-[#F5F9FD] rounded-[5px] overflow-auto hide-scrollbar
          ${
            config.layout === "portrait"
              ? "w-full h-full max-w-[554px]"
              : "w-full h-full"
          }
          ${rows > 1 ? "divide-y divide-[#C0DAF9]" : ""}
          ${cols > 1 ? "divide-x divide-[#C0DAF9]" : ""}`}
        style={{
          gridTemplateRows: `repeat(${rows}, 1fr)`,
          gridTemplateColumns: `repeat(${cols}, 1fr)`,
          aspectRatio: config.layout === "landscape" ? "16/9" : "9/16",
        }}
      >
        {Array.from({ length: rows * cols }).map((_, i) => (
          <TemplateLayoutBox
            key={i}
            index={i}
            rows={rows}
            cols={cols}
            layout={config.layout}
            handleItemDrop={handleItemDrop}
            layoutBoxItem={layoutBoxItem}
            handleCardRemove={handleCardRemove}
            handleCardDragStart={handleCardDragStart}
            handleCardDragEnd={handleCardDragEnd}
            realRow={realRow}
            realCol={realCol}
          />
        ))}
      </div>
    </div>
  );
}

function CreateIntelligentControlTemplate() {
  const userPermissions = useUserStore((state) => state.permissions);

  const location = useLocation();
  const navigate = useNavigate();
  const data = location.state;
  const [templateData] = useState(data);

  const [draggedItem, setDraggedItem] = useState({});
  const [layoutBoxItem, setLayoutBoxItem] = useState({});

  const { data: allDevices, isLoading, isError } = useGetAllDevices();
  const { data: createdWidgets, isLoading: isWidgetsLoading } =
    useGetCreatedWidgets();

  const createTemplateMutation = useCreateTemplate({
    onSuccess: (response) => {
      // Navigate to template listing page after successful creation
      navigate(ROUTES.INTELLIGENT_CONTROLS_TEMPLATE);
    },
    onError: (error) => {
      console.error("Error creating template:", error);
      // You can add error handling here
    },
  });

  const template_data = {
    scenes:
      allDevices?.data?.scenes?.map((scene) => ({
        ...scene,
        type: "scene",
        scene_name: scene.name,
        scene_id: scene.id,
        // Map scene details structure
        sceneDetails: {
          type: scene.groups?.length > 0 ? "group" : "device",
          groups:
            scene.groups?.map((group) => ({
              ...group,
              groupId: group.id,
              groupName: group.name,
              devices: group.devices?.map((device) => ({
                ...device,
                sceneChannels: device.channels?.map((channel) => ({
                  ...channel,
                  deviceId: device.id,
                  channelId: channel.id,
                  channelName: channel.name,
                  channelType: channel.type,
                })),
              })),
            })) || [],
          devices:
            scene.devices?.map((device) => ({
              ...device,
              deviceName: device.name,
              sceneChannels: device.channels?.map((channel) => ({
                ...channel,
                deviceId: device.id,
                channelId: channel.id,
                channelName: channel.name,
                channelType: channel.type,
              })),
            })) || [],
        },
      })) || [],
    groups:
      allDevices?.data?.groups?.map((group) => {
        const allChannels =
          group.devices?.flatMap((device) =>
            device.channels
              ?.filter((channel) => channel.type !== "sensor") // Filter out sensors
              .map((channel) => ({
                ...channel,
                id: channel.id,
                type: channel.type,
                name: channel.name,
                deviceId: device?.id,
                channelId: channel.id,
              }))
          ) || [];

        return {
          group_name: group.name,
          id: group.id,
          type: "group",
          elements: allChannels,
        };
      }) || [],
    devices:
      allDevices?.data?.devices?.map((device) => ({
        device_name: device.name,
        id: device.id,
        channels:
          device.channels
            ?.filter((channel) => channel.type !== "sensor") // Filter out sensors
            .map((channel) => ({
              ...channel,
              id: channel.id,
              type: channel.type,
              name: channel.name,
              deviceId: device?.id,
            })) || [],
      })) || [],
    widgets:
      createdWidgets?.data?.map((widget) => ({
        ...widget,
        type: "widget",
      })) || [],
  };

  const handleDragStart = (e, item) => {
    e.dataTransfer.setData("text/plain", JSON.stringify(item));
    e.dataTransfer.effectAllowed = "move";
    e.target.style.opacity = "0.5";
  };

  const handleDragEnd = (e) => {
    e.target.style.opacity = "1";
  };

  const handleItemDrop = (data, index, oldItem) => {
    const uniqueKey = data.deviceId
      ? `${data.deviceId}_${data.id}`
      : data._id
      ? data._id
      : data.id;

    setDraggedItem((prev) => {
      if (oldItem) {
        const oldUniqueKey = oldItem.deviceId
          ? `${oldItem.deviceId}_${oldItem.id}`
          : oldItem._id
          ? oldItem._id
          : oldItem.id;
        delete prev[oldUniqueKey];
      }
      return {
        ...prev,
        [uniqueKey]: {
          index,
          data: data,
        },
      };
    });
    setLayoutBoxItem((prev) => ({
      ...prev,
      [`${index}`]: data,
    }));
  };

  // New function to handle card removal
  const handleCardRemove = (index) => {
    const item = layoutBoxItem[`${index}`];
    if (item) {
      const uniqueKey = item.deviceId
        ? `${item.deviceId}_${item.id}`
        : item._id
        ? item._id
        : item.id;

      setDraggedItem((prev) => {
        const newDraggedItem = { ...prev };
        delete newDraggedItem[uniqueKey];
        return newDraggedItem;
      });
      setLayoutBoxItem((prev) => {
        const newLayoutBoxItem = { ...prev };
        delete newLayoutBoxItem[`${index}`];
        return newLayoutBoxItem;
      });
    }
  };

  // New function to handle card drag start for repositioning
  const handleCardDragStart = (e, data, sourceIndex) => {
    e.dataTransfer.setData(
      "text/plain",
      JSON.stringify({
        ...data,
        isRepositioning: true,
        sourceIndex,
      })
    );
    e.dataTransfer.effectAllowed = "move";
    e.target.style.opacity = "0.5";
  };

  // New function to handle card drag end
  const handleCardDragEnd = (e) => {
    e.target.style.opacity = "1";
  };

  // Modified handleItemDrop to handle repositioning
  const handleItemDropWithRepositioning = (data, targetIndex, oldItem) => {
    if (data.isRepositioning && data.sourceIndex !== undefined) {
      // This is a repositioning operation
      const sourceIndex = data.sourceIndex;
      const sourceItem = layoutBoxItem[`${sourceIndex}`];

      // Swap items if target has an item, otherwise just move
      setLayoutBoxItem((prev) => {
        const newLayout = { ...prev };

        if (oldItem) {
          // Swap
          newLayout[`${sourceIndex}`] = oldItem;
          newLayout[`${targetIndex}`] = sourceItem;

          // Update draggedItem accordingly
          const sourceUniqueKey = sourceItem.deviceId
            ? `${sourceItem.deviceId}_${sourceItem.id}`
            : sourceItem._id
            ? sourceItem._id
            : sourceItem.id;
          const oldUniqueKey = oldItem.deviceId
            ? `${oldItem.deviceId}_${oldItem.id}`
            : oldItem._id
            ? oldItem._id
            : oldItem.id;

          setDraggedItem((prevDragged) => ({
            ...prevDragged,
            [sourceUniqueKey]: { index: targetIndex, data: sourceItem },
            [oldUniqueKey]: { index: sourceIndex, data: oldItem },
          }));
        } else {
          // Just move
          delete newLayout[`${sourceIndex}`];
          newLayout[`${targetIndex}`] = sourceItem;

          // Update draggedItem
          const sourceUniqueKey = sourceItem.deviceId
            ? `${sourceItem.deviceId}_${sourceItem.id}`
            : sourceItem._id
            ? sourceItem._id
            : sourceItem.id;

          setDraggedItem((prevDragged) => ({
            ...prevDragged,
            [sourceUniqueKey]: { index: targetIndex, data: sourceItem },
          }));
        }

        return newLayout;
      });
    } else {
      // This is a new drop from the sidebar
      handleItemDrop(data, targetIndex, oldItem);
    }
  };

  const createTemplatePayload = (status = "Active") => {
    let layoutStructure = {
      rows: [],
    };

    let loopby =
      templateData?.layout?.layout === "landscape"
        ? templateData.layout.col
        : templateData.layout.row;

    for (let i = 0; i < loopby; i++) {
      const item = layoutBoxItem[i];

      if (item?.type === "group") {
        layoutStructure.rows.push({
          columns: [
            {
              id: item?.id,
              group_name: item?.group_name,
              type: item?.type,
              elements:
                item.elements?.map((channel) => {
                  return {
                    id: channel?.id,
                    name: channel?.name,
                    deviceId: channel?.deviceId,
                    type: channel?.type,
                    channelId: channel?.id,
                    status: channel?.status,
                    properties: channel?.properties,
                  };
                }) || [],
            },
          ],
        });
      } else if (item?.type === "scene") {
        layoutStructure.rows.push({
          columns: [
            {
              id: item?.id,
              scene_name: item?.name || item?.scene_name,
              type: item?.type || "scene",
              operateType: item?.operateType || "normal",
              invert_flag: item?.invert_flag || false,
              sceneDetails: item?.sceneDetails || {},
            },
          ],
        });
      } else if (item?.type === "widget" || item?.itemType === "WIDGET") {
        layoutStructure.rows.push({
          columns: [
            {
              id: item?._id || item?.id,
              type: "widget",
              widget_data: {
                _id: item?._id,
                structure: item?.structure,
              },
            },
          ],
        });
      } else if (item) {
        layoutStructure.rows.push({
          columns: [
            {
              type: item?.type,
              elements: [
                {
                  deviceId: item?.deviceId,
                  type: item?.type,
                  name: item?.name,
                  channelId: item?.id,
                  status: item?.status,
                  properties: item?.properties,
                },
              ],
            },
          ],
        });
      }
    }

    return {
      name: templateData.templateName,
      layout: templateData.layout.layout,
      status: status,
      rows: templateData.layout.row,
      columns: templateData.layout.col,
      layoutStructure: layoutStructure,
    };
  };

  const onCreateTemplateClick = () => {
    const templatePayload = createTemplatePayload("Active");
    createTemplateMutation.mutate(templatePayload);
  };

  const onSaveAsDraftClick = () => {
    const templatePayload = createTemplatePayload("Drafted");
    createTemplateMutation.mutate(templatePayload);
  };

  if (!userPermissions?.INTELLIGENT_CONTROL?.template_management?.addModify)
    return <PermissionDenied />;

  if (!templateData)
    return <Navigate to={ROUTES.INTELLIGENT_CONTROLS_TEMPLATE} />;

  if (isLoading || isWidgetsLoading) return <div>Loading...</div>;

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex flex-col">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header
          templateData={templateData}
          onCreateTemplateClick={onCreateTemplateClick}
          onSaveAsDraftClick={onSaveAsDraftClick}
          draggedItem={draggedItem}
          isCreatingTemplate={createTemplateMutation.isLoading}
        />
      </div>
      <div className="my-5 flex flex-grow w-full gap-5 min-h-0">
        <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] max-w-[540px] min-w-[300px] w-1/3 flex flex-col flex-shrink-0">
          <div className="p-5 mb-5 border-b border-[#DDDDDD]">
            <SearchInput placeholder="Search by Device name, group name…" />
          </div>
          <div className="overflow-auto">
            <DevicesList
              draggedItem={draggedItem}
              data={template_data.devices}
              handleDragStart={handleDragStart}
              handleDragEnd={handleDragEnd}
            />
            <div className="mx-[10px] mb-[15px] border-b border-[#DDDDDD]"></div>
            <GroupsList
              data={template_data.groups}
              handleDragStart={handleDragStart}
              handleDragEnd={handleDragEnd}
              draggedItem={draggedItem}
            />
            <div className="mx-[10px] mb-[15px] border-b border-[#DDDDDD]"></div>
            <ScenesList
              data={template_data.scenes}
              handleDragStart={handleDragStart}
              handleDragEnd={handleDragEnd}
              draggedItem={draggedItem}
            />
            <div className="mx-[10px] my-[15px] border-b border-[#DDDDDD]"></div>
            <WidgetsList
              data={template_data.widgets}
              handleDragStart={handleDragStart}
              handleDragEnd={handleDragEnd}
              draggedItem={draggedItem}
              layout={templateData.layout}
              realRow={templateData.layout.row}
              realCol={templateData.layout.col}
            />
          </div>
        </div>

        <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] flex-grow overflow-auto">
          <TemplateLayout
            layout={templateData.layout}
            realRow={templateData.layout.row}
            realCol={templateData.layout.col}
            handleItemDrop={handleItemDropWithRepositioning}
            layoutBoxItem={layoutBoxItem}
            handleCardRemove={handleCardRemove}
            handleCardDragStart={handleCardDragStart}
            handleCardDragEnd={handleCardDragEnd}
          />
        </div>
      </div>
    </div>
  );
}

export default CreateIntelligentControlTemplate;
