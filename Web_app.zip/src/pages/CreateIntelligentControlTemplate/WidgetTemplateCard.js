import { CircleCrossSvg, MoveSvg } from "../../assets/svg";
import { getWidgetLayout } from "../../utils/helpers";
import {
  LandscapeLayout,
  PortraitLayout,
} from "../CreateWidget/WidgetVisualizer";

const WidgetTemplateCard = ({
  data,
  onRemove,
  onDragStart,
  onDragEnd,
  index,
  layout = "portrait",
  realRow,
  realCol,
}) => {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center relative">
      <div className="absolute top-3 left-3 flex w-[calc(100%-20px)] items-center justify-between">
        <div
          draggable
          onDragStart={(e) => onDragStart && onDragStart(e, data, index)}
          onDragEnd={onDragEnd}
          title="Drag to reposition"
        >
          <MoveSvg className="w-6 h-6 fill-[#7a838e]" />
        </div>
        <div onClick={() => onRemove && onRemove(index)} title="Remove">
          <CircleCrossSvg className="w-6 h-6 fill-[#7a838e]" />
        </div>
      </div>
      {getWidgetLayout(layout, realRow, realCol) === "landscape" ? (
        <PortraitLayout
          className="w-full h-full pointer-events-none"
          selectedWidgets={data?.structure}
        />
      ) : (
        <LandscapeLayout
          className="w-full h-full pointer-events-none"
          selectedWidgets={data?.structure}
        />
      )}
    </div>
  );
};

export default WidgetTemplateCard;
