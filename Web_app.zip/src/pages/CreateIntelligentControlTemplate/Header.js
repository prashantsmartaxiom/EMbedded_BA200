import { Link } from "react-router-dom";
import { BackspaceSvg, EditSvg } from "../../assets/svg";
import { PrimaryBtn2 } from "../../components";
import { ROUTES } from "../../router";

function Header({
  templateData,
  onCreateTemplateClick,
  onSaveAsDraftClick,
  draggedItem,
  isCreatingTemplate,
}) {
  return (
    <div>
      <div className="flex items-center justify-between pb-[15px]">
        <Link
          to={ROUTES.INTELLIGENT_CONTROLS_TEMPLATE}
          className="flex items-center gap-[10px]"
        >
          <BackspaceSvg />
          <h2 className="text-[#222222] font-bold">Create Template</h2>
        </Link>
        <div className="flex items-center gap-[15px]">
          <PrimaryBtn2
            onClick={onSaveAsDraftClick}
            className={"w-[135px] justify-center"}
            disabled={
              isCreatingTemplate || Object.keys(draggedItem).length === 0
            }
          >
            SAVE AS DRAFT
          </PrimaryBtn2>
          <PrimaryBtn2
            onClick={onCreateTemplateClick}
            className={"w-[80px] justify-center"}
            disabled={
              isCreatingTemplate ||
              (templateData?.layout?.row && templateData?.layout?.col
                ? Object.keys(draggedItem).length ===
                  templateData?.layout?.row * templateData?.layout?.col
                  ? false
                  : true
                : true)
            }
          >
            CREATE
          </PrimaryBtn2>
        </div>
      </div>
      <div className="flex items-center mb-2">
        <p className="text-[#939CA7] text-[12px] mr-[30px]">Template Name:</p>
        <div className="text-[#222222] text-[12px] flex items-center gap-5">
          {templateData.templateName}
          <button
            type="button"
            className="text-[#227EEB] flex items-center gap-[5px] text-[12px]"
          >
            <EditSvg className="fill-[#227EEB]" /> Edit
          </button>
        </div>
      </div>
    </div>
  );
}

export default Header;
