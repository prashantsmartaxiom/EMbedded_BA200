import { SignInForm } from "../../forms";
import LogoXL from "../../assets/images/LogoXL.png";

function SignIn() {
  return (
    <div className="w-full h-full flex justify-center items-center flex-col">
      <img src={LogoXL} alt="Logo" className="h-[52px] w-[195px]" />
      <div className="mt-20 mb-[30px]">
        <h2 className="text-[#222222] font-bold text-2xl text-center">
          Sign In
        </h2>
        <p className="text-sm text-[#939CA7] text-center mt-2">
          Welcome back! Please enter your details.
        </p>
      </div>
      <div className="w-full max-w-[360px]">
        <SignInForm />
      </div>
    </div>
  );
}

export default SignIn;
