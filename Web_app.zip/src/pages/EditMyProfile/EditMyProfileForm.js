import { useFormik } from "formik";
import * as Yup from "yup";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import * as Select from "@radix-ui/react-select";
import {
  PrimaryBtn2,
  PrimaryFileInput,
  PrimaryInput,
  SecondaryBtn,
} from "../../components";
import { BackspaceSvg, DownArrowSvg } from "../../assets/svg";
import { useUpdateUser } from "../../api/queryHooks";
import {
  MAX_FILE_SIZE_TO_UPLOAD_IMAGE,
  REGEX,
  VALID_IMAGE_FILE_TYPES,
} from "../../consts";
import toaster from "../../utils/toaster";
import { countryCodes } from "../../utils/countryCodes";
import CONFIG from "../../config";

const MAX_FILE_SIZE = MAX_FILE_SIZE_TO_UPLOAD_IMAGE; // 2MB
const VALID_FILE_TYPES = VALID_IMAGE_FILE_TYPES;

const validationSchema = Yup.object().shape({
  organization: Yup.string().required("Organisation is required"),
  fullName: Yup.string()
    .required("Full name is required")
    .min(2, "At least two characters required"),
  email: Yup.string()
    .matches(REGEX.email, "Invalid email format")
    .required("Email is required"),
  mobile: Yup.string().test(
    "mobile-validation",
    "Invalid mobile number",
    function (value) {
      if (!value || value.trim() === "") return true; // Mobile is optional
      
      const { parent } = this;
      const countryCode = parent.countryCode;
      const selectedCountry = countryCodes.find(
        (country) => country.phonecode === countryCode
      );
      
      if (selectedCountry && selectedCountry.regex) {
        const regex = new RegExp(selectedCountry.regex);
        if (!regex.test(value)) {
          return this.createError({
            message: `Invalid mobile number for ${selectedCountry.iso}`,
          });
        }
      } else {
        // Fallback validation for other countries
        if (!/^[0-9]+$/.test(value)) {
          return this.createError({
            message: "Mobile number must contain only digits",
          });
        }
        if (value.length < 7 || value.length > 15) {
          return this.createError({
            message: "Mobile number must be 7-15 digits",
          });
        }
      }
      return true;
    }
  ),
  profileImage: Yup.mixed()
    .nullable()
    .test("fileSize", "File too large (max 2MB)", (value) => {
      if (!value) return true;
      return value.size <= MAX_FILE_SIZE;
    })
    .test("fileType", "Unsupported file type (only JPG, PNG)", (value) => {
      if (!value) return true;
      return VALID_FILE_TYPES.includes(value.type);
    }),
});

function EditMyProfileForm({ user }) {
  const navigate = useNavigate();

  // Extract mobile code and number from contactNumber
  const mobileCode =
    user?.contactNumber?.split(" ")?.[0] || countryCodes[0]?.phonecode;
  const mobileNumber = user?.contactNumber?.split(" ")?.[1] || "";

  const [countryCode, setCountryCode] = useState(mobileCode);

  // Get selected country data for input restrictions
  const selectedCountry = countryCodes.find(
    (country) => country.phonecode === countryCode
  );
  
  // Determine max length based on country regex
  const getMaxLength = () => {
    if (selectedCountry && selectedCountry.regex) {
      // Extract expected length from regex patterns
      switch (selectedCountry.iso) {
        case "US": return 10; // US/Canada: 10 digits
        case "IN": return 10; // India: 10 digits
        case "CN": return 11; // China: 11 digits
        default: return 15; // Default max length
      }
    }
    return 15; // Default max length
  };

  const updateUserMutation = useUpdateUser({
    onSuccess: (data) => {
      navigate(-1);
      toaster.success("Profile updated successfully!");
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || `Error updating profile`);
      console.error("Error updating profile:", error);
    },
  });

  const formik = useFormik({
    initialValues: {
      organization: user?.organization || "",
      fullName: user?.fullName || "",
      email: user?.email || "",
      mobile: mobileNumber,
      countryCode: countryCode,
      profileImage: null,
    },
    validationSchema: validationSchema,
    enableReinitialize: true,
    onSubmit: async (values) => {
      // Convert profileImage to base64 if it exists
      let base64Image = null;
      if (values.profileImage) {
        try {
          const reader = new FileReader();
          reader.readAsDataURL(values.profileImage);
          await new Promise((resolve) => {
            reader.onloadend = () => {
              base64Image = reader.result;
              resolve();
            };
          });
        } catch (error) {
          console.error("Error converting image to base64:", error);
          toaster.error("Failed to process profile image.");
          return;
        }
      }

      const payload = {
        fullName: values.fullName,
        organization: values.organization,
        contactNumber: values.mobile.trim()
          ? countryCode + " " + values.mobile.trim()
          : "",
        ...(base64Image && { profileImage: base64Image }),
      };

      updateUserMutation.mutate({
        userId: user?._id,
        userData: payload,
      });
    },
  });

  // Don't render the form if user data is not available
  if (!user) {
    return (
      <div className="flex items-center justify-center p-8">
        <p className="text-[#939CA7]">Loading user data...</p>
      </div>
    );
  }

  return (
    <form onSubmit={formik.handleSubmit}>
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
          <Link to={-1} className="flex items-center gap-[10px]">
            <BackspaceSvg />
            <h2 className="text-[#222222] font-bold">Edit My Profile</h2>
          </Link>
          <div className="flex items-center gap-[10px]">
            <SecondaryBtn
              className={"w-[80px] justify-center"}
              onClick={() => formik.resetForm()}
              type="button"
            >
              RESET
            </SecondaryBtn>
            <PrimaryBtn2
              type="submit"
              disabled={formik.isSubmitting || updateUserMutation.isLoading}
              className={"w-[80px] justify-center"}
            >
              {formik.isSubmitting || updateUserMutation.isLoading
                ? "UPDATING..."
                : "UPDATE"}
            </PrimaryBtn2>
          </div>
        </div>

        {/* User Edit Form */}
        <div className="grid grid-cols-3 gap-x-10 gap-y-6">
          {/* Organisation */}
          <div className="row-start-1 col-start-1">
            <div className="flex justify-between items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Organisation:
              </h4>
              <PrimaryInput
                placeholder="Organisation"
                className="w-full"
                name="organization"
                value={formik.values.organization}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
            </div>
            {formik.touched.organization && formik.errors.organization ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[140px]">
                {formik.errors.organization}
              </div>
            ) : null}
          </div>

          {/* Profile Picture */}
          <div className="row-start-1 col-start-2 row-span-4">
            <PrimaryFileInput
              type="image"
              label="Profile Picture"
              description="Please upload an image of size upto 2 MB Accepted format: JPEG, PNG."
              onFileSelect={(file) =>
                formik.setFieldValue("profileImage", file)
              }
              value={formik.values.profileImage}
              imageUrl={user?.ImageURL}
            />
            {formik.touched.profileImage && formik.errors.profileImage ? (
              <div className="text-red-500 text-xs mt-1">
                {formik.errors.profileImage}
              </div>
            ) : null}
          </div>

          {/* Full Name */}
          <div className="row-start-2 col-start-1">
            <div className="flex justify-between items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Full Name:
              </h4>
              <PrimaryInput
                placeholder="Enter full name"
                className="w-full"
                name="fullName"
                value={formik.values.fullName}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
            </div>
            {formik.touched.fullName && formik.errors.fullName ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[140px]">
                {formik.errors.fullName}
              </div>
            ) : null}
          </div>

          {/* Email - Read Only */}
          <div className="row-start-3 col-start-1">
            <div className="flex justify-between items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Email:
              </h4>
              <PrimaryInput
                placeholder="Enter email address"
                className="w-full"
                type="email"
                name="email"
                value={formik.values.email}
                disabled
              />
            </div>
          </div>

          {/* Mobile Number */}
          <div className="row-start-4 col-start-1">
            <div className="flex justify-between items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Mobile:
              </h4>
              <div className="w-full flex">
                <Select.Root 
                  value={countryCode} 
                  onValueChange={(value) => {
                    setCountryCode(value);
                    formik.setFieldValue("countryCode", value);
                    // Clear mobile number when country changes to trigger re-validation
                    formik.setFieldValue("mobile", "");
                  }}
                >
                  <Select.Trigger className="group text-[#222222] placeholder:text-[#939CA7] rounded-l-[10px] border border-r-0 border-[#E7E8E8] bg-[#ffffff] p-[10px] text-xs focus:outline-[#227EEB] w-[80px] flex items-center justify-between">
                    <Select.Value placeholder="Country" />
                    <Select.Icon className="text-[#222222] flex-shrink-0 transition-transform duration-200 group-data-[state=open]:rotate-180">
                      <DownArrowSvg />
                    </Select.Icon>
                  </Select.Trigger>

                  <Select.Portal>
                    <Select.Content className="max-h-[300px] bg-white rounded-md shadow-lg z-50 border border-[#E7E8E8]">
                      <Select.Viewport className="p-1">
                        {countryCodes.map((country) => (
                          <Select.Item
                            key={country.id}
                            value={country.phonecode}
                            className="relative flex items-center min-h-7 pr-9 pl-6 py-2 rounded-sm text-xs leading-none text-gray-800 select-none cursor-pointer data-[highlighted]:outline-none data-[highlighted]:bg-blue-500 data-[highlighted]:text-white"
                          >
                            <div className="flex items-center gap-2">
                              <img
                                src={CONFIG.GET_FLAG_URL_BY_ISO(country.iso)}
                                alt={`${country.iso} flag`}
                                className="w-4 h-3 object-cover"
                              />
                              <Select.ItemText>
                                {country.phonecode}
                              </Select.ItemText>
                            </div>
                            <Select.ItemIndicator className="absolute left-0 w-6 inline-flex items-center justify-center">
                              ✓
                            </Select.ItemIndicator>
                          </Select.Item>
                        ))}
                      </Select.Viewport>
                    </Select.Content>
                  </Select.Portal>
                </Select.Root>
                <PrimaryInput
                  name="mobile"
                  type="tel"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.mobile}
                  placeholder="Mobile Number"
                  className="flex-1 rounded-l-none"
                  maxLength={getMaxLength()}
                  pattern="[0-9]*"
                />
              </div>
            </div>
            {formik.touched.mobile && formik.errors.mobile ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[140px]">
                {formik.errors.mobile}
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </form>
  );
}

export default EditMyProfileForm;
