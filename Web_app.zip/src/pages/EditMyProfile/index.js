import { useParams } from "react-router-dom";
import EditMyProfileForm from "./EditMyProfileForm";
import { useGetUserInfo } from "../../api/queryHooks";
import { SpinnerV1 } from "../../components";

function EditMyProfile() {
  const { userId } = useParams();
  const { data: userData, isLoading, error } = useGetUserInfo(userId);

  const user = userData?.data?.user;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <SpinnerV1 />
      </div>
    );
  }

  if (error || !user?._id) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-red-500">Failed to load user information</div>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <EditMyProfileForm user={user} />
    </div>
  );
}

export default EditMyProfile;
