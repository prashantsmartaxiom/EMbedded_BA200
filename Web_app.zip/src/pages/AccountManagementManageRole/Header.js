import { AddSvg } from "../../assets/svg";
import { SearchInput, SecondaryBtnLink } from "../../components";
import { ROUTES } from "../../router";
import useUserStore from "../../store/useUserStore";

function Header({ onSearchChange }) {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
      <h2 className="text-[#222222] font-bold">Account Management</h2>
      <div className="flex items-center gap-[15px]">
        <SearchInput
          className="w-[260px]"
          placeholder="Search by role"
          onChange={(e) => onSearchChange(e.target.value)}
        />
        <SecondaryBtnLink
          to={ROUTES.CREATE_NEW_ROLE}
          className={"w-[135px] justify-center"}
          Icon={AddSvg}
          canAccess={
            userPermissions?.USER_MANAGEMENT?.role_management?.addModify
          }
        >
          NEW ROLE
        </SecondaryBtnLink>
      </div>
    </div>
  );
}

export default Header;
