import { useState } from "react";
import { DataTable, PrimaryDropdown, TabBtn } from "../../components";
import { useGetRoles, useUpdateRoleStatus } from "../../api/queryHooks";
import { DeleteSvg, EditSvg, SuspendSvg } from "../../assets/svg";
import DeleteRolePopup from "./DeleteRolePopup";
import toaster from "../../utils/toaster";
import Seperator from "../../components/Header/Seperator";
import { Link } from "react-router-dom";
import { ROUTES } from "../../router";
import useUserStore from "../../store/useUserStore";
import CONFIG from "../../config";

const TABS = {
  ALL: "all",
  ACTIVE: "active",
  INACTIVE: "inactive",
};

function Header({ tab, onTabChange, limit, onLimitChange, counts }) {
  return (
    <div className="flex items-center justify-between mb-[15px]">
      <h2 className="text-[#222222] text-[14px] font-semibold">Manage Role</h2>
      <div className="flex items-center gap-[5px]">
        <div className="flex items-center gap-[20px]">
          <div className="flex items-center gap-[10px]">
            <span className="text-[#222222] text-[12px]">Show:</span>
            <PrimaryDropdown
              className="w-[60px]"
              value={limit}
              onValueChange={onLimitChange}
              options={[
                { value: "10", label: "10" },
                { value: "20", label: "20" },
                { value: "25", label: "25" },
                { value: "50", label: "50" },
              ]}
            />
            <span className="text-[12px] text-[#7A838E]">Entries</span>
          </div>
        </div>
        <Seperator className="h-[25px] ml-3" />
        <TabBtn
          isActive={tab === TABS.ALL}
          onClick={() => onTabChange(TABS.ALL)}
        >
          All
          <span className="ml-2">{counts.all}</span>
        </TabBtn>
        <TabBtn
          isActive={tab === TABS.ACTIVE}
          onClick={() => onTabChange(TABS.ACTIVE)}
        >
          Active
          <span className="ml-2">{counts.active}</span>
        </TabBtn>
        <TabBtn
          isActive={tab === TABS.INACTIVE}
          onClick={() => onTabChange(TABS.INACTIVE)}
        >
          Inactive
          <span className="ml-2">{counts.inactive}</span>
        </TabBtn>
      </div>
    </div>
  );
}

const AccountManagementRoleContent = ({ search, page, setPage }) => {
  const userPermissions = useUserStore((state) => state.permissions);
  const [tab, setTab] = useState(TABS.ACTIVE);
  const [limit, setLimit] = useState("10");
  const [sortBy, setSortBy] = useState("");
  const [sortOrder, setSortOrder] = useState(null);
  const [deleteModal, setDeleteModal] = useState({
    isOpen: false,
    roleId: null,
  });
  const [updatingStatusRoleId, setUpdatingStatusRoleId] = useState(null);

  const updateRoleStatusMutation = useUpdateRoleStatus({
    onSuccess: (data) => {
      setUpdatingStatusRoleId(null);
      toaster.success("Role status updated successfully!");
    },
    onError: (error) => {
      setUpdatingStatusRoleId(null);
      toaster.error(
        error?.response?.data?.message || `Error updating role status`
      );
      console.error("Error updating role status:", error);
    },
  });

  const handleStatusUpdate = (roleId, isActive) => {
    setUpdatingStatusRoleId(roleId);
    updateRoleStatusMutation.mutate({
      roleId,
      statusData: { isActive },
    });
  };

  const handleDeleteClick = (roleId) => {
    setDeleteModal({ isOpen: true, roleId });
  };

  const handleDeleteModalClose = () => {
    setDeleteModal({ isOpen: false, roleId: null });
  };

  const handleDeleteSuccess = () => {
    // The query will be automatically refetched due to invalidateQueries in the hook
  };

  const handleSortChange = (columnKey, newSortOrder) => {
    setSortBy(columnKey);
    setSortOrder(newSortOrder);
    setPage(1); // Reset to first page when sorting changes
  };

  const columns = [
    { key: "sno", label: "S. No." },
    { key: "roleName", label: "Role Name", sortable: true },
    {
      key: "status",
      label: "Status",
      render: (_, row) => (
        <span
          className={`px-2 py-1 rounded-full text-xs ${
            row.is_active
              ? "bg-green-100 text-green-800"
              : "bg-red-100 text-red-800"
          }`}
        >
          {row.is_active ? "Active" : "Inactive"}
        </span>
      ),
    },
    {
      key: "access",
      label: "Access",
      render: (_, row) => (
        <Link
          to={ROUTES.GET_VIEW_ROLE(row.id)}
          className="text-[#027AFF] text-[12px] hover:underline"
        >
          View
        </Link>
      ),
    },
    {
      key: "action",
      label: "Action",
      render: (_, row) =>
        !CONFIG.CAN_EDIT_DEFAULT_ROLES && (row?.byDefault === "true" || row?.byDefault === true) ? (
        // false ? (
          <button className="text-[#222222]">Default</button>
        ) : (
          <div className="flex gap-6">
            {userPermissions?.USER_MANAGEMENT?.role_management?.addModify ? (
              <Link
                to={ROUTES.GET_EDIT_ROLE(row.id)}
                className="text-[#222222] fill-[#222222] hover:underline flex items-center"
              >
                <EditSvg className="inline mr-1 mt-px" />
                Edit
              </Link>
            ) : null}
            {userPermissions?.USER_MANAGEMENT?.role_management?.addModify ? (
              row?.is_active ? (
                <button
                  className="text-[#222222] fill-[#222222] hover:underline flex items-center"
                  onClick={() => handleStatusUpdate(row.id, false)}
                  disabled={updatingStatusRoleId === row.id}
                >
                  <SuspendSvg className="inline mr-1" />
                  Suspend
                </button>
              ) : (
                <button
                  className="text-[#F29F1A] fill-[#F29F1A] hover:underline flex items-center"
                  onClick={() => handleStatusUpdate(row.id, true)}
                  disabled={updatingStatusRoleId === row.id}
                >
                  <SuspendSvg className="inline mr-1" />
                  Re-Active
                </button>
              )
            ) : null}
            {userPermissions?.USER_MANAGEMENT?.role_management?.delete ? (
              <button
                className="text-red-500 fill-red-500 hover:underline flex items-center"
                onClick={() => handleDeleteClick(row.id)}
              >
                <DeleteSvg className="inline mr-1 mt-px" />
                Delete
              </button>
            ) : null}
          </div>
        ),
    },
  ];

  const { data: roleData, isLoading } = useGetRoles({
    page,
    limit: Number(limit),
    search,
    status: tab === TABS.ACTIVE ? 1 : tab === TABS.INACTIVE ? 0 : null,
    sortBy: sortBy || undefined,
    sortOrder: sortOrder || undefined,
  });

  const data =
    roleData?.data?.roles?.map((role, index) => ({
      sno: String((page - 1) * Number(limit) + index + 1).padStart(2, "0"),
      roleName: role.roleName || role.name || role.title,
      id: role.id || role._id,
      is_active: role.isActive !== undefined ? role.isActive : true, // Default to true if not provided
      byDefault: role?.byDefault,
    })) || [];

  const counts = {
    all: (roleData?.data?.totalNonDeleted || 0)
      .toString()
      .padStart(2, "0"),
    active: (roleData?.data?.totalActive || 0)
      .toString()
      .padStart(2, "0"),
    inactive: (roleData?.data?.totalInactive || 0)
      .toString()
      .padStart(2, "0"),
  };

  return (
    <div>
      <Header
        tab={tab}
        onTabChange={setTab}
        limit={limit}
        onLimitChange={setLimit}
        counts={counts}
      />
      <DataTable
        columns={columns}
        data={data}
        totalItems={roleData?.data?.pagination?.totalRoles || 0}
        currentPage={page}
        onPageChange={setPage}
        isLoading={isLoading}
        rowsPerPage={Number(limit)}
        sortBy={sortBy}
        sortOrder={sortOrder}
        onSortChange={handleSortChange}
      />

      <DeleteRolePopup
        isOpen={deleteModal.isOpen}
        toggleModal={handleDeleteModalClose}
        roleId={deleteModal.roleId}
        onSuccess={handleDeleteSuccess}
      />
    </div>
  );
};

export default AccountManagementRoleContent;
