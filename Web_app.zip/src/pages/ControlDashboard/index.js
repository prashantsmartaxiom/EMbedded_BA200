import Header from "./Header";

function ControlDashboard() {
  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header />
      </div>
    </div>
  );
}

export default ControlDashboard;
