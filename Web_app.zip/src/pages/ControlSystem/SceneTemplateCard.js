import { useEffect, useState } from "react";
import {
  SceneOffSvg,
  SceneOnSvg,
  LEDonSvg,
  LEDSvg,
  MdArrowDownSvg,
  SensorSvg,
  StopSvg,
  BackspaceSvg,
  ChipSvg,
  ShadeSSSvg,
  ShadeTTSvg,
} from "../../assets/svg";
import { RangeSlider, CurtainSvg } from "../../components";
import { MdArrowLeft, MdArrowRight } from "react-icons/md";
import {
  convertGroupChannelToElementInScene,
  convertNormalChannelToElementInScene,
  percentToNumber,
} from "../../utils/helpers";

const OperateButton = ({ scene, handleExecuteScene, canControl = true }) => {
  const [invertFlag, setInvertFlag] = useState(scene?.invert_flag);

  useEffect(() => {
    setInvertFlag(scene?.invert_flag);
  }, [scene?.invert_flag]);

  const handleSwitchChange = (checked) => {
    if (!canControl) return;
    setInvertFlag(!checked);
    // setInvertFlag(checked);
    handleExecuteScene({
      ...scene,
      invertFlag: !checked,
      // invertFlag: checked,
    });
  };

  return (
    <div className="flex flex-col items-center gap-2">
      {/* <Switch
        id={`scene-switch-${scene?.id}`}
        // checked={invertFlag}
        checked={!invertFlag}
        onCheckedChange={handleSwitchChange}
        size="small"
        variant="primary"
        disabled={!canControl}
      /> */}
      <button onClick={() => handleSwitchChange(invertFlag)}>
        {invertFlag ? <SceneOffSvg /> : <SceneOnSvg />}
      </button>
      {/* <span className="text-[10px] text-center text-[#222222] font-medium">
        {invertFlag ? "Set On" : "Set Off"}
      </span> */}
    </div>
  );
};

const MainSceneChannel = ({
  data,
  canControl,
  onSceneExecute,
  sceneBrightness,
  handleBrightnessChange,
  handleBrightnessCommit,
  shouldShowBrightness,
}) => {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center p-2 relative">
      <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
        {data?.scene_name || data?.name}
      </h2>
      <div className="flex-1 flex items-center justify-center w-full h-full">
        {data?.operateType === "invert" ? (
          <OperateButton
            scene={data}
            handleExecuteScene={onSceneExecute}
            canControl={canControl}
          />
        ) : (
          <button
            onClick={() => canControl && onSceneExecute && onSceneExecute(data)}
            disabled={!canControl}
            className={`rounded-lg w-full max-w-[120px] h-[32px] flex items-center justify-center text-sm font-semibold transition-colors ${
              canControl
                ? "bg-[#227EEB] text-[#FFFFFF] hover:bg-[#1a6acc] cursor-pointer"
                : "bg-gray-400 text-gray-200 cursor-not-allowed"
            }`}
          >
            EXECUTE
          </button>
        )}
      </div>
      {shouldShowBrightness ? (
        <div className="w-full max-w-[240px]">
          <RangeSlider
            min={0}
            max={100}
            value={sceneBrightness}
            onChange={handleBrightnessChange}
            onValueCommit={handleBrightnessCommit}
            disabled={!canControl}
          />
        </div>
      ) : null}
    </div>
  );
};

// Scene Channel Item Component (similar to GroupTemplateCard ChannelItem)
const SceneChannelItem = ({
  channel,
  mainChannel = false,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit,
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  channelStates,
  isGroup = false,
  groupData = null,
  canControl = true,
}) => {
  if (channel?.channelType === "led" || channel?.type === "led") {
    const currentState =
      channelStates[`${channel.deviceId}-${channel.channelId}`] || channel;
    const isOn =
      currentState.channelStatus === "on" || currentState.status === "on";
    const brightness = parseInt(
      currentState.brightness || currentState.properties?.brightness || 0
    );
    const powerMin = 0;
    const powerMax = 100;

    if (mainChannel)
      return (
        <div className="flex flex-col items-center gap-2 w-full h-fit truncate p-[14px]">
          <div className="flex items-center w-full gap-3">
            <div
              className={`${
                canControl ? "cursor-pointer" : "cursor-not-allowed"
              }`}
              onClick={() =>
                canControl &&
                onLEDToggle &&
                onLEDToggle(channel, isGroup, groupData)
              }
            >
              {isOn ? (
                <LEDonSvg className="w-[100px] h-[100px] max-w-[120px] max-h-[120px]" />
              ) : (
                <LEDSvg className="w-[94px] h-[94px] max-w-[120px] max-h-[120px]" />
              )}
            </div>
            <div className="truncate mb-6">
              <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
                {channel.isMainChannel
                  ? channel.channelName || channel.name || channel.channelId
                  : channel.channelName || channel.name || channel.channelId}
              </h2>
            </div>
          </div>

          <div className="w-full">
            <RangeSlider
              min={powerMin}
              max={powerMax}
              value={brightness}
              onChange={(value) =>
                onLEDBrightnessChange &&
                onLEDBrightnessChange(channel, value, isGroup, groupData)
              }
              onValueCommit={(value) =>
                onLEDBrightnessCommit &&
                onLEDBrightnessCommit(channel, value, isGroup, groupData)
              }
              disabled={!isOn || !canControl}
            />
          </div>
        </div>
      );

    return (
      <div className="flex flex-col items-center gap-2 w-full h-full truncate">
        {mainChannel ? null : (
          <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
            {channel.isMainChannel
              ? channel.channelName || channel.name || channel.channelId
              : channel.channelName || channel.name || channel.channelId}
          </h2>
        )}
        <div
          className={`flex-1 flex items-center justify-center w-full h-full ${
            canControl ? "cursor-pointer" : "cursor-not-allowed"
          }`}
          onClick={() =>
            canControl &&
            onLEDToggle &&
            onLEDToggle(channel, isGroup, groupData)
          }
        >
          {isOn ? (
            <LEDonSvg className="w-[100px] h-[100px] max-w-[120px] max-h-[120px]" />
          ) : (
            <LEDSvg className="w-[94px] h-[94px] max-w-[120px] max-h-[120px]" />
          )}
        </div>
        <div className="w-full max-w-[240px]">
          <RangeSlider
            min={powerMin}
            max={powerMax}
            value={brightness}
            onChange={(value) =>
              onLEDBrightnessChange &&
              onLEDBrightnessChange(channel, value, isGroup, groupData)
            }
            onValueCommit={(value) =>
              onLEDBrightnessCommit &&
              onLEDBrightnessCommit(channel, value, isGroup, groupData)
            }
            disabled={!isOn || !canControl}
          />
        </div>
      </div>
    );
  }

  if (channel?.channelType === "shade" || channel?.type === "shade") {
    const currentState =
      channelStates[`${channel.deviceId}-${channel.channelId}`] || channel;

    const openLevel =
      percentToNumber(currentState.openLevel) ||
      percentToNumber(currentState.properties?.openLevel) ||
      0;
    const isFullyOpen = openLevel >= 100;
    const isFullyClosed = openLevel <= 0;
    const isLutronShade = channel?.deviceType?.toLowerCase() === "shade_lutron";

    if (mainChannel)
      return (
        <div className="flex flex-col gap-2 w-full h-fit truncate p-[14px]">
          <div className="flex items-center w-full gap-3">
            <div className="flex items-center justify-center flex-col gap-2">
              <CurtainSvg
                openValue={openLevel}
                className="w-[100px] h-[100px] max-w-[120px] max-h-[120px]"
              />
              <div className="flex flex-col gap-2 w-fit min-w-32">
                <div className="text-xs text-center text-gray-600">
                  {isLutronShade
                    ? `${
                        channel?.properties?.numberOfCmds ||
                        channel?.numberOfCmds ||
                        3
                      }/4 commands`
                    : ``}
                </div>
                <div className="flex items-center justify-center">
                  <div
                    className="h-[30px] bg-[#F5F9FD] border border-[#CCCCCC] rounded-lg w-full max-w-32 grid text-[#222222]"
                    style={{
                      gridTemplateColumns:
                        (channel?.properties?.numberOfCmds ||
                          channel?.numberOfCmds) === 4
                          ? "repeat(4, 1fr)"
                          : "repeat(3, 1fr)",
                    }}
                  >
                    <button
                      className={`flex items-center justify-center hover:bg-gray-100 ${
                        !canControl || (!isLutronShade && isFullyOpen)
                          ? "opacity-50 cursor-not-allowed"
                          : "cursor-pointer"
                      }`}
                      onClick={() =>
                        canControl &&
                        (!isLutronShade ? !isFullyOpen : true) &&
                        onShadeUp &&
                        onShadeUp(channel, isGroup, groupData)
                      }
                      disabled={!canControl || (!isLutronShade && isFullyOpen)}
                    >
                      <MdArrowDownSvg className="rotate-180 w-[12px] h-[12px]" />
                    </button>

                    {(channel?.properties?.numberOfCmds ||
                      channel?.numberOfCmds) === 4 ? (
                      <>
                        <button
                          className={`border-l border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100 ${
                            canControl ? "cursor-pointer" : "cursor-not-allowed"
                          }`}
                          onClick={() =>
                            canControl &&
                            onShade66 &&
                            onShade66(channel, isGroup, groupData)
                          }
                          disabled={!canControl}
                        >
                          <ShadeSSSvg className="w-[14px] h-[14px]" />
                        </button>
                        <button
                          className={`border-l border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100 ${
                            canControl ? "cursor-pointer" : "cursor-not-allowed"
                          }`}
                          onClick={() =>
                            canControl &&
                            onShade33 &&
                            onShade33(channel, isGroup, groupData)
                          }
                          disabled={!canControl}
                        >
                          <ShadeTTSvg className="w-[14px] h-[14px]" />
                        </button>
                      </>
                    ) : (
                      <button
                        className={`border-l border-r border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100 ${
                          canControl ? "cursor-pointer" : "cursor-not-allowed"
                        }`}
                        onClick={() =>
                          canControl &&
                          onShadeStop &&
                          onShadeStop(channel, isGroup, groupData)
                        }
                        disabled={!canControl}
                      >
                        <StopSvg className="w-[20px] h-[20px]" />
                      </button>
                    )}

                    <button
                      className={`${
                        (channel?.properties?.numberOfCmds ||
                          channel?.numberOfCmds) === 4
                          ? "border-l border-[#CCCCCC]"
                          : ""
                      } flex items-center justify-center hover:bg-gray-100 ${
                        !canControl || (!isLutronShade && isFullyClosed)
                          ? "opacity-50 cursor-not-allowed"
                          : "cursor-pointer"
                      }`}
                      onClick={() =>
                        canControl &&
                        (!isLutronShade ? !isFullyClosed : true) &&
                        onShadeDown &&
                        onShadeDown(channel, isGroup, groupData)
                      }
                      disabled={
                        !canControl || (!isLutronShade && isFullyClosed)
                      }
                    >
                      <MdArrowDownSvg className="w-[12px] h-[12px]" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div className="truncate mb-8">
              <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
                {channel.isMainChannel
                  ? channel.channelName || channel.name || channel.channelId
                  : channel.channelName || channel.name || channel.channelId}
              </h2>
            </div>
          </div>
        </div>
      );

    return (
      <div className="flex flex-col items-center gap-2 w-full h-full truncate">
        {mainChannel ? null : (
          <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
            {channel.isMainChannel
              ? channel.channelName || channel.name || channel.channelId
              : channel.channelName || channel.name || channel.channelId}
          </h2>
        )}
        <div className="flex-1 flex items-center justify-center w-full h-full">
          <CurtainSvg
            openValue={openLevel}
            className="h-[60%] max-w-[120px] max-h-[120px]"
          />
        </div>
        <div className="text-xs text-center text-gray-600 mb-1">
          {isLutronShade
            ? `${
                channel?.properties?.numberOfCmds || channel?.numberOfCmds || 3
              }/4 commands`
            : ``}
        </div>
        <div className="w-full flex items-center justify-center">
          <div
            className="h-[30px] bg-[#F5F9FD] border border-[#CCCCCC] rounded-lg w-full max-w-32 grid text-[#222222]"
            style={{
              gridTemplateColumns:
                (channel?.properties?.numberOfCmds || channel?.numberOfCmds) ===
                4
                  ? "repeat(4, 1fr)"
                  : "repeat(3, 1fr)",
            }}
          >
            <button
              className={`flex items-center justify-center hover:bg-gray-100 ${
                !canControl || (!isLutronShade && isFullyOpen)
                  ? "opacity-50 cursor-not-allowed"
                  : "cursor-pointer"
              }`}
              onClick={() =>
                canControl &&
                (!isLutronShade ? !isFullyOpen : true) &&
                onShadeUp &&
                onShadeUp(channel, isGroup, groupData)
              }
              disabled={!canControl || (!isLutronShade && isFullyOpen)}
            >
              <MdArrowDownSvg className="rotate-180 w-[12px] h-[12px]" />
            </button>

            {(channel?.properties?.numberOfCmds || channel?.numberOfCmds) ===
            4 ? (
              <>
                <button
                  className={`border-l border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100 ${
                    canControl ? "cursor-pointer" : "cursor-not-allowed"
                  }`}
                  onClick={() =>
                    canControl &&
                    onShade66 &&
                    onShade66(channel, isGroup, groupData)
                  }
                  disabled={!canControl}
                >
                  <ShadeSSSvg className="w-[14px] h-[14px]" />
                </button>
                <button
                  className={`border-l border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100 ${
                    canControl ? "cursor-pointer" : "cursor-not-allowed"
                  }`}
                  onClick={() =>
                    canControl &&
                    onShade33 &&
                    onShade33(channel, isGroup, groupData)
                  }
                  disabled={!canControl}
                >
                  <ShadeTTSvg className="w-[14px] h-[14px]" />
                </button>
              </>
            ) : (
              <button
                className={`border-l border-r border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100 ${
                  canControl ? "cursor-pointer" : "cursor-not-allowed"
                }`}
                onClick={() =>
                  canControl &&
                  onShadeStop &&
                  onShadeStop(channel, isGroup, groupData)
                }
                disabled={!canControl}
              >
                <StopSvg className="w-[20px] h-[20px]" />
              </button>
            )}

            <button
              className={`${
                (channel?.properties?.numberOfCmds || channel?.numberOfCmds) ===
                4
                  ? "border-l border-[#CCCCCC]"
                  : ""
              } flex items-center justify-center hover:bg-gray-100 ${
                !canControl || (!isLutronShade && isFullyClosed)
                  ? "opacity-50 cursor-not-allowed"
                  : "cursor-pointer"
              }`}
              onClick={() =>
                canControl &&
                (!isLutronShade ? !isFullyClosed : true) &&
                onShadeDown &&
                onShadeDown(channel, isGroup, groupData)
              }
              disabled={!canControl || (!isLutronShade && isFullyClosed)}
            >
              <MdArrowDownSvg className="w-[12px] h-[12px]" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (channel?.channelType === "sensor" || channel?.type === "sensor") {
    return (
      <div className="flex flex-col items-center gap-2 w-full h-full truncate">
        {mainChannel ? null : (
          <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
            Sensor
          </h2>
        )}
        <div className="flex-1 flex items-center justify-center w-full h-full">
          <SensorSvg
            className={`h-[60%] max-w-[120px] max-h-[120px] ${
              channel.channelStatus === "active" || channel.status === "active"
                ? "text-blue-500"
                : "text-gray-400"
            }`}
          />
        </div>
        <div className="text-sm text-center text-gray-600">
          {channel.channelStatus || channel.status || "inactive"}
        </div>
      </div>
    );
  }

  return null;
};

const GroupPage = ({
  group,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit,
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  channelStates,
  canControl = true,
}) => {
  const [currentChannelPage, setCurrentChannelPage] = useState(0);

  // Get all channels from all devices in the group, excluding sensors
  const allChannels = [];
  group?.devices?.forEach((device) => {
    device?.sceneChannels?.forEach((channel) => {
      if (channel.channelType !== "sensor") {
        allChannels.push({
          ...channel,
          deviceId: device.deviceId,
          deviceName: device.deviceName,
        });
      }
    });
  });

  // Create main channel from first channel
  const firstChannel = allChannels[0];
  const mainChannel = firstChannel
    ? {
        ...firstChannel,
        isMainChannel: true,
        channelName: group?.groupName || firstChannel.channelName,
      }
    : null;

  // Pagination for channels (2 per page after main channel)
  const channelPages = [];
  for (let i = 0; i < allChannels.length; i += 2) {
    channelPages.push(allChannels.slice(i, i + 2));
  }

  const totalChannelPages = channelPages.length;

  return (
    <div className="w-full h-full flex flex-col">
      {/* Group Name */}
      {/* <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-4">
        {group?.groupName}
      </h2> */}

      {allChannels?.length === 0 ? (
        <div className="flex-1 flex items-center justify-center w-full h-full">
          <div className="text-center text-[#939CA7] text-sm">
            Currently not available
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col">
          {/* Main Channel Row */}
          {mainChannel && (
            <div className="flex items-center justify-center border-b border-gray-200 pb-2 mb-2">
              <SceneChannelItem
                channel={mainChannel}
                mainChannel={true}
                onLEDToggle={onLEDToggle}
                onLEDBrightnessChange={onLEDBrightnessChange}
                onLEDBrightnessCommit={onLEDBrightnessCommit}
                onShadeUp={onShadeUp}
                onShadeDown={onShadeDown}
                onShadeStop={onShadeStop}
                onShade33={onShade33}
                onShade66={onShade66}
                channelStates={channelStates}
                isGroup={true}
                groupData={group}
                canControl={canControl}
              />
            </div>
          )}

          {/* Individual Channels Row with Pagination */}
          <div className="flex-1 flex flex-col px-[14px] relative">
            <div className="flex-1 flex items-center justify-center gap-8">
              {channelPages[currentChannelPage]?.map((channel, idx) => (
                <SceneChannelItem
                  key={`${channel.deviceId}-${channel.channelId}-${idx}`}
                  channel={channel}
                  onLEDToggle={onLEDToggle}
                  onLEDBrightnessChange={onLEDBrightnessChange}
                  onLEDBrightnessCommit={onLEDBrightnessCommit}
                  onShadeUp={onShadeUp}
                  onShadeDown={onShadeDown}
                  onShadeStop={onShadeStop}
                  onShade33={onShade33}
                  onShade66={onShade66}
                  channelStates={channelStates}
                  isGroup={false}
                  groupData={null}
                  canControl={canControl}
                />
              ))}
            </div>

            {/* Channel Navigation Arrows */}
            {totalChannelPages > 1 && (
              <>
                <button
                  onClick={() =>
                    setCurrentChannelPage(Math.max(0, currentChannelPage - 1))
                  }
                  disabled={currentChannelPage === 0}
                  className={`p-2 absolute top-1/2 left-0 rounded ${
                    currentChannelPage === 0
                      ? "text-gray-400 cursor-not-allowed"
                      : "text-[#4A90E2]"
                  }`}
                >
                  <BackspaceSvg className="w-4 h-4" />
                </button>
                {/* <span className="text-sm text-gray-600">
                  {currentChannelPage + 1} / {totalChannelPages}
                </span> */}
                <button
                  onClick={() =>
                    setCurrentChannelPage(
                      Math.min(totalChannelPages - 1, currentChannelPage + 1)
                    )
                  }
                  disabled={currentChannelPage === totalChannelPages - 1}
                  className={`p-2 absolute top-1/2 right-0 rounded ${
                    currentChannelPage === totalChannelPages - 1
                      ? "text-gray-400 cursor-not-allowed"
                      : "text-[#4A90E2]"
                  }`}
                >
                  <BackspaceSvg className="w-4 h-4 rotate-180" />
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

const DevicePage = ({
  device,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit,
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  channelStates,
  canControl = true,
}) => {
  const [currentChannelPage, setCurrentChannelPage] = useState(0);

  // Get all channels from the device, excluding sensors
  const allChannels = [];
  device?.sceneChannels?.forEach((channel) => {
    if (channel.channelType !== "sensor") {
      allChannels.push({
        ...channel,
        deviceId: device.deviceId,
        deviceName: device.deviceName,
      });
    }
  });

  // Pagination for channels (2 per page)
  const channelPages = [];
  for (let i = 0; i < allChannels.length; i += 2) {
    channelPages.push(allChannels.slice(i, i + 2));
  }

  const totalChannelPages = channelPages.length;

  return (
    <div className="w-full h-full flex flex-col">
      {/* Device Name Row */}
      <div className="p-[14px] flex items-center justify-center border-b border-gray-200 pb-2 mb-2 min-h-[165px]">
        <div className="flex items-center w-full gap-5 px-5">
          <div>
            <ChipSvg className="fill-[#227EEB] h-[80px] w-[80px]" />
          </div>
          <div className="truncate">
            <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)]">
              {device?.deviceName || device?.name}
            </h2>
          </div>
        </div>
      </div>

      {/* Channels Row */}
      <div className="flex-1 flex flex-col">
        {allChannels?.length === 0 ? (
          <div className="flex-1 flex items-center justify-center w-full h-full">
            <div className="text-center text-[#939CA7] text-sm">
              Currently not available
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col px-[14px] relative">
            <div className="flex-1 flex items-center justify-center gap-8">
              {channelPages[currentChannelPage]?.map((channel, idx) => (
                <SceneChannelItem
                  key={`${channel.deviceId}-${channel.channelId}-${idx}`}
                  channel={channel}
                  onLEDToggle={onLEDToggle}
                  onLEDBrightnessChange={onLEDBrightnessChange}
                  onLEDBrightnessCommit={onLEDBrightnessCommit}
                  onShadeUp={onShadeUp}
                  onShadeDown={onShadeDown}
                  onShadeStop={onShadeStop}
                  onShade33={onShade33}
                  onShade66={onShade66}
                  channelStates={channelStates}
                  isGroup={false}
                  groupData={null}
                  canControl={canControl}
                />
              ))}
            </div>

            {/* Channel Navigation Arrows */}
            {totalChannelPages > 1 && (
              <div className="flex items-center justify-center gap-4 mt-2">
                <button
                  onClick={() =>
                    setCurrentChannelPage(Math.max(0, currentChannelPage - 1))
                  }
                  disabled={currentChannelPage === 0}
                  className={`p-2 absolute top-1/2 left-0 rounded ${
                    currentChannelPage === 0
                      ? "text-gray-400 cursor-not-allowed"
                      : "text-[#4A90E2]"
                  }`}
                >
                  <BackspaceSvg className="w-4 h-4" />
                </button>
                {/* <span className="text-sm text-gray-600">
                  {currentChannelPage + 1} / {totalChannelPages}
                </span> */}
                <button
                  onClick={() =>
                    setCurrentChannelPage(
                      Math.min(totalChannelPages - 1, currentChannelPage + 1)
                    )
                  }
                  disabled={currentChannelPage === totalChannelPages - 1}
                  className={`p-2 absolute top-1/2 right-0 rounded ${
                    currentChannelPage === totalChannelPages - 1
                      ? "text-gray-400 cursor-not-allowed"
                      : "text-[#4A90E2]"
                  }`}
                >
                  <BackspaceSvg className="w-4 h-4 rotate-180" />
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

const SceneTemplateCard = ({
  data,
  onSceneExecute,
  onSceneBrightnessChange,
  onSceneBrightnessCommit,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit,
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  canControl = true,
}) => {
  const [pageIndex, setPageIndex] = useState(0);
  const pageCount =
    (data?.sceneDetails?.type === "group"
      ? data?.sceneDetails?.groups?.length
      : data?.sceneDetails?.devices?.length) + 1;

  const [sceneBrightness, setSceneBrightness] = useState(
    data?.scene_brightness || 0
  );

  // Local channel states management
  const [channelStates, setChannelStates] = useState({});

  // Initialize channel states from scene data
  useEffect(() => {
    const initializeChannelStates = () => {
      const states = {};

      if (data?.sceneDetails?.type === "group") {
        data?.sceneDetails?.groups?.forEach((group) => {
          group?.devices?.forEach((device) => {
            device?.sceneChannels?.forEach((channel) => {
              const key = `${device.deviceId}-${channel.channelId}`;
              states[key] = {
                ...channel,
                deviceId: device.deviceId,
                deviceName: device.deviceName,
              };
            });
          });
        });
      } else {
        data?.sceneDetails?.devices?.forEach((device) => {
          device?.sceneChannels?.forEach((channel) => {
            const key = `${device.deviceId}-${channel.channelId}`;
            states[key] = {
              ...channel,
              deviceId: device.deviceId,
              deviceName: device.deviceName,
            };
          });
        });
      }

      setChannelStates(states);
    };

    if (data?.sceneDetails) {
      initializeChannelStates();
    }
  }, [data?.sceneDetails]);

  // Helper function to update channel state
  const updateChannelState = (deviceId, channelId, newState) => {
    const key = `${deviceId}-${channelId}`;
    setChannelStates((prev) => ({
      ...prev,
      [key]: {
        ...prev[key],
        ...newState,
      },
    }));
  };

  useEffect(() => {
    setSceneBrightness(data?.scene_brightness || 0);
  }, [data?.scene_brightness]);

  const handleBrightnessChange = (value) => {
    setSceneBrightness(value);
    if (onSceneBrightnessChange) {
      onSceneBrightnessChange(data, value);
    }
  };

  const handleBrightnessCommit = (value) => {
    if (onSceneBrightnessCommit) {
      onSceneBrightnessCommit(data, value);
    }
  };

  const handleLEDToggle = (channel, isGroup = false, groupData = null) => {
    const newStatus =
      channelStates[`${channel.deviceId}-${channel.channelId}`]
        ?.channelStatus === "on" ||
      channelStates[`${channel.deviceId}-${channel.channelId}`]?.status === "on"
        ? "off"
        : "on";

    updateChannelState(channel.deviceId, channel.channelId, {
      channelStatus: newStatus,
      status: newStatus,
    });

    if (onLEDToggle) {
      onLEDToggle(
        convertNormalChannelToElementInScene(channel),
        isGroup,
        convertGroupChannelToElementInScene(groupData)
      );
    }
  };

  const handleLEDBrightnessChange = (
    channel,
    brightness,
    isGroup = false,
    groupData = null
  ) => {
    updateChannelState(channel.deviceId, channel.channelId, {
      brightness: brightness,
      properties: {
        ...channelStates[`${channel.deviceId}-${channel.channelId}`]
          ?.properties,
        brightness: brightness,
      },
    });

    if (onLEDBrightnessChange) {
      onLEDBrightnessChange(
        convertNormalChannelToElementInScene(channel),
        brightness,
        isGroup,
        convertGroupChannelToElementInScene(groupData)
      );
    }
  };

  const handleLEDBrightnessCommit = (
    channel,
    brightness,
    isGroup = false,
    groupData = null
  ) => {
    if (onLEDBrightnessCommit) {
      onLEDBrightnessCommit(
        convertNormalChannelToElementInScene(channel),
        brightness,
        isGroup,
        convertGroupChannelToElementInScene(groupData)
      );
    }
  };

  const handleShadeUp = (channel, isGroup = false, groupData = null) => {
    const currentOpenLevel =
      percentToNumber(
        channelStates[`${channel.deviceId}-${channel.channelId}`]?.openLevel
      ) ||
      percentToNumber(
        channelStates[`${channel.deviceId}-${channel.channelId}`]?.properties
          ?.openLevel
      ) ||
      0;
    const newOpenLevel =
      channel?.deviceType?.toLowerCase() === "shade_lutron"
        ? 100
        : Math.min(100, currentOpenLevel + 10);

    updateChannelState(channel.deviceId, channel.channelId, {
      openLevel: `${newOpenLevel}%`,
      properties: {
        ...channelStates[`${channel.deviceId}-${channel.channelId}`]
          ?.properties,
        openLevel: `${newOpenLevel}%`,
      },
    });

    if (onShadeUp) {
      onShadeUp(
        channel,
        isGroup,
        convertGroupChannelToElementInScene(groupData)
      );
    }
  };

  const handleShadeDown = (channel, isGroup = false, groupData = null) => {
    const currentOpenLevel =
      percentToNumber(
        channelStates[`${channel.deviceId}-${channel.channelId}`]?.openLevel
      ) ||
      percentToNumber(
        channelStates[`${channel.deviceId}-${channel.channelId}`]?.properties
          ?.openLevel
      ) ||
      0;
    const newOpenLevel =
      channel?.deviceType?.toLowerCase() === "shade_lutron"
        ? 0
        : Math.max(0, currentOpenLevel - 10);

    updateChannelState(channel.deviceId, channel.channelId, {
      openLevel: `${newOpenLevel}%`,
      properties: {
        ...channelStates[`${channel.deviceId}-${channel.channelId}`]
          ?.properties,
        openLevel: `${newOpenLevel}%`,
      },
    });

    if (onShadeDown) {
      onShadeDown(
        channel,
        isGroup,
        convertGroupChannelToElementInScene(groupData)
      );
    }
  };

  const handleShadeStop = (channel, isGroup = false, groupData = null) => {
    if (onShadeStop) {
      onShadeStop(
        channel,
        isGroup,
        convertGroupChannelToElementInScene(groupData)
      );
    }
  };

  const handleShade33 = (channel, isGroup = false, groupData = null) => {
    updateChannelState(channel.deviceId, channel.channelId, {
      openLevel: "33%",
      properties: {
        ...channelStates[`${channel.deviceId}-${channel.channelId}`]
          ?.properties,
        openLevel: "33%",
      },
    });

    if (onShade33) {
      onShade33(
        channel,
        isGroup,
        convertGroupChannelToElementInScene(groupData)
      );
    }
  };

  const handleShade66 = (channel, isGroup = false, groupData = null) => {
    updateChannelState(channel.deviceId, channel.channelId, {
      openLevel: "66%",
      properties: {
        ...channelStates[`${channel.deviceId}-${channel.channelId}`]
          ?.properties,
        openLevel: "66%",
      },
    });

    if (onShade66) {
      onShade66(
        channel,
        isGroup,
        convertGroupChannelToElementInScene(groupData)
      );
    }
  };

  return (
    <div className="w-full h-full flex flex-col">
      <div className="flex-grow">
        {pageIndex === 0 ? (
          <MainSceneChannel
            data={data}
            canControl={canControl}
            onSceneExecute={onSceneExecute}
            sceneBrightness={sceneBrightness}
            handleBrightnessChange={handleBrightnessChange}
            handleBrightnessCommit={handleBrightnessCommit}
            shouldShowBrightness={
              data?.scene_brightness === null ||
              data?.scene_brightness === undefined
                ? false
                : true
            }
          />
        ) : data?.sceneDetails?.type === "group" ? (
          <GroupPage
            group={data?.sceneDetails?.groups?.[pageIndex - 1]}
            onLEDToggle={handleLEDToggle}
            onLEDBrightnessChange={handleLEDBrightnessChange}
            onLEDBrightnessCommit={handleLEDBrightnessCommit}
            onShadeUp={handleShadeUp}
            onShadeDown={handleShadeDown}
            onShadeStop={handleShadeStop}
            onShade33={handleShade33}
            onShade66={handleShade66}
            channelStates={channelStates}
            canControl={canControl}
          />
        ) : (
          <DevicePage
            device={data?.sceneDetails?.devices?.[pageIndex - 1]}
            onLEDToggle={handleLEDToggle}
            onLEDBrightnessChange={handleLEDBrightnessChange}
            onLEDBrightnessCommit={handleLEDBrightnessCommit}
            onShadeUp={handleShadeUp}
            onShadeDown={handleShadeDown}
            onShadeStop={handleShadeStop}
            onShade33={handleShade33}
            onShade66={handleShade66}
            channelStates={channelStates}
            canControl={canControl}
          />
        )}
      </div>
      {pageCount > 1 && (
        <div className="flex items-center justify-center gap-2 py-4">
          {Array.from({ length: pageCount }, (_, pIndex) => (
            <button
              key={pIndex}
              onClick={() => setPageIndex(pIndex)}
              className={`w-2 h-2 rounded-full transition-colors ${
                pageIndex === pIndex ? "bg-[#4A90E2]" : "bg-[#CCCCCC]"
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default SceneTemplateCard;
