import { useState, useEffect } from "react";
import { useDebouncedCallback } from "use-debounce";
import {
  useGetDeviceListInControlSystem,
  useTriggerEvent,
} from "../../api/queryHooks";
import {
  PermissionDenied,
  PrimaryBtn2,
  SearchInput,
  SpinnerV1,
} from "../../components";
import useUserStore from "../../store/useUserStore";
import toaster from "../../utils/toaster";

const RebootDevice = ({ device }) => {
  const { mutate: triggerEvent, isLoading } = useTriggerEvent();

  const handleClick = () => {
    const payload = {
      device_id: device.id,
      type: "reboot",
    };

    triggerEvent(payload, {
      onSuccess: () => {
        // onSuccess logic here
        toaster.success("Device reboot successfully");
      },
      onError: (error) => {
        // onError logic here
        toaster.error(
          error?.response?.data?.message || "Failed to send reboot command"
        );
      },
    });
  };

  return <PrimaryBtn2 onClick={handleClick}>{isLoading ? "Rebooting..." : "Reboot"}</PrimaryBtn2>;
};

const DeviceCard = ({ device, onClick, isSelected }) => {
  const userPermissions = useUserStore((state) => state.permissions);
  const canControl = userPermissions?.CONTROL_SECTION?.device_tab?.addModify;

  return (
    <div
      title={device.name}
      className={`cursor-pointer p-[10px] rounded-[10px] border truncate  ${
        isSelected ? "border-[#227EEB]" : "border-[#DDDDDD]"
      }`}
      onClick={onClick}
    >
      <div className="flex justify-between truncate">
        <div className="truncate mr-2">
          <h2 className="text-sm text-[#222222] font-semibold truncate">
            {device.name}
          </h2>
          <p className="text-xs text-[#939CA7] truncate">{device.id}</p>
        </div>
        {canControl ? (
          <div>
            <RebootDevice device={device} />
          </div>
        ) : null}
      </div>
    </div>
  );
};

function DevicesListing({ selectedItem, handleSelectItem, onDataLoaded }) {
  const [searchTerm, setSearchTerm] = useState("");
  const userPermissions = useUserStore((state) => state.permissions);
  const { data: devicesData, isLoading } = useGetDeviceListInControlSystem(searchTerm);

  const debouncedSearch = useDebouncedCallback((value) => {
    setSearchTerm(value);
  }, 300);

  const devices = devicesData?.data?.devices || [];

  // Call onDataLoaded when data is available and not loading
  useEffect(() => {
    if (!isLoading && onDataLoaded && devices.length > 0) {
      const formattedItems = devices.map(device => ({ 
        ...device, 
        id: device.device_id, 
        on: "device" 
      }));
      onDataLoaded(formattedItems);
    } else if (!isLoading && onDataLoaded && devices.length === 0) {
      onDataLoaded([]);
    }
  }, [isLoading, devices, onDataLoaded]);

  if (!userPermissions?.CONTROL_SECTION?.device_tab?.readOnly)
    return (
      <PermissionDenied
        className="mt-40 text-center"
        text="You do not have permission to modify devices."
      />
    );
  return (
    <>
      <div className="p-5 mb-5 border-b border-[#DDDDDD]">
        <SearchInput 
          placeholder="Search by devices name…" 
          onChange={(e) => debouncedSearch(e.target.value)}
        />
      </div>
      <div className="overflow-auto">
        {isLoading ? (
          <div className="p-5">
            <SpinnerV1 />
          </div>
        ) : devicesData?.data?.devices?.length ? (
          <div className="grid grid-cols-2 px-5 pb-5 gap-5">
            {devices.map((device) => {
              const formatedDevice = {
                ...device,
                id: device.device_id,
              };

              return (
                <DeviceCard
                  key={formatedDevice.id}
                  device={formatedDevice}
                  onClick={() =>
                    handleSelectItem({
                      ...formatedDevice,
                      on: "device",
                    })
                  }
                  isSelected={selectedItem?.id === formatedDevice.id}
                />
              );
            })}
          </div>
        ) : (
          <div className="text-center text-sm">No devices found.</div>
        )}
      </div>
    </>
  );
}

export default DevicesListing;
