import { PrimaryDropdown } from "../../components";
import useUserStore from "../../store/useUserStore";

function Header() {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="flex items-center justify-between">
      <h2 className="text-[#222222] font-bold">Control System</h2>
      <div className="flex items-center gap-[15px]">
        {/* {userPermissions?.CONTROL_SECTION?.filter?.addModify ? ( */}
        {false ? (
          <div className="flex items-center gap-[10px]">
            <span className="text-[12px]">Filters:</span>
            <PrimaryDropdown
              className="w-[200px]"
              options={[
                { value: "1", label: "Kalpataru Grandeur" },
                { value: "2", label: "Kalpataru Grandeur" },
                { value: "3", label: "Kalpataru Grandeur" },
                { value: "4", label: "Kalpataru Grandeur" },
              { value: "5", label: "Kalpataru Grandeur" },
              { value: "6", label: "Kalpataru Grandeur" },
              { value: "7", label: "Kalpataru Grandeur" },
              { value: "8", label: "Kalpataru Grandeur" },
              { value: "9", label: "Kalpataru Grandeur" },
              { value: "10", label: "Kalpataru Grandeur" },
            ]}
            // value={}
            // onValueChange={}
            // onBlur={}
            placeholder="Select Campus"
          />
          <PrimaryDropdown
            className="w-[200px]"
            options={[
              { value: "1", label: "Kalpataru Grandeur" },
              { value: "2", label: "Kalpataru Grandeur" },
              { value: "3", label: "Kalpataru Grandeur" },
              { value: "4", label: "Kalpataru Grandeur" },
              { value: "5", label: "Kalpataru Grandeur" },
              { value: "6", label: "Kalpataru Grandeur" },
              { value: "7", label: "Kalpataru Grandeur" },
              { value: "8", label: "Kalpataru Grandeur" },
              { value: "9", label: "Kalpataru Grandeur" },
              { value: "10", label: "Kalpataru Grandeur" },
            ]}
            // value={}
            // onValueChange={}
            // onBlur={}
            placeholder="Select Building"
          />
          <PrimaryDropdown
            className="w-[200px]"
            options={[
              { value: "1", label: "Kalpataru Grandeur" },
              { value: "2", label: "Kalpataru Grandeur" },
              { value: "3", label: "Kalpataru Grandeur" },
              { value: "4", label: "Kalpataru Grandeur" },
              { value: "5", label: "Kalpataru Grandeur" },
              { value: "6", label: "Kalpataru Grandeur" },
              { value: "7", label: "Kalpataru Grandeur" },
              { value: "8", label: "Kalpataru Grandeur" },
              { value: "9", label: "Kalpataru Grandeur" },
              { value: "10", label: "Kalpataru Grandeur" },
            ]}
            // value={}
            // onValueChange={}
            // onBlur={}
            placeholder="Select Floor"
          />
          <PrimaryDropdown
            className="w-[200px]"
            options={[
              { value: "1", label: "Kalpataru Grandeur" },
              { value: "2", label: "Kalpataru Grandeur" },
              { value: "3", label: "Kalpataru Grandeur" },
              { value: "4", label: "Kalpataru Grandeur" },
              { value: "5", label: "Kalpataru Grandeur" },
              { value: "6", label: "Kalpataru Grandeur" },
              { value: "7", label: "Kalpataru Grandeur" },
              { value: "8", label: "Kalpataru Grandeur" },
              { value: "9", label: "Kalpataru Grandeur" },
              { value: "10", label: "Kalpataru Grandeur" },
            ]}
            // value={}
            // onValueChange={}
            // onBlur={}
            placeholder="Select Zone"
          />
        </div>
        ) : null}
      </div>
    </div>
  );
}export default Header;
