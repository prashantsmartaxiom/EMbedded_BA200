import { useMemo, useState } from "react";
import Header from "./Header";
import TemplatesListing from "./TemplatesListing";
import ScenesListing from "./ScenesListing";
import GroupsListing from "./GroupsListing";
import DevicesListing from "./DevicesListing";
import ControlTabBtn from "./ControlTabBtn";
import { CircleInfoSvg } from "../../assets/svg";
import SceneView from "./Views/SceneView";
import GroupView from "./Views/GroupView";
import DeviceView from "./Views/DeviceView";
import TemplateView from "./Views/TemplateView";

const TABS = {
  TEMPLATES: "Templates",
  SCENES: "Scenes",
  GROUPS: "Groups",
  DEVICES: "Devices",
};

function SelectedNoneView({ tab }) {
  return (
    <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] flex-grow overflow-auto flex flex-col items-center justify-center">
      <CircleInfoSvg className="text-[#7A838E]" />
      <h2 className="text-[13px] text-[#7A838E]">
        Choose {tab?.toLowerCase().slice(0, -1)} to control directly
      </h2>
    </div>
  );
}

function ControlSystem() {
  // const { data: allDevices, isLoading, isError } = useGetAllDevices();

  const [state, setState] = useState({
    tab: TABS.TEMPLATES,
  });

  const [selectedItem, setSelectedItem] = useState(null);

  const handleTabClick = (tab) => {
    setState({ tab });
    // Reset selected item when tab changes
    setSelectedItem(null);
  };

  const handleSelectItem = (item) => {
    setSelectedItem(item);
  };

  // Callback to handle when listing data is loaded and auto-select first item
  const handleDataLoaded = (items, tabType) => {
    // Only auto-select if no item is currently selected and this is the active tab
    if (!selectedItem && state.tab === tabType && items && items.length > 0) {
      setSelectedItem(items[0]);
    }
  };

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex flex-col">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header />
      </div>
      <div className="mt-5 flex flex-grow w-full gap-5 min-h-0">
        <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] max-w-[540px] min-w-[540px] w-1/3 flex flex-col flex-shrink-0 overflow-hidden">
          <div className="flex items-center border-b-2 border-[#DDDDDD]">
            <ControlTabBtn
              isActive={state.tab === TABS.TEMPLATES}
              title={"Templates"}
              onClick={() => handleTabClick(TABS.TEMPLATES)}
            />
            <ControlTabBtn
              isActive={state.tab === TABS.SCENES}
              title={"Scenes"}
              onClick={() => handleTabClick(TABS.SCENES)}
            />
            <ControlTabBtn
              isActive={state.tab === TABS.GROUPS}
              title={"Groups"}
              onClick={() => handleTabClick(TABS.GROUPS)}
            />
            <ControlTabBtn
              isActive={state.tab === TABS.DEVICES}
              title={"Devices"}
              onClick={() => handleTabClick(TABS.DEVICES)}
            />
          </div>

          {state.tab === TABS.TEMPLATES ? (
            <TemplatesListing
              selectedItem={selectedItem}
              handleSelectItem={handleSelectItem}
              onDataLoaded={(items) => handleDataLoaded(items, TABS.TEMPLATES)}
            />
          ) : state.tab === TABS.SCENES ? (
            <ScenesListing
              selectedItem={selectedItem}
              handleSelectItem={handleSelectItem}
              onDataLoaded={(items) => handleDataLoaded(items, TABS.SCENES)}
              // isLoading={isLoading}
              // data={allDevices?.data?.scenes}
            />
          ) : state.tab === TABS.GROUPS ? (
            <GroupsListing
              selectedItem={selectedItem}
              handleSelectItem={handleSelectItem}
              onDataLoaded={(items) => handleDataLoaded(items, TABS.GROUPS)}
              // isLoading={isLoading}
              // data={allDevices?.data?.groups}
            />
          ) : (
            <DevicesListing
              selectedItem={selectedItem}
              handleSelectItem={handleSelectItem}
              onDataLoaded={(items) => handleDataLoaded(items, TABS.DEVICES)}
              // isLoading={isLoading}
              // data={allDevices?.data?.devices}
            />
          )}
        </div>

        {selectedItem?.on === "scene" ? (
          <SceneView selectedItem={selectedItem} />
        ) : selectedItem?.on === "group" ? (
          <GroupView selectedItem={selectedItem} />
        ) : selectedItem?.on === "device" ? (
          <DeviceView selectedItem={selectedItem} />
        ) : selectedItem?.on === "template" ? (
          <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] flex-grow overflow-auto">
            <TemplateView selectedItem={selectedItem} />
          </div>
        ) : (
          <SelectedNoneView tab={state.tab} />
        )}
      </div>
    </div>
  );
}

export default ControlSystem;
