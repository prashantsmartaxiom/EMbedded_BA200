import { InvertSvg, LEDonSvg, LEDSvg, SensorSvg } from "../../../assets/svg";
import ShadeImage from "../../../assets/images/Shade.png";
import { useGetSceneById } from "../../../api/queryHooks";
import {
  CurtainSvg,
  DeviceStatusChanged,
  SpinnerV1,
} from "../../../components";
import CONFIG from "../../../config";
import QUERY_KEYS from "../../../api/queryKeys";
import { useQueryClient } from "react-query";
import { percentToNumber } from "../../../utils/helpers";

const ChannelItem = ({ channel }) => {
  if (channel?.channelType === "led") {
    return (
      <div className="flex flex-col justify-center items-center truncate">
        {channel?.channelStatus === "on" && channel?.brightness > 0 ? (
          <LEDonSvg
            className="w-[60px] h-[60px]"
            title={`Brightness: ${channel?.brightness}`}
          />
        ) : (
          <LEDSvg
            className="w-[60px] h-[60px]"
            title={`Brightness: ${channel?.brightness}`}
          />
        )}
        <h2 title={channel?.channelName} className="w-full truncate text-[12px] text-[#7A838E] text-center mt-2 mb-2">
          {channel?.channelName}
        </h2>
      </div>
    );
  }

  if (channel?.channelType === "shade") {
    return (
      <div className="flex flex-col justify-center items-center truncate">
        <CurtainSvg title={`Open Level: ${channel?.openLevel}`} className="h-[60px]" openValue={percentToNumber(channel?.openLevel)} />
        <h2 title={channel?.channelName} className="w-full truncate text-[12px] text-[#7A838E] text-center mt-2 mb-2">
          {channel?.channelName}
        </h2>
      </div>
    );
  }

  if (channel?.channelType === "sensor") {
    return (
      <div className="flex flex-col justify-center items-center truncate">
        <SensorSvg className="w-[60px] h-[60px]" />
        <h2 title={channel?.channelName} className="w-full truncate text-[12px] text-[#7A838E] text-center mt-2 mb-2">
          {channel?.channelName}
        </h2>
      </div>
    );
  }

  return null;
};

function parseChannelsByGroupOrDevice(data) {
  if (data.groups && data.groups.length > 0) {
    return data.groups.map((group) => ({
      type: "group",
      id: group.groupId,
      name: group.groupName,
      channels: group.devices.flatMap((device) => device.sceneChannels),
    }));
  } else if (data.devices && data.devices.length > 0) {
    return data.devices.map((device) => ({
      type: "device",
      id: device.deviceId,
      name: device.deviceName,
      channels: device.sceneChannels,
    }));
  }
  return [];
}

function SceneView({ selectedItem }) {
  const { data: scenesData, isLoading } = useGetSceneById(selectedItem?._id, {
    refetchInterval: CONFIG.REFETCH_INTERVAL,
  });

  const queryClient = useQueryClient();
  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.GET_ALL_SCENES_IN_CONTROL_SYSTEM],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.SCENES],
      exact: false,
    });
  };

  const groupsOrDevices = parseChannelsByGroupOrDevice(scenesData?.data || {});

  if (isLoading) {
    return (
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] flex-grow overflow-auto flex items-center justify-center">
        <SpinnerV1 />
      </div>
    );
  }

  return (
    <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] flex-grow overflow-auto">
      <DeviceStatusChanged callback={realTimeChangeCallback} />
      <div className="flex items-center px-5 py-3 border-b border-[#DDDDDD]">
        <h2 className="text-base text-[#222222] font-semibold">
          {selectedItem?.name}
        </h2>
        {selectedItem?.operateType === "invert" ? (
          <div className="ml-2 flex-shrink-0 w-[22px] h-[20px] flex items-center justify-center bg-[#939CA7] rounded-[5px]">
            <InvertSvg className="fill-white" />
          </div>
        ) : null}
      </div>

      <div className="p-5 space-y-5">
        {groupsOrDevices.map((item) => (
          <div
            key={`${item.type}-${item.id}`}
            className="border border-[#C0DAF9] bg-[#F5F9FD] rounded-lg"
          >
            <div className="flex items-center justify-between mx-3 py-3 mb-5 border-b border-[#DDDDDD]">
              <h2 className="text-xs text-[#222222] font-semibold">
                {item.name ||
                  `${item.type === "group" ? "Group" : "Device"} ${item.id}`}
              </h2>
              <span className="text-xs text-[#7A838E] capitalize">
                {item.type}
              </span>
            </div>
            <div className="grid grid-cols-5 gap-[32px] mb-5 px-5">
              {item.channels?.map((channel) => (
                <ChannelItem key={channel?.channelId} channel={channel} />
              ))}
            </div>
          </div>
        ))}

        {groupsOrDevices.length === 0 && (
          <div className="border border-[#C0DAF9] bg-[#F5F9FD] rounded-lg">
            <div className="flex items-center justify-center py-10">
              <p className="text-sm text-[#7A838E]">
                No channels configured for this scene
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default SceneView;
