import { useState, useCallback, useRef, useEffect } from "react";
import {
  LEDSvg,
  LEDonSvg,
  MdArrowDownSvg,
  SensorSvg,
  StopSvg,
  ShadeSSSvg,
  ShadeTTSvg,
  BackspaceSvg,
} from "../../../assets/svg";
import { IoChevronBackOutline, IoChevronForwardOutline } from "react-icons/io5";
import {
  CurtainSvg,
  DeviceStatusChanged,
  RangeSlider,
} from "../../../components";
import { useGetGroupById, useTriggerEvent } from "../../../api/queryHooks";
import useUserStore from "../../../store/useUserStore";
import CONFIG from "../../../config";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../../api/queryKeys";
import toaster from "../../../utils/toaster";

const LEDCard = ({
  channel,
  deviceId,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit,
  channelStates,
  canControl = true, // New prop for permission control
}) => {
  const currentState = channelStates[`${deviceId}-${channel.id}`] || channel;
  const isOn = currentState.status === "on";
  const brightness = parseInt(currentState.properties?.brightness || 0);
  const powerMin = 0;
  const powerMax = 100;
  // const powerMin = parseInt(currentState.properties?.powerMin || 0);
  // const powerMax = parseInt(currentState.properties?.powerMax || 100);

  return (
    <div
      title={channel.name}
      className="flex flex-col justify-center items-center"
    >
      <div
        className={`${canControl ? "cursor-pointer" : "cursor-not-allowed"}`}
        onClick={() => canControl && onLEDToggle(channel, deviceId)}
      >
        {isOn ? (
          <LEDonSvg className="w-[60px] h-[60px]" />
        ) : (
          <LEDSvg className="w-[60px] h-[60px]" />
        )}
      </div>
      <h2 className="w-full truncate text-[12px] text-[#7A838E] text-center mt-2 mb-2">
        {channel.name}
      </h2>
      <RangeSlider
        min={powerMin}
        max={powerMax}
        value={brightness}
        onChange={(value) => onLEDBrightnessChange(channel, value, deviceId)}
        onValueCommit={(value) =>
          onLEDBrightnessCommit(channel, value, deviceId)
        }
        disabled={!isOn || !canControl}
        tooltipPosition="bottom"
      />
    </div>
  );
};

const SensorCard = ({ channel }) => {
  return (
    <div
      title={channel.name}
      className="flex flex-col justify-center items-center"
    >
      <SensorSvg
        className={`w-[60px] h-[60px] ${
          channel.status === "active" ? "text-blue-500" : "text-gray-400"
        }`}
      />
      <h2 className="w-full truncate text-[12px] text-[#7A838E] text-center mt-2 mb-2">
        {channel.name}
      </h2>
      <div className="text-sm text-center text-gray-600">
        {channel.status || "inactive"}
      </div>
    </div>
  );
};

const ShadeCard = ({
  channel,
  deviceId,
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  channelStates,
  canControl = true, // New prop for permission control
  device, // Add device prop
}) => {
  const currentState = channelStates[`${deviceId}-${channel.id}`] || channel;
  const openLevel = parseInt(
    currentState.properties?.openLevel?.replace?.("%", "") || 0
  );
  const isFullyOpen = openLevel >= 100;
  const isFullyClosed = openLevel <= 0;

  return (
    <div
      title={channel.name}
      className="flex flex-col justify-center items-center"
    >
      <CurtainSvg openValue={openLevel} className="h-[60px] w-[60px]" />
      <h2 className="w-full truncate text-[12px] text-[#7A838E] text-center mt-2">
        {channel.name}
      </h2>
      <div className="text-xs text-center text-gray-600 mb-1">
        {device?.device_type?.toLowerCase() === "shade_lutron"
          ? `${channel?.properties?.numberOfCmds || 3}/4 commands`
          : ``}
      </div>
      <div className="w-full flex items-center justify-center mt-1">
        <div
          className="bg-[#F5F9FD] border border-[#CCCCCC] rounded-lg grid text-[#222222]"
          style={{
            gridTemplateColumns:
              channel?.properties?.numberOfCmds === 4
                ? "repeat(4, 1fr)"
                : "repeat(3, 1fr)",
          }}
        >
          <button
            className={`flex items-center justify-center px-1 py-[3px] w-[35px] h-[30px] hover:bg-gray-100 ${
              device?.device_type?.toLowerCase() === "shade_lutron"
                ? "cursor-pointer"
                : !canControl || isFullyOpen
                ? "opacity-50 cursor-not-allowed"
                : "cursor-pointer"
            }`}
            onClick={() =>
              device?.device_type?.toLowerCase() === "shade_lutron"
                ? canControl && onShadeUp(channel, deviceId)
                : canControl && !isFullyOpen && onShadeUp(channel, deviceId)
            }
            disabled={
              device?.device_type?.toLowerCase() === "shade_lutron"
                ? !canControl
                : !canControl || isFullyOpen
            }
          >
            <MdArrowDownSvg className="rotate-180 w-[12px] h-[12px]" />
          </button>

          {channel?.properties?.numberOfCmds === 4 ? (
            <>
              <button
                className={`border-l border-[#CCCCCC] flex items-center justify-center px-1 py-[3px] w-[35px] h-[30px] hover:bg-gray-100 ${
                  canControl ? "cursor-pointer" : "cursor-not-allowed"
                }`}
                onClick={() => canControl && onShade66(channel, deviceId)}
                disabled={!canControl}
              >
                <ShadeSSSvg className="w-[14px] h-[14px]" />
              </button>
              <button
                className={`border-l border-[#CCCCCC] flex items-center justify-center px-1 py-[3px] w-[35px] h-[30px] hover:bg-gray-100 ${
                  canControl ? "cursor-pointer" : "cursor-not-allowed"
                }`}
                onClick={() => canControl && onShade33(channel, deviceId)}
                disabled={!canControl}
              >
                <ShadeTTSvg className="w-[14px] h-[14px]" />
              </button>
            </>
          ) : (
            <button
              className={`border-l border-r border-[#CCCCCC] flex items-center justify-center px-1 py-[3px] w-[35px] h-[30px] hover:bg-gray-100 ${
                canControl ? "cursor-pointer" : "cursor-not-allowed"
              }`}
              onClick={() => canControl && onShadeStop(channel, deviceId)}
              disabled={!canControl}
            >
              <StopSvg className="w-[20px] h-[20px]" />
            </button>
          )}

          <button
            className={`${
              channel?.properties?.numberOfCmds === 4
                ? "border-l border-[#CCCCCC]"
                : ""
            } flex items-center justify-center px-1 py-[3px] w-[35px] h-[30px] hover:bg-gray-100 ${
              device?.device_type?.toLowerCase() === "shade_lutron"
                ? "cursor-pointer"
                : !canControl || isFullyClosed
                ? "opacity-50 cursor-not-allowed"
                : "cursor-pointer"
            }`}
            onClick={() =>
              device?.device_type?.toLowerCase() === "shade_lutron"
                ? canControl && onShadeDown(channel, deviceId)
                : canControl && !isFullyClosed && onShadeDown(channel, deviceId)
            }
            disabled={
              device?.device_type?.toLowerCase() === "shade_lutron"
                ? !canControl
                : !canControl || isFullyClosed
            }
          >
            <MdArrowDownSvg className="w-[12px] h-[12px]" />
          </button>
        </div>
      </div>
    </div>
  );
};

function GroupView({ selectedItem, groupData: propGroupData, usedIn = "" }) {
  const [channelStates, setChannelStates] = useState({});
  const [scrollPosition, setScrollPosition] = useState(0);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);
  const scrollContainerRef = useRef(null);
  
  const { data: fetchedGroupData } = useGetGroupById(selectedItem?.id, {
    enabled: !propGroupData, // Only fetch if groupData is not provided via props
    onSuccess: () => {
      setChannelStates({});
    },
    refetchInterval: CONFIG.REFETCH_INTERVAL,
  });

  // Use prop data if available, otherwise use fetched data
  const groupData = propGroupData || fetchedGroupData;

  // Update scroll button states
  const updateScrollStates = () => {
    if (scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      const { scrollLeft, scrollWidth, clientWidth } = container;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 1);
      setScrollPosition(scrollLeft);
    }
  };

  // Scroll navigation functions for dashboard
  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      const scrollAmount = 120; // Adjusted for 80% size channels
      const newPosition = Math.max(0, scrollPosition - scrollAmount);
      container.scrollTo({ left: newPosition, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      const scrollAmount = 120; // Adjusted for 80% size channels
      const maxScroll = container.scrollWidth - container.clientWidth;
      const newPosition = Math.min(maxScroll, scrollPosition + scrollAmount);
      container.scrollTo({ left: newPosition, behavior: 'smooth' });
    }
  };

  const queryClient = useQueryClient();
  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.GET_ALL_GROUPS_IN_CONTROL_SYSTEM],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.GROUPS],
      exact: false,
    });
  };

  const { user } = useUserStore();
  const userPermissions = useUserStore((state) => state.permissions);
  const canControl = userPermissions?.CONTROL_SECTION?.group_tab?.addModify;

  // Extract data from API response
  const groupInfo = groupData?.data?.group;
  const devices = groupData?.data?.devices || [];

  // Update scroll states when component mounts or data changes
  useEffect(() => {
    const timer = setTimeout(() => {
      updateScrollStates();
    }, 100);
    return () => clearTimeout(timer);
  }, [devices, usedIn]);

  const triggerEventMutation = useTriggerEvent({
    onSuccess: (response) => {},
    onError: (error) => {
      console.error("Event trigger failed:", error);
    },
  });

  const getChannelKey = (channel, deviceId) => `${deviceId}-${channel.id}`;

  const getUserData = () => ({
    userId: user?.id,
  });

  const handleLEDToggle = useCallback(
    (channel, deviceId) => {
      const key = getChannelKey(channel, deviceId);
      const currentState = channelStates[key] || channel;
      const newStatus = currentState.status === "on" ? "off" : "on";

      // Check if this is a main channel operation
      if (channel.isMainChannel) {
        // Get all LED channels from all devices
        const allLedChannels = [];
        devices?.forEach((device) => {
          device?.group_channels?.forEach((ch) => {
            if (ch?.type === "led") {
              allLedChannels.push({
                ...ch,
                deviceId: device.device_id,
                channelId: ch.id,
                channelType: ch.type,
              });
            }
          });
        });

        const updatedStates = {};

        // Update all LED channels to match the main channel
        allLedChannels.forEach((ch) => {
          const chKey = getChannelKey(ch, ch.deviceId);
          const chCurrentState = channelStates[chKey] || ch;
          updatedStates[chKey] = {
            ...chCurrentState,
            status: newStatus,
          };
        });

        setChannelStates((prev) => ({
          ...prev,
          ...updatedStates,
        }));

        // Call group API
        const userData = getUserData();
        const groupedDevices = Object.values(
          allLedChannels.reduce((acc, item) => {
            if (!acc[item.deviceId]) {
              acc[item.deviceId] = {
                deviceId: item.deviceId,
                channels: [],
              };
            }

            acc[item.deviceId].channels.push({
              channelId: item.channelId,
              channelType:
                item.channelType?.toUpperCase() || item.type?.toUpperCase(),
            });

            return acc;
          }, {})
        );

        const firstChannel = allLedChannels[0];
        const payload = {
          ...userData,
          device_id: firstChannel?.deviceId,
          deviceData: { devices: groupedDevices },
          channelType: "",
          channelAddress: "",
          command: newStatus === "on" ? "GROUP_LED_ON" : "GROUP_LED_OFF",
          groupId: groupData?.data?.group?.id,
        };

        triggerEventMutation.mutate(payload);
      } else {
        // Individual channel toggle
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            status: newStatus,
          },
        }));

        const userData = getUserData();

        const payload = {
          ...userData,
          device_id: deviceId,
          deviceData:
            newStatus === "on"
              ? {
                  properties: {
                    brightness: parseInt(
                      currentState.properties?.brightness || 0
                    ),
                    // powerMin: 0,
                    // powerMax: 100,
                    powerMin: parseInt(currentState.properties?.powerMin || 0),
                    powerMax: parseInt(currentState.properties?.powerMax || 0),
                  },
                }
              : {},
          channelType: "LED",
          channelAddress: channel.id,
          command: newStatus === "on" ? "LED_ON" : "LED_OFF",
        };

        triggerEventMutation.mutate(payload);
      }
    },
    [channelStates, triggerEventMutation, devices, groupData]
  );

  const handleLEDBrightnessChange = useCallback(
    (channel, brightness, deviceId) => {
      const key = getChannelKey(channel, deviceId);
      const currentState = channelStates[key] || channel;

      if (channel.isMainChannel) {
        // Update all LED channels in the group for main channel
        const allLedChannels = [];
        devices?.forEach((device) => {
          device?.group_channels?.forEach((ch) => {
            if (ch?.type === "led") {
              allLedChannels.push({
                ...ch,
                deviceId: device.device_id,
              });
            }
          });
        });

        const updatedStates = {};
        allLedChannels.forEach((ch) => {
          const chKey = getChannelKey(ch, ch.deviceId);
          const chCurrentState = channelStates[chKey] || ch;
          updatedStates[chKey] = {
            ...chCurrentState,
            properties: {
              ...chCurrentState.properties,
              brightness: brightness,
            },
          };
        });

        setChannelStates((prev) => ({
          ...prev,
          ...updatedStates,
        }));
      } else {
        // Individual channel brightness change
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              brightness: brightness,
            },
          },
        }));
      }
    },
    [channelStates, devices]
  );

  const handleLEDBrightnessCommit = useCallback(
    (channel, brightness, deviceId) => {
      const key = getChannelKey(channel, deviceId);
      const currentState = channelStates[key] || channel;

      if (channel.isMainChannel) {
        // Call group brightness API for main channel
        const userData = getUserData();
        const allLedChannels = [];
        devices?.forEach((device) => {
          device?.group_channels?.forEach((ch) => {
            if (ch?.type === "led") {
              allLedChannels.push({
                ...ch,
                deviceId: device.device_id,
                channelId: ch.id,
                channelType: ch.type,
              });
            }
          });
        });

        const groupedDevices = Object.values(
          allLedChannels.reduce((acc, item) => {
            if (!acc[item.deviceId]) {
              acc[item.deviceId] = {
                deviceId: item.deviceId,
                channels: [],
              };
            }

            acc[item.deviceId].channels.push({
              channelId: item.channelId,
              channelType:
                item.channelType?.toUpperCase() || item.type?.toUpperCase(),
            });

            return acc;
          }, {})
        );

        const firstChannel = allLedChannels[0];
        const payload = {
          ...userData,
          device_id: firstChannel?.deviceId,
          deviceData: { devices: groupedDevices },
          channelType: "",
          channelAddress: "",
          command: `GROUP_LED_BRIGHTNESS${brightness}`,
        };

        triggerEventMutation.mutate(payload, {
          onSuccess: () => {
            toaster.success("Brightness updated successfully");
          },
          onError: (error) => {
            toaster.error(
              error?.response?.data?.message || "Failed to update brightness"
            );
          },
        });
      } else {
        // Individual channel brightness commit
        const userData = getUserData();

        const payload = {
          ...userData,
          device_id: deviceId,
          deviceData: {
            properties: {
              brightness: brightness,
              // powerMin: 0,
              // powerMax: 100,
              powerMin: parseInt(currentState.properties?.powerMin || 0),
              powerMax: parseInt(currentState.properties?.powerMax || 0),
            },
          },
          channelType: "LED",
          channelAddress: channel.id,
          command: "LED_BRIGHTNESS",
        };

        triggerEventMutation.mutate(payload, {
          onSuccess: () => {
            toaster.success("Brightness updated successfully");
          },
          onError: (error) => {
            toaster.error(
              error?.response?.data?.message || "Failed to update brightness"
            );
          },
        });
      }
    },
    [channelStates, triggerEventMutation, devices]
  );

  const handleShadeUp = useCallback(
    (channel, deviceId) => {
      const key = getChannelKey(channel, deviceId);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") || 0
      );

      if (channel.isMainChannel) {
        // Update all shade channels in the group for main channel
        const allShadeChannels = [];
        devices?.forEach((device) => {
          device?.group_channels?.forEach((ch) => {
            if (ch?.type === "shade") {
              allShadeChannels.push({
                ...ch,
                deviceId: device.device_id,
                channelId: ch.id,
                channelType: ch.type,
                deviceType: device.device_type,
              });
            }
          });
        });

        const updatedStates = {};
        allShadeChannels.forEach((ch) => {
          const chKey = getChannelKey(ch, ch.deviceId);
          const chCurrentState = channelStates[chKey] || ch;
          const chCurrentLevel = parseInt(
            chCurrentState.properties?.openLevel?.replace?.("%", "") || 0
          );

          const isLutronShade = ch.deviceType?.toLowerCase() === "shade_lutron";
          // const newLevel = isLutronShade
          //   ? 100
          //   : Math.min(100, chCurrentLevel + 10);
          const newLevel = 100;
          updatedStates[chKey] = {
            ...chCurrentState,
            properties: {
              ...chCurrentState.properties,
              openLevel: `${newLevel}%`,
            },
          };
        });

        setChannelStates((prev) => ({
          ...prev,
          ...updatedStates,
        }));

        // Call group API
        const userData = getUserData();
        const groupedDevices = Object.values(
          allShadeChannels.reduce((acc, item) => {
            if (!acc[item.deviceId]) {
              acc[item.deviceId] = {
                deviceId: item.deviceId,
                channels: [],
              };
            }

            acc[item.deviceId].channels.push({
              channelId: item.channelId,
              channelType:
                item.channelType?.toUpperCase() || item.type?.toUpperCase(),
              numberOfCmds: item?.properties?.numberOfCmds,
            });

            return acc;
          }, {})
        );

        const firstChannel = allShadeChannels[0];
        const payload = {
          ...userData,
          device_id: firstChannel?.deviceId,
          deviceData: { devices: groupedDevices },
          channelType: "",
          channelAddress: "",
          command: "GROUP_SHADE_UP",
          groupId: groupData?.data?.group?.id,
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      } else {
        // Individual shade up
        const device = devices.find((d) => d.device_id === deviceId);
        // const newLevel =
        //   device?.device_type?.toLowerCase() === "shade_lutron"
        //     ? 100
        //     : Math.min(100, currentLevel + 10);
        const newLevel = 100;

        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));

        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: deviceId,
          deviceData: {
            properties: {
              ...(device?.device_type?.toLowerCase() !== "shade_lutron" && {
                // openLevel: newLevel,
              }),
              numberOfCmds: channel?.properties?.numberOfCmds || null,
            },
          },
          channelType: "SHADE",
          channelAddress: channel.id,
          command: "SHADE_UP",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [channelStates, triggerEventMutation, devices, groupData]
  );

  const handleShadeDown = useCallback(
    (channel, deviceId) => {
      const key = getChannelKey(channel, deviceId);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") || 0
      );

      if (channel.isMainChannel) {
        // Update all shade channels in the group for main channel
        const allShadeChannels = [];
        devices?.forEach((device) => {
          device?.group_channels?.forEach((ch) => {
            if (ch?.type === "shade") {
              allShadeChannels.push({
                ...ch,
                deviceId: device.device_id,
                channelId: ch.id,
                channelType: ch.type,
                deviceType: device.device_type,
              });
            }
          });
        });

        const updatedStates = {};
        allShadeChannels.forEach((ch) => {
          const chKey = getChannelKey(ch, ch.deviceId);
          const chCurrentState = channelStates[chKey] || ch;
          const chCurrentLevel = parseInt(
            chCurrentState.properties?.openLevel?.replace?.("%", "") || 0
          );

          const isLutronShade = ch.deviceType?.toLowerCase() === "shade_lutron";
          // const newLevel = isLutronShade ? 0 : Math.max(0, chCurrentLevel - 10);
          const newLevel = 0;

          updatedStates[chKey] = {
            ...chCurrentState,
            properties: {
              ...chCurrentState.properties,
              openLevel: `${newLevel}%`,
            },
          };
        });

        setChannelStates((prev) => ({
          ...prev,
          ...updatedStates,
        }));

        // Call group API
        const userData = getUserData();
        const groupedDevices = Object.values(
          allShadeChannels.reduce((acc, item) => {
            if (!acc[item.deviceId]) {
              acc[item.deviceId] = {
                deviceId: item.deviceId,
                channels: [],
              };
            }

            acc[item.deviceId].channels.push({
              channelId: item.channelId,
              channelType:
                item.channelType?.toUpperCase() || item.type?.toUpperCase(),
              numberOfCmds: item?.properties?.numberOfCmds,
            });

            return acc;
          }, {})
        );

        const firstChannel = allShadeChannels[0];
        const payload = {
          ...userData,
          device_id: firstChannel?.deviceId,
          deviceData: { devices: groupedDevices },
          channelType: "",
          channelAddress: "",
          command: "GROUP_SHADE_DOWN",
          groupId: groupData?.data?.group?.id,
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      } else {
        // Individual shade down
        const device = devices.find((d) => d.device_id === deviceId);
        // const newLevel =
        //   device?.device_type?.toLowerCase() === "shade_lutron"
        //     ? 0
        //     : Math.max(0, currentLevel - 10);
        const newLevel = 0;

        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));

        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: deviceId,
          deviceData: {
            properties: {
              ...(device?.device_type?.toLowerCase() !== "shade_lutron" && {
                // openLevel: newLevel,
              }),
              numberOfCmds: channel?.properties?.numberOfCmds || null,
            },
          },
          channelType: "SHADE",
          channelAddress: channel.id,
          command: "SHADE_DOWN",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [channelStates, triggerEventMutation, devices, groupData]
  );

  const handleShadeStop = useCallback(
    (channel, deviceId) => {
      if (channel.isMainChannel) {
        // Call group API for shade stop
        const allShadeChannels = [];
        devices?.forEach((device) => {
          device?.group_channels?.forEach((ch) => {
            if (ch?.type === "shade") {
              allShadeChannels.push({
                ...ch,
                deviceId: device.device_id,
                channelId: ch.id,
                channelType: ch.type,
              });
            }
          });
        });

        const userData = getUserData();
        const groupedDevices = Object.values(
          allShadeChannels.reduce((acc, item) => {
            if (!acc[item.deviceId]) {
              acc[item.deviceId] = {
                deviceId: item.deviceId,
                channels: [],
              };
            }

            acc[item.deviceId].channels.push({
              channelId: item.channelId,
              channelType:
                item.channelType?.toUpperCase() || item.type?.toUpperCase(),
              numberOfCmds: item?.properties?.numberOfCmds,
            });

            return acc;
          }, {})
        );

        const firstChannel = allShadeChannels[0];
        const payload = {
          ...userData,
          device_id: firstChannel?.deviceId,
          deviceData: { devices: groupedDevices },
          channelType: "",
          channelAddress: "",
          command: "GROUP_SHADE_STOP",
          groupId: groupData?.data?.group?.id,
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      } else {
        // Individual shade stop
        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: deviceId,
          deviceData: {
            properties: {
              numberOfCmds: channel?.properties?.numberOfCmds || null,
            },
          },
          channelType: "SHADE",
          channelAddress: channel.id,
          command: "SHADE_STOP",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [triggerEventMutation, devices, groupData]
  );

  const handleShade33 = useCallback(
    (channel, deviceId) => {
      const key = getChannelKey(channel, deviceId);
      const currentState = channelStates[key] || channel;
      const newLevel = 33;

      if (channel.isMainChannel) {
        // Update all shade channels in the group for main channel
        const allShadeChannels = [];
        devices?.forEach((device) => {
          device?.group_channels?.forEach((ch) => {
            if (ch?.type === "shade") {
              allShadeChannels.push({
                ...ch,
                deviceId: device.device_id,
                channelId: ch.id,
                channelType: ch.type,
                deviceType: device.device_type,
              });
            }
          });
        });

        const updatedStates = {};
        allShadeChannels.forEach((ch) => {
          const chKey = getChannelKey(ch, ch.deviceId);
          const chCurrentState = channelStates[chKey] || ch;

          updatedStates[chKey] = {
            ...chCurrentState,
            properties: {
              ...chCurrentState.properties,
              openLevel: `${newLevel}%`,
            },
          };
        });

        setChannelStates((prev) => ({
          ...prev,
          ...updatedStates,
        }));

        // Call group API
        const userData = getUserData();
        const groupedDevices = Object.values(
          allShadeChannels.reduce((acc, item) => {
            if (!acc[item.deviceId]) {
              acc[item.deviceId] = {
                deviceId: item.deviceId,
                channels: [],
              };
            }

            acc[item.deviceId].channels.push({
              channelId: item.channelId,
              channelType:
                item.channelType?.toUpperCase() || item.type?.toUpperCase(),
              numberOfCmds: item?.properties?.numberOfCmds,
            });

            return acc;
          }, {})
        );

        const firstChannel = allShadeChannels[0];
        const payload = {
          ...userData,
          device_id: firstChannel?.deviceId,
          deviceData: { devices: groupedDevices },
          channelType: "",
          channelAddress: "",
          command: "GROUP_SHADE_33",
          groupId: groupData?.data?.group?.id,
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      } else {
        // Individual shade 33
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));

        const device = devices.find((d) => d.device_id === deviceId);
        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: deviceId,
          deviceData: {
            properties: {
              ...(device?.device_type?.toLowerCase() !== "shade_lutron" && {
                // openLevel: newLevel,
              }),
              numberOfCmds: channel?.properties?.numberOfCmds || null,
            },
          },
          channelType: "SHADE",
          channelAddress: channel.id,
          command: "SHADE_33",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [channelStates, triggerEventMutation, devices, groupData]
  );

  const handleShade66 = useCallback(
    (channel, deviceId) => {
      const key = getChannelKey(channel, deviceId);
      const currentState = channelStates[key] || channel;
      const newLevel = 66;

      if (channel.isMainChannel) {
        // Update all shade channels in the group for main channel
        const allShadeChannels = [];
        devices?.forEach((device) => {
          device?.group_channels?.forEach((ch) => {
            if (ch?.type === "shade") {
              allShadeChannels.push({
                ...ch,
                deviceId: device.device_id,
                channelId: ch.id,
                channelType: ch.type,
                deviceType: device.device_type,
              });
            }
          });
        });

        const updatedStates = {};
        allShadeChannels.forEach((ch) => {
          const chKey = getChannelKey(ch, ch.deviceId);
          const chCurrentState = channelStates[chKey] || ch;

          updatedStates[chKey] = {
            ...chCurrentState,
            properties: {
              ...chCurrentState.properties,
              openLevel: `${newLevel}%`,
            },
          };
        });

        setChannelStates((prev) => ({
          ...prev,
          ...updatedStates,
        }));

        // Call group API
        const userData = getUserData();
        const groupedDevices = Object.values(
          allShadeChannels.reduce((acc, item) => {
            if (!acc[item.deviceId]) {
              acc[item.deviceId] = {
                deviceId: item.deviceId,
                channels: [],
              };
            }

            acc[item.deviceId].channels.push({
              channelId: item.channelId,
              channelType:
                item.channelType?.toUpperCase() || item.type?.toUpperCase(),
              numberOfCmds: item?.properties?.numberOfCmds,
            });

            return acc;
          }, {})
        );

        const firstChannel = allShadeChannels[0];
        const payload = {
          ...userData,
          device_id: firstChannel?.deviceId,
          deviceData: { devices: groupedDevices },
          channelType: "",
          channelAddress: "",
          command: "GROUP_SHADE_66",
          groupId: groupData?.data?.group?.id,
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      } else {
        // Individual shade 66
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));

        const device = devices.find((d) => d.device_id === deviceId);
        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: deviceId,
          deviceData: {
            properties: {
              ...(device?.device_type?.toLowerCase() !== "shade_lutron" && {
                // openLevel: newLevel,
              }),
              numberOfCmds: channel?.properties?.numberOfCmds || null,
            },
          },
          channelType: "SHADE",
          channelAddress: channel.id,
          command: "SHADE_66",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [channelStates, triggerEventMutation, devices, groupData]
  );

  if (usedIn === "dashboard") {
    const channels = devices.flatMap((device) => device.group_channels || []);
    const main_channel = channels?.[0]
      ? {
          ...channels[0],
          isMainChannel: true,
          name: groupInfo?.name || channels[0].name,
        }
      : null;
    return (
      <div className="flex items-center gap-0 w-full border border-[#C0DAF9] bg-[#F5F9FD] rounded-lg">
        <div className="h-full flex justify-center w-[180px] flex-shrink-0 border-r border-[#C0DAF9]">
          <div 
            className="min-w-[120px]"
            style={{ 
              transform: 'scale(0.85)',
              transformOrigin: 'center'
            }}
          >
            {main_channel?.type === "led" ? (
              <LEDCard
                channel={main_channel}
                deviceId={devices[0]?.device_id}
                onLEDToggle={handleLEDToggle}
                onLEDBrightnessChange={handleLEDBrightnessChange}
                onLEDBrightnessCommit={handleLEDBrightnessCommit}
                channelStates={channelStates}
                canControl={canControl}
              />
            ) : main_channel?.type === "shade" ? (
              <ShadeCard
                channel={main_channel}
                deviceId={devices[0]?.device_id}
                onShadeUp={handleShadeUp}
                onShadeDown={handleShadeDown}
                onShadeStop={handleShadeStop}
                onShade33={handleShade33}
                onShade66={handleShade66}
                channelStates={channelStates}
                canControl={canControl}
                device={devices[0]}
              />
            ) : main_channel?.type === "sensor" ? (
              <SensorCard channel={main_channel} />
            ) : null}
          </div>
        </div>
        <div className="flex-grow overflow-hidden relative flex items-center">
          {/* Left Arrow */}
          <button
            onClick={scrollLeft}
            disabled={!canScrollLeft}
            className={`absolute left-2 z-10 transition-all ${
              !canScrollLeft 
                ? 'opacity-50 cursor-not-allowed' 
                : 'hover:bg-gray-50 cursor-pointer'
            }`}
          >
            <BackspaceSvg className="w-4 h-4 text-gray-600" />
          </button>

          {/* Scrollable Container */}
          <div 
            ref={scrollContainerRef}
            className="flex gap-4 ml-6 mr-6 overflow-x-auto hide-scrollbar"
            onScroll={updateScrollStates}
          >
            {devices?.map((device) => (
              <>
                {device?.group_channels?.map((channel) => (
                  <div 
                    key={`${device.device_id}-${channel.id}`}
                    className="flex-shrink-0"
                    style={{ 
                      width: '112px', // 80% of 140px 
                      transform: 'scale(0.75)',
                      transformOrigin: 'center'
                    }}
                  >
                    {channel?.type === "led" ? (
                      <LEDCard
                        channel={channel}
                        deviceId={device.device_id}
                        onLEDToggle={handleLEDToggle}
                        onLEDBrightnessChange={handleLEDBrightnessChange}
                        onLEDBrightnessCommit={handleLEDBrightnessCommit}
                        channelStates={channelStates}
                        canControl={canControl}
                      />
                    ) : channel?.type === "shade" ? (
                      <ShadeCard
                        channel={channel}
                        deviceId={device.device_id}
                        onShadeUp={handleShadeUp}
                        onShadeDown={handleShadeDown}
                        onShadeStop={handleShadeStop}
                        onShade33={handleShade33}
                        onShade66={handleShade66}
                        channelStates={channelStates}
                        canControl={canControl}
                        device={device}
                      />
                    ) : channel?.type === "sensor" ? (
                      <SensorCard channel={channel} />
                    ) : null}
                  </div>
                ))}
              </>
            ))}
          </div>

          {/* Right Arrow */}
          <button
            onClick={scrollRight}
            disabled={!canScrollRight}
            className={`absolute right-2 z-10 rotate-180 transition-all ${
              !canScrollRight
                ? 'opacity-50 cursor-not-allowed' 
                : 'hover:bg-gray-50 cursor-pointer'
            }`}
          >
            <BackspaceSvg className="w-4 h-4 text-gray-600" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] flex-grow overflow-auto">
      <DeviceStatusChanged callback={realTimeChangeCallback} />
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#DDDDDD]">
        <h2 className="text-base text-[#222222] font-semibold">
          {groupInfo?.name || selectedItem?.name}
        </h2>
        {/* <div className="w-[180px]">
          <span className="text-xs text-[#7A838E]">Brightness: </span>
          <RangeSlider 
            min={0}
            max={100}
            value={calculateGroupBrightness()}
            onChange={handleGroupBrightnessChange}
            onValueCommit={handleGroupBrightnessCommit}
            tooltipPosition="bottom" 
          />
        </div> */}
      </div>

      {devices?.map((device) => (
        <div className="p-5" key={device?.device_id}>
          <div className="border border-[#C0DAF9] bg-[#F5F9FD] rounded-lg">
            <div className="flex items-center justify-between mx-3 py-3 mb-5 border-b border-[#DDDDDD]">
              <h2 className="text-xs text-[#222222] font-semibold">
                {device?.device_name}
              </h2>
            </div>
            <div className="grid grid-cols-4 1540:grid-cols-5 gap-[32px] mb-5 px-5">
              {device?.group_channels?.map((channel) => (
                <div key={`${device.device_id}-${channel.id}`}>
                  {channel?.type === "led" ? (
                    <LEDCard
                      channel={channel}
                      deviceId={device.device_id}
                      onLEDToggle={handleLEDToggle}
                      onLEDBrightnessChange={handleLEDBrightnessChange}
                      onLEDBrightnessCommit={handleLEDBrightnessCommit}
                      channelStates={channelStates}
                      canControl={canControl}
                    />
                  ) : channel?.type === "shade" ? (
                    <ShadeCard
                      channel={channel}
                      deviceId={device.device_id}
                      onShadeUp={handleShadeUp}
                      onShadeDown={handleShadeDown}
                      onShadeStop={handleShadeStop}
                      onShade33={handleShade33}
                      onShade66={handleShade66}
                      channelStates={channelStates}
                      canControl={canControl}
                      device={device}
                    />
                  ) : channel?.type === "sensor" ? (
                    <SensorCard channel={channel} />
                  ) : null}
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default GroupView;
