import { useState, useCallback, useRef, useEffect } from "react";
import {
  CurtainSvg,
  DeviceStatusChanged,
  RangeSlider,
  SpinnerV1,
  Switch,
} from "../../../components";
import {
  LEDSvg,
  LEDonSvg,
  SensorSvg,
  MdArrowDownSvg,
  StopSvg,
  SceneSvg,
  SceneOnSvg,
  SceneOffSvg,
  ShadeSSSvg,
  ShadeTTSvg,
} from "../../../assets/svg";
import ShadeImage from "../../../assets/images/Shade.png";
import { useGetTemplatesById, useTriggerEvent } from "../../../api/queryHooks";
import useUserStore from "../../../store/useUserStore";
import toaster from "../../../utils/toaster";
import CONFIG from "../../../config";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../../api/queryKeys";
import SceneTemplateCard from "../SceneTemplateCard";
import GroupTemplateCard from "../GroupTemplateCard";
import WidgetTemplateCard from "../../CreateIntelligentControlTemplate/WidgetTemplateCard";
import {
  LandscapeLayout,
  PortraitLayout,
} from "../../CreateWidget/WidgetVisualizer";
import { getWidgetLayout } from "../../../utils/helpers";

const ShadeTemplateCard = ({
  data,
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  channelStates,
  canControl = true, // New prop for permission control
}) => {
  const currentState =
    channelStates[`${data.deviceId}-${data.channelId}`] || data;
  const openLevel = parseInt(
    currentState.properties?.openLevel?.replace?.("%", "") || 0
  );
  const isFullyOpen = openLevel >= 100;
  const isFullyClosed = openLevel <= 0;

  const isLutronShade = data?.deviceType?.toLowerCase() === "shade_lutron";
  return (
    <div className="w-full h-full flex flex-col items-center justify-center p-2 relative truncate">
      <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
        {data?.channelName || data?.name || data?.channelId}
      </h2>
      <div className="flex-1 flex items-center justify-center w-full h-full">
        {/* <img
          className="h-[60%] max-w-[120px] max-h-[120px]"
          src={ShadeImage}
          alt={data?.channelId || data?.name}
        /> */}
        <CurtainSvg
          openValue={openLevel}
          className="h-[60%] max-w-[120px] max-h-[120px]"
        />
      </div>
      <div className="text-xs text-center text-gray-600 mb-1">
        {isLutronShade
          ? `${data?.properties?.numberOfCmds || 3}/4 commands`
          : ``}
      </div>
      <div className="w-full flex items-center justify-center">
        <div
          className="h-[30px] bg-[#F5F9FD] border border-[#CCCCCC] rounded-lg w-full max-w-32 grid text-[#222222]"
          style={{
            gridTemplateColumns:
              data?.properties?.numberOfCmds === 4
                ? "repeat(4, 1fr)"
                : "repeat(3, 1fr)",
          }}
        >
          <button
            className={`flex items-center justify-center hover:bg-gray-100 ${
              !canControl || (!isLutronShade && isFullyOpen)
                ? "opacity-50 cursor-not-allowed"
                : "cursor-pointer"
            }`}
            onClick={() =>
              canControl &&
              (!isLutronShade ? !isFullyOpen : true) &&
              onShadeUp(data, false)
            }
            disabled={!canControl || (!isLutronShade && isFullyOpen)}
          >
            <MdArrowDownSvg className="rotate-180 w-[12px] h-[12px]" />
          </button>

          {data?.properties?.numberOfCmds === 4 ? (
            <>
              <button
                className={`border-l border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100 ${
                  canControl ? "cursor-pointer" : "cursor-not-allowed"
                }`}
                onClick={() => canControl && onShade66(data, false)}
                disabled={!canControl}
              >
                <ShadeSSSvg className="w-[14px] h-[14px]" />
              </button>
              <button
                className={`border-l border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100 ${
                  canControl ? "cursor-pointer" : "cursor-not-allowed"
                }`}
                onClick={() => canControl && onShade33(data, false)}
                disabled={!canControl}
              >
                <ShadeTTSvg className="w-[14px] h-[14px]" />
              </button>
            </>
          ) : (
            <button
              className={`border-l border-r border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100 ${
                canControl ? "cursor-pointer" : "cursor-not-allowed"
              }`}
              onClick={() => canControl && onShadeStop(data, false)}
              disabled={!canControl}
            >
              <StopSvg className="w-[20px] h-[20px]" />
            </button>
          )}

          <button
            className={`${
              data?.properties?.numberOfCmds === 4
                ? "border-l border-[#CCCCCC]"
                : ""
            } flex items-center justify-center hover:bg-gray-100 ${
              !canControl || (!isLutronShade && isFullyClosed)
                ? "opacity-50 cursor-not-allowed"
                : "cursor-pointer"
            }`}
            onClick={() =>
              canControl &&
              (!isLutronShade ? !isFullyClosed : true) &&
              onShadeDown(data, false)
            }
            disabled={!canControl || (!isLutronShade && isFullyClosed)}
          >
            <MdArrowDownSvg className="w-[12px] h-[12px]" />
          </button>
        </div>
      </div>
    </div>
  );
};

const LEDTemplateCard = ({
  data,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit, // New prop for API call
  channelStates,
  canControl = true, // New prop for permission control
}) => {
  const currentState =
    channelStates[`${data.deviceId}-${data.channelId}`] || data;
  const isOn = currentState.status === "on";
  const brightness = parseInt(currentState.properties?.brightness || 0);
  // const powerMin = parseInt(currentState.properties?.powerMin || 0);
  // const powerMax = parseInt(currentState.properties?.powerMax || 100);
  const powerMin = 0;
  const powerMax = 100;

  return (
    <div className="w-full h-full flex flex-col items-center justify-center p-2 relative truncate">
      <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
        {data?.channelName || data?.name || data?.channelId}
      </h2>
      <div
        className={`flex-1 flex items-center justify-center w-full h-full ${
          canControl ? "cursor-pointer" : "cursor-not-allowed"
        }`}
        onClick={() => canControl && onLEDToggle(data, false)}
      >
        {isOn ? (
          <LEDonSvg className="w-[100px] h-[100px] max-w-[120px] max-h-[120px]" />
        ) : (
          <LEDSvg className="w-[94px] h-[94px] max-w-[120px] max-h-[120px]" />
        )}
      </div>
      <div className="w-full max-w-[240px]">
        <RangeSlider
          min={powerMin}
          max={powerMax}
          value={brightness}
          onChange={(value) => onLEDBrightnessChange(data, value, false)}
          onValueCommit={(value) => onLEDBrightnessCommit(data, value, false)}
          disabled={!isOn || !canControl}
        />
      </div>
    </div>
  );
};

const SensorTemplateCard = ({ data }) => {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center p-2 relative truncate">
      <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
        Sensor
      </h2>
      <div className="flex-1 flex items-center justify-center w-full h-full">
        <SensorSvg
          className={`h-[60%] max-w-[120px] max-h-[120px] ${
            data?.status === "active" ? "text-blue-500" : "text-gray-400"
          }`}
        />
      </div>
      <div className="text-sm text-center text-gray-600">
        {data?.status || "inactive"}
      </div>
    </div>
  );
};

const ChannelTemplateCard = ({
  data,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit, // New prop
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  onSceneExecute, // New prop for scene execution
  onSceneBrightnessChange, // New prop for scene brightness change
  onSceneBrightnessCommit, // New prop for scene brightness commit
  channelStates,
  canControl = true, // New prop for permission control
  layout,
  realRow,
  realCol,
}) => {
  if (data?.type === "group") {
    return (
      <GroupTemplateCard
        data={data}
        onLEDToggle={onLEDToggle}
        onLEDBrightnessChange={onLEDBrightnessChange}
        onLEDBrightnessCommit={onLEDBrightnessCommit}
        onShadeUp={onShadeUp}
        onShadeDown={onShadeDown}
        onShadeStop={onShadeStop}
        onShade33={onShade33}
        onShade66={onShade66}
        channelStates={channelStates}
        canControl={canControl}
      />
    );
  }

  if (data?.type === "scene") {
    return (
      <SceneTemplateCard
        data={data}
        onSceneExecute={onSceneExecute}
        onSceneBrightnessChange={onSceneBrightnessChange}
        onSceneBrightnessCommit={onSceneBrightnessCommit}
        canControl={canControl}
        onLEDToggle={onLEDToggle}
        onLEDBrightnessChange={onLEDBrightnessChange}
        onLEDBrightnessCommit={onLEDBrightnessCommit}
        onShadeUp={onShadeUp}
        onShadeDown={onShadeDown}
        onShadeStop={onShadeStop}
        onShade33={onShade33}
        onShade66={onShade66}
      />
    );
  }

  // Check if elements array exists and is empty
  if (data?.elements && data.elements.length === 0) {
    return (
      <div className="w-full h-full flex items-center justify-center text-gray-400">
        <div className="text-center text-[#939CA7] text-sm">
          Currently not available
        </div>
      </div>
    );
  }

  if (data?.elements?.length === 1) {
    const element = data.elements[0];
    if (element.type === "led") {
      return (
        <LEDTemplateCard
          data={element}
          onLEDToggle={onLEDToggle}
          onLEDBrightnessChange={onLEDBrightnessChange}
          onLEDBrightnessCommit={onLEDBrightnessCommit}
          channelStates={channelStates}
          canControl={canControl}
        />
      );
    }
    if (element.type === "shade") {
      return (
        <ShadeTemplateCard
          data={element}
          onShadeUp={onShadeUp}
          onShadeDown={onShadeDown}
          onShadeStop={onShadeStop}
          onShade33={onShade33}
          onShade66={onShade66}
          channelStates={channelStates}
          canControl={canControl}
        />
      );
    }
    if (element.type === "sensor") {
      return <SensorTemplateCard data={element} />;
    }
  }

  if (data?.type === "led") {
    return (
      <LEDTemplateCard
        data={data}
        onLEDToggle={onLEDToggle}
        onLEDBrightnessChange={onLEDBrightnessChange}
        channelStates={channelStates}
        canControl={canControl}
      />
    );
  }

  if (data?.type === "shade") {
    return (
      <ShadeTemplateCard
        data={data}
        onShadeUp={onShadeUp}
        onShadeDown={onShadeDown}
        onShadeStop={onShadeStop}
        onShade33={onShade33}
        onShade66={onShade66}
        channelStates={channelStates}
        canControl={canControl}
      />
    );
  }

  if (data?.type === "sensor") {
    return <SensorTemplateCard data={data} />;
  }

  if (data?.type === "widget") {
    return getWidgetLayout(layout, realRow, realCol) === "landscape" ? (
      <PortraitLayout
        listenRealTimeChange={true}
        selectedWidgets={data?.widget_data?.structure}
        className="w-full h-full"
      />
    ) : (
      <LandscapeLayout
        listenRealTimeChange={true}
        selectedWidgets={data?.widget_data?.structure}
        className="w-full h-full"
      />
    );
  }

  return (
    <div className="w-full h-full flex items-center justify-center text-gray-400">
      {"Currently not available"} {data?.type}
    </div>
  );
};

const TemplateLayoutBox = ({
  column,
  index,
  rows,
  cols,
  layout,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit,
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  onSceneExecute,
  onSceneBrightnessChange,
  onSceneBrightnessCommit,
  channelStates,
  canControl = true, // New prop for permission control
}) => {
  return (
    <div
      className={`flex items-center justify-center text-[#939CA7] ${
        column?.type === "scene" && layout === "portrait"
          ? "min-h-[500px] min-w-[320px]"
          : column?.type === "widget" && layout === "portrait"
          ? "min-h-[380px] min-w-[320px]"
          : column?.type === "widget" && layout === "landscape"
          ? "min-w-[320px] min-h-[300px]"
          : "min-w-[320px] min-h-[300px]"
      }`}
    >
      <ChannelTemplateCard
        data={column}
        onLEDToggle={onLEDToggle}
        onLEDBrightnessChange={onLEDBrightnessChange}
        onLEDBrightnessCommit={onLEDBrightnessCommit}
        onShadeUp={onShadeUp}
        onShadeDown={onShadeDown}
        onShadeStop={onShadeStop}
        onShade33={onShade33}
        onShade66={onShade66}
        onSceneExecute={onSceneExecute}
        onSceneBrightnessChange={onSceneBrightnessChange}
        onSceneBrightnessCommit={onSceneBrightnessCommit}
        channelStates={channelStates}
        canControl={canControl}
        layout={layout}
        realRow={rows}
        realCol={cols}
      />
    </div>
  );
};

function TemplateLayout({
  config,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit,
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  onSceneExecute,
  onSceneBrightnessChange,
  onSceneBrightnessCommit,
  channelStates,
  canControl = true, // New prop for permission control
  ...props
}) {
  if (!config?._id) return <div>Invalid layout</div>;

  const { layoutStructure, layout, rows, columns } = config;

  if (!layoutStructure?.rows) return <div>No layout data</div>;

  const gridItems = [];
  layoutStructure.rows.forEach((row) => {
    row.columns?.forEach((column) => {
      gridItems.push(column);
    });
  });

  return (
    <div
      className={`cursor-pointer relative flex p-5 items-center justify-center h-full w-full`}
      {...props}
    >
      <div
        className={`grid border-2 border-[#666666] rounded-[5px] overflow-auto hide-scrollbar
          ${
            layout === "portrait"
              ? "w-full h-full max-w-[554px]"
              : "w-full h-full max-h-[554px]"
          }
          ${rows > 1 ? "divide-y divide-[#666666]" : ""}
          ${columns > 1 ? "divide-x divide-[#666666]" : ""}`}
        style={{
          gridTemplateRows: `repeat(${rows}, 1fr)`,
          gridTemplateColumns: `repeat(${columns}, 1fr)`,
          aspectRatio: layout === "landscape" ? "16/9" : "9/16",
        }}
      >
        {Array.from({ length: rows * columns }).map((_, i) => (
          <TemplateLayoutBox
            key={i}
            column={gridItems[i]}
            index={i}
            rows={rows}
            cols={columns}
            layout={layout}
            onLEDToggle={onLEDToggle}
            onLEDBrightnessChange={onLEDBrightnessChange}
            onLEDBrightnessCommit={onLEDBrightnessCommit}
            onShadeUp={onShadeUp}
            onShadeDown={onShadeDown}
            onShadeStop={onShadeStop}
            onShade33={onShade33}
            onShade66={onShade66}
            onSceneExecute={onSceneExecute}
            onSceneBrightnessChange={onSceneBrightnessChange}
            onSceneBrightnessCommit={onSceneBrightnessCommit}
            channelStates={channelStates}
            canControl={canControl}
          />
        ))}
      </div>
    </div>
  );
}

function TemplateView({ selectedItem }) {
  const [channelStates, setChannelStates] = useState({});
  const { data, isLoading, isError } = useGetTemplatesById({
    id: selectedItem?._id,
    refetchInterval: CONFIG.REFETCH_INTERVAL,
    onSuccess: () => {
      setChannelStates({}); // Reset channel states when template changes
    },
  });

  const queryClient = useQueryClient();
  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.TEMPLATE_BY_ID],
      exact: false,
    });
  };

  const { user } = useUserStore();
  const userPermissions = useUserStore((state) => state.permissions);
  const canControl = userPermissions?.CONTROL_SECTION?.template_tab?.addModify;

  const triggerEventMutation = useTriggerEvent({
    onSuccess: (response) => {
      // Optionally, you can refetch or update the channel state here based on response
    },
    onError: (error) => {
      console.error("Event trigger failed:", error);
    },
  });

  const getChannelKey = (channel) => `${channel.deviceId}-${channel.channelId}`;

  const getUserData = () => ({
    userId: user?.id,
  });

  const handleLEDToggle = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const newStatus = currentState.status === "on" ? "off" : "on";

      if (isGroup && groupData) {
        // If this is the main channel, update all LED channels in the group
        if (channel.isMainChannel) {
          const ledChannels =
            groupData.elements?.filter((ch) => ch.type === "led") || [];
          const updatedStates = {};

          // Update main channel state (using first channel's key)
          const firstChannel = groupData.elements?.[0];
          if (firstChannel) {
            const firstChannelKey = getChannelKey(firstChannel);
            updatedStates[firstChannelKey] = {
              ...currentState,
              status: newStatus,
            };
          }

          // Update all LED channels in the group to match the main channel
          ledChannels.forEach((ch) => {
            const chKey = getChannelKey(ch);
            const chCurrentState = channelStates[chKey] || ch;
            updatedStates[chKey] = {
              ...chCurrentState,
              status: newStatus,
            };
          });

          setChannelStates((prev) => ({
            ...prev,
            ...updatedStates,
          }));

          // Call group API using first channel's device info
          const userData = getUserData();

          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel.deviceId, // Use first channel's device ID
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: newStatus === "on" ? "GROUP_LED_ON" : "GROUP_LED_OFF",
            groupId: groupData?.id,
          };

          triggerEventMutation.mutate(payload);
        } else {
          // Individual channel in group toggle (non-main channel)
          setChannelStates((prev) => ({
            ...prev,
            [key]: {
              ...currentState,
              status: newStatus,
            },
          }));

          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData:
              newStatus === "on"
                ? {
                    properties: {
                      brightness: parseInt(
                        currentState.properties?.brightness || 0
                      ),
                      powerMin: parseInt(
                        currentState.properties?.powerMin || 0
                        // 0
                      ),
                      powerMax: parseInt(
                        currentState.properties?.powerMax || 0
                        // 100
                      ),
                    },
                  }
                : {},
            channelType: "LED",
            channelAddress: channel.channelId,
            command: newStatus === "on" ? "LED_ON" : "LED_OFF",
          };

          triggerEventMutation.mutate(payload);
        }
      } else {
        // Individual channel toggle (not in group)
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            status: newStatus,
          },
        }));

        const userData = getUserData();

        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData:
            newStatus === "on"
              ? {
                  properties: {
                    brightness: parseInt(
                      currentState.properties?.brightness || 0
                    ),
                    // powerMin: 0,
                    // powerMax: 100,
                    powerMin: parseInt(currentState.properties?.powerMin || 0),
                    powerMax: parseInt(
                      currentState.properties?.powerMax || 0
                    ),
                  },
                }
              : {},
          channelType: "LED",
          channelAddress: channel.channelId,
          command: newStatus === "on" ? "LED_ON" : "LED_OFF",
        };

        triggerEventMutation.mutate(payload);
      }
    },
    [channelStates, triggerEventMutation]
  );

  const handleLEDBrightnessChange = useCallback(
    (channel, brightness, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Update all LED channels in the group for main channel
          const ledChannels =
            groupData.elements?.filter((ch) => ch.type === "led") || [];
          const updatedStates = {};

          // Update main channel state (using first channel's key)
          const firstChannel = groupData.elements?.[0];
          if (firstChannel) {
            const firstChannelKey = getChannelKey(firstChannel);
            updatedStates[firstChannelKey] = {
              ...currentState,
              properties: {
                ...currentState.properties,
                brightness: brightness,
              },
            };
          }

          ledChannels.forEach((ch) => {
            const chKey = getChannelKey(ch);
            const chCurrentState = channelStates[chKey] || ch;
            updatedStates[chKey] = {
              ...chCurrentState,
              properties: {
                ...chCurrentState.properties,
                brightness: brightness,
              },
            };
          });

          setChannelStates((prev) => ({
            ...prev,
            ...updatedStates,
          }));
        } else {
          // Individual channel brightness change in group
          setChannelStates((prev) => ({
            ...prev,
            [key]: {
              ...currentState,
              properties: {
                ...currentState.properties,
                brightness: brightness,
              },
            },
          }));
        }
      } else {
        // Individual channel brightness change (not in group)
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              brightness: brightness,
            },
          },
        }));
      }
    },
    [channelStates]
  );

  const handleLEDBrightnessCommit = useCallback(
    (channel, brightness, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Call group brightness API for main channel
          const userData = getUserData();
          const firstChannel = groupData.elements?.[0];
          const ledChannels =
            groupData.elements?.filter((ch) => ch.type === "led") || [];
          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel?.deviceId,
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: `GROUP_LED_BRIGHTNESS${brightness}`,
          };

          triggerEventMutation.mutate(payload, {
            onSuccess: () => {
              toaster.success("Brightness updated successfully");
            },
            onError: (error) => {
              toaster.error(
                error?.response?.data?.message || "Failed to update brightness"
              );
            },
          });
        } else {
          // Individual channel brightness commit in group
          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              properties: {
                brightness: brightness,
                powerMin: parseInt(currentState.properties?.powerMin || 0),
                powerMax: parseInt(currentState.properties?.powerMax || 0),
                // powerMin: 0,
                // powerMax: 100,
              },
            },
            channelType: "LED",
            channelAddress: channel.channelId,
            command: "LED_BRIGHTNESS",
          };

          triggerEventMutation.mutate(payload, {
            onSuccess: () => {
              toaster.success("Brightness updated successfully");
            },
            onError: (error) => {
              toaster.error(
                error?.response?.data?.message || "Failed to update brightness"
              );
            },
          });
        }
      } else {
        // Individual channel brightness commit (not in group)
        const userData = getUserData();

        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData: {
            properties: {
              brightness: brightness,
              // powerMin: 0,
              // powerMax: 100,
              powerMin: parseInt(currentState.properties?.powerMin || 0),
              powerMax: parseInt(currentState.properties?.powerMax || 0),
            },
          },
          channelType: "LED",
          channelAddress: channel.channelId,
          command: "LED_BRIGHTNESS",
        };

        triggerEventMutation.mutate(payload, {
          onSuccess: () => {
            toaster.success("Brightness updated successfully");
          },
          onError: (error) => {
            toaster.error(
              error?.response?.data?.message || "Failed to update brightness"
            );
          },
        });
      }
    },
    [channelStates, triggerEventMutation]
  );

  const handleShadeUp = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      // Check if this is a shade_lutron device

      const isLutronShade =
        channel?.deviceType?.toLowerCase() === "shade_lutron";

      if (isLutronShade) {
        // For shade_lutron, set to 100%
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: "100%",
            },
          },
        }));
      } else {
        // For regular shades, increment by 10%
        const currentLevel = parseInt(
          currentState.properties?.openLevel?.replace?.("%", "") ||
            currentState?.openLevel?.replace?.("%", "") ||
            0
        );
        // const newLevel = Math.min(100, currentLevel + 10);
        const newLevel = 100;

        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));
      }

      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Update all shade channels in the group for main channel
          const shadeChannels =
            groupData.elements?.filter((ch) => ch.type === "shade") || [];
          const updatedStates = {};

          // Update main channel state (using first channel's key)
          const firstChannel = groupData.elements?.[0];
          if (firstChannel) {
            const firstChannelKey = getChannelKey(firstChannel);

            const firstIsLutron =
              firstChannel?.deviceType?.toLowerCase() === "shade_lutron";
            updatedStates[firstChannelKey] = {
              ...currentState,
              properties: {
                ...currentState.properties,
                // openLevel: firstIsLutron
                //   ? "100%"
                //   : `${Math.min(
                //       100,
                //       parseInt(
                //         currentState.properties?.openLevel?.replace?.("%", "") ||
                //           0
                //       ) + 10
                //     )}%`,
                openLevel: "100%",
              },
            };
          }

          shadeChannels.forEach((ch) => {
            const chKey = getChannelKey(ch);
            const chCurrentState = channelStates[chKey] || ch;

            const chIsLutron = ch?.deviceType?.toLowerCase() === "shade_lutron";
            updatedStates[chKey] = {
              ...chCurrentState,
              properties: {
                ...chCurrentState.properties,
                // openLevel: chIsLutron
                //   ? "100%"
                //   : `${Math.min(
                //       100,
                //       parseInt(
                //         chCurrentState.properties?.openLevel?.replace?.(
                //           "%",
                //           ""
                //         ) || 0
                //       ) + 10
                //     )}%`,
                openLevel: "100%",
              },
            };
          });

          setChannelStates((prev) => ({
            ...prev,
            ...updatedStates,
          }));

          // Call group API for shades using first channel info
          const userData = getUserData();

          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                ...(item.channelType === "shade" &&
                  item?.deviceType?.toLowerCase() !== "shade_lutron" && {
                    // openLevel: Math.min(
                    //   100,
                    //   parseInt(
                    //     (
                    //       channelStates[getChannelKey(item)] || item
                    //     ).properties?.openLevel?.replace?.("%", "") || 0
                    //   ) + 10
                    // ),
                    openLevel: 100,
                  }),
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel?.deviceId,
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: "GROUP_SHADE_UP",
            groupId: groupData?.id,
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        } else {
          // Individual shade up in group
          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData: isLutronShade
              ? {}
              : {
                  properties: {
                    openLevel: 100,
                    // openLevel: Math.min(
                    //   100,
                    //   parseInt(
                    //     currentState.properties?.openLevel?.replace?.("%", "") ||
                    //       0
                    //   ) + 10
                    // ),
                    numberOfCmds: channel?.properties?.numberOfCmds || null,
                  },
                },
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_UP",
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        }
      } else {
        // Individual shade up (not in group)
        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData: isLutronShade
            ? {
                properties: {
                  numberOfCmds:
                    channel?.properties?.numberOfCmds ||
                    channel?.numberOfCmds ||
                    null,
                },
              }
            : {
                properties: {
                  // openLevel: Math.min(
                  //   100,
                  //   parseInt(
                  //     currentState.properties?.openLevel?.replace?.("%", "") || 0
                  //   ) + 10
                  // ),
                  openLevel: 100,
                  numberOfCmds:
                    channel?.properties?.numberOfCmds ||
                    channel?.numberOfCmds ||
                    null,
                },
              },
          channelType: "SHADE",
          channelAddress: channel.channelId,
          command: "SHADE_UP",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [channelStates, triggerEventMutation]
  );

  const handleShadeDown = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      // Check if this is a shade_lutron device
      const isLutronShade =
        channel?.deviceType?.toLowerCase() === "shade_lutron";

      if (isLutronShade) {
        // For shade_lutron, set to 0%
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: "0%",
            },
          },
        }));
      } else {
        // For regular shades, decrement by 10%
        const currentLevel = parseInt(
          currentState.properties?.openLevel?.replace?.("%", "") ||
            currentState?.openLevel?.replace?.("%", "") ||
            0
        );
        // const newLevel = Math.max(0, currentLevel - 10);
        const newLevel = 0;

        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));
      }

      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Update all shade channels in the group for main channel
          const shadeChannels =
            groupData.elements?.filter((ch) => ch.type === "shade") || [];
          const updatedStates = {};

          // Update main channel state (using first channel's key)
          const firstChannel = groupData.elements?.[0];
          if (firstChannel) {
            const firstChannelKey = getChannelKey(firstChannel);
            const firstIsLutron =
              firstChannel?.deviceType?.toLowerCase() === "shade_lutron";
            updatedStates[firstChannelKey] = {
              ...currentState,
              properties: {
                ...currentState.properties,
                // openLevel: firstIsLutron
                //   ? "0%"
                //   : `${Math.max(
                //       0,
                //       parseInt(
                //         currentState.properties?.openLevel?.replace?.("%", "") ||
                //           0
                //       ) - 10
                //     )}%`,
                openLevel: 0,
              },
            };
          }

          shadeChannels.forEach((ch) => {
            const chKey = getChannelKey(ch);
            const chCurrentState = channelStates[chKey] || ch;
            const chIsLutron = ch?.deviceType?.toLowerCase() === "shade_lutron";
            updatedStates[chKey] = {
              ...chCurrentState,
              properties: {
                ...chCurrentState.properties,
                // openLevel: chIsLutron
                //   ? "0%"
                //   : `${Math.max(
                //       0,
                //       parseInt(
                //         chCurrentState.properties?.openLevel?.replace?.(
                //           "%",
                //           ""
                //         ) || 0
                //       ) - 10
                //     )}%`,
                openLevel: 0,
              },
            };
          });

          setChannelStates((prev) => ({
            ...prev,
            ...updatedStates,
          }));

          // Call group API for shades using first channel info
          const userData = getUserData();

          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                ...(item.channelType === "shade" &&
                  item?.deviceType?.toLowerCase() !== "shade_lutron" && {
                    openLevel: 0,
                    // openLevel: Math.max(
                    //   0,
                    //   parseInt(
                    //     (
                    //       channelStates[getChannelKey(item)] || item
                    //     ).properties?.openLevel?.replace?.("%", "") || 0
                    //   ) - 10
                    // ),
                  }),
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel?.deviceId,
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: "GROUP_SHADE_DOWN",
            groupId: groupData?.id,
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        } else {
          // Individual shade down in group
          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData: isLutronShade
              ? {}
              : {
                  properties: {
                    // openLevel: Math.max(
                    //   0,
                    //   parseInt(
                    //     currentState.properties?.openLevel?.replace?.("%", "") ||
                    //       0
                    //   ) - 10
                    // ),
                    openLevel: 0,
                    numberOfCmds: channel?.properties?.numberOfCmds || null,
                  },
                },
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_DOWN",
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        }
      } else {
        // Individual shade down (not in group)
        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData: isLutronShade
            ? {
                properties: {
                  numberOfCmds: channel?.properties?.numberOfCmds || null,
                },
              }
            : {
                properties: {
                  // openLevel: Math.max(
                  //   0,
                  //   parseInt(
                  //     currentState.properties?.openLevel?.replace?.("%", "") || 0
                  //   ) - 10
                  // ),
                  openLevel: 0,
                  numberOfCmds: channel?.properties?.numberOfCmds || null,
                },
              },
          channelType: "SHADE",
          channelAddress: channel.channelId,
          command: "SHADE_DOWN",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [channelStates, triggerEventMutation]
  );

  const handleShade33 = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") ||
          currentState?.openLevel?.replace?.("%", "") ||
          0
      );
      // const newLevel = Math.max(0, currentLevel - 10);
      const newLevel = 33;

      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Update all shade channels in the group for main channel
          const shadeChannels =
            groupData.elements?.filter((ch) => ch.type === "shade") || [];
          const updatedStates = {};

          // Update main channel state (using first channel's key)
          const firstChannel = groupData.elements?.[0];
          if (firstChannel) {
            const firstChannelKey = getChannelKey(firstChannel);
            updatedStates[firstChannelKey] = {
              ...currentState,
              properties: {
                ...currentState.properties,
                openLevel: `${newLevel}%`,
              },
            };
          }

          shadeChannels.forEach((ch) => {
            const chKey = getChannelKey(ch);
            const chCurrentState = channelStates[chKey] || ch;
            updatedStates[chKey] = {
              ...chCurrentState,
              properties: {
                ...chCurrentState.properties,
                openLevel: `${newLevel}%`,
              },
            };
          });

          setChannelStates((prev) => ({
            ...prev,
            ...updatedStates,
          }));

          // Call group API for shades using first channel info
          const userData = getUserData();
          // const devices = [
          //   {
          //     deviceId: firstChannel?.deviceId,
          //     channels: shadeChannels.map((ch) => ({
          //       channelId: ch.channelId,
          //       channelType: "SHADE",
          //       openLevel: newLevel,
          //       numberOfCmds: ch?.properties?.numberOfCmds || null,
          //     })),
          //   },
          // ];

          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                openLevel: item.channelType === "shade" ? newLevel : undefined,
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel?.deviceId,
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: "GROUP_SHADE_33",
            groupId: groupData?.id,
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        } else {
          // Individual shade down in group
          setChannelStates((prev) => ({
            ...prev,
            [key]: {
              ...currentState,
              properties: {
                ...currentState.properties,
                openLevel: `${newLevel}%`,
              },
            },
          }));

          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              properties: {
                openLevel: newLevel,
                numberOfCmds: channel?.properties?.numberOfCmds || null,
              },
            },
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_33",
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        }
      } else {
        // Individual shade down (not in group)
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));

        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData: {
            properties: {
              openLevel: newLevel,
              numberOfCmds: channel?.properties?.numberOfCmds || null,
            },
          },
          channelType: "SHADE",
          channelAddress: channel.channelId,
          command: "SHADE_33",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [channelStates, triggerEventMutation]
  );

  const handleShade66 = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") ||
          currentState?.openLevel?.replace?.("%", "") ||
          0
      );
      // const newLevel = Math.max(0, currentLevel - 10);
      const newLevel = 66;

      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Update all shade channels in the group for main channel
          const shadeChannels =
            groupData.elements?.filter((ch) => ch.type === "shade") || [];
          const updatedStates = {};

          // Update main channel state (using first channel's key)
          const firstChannel = groupData.elements?.[0];
          if (firstChannel) {
            const firstChannelKey = getChannelKey(firstChannel);
            updatedStates[firstChannelKey] = {
              ...currentState,
              properties: {
                ...currentState.properties,
                openLevel: `${newLevel}%`,
              },
            };
          }

          shadeChannels.forEach((ch) => {
            const chKey = getChannelKey(ch);
            const chCurrentState = channelStates[chKey] || ch;
            updatedStates[chKey] = {
              ...chCurrentState,
              properties: {
                ...chCurrentState.properties,
                openLevel: `${newLevel}%`,
              },
            };
          });

          setChannelStates((prev) => ({
            ...prev,
            ...updatedStates,
          }));

          // Call group API for shades using first channel info
          const userData = getUserData();
          // const devices = [
          //   {
          //     deviceId: firstChannel?.deviceId,
          //     channels: shadeChannels.map((ch) => ({
          //       channelId: ch.channelId,
          //       channelType: "SHADE",
          //       openLevel: newLevel,
          //       numberOfCmds: ch?.properties?.numberOfCmds || null,
          //     })),
          //   },
          // ];

          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                openLevel: item.channelType === "shade" ? newLevel : undefined,
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel?.deviceId,
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: "GROUP_SHADE_66",
            groupId: groupData?.id,
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        } else {
          // Individual shade down in group
          setChannelStates((prev) => ({
            ...prev,
            [key]: {
              ...currentState,
              properties: {
                ...currentState.properties,
                openLevel: `${newLevel}%`,
              },
            },
          }));

          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              properties: {
                openLevel: newLevel,
                numberOfCmds: channel?.properties?.numberOfCmds || null,
              },
            },
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_66",
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        }
      } else {
        // Individual shade down (not in group)
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));

        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData: {
            properties: {
              openLevel: newLevel,
              numberOfCmds: channel?.properties?.numberOfCmds || null,
            },
          },
          channelType: "SHADE",
          channelAddress: channel.channelId,
          command: "SHADE_66",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [channelStates, triggerEventMutation]
  );

  const handleShadeStop = useCallback(
    (channel, isGroup = false, groupData = null) => {
      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Call group API for shade stop using first channel info
          const userData = getUserData();
          const firstChannel = groupData.elements?.[0];
          const shadeChannels =
            groupData.elements?.filter((ch) => ch.type === "shade") || [];
          // const devices = [
          //   {
          //     deviceId: firstChannel?.deviceId,
          //     channels: shadeChannels.map((ch) => ({
          //       channelId: ch.channelId,
          //       channelType: "SHADE",
          //     })),
          //   },
          // ];

          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel?.deviceId,
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: "GROUP_SHADE_STOP",
            groupId: groupData?.id,
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        } else {
          // Individual shade stop in group
          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {},
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_STOP",
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        }
      } else {
        // Individual shade stop (not in group)
        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData: {},
          channelType: "SHADE",
          channelAddress: channel.channelId,
          command: "SHADE_STOP",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [triggerEventMutation]
  );

  const handleSceneExecute = useCallback(
    (sceneData) => {
      const payload = {
        user_id: user?.user_id,
        deviceData: sceneData.id,
        command: "SCENE_EXECUTE",
      };

      if (sceneData?.operateType === "invert")
        payload.invertFlag = sceneData?.invertFlag;

      triggerEventMutation.mutate(payload, {
        onSuccess: () => {
          toaster.success("Scene executed successfully");
        },
        onError: (error) => {
          toaster.error(
            error?.response?.data?.message || "Failed to execute scene"
          );
        },
      });
    },
    [triggerEventMutation, user]
  );

  const handleSceneBrightnessChange = useCallback((sceneData, brightness) => {
    // This could be used for local state updates if needed
  }, []);

  const handleSceneBrightnessCommit = useCallback(
    (sceneData, brightness) => {
      const payload = {
        user_id: user?.user_id,
        deviceData: sceneData.id,
        command: "SCENE_EXECUTE",
        device_id: brightness,
      };

      if (sceneData?.operateType === "invert")
        payload.invertFlag = sceneData?.invert_flag;

      triggerEventMutation.mutate(payload, {
        onSuccess: () => {
          toaster.success("Scene brightness updated successfully");
        },
        onError: (error) => {
          toaster.error(
            error?.response?.data?.message ||
              "Failed to update scene brightness"
          );
        },
      });
    },
    [triggerEventMutation, user]
  );

  if (isError) {
    return (
      <div className="flex items-center justify-center h-full min-h-[100px]">
        <h3>Template not found</h3>
      </div>
    );
  }

  if (isLoading)
    return (
      <div className="flex items-center justify-center h-full min-h-[100px]">
        <SpinnerV1 />
      </div>
    );

  return (
    <>
      <DeviceStatusChanged callback={realTimeChangeCallback} />
      <TemplateLayout
        config={data?.data}
        onLEDToggle={handleLEDToggle}
        onLEDBrightnessChange={handleLEDBrightnessChange}
        onLEDBrightnessCommit={handleLEDBrightnessCommit}
        onShadeUp={handleShadeUp}
        onShadeDown={handleShadeDown}
        onShadeStop={handleShadeStop}
        onShade33={handleShade33}
        onShade66={handleShade66}
        onSceneExecute={handleSceneExecute}
        onSceneBrightnessChange={handleSceneBrightnessChange}
        onSceneBrightnessCommit={handleSceneBrightnessCommit}
        channelStates={channelStates}
        canControl={canControl}
      />
    </>
  );
}

export function ElementView({ data, isLoading = false }) {
  const [channelStates, setChannelStates] = useState({});
  const { user } = useUserStore();
  const userPermissions = useUserStore((state) => state.permissions);
  const canControl = userPermissions?.CONTROL_SECTION?.template_tab?.addModify;

  const queryClient = useQueryClient();
  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.GROUPS],
      exact: false,
    });
  };

  const triggerEventMutation = useTriggerEvent({
    onSuccess: (response) => {
      // Optionally, you can refetch or update the channel state here based on response
    },
    onError: (error) => {
      console.error("Event trigger failed:", error);
    },
  });

  const getChannelKey = (channel) => `${channel.deviceId}-${channel.channelId}`;

  const getUserData = () => ({
    userId: user?.id,
  });

  const handleLEDToggle = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const newStatus = currentState.status === "on" ? "off" : "on";

      if (isGroup && groupData) {
        // If this is the main channel, update all LED channels in the group
        if (channel.isMainChannel) {
          const ledChannels =
            groupData.elements?.filter((ch) => ch.type === "led") || [];
          const updatedStates = {};

          // Update main channel state (using first channel's key)
          const firstChannel = groupData.elements?.[0];
          if (firstChannel) {
            const firstChannelKey = getChannelKey(firstChannel);
            updatedStates[firstChannelKey] = {
              ...currentState,
              status: newStatus,
            };
          }

          // Update all LED channels in the group to match the main channel
          ledChannels.forEach((ch) => {
            const chKey = getChannelKey(ch);
            const chCurrentState = channelStates[chKey] || ch;
            updatedStates[chKey] = {
              ...chCurrentState,
              status: newStatus,
            };
          });

          setChannelStates((prev) => ({
            ...prev,
            ...updatedStates,
          }));

          // Call group API using first channel's device info
          const userData = getUserData();
          // const devices = [
          //   {
          //     deviceId: firstChannel.deviceId,
          //     channels: ledChannels.map((ch) => ({
          //       channelId: ch.channelId,
          //       channelType: "LED",
          //     })),
          //   },
          // ];

          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel.deviceId, // Use first channel's device ID
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: newStatus === "on" ? "GROUP_LED_ON" : "GROUP_LED_OFF",
            groupId: groupData?.id,
          };

          triggerEventMutation.mutate(payload);
        } else {
          // Individual channel in group toggle (non-main channel)
          setChannelStates((prev) => ({
            ...prev,
            [key]: {
              ...currentState,
              status: newStatus,
            },
          }));

          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData:
              newStatus === "on"
                ? {
                    properties: {
                      brightness: parseInt(
                        currentState.properties?.brightness || 0
                      ),
                      powerMin: parseInt(
                        currentState.properties?.powerMin || 0
                        // 0
                      ),
                      powerMax: parseInt(
                        // 100
                        currentState.properties?.powerMax || 0
                      ),
                    },
                  }
                : {},
            channelType: "LED",
            channelAddress: channel.channelId,
            command: newStatus === "on" ? "LED_ON" : "LED_OFF",
          };

          triggerEventMutation.mutate(payload);
        }
      } else {
        // Individual channel toggle (not in group)
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            status: newStatus,
          },
        }));

        const userData = getUserData();

        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData:
            newStatus === "on"
              ? {
                  properties: {
                    brightness: parseInt(
                      currentState.properties?.brightness || 0
                    ),
                    // powerMin: parseInt(0),
                    // powerMax: parseInt(100),
                    powerMin: parseInt(currentState.properties?.powerMin || 0),
                    powerMax: parseInt(
                      currentState.properties?.powerMax || 0
                    ),
                  },
                }
              : {},
          channelType: "LED",
          channelAddress: channel.channelId,
          command: newStatus === "on" ? "LED_ON" : "LED_OFF",
        };

        triggerEventMutation.mutate(payload);
      }
    },
    [channelStates, triggerEventMutation]
  );

  const handleLEDBrightnessChange = useCallback(
    (channel, brightness, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Update all LED channels in the group for main channel
          const ledChannels =
            groupData.elements?.filter((ch) => ch.type === "led") || [];
          const updatedStates = {};

          // Update main channel state (using first channel's key)
          const firstChannel = groupData.elements?.[0];
          if (firstChannel) {
            const firstChannelKey = getChannelKey(firstChannel);
            updatedStates[firstChannelKey] = {
              ...currentState,
              properties: {
                ...currentState.properties,
                brightness: brightness,
              },
            };
          }

          ledChannels.forEach((ch) => {
            const chKey = getChannelKey(ch);
            const chCurrentState = channelStates[chKey] || ch;
            updatedStates[chKey] = {
              ...chCurrentState,
              properties: {
                ...chCurrentState.properties,
                brightness: brightness,
              },
            };
          });

          setChannelStates((prev) => ({
            ...prev,
            ...updatedStates,
          }));
        } else {
          // Individual channel brightness change in group
          setChannelStates((prev) => ({
            ...prev,
            [key]: {
              ...currentState,
              properties: {
                ...currentState.properties,
                brightness: brightness,
              },
            },
          }));
        }
      } else {
        // Individual channel brightness change (not in group)
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              brightness: brightness,
            },
          },
        }));
      }
    },
    [channelStates]
  );

  const handleLEDBrightnessCommit = useCallback(
    (channel, brightness, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Call group brightness API for main channel
          const userData = getUserData();
          const firstChannel = groupData.elements?.[0];
          const ledChannels =
            groupData.elements?.filter((ch) => ch.type === "led") || [];
          // const devices = [
          //   {
          //     deviceId: firstChannel?.deviceId,
          //     channels: ledChannels.map((ch) => ({
          //       channelId: ch.channelId,
          //       channelType: "LED",
          //     })),
          //   },
          // ];

          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel?.deviceId,
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: `GROUP_LED_BRIGHTNESS${brightness}`,
          };

          triggerEventMutation.mutate(payload, {
            onSuccess: () => {
              toaster.success("Brightness updated successfully");
            },
            onError: (error) => {
              toaster.error(
                error?.response?.data?.message || "Failed to update brightness"
              );
            },
          });
        } else {
          // Individual channel brightness commit in group
          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              properties: {
                brightness: brightness,
                // powerMin: 0,
                // powerMax: 100,
                powerMin: parseInt(currentState.properties?.powerMin || 0),
                powerMax: parseInt(currentState.properties?.powerMax || 0),
              },
            },
            channelType: "LED",
            channelAddress: channel.channelId,
            command: "LED_BRIGHTNESS",
          };

          triggerEventMutation.mutate(payload, {
            onSuccess: () => {
              toaster.success("Brightness updated successfully");
            },
            onError: (error) => {
              toaster.error(
                error?.response?.data?.message || "Failed to update brightness"
              );
            },
          });
        }
      } else {
        // Individual channel brightness commit (not in group)
        const userData = getUserData();

        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData: {
            properties: {
              brightness: brightness,
              // powerMin: 0,
              // powerMax: 100,
              powerMin: parseInt(currentState.properties?.powerMin || 0),
              powerMax: parseInt(currentState.properties?.powerMax || 0),
            },
          },
          channelType: "LED",
          channelAddress: channel.channelId,
          command: "LED_BRIGHTNESS",
        };

        triggerEventMutation.mutate(payload, {
          onSuccess: () => {
            toaster.success("Brightness updated successfully");
          },
          onError: (error) => {
            toaster.error(
              error?.response?.data?.message || "Failed to update brightness"
            );
          },
        });
      }
    },
    [channelStates, triggerEventMutation]
  );

  const handleShadeUp = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      // Check if this is a shade_lutron device

      const isLutronShade =
        channel?.deviceType?.toLowerCase() === "shade_lutron";

      if (isLutronShade) {
        // For shade_lutron, set to 100%
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: "100%",
            },
          },
        }));
      } else {
        // For regular shades, increment by 10%
        const currentLevel = parseInt(
          currentState.properties?.openLevel?.replace?.("%", "") ||
            currentState?.openLevel?.replace?.("%", "") ||
            0
        );
        // const newLevel = Math.min(100, currentLevel + 10);
        const newLevel = 100;

        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));
      }

      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Update all shade channels in the group for main channel
          const shadeChannels =
            groupData.elements?.filter((ch) => ch.type === "shade") || [];
          const updatedStates = {};

          // Update main channel state (using first channel's key)
          const firstChannel = groupData.elements?.[0];
          if (firstChannel) {
            const firstChannelKey = getChannelKey(firstChannel);

            const firstIsLutron =
              firstChannel?.deviceType?.toLowerCase() === "shade_lutron";
            updatedStates[firstChannelKey] = {
              ...currentState,
              properties: {
                ...currentState.properties,
                openLevel: "100%",
                // openLevel: firstIsLutron
                //   ? "100%"
                //   : `${Math.min(
                //       100,
                //       parseInt(
                //         currentState.properties?.openLevel?.replace?.("%", "") ||
                //           0
                //       ) + 10
                //     )}%`,
              },
            };
          }

          shadeChannels.forEach((ch) => {
            const chKey = getChannelKey(ch);
            const chCurrentState = channelStates[chKey] || ch;

            const chIsLutron = ch?.deviceType?.toLowerCase() === "shade_lutron";
            updatedStates[chKey] = {
              ...chCurrentState,
              properties: {
                ...chCurrentState.properties,
                // openLevel: chIsLutron
                //   ? "100%"
                //   : `${Math.min(
                //       100,
                //       parseInt(
                //         chCurrentState.properties?.openLevel?.replace?.(
                //           "%",
                //           ""
                //         ) || 0
                //       ) + 10
                //     )}%`,
                openLevel: "100%",
              },
            };
          });

          setChannelStates((prev) => ({
            ...prev,
            ...updatedStates,
          }));

          // Call group API for shades using first channel info
          const userData = getUserData();

          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                ...(item.channelType === "shade" &&
                  item?.deviceType?.toLowerCase() !== "shade_lutron" && {
                    // openLevel: Math.min(
                    //   100,
                    //   parseInt(
                    //     (
                    //       channelStates[getChannelKey(item)] || item
                    //     ).properties?.openLevel?.replace?.("%", "") || 0
                    //   ) + 10
                    // ),
                    openLevel: 100,
                  }),
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel?.deviceId,
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: "GROUP_SHADE_UP",
            groupId: groupData?.id,
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        } else {
          // Individual shade up in group
          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData: isLutronShade
              ? {}
              : {
                  properties: {
                    openLevel: 100,
                    // openLevel: Math.min(
                    //   100,
                    //   parseInt(
                    //     currentState.properties?.openLevel?.replace?.("%", "") ||
                    //       0
                    //   ) + 10
                    // ),
                    numberOfCmds: channel?.properties?.numberOfCmds || null,
                  },
                },
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_UP",
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        }
      } else {
        // Individual shade up (not in group)
        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData: isLutronShade
            ? {
                properties: {
                  numberOfCmds:
                    channel?.properties?.numberOfCmds ||
                    channel?.numberOfCmds ||
                    null,
                },
              }
            : {
                properties: {
                  // openLevel: Math.min(
                  //   100,
                  //   parseInt(
                  //     currentState.properties?.openLevel?.replace?.("%", "") || 0
                  //   ) + 10
                  // ),
                  openLevel: 100,
                  numberOfCmds:
                    channel?.properties?.numberOfCmds ||
                    channel?.numberOfCmds ||
                    null,
                },
              },
          channelType: "SHADE",
          channelAddress: channel.channelId,
          command: "SHADE_UP",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [channelStates, triggerEventMutation]
  );

  const handleShadeDown = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      // Check if this is a shade_lutron device
      const isLutronShade =
        channel?.deviceType?.toLowerCase() === "shade_lutron";

      if (isLutronShade) {
        // For shade_lutron, set to 0%
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: "0%",
            },
          },
        }));
      } else {
        // For regular shades, decrement by 10%
        const currentLevel = parseInt(
          currentState.properties?.openLevel?.replace?.("%", "") ||
            currentState?.openLevel?.replace?.("%", "") ||
            0
        );
        // const newLevel = Math.max(0, currentLevel - 10);
        const newLevel = 0;

        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));
      }

      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Update all shade channels in the group for main channel
          const shadeChannels =
            groupData.elements?.filter((ch) => ch.type === "shade") || [];
          const updatedStates = {};

          // Update main channel state (using first channel's key)
          const firstChannel = groupData.elements?.[0];
          if (firstChannel) {
            const firstChannelKey = getChannelKey(firstChannel);
            const firstIsLutron =
              firstChannel?.deviceType?.toLowerCase() === "shade_lutron";
            updatedStates[firstChannelKey] = {
              ...currentState,
              properties: {
                ...currentState.properties,
                openLevel: "0%",
                // openLevel: firstIsLutron
                //   ? "0%"
                //   : `${Math.max(
                //       0,
                //       parseInt(
                //         currentState.properties?.openLevel?.replace?.("%", "") ||
                //           0
                //       ) - 10
                //     )}%`,
              },
            };
          }

          shadeChannels.forEach((ch) => {
            const chKey = getChannelKey(ch);
            const chCurrentState = channelStates[chKey] || ch;
            const chIsLutron = ch?.deviceType?.toLowerCase() === "shade_lutron";
            updatedStates[chKey] = {
              ...chCurrentState,
              properties: {
                ...chCurrentState.properties,
                openLevel: "0%",
                // openLevel: chIsLutron
                //   ? "0%"
                //   : `${Math.max(
                //       0,
                //       parseInt(
                //         chCurrentState.properties?.openLevel?.replace?.(
                //           "%",
                //           ""
                //         ) || 0
                //       ) - 10
                //     )}%`,
              },
            };
          });

          setChannelStates((prev) => ({
            ...prev,
            ...updatedStates,
          }));

          // Call group API for shades using first channel info
          const userData = getUserData();

          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                ...(item.channelType === "shade" &&
                  item?.deviceType?.toLowerCase() !== "shade_lutron" && {
                    openLevel: 0,
                    // openLevel: Math.max(
                    //   0,
                    //   parseInt(
                    //     (
                    //       channelStates[getChannelKey(item)] || item
                    //     ).properties?.openLevel?.replace?.("%", "") || 0
                    //   ) - 10
                    // ),
                  }),
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel?.deviceId,
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: "GROUP_SHADE_DOWN",
            groupId: groupData?.id,
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        } else {
          // Individual shade down in group
          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData: isLutronShade
              ? {}
              : {
                  properties: {
                    openLevel: 0,
                    // openLevel: Math.max(
                    //   0,
                    //   parseInt(
                    //     currentState.properties?.openLevel?.replace?.("%", "") ||
                    //       0
                    //   ) - 10
                    // ),
                    numberOfCmds: channel?.properties?.numberOfCmds || null,
                  },
                },
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_DOWN",
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        }
      } else {
        // Individual shade down (not in group)
        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData: isLutronShade
            ? {
                properties: {
                  numberOfCmds: channel?.properties?.numberOfCmds || null,
                },
              }
            : {
                properties: {
                  // openLevel: Math.max(
                  //   0,
                  //   parseInt(
                  //     currentState.properties?.openLevel?.replace?.("%", "") || 0
                  //   ) - 10
                  // ),
                  openLevel: 0,
                  numberOfCmds: channel?.properties?.numberOfCmds || null,
                },
              },
          channelType: "SHADE",
          channelAddress: channel.channelId,
          command: "SHADE_DOWN",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [channelStates, triggerEventMutation]
  );

  const handleShade33 = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") ||
          currentState?.openLevel?.replace?.("%", "") ||
          0
      );
      // const newLevel = Math.max(0, currentLevel - 10);
      const newLevel = 33;

      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Update all shade channels in the group for main channel
          const shadeChannels =
            groupData.elements?.filter((ch) => ch.type === "shade") || [];
          const updatedStates = {};

          // Update main channel state (using first channel's key)
          const firstChannel = groupData.elements?.[0];
          if (firstChannel) {
            const firstChannelKey = getChannelKey(firstChannel);
            updatedStates[firstChannelKey] = {
              ...currentState,
              properties: {
                ...currentState.properties,
                openLevel: `${newLevel}%`,
              },
            };
          }

          shadeChannels.forEach((ch) => {
            const chKey = getChannelKey(ch);
            const chCurrentState = channelStates[chKey] || ch;
            updatedStates[chKey] = {
              ...chCurrentState,
              properties: {
                ...chCurrentState.properties,
                openLevel: `${newLevel}%`,
              },
            };
          });

          setChannelStates((prev) => ({
            ...prev,
            ...updatedStates,
          }));

          // Call group API for shades using first channel info
          const userData = getUserData();
          // const devices = [
          //   {
          //     deviceId: firstChannel?.deviceId,
          //     channels: shadeChannels.map((ch) => ({
          //       channelId: ch.channelId,
          //       channelType: "SHADE",
          //       openLevel: newLevel,
          //       numberOfCmds: ch?.properties?.numberOfCmds || null,
          //     })),
          //   },
          // ];

          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                openLevel: item.channelType === "shade" ? newLevel : undefined,
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel?.deviceId,
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: "GROUP_SHADE_33",
            groupId: groupData?.id,
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        } else {
          // Individual shade down in group
          setChannelStates((prev) => ({
            ...prev,
            [key]: {
              ...currentState,
              properties: {
                ...currentState.properties,
                openLevel: `${newLevel}%`,
              },
            },
          }));

          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              properties: {
                openLevel: newLevel,
                numberOfCmds: channel?.properties?.numberOfCmds || null,
              },
            },
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_33",
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        }
      } else {
        // Individual shade down (not in group)
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));

        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData: {
            properties: {
              openLevel: newLevel,
              numberOfCmds: channel?.properties?.numberOfCmds || null,
            },
          },
          channelType: "SHADE",
          channelAddress: channel.channelId,
          command: "SHADE_33",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [channelStates, triggerEventMutation]
  );

  const handleShade66 = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") ||
          currentState?.openLevel?.replace?.("%", "") ||
          0
      );
      // const newLevel = Math.max(0, currentLevel - 10);
      const newLevel = 66;

      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Update all shade channels in the group for main channel
          const shadeChannels =
            groupData.elements?.filter((ch) => ch.type === "shade") || [];
          const updatedStates = {};

          // Update main channel state (using first channel's key)
          const firstChannel = groupData.elements?.[0];
          if (firstChannel) {
            const firstChannelKey = getChannelKey(firstChannel);
            updatedStates[firstChannelKey] = {
              ...currentState,
              properties: {
                ...currentState.properties,
                openLevel: `${newLevel}%`,
              },
            };
          }

          shadeChannels.forEach((ch) => {
            const chKey = getChannelKey(ch);
            const chCurrentState = channelStates[chKey] || ch;
            updatedStates[chKey] = {
              ...chCurrentState,
              properties: {
                ...chCurrentState.properties,
                openLevel: `${newLevel}%`,
              },
            };
          });

          setChannelStates((prev) => ({
            ...prev,
            ...updatedStates,
          }));

          // Call group API for shades using first channel info
          const userData = getUserData();
          // const devices = [
          //   {
          //     deviceId: firstChannel?.deviceId,
          //     channels: shadeChannels.map((ch) => ({
          //       channelId: ch.channelId,
          //       channelType: "SHADE",
          //       openLevel: newLevel,
          //       numberOfCmds: ch?.properties?.numberOfCmds || null,
          //     })),
          //   },
          // ];

          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                openLevel: item.channelType === "shade" ? newLevel : undefined,
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel?.deviceId,
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: "GROUP_SHADE_66",
            groupId: groupData?.id,
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        } else {
          // Individual shade down in group
          setChannelStates((prev) => ({
            ...prev,
            [key]: {
              ...currentState,
              properties: {
                ...currentState.properties,
                openLevel: `${newLevel}%`,
              },
            },
          }));

          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              properties: {
                openLevel: newLevel,
                numberOfCmds: channel?.properties?.numberOfCmds || null,
              },
            },
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_66",
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        }
      } else {
        // Individual shade down (not in group)
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));

        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData: {
            properties: {
              openLevel: newLevel,
              numberOfCmds: channel?.properties?.numberOfCmds || null,
            },
          },
          channelType: "SHADE",
          channelAddress: channel.channelId,
          command: "SHADE_66",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [channelStates, triggerEventMutation]
  );

  const handleShadeStop = useCallback(
    (channel, isGroup = false, groupData = null) => {
      if (isGroup && groupData) {
        if (channel.isMainChannel) {
          // Call group API for shade stop using first channel info
          const userData = getUserData();
          const firstChannel = groupData.elements?.[0];
          const shadeChannels =
            groupData.elements?.filter((ch) => ch.type === "shade") || [];
          // const devices = [
          //   {
          //     deviceId: firstChannel?.deviceId,
          //     channels: shadeChannels.map((ch) => ({
          //       channelId: ch.channelId,
          //       channelType: "SHADE",
          //     })),
          //   },
          // ];

          const devices = Object.values(
            groupData.elements.reduce((acc, item) => {
              if (!acc[item.deviceId]) {
                acc[item.deviceId] = {
                  deviceId: item.deviceId,
                  channels: [],
                };
              }

              acc[item.deviceId].channels.push({
                channelId: item.channelId,
                channelType:
                  item.channelType?.toUpperCase() || item.type?.toUpperCase(),
                numberOfCmds: item?.properties?.numberOfCmds,
              });

              return acc;
            }, {})
          );

          const payload = {
            ...userData,
            device_id: firstChannel?.deviceId,
            deviceData: { devices },
            channelType: "",
            channelAddress: "",
            command: "GROUP_SHADE_STOP",
            groupId: groupData?.id,
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        } else {
          // Individual shade stop in group
          const userData = getUserData();
          const payload = {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {},
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_STOP",
          };

          triggerEventMutation.mutate(payload, {
            onError: (error) => {
              toaster.error(error?.response?.data?.message || "Failed");
            },
          });
        }
      } else {
        // Individual shade stop (not in group)
        const userData = getUserData();
        const payload = {
          ...userData,
          device_id: channel.deviceId,
          deviceData: {},
          channelType: "SHADE",
          channelAddress: channel.channelId,
          command: "SHADE_STOP",
        };

        triggerEventMutation.mutate(payload, {
          onError: (error) => {
            toaster.error(error?.response?.data?.message || "Failed");
          },
        });
      }
    },
    [triggerEventMutation]
  );

  const handleSceneExecute = useCallback(
    (sceneData) => {
      const payload = {
        user_id: user?.user_id,
        deviceData: sceneData.id,
        command: "SCENE_EXECUTE",
      };

      if (sceneData?.operateType === "invert")
        payload.invertFlag = sceneData?.invertFlag;

      triggerEventMutation.mutate(payload, {
        onSuccess: () => {
          toaster.success("Scene executed successfully");
        },
        onError: (error) => {
          toaster.error(
            error?.response?.data?.message || "Failed to execute scene"
          );
        },
      });
    },
    [triggerEventMutation, user]
  );

  const handleSceneBrightnessChange = useCallback((sceneData, brightness) => {
    // This could be used for local state updates if needed
  }, []);

  const handleSceneBrightnessCommit = useCallback(
    (sceneData, brightness) => {
      const payload = {
        user_id: user?.user_id,
        deviceData: sceneData.id,
        command: "SCENE_EXECUTE",
        device_id: brightness,
      };

      if (sceneData?.operateType === "invert")
        payload.invertFlag = sceneData?.invert_flag;

      triggerEventMutation.mutate(payload, {
        onSuccess: () => {
          toaster.success("Scene brightness updated successfully");
        },
        onError: (error) => {
          toaster.error(
            error?.response?.data?.message ||
              "Failed to update scene brightness"
          );
        },
      });
    },
    [triggerEventMutation, user]
  );

  if (isLoading)
    return (
      <div className="flex items-center justify-center h-full min-h-[100px]">
        <SpinnerV1 />
      </div>
    );

  return (
    <>
      <DeviceStatusChanged callback={realTimeChangeCallback} />
      <TemplateLayout
        config={data?.data}
        onLEDToggle={handleLEDToggle}
        onLEDBrightnessChange={handleLEDBrightnessChange}
        onLEDBrightnessCommit={handleLEDBrightnessCommit}
        onShadeUp={handleShadeUp}
        onShadeDown={handleShadeDown}
        onShadeStop={handleShadeStop}
        onShade33={handleShade33}
        onShade66={handleShade66}
        onSceneExecute={handleSceneExecute}
        onSceneBrightnessChange={handleSceneBrightnessChange}
        onSceneBrightnessCommit={handleSceneBrightnessCommit}
        channelStates={channelStates}
        canControl={canControl}
      />
    </>
  );
}

export default TemplateView;
