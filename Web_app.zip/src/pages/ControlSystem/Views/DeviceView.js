import { useState, useCallback } from "react";
import {
  LEDSvg,
  LEDonSvg,
  MdArrowDownSvg,
  SensorSvg,
  StopSvg,
  ShadeSSSvg,
  ShadeTTSvg,
} from "../../../assets/svg";
import {
  CurtainSvg,
  DeviceStatusChanged,
  RangeSlider,
  SpinnerV1,
} from "../../../components";
import {
  useGetDeviceByIdInControlSystem,
  useGetDeviceChannelsByDeviceId,
  useTriggerEvent,
} from "../../../api/queryHooks";
import useUserStore from "../../../store/useUserStore";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../../api/queryKeys";
import toaster from "../../../utils/toaster";

export const LEDCard = ({
  channel,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit,
  channelStates,
  canControl = true, // New prop for permission control
}) => {
  const currentState =
    channelStates[`${channel.deviceId}-${channel.id}`] || channel;
  const isOn = currentState.status === "on";
  const brightness = parseInt(currentState.properties?.brightness || 0);
  const powerMin = 0;
  const powerMax = 100;
  // const powerMin = parseInt(currentState.properties?.powerMin || 0);
  // const powerMax = parseInt(currentState.properties?.powerMax || 100);

  return (
    <div title={channel.name} className="flex flex-col justify-center items-center">
      <div
        className={`${canControl ? "cursor-pointer" : "cursor-not-allowed"}`}
        onClick={() => canControl && onLEDToggle(channel)}
      >
        {isOn ? (
          <LEDonSvg className="w-[60px] h-[60px]" />
        ) : (
          <LEDSvg className="w-[60px] h-[60px]" />
        )}
      </div>
      <h2 className="w-full truncate text-[12px] text-[#7A838E] text-center mt-2 mb-2">
        {channel.name}
      </h2>
      <RangeSlider
        min={powerMin}
        max={powerMax}
        value={brightness}
        onChange={(value) => onLEDBrightnessChange(channel, value)}
        onValueCommit={(value) => onLEDBrightnessCommit(channel, value)}
        disabled={!isOn || !canControl}
      />
    </div>
  );
};

export const SensorCard = ({ channel }) => {
  return (
    <div title={channel.name} className="flex flex-col justify-center items-center">
      <SensorSvg
        className={`w-[60px] h-[60px] ${
          channel.status === "active" ? "text-blue-500" : "text-gray-400"
        }`}
      />
      <h2 className="w-full truncate text-[12px] text-[#7A838E] text-center mt-2 mb-2">
        {channel.name}
      </h2>
      <div className="text-sm text-center text-gray-600">
        {channel.status || "inactive"}
      </div>
    </div>
  );
};

export const ShadeCard = ({
  channel,
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  channelStates,
  canControl = true, // New prop for permission control
  device, // Add device prop
}) => {
  const currentState =
    channelStates[`${channel.deviceId}-${channel.id}`] || channel;
  const openLevel = parseInt(
    currentState.properties?.openLevel?.replace?.("%", "") || 0
  );
  const isFullyOpen = openLevel >= 100;
  const isFullyClosed = openLevel <= 0;

  return (
    <div title={channel.name} className="flex flex-col justify-center items-center">
      <CurtainSvg openValue={openLevel} className="h-[60px] w-[60px]" />
      <h2 className="w-full truncate text-[12px] text-[#7A838E] text-center mt-2">
        {channel.name}
      </h2>
      <div className="text-xs text-center text-gray-600 mb-1">
        {device?.type?.toLowerCase() === "shade_lutron" 
          ? `${channel?.properties?.numberOfCmds || 3}/4 commands`
          : ``
        }
      </div>
      <div className="w-full flex items-center justify-center mt-1">
        <div className="bg-[#F5F9FD] border border-[#CCCCCC] rounded-lg grid text-[#222222]"
             style={{
               gridTemplateColumns: channel?.properties?.numberOfCmds === 4 ? 'repeat(4, 1fr)' : 'repeat(3, 1fr)'
             }}>
          <button
            className={`flex items-center justify-center px-1 py-[3px] w-[35px] h-[30px] hover:bg-gray-100 ${
              device?.type?.toLowerCase() === "shade_lutron"
                ? "cursor-pointer"
                : !canControl || isFullyOpen
                ? "opacity-50 cursor-not-allowed"
                : "cursor-pointer"
            }`}
            onClick={() => 
              device?.type?.toLowerCase() === "shade_lutron"
                ? canControl && onShadeUp(channel)
                : canControl && !isFullyOpen && onShadeUp(channel)
            }
            disabled={
              device?.type?.toLowerCase() === "shade_lutron"
                ? !canControl
                : !canControl || isFullyOpen
            }
          >
            <MdArrowDownSvg className="rotate-180 w-[12px] h-[12px]" />
          </button>
          
          {channel?.properties?.numberOfCmds === 4 ? (
            <>
              <button
                className={`border-l border-[#CCCCCC] flex items-center justify-center px-1 py-[3px] w-[35px] h-[30px] hover:bg-gray-100 ${
                  canControl ? "cursor-pointer" : "cursor-not-allowed"
                }`}
                onClick={() => canControl && onShade66(channel)}
                disabled={!canControl}
              >
                <ShadeSSSvg className="w-[14px] h-[14px]" />
              </button>
              <button
                className={`border-l border-[#CCCCCC] flex items-center justify-center px-1 py-[3px] w-[35px] h-[30px] hover:bg-gray-100 ${
                  canControl ? "cursor-pointer" : "cursor-not-allowed"
                }`}
                onClick={() => canControl && onShade33(channel)}
                disabled={!canControl}
              >
                <ShadeTTSvg className="w-[14px] h-[14px]" />
              </button>
            </>
          ) : (
            <button
              className={`border-l border-r border-[#CCCCCC] flex items-center justify-center px-1 py-[3px] w-[35px] h-[30px] hover:bg-gray-100 ${
                canControl ? "cursor-pointer" : "cursor-not-allowed"
              }`}
              onClick={() => canControl && onShadeStop(channel)}
              disabled={!canControl}
            >
              <StopSvg className="w-[20px] h-[20px]" />
            </button>
          )}
          
          <button
            className={`${channel?.properties?.numberOfCmds === 4 ? 'border-l border-[#CCCCCC]' : ''} flex items-center justify-center px-1 py-[3px] w-[35px] h-[30px] hover:bg-gray-100 ${
              device?.type?.toLowerCase() === "shade_lutron"
                ? "cursor-pointer"
                : !canControl || isFullyClosed
                ? "opacity-50 cursor-not-allowed"
                : "cursor-pointer"
            }`}
            onClick={() => 
              device?.type?.toLowerCase() === "shade_lutron"
                ? canControl && onShadeDown(channel)
                : canControl && !isFullyClosed && onShadeDown(channel)
            }
            disabled={
              device?.type?.toLowerCase() === "shade_lutron"
                ? !canControl
                : !canControl || isFullyClosed
            }
          >
            <MdArrowDownSvg className="w-[12px] h-[12px]" />
          </button>
        </div>
      </div>
    </div>
  );
};

function DeviceView({ selectedItem }) {
  const queryClient = useQueryClient();
  const [channelStates, setChannelStates] = useState({});
  const { user } = useUserStore();
  const userPermissions = useUserStore((state) => state.permissions);
  const canControl = userPermissions?.CONTROL_SECTION?.device_tab?.addModify;
  const { data, isLoading } = useGetDeviceByIdInControlSystem(
    selectedItem?.id,
    () => {
      setChannelStates({});
    }
  );

  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DEVICE_IN_CONTROL_SYSTEM],
      exact: false,
    });
  };

  // const channels = data?.data?.channels || [];
  const channels = data?.data?.installed_channels || [];
  const triggerEventMutation = useTriggerEvent({
    onSuccess: (response) => {
      // Optionally handle success response
    },
    onError: (error) => {
      console.error("Event trigger failed:", error);
    },
  });

  const getChannelKey = (channel) => `${selectedItem?.id}-${channel.id}`;

  const getUserData = () => ({
    userId: user?.id,
  });

  const handleLEDToggle = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const newStatus = currentState.status === "on" ? "off" : "on";

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          status: newStatus,
        },
      }));

      if (newStatus === "on") handleLEDBrightnessCommit(channel, 100)

      const userData = getUserData();

      const payload = {
        ...userData,
        device_id: selectedItem?.id,
        deviceData:
          newStatus === "on"
            ? {
                properties: {
                  brightness: parseInt(
                    currentState.properties?.brightness || 0
                  ),
                  // powerMin: 0,
                  // powerMax: 100,
                  powerMin: parseInt(currentState.properties?.powerMin || 0),
                  powerMax: parseInt(currentState.properties?.powerMax || 0),
                },
              }
            : {},
        channelType: "LED",
        channelAddress: channel.id,
        command: newStatus === "on" ? "LED_ON" : "LED_OFF",
      };

      triggerEventMutation.mutate(payload);
    },
    [channelStates, triggerEventMutation, selectedItem?.id]
  );

  const handleLEDBrightnessChange = useCallback(
    (channel, brightness) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            brightness: brightness,
          },
        },
      }));
    },
    [channelStates]
  );

  const handleLEDBrightnessCommit = useCallback(
    (channel, brightness) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      const userData = getUserData();

      const payload = {
        ...userData,
        device_id: selectedItem?.id,
        deviceData: {
          properties: {
            brightness: brightness,
            // powerMin: 0,
            // powerMax: 100,
            powerMin: parseInt(currentState.properties?.powerMin || 0),
            powerMax: parseInt(currentState.properties?.powerMax || 0),
          },
        },
        channelType: "LED",
        channelAddress: channel.id,
        command: "LED_BRIGHTNESS",
      };

      triggerEventMutation.mutate(payload, {
        onSuccess: () => {
          toaster.success("Brightness updated successfully");
        },
        onError: (error) => {
          toaster.error(
            error?.response?.data?.message || "Failed to update brightness"
          );
        },
      });
    },
    [channelStates, triggerEventMutation, selectedItem?.id]
  );

  const handleShadeUp = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") || 0
      );
      // For shade_lutron devices, set openLevel to 100 when going up
      // const newLevel = selectedItem?.type?.toLowerCase() === "shade_lutron" ? 100 : Math.min(100, currentLevel + 10);
      const newLevel = 100;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: selectedItem?.id,
        deviceData: {
          properties: {
            ...(selectedItem?.type?.toLowerCase() !== "shade_lutron" && { 
              // openLevel: newLevel
            }),
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          },
        },
        channelType: "SHADE",
        channelAddress: channel.id,
        command: "SHADE_UP",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [channelStates, triggerEventMutation, selectedItem?.id]
  );

  const handleShadeDown = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") || 0
      );
      // For shade_lutron devices, set openLevel to 0 when going down
      // const newLevel = selectedItem?.type?.toLowerCase() === "shade_lutron" ? 0 : Math.max(0, currentLevel - 10);
      const newLevel = 0;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: selectedItem?.id,
        deviceData: {
          properties: {
            ...(selectedItem?.type?.toLowerCase() !== "shade_lutron" && { 
              // openLevel: newLevel
            }),
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          },
        },
        channelType: "SHADE",
        channelAddress: channel.id,
        command: "SHADE_DOWN",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [channelStates, triggerEventMutation, selectedItem?.id]
  );

  const handleShadeStop = useCallback(
    (channel) => {
      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: selectedItem?.id,
        deviceData: {
          properties: {
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          }
        },
        channelType: "SHADE",
        channelAddress: channel.id,
        command: "SHADE_STOP",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [triggerEventMutation, selectedItem?.id]
  );

  const handleShade33 = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const newLevel = 33;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: selectedItem?.id,
        deviceData: {
          properties: {
            ...(selectedItem?.type?.toLowerCase() !== "shade_lutron" && { 
              // openLevel: newLevel 
            }),
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          },
        },
        channelType: "SHADE",
        channelAddress: channel.id,
        command: "SHADE_33",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [channelStates, triggerEventMutation, selectedItem?.id]
  );

  const handleShade66 = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const newLevel = 66;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: selectedItem?.id,
        deviceData: {
          properties: {
            ...(selectedItem?.type?.toLowerCase() !== "shade_lutron" && { 
              // openLevel: newLevel 
            }),
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          },
        },
        channelType: "SHADE",
        channelAddress: channel.id,
        command: "SHADE_66",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [channelStates, triggerEventMutation, selectedItem?.id]
  );

  const leds = channels
    .map((item) => ({
      ...item,
      id: item?.channel_id,
      channelId: item?.channel_id,
      name: item?.channel_name,
      type: item?.channel_type,
    }))
    ?.filter((device) => device.type === "led");
  const shades = channels
    .map((item) => ({
      ...item,
      id: item?.channel_id,
      channelId: item?.channel_id,
      name: item?.channel_name,
      type: item?.channel_type,
    }))
    ?.filter((device) => device.type === "shade");
  const sensors = channels
    .map((item) => ({
      ...item,
      id: item?.channel_id,
      channelId: item?.channel_id,
      name: item?.channel_name,
      type: item?.channel_type,
    }))
    ?.filter((device) => device.type === "sensor");

  if (isLoading)
    return (
      <div className="flex-grow flex items-center justify-center shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mb-5">
        <SpinnerV1 />
      </div>
    );

  return (
    <div className="flex-grow overflow-auto hide-scrollbar">
      <DeviceStatusChanged callback={realTimeChangeCallback} />
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mb-5">
        <div className="flex items-center justify-between pb-3 mb-5 border-b border-[#DDDDDD]">
          <h2 className="text-xs text-[#222222] font-semibold">LED Channels</h2>
        </div>
        <div className="grid grid-cols-4 1540:grid-cols-5 gap-[32px] mb-5 px-5">
          {leds?.length ? (
            leds?.map((led) => (
              <LEDCard
                key={led.id}
                channel={{ ...led, deviceId: selectedItem?.id }}
                onLEDToggle={handleLEDToggle}
                onLEDBrightnessChange={handleLEDBrightnessChange}
                onLEDBrightnessCommit={handleLEDBrightnessCommit}
                channelStates={channelStates}
                canControl={canControl}
              />
            ))
          ) : (
            <div className="text-xs text-[#7A838E]">
              Leds not configured yet.
            </div>
          )}
        </div>
      </div>
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mb-5">
        <div className="flex items-center justify-between pb-3 mb-5 border-b border-[#DDDDDD]">
          <h2 className="text-xs text-[#222222] font-semibold">
            Shade Channels
          </h2>
        </div>
        <div className="grid grid-cols-4 1540:grid-cols-5 gap-[32px] mb-5 px-5">
          {shades?.length ? (
            shades?.map((shade) => (
              <ShadeCard
                key={shade.id}
                channel={{ ...shade, deviceId: selectedItem?.id }}
                onShadeUp={handleShadeUp}
                onShadeDown={handleShadeDown}
                onShadeStop={handleShadeStop}
                onShade33={handleShade33}
                onShade66={handleShade66}
                channelStates={channelStates}
                canControl={canControl}
                device={selectedItem}
              />
            ))
          ) : (
            <div className="text-xs text-[#7A838E]">
              Shades not configured yet.
            </div>
          )}
        </div>
      </div>
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mb-5">
        <div className="flex items-center justify-between pb-3 mb-5 border-b border-[#DDDDDD]">
          <h2 className="text-xs text-[#222222] font-semibold">
            Sensor Channels
          </h2>
        </div>

        <div className="grid grid-cols-4 1540:grid-cols-5 gap-[32px] mb-5 px-5">
          {sensors?.length ? (
            sensors?.map((sensor) => (
              <SensorCard key={sensor.id} channel={sensor} />
            ))
          ) : (
            <div className="text-xs text-[#7A838E]">
              Sensors not configured yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default DeviceView;
