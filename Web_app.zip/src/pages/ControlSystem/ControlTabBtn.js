const ControlTabBtn = ({ isActive = false, title, ...props }) => {
  return (
    <button
      type="button"
      className={`h-[50px] px-[15px] py-[8px] flex items-center gap-[20px] ${
        isActive ? "bg-[#E6F0FC] border-b border-[#227EEB]" : "bg-[#ffffff]"
      }`}
      {...props}
    >
      <span
        className={`text-sm ${
          isActive ? "text-[#227EEB]" : "text-[#222222]"
        } font-semibold`}
      >
        {title}
      </span>
    </button>
  );
};

export default ControlTabBtn;
