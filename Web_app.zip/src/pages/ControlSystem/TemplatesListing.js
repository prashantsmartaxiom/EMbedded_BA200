import { useState, useEffect } from "react";
import { useDebouncedCallback } from "use-debounce";
import {
  useGetTemplates,
  useGetTemplatesInControlSystem,
} from "../../api/queryHooks";
import { PermissionDenied, SearchInput, SpinnerV1 } from "../../components";
import useUserStore from "../../store/useUserStore";

const TemplateCard = ({ template, onClick, isSelected }) => {
  return (
    <div title={template.name} className="cursor-pointer" onClick={onClick}>
      <div
        className={`flex items-center justify-center text-[#222222] bg-[#EBF0F8] border ${
          isSelected ? "border-[#227EEB]" : "border-[#dddddd]"
        } rounded-[10px] aspect-square`}
      >
        {template.layout === "landscape"
          ? `${template.rows}x${template.columns}`
          : `${template.columns}x${template.rows}`}
        x{template.layout}
      </div>
      <div className="mt-2 text-[#222222] text-[13px] truncate text-center">
        {template.name}
      </div>
    </div>
  );
};

function TemplatesListing({ selectedItem, handleSelectItem, onDataLoaded }) {
  const [searchTerm, setSearchTerm] = useState("");
  const userPermissions = useUserStore((state) => state.permissions);
  const { data, isLoading } = useGetTemplatesInControlSystem(searchTerm);

  const debouncedSearch = useDebouncedCallback((value) => {
    setSearchTerm(value);
  }, 300);

  const templates = data?.data?.data || [];
  const activeTemplates = templates.filter(template => template?.status === "Active");

  // Call onDataLoaded when data is available and not loading
  useEffect(() => {
    if (!isLoading && onDataLoaded && activeTemplates.length > 0) {
      const formattedItems = activeTemplates.map(template => ({ ...template, on: "template" }));
      onDataLoaded(formattedItems);
    } else if (!isLoading && onDataLoaded && activeTemplates.length === 0) {
      onDataLoaded([]);
    }
  }, [isLoading, activeTemplates, onDataLoaded]);

  if (!userPermissions?.CONTROL_SECTION?.template_tab?.readOnly)
    return (
      <PermissionDenied
        className="mt-40 text-center"
        text="You do not have permission to modify templates."
      />
    );
  return (
    <>
      <div className="p-5 mb-5 border-b border-[#DDDDDD]">
        <SearchInput 
          placeholder="Search by templates name…" 
          onChange={(e) => debouncedSearch(e.target.value)}
        />
      </div>
      <div className="overflow-auto">
        {isLoading ? (
          <SpinnerV1 />
        ) : templates?.length ? (
          <div className="grid grid-cols-2 px-5 pb-5 gap-5">
            {activeTemplates.map((template) => (
              <TemplateCard
                key={template._id}
                template={template}
                onClick={() =>
                  handleSelectItem({ ...template, on: "template" })
                }
                isSelected={selectedItem?._id === template._id}
              />
            ))}
          </div>
        ) : (
          <div className="text-center text-sm">No templates found.</div>
        )}
      </div>
    </>
  );
}

export default TemplatesListing;
