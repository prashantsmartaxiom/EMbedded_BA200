import { useState, useCallback, useEffect } from "react";
import { useDebouncedCallback } from "use-debounce";
import {
  useGetAllGroupsInControlSystem,
  useTriggerEvent,
} from "../../api/queryHooks";
import {
  BackspaceSvg,
  LEDSvg,
  LEDonSvg,
  SensorSvg,
  MdArrowDownSvg,
  StopSvg,
  ShadeSSSvg,
  ShadeTTSvg,
} from "../../assets/svg";
import {
  PrimaryBtn2,
  SearchInput,
  SpinnerV1,
  CurtainSvg,
  RangeSlider,
  PermissionDenied,
  DeviceStatusChanged,
} from "../../components";
import useUserStore from "../../store/useUserStore";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../api/queryKeys";
import toaster from "../../utils/toaster";

const GroupCard = ({
  group,
  onClick,
  isSelected,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit,
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  channelStates,
}) => {
  const userPermissions = useUserStore((state) => state.permissions);
  // Create main channel similar to TemplateView for groups
  const canControl = userPermissions?.CONTROL_SECTION?.group_tab?.addModify;

  const firstChannel =
    group.devices?.length && group.devices[0]?.channels?.length
      ? group.devices[0].channels[0]
      : null;

  const main_channel = firstChannel
    ? {
        ...firstChannel,
        isMainChannel: true,
        deviceId: group.devices[0].id,
        channelId: firstChannel.id,
        name: group.name,
        deviceType: group.devices[0].device_type, // Add device type for compatibility
      }
    : null;

  const device_type = group?.devices?.[0]?.device_type;

  return (
    <div
      title={group.name}
      className={`p-[10px] rounded-[10px] aspect-square border truncate flex flex-col ${
        isSelected ? "border-[#227EEB]" : "border-[#DDDDDD]"
      }`}
    >
      <div className="flex items-center justify-between gap-3 cursor-pointer">
        <span className="truncate text-sm text-[#222222]">{group.name}</span>
        <button onClick={onClick}>
          <BackspaceSvg className="rotate-180 text-xl" />
        </button>
      </div>
      <div
        className={`${
          canControl ? "cursor-pointer" : "cursor-not-allowed"
        } flex flex-col flex-grow`}
      >
        <div
          className={`flex flex-col items-center justify-center mt-3 flex-grow ${
            canControl ? "" : "pointer-events-none"
          }`}
        >
          {main_channel?.type === "led" ? (
            <div className="flex flex-col items-center w-full h-full">
              <div
                className="flex-grow flex items-center justify-center"
                onClick={() => {
                  if (userPermissions?.CONTROL_SECTION?.group_tab?.addModify) {
                    onLEDToggle(main_channel, true, group);
                  }
                }}
              >
                {(channelStates[
                  `${main_channel.deviceId}-${main_channel.channelId}`
                ]?.status || main_channel?.status) === "on" ? (
                  <LEDonSvg className="w-[80px] h-[80px]" />
                ) : (
                  <LEDSvg className="w-[80px] h-[80px]" />
                )}
              </div>
              <div className="w-full px-2">
                <RangeSlider
                  // min={parseInt(main_channel?.properties?.powerMin || 0)}
                  // max={parseInt(main_channel?.properties?.powerMax || 100)}
                  min={0}
                  max={100}
                  value={parseInt(
                    channelStates[
                      `${main_channel.deviceId}-${main_channel.channelId}`
                    ]?.properties?.brightness ||
                      main_channel?.properties?.brightness ||
                      0
                  )}
                  onChange={(value) =>
                    onLEDBrightnessChange(main_channel, value, true, group)
                  }
                  onValueCommit={(value) =>
                    onLEDBrightnessCommit(main_channel, value, true, group)
                  }
                  disabled={
                    (channelStates[
                      `${main_channel.deviceId}-${main_channel.channelId}`
                    ]?.status || main_channel?.status) !== "on"
                  }
                  tooltipPosition="top"
                  size="sm"
                />
              </div>
            </div>
          ) : main_channel?.type === "shade" ? (
            <div className="flex flex-col items-center w-full h-full">
              <div className="flex-grow flex items-center justify-center">
                <CurtainSvg
                  openValue={parseInt(
                    (
                      channelStates[
                        `${main_channel.deviceId}-${main_channel.channelId}`
                      ]?.properties?.openLevel ||
                      main_channel?.properties?.openLevel ||
                      "0%"
                    ).replace?.("%", "")
                  )}
                  className="w-[80px] h-[80px]"
                />
              </div>
              <div className="text-xs text-center text-gray-600 mt-1 mb-2">
                {main_channel?.deviceType?.toLowerCase() === "shade_lutron" 
                  ? `${main_channel?.properties?.numberOfCmds || 3}/4 commands`
                  : ""
                }
              </div>
              <div className="bg-[#F5F9FD] border border-[#CCCCCC] rounded-lg grid text-[#222222]"
                   style={{
                     gridTemplateColumns: main_channel?.properties?.numberOfCmds === 4 ? 'repeat(4, 1fr)' : 'repeat(3, 1fr)'
                   }}>
                <button
                  className={`flex items-center justify-center px-1 py-[2px] w-[35px] h-[30px] ${
                    main_channel?.deviceType?.toLowerCase() === "shade_lutron" 
                      ? "hover:bg-gray-100 cursor-pointer"
                      : "hover:bg-gray-100 cursor-pointer"
                  }`}
                  onClick={() => onShadeUp(main_channel, true, group)}
                >
                  <MdArrowDownSvg className="rotate-180 text-xs w-[12px] h-[12px]" />
                </button>
                
                {main_channel?.properties?.numberOfCmds === 4 ? (
                  <>
                    <button
                      className="border-l border-[#CCCCCC] flex items-center justify-center px-1 py-[2px] w-[35px] h-[30px] hover:bg-gray-100 cursor-pointer"
                      onClick={() => onShade66(main_channel, true, group)}
                    >
                      <ShadeSSSvg className="w-[14px] h-[14px]" />
                    </button>
                    <button
                      className="border-l border-[#CCCCCC] flex items-center justify-center px-1 py-[2px] w-[35px] h-[30px] hover:bg-gray-100 cursor-pointer"
                      onClick={() => onShade33(main_channel, true, group)}
                    >
                      <ShadeTTSvg className="w-[14px] h-[14px]" />
                    </button>
                  </>
                ) : (
                  <button
                    className="border-l border-r border-[#CCCCCC] flex items-center justify-center px-1 py-[2px] w-[35px] h-[30px] hover:bg-gray-100 cursor-pointer"
                    onClick={() => onShadeStop(main_channel, true, group)}
                  >
                    <StopSvg className="text-xs w-[20px] h-[20px]" />
                  </button>
                )}
                
                <button
                  className={`${main_channel?.properties?.numberOfCmds === 4 ? 'border-l border-[#CCCCCC]' : ''} flex items-center justify-center px-1 py-[2px] w-[35px] h-[30px] ${
                    main_channel?.deviceType?.toLowerCase() === "shade_lutron" 
                      ? "hover:bg-gray-100 cursor-pointer"
                      : "hover:bg-gray-100 cursor-pointer"
                  }`}
                  onClick={() => onShadeDown(main_channel, true, group)}
                >
                  <MdArrowDownSvg className="text-xs w-[12px] h-[12px]" />
                </button>
              </div>
            </div>
          ) : main_channel?.type === "sensor" ? (
            <div className="flex flex-col items-center w-full h-full">
              <div className="flex-grow flex items-center justify-center">
                <SensorSvg
                  className={`w-[80px] h-[80px] ${
                    main_channel?.status === "active"
                      ? "text-blue-500"
                      : "text-gray-400"
                  }`}
                />
              </div>
              <div className="mt-1 text-xs text-center text-gray-600">
                {main_channel?.status || "inactive"}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center w-full">
              <div className="w-[40px] h-[40px] bg-gray-200 rounded-full flex items-center justify-center">
                <span className="text-xs text-gray-500">?</span>
              </div>
              <span className="text-xs text-[#7A838E] mt-1">NONE</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

function GroupsListing({ selectedItem, handleSelectItem, onDataLoaded }) {
  const [channelStates, setChannelStates] = useState({});
  const [searchTerm, setSearchTerm] = useState("");
  const userPermissions = useUserStore((state) => state.permissions);
  const { data: groupsData, isLoading } = useGetAllGroupsInControlSystem(
    searchTerm,
    () => {
      setChannelStates({});
    }
  );
  const { user } = useUserStore();

  const queryClient = useQueryClient();
  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.GET_ALL_GROUPS_IN_CONTROL_SYSTEM],
      exact: false,
    });

    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.GROUPS],
      exact: false,
    });
  };

  const debouncedSearch = useDebouncedCallback((value) => {
    setSearchTerm(value);
  }, 300);

  const triggerEventMutation = useTriggerEvent({
    onSuccess: (response) => {
      // success handling if needed
    },
    onError: (error) => {
      // error handling if needed
    },
  });

  const getChannelKey = (channel) => `${channel.deviceId}-${channel.channelId}`;

  const getUserData = () => ({
    userId: user?.id,
  });

  const handleLEDToggle = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const newStatus = currentState.status === "on" ? "off" : "on";

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          status: newStatus,
        },
      }));

      const userData = getUserData();
      const payload = isGroup
        ? {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              devices: groupData.devices?.map((device) => ({
                deviceId: device.id,
                channels: device.channels.map((ch) => ({
                  channelId: ch.id,
                  channelType: ch?.type?.toUpperCase(),
                  numberOfCmds: ch?.properties?.numberOfCmds,
                })),
              })),
            },
            channelType: "",
            channelAddress: "",
            command: newStatus === "on" ? "GROUP_LED_ON" : "GROUP_LED_OFF",
            groupId: groupData?.id,
          }
        : {
            ...userData,
            device_id: channel.deviceId,
            deviceData:
              newStatus === "on"
                ? {
                    properties: {
                      brightness: parseInt(
                        currentState.properties?.brightness || 0
                      ),
                      powerMin: parseInt(
                        currentState.properties?.powerMin || 0
                        // 0
                      ),
                      powerMax: parseInt(
                        currentState.properties?.powerMax || 0
                        // 100
                      ),
                    },
                  }
                : {},
            channelType: "LED",
            channelAddress: channel.channelId,
            command: newStatus === "on" ? "LED_ON" : "LED_OFF",
          };

      triggerEventMutation.mutate(payload);
    },
    [channelStates, triggerEventMutation, user]
  );

  const handleLEDBrightnessChange = useCallback(
    (channel, brightness, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            brightness: brightness,
          },
        },
      }));
    },
    [channelStates]
  );

  const handleLEDBrightnessCommit = useCallback(
    (channel, brightness, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      const userData = getUserData();

      const payload = isGroup
        ? {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              devices: groupData.devices?.map((device) => ({
                deviceId: device.id,
                channels: device.channels.map((ch) => ({
                  channelId: ch.id,
                  channelType: ch?.type?.toUpperCase(),
                  numberOfCmds: ch?.properties?.numberOfCmds,
                })),
              })),
            },
            channelType: "",
            channelAddress: "",
            command: `GROUP_LED_BRIGHTNESS${brightness}`,
          }
        : {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              properties: {
                brightness: brightness,
                // powerMin: 0,
                // powerMax: 100,
                powerMin: parseInt(currentState.properties?.powerMin || 0),
                powerMax: parseInt(currentState.properties?.powerMax || 0),
              },
            },
            channelType: "LED",
            channelAddress: channel.channelId,
            command: "LED_BRIGHTNESS",
          };

      triggerEventMutation.mutate(payload, {
        onSuccess: () => {
          toaster.success("Brightness updated successfully");
        },
        onError: (error) => {
          toaster.error(
            error?.response?.data?.message || "Failed to update brightness"
          );
        },
      });
    },
    [channelStates, triggerEventMutation, user]
  );

  const handleShadeUp = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      
      // Find the device to check its type
      const device = groupData?.devices?.find(d => d.id === channel.deviceId);
      const isLutronShade = device?.device_type?.toLowerCase() === "shade_lutron";
      
      if (isLutronShade) {
        // For shade_lutron, set to 100%
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: "100%",
            },
          },
        }));
      } else {
        // For regular shades, increment by 10%
        const currentLevel = parseInt(
          currentState.properties?.openLevel?.replace?.("%", "") || 0
        );
        // const newLevel = Math.min(100, currentLevel + 10);
        const newLevel = 100;

        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));
      }

      const userData = getUserData();
      const payload = isGroup
        ? {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              devices: groupData.devices?.map((device) => ({
                deviceId: device.id,
                channels: device.channels.map((ch) => ({
                  channelId: ch.id,
                  channelType: ch?.type?.toUpperCase(),
                  ...(ch?.type === "shade" && device?.device_type?.toLowerCase() !== "shade_lutron" && {
                    // openLevel: parseInt(
                    //   (channelStates[`${device.id}-${ch.id}`]?.properties?.openLevel || ch?.properties?.openLevel || "0%").replace?.("%", "")
                    // ) + 10,
                    // openLevel: 100,
                  }),
                  numberOfCmds: ch?.properties?.numberOfCmds,
                })),
              })),
            },
            channelType: "",
            channelAddress: "",
            groupId: groupData?.id,
            command: "GROUP_SHADE_UP",
          }
        : {
            ...userData,
            device_id: channel.deviceId,
            deviceData: isLutronShade ? {} : {
              ...channel,
            },
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_UP",
          };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [channelStates, triggerEventMutation, user]
  );

  const handleShadeDown = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      
      // Find the device to check its type
      const device = groupData?.devices?.find(d => d.id === channel.deviceId);
      const isLutronShade = device?.device_type?.toLowerCase() === "shade_lutron";
      
      if (isLutronShade) {
        // For shade_lutron, set to 0%
        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: "0%",
            },
          },
        }));
      } else {
        // For regular shades, decrement by 10%
        const currentLevel = parseInt(
          currentState.properties?.openLevel?.replace?.("%", "") || 0
        );
        // const newLevel = Math.max(0, currentLevel - 10);
        const newLevel = 0;

        setChannelStates((prev) => ({
          ...prev,
          [key]: {
            ...currentState,
            properties: {
              ...currentState.properties,
              openLevel: `${newLevel}%`,
            },
          },
        }));
      }

      const userData = getUserData();
      const payload = isGroup
        ? {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              devices: groupData.devices?.map((device) => ({
                deviceId: device.id,
                channels: device.channels.map((ch) => ({
                  channelId: ch.id,
                  channelType: ch?.type?.toUpperCase(),
                  ...(ch?.type === "shade" && device?.device_type?.toLowerCase() !== "shade_lutron" && {
                    // openLevel: Math.max(0, parseInt(
                    //   (channelStates[`${device.id}-${ch.id}`]?.properties?.openLevel || ch?.properties?.openLevel || "0%").replace?.("%", "")
                    // ) - 10)
                    // openLevel: 0,
                  }),
                  numberOfCmds: ch?.properties?.numberOfCmds,
                })),
              })),
            },
            channelType: "",
            channelAddress: "",
            groupId: groupData?.id,
            command: "GROUP_SHADE_DOWN",
          }
        : {
            ...userData,
            device_id: channel.deviceId,
            deviceData: isLutronShade ? {} : {},
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_DOWN",
          };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [channelStates, triggerEventMutation, user]
  );

  const handleShade33 = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const newLevel = 33;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const device = groupData?.devices?.find(d => d.id === channel.deviceId);
      
      const payload = isGroup
        ? {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              devices: groupData.devices?.map((device) => ({
                deviceId: device.id,
                channels: device.channels.map((ch) => ({
                  channelId: ch.id,
                  channelType: ch?.type?.toUpperCase(),
                  ...(ch?.type === "shade" && device?.device_type?.toLowerCase() !== "shade_lutron" && {
                    // openLevel: newLevel
                  }),
                  numberOfCmds: ch?.properties?.numberOfCmds,
                })),
              })),
            },
            channelType: "",
            channelAddress: "",
            groupId: groupData?.id,
            command: "GROUP_SHADE_33",
          }
        : {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              properties: {
                ...(device?.device_type?.toLowerCase() !== "shade_lutron" && { openLevel: newLevel }),
                numberOfCmds: channel?.properties?.numberOfCmds || null,
              },
            },
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_33",
          };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [channelStates, triggerEventMutation, user]
  );

  const handleShade66 = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const newLevel = 66;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const device = groupData?.devices?.find(d => d.id === channel.deviceId);
      
      const payload = isGroup
        ? {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              devices: groupData.devices?.map((device) => ({
                deviceId: device.id,
                channels: device.channels.map((ch) => ({
                  channelId: ch.id,
                  channelType: ch?.type?.toUpperCase(),
                  ...(ch?.type === "shade" && device?.device_type?.toLowerCase() !== "shade_lutron" && {
                    // openLevel: newLevel
                  }),
                  numberOfCmds: ch?.properties?.numberOfCmds,
                })),
              })),
            },
            channelType: "",
            channelAddress: "",
            groupId: groupData?.id,
            command: "GROUP_SHADE_66",
          }
        : {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              properties: {
                ...(device?.device_type?.toLowerCase() !== "shade_lutron" && { openLevel: newLevel }),
                numberOfCmds: channel?.properties?.numberOfCmds || null,
              },
            },
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_66",
          };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [channelStates, triggerEventMutation, user]
  );

  const handleShadeStop = useCallback(
    (channel, isGroup = false, groupData = null) => {
      const userData = getUserData();
      const payload = isGroup
        ? {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {
              devices: groupData.devices?.map((device) => ({
                deviceId: device.id,
                channels: device.channels.map((ch) => ({
                  channelId: ch.id,
                  channelType: ch?.type?.toUpperCase(),
                  numberOfCmds: ch?.properties?.numberOfCmds,
                })),
              })),
            },
            channelType: "",
            channelAddress: "",
            groupId: groupData?.id,
            command: "GROUP_SHADE_STOP",
          }
        : {
            ...userData,
            device_id: channel.deviceId,
            deviceData: {},
            channelType: "SHADE",
            channelAddress: channel.channelId,
            command: "SHADE_STOP",
          };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [triggerEventMutation, user]
  );

  const mappedGroups =
    groupsData?.data?.data?.map((group) => ({
      id: group.group_id,
      name: group.group_name,
      devices:
        group.devices?.map((device) => ({
          id: device.device_id,
          name: device.device_name,
          device_type: device.device_type,
          mac_addr: device.hardware_info?.mac_address,
          // Only include channels that are part of this group
          channels:
            device.channels
              ?.filter((channel) => channel.is_in_group)
              .map((channel) => ({
                id: channel.channel_id,
                name: channel.channel_name,
                type: channel.channel_type,
                status: channel.status,
                properties: channel.properties,
              })) || [],
        })) || [],
    })) || [];

  // Call onDataLoaded when data is available and not loading
  useEffect(() => {
    if (!isLoading && onDataLoaded && mappedGroups.length > 0) {
      const formattedItems = mappedGroups.map((group) => ({
        ...group,
        on: "group",
      }));
      onDataLoaded(formattedItems);
    } else if (!isLoading && onDataLoaded && mappedGroups.length === 0) {
      onDataLoaded([]);
    }
  }, [isLoading, mappedGroups, onDataLoaded]);

  if (!userPermissions?.CONTROL_SECTION?.group_tab?.readOnly)
    return (
      <PermissionDenied
        className="mt-40 text-center"
        text="You do not have permission to modify groups."
      />
    );

  return (
    <>
      <DeviceStatusChanged callback={realTimeChangeCallback} />
      <div className="p-5 mb-5 border-b border-[#DDDDDD]">
        <SearchInput
          placeholder="Search by groups name…"
          onChange={(e) => debouncedSearch(e.target.value)}
        />
      </div>
      <div className="overflow-auto">
        {isLoading ? (
          <div className="p-5">
            <SpinnerV1 />
          </div>
        ) : mappedGroups?.length ? (
          <div className="grid grid-cols-2 px-5 pb-5 gap-5">
            {mappedGroups?.map((group) => {
              return (
                <GroupCard
                  key={group.id}
                  group={group}
                  onClick={() => handleSelectItem({ ...group, on: "group" })}
                  isSelected={selectedItem?.id === group.id}
                  onLEDToggle={handleLEDToggle}
                  onLEDBrightnessChange={handleLEDBrightnessChange}
                  onLEDBrightnessCommit={handleLEDBrightnessCommit}
                  onShadeUp={handleShadeUp}
                  onShadeDown={handleShadeDown}
                  onShadeStop={handleShadeStop}
                  onShade33={handleShade33}
                  onShade66={handleShade66}
                  channelStates={channelStates}
                />
              );
            })}
          </div>
        ) : (
          <div className="text-center text-sm">No groups found.</div>
        )}
      </div>
    </>
  );
}

export default GroupsListing;
