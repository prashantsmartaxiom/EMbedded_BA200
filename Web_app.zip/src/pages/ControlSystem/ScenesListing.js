import { useState, useEffect } from "react";
import { useDebouncedCallback } from "use-debounce";
import {
  DeviceStatusChanged,
  PermissionDenied,
  PrimaryBtn2,
  RangeSlider,
  SearchInput,
  SpinnerV1,
} from "../../components";
import {
  useGetScenesInControlSystem,
  useTriggerEvent,
} from "../../api/queryHooks";
import useUserStore from "../../store/useUserStore";
import toaster from "../../utils/toaster";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../api/queryKeys";
import { NounLEDSvg, NounShadeSvg } from "../../assets/svg";
import { formatTimev2, padStart } from "../../utils/helpers";

export const SceneCard = ({ scene, onClick, isSelected, usedIn }) => {
  const userPermissions = useUserStore((state) => state.permissions);
  const canControl = userPermissions?.CONTROL_SECTION?.scene_tab?.addModify;

  const queryClient = useQueryClient();

  const { mutate: triggerEvent } = useTriggerEvent({
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.GET_ALL_SCENES_IN_CONTROL_SYSTEM],
      });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.DASHBOARD_DEVICE_INFO],
      });
      toaster.success("Scene executed successfully");
    },
    onError: (error) => {
      toaster.error(
        error?.response?.data?.message || "Failed to execute scene"
      );
    },
  });
  const { user } = useUserStore();

  const handleExecuteScene = (e) => {
    e.stopPropagation(); // Prevent triggering the card onClick

    const userData = {
      user_id: user?.user_id,
    };

    const payload = {
      ...userData,
      deviceData: scene._id,
      command: "SCENE_EXECUTE",
    };

    if (scene?.operateType === "invert")
      payload.invertFlag = !scene?.invert_flag;

    triggerEvent(payload);
  };

  if (usedIn === "dashboard") {
    return (
      <div
        title={scene.name}
        className={`cursor-pointer pb-[10px] mb-[15px] border-b border-[#CCCCCC]`}
        onClick={onClick}
      >
        <div className="flex items-end justify-between truncate">
          <div className="truncate mr-2">
            <h3 className="text-sm text-[#222222] font-medium truncate">
              {scene.name}
            </h3>
            <p className="font-medium text-xs text-[#7A838E] mt-[5px] truncate">
              {scene?.type?.toUpperCase()}
            </p>
          </div>
          {canControl ? (
            <div>
              {scene?.operateType === "invert" ? (
                scene?.invert_flag ? (
                  <PrimaryBtn2
                    className={"w-[66px] justify-center"}
                    onClick={handleExecuteScene}
                  >
                    Set On
                  </PrimaryBtn2>
                ) : (
                  <PrimaryBtn2
                    className={"w-[66px] justify-center"}
                    onClick={handleExecuteScene}
                  >
                    Set Off
                  </PrimaryBtn2>
                )
              ) : (
                <PrimaryBtn2
                  className={"w-[66px] justify-center"}
                  onClick={handleExecuteScene}
                >
                  Execute
                </PrimaryBtn2>
              )}
            </div>
          ) : null}
        </div>
        <div className="flex items-center gap-[40px] mt-[10px]">
          <button
            type="button"
            className="flex items-center gap-[4px] text-[#222222] text-[11px]"
          >
            <NounLEDSvg className="text-base" />{" "}
            {padStart(scene?.channelCounts?.leds || 0)}
          </button>
          <button
            type="button"
            className="flex items-center gap-[4px] text-[#222222] text-[11px]"
          >
            <NounShadeSvg className="text-base" />{" "}
            {padStart(scene?.channelCounts?.shades || 0)}
          </button>
        </div>
        <div className="w-full">
          {scene?.lastExecuted ? (
            <button
              type="button"
              className="text-[#7A838E] w-full text-right text-xs"
            >
              {formatTimev2(scene?.lastExecuted)}
              {scene?.operateType === "invert"
                ? `${scene?.invert_flag ? " (Set Off)" : " (Set On)"}`
                : ""}
            </button>
          ) : (
            <button
              type="button"
              className="text-[#7A838E] w-full text-right text-xs"
            >
              Not Executed Yet
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div
      title={scene.name}
      className={`cursor-pointer p-[10px] rounded-[10px] border ${
        isSelected ? "border-[#227EEB]" : "border-[#DDDDDD]"
      }`}
      onClick={onClick}
    >
      <div className="flex justify-between truncate">
        <div className="truncate mr-2">
          <h2 className="text-sm text-[#222222] font-semibold truncate">
            {scene.name}
          </h2>
          <p className="text-xs text-[#939CA7] truncate">
            {/* {scene.devices?.length
              ? scene.devices[0]?.name
              : scene.groups?.length
              ? scene.groups[0]?.name
              : ""} */}
            {scene?.type?.toUpperCase()}
          </p>
        </div>
        {canControl ? (
          <div>
            {scene?.operateType === "invert" ? (
              scene?.invert_flag ? (
                <PrimaryBtn2
                  className={"w-[66px] justify-center"}
                  onClick={handleExecuteScene}
                >
                  Set On
                </PrimaryBtn2>
              ) : (
                <PrimaryBtn2
                  className={"w-[66px] justify-center"}
                  onClick={handleExecuteScene}
                >
                  Set Off
                </PrimaryBtn2>
              )
            ) : (
              <PrimaryBtn2
                className={"w-[66px] justify-center"}
                onClick={handleExecuteScene}
              >
                Execute
              </PrimaryBtn2>
            )}
          </div>
        ) : null}
      </div>
    </div>
  );
};

function ScenesListing({ selectedItem, handleSelectItem, data, onDataLoaded }) {
  const [searchTerm, setSearchTerm] = useState("");
  const userPermissions = useUserStore((state) => state.permissions);
  const { data: scenesData, isLoading } =
    useGetScenesInControlSystem(searchTerm);

  const queryClient = useQueryClient();
  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.GET_ALL_SCENES_IN_CONTROL_SYSTEM],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.SCENES],
      exact: false,
    });
  };

  const debouncedSearch = useDebouncedCallback((value) => {
    setSearchTerm(value);
  }, 300);

  const scenes = scenesData?.data?.scenes || [];

  // Call onDataLoaded when data is available and not loading
  useEffect(() => {
    if (!isLoading && onDataLoaded && scenes.length > 0) {
      const formattedItems = scenes.map((scene) => ({ ...scene, on: "scene" }));
      onDataLoaded(formattedItems);
    } else if (!isLoading && onDataLoaded && scenes.length === 0) {
      onDataLoaded([]);
    }
  }, [isLoading, scenes, onDataLoaded]);

  if (!userPermissions?.CONTROL_SECTION?.scene_tab?.readOnly)
    return (
      <PermissionDenied
        className="mt-40 text-center"
        text="You do not have permission to modify scenes."
      />
    );

  return (
    <>
      <DeviceStatusChanged callback={realTimeChangeCallback} />
      <div className="p-5 mb-5 border-b border-[#DDDDDD]">
        <SearchInput
          placeholder="Search by scenes name…"
          onChange={(e) => debouncedSearch(e.target.value)}
        />
      </div>
      <div className="overflow-auto">
        {isLoading ? (
          <div className="p-5">
            <SpinnerV1 />
          </div>
        ) : scenesData?.data?.scenes?.length ? (
          <div className="grid grid-cols-2 px-5 pb-5 gap-5">
            {scenesData?.data?.scenes?.map((scene) => (
              <SceneCard
                key={scene._id}
                scene={scene}
                onClick={() =>
                  handleSelectItem({
                    ...scene,
                    on: "scene",
                  })
                }
                isSelected={selectedItem?._id === scene._id}
              />
            ))}
          </div>
        ) : (
          <div className="text-center text-sm">No scenes found.</div>
        )}
      </div>
    </>
  );
}

export default ScenesListing;
