import { useState } from "react";
import {
  LEDonSvg,
  LEDSvg,
  MdArrowDownSvg,
  SensorSvg,
  StopSvg,
  ShadeSSSvg,
  ShadeTTSvg,
} from "../../assets/svg";
import { CurtainSvg, RangeSlider } from "../../components";

const ChannelItem = ({
  channel,
  mainChannel = false,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit, // New prop for API call on mouse up
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  channelStates,
  isGroup = false,
  groupData = null,
  canControl = true, // New prop for permission control
}) => {
  if (channel?.type === "led") {
    const currentState =
      channelStates[`${channel.deviceId}-${channel.channelId}`] || channel;
    const isOn = currentState.status === "on";
    const brightness = parseInt(currentState.properties?.brightness || 0);
    const powerMin = 0;
    const powerMax = 100;
    // const powerMin = parseInt(currentState.properties?.powerMin || 0);
    // const powerMax = parseInt(currentState.properties?.powerMax || 100);

    return (
      <div className="flex flex-col items-center gap-2 w-full h-full truncate">
        {mainChannel ? null : (
          <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
            {channel.isMainChannel
              ? channel?.channelName || channel?.name || channel.channelId
              : channel?.channelName || channel?.name || channel.channelId}
          </h2>
        )}
        <div
          className={`flex-1 flex items-center justify-center w-full h-full ${
            canControl ? "cursor-pointer" : "cursor-not-allowed"
          }`}
          onClick={() => canControl && onLEDToggle(channel, isGroup, groupData)}
        >
          {isOn ? (
            <LEDonSvg className="w-[100px] h-[100px] max-w-[120px] max-h-[120px]" />
          ) : (
            <LEDSvg className="w-[94px] h-[94px] max-w-[120px] max-h-[120px]" />
          )}
        </div>
        <div className="w-full max-w-[240px]">
          <RangeSlider
            min={powerMin}
            max={powerMax}
            value={brightness}
            onChange={(value) =>
              onLEDBrightnessChange(channel, value, isGroup, groupData)
            }
            onValueCommit={(value) =>
              onLEDBrightnessCommit(channel, value, isGroup, groupData)
            }
            disabled={!isOn || !canControl}
          />
        </div>
      </div>
    );
  }

  if (channel?.type === "shade") {
    const currentState =
      channelStates[`${channel.deviceId}-${channel.channelId}`] || channel;
    const openLevel = parseInt(
      currentState.properties?.openLevel?.replace?.("%", "") || 0
    );
    const isFullyOpen = openLevel >= 100;
    const isFullyClosed = openLevel <= 0;
    const isLutronShade = channel?.deviceType?.toLowerCase() === "shade_lutron";

    return (
      <div className="flex flex-col items-center gap-2 w-full h-full truncate">
        {mainChannel ? null : (
          <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
            {channel.isMainChannel
              ? channel?.channelName || channel?.name || channel.channelId
              : channel?.channelName || channel?.name || channel.channelId}
          </h2>
        )}
        <div className="flex-1 flex items-center justify-center w-full h-full">
          <CurtainSvg
            openValue={openLevel}
            className="h-[60%] max-w-[120px] max-h-[120px]"
          />
        </div>
        <div className="text-xs text-center text-gray-600 mb-1">
          {isLutronShade
            ? `${channel?.properties?.numberOfCmds || 3}/4 commands`
            : ``}
        </div>
        <div className="w-full flex items-center justify-center">
          <div
            className="h-[30px] bg-[#F5F9FD] border border-[#CCCCCC] rounded-lg w-full max-w-32 grid text-[#222222]"
            style={{
              gridTemplateColumns:
                channel?.properties?.numberOfCmds === 4
                  ? "repeat(4, 1fr)"
                  : "repeat(3, 1fr)",
            }}
          >
            <button
              className={`flex items-center justify-center hover:bg-gray-100 ${
                !canControl || (!isLutronShade && isFullyOpen)
                  ? "opacity-50 cursor-not-allowed"
                  : "cursor-pointer"
              }`}
              onClick={() =>
                canControl &&
                (!isLutronShade ? !isFullyOpen : true) &&
                onShadeUp(channel, isGroup, groupData)
              }
              disabled={!canControl || (!isLutronShade && isFullyOpen)}
            >
              <MdArrowDownSvg className="rotate-180 w-[12px] h-[12px]" />
            </button>

            {channel?.properties?.numberOfCmds === 4 ? (
              <>
                <button
                  className={`border-l border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100 ${
                    canControl ? "cursor-pointer" : "cursor-not-allowed"
                  }`}
                  onClick={() =>
                    canControl && onShade66(channel, isGroup, groupData)
                  }
                  disabled={!canControl}
                >
                  <ShadeSSSvg className="w-[14px] h-[14px]" />
                </button>
                <button
                  className={`border-l border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100 ${
                    canControl ? "cursor-pointer" : "cursor-not-allowed"
                  }`}
                  onClick={() =>
                    canControl && onShade33(channel, isGroup, groupData)
                  }
                  disabled={!canControl}
                >
                  <ShadeTTSvg className="w-[14px] h-[14px]" />
                </button>
              </>
            ) : (
              <button
                className={`border-l border-r border-[#CCCCCC] flex items-center justify-center hover:bg-gray-100 ${
                  canControl ? "cursor-pointer" : "cursor-not-allowed"
                }`}
                onClick={() =>
                  canControl && onShadeStop(channel, isGroup, groupData)
                }
                disabled={!canControl}
              >
                <StopSvg className="w-[20px] h-[20px]" />
              </button>
            )}

            <button
              className={`${
                channel?.properties?.numberOfCmds === 4
                  ? "border-l border-[#CCCCCC]"
                  : ""
              } flex items-center justify-center hover:bg-gray-100 ${
                !canControl || (!isLutronShade && isFullyClosed)
                  ? "opacity-50 cursor-not-allowed"
                  : "cursor-pointer"
              }`}
              onClick={() =>
                canControl &&
                (!isLutronShade ? !isFullyClosed : true) &&
                onShadeDown(channel, isGroup, groupData)
              }
              disabled={!canControl || (!isLutronShade && isFullyClosed)}
            >
              <MdArrowDownSvg className="w-[12px] h-[12px]" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (channel?.type === "sensor") {
    return (
      <div className="flex flex-col items-center gap-2 w-full h-full truncate">
        {mainChannel ? null : (
          <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
            Sensor
          </h2>
        )}
        <div className="flex-1 flex items-center justify-center w-full h-full">
          <SensorSvg
            className={`h-[60%] max-w-[120px] max-h-[120px] ${
              channel.status === "active" ? "text-blue-500" : "text-gray-400"
            }`}
          />
        </div>
        <div className="text-sm text-center text-gray-600">
          {channel.status || "inactive"}
        </div>
      </div>
    );
  }

  return null;
};

const GroupTemplateCard = ({
  data,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit, // New prop
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  channelStates,
  canControl = true, // New prop for permission control
}) => {
  const [currentPage, setCurrentPage] = useState(0);

  const pages = [];

  // Create main channel using the first channel's properties but as a separate entity
  const firstChannel = data?.elements?.[0];
  const mainChannel = firstChannel
    ? {
        ...firstChannel,
        // Keep original properties but mark it as main channel
        isMainChannel: true,
        // Use the group name for display but keep original channel data
        name: data?.group_name || firstChannel.name,
        // Preserve all original channel properties for API calls
      }
    : null;

  if (mainChannel) {
    // First page shows the main channel (derived from first channel)
    pages.push([mainChannel]);
  }

  // All original channels (including the first one) for subsequent pages
  const allChannels =
    data?.elements?.filter((ele) => ele?.channelType !== "sensor") || [];

  for (let i = 0; i < allChannels.length; i += 2) {
    pages.push(allChannels.slice(i, i + 2));
  }

  const totalPages = pages.length;

  return (
    <div className="w-full h-full flex flex-col items-center justify-center p-2 relative">
      {currentPage === 0 ? (
        <h2 className="text-center font-semibold w-full truncate text-[clamp(12px,2vw,20px)] mt-8">
          {data?.group_name || data?.name}
        </h2>
      ) : null}

      {/* Carousel Content */}
      {allChannels?.length === 0 ? (
        <div className="flex-1 flex items-center justify-center w-full h-full">
          Currently not available
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center w-full h-full">
          <div className="w-full h-full flex flex-col items-center justify-center">
            {/* Main content area */}
            <div className="flex-1 flex items-center justify-center w-full">
              {currentPage === 0 && pages[currentPage]?.length === 1 ? (
                <div className="flex items-center justify-center w-full h-full">
                  <ChannelItem
                    channel={pages[currentPage][0]}
                    mainChannel={true}
                    onLEDToggle={onLEDToggle}
                    onLEDBrightnessChange={onLEDBrightnessChange}
                    onLEDBrightnessCommit={onLEDBrightnessCommit}
                    onShadeUp={onShadeUp}
                    onShadeDown={onShadeDown}
                    onShadeStop={onShadeStop}
                    onShade33={onShade33}
                    onShade66={onShade66}
                    channelStates={channelStates}
                    isGroup={true}
                    groupData={data}
                    canControl={canControl}
                  />
                </div>
              ) : (
                <div className="flex items-center justify-center gap-8 w-full h-full">
                  {pages[currentPage]?.map((channel, idx) => (
                    <ChannelItem
                      key={channel.id || idx}
                      channel={channel}
                      onLEDToggle={onLEDToggle}
                      onLEDBrightnessChange={onLEDBrightnessChange}
                      onLEDBrightnessCommit={onLEDBrightnessCommit}
                      onShadeUp={onShadeUp}
                      onShadeDown={onShadeDown}
                      onShadeStop={onShadeStop}
                      onShade33={onShade33}
                      onShade66={onShade66}
                      channelStates={channelStates}
                      isGroup={false}
                      groupData={null}
                      canControl={canControl}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Navigation dots */}
            {totalPages > 1 && (
              <div className="flex items-center gap-2 mt-4">
                {pages.map((_, pageIndex) => (
                  <button
                    key={pageIndex}
                    onClick={() => setCurrentPage(pageIndex)}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      currentPage === pageIndex
                        ? "bg-[#4A90E2]"
                        : "bg-[#CCCCCC]"
                    }`}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default GroupTemplateCard;
