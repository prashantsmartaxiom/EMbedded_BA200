import {
  BuildingSvg,
  CopySvg,
  FloorSvg,
  ImagePlaceholderSvg,
  ZoneSvg,
} from "../../assets/svg";
import { CampusUpdateStatusDropdown } from "../../components/Cards/CampusCard";
import useUserStore from "../../store/useUserStore";
import { formatDatev1, padStart } from "../../utils/helpers";

function ViewCampusDetailContent({ campus }) {
  const userPermissions = useUserStore((state) => state.permissions);
  
  return (
    <div>
      <div className="flex items-center gap-5">
        {campus?.imageUrl ? (
          <div className="w-[138px] h-[138px] flex items-center justify-center bg-[#EEEEEE] rounded-[9px] flex-shrink-0 overflow-hidden">
            <img
              alt={campus?.name}
              src={campus?.imageUrl}
              className="w-full h-full object-cover"
            />
          </div>
        ) : (
          <div className="w-[138px] h-[138px] flex items-center justify-center bg-[#EEEEEE] rounded-[9px] flex-shrink-0">
            <ImagePlaceholderSvg />
          </div>
        )}
        <div className="flex-grow">
          <div className="flex items-center justify-between">
            <h2 className="text-[#222222] font-semibold">{campus?.name}</h2>
            <div className="flex items-center gap-5">
              <button
                type="button"
                className="text-[#7A838E] flex items-center gap-[10px] text-[12px]"
              >
                ID: {campus?.accessId} <CopySvg />
              </button>
              {userPermissions?.CAMPUS_MANAGEMENT?.campus_management
                ?.addModify ? (
                <CampusUpdateStatusDropdown campus={campus} />
              ) : null}
            </div>
          </div>

          <div className="mt-1 mb-4">
            <div className="flex items-center mb-1">
              <h2 className="text-[#7A838E] text-[12px] w-[80px]">Location:</h2>
              <p className="text-[#222222] text-[12px]">{campus?.location}</p>
            </div>
            <div className="flex items-center">
              <h2 className="text-[#7A838E] text-[12px] w-[80px]">
                Description:
              </h2>
              <p className="text-[#222222] text-[12px]">
                {campus?.description ? campus.description : "-"}
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-5">
              <div className="text-[10px] bg-[#EEEEEE] p-[6px] w-fit min-w-[85px] text-center text-[#222222] rounded-md">
                {campus?.type}
              </div>
              <div className="flex items-center gap-[15px]">
                <button
                  type="button"
                  className="flex items-center gap-[5px] text-[#222222] text-xs"
                >
                  <BuildingSvg /> {padStart(campus?.buildingCount)}
                </button>
                <button
                  type="button"
                  className="flex items-center gap-[5px] text-[#222222] text-xs"
                >
                  <FloorSvg /> {padStart(campus?.floorCount)}
                </button>
                <button
                  type="button"
                  className="flex items-center gap-[5px] text-[#222222] text-xs"
                >
                  <ZoneSvg /> {padStart(campus?.zoneCount)}
                </button>
              </div>
            </div>

            <button
              type="button"
              className="text-[#7A838E] flex items-center gap-[10px] text-[12px]"
            >
              Added on: {formatDatev1(campus?.createdAt)}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ViewCampusDetailContent;
