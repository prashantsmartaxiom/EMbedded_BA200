import { WarningSvg } from "../../assets/svg";
import { SecondaryBtn } from "../../components";
import { CenterModal } from "../../components/Models";
import { useDeleteCampus } from "../../api/queryHooks";
import toaster from "../../utils/toaster";

function DeleteCampusPopup({ toggleModal, campusId }) {
  const { mutate: deleteCampus, isLoading } = useDeleteCampus({
    onSuccess: () => {
      toaster.success("Campus deleted successfully");
      toggleModal();
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || "Failed to delete campus");
    },
  });

  const handleDelete = () => {
    deleteCampus(campusId);
  };

  return (
    <CenterModal
      toggleModal={toggleModal}
      className="max-w-[460px] w-full p-8 flex flex-col items-center gap-6"
    >
      <div>
        <WarningSvg className="text-[54px] text-[#FF1212]" />
      </div>
      <div className="text-center">
        <h3 className="text-base font-semibold">Are you sure?</h3>
        <p className="text-sm text-[#939CA7] mt-3">
          Do you really want to delete the campus?
          <br />
          This process cannot be undone.
        </p>
      </div>

      <div className="flex items-center gap-[10px]">
        <SecondaryBtn
          onClick={toggleModal}
          disabled={isLoading}
          className={
            "justify-center !bg-[#AAAAAA] !border-none !text-white min-w-20"
          }
        >
          CANCEL
        </SecondaryBtn>
        <SecondaryBtn
          onClick={handleDelete}
          disabled={isLoading}
          className={
            "justify-center !bg-[#FF1212] !border-none !text-white min-w-20"
          }
        >
          {isLoading ? "DELETING..." : "DELETE"}
        </SecondaryBtn>
      </div>
    </CenterModal>
  );
}

export default DeleteCampusPopup;
