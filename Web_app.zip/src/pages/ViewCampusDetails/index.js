import { useParams } from "react-router-dom";
import { useGetCampusById } from "../../api/queryHooks";
import BuildingAccordian from "./BuildingAccordian";
import Header from "./Header";
import ViewCampusDetailContent from "./ViewCampusDetailContent";
import {
  AddMoreButton,
  BottomRightModal,
  BottomRightModalHeader,
  PermissionDenied,
  SpinnerV1,
} from "../../components";
import NewBuildingFromCampusForm from "./NewBuildingFromCampusForm";
import { useState } from "react";
import useUserStore from "../../store/useUserStore";

function AddNewBuildingButton({ campus }) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = (value) => {
    setIsOpen(value);
  };

  return (
    <>
      <AddMoreButton onClick={() => toggleModal(true)}>
        MORE BUILDINGS
      </AddMoreButton>
      {isOpen ? (
        <BottomRightModal
          toggleModal={toggleModal}
          className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
        >
          <BottomRightModalHeader
            toggleModal={toggleModal}
            title="Add New Building"
          />
          <NewBuildingFromCampusForm
            toggleModal={toggleModal}
            defaultValues={{
              campusId: campus?._id,
              campusName: campus?.name,
            }}
          />
        </BottomRightModal>
      ) : null}
    </>
  );
}

function ViewCampusDetails() {
  const userPermissions = useUserStore((state) => state.permissions);

  const { id } = useParams();
  const { data, isLoading, error } = useGetCampusById(id);
  const campus = data?.data?.campus;

  if (!userPermissions?.CAMPUS_MANAGEMENT?.campus_management?.readOnly)
    return <PermissionDenied />;

  if (isLoading)
    return (
      <div className="p-5 mt-5">
        <SpinnerV1 />
      </div>
    );
  if (error)
    return <div className="p-5 mt-5 text-center">Campus not found</div>;
  if (!campus)
    return <div className="p-5 mt-5 text-center">Something went wrong</div>;

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header campus={campus} />
        <ViewCampusDetailContent campus={campus} />
      </div>
      {userPermissions?.CAMPUS_MANAGEMENT?.building_management?.readOnly ? (
        <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mt-[15px] flex flex-col gap-5">
          {campus?.buildings?.map((building) => (
            <BuildingAccordian
              key={building.id}
              building={building}
              campus={campus}
            />
          ))}
          {campus?._id ? (
            <div className="flex justify-center">
              {userPermissions?.CAMPUS_MANAGEMENT?.building_management
                ?.addModify ? (
                <AddNewBuildingButton campus={campus} />
              ) : null}
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

export default ViewCampusDetails;
