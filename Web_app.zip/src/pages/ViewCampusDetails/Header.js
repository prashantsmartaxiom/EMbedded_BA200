import { Link } from "react-router-dom";
import { BackspaceSvg, DeleteSvg, EditSvg } from "../../assets/svg";
import { SecondaryBtn, SecondaryBtnLink } from "../../components";
import { ROUTES } from "../../router";
import DeleteCampusPopup from "./DeleteCampusPopup";
import { useState } from "react";
import useUserStore from "../../store/useUserStore";

const DeleteCampus = ({ campus }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <SecondaryBtn
        className={
          "justify-center fill-[#227EEB] !text-[#FF1212] !border-[#FF1212]"
        }
        onClick={toggleModal}
        iconClassName="fill-[#FF1212]"
        Icon={DeleteSvg}
      >
        DELETE
      </SecondaryBtn>
      {open ? (
        <DeleteCampusPopup toggleModal={toggleModal} campusId={campus._id} />
      ) : null}
    </>
  );
};

function Header({ campus }) {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
      <Link
        to={ROUTES.CAMPUS_MANAGEMENT}
        className="flex items-center gap-[10px]"
      >
        <BackspaceSvg />
        <h2 className="text-[#222222] font-bold">View Campus Details</h2>
      </Link>
      <div className="flex items-center gap-[15px]">
        {userPermissions?.CAMPUS_MANAGEMENT?.campus_management?.addModify ? (
          <SecondaryBtnLink
            to={ROUTES.GET_EDIT_CAMPUS(campus?._id)}
            className={"w-[80px] justify-center fill-[#227EEB]"}
            Icon={EditSvg}
          >
            EDIT
          </SecondaryBtnLink>
        ) : null}
        {userPermissions?.CAMPUS_MANAGEMENT?.campus_management?.delete ? (
          <DeleteCampus campus={campus} />
        ) : null}
      </div>
    </div>
  );
}

export default Header;
