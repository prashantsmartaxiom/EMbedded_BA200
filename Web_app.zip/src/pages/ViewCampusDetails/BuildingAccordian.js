import { useState } from "react";
import {
  MdArrowDownSvg,
  BuildingSvg,
  DeleteSvg,
  EditSvg,
  AddSvg,
  FloorSvg,
} from "../../assets/svg";
import DeleteBuildingPopup from "../ViewBuildingDetails/DeleteBuildingPopup";
import EditBuildingModal from "../BuildingManagement/EditBuildingModal";
import { BottomRightModal, BottomRightModalHeader } from "../../components";
import NewFloorFromCampusForm from "./NewFloorFromCampusForm";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../api/queryKeys";
import DeleteFloorPopup from "../ViewFloorDetails/DeleteFloorPopup";
import EditFloorFromCampusForm from "./EditFloorFromCampusForm";
import useUserStore from "../../store/useUserStore";

function DeleteFloorButton({ floorId, campus }) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  const onSuccess = () => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.CAMPUS, campus?.id],
    });
  };

  return (
    <>
      <button
        className="flex items-center justify-center rounded bg-[#FF1212] w-7 h-7"
        onClick={toggleModal}
        title="Delete"
      >
        <DeleteSvg className="fill-[#ffffff]" />
      </button>

      {open && (
        <DeleteFloorPopup
          navigateToRoute=""
          toggleModal={toggleModal}
          floorId={floorId}
          onSuccess={onSuccess}
        />
      )}
    </>
  );
}

function EditFloorButton({ floorId, campus }) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  const onSuccess = () => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.CAMPUS, campus?.id],
    });
  };

  return (
    <>
      <button
        title="Edit"
        className="flex items-center justify-center rounded bg-[#227EEB] w-7 h-7"
        onClick={toggleModal}
      >
        <EditSvg className="fill-[#ffffff]" />
      </button>
      {open && (
        <BottomRightModal
          toggleModal={toggleModal}
          className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
        >
          <BottomRightModalHeader
            toggleModal={toggleModal}
            title="Edit Floor"
          />
          <EditFloorFromCampusForm
            floorId={floorId}
            toggleModal={toggleModal}
            onSuccess={onSuccess}
          />
        </BottomRightModal>
      )}
    </>
  );
}

const FloorCardForAccordian = ({ floor, campus }) => {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="cursor-pointer bg-[#E9F3FC] border border-[#BED9F9] rounded-lg flex items-center justify-between px-3 py-3 group hover:shadow-md transition-all duration-200 relative">
      <div className="flex items-center gap-2">
        <FloorSvg className="fill-[#227EEB] text-[#227EEB]" />
        <span className="text-[#222222] text-[14px] font-medium">
          {floor.name}
        </span>
      </div>

      <span className="text-[#7A838E] text-[12px] group-hover:opacity-0 transition-opacity duration-200">
        Zone: {floor?.zoneCount ? floor?.zoneCount : 0}
      </span>

      <div className="absolute right-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        {userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.addModify ? (
          <EditFloorButton floorId={floor.id} campus={campus} />
        ) : null}

        {userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.delete ? (
          <DeleteFloorButton floorId={floor.id} campus={campus} />
        ) : null}
      </div>
    </div>
  );
};

const DeleteBuilding = ({ building, campus }) => {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  const onSuccess = () => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.CAMPUS, campus?.id],
    });
  };

  return (
    <>
      <button
        type="button"
        className="text-[#FF1212] text-[12px] flex items-center gap-[5px]"
        onClick={toggleModal}
      >
        <DeleteSvg className="fill-[#ff1212]" /> Delete
      </button>
      {open ? (
        <DeleteBuildingPopup
          toggleModal={toggleModal}
          buildingId={building._id}
          navigateOnDelete=""
          onSuccess={onSuccess}
        />
      ) : null}
    </>
  );
};

const EditBuilding = ({ building, campus }) => {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  const onSuccess = () => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.CAMPUS, campus?.id],
    });
  };

  return (
    <>
      <button
        type="button"
        className="text-[#222222] text-[12px] flex items-center gap-[5px]"
        onClick={toggleModal}
      >
        <EditSvg /> Edit
      </button>
      {open ? (
        <EditBuildingModal
          toggleModal={toggleModal}
          buildingId={building._id}
          onSuccess={onSuccess}
        />
      ) : null}
    </>
  );
};

function AddNewFloor({ building, campus }) {
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = (value) => {
    setIsOpen(value);
  };

  const onSuccess = () => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.CAMPUS, campus?.id],
    });
  };

  return (
    <>
      <button
        type="button"
        className="text-[#222222] text-[12px] flex items-center gap-[5px]"
        onClick={() => toggleModal(true)}
      >
        <AddSvg className="text-[#222222] text-[12px]" /> New Floor
      </button>
      {isOpen ? (
        <BottomRightModal
          toggleModal={toggleModal}
          className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
        >
          <BottomRightModalHeader
            toggleModal={toggleModal}
            title="Add New Floor"
          />
          <NewFloorFromCampusForm
            toggleModal={toggleModal}
            defaultValues={{
              campusId: building?.campusId,
              campusName: campus?.name,
              buildingId: building?._id,
              buildingName: building?.name,
              name: "",
              floorLevel: "1",
              floorImage: "base64image",
            }}
            onSuccess={onSuccess}
          />
        </BottomRightModal>
      ) : null}
    </>
  );
}

const BuildingAccordion = ({ building, campus }) => {
  const userPermissions = useUserStore((state) => state.permissions);

  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="border rounded-[10px] overflow-hidden">
      <div
        className="flex items-center justify-between bg-[#F2F4F8] px-4 h-[46px] cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="flex items-center gap-2">
          <MdArrowDownSvg className={`${isOpen ? "rotate-180" : ""}`} />
          <BuildingSvg className="fill-[#227EEB]" />
          <span className="text-[#222222] text-[14px] font-semibold">
            {building?.name}
          </span>
          {/* <span className="text-[#7A838E] text-[11px]">- {}</span> */}
        </div>

        <div
          className="flex items-center gap-4"
          onClick={(e) => e.stopPropagation()}
        >
          {userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.addModify ? (
            <AddNewFloor building={building} campus={campus} />
          ) : null}
          {userPermissions?.CAMPUS_MANAGEMENT?.building_management
            ?.addModify ? (
            <EditBuilding building={building} campus={campus} />
          ) : null}
          {userPermissions?.CAMPUS_MANAGEMENT?.building_management?.delete ? (
            <DeleteBuilding building={building} campus={campus} />
          ) : null}
        </div>
      </div>
      {isOpen && (
        <div className="grid grid-cols-4 gap-3 p-3">
          {building?.floors.length === 0 ? (
            <div className="text-xs text-[#222222] text-center p-5 w-full">
              No floors available
            </div>
          ) : (
            building?.floors
              ?.map((floor, index) => ({
                id: floor?._id,
                ...floor,
              }))
              .map((floor) => (
                <FloorCardForAccordian
                  key={floor.id}
                  floor={floor}
                  campus={campus}
                />
              ))
          )}
        </div>
      )}
    </div>
  );
};

export default BuildingAccordion;
