import { useParams } from "react-router-dom";
import { useGetUserInfo } from "../../api/queryHooks";
import UserPasswordChangeForm from "./UserPasswordChangeForm";
import UserProfileView from "./UserProfileView";
import { PermissionDenied, SpinnerV1 } from "../../components";
import useUserStore from "../../store/useUserStore";

function UserProfile() {
  const userPermissions = useUserStore((state) => state.permissions);

  const currentUser = useUserStore((state) => state.user);
  const { userId } = useParams();
  const { data: userData, isLoading, error } = useGetUserInfo(userId);

  const user = userData?.data?.user;

  if (!userPermissions?.USER_MANAGEMENT?.user_accounts?.readOnly && !userId === currentUser?._id)
    return <PermissionDenied />;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <SpinnerV1 />
      </div>
    );
  }

  if (error || !user?._id) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-red-500">Failed to load user information</div>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <UserProfileView user={user} />
      </div>
      {user._id === currentUser.id 
      // &&
      // userPermissions?.USER_MANAGEMENT?.user_accounts?.addModify 
      ? (
        <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mt-5">
          <UserPasswordChangeForm user={user} />
        </div>
      ) : null}
    </div>
  );
}

export default UserProfile;
