import { EditSvg, UserSvg } from "../../assets/svg";
import { PrimaryInput, SecondaryBtnLink } from "../../components";
import { UNUSED_API_VARIABLES } from "../../consts";
import { ROUTES } from "../../router";

function UserProfileView({ user }) {
  return (
    <div>
      <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
        <h2 className="text-[#222222] font-bold">View Profile</h2>
        <div>
          <SecondaryBtnLink
            className={"w-[80px] justify-center fill-[#227EEB]"}
            Icon={EditSvg}
            to={ROUTES.GET_EDIT_PROFILE(user?._id)}
          >
            EDIT
          </SecondaryBtnLink>
        </div>
      </div>
      <div className="mt-5 flex items-start gap-[50px]">
        <div>
          <div className="flex items-center">
            <div className="w-[120px]">
              <h3 className="text-[#222222] font-medium text-xs">
                Organisation:
              </h3>
            </div>
            <div className="w-[380px]">
              <PrimaryInput
                type="text"
                value={
                  user.organization ||
                  UNUSED_API_VARIABLES.ORGANIZATION ||
                  "N/A"
                }
                className="w-full"
                disabled
              />
            </div>
          </div>

          <div className="flex items-center mt-5">
            <div className="w-[120px]">
              <h3 className="text-[#939CA7] font-medium text-xs">Full Name:</h3>
            </div>
            <div className="w-[380px]">
              <p className="text-[#222222] font-medium text-xs">
                {user?.fullName || "N/A"}
              </p>
            </div>
          </div>

          <div className="flex items-center mt-5">
            <div className="w-[120px]">
              <h3 className="text-[#939CA7] font-medium text-xs">Email:</h3>
            </div>
            <div className="w-[380px]">
              <p className="text-[#222222] font-medium text-xs">
                {user?.email || "N/A"}
              </p>
            </div>
          </div>

          <div className="flex items-center mt-5">
            <div className="w-[120px]">
              <h3 className="text-[#939CA7] font-medium text-xs">
                Mobile Number:
              </h3>
            </div>
            <div className="w-[380px]">
              <p className="text-[#222222] font-medium text-xs">
                {user?.contactNumber || "N/A"}
              </p>
            </div>
          </div>
        </div>
        <div>
          <h3 className="text-[#222222] font-medium text-xs">
            Profile Picture
          </h3>
          {user?.ImageURL ? (
            <div className="w-[138px] h-[138px] border rounded-xl mt-3 flex items-center justify-center overflow-hidden">
              <img
                src={user.ImageURL}
                alt="Profile"
                className="w-full h-full object-cover"
              />
            </div>
          ) : (
            <div className="w-[138px] h-[138px] border rounded-xl mt-3 flex items-center justify-center">
              <UserSvg className="w-10 h-10 object-cover fill-[#aaa]" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default UserProfileView;
