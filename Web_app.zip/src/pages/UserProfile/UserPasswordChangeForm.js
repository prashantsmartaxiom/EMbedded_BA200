import { useFormik } from "formik";
import * as Yup from "yup";
import { PasswordInput, PrimaryBtn2 } from "../../components";
import { useChangeUserPassword } from "../../api/queryHooks";
import toaster from "../../utils/toaster";

const passwordValidationSchema = Yup.object().shape({
  currentPassword: Yup.string().required("Current password is required"),
  newPassword: Yup.string()
    .min(8, "Password must be at least 8 characters")
    .matches(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
      "Password should be at least 8 characters, combination of lowercase (a-z) & uppercase (A-Z) with one number (0-9) or symbol"
    )
    .required("New password is required"),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref("newPassword"), null], "Passwords must match")
    .required("Confirm password is required"),
});

function UserPasswordChangeForm({ user }) {
  const userId = user._id;

  const changePasswordMutation = useChangeUserPassword({
    onSuccess: (data) => {
      toaster.success("Password changed successfully!");
      formik.resetForm();
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || `Error changing password: ${error.message}`);
      console.error("Error changing password:", error);
    },
  });

  const formik = useFormik({
    initialValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
    validationSchema: passwordValidationSchema,
    onSubmit: async (values) => {
      const payload = {
        currentPassword: values.currentPassword,
        newPassword: values.newPassword,
        confirmPassword: values.confirmPassword,
      };

      changePasswordMutation.mutate({ userId, passwordData: payload });
    },
  });

  return (
    <form onSubmit={formik.handleSubmit}>
      <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
        <h2 className="text-[#222222] font-bold">Change Password</h2>
        <div>
          <PrimaryBtn2
            className={"w-[80px] justify-center"}
            type="submit"
            disabled={formik.isSubmitting || changePasswordMutation.isLoading}
          >
            {
              formik.isSubmitting || changePasswordMutation.isLoading ?
              "UPDATING..." : "UPDATE"
            }
          </PrimaryBtn2>
        </div>
      </div>

      <div className="mt-5 flex items-start gap-[50px]">
        <div>
          <div className="flex items-center">
            <div className="w-[120px]">
              <h3 className="text-[#222222] font-medium text-xs">
                Current Password:
              </h3>
            </div>
            <div className="w-[380px]">
              <PasswordInput
                name="currentPassword"
                value={formik.values.currentPassword}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                className="w-full"
                placeholder="Enter current password"
                autoComplete="off"
              />
            </div>
          </div>
          {formik.touched.currentPassword && formik.errors.currentPassword && (
            <div className="text-red-500 text-xs mt-1 ml-[120px]">
              {formik.errors.currentPassword}
            </div>
          )}

          <div className="flex items-center mt-5">
            <div className="w-[120px]">
              <h3 className="text-[#222222] font-medium text-xs">
                Create Password:
              </h3>
            </div>
            <div className="w-[380px]">
              <PasswordInput
                name="newPassword"
                value={formik.values.newPassword}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                className="w-full"
                placeholder="Enter new password"
                autoComplete="off"
              />
            </div>
            <div className="w-[318px] ml-5">
              <p className="text-[#888888] text-[10px]">
                Password should be at least 8 characters, combination of
                lowercase (a-z) & uppercase (A-Z) with one number (0-9) or
                symbol
              </p>
            </div>
          </div>
          {formik.touched.newPassword && formik.errors.newPassword && (
            <div className="text-red-500 text-xs mt-1 ml-[120px]">
              {formik.errors.newPassword}
            </div>
          )}

          <div className="flex items-center mt-5">
            <div className="w-[120px]">
              <h3 className="text-[#222222] font-medium text-xs">
                Confirm Password:
              </h3>
            </div>
            <div className="w-[380px]">
              <PasswordInput
                name="confirmPassword"
                value={formik.values.confirmPassword}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                className="w-full"
                placeholder="Confirm password"
                autoComplete="off"
                // defaultEyeOpen={true}
              />
            </div>
          </div>
          {formik.touched.confirmPassword && formik.errors.confirmPassword && (
            <div className="text-red-500 text-xs mt-1 ml-[120px]">
              {formik.errors.confirmPassword}
            </div>
          )}
        </div>
      </div>
    </form>
  );
}

export default UserPasswordChangeForm;
