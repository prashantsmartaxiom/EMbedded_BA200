import { useLocation, Navigate } from "react-router-dom";
import { VerifyAccountForm } from "../../forms";
import LogoXL from "../../assets/images/LogoXL.png";
import { ROUTES } from "../../router";

function VerifyAccount() {
  const location = useLocation();
  const email = location.state?.email;

  // Redirect to forgot password if no email is provided
  if (!email) {
    return <Navigate to={ROUTES.FORGOT_PASSWORD} replace />;
  }
  return (
    <div className="w-full h-full flex justify-center items-center flex-col">
      <img src={LogoXL} alt="Logo" className="h-[52px] w-[195px]" />
      <div className="mt-20 mb-[30px]">
        <h2 className="text-[#222222] font-bold text-2xl text-center">
          Verify Account
        </h2>
      </div>
      <div className="w-full max-w-[400px]">
        <VerifyAccountForm email={email} />
      </div>
    </div>
  );
}

export default VerifyAccount;
