import { useFormik } from "formik";
import * as Yup from "yup";
import { useGetZoneById, useUpdateZone } from "../../api/queryHooks";
import {
  BottomRightModal,
  BottomRightModalHeader,
  PrimaryBtn2,
  PrimaryInput,
  PrimaryTextarea,
  SpinnerV1,
} from "../../components";
import { useEffect } from "react";
import toaster from "../../utils/toaster";

const validationSchema = Yup.object({
  zoneName: Yup.string().required("Zone name is required"),
  zoneDescription: Yup.string().optional(),
});

function EditZoneForm({ zoneId, toggleModal, onSuccess }) {
  const { data, isLoading: isLoadingZone, isError } = useGetZoneById(zoneId);
  const zoneData = data?.data?.zone;

  const { mutate: updateZone, isLoading } = useUpdateZone({
    onSuccess: () => {
      toggleModal(false);
      onSuccess?.();
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || "Failed to edit zone");
      console.error("Error updating zone:", error);
    },
  });

  const formik = useFormik({
    initialValues: {
      zoneName: "",
      zoneDescription: "",
      status: "active",
    },
    validationSchema,
    onSubmit: (values) => {
      updateZone({
        zoneId,
        zoneData: values,
      });
    },
  });

  // Update form values when zone data is loaded
  useEffect(() => {
    if (zoneData) {
      const zone = zoneData;
      formik.setValues({
        zoneName: zone.zoneName || "",
        zoneDescription: zone.zoneDescription || "",
        status: zone.status || "active",
      });
    }
  }, [zoneData]);

  if (isLoadingZone) {
    return (
      <div className="p-5">
        <SpinnerV1 />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex-grow flex items-center justify-center">
        <div className="text-red-500">Error loading zone data</div>
      </div>
    );
  }

  return (
    <form
      onSubmit={formik.handleSubmit}
      className="flex-grow flex flex-col justify-between"
    >
      <div>
        <div className="flex items-center justify-between px-5 pb-5 mb-5">
          <label htmlFor="zoneName" className="text-[#222222] text-[12px]">
            Zone Name
          </label>
          <div>
            <PrimaryInput
              id="zoneName"
              name="zoneName"
              className="w-[300px]"
              placeholder="Enter zone name"
              value={formik.values.zoneName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.touched.zoneName && formik.errors.zoneName && (
              <p className="text-red-500 text-xs mt-1">
                {formik.errors.zoneName}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-start justify-between px-5">
          <label
            htmlFor="zoneDescription"
            className="text-[#222222] text-[12px] mt-2"
          >
            Zone Description
            <p className="text-[#939CA7] text-[10px]">(Optional)</p>
          </label>
          <div className="w-[300px]">
            <PrimaryTextarea
              id="zoneDescription"
              name="zoneDescription"
              className="w-full h-[82px] resize-none"
              placeholder="Enter zone description"
              value={formik.values.zoneDescription}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
          </div>
        </div>
      </div>

      <div className="p-5 flex justify-end border-t border-[#DDDDDD]">
        <PrimaryBtn2
          type="submit"
          className="min-w-20 justify-center"
          disabled={isLoading || !formik.isValid}
        >
          {isLoading ? "Updating..." : "UPDATE"}
        </PrimaryBtn2>
      </div>
    </form>
  );
}

function EditZoneModal({ zoneId, toggleModal, onSuccess }) {
  return (
    <BottomRightModal
      toggleModal={toggleModal}
      className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
    >
      <BottomRightModalHeader toggleModal={toggleModal} title="Edit Zone" />
      <EditZoneForm
        zoneId={zoneId}
        toggleModal={toggleModal}
        onSuccess={onSuccess}
      />
    </BottomRightModal>
  );
}

export default EditZoneModal;
