import { useState } from "react";
import ZoneListing from "./ZoneListing";
import Header from "./Header";
import { useDebouncedCallback } from "use-debounce";
import useUserStore from "../../store/useUserStore";
import { PermissionDenied } from "../../components";

function ZoneManagement() {
  const userPermissions = useUserStore((state) => state.permissions);

  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedCallback((value) => {
    setSearch(value);
  }, 500);

  if (!userPermissions?.CAMPUS_MANAGEMENT?.zone_management?.readOnly)
    return <PermissionDenied />;

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header onSearchChange={debouncedSearch} />
        <ZoneListing search={search} />
      </div>
    </div>
  );
}

export default ZoneManagement;
