import { useState, useMemo, useCallback } from "react";
import {
  formatDatev1,
  formatTimev2,
  getGaugeColor,
  padStart,
  parseJSON,
  showToasterFromSocketAlerts,
} from "../../utils/helpers";
import { IoMdArrowDropup } from "react-icons/io";
import { Link } from "react-router-dom";
import { RiEditFill } from "react-icons/ri";
import {
  useGetDashboardSummary,
  useGetDashboardZoneStats,
  useGetDeviceByIdInControlSystem,
  useGetDashboardDeviceInfo,
  useGetDashboardAlerts,
  useTriggerEvent,
  useGetFirstWeatherLocation,
  useGetDashboardDeviceGetGroups,
} from "../../api/queryHooks";
import { DeviceStatusChanged, SpinnerV1 } from "../../components";
import {
  LEDCard,
  ShadeCard,
  SensorCard,
} from "../ControlSystem/Views/DeviceView";
import { SceneCard } from "../ControlSystem/ScenesListing";
import useLocationSelectedStore from "../../store/useLocationSelectedStore";
import useUserStore from "../../store/useUserStore";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../api/queryKeys";
import { ROUTES } from "../../router";
import toaster from "../../utils/toaster";
import WeatherCard, { AQIGauge } from "./WeatherCard";
import { LogsStatusChanged } from "../../components/SocketComponents/LogsStatusChanged";
import {
  BackspaceSvg,
  BrightnessShalfSvg,
  IndoorHumiditySvg,
  IndoorTemperatureSvg,
} from "../../assets/svg";
import GroupView from "../ControlSystem/Views/GroupView";
import GaugeMeter from "../../components/RangeSlider/GaugeMeter";

const FirstWeatherCard = () => {
  const { data } = useGetFirstWeatherLocation();

  return (
    <>
      <WeatherCard
        location={data?.data}
        placeName={data?.data?.placeName || "--"}
      />
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] px-[10px] py-[15px]">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-[#222222] text-sm font-semibold text-nowrap">
            AQI: Air Quality Index
          </h2>
        </div>
        <div className="flex items-center justify-center mt-[30px]">
          <div className="w-[100px] 1540:w-[124px]">
            <AQIGauge value={data?.data?.currentHourData?.us_aqi || 0} />
          </div>
        </div>
      </div>
    </>
  );
};

const SensorReadingCard = ({
  labelvalue = "",
  label = "",
  subLabel = "",
  gaugeValue = 0,
  unit = "",
  className = "",
  labelClassName = "",
  subClassName = "",
  unitClassName = "",
  labelContainerClassName = "",
  RightComponent = () => null,
  items = [],
}) => {
  const dotColor = getGaugeColor(gaugeValue, items);
  return (
    <div
      className={`px-[15px] ${className} border-r border-[#CCCCCC] last:border-none`}
    >
      <div
        className={`flex items-center justify-between mb-[10px] ${labelContainerClassName}`}
      >
        <div className="flex items-center gap-1">
          <div
            className={"w-[8px] h-[8px] rounded-full"}
            style={{
              backgroundColor: dotColor,
            }}
          ></div>
          <h2 className="text-[#222222] text-2xl font-semibold">
            {labelvalue}
            <span className={unitClassName}>{unit}</span>
          </h2>
        </div>

        <div>
          <RightComponent />
        </div>
      </div>

      <p
        className={`text-[11px] font-semibold text-[#AAAAAA] ${labelClassName}`}
      >
        {label}
      </p>
      <p className={`text-[11px] text-[#222222] mt-[3px] mb-2 ${subClassName}`}>
        {subLabel}
      </p>

      <div>
        <GaugeMeter value={gaugeValue} unit={unit} items={items} />
      </div>
    </div>
  );
};

const SensorReadings = () => {
  const { data: weatherData } = useGetFirstWeatherLocation();

  const sensorCards = [
    {
      className: "flex-1 min-w-[135px]",
      labelvalue: "21",
      label: "Temperature",
      subLabel: "Indoor",
      gaugeValue: 50,
      unit: "°c",
      RightComponent: () => (
        <IndoorTemperatureSvg className="w-[24px] h-[24px] fill-[#c9cdd1]" />
      ),
      items: [
        { label: "Low", color: "#78B4F2", length: 33 },
        { label: "Medium", color: "#56DB33", length: 33 },
        { label: "High", color: "#FA7E02", length: 34 },
      ],
    },
    {
      className: "flex-1 min-w-[180px]",
      labelvalue: "33",
      gaugeValue: 20,
      unit: "%",
      label: "Humidity",
      subLabel: "Comformtable",
      RightComponent: () => <IndoorHumiditySvg className="w-[24px] h-[24px] fill-[#c9cdd1]" />,
      items: [
        { label: "1", color: "#EBB1CA", length: 20 },
        { label: "2", color: "#DB92B1", length: 20 },
        { label: "3", color: "#78B4F2", length: 20 },
        { label: "4", color: "#5FA0F0", length: 20 },
        { label: "5", color: "#3A85E3", length: 20 },
      ],
    },
    {
      className: "flex-1 min-w-[180px]",
      labelvalue: "92",
      unit: "µg/m³",
      label: "",
      gaugeValue: 50,
      subLabel: "Unhealthy Everyone may feel effects",
      subClassName: "mb-[6px] line-clamp-2 min-h-[35px]",
      unitClassName: "text-[#7A838E] text-[10px] ml-1",
      RightComponent: () => (
        <h2 className="text-[#7A838E] font-bold text-[18px]">PM2.5</h2>
      ),
      items: [
        { label: "1", color: "#56DB33", length: 16 },
        { label: "2", color: "#F9C330", length: 16 },
        { label: "3", color: "#FA7E02", length: 16 },
        { label: "4", color: "#E5432E", length: 16 },
        { label: "5", color: "#99004C", length: 16 },
        { label: "6", color: "#7E0222", length: 20 },
      ],
    },
    {
      className: "flex-1 min-w-[180px]",
      labelvalue: "118",
      unit: "µg/m³",
      label: "",
      subLabel: "Unhealthy for sensitive groups may cause breathing",
      gaugeValue: 30,
      subClassName: "mb-[6px] line-clamp-2 min-h-[35px]",
      unitClassName: "text-[#7A838E] text-[10px] ml-1",
      RightComponent: () => (
        <h2 className="text-[#7A838E] font-bold text-[18px]">PM10</h2>
      ),
      items: [
        { label: "1", color: "#56DB33", length: 16 },
        { label: "2", color: "#F9C330", length: 16 },
        { label: "3", color: "#FA7E02", length: 16 },
        { label: "4", color: "#E5432E", length: 16 },
        { label: "5", color: "#99004C", length: 16 },
        { label: "6", color: "#7E0222", length: 20 },
      ],
    },
    {
      className: "flex-1 min-w-[180px]",
      labelvalue: "1002",
      gaugeValue: 30,
      unit: "ppm",
      label: "CO₂ Concentration",
      subLabel: "Poor ventilation",
      labelContainerClassName: "!mb-[5px]",
      unitClassName: "text-[#7A838E] text-[10px] ml-1",
      RightComponent: () => (
        <h2 className="text-[#7A838E] font-bold text-[18px]">
          CO<sup className="text-[10px]">2</sup>
        </h2>
      ),
      items: [
        { label: "1", color: "#56DB33", length: 16 },
        { label: "2", color: "#F9C330", length: 16 },
        { label: "3", color: "#FA7E02", length: 16 },
        { label: "4", color: "#E5432E", length: 16 },
        { label: "5", color: "#99004C", length: 16 },
        { label: "6", color: "#7E0222", length: 20 },
      ],
    },
    {
      className: "flex-1 min-w-[180px]",
      labelvalue: "129",
      gaugeValue: 40,
      unit: "Lx",
      label: "Light Intensity",
      subLabel: "Bright office lighting",
      labelContainerClassName: "!mb-[5px]",
      unitClassName: "text-[#7A838E] text-[10px] ml-1",
      RightComponent: () => (
        <BrightnessShalfSvg className="w-[24px] h-[24px] fill-[#c9cdd1]" />
      ),
      items: [
        { label: "1", color: "#A4ACB5", length: 20 },
        { label: "2", color: "#BDC9D6", length: 20 },
        { label: "3", color: "#FFD565", length: 20 },
        { label: "4", color: "#FFCB1A", length: 20 },
        { label: "5", color: "#FFBA00", length: 20 },
      ],
    },
  ];

  return (
    <div className="mt-4 shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-[15px] overflow-x-auto">
      <div className="flex">
        <div className="flex flex-col border-r border-[#CCCCCC] pr-[15px]">
          <h2 className="text-[#222222] text-sm font-semibold mb-[16px]">
            AQI: <span className="text-[#FA7E01]">Moderate</span>
          </h2>
          <div className="w-[100px] 1540:w-[124px]">
            <AQIGauge value={weatherData?.data?.currentHourData?.us_aqi || 0} />
          </div>
        </div>

        <div className="flex-grow">
          <h2 className="text-[#222222] text-sm font-semibold pl-[15px]">
            Sensor Readings
          </h2>
          <div className="flex mt-[12px]">
            {sensorCards.map((card, i) => (
              <SensorReadingCard key={i} {...card} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const SelectedCampusesDetails = ({ dashboardData, locationPayload }) => {
  const totals = useMemo(() => {
    if (!dashboardData?.campusCounts)
      return { buildings: 0, floors: 0, zones: 0 };

    return dashboardData.campusCounts.reduce(
      (acc, campus) => ({
        buildings: acc.buildings + campus.buildings,
        floors: acc.floors + campus.floors,
        zones: acc.zones + campus.zones,
      }),
      { buildings: 0, floors: 0, zones: 0 }
    );
  }, [dashboardData]);

  const campusDisplay = useMemo(() => {
    const campusNames =
      dashboardData?.campusCounts
        ?.map((campus) => campus.campusName)
        ?.filter((name) => name) || []; // Filter out null/undefined names

    if (campusNames.length === 0) {
      return { text: "All Campuses", showBadge: false, count: 0 };
    } else if (campusNames.length === 1) {
      return { text: campusNames[0], showBadge: false, count: 0 };
    } else {
      return {
        text: campusNames[0],
        showBadge: true,
        count: campusNames.length - 1,
      };
    }
  }, [dashboardData]);

  return (
    <div className="px-[15px] pt-[15px]">
      <div
        title={dashboardData?.campusCounts
          ?.map((campus) => campus.campusName)
          ?.filter((name) => name) // Filter out null/undefined names
          ?.join(", ")}
      >
        <h2 className="text-[#222222] font-semibold text-sm truncate">
          Campus:{" "}
          <span className="truncate text-[#227EEB]">{campusDisplay.text}</span>
          {campusDisplay.showBadge && (
            <span className="ml-2 inline-flex items-center px-2 rounded-full text-[10px] font-medium bg-[#227EEB] text-white">
              +{campusDisplay.count}
            </span>
          )}
        </h2>
      </div>
      <div className="grid grid-cols-3 py-3 border-b border-[#CCCCCC]">
        <div className="text-center py-1 border-r border-[#CCCCCC]">
          <h2 className="text-[#AAAAAA] text-xs font-semibold">Building</h2>
          <p className="text-sm font-semibold text-[#222222] pt-2">
            {padStart(totals.buildings)}
          </p>
        </div>
        <div className="text-center py-1 border-r border-[#CCCCCC]">
          <h2 className="text-[#AAAAAA] text-xs font-semibold">Floor</h2>
          <p className="text-sm font-semibold text-[#222222] pt-2">
            {padStart(totals.floors)}
          </p>
        </div>
        <div className="text-center py-1">
          <h2 className="text-[#AAAAAA] text-xs font-semibold">Zone</h2>
          <p className="text-sm font-semibold text-[#222222] pt-2">
            {padStart(totals.zones)}
          </p>
        </div>
      </div>
    </div>
  );
};

const Device = ({ device, isSelected, onClick, zone }) => {
  const isInactive = device.status === "Inactive";

  return (
    <div
      className={`p-[10px] rounded-[10px] border truncate ${
        isInactive
          ? "border-[#DDDDDD] bg-gray-50 opacity-60 cursor-not-allowed"
          : `cursor-pointer ${
              isSelected ? "border-[#227EEB]" : "border-[#DDDDDD]"
            }`
      }`}
      onClick={isInactive ? undefined : onClick}
    >
      <div className="flex justify-between truncate">
        <div className="truncate mr-2">
          <h2
            className={`text-sm font-semibold truncate ${
              isInactive
                ? "text-gray-400"
                : isSelected
                ? "text-[#227EEB]"
                : "text-[#222222]"
            }`}
          >
            {device.name}
          </h2>
          <p
            className={`text-xs truncate ${
              isInactive ? "text-gray-300" : "text-[#939CA7]"
            }`}
          >
            {/* {zone?.campusName && `${zone.campusName} • `}
            {zone?.name} */}
            {device?.id}
          </p>
        </div>
        {/* {isInactive && (
          <div className="flex items-center">
            <span className="text-xs text-red-400 font-medium">Inactive</span>
          </div>
        )} */}
        {isSelected ? (
          <div className="flex items-center flex-shrink-0">
            <BackspaceSvg className="rotate-180 fill-[#227EEB]" />
          </div>
        ) : null}
      </div>
    </div>
  );
};

const ZoneAccordian = ({
  zone,
  isSelected,
  onClick,
  selectedDevice,
  setSelectedDevice,
}) => {
  // Separate devices into active and inactive
  const activeDevices =
    zone.devices?.filter(
      (device) => !device.status || device.status === "Active"
    ) || [];
  const inactiveDevices =
    zone.devices?.filter((device) => device.status === "Inactive") || [];

  return (
    <div>
      <button
        onClick={onClick}
        className="flex items-center text-[#7A838E] text-sm font-semibold gap-[5px] w-full px-[10px]"
      >
        <span>
          <IoMdArrowDropup
            className={`text-lg ${isSelected ? "rotate-180" : ""}`}
          />
        </span>
        <span>{zone.name}</span>
        {/* {zone.campusName && (
          <span className="text-xs text-[#939CA7]">({zone.campusName})</span>
        )} */}
        <span className="border-b-2 border-[#cccccc] flex-grow"></span>
        <span className="text-xs text-[#939CA7]">
          {padStart(zone.devices?.length) || "00"}
        </span>
      </button>
      {isSelected ? (
        <div className="px-[14px] pt-2">
          {zone.devices?.length === 0 ? (
            <div className="text-xs text-center text-[#7A838E] py-4">
              No devices in this zone
            </div>
          ) : (
            <div className="space-y-4">
              {/* Active Devices Section */}
              {activeDevices.length > 0 && (
                <div>
                  <h4 className="text-xs font-semibold text-[#1EC34A] mb-2 flex items-center gap-1">
                    <span className="w-2 h-2 bg-[#1EC34A] rounded-full"></span>
                    Online Devices ({activeDevices.length})
                  </h4>
                  <div className="grid grid-cols-2 gap-2">
                    {activeDevices.map((device) => (
                      <Device
                        key={device.id}
                        device={device}
                        zone={zone}
                        onClick={() => setSelectedDevice(device)}
                        isSelected={device?.id === selectedDevice?.id}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Inactive Devices Section */}
              {inactiveDevices.length > 0 && (
                <div>
                  <h4 className="text-xs font-semibold text-red-500 mb-2 flex items-center gap-1">
                    <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                    Offline Devices ({inactiveDevices.length})
                  </h4>
                  <div className="grid grid-cols-2 gap-2">
                    {inactiveDevices.map((device) => (
                      <Device
                        key={device.id}
                        device={device}
                        zone={zone}
                        onClick={() => {}} // No-op for inactive devices
                        isSelected={false} // Inactive devices can't be selected
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      ) : null}
    </div>
  );
};

const ZonesListing = ({
  dashboardData,
  selectedDevice,
  setSelectedDevice,
  setZonesListingCount,
}) => {
  const [selectedZone, setSelectedZone] = useState(null);

  const setSelectedDeviceMiddleware = (device) => {
    setSelectedDevice(device);
    localStorage.setItem("selectedDeviceOD", JSON.stringify(device));
  };

  const handleSelectZone = (zone) => {
    const newSelectedZone = zone?.id === selectedZone?.id ? null : zone;
    setSelectedZone(newSelectedZone);
    localStorage.setItem(
      "selectedZoneOD",
      newSelectedZone ? JSON.stringify(newSelectedZone) : ""
    );
  };

  const zones = useMemo(() => {
    if (!dashboardData?.campusCounts) return [];

    // Flatten all zones from all campuses
    const allZones = [];
    dashboardData.campusCounts.forEach((campus) => {
      campus.zonesList?.forEach((zone) => {
        allZones.push({
          id: zone.zoneId,
          name: zone.zoneName,
          campusName: zone.campusName,
          devices:
            zone.devices?.map((device) => ({
              id: device.deviceId,
              name: device.deviceName,
              status: device.status, // Include status property
            })) || [],
        });
      });
    });
    return allZones;
  }, [dashboardData]);

  // Auto-select zone and device logic
  useMemo(() => {
    setZonesListingCount(zones?.length || 0);

    if (zones.length === 0) {
      setSelectedZone(null);
      setSelectedDevice(null);
      return;
    }

    // Get stored zone and device from localStorage
    const storedZoneData = localStorage.getItem("selectedZoneOD");
    const storedDeviceData = localStorage.getItem("selectedDeviceOD");

    let storedZone = null;
    let storedDevice = null;

    try {
      storedZone = storedZoneData ? parseJSON(storedZoneData) : null;
      storedDevice = storedDeviceData ? parseJSON(storedDeviceData) : null;
    } catch (error) {
      console.error("Error parsing stored data:", error);
    }

    // Check if stored zone exists in current zones list
    const storedZoneExists = storedZone
      ? zones.find((zone) => zone.id === storedZone.id)
      : null;

    // Check if stored device exists in the stored zone and is active
    const storedDeviceExists =
      storedZoneExists && storedDevice
        ? storedZoneExists.devices.find(
            (device) =>
              device.id === storedDevice.id && device.status === "Active"
          )
        : null;

    if (storedZoneExists && storedDeviceExists) {
      // If both stored zone and device exist, restore them
      setSelectedZone(storedZoneExists);
      if (!selectedDevice || selectedDevice.id !== storedDevice.id) {
        setSelectedDeviceMiddleware(storedDeviceExists);
      }
    } else {
      // If stored data is invalid or doesn't exist, select first zone with active devices
      const firstZoneWithActiveDevices = zones.find(
        (zone) =>
          zone.devices &&
          zone.devices.some((device) => device.status === "Active")
      );

      if (firstZoneWithActiveDevices) {
        // Set the zone as selected
        setSelectedZone(firstZoneWithActiveDevices);
        localStorage.setItem(
          "selectedZoneOD",
          JSON.stringify(firstZoneWithActiveDevices)
        );

        // Set the first active device as selected
        const firstActiveDevice = firstZoneWithActiveDevices.devices.find(
          (device) => device.status === "Active"
        );
        if (
          firstActiveDevice &&
          (!selectedDevice || selectedDevice.id !== firstActiveDevice.id)
        ) {
          setSelectedDeviceMiddleware(firstActiveDevice);
        }
      } else {
        // No zones with active devices available, clear storage
        setSelectedZone(null);
        localStorage.removeItem("selectedZoneOD");
        localStorage.removeItem("selectedDeviceOD");
        setSelectedDevice(null);
      }
    }
  }, [zones, setSelectedDevice]);

  return (
    <div>
      <h2 className="text-[#222222] text-sm font-semibold pt-[15px] pb-[8px] px-[15px]">
        Zone List ({zones.length})
      </h2>
      {zones.length === 0 ? (
        <div className="text-xs text-center text-[#7A838E] py-4">
          No zones available
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {zones.map((zone) => (
            <ZoneAccordian
              key={zone.id}
              zone={zone}
              isSelected={selectedZone?.id === zone.id}
              onClick={() => handleSelectZone(zone)}
              selectedDevice={selectedDevice}
              setSelectedDevice={setSelectedDeviceMiddleware}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const StatVisualization = ({
  values = [
    {
      label: "On",
      value: 65,
      color: "#1EC34A",
    },
    {
      label: "Off",
      value: 35,
      color: "#F29F1A",
    },
  ],
}) => {
  return (
    <div className="max-w-[180px] w-full flex items-center gap-1">
      {values.map((item) => (
        <div
          className="h-[5px] rounded-[10px]"
          style={{
            width: `${item.value}%`,
            backgroundColor: `${item.color}`,
          }}
        ></div>
      ))}
    </div>
  );
};

const EnergyConsumptionCard = ({ isLoading = false }) => {
  return (
    <div
      className={`shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] px-[10px] py-[15px] flex flex-col`}
    >
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-[#222222] text-sm 1540:text-sm font-semibold text-nowrap">
          Energy Consumption
        </h2>
      </div>
      <div className="grid grid-cols-2 pt-3 flex-grow">
        <div className="text-center py-1 border-r border-[#CCCCCC] flex justify-center flex-col">
          <h2 className="text-[#AAAAAA] text-sm font-semibold">Yesterday</h2>
          <p className="text-xl 1540:text-2xl font-semibold text-[#222222] pt-2">
            45.1 kW
          </p>
        </div>
        <div className="text-center py-1 flex justify-center flex-col">
          <h2 className="text-[#AAAAAA] text-sm font-semibold">
            Current Usage
          </h2>
          <p className="text-xl 1540:text-2xl font-semibold text-[#222222] pt-2">
            10.9 kW
          </p>
        </div>
      </div>
    </div>
  );
};

const StatsCards = ({ statsData, isLoading = false, zonesListingCount }) => {
  const queryClient = useQueryClient();

  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DASHBOARD_ZONE_STATS],
      exact: false,
    });
  };

  const values = useMemo(() => {
    if (!statsData || zonesListingCount === 0) {
      // Return default/loading values
      return [
        {
          id: 1,
          label: "LED Stats",
          properties: {
            installed: 0,
            on: 0,
            off: 0,
          },
        },
        {
          id: 2,
          label: "Shade Stats",
          properties: {
            installed: 0,
            on: 0,
            off: 0,
          },
        },
        {
          id: 3,
          label: "Sensor Stats",
          properties: {
            installed: 0,
            on: 0,
            off: 0,
          },
        },
      ];
    }

    return [
      {
        id: 1,
        label: "LED Stats",
        properties: {
          installed: statsData.leds?.installed || 0,
          on: statsData.leds?.on || 0,
          off: statsData.leds?.off || 0,
        },
      },
      {
        id: 2,
        label: "Shade Stats",
        properties: {
          installed: statsData.shades?.installed || 0,
          on: statsData.shades?.open || 0, // API returns 'open' for shades
          off: statsData.shades?.closed || 0, // API returns 'closed' for shades
        },
      },
      {
        id: 3,
        label: "Sensor Stats",
        properties: {
          installed: statsData.sensors?.installed || 0,
          on: statsData.sensors?.active || 0, // API returns 'active' for sensors
          off: statsData.sensors?.inactive || 0, // API returns 'inactive' for sensors
        },
      },
    ];
  }, [statsData, zonesListingCount]);

  return (
    <div className="grid grid-cols-4 gap-4">
      <DeviceStatusChanged callback={realTimeChangeCallback} />
      {values.map((item) => (
        <div
          key={item.id}
          className={`shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] px-[10px] py-[15px] ${
            isLoading ? "opacity-60" : ""
          }`}
        >
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-[#222222] text-sm font-semibold text-nowrap">
              {item.label}
            </h2>
            <StatVisualization
              values={[
                {
                  label: "On",
                  value:
                    (item.properties.on / item.properties.installed) * 100 || 0,
                  color: "#1EC34A",
                },
                {
                  label: "Off",
                  value:
                    (item.properties.off / item.properties.installed) * 100 ||
                    0,
                  color: "#F29F1A",
                },
              ]}
            />
          </div>
          <div className="grid grid-cols-3 pt-3">
            <div className="text-center py-1 border-r border-[#CCCCCC]">
              <h2 className="text-[#AAAAAA] text-xs font-semibold">
                Installed
              </h2>
              <p className="text-sm font-semibold text-[#222222] pt-2">
                {isLoading ? "..." : padStart(item.properties.installed)}
              </p>
            </div>
            <div className="text-center py-1 border-r border-[#CCCCCC]">
              <h2 className="text-[#AAAAAA] text-xs font-semibold">
                {item.id === 2 ? "Open" : item.id === 3 ? "Active" : "On"}
              </h2>
              <p className="text-sm font-semibold text-[#222222] pt-2">
                {isLoading ? "..." : padStart(item.properties.on)}
              </p>
            </div>
            <div className="text-center py-1">
              <h2 className="text-[#AAAAAA] text-xs font-semibold">
                {item.id === 2 ? "Closed" : item.id === 3 ? "Inactive" : "Off"}
              </h2>
              <p className="text-sm font-semibold text-[#222222] pt-2">
                {isLoading ? "..." : padStart(item.properties.off)}
              </p>
            </div>
          </div>
        </div>
      ))}
      <EnergyConsumptionCard />
    </div>
  );
};

const DeviceOverviewCard = ({
  deviceDetails,
  isLoading,
  error,
  selectedDevice,
}) => {
  if (error) {
    return (
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-[15px]">
        <div className="flex items-center justify-between">
          <h2 className="text-[#222222] text-sm font-semibold">
            Device Overview
          </h2>
        </div>
        <div className="pt-[15px] text-xs text-center text-[#7A838E]">
          Error loading device details
        </div>
      </div>
    );
  }

  if (!selectedDevice) {
    return (
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-[15px]">
        <div className="flex items-center justify-between">
          <h2 className="text-[#222222] text-sm font-semibold">
            Device Overview
          </h2>
        </div>
        <div className="pt-[15px] text-xs text-center text-[#7A838E]">
          No device selected
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-[15px]">
        <div className="flex items-center justify-between">
          <h2 className="text-[#222222] text-sm font-semibold">
            Device Overview
          </h2>
        </div>
        <div className="pt-[15px] text-xs text-center text-[#7A838E]">
          Loading device details...
        </div>
      </div>
    );
  }

  return (
    <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-[15px]">
      <div className="flex items-center justify-between">
        <h2 className="text-[#222222] text-sm font-semibold">
          Device Overview
        </h2>
        <Link
          to={ROUTES.GET_VIEW_CONFIGURED_DEVICE(deviceDetails?.device_id)}
          className="text-[#227EEB] text-xs flex items-center gap-1"
        >
          <RiEditFill />
          Manage Channel
        </Link>
      </div>

      <div className="grid grid-cols-4 gap-x-4 gap-y-[10px] pt-[15px] text-xs">
        <div className="text-[#7A838E]">Name: </div>
        <div>{deviceDetails?.device_name || "N/A"}</div>
        <div className="text-[#7A838E]">Device Type:</div>
        <div>{deviceDetails?.device_type || "N/A"}</div>
        <div className="text-[#7A838E]">DeviceId: </div>
        <div>{deviceDetails?.device_id || "N/A"}</div>
        <div className="text-[#7A838E]">Serial No.:</div>
        <div>{deviceDetails?.sno || "N/A"}</div>
        <div className="text-[#7A838E]">Mac Address:</div>
        <div>{deviceDetails?.mac_address || "N/A"}</div>
        <div className="text-[#7A838E]">Firmware: </div>
        <div>{deviceDetails?.firmware || "N/A"}</div>
        <div className="text-[#7A838E]">Description: </div>
        <div>{deviceDetails?.description || "N/A"}</div>
      </div>

      <hr className="my-4 border-[#CCCCCC]" />

      <div className="flex items-center justify-between">
        <h2 className="text-[#222222] text-sm font-semibold">
          Location Details
        </h2>
      </div>

      <div className="grid grid-cols-4 gap-x-4 gap-y-[10px] pt-[15px] text-xs">
        <div className="text-[#7A838E]">Campus: </div>
        <div>{deviceDetails?.location?.campus?.name || "N/A"}</div>
        <div className="text-[#7A838E]">Building:</div>
        <div>{deviceDetails?.location?.building?.name || "N/A"}</div>
        <div className="text-[#7A838E]">Floor: </div>
        <div>{deviceDetails?.location?.floor?.name || "N/A"}</div>
        <div className="text-[#7A838E]">Zone:</div>
        <div>{deviceDetails?.location?.zone?.name || "N/A"}</div>
      </div>
    </div>
  );
};

const DeviceControlView = ({
  deviceDetails,
  isLoading,
  error,
  selectedDevice,
  activeAccordion,
  onAccordionToggle,
}) => {
  const queryClient = useQueryClient();
  const [channelStates, setChannelStates] = useState({});
  const { user } = useUserStore();
  const userPermissions = useUserStore((state) => state.permissions);
  const canControl = userPermissions?.CONTROL_SECTION?.device_tab?.addModify;

  const triggerEventMutation = useTriggerEvent({
    onSuccess: (response) => {
      // Optionally handle success response
    },
    onError: (error) => {
      console.error("Event trigger failed:", error);
    },
  });

  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DEVICE_IN_CONTROL_SYSTEM],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.GET_ALL_SCENES_IN_CONTROL_SYSTEM],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DASHBOARD_DEVICE_INFO],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.SCENES],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DASHBOARD_ZONE_STATS],
      exact: false,
    });
  };

  const getChannelKey = (channel) => `${selectedDevice?.id}-${channel.id}`;

  const getUserData = () => ({
    userId: user?.id,
  });

  const handleLEDToggle = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const newStatus = currentState.status === "on" ? "off" : "on";

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          status: newStatus,
          properties: {
            ...currentState.properties,
            brightness:
              newStatus === "on"
                ? 100
                : parseInt(currentState.properties?.brightness || 0),
          },
        },
      }));

      if (newStatus === "on") handleLEDBrightnessCommit(channel, 100);

      const userData = getUserData();

      const payload = {
        ...userData,
        device_id: selectedDevice?.id,
        deviceData:
          newStatus === "on"
            ? {
                properties: {
                  brightness: parseInt(
                    currentState.properties?.brightness || 0
                  ),
                  // powerMin: 0,
                  // powerMax: 100,
                  powerMin: parseInt(currentState.properties?.powerMin || 0),
                  powerMax: parseInt(
                    currentState.properties?.powerMax || 0
                  ),
                },
              }
            : {},
        channelType: "LED",
        channelAddress: channel.id,
        command: newStatus === "on" ? "LED_ON" : "LED_OFF",
      };

      triggerEventMutation.mutate(payload);
    },
    [channelStates, triggerEventMutation, selectedDevice?.id, user?.id]
  );

  const handleLEDBrightnessChange = useCallback(
    (channel, brightness) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            brightness: brightness,
          },
        },
      }));
    },
    [channelStates, selectedDevice?.id]
  );

  const handleLEDBrightnessCommit = useCallback(
    (channel, brightness) => {
      const userData = getUserData();

      const payload = {
        ...userData,
        device_id: selectedDevice?.id,
        deviceData: {
          properties: {
            brightness: brightness,
            // powerMin: 0,
            // powerMax: 100,
            powerMin: parseInt(channel?.properties?.powerMin || 0),
            powerMax: parseInt(channel?.properties?.powerMax || 0),
          },
        },
        channelType: "LED",
        channelAddress: channel.id,
        command: "LED_BRIGHTNESS",
      };

      triggerEventMutation.mutate(payload, {
        onSuccess: () => {
          toaster.success("Brightness updated successfully");
        },
        onError: (error) => {
          toaster.error(
            error?.response?.data?.message || "Failed to update brightness"
          );
        },
      });
    },
    [triggerEventMutation, selectedDevice?.id, user?.id]
  );

  const handleShadeUp = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") || 0
      );
      // For shade_lutron devices, set openLevel to 100 when going up
      // const newLevel =
      //   deviceDetails?.device_type?.toLowerCase() === "shade_lutron"
      //     ? 100
      //     : Math.min(100, currentLevel + 10);
      const newLevel = 100;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: selectedDevice?.id,
        deviceData: {
          properties: {
            ...(deviceDetails?.device_type?.toLowerCase() !==
              "shade_lutron" && { openLevel: newLevel }),
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          },
        },
        channelType: "SHADE",
        channelAddress: channel.id,
        command: "SHADE_UP",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [
      channelStates,
      triggerEventMutation,
      selectedDevice?.id,
      user?.id,
      deviceDetails?.device_type,
    ]
  );

  const handleShadeDown = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") || 0
      );
      // For shade_lutron devices, set openLevel to 0 when going down
      const newLevel = 0;
      // const newLevel =
      //   deviceDetails?.device_type?.toLowerCase() === "shade_lutron"
      //     ? 0
      //     : Math.max(0, currentLevel - 10);

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: selectedDevice?.id,
        deviceData: {
          properties: {
            ...(deviceDetails?.device_type?.toLowerCase() !==
              "shade_lutron" && { openLevel: newLevel }),
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          },
        },
        channelType: "SHADE",
        channelAddress: channel.id,
        command: "SHADE_DOWN",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [
      channelStates,
      triggerEventMutation,
      selectedDevice?.id,
      user?.id,
      deviceDetails?.device_type,
    ]
  );

  const handleShade33 = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") || 0
      );
      const newLevel = 33;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: selectedDevice?.id,
        deviceData: {
          properties: {
            ...(deviceDetails?.device_type?.toLowerCase() !==
              "shade_lutron" && { openLevel: newLevel }),
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          },
        },
        channelType: "SHADE",
        channelAddress: channel.id,
        command: "SHADE_33",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [
      channelStates,
      triggerEventMutation,
      selectedDevice?.id,
      user?.id,
      deviceDetails?.device_type,
    ]
  );

  const handleShade66 = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") || 0
      );
      const newLevel = 66;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: selectedDevice?.id,
        deviceData: {
          properties: {
            ...(deviceDetails?.device_type?.toLowerCase() !==
              "shade_lutron" && { openLevel: newLevel }),
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          },
        },
        channelType: "SHADE",
        channelAddress: channel.id,
        command: "SHADE_66",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [
      channelStates,
      triggerEventMutation,
      selectedDevice?.id,
      user?.id,
      deviceDetails?.device_type,
    ]
  );

  const handleShadeStop = useCallback(
    (channel) => {
      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: selectedDevice?.id,
        deviceData: {
          properties: {
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          },
        },
        channelType: "SHADE",
        channelAddress: channel.id,
        command: "SHADE_STOP",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [triggerEventMutation, selectedDevice?.id, user?.id]
  );

  // Process channels from device details
  const channels = deviceDetails?.installed_channels || [];

  const leds = channels
    .map((item) => ({
      ...item,
      id: item?.channel_id,
      channelId: item?.channel_id,
      name: item?.channel_name,
      type: item?.channel_type,
    }))
    ?.filter((device) => device.type === "led");

  const shades = channels
    .map((item) => ({
      ...item,
      id: item?.channel_id,
      channelId: item?.channel_id,
      name: item?.channel_name,
      type: item?.channel_type,
    }))
    ?.filter((device) => device.type === "shade");

  const sensors = channels
    .map((item) => ({
      ...item,
      id: item?.channel_id,
      channelId: item?.channel_id,
      name: item?.channel_name,
      type: item?.channel_type,
    }))
    ?.filter((device) => device.type === "sensor");

  return (
    <div className="pt-5 space-y-4">
      <DeviceStatusChanged callback={realTimeChangeCallback} />

      {/* LED Channels Accordion */}
      <div className="">
        <button
          onClick={() => onAccordionToggle("leds")}
          className="flex items-center text-[#7A838E] text-sm font-semibold gap-[5px] w-full px-[10px] mb-3"
        >
          <span>
            <IoMdArrowDropup
              className={`text-lg fill-[#222222] ${
                activeAccordion === "leds" ? "rotate-180" : ""
              }`}
            />
          </span>
          <span className="text-[#222222]">LEDs</span>
          <span className="border-b-2 border-[#cccccc] flex-grow"></span>
          <span className="text-xs text-[#939CA7]">
            {padStart(deviceDetails?.channel_summary?.by_type?.led || 0)} Active
            -{" "}
            {padStart(
              (deviceDetails?.channel_summary?.total_leds || 0) -
                (deviceDetails?.channel_summary?.by_type?.led || 0)
            )}{" "}
            Inactive
          </span>
        </button>
        {activeAccordion === "leds" && (
          <div className="px-5 pb-5">
            {error ? (
              <div className="text-xs text-center text-[#7A838E] py-8">
                Error loading device control
              </div>
            ) : !selectedDevice ? (
              <div className="text-xs text-center text-[#7A838E] py-8">
                No device selected
              </div>
            ) : isLoading ? (
              <div className="flex items-center justify-center py-8">
                <SpinnerV1 />
              </div>
            ) : (
              <div className="grid grid-cols-4 1540:grid-cols-5 gap-[32px]">
                {leds?.length ? (
                  leds?.map((led) => (
                    <LEDCard
                      key={led.id}
                      channel={{ ...led, deviceId: selectedDevice?.id }}
                      onLEDToggle={handleLEDToggle}
                      onLEDBrightnessChange={handleLEDBrightnessChange}
                      onLEDBrightnessCommit={handleLEDBrightnessCommit}
                      channelStates={channelStates}
                      canControl={canControl}
                    />
                  ))
                ) : (
                  <div className="text-xs text-[#7A838E]">
                    LEDs not configured yet.
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Shade Channels Accordion */}
      <div className="">
        <button
          onClick={() => onAccordionToggle("shades")}
          className="flex items-center text-[#7A838E] text-sm font-semibold gap-[5px] w-full px-[10px] mb-3"
        >
          <span>
            <IoMdArrowDropup
              className={`text-lg fill-[#222222] ${
                activeAccordion === "shades" ? "rotate-180" : ""
              }`}
            />
          </span>
          <span className="text-[#222222]">Shades</span>
          <span className="border-b-2 border-[#cccccc] flex-grow"></span>
          <span className="text-xs text-[#939CA7]">
            {padStart(deviceDetails?.channel_summary?.by_type?.shade || 0)}{" "}
            Active -{" "}
            {padStart(
              (deviceDetails?.channel_summary?.total_shades || 0) -
                (deviceDetails?.channel_summary?.by_type?.shade || 0)
            )}{" "}
            Inactive
          </span>
        </button>
        {activeAccordion === "shades" && (
          <div className="px-5 pb-5">
            {error ? (
              <div className="text-xs text-center text-[#7A838E] py-8">
                Error loading device control
              </div>
            ) : !selectedDevice ? (
              <div className="text-xs text-center text-[#7A838E] py-8">
                No device selected
              </div>
            ) : isLoading ? (
              <div className="flex items-center justify-center py-8">
                <SpinnerV1 />
              </div>
            ) : (
              <div className="grid grid-cols-3 1540:grid-cols-4 gap-[32px]">
                {shades?.length ? (
                  shades?.map((shade) => (
                    <ShadeCard
                      key={shade.id}
                      channel={{ ...shade, deviceId: selectedDevice?.id }}
                      onShadeUp={handleShadeUp}
                      onShadeDown={handleShadeDown}
                      onShadeStop={handleShadeStop}
                      onShade33={handleShade33}
                      onShade66={handleShade66}
                      channelStates={channelStates}
                      canControl={canControl}
                      device={{
                        ...deviceDetails,
                        type: deviceDetails?.device_type,
                      }}
                    />
                  ))
                ) : (
                  <div className="text-xs text-[#7A838E]">
                    Shades not configured yet.
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

const NewDeviceOverViewCard = ({ selectedDevice }) => {
  const {
    data: deviceDetailsResponse,
    isLoading,
    error,
  } = useGetDeviceByIdInControlSystem(selectedDevice?.id, (data) => {});

  const deviceDetails = deviceDetailsResponse?.data;

  return (
    <DeviceOverviewCard
      deviceDetails={deviceDetails}
      isLoading={isLoading}
      error={error}
      selectedDevice={selectedDevice}
    />
  );
};

const DeviceOverviewContainer = ({ selectedDevice }) => {
  const [activeAccordion, setActiveAccordion] = useState(null); // Manage accordion state for all sections

  // Fetch device details when a device is selected
  const {
    data: deviceDetailsResponse,
    isLoading,
    error,
  } = useGetDeviceByIdInControlSystem(selectedDevice?.id, (data) => {});

  const deviceDetails = deviceDetailsResponse?.data;

  const handleAccordionToggle = (accordionType) => {
    setActiveAccordion(
      activeAccordion === accordionType ? null : accordionType
    );
  };

  return (
    <>
      {/* <DeviceOverviewCard
        deviceDetails={deviceDetails}
        isLoading={isLoading}
        error={error}
        selectedDevice={selectedDevice}
      /> */}
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] pb-3">
        <DeviceControlView
          deviceDetails={deviceDetails}
          isLoading={isLoading}
          error={error}
          selectedDevice={selectedDevice}
          activeAccordion={activeAccordion}
          onAccordionToggle={handleAccordionToggle}
        />
        <Devicegroups
          selectedDevice={selectedDevice}
          activeAccordion={activeAccordion}
          onAccordionToggle={handleAccordionToggle}
        />
        <Devicescenes
          selectedDevice={selectedDevice}
          activeAccordion={activeAccordion}
          onAccordionToggle={handleAccordionToggle}
        />
      </div>
    </>
  );
};

const AlertCard = ({ alert }) => {
  // Convert Unix timestamp to Date object for formatting
  const formattedTime = formatTimev2(new Date(alert.timestamp * 1000), ", ");

  return (
    <div className="border-b border-[#DDDDDD] py-3 last:border-0">
      <div className="flex items-start justify-between mb-2">
        <h4 className="text-sm text-[#222222]" title={alert.action}>
          {alert?.name === "" || alert?.name === "-" ? "" : `${alert?.name} - `}
          {alert.action}
        </h4>
      </div>
      <div>
        <h3 className="text-[#257FEA] text-xs">{alert?.deviceName || ""}</h3>
      </div>
      <div className="flex items-center justify-between gap-3">
        <h3 className="text-[#AAAAAA] text-xs truncate">
          ({alert?.deviceId || ""})
        </h3>
        <h3 className="text-[#AAAAAA] text-xs flex-shrink-0">
          {alert?.timestamp ? formattedTime : ""}
        </h3>
      </div>
    </div>
  );
};

const AlertsContainer = ({ selectedDevice }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const limit = 20;

  // Fetch alerts from API
  const {
    data: alertsResponse,
    isLoading,
    error,
    refetch,
  } = useGetDashboardAlerts({
    page: currentPage,
    limit,
    device_id: selectedDevice?.id,
  });

  const alerts = alertsResponse?.data?.alerts || [];
  const pagination = alertsResponse?.data?.pagination || {};

  const handlePageChange = useCallback((page) => {
    setCurrentPage(page);
  }, []);

  const handleRefresh = useCallback(() => {
    refetch();
  }, [refetch]);

  if (error) {
    return (
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <div className="flex items-center justify-between">
          <h3 className="text-xs text-[#222222] font-semibold">Alerts</h3>
          <button
            onClick={handleRefresh}
            className="text-xs text-[#227EEB] hover:underline"
          >
            Retry
          </button>
        </div>
        <div className="text-xs text-center text-[#7A838E] py-8">
          Error loading alerts
        </div>
      </div>
    );
  }

  return (
    <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 max-h-[calc(100vh-80px)] overflow-y-auto hide-scrollbar">
      <div className="flex items-center justify-between">
        <h3 className="text-sm text-[#222222] font-semibold">Alerts</h3>
      </div>

      <div>
        {isLoading && currentPage === 1 ? (
          <div className="text-xs text-center text-[#7A838E] py-8">
            Loading alerts...
          </div>
        ) : alerts.length === 0 ? (
          <div className="text-xs text-center text-[#7A838E] py-8">
            No alerts found
          </div>
        ) : (
          <>
            {alerts.map((alert) => (
              <AlertCard key={alert._id} alert={alert} />
            ))}

            {/* Pagination */}
            {pagination.totalPages > 1 && (
              <div className="flex items-center justify-between mt-4 pt-4 border-[#DDDDDD]">
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={!pagination.hasPrevPage || isLoading}
                  className="text-xs text-[#227EEB] hover:underline disabled:text-[#AAAAAA] disabled:no-underline"
                >
                  Previous
                </button>

                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={!pagination.hasNextPage || isLoading}
                  className="text-xs text-[#227EEB] hover:underline disabled:text-[#AAAAAA] disabled:no-underline"
                >
                  Next
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

const Devicescenes = ({
  selectedDevice,
  activeAccordion,
  onAccordionToggle,
}) => {
  const queryClient = useQueryClient();
  const [selectedScene, setSelectedScene] = useState(null);

  // Create payload for device info API
  const deviceInfoPayload = useMemo(() => {
    if (!selectedDevice?.id) return null;
    return {
      deviceId: selectedDevice.id,
    };
  }, [selectedDevice?.id]);

  // Fetch device scenes when device is selected
  const {
    data: deviceInfoResponse,
    isLoading: isScenesLoading,
    error: scenesError,
  } = useGetDashboardDeviceInfo(deviceInfoPayload || {});

  const deviceScenes = deviceInfoResponse?.data?.scenes || [];

  const handleSceneSelect = useCallback(
    (scene) => {
      setSelectedScene(
        scene?.sceneId === selectedScene?.sceneId ? null : scene
      );
    },
    [selectedScene]
  );

  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.GET_ALL_SCENES_IN_CONTROL_SYSTEM],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DASHBOARD_DEVICE_INFO],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.SCENES],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DASHBOARD_ZONE_STATS],
      exact: false,
    });
  };

  return (
    <div className="px-[10px]">
      <DeviceStatusChanged callback={realTimeChangeCallback} />

      {/* Scenes Accordion */}
      <div className="">
        <button
          onClick={() => onAccordionToggle("scenes")}
          className="flex items-center text-[#7A838E] text-sm font-semibold gap-[5px] w-full mb-3"
        >
          <span>
            <IoMdArrowDropup
              className={`text-lg fill-[#222222] ${
                activeAccordion === "scenes" ? "rotate-180" : ""
              }`}
            />
          </span>
          <span className="text-[#222222]">Scenes</span>
          <span className="border-b-2 border-[#cccccc] flex-grow"></span>
          <span className="text-xs text-[#939CA7]">
            {padStart(deviceScenes.length || 0)} Total
          </span>
        </button>
        {activeAccordion === "scenes" && (
          <div className="px-5 pb-5">
            {scenesError ? (
              <div className="text-xs text-center text-[#7A838E] py-8">
                Error loading device scenes
              </div>
            ) : !selectedDevice ? (
              <div className="text-xs text-center text-[#7A838E] py-8">
                No device selected
              </div>
            ) : isScenesLoading ? (
              <div className="flex items-center justify-center py-8">
                <SpinnerV1 />
              </div>
            ) : deviceScenes.length === 0 ? (
              <div className="text-xs text-center text-[#7A838E] py-8">
                No scenes found for this device
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {deviceScenes.map((scene) => (
                  <SceneCard
                    key={scene.sceneId}
                    scene={{
                      _id: scene.sceneId,
                      name: scene.name,
                      type: scene.type,
                      operateType: scene.operateType,
                      lastExecuted: scene.lastExecuted,
                      invert_flag: scene.invert_flag,
                      ...scene,
                    }}
                    onClick={() => handleSceneSelect(scene)}
                    isSelected={selectedScene?.sceneId === scene.sceneId}
                    // usedIn="dashboard"
                  />
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

const Devicegroups = ({
  selectedDevice,
  activeAccordion,
  onAccordionToggle,
}) => {
  const queryClient = useQueryClient();

  // Create payload for device info API
  const deviceInfoPayload = useMemo(() => {
    if (!selectedDevice?.id) return null;
    return {
      deviceId: selectedDevice.id,
    };
  }, [selectedDevice?.id]);

  // Fetch device scenes when device is selected
  const {
    data: deviceInfoResponse,
    isLoading: isGroupsLoading,
    error: groupsError,
  } = useGetDashboardDeviceGetGroups(deviceInfoPayload || {});

  const deviceGroups = deviceInfoResponse?.data || [];

  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.GET_ALL_SCENES_IN_CONTROL_SYSTEM],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DASHBOARD_DEVICE_INFO],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.SCENES],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DASHBOARD_ZONE_STATS],
      exact: false,
    });
  };

  return (
    <div className="px-[10px]">
      <DeviceStatusChanged callback={realTimeChangeCallback} />

      {/* Groups Accordion */}
      <div className="">
        <button
          onClick={() => onAccordionToggle("groups")}
          className="flex items-center text-[#7A838E] text-sm font-semibold gap-[5px] w-full mb-3"
        >
          <span>
            <IoMdArrowDropup
              className={`text-lg fill-[#222222] ${
                activeAccordion === "groups" ? "rotate-180" : ""
              }`}
            />
          </span>
          <span className="text-[#222222]">Groups</span>
          <span className="border-b-2 border-[#cccccc] flex-grow"></span>
          <span className="text-xs text-[#939CA7]">
            {padStart(deviceGroups.length || 0)} Total
          </span>
        </button>
        {activeAccordion === "groups" && (
          <div className="px-5 pb-5">
            {groupsError ? (
              <div className="text-xs text-center text-[#7A838E] py-8">
                Error loading device groups
              </div>
            ) : !selectedDevice ? (
              <div className="text-xs text-center text-[#7A838E] py-8">
                No device selected
              </div>
            ) : isGroupsLoading ? (
              <div className="flex items-center justify-center py-8">
                <SpinnerV1 />
              </div>
            ) : deviceGroups.length === 0 ? (
              <div className="text-xs text-center text-[#7A838E] py-8">
                No groups found for this device
              </div>
            ) : (
              <div className="flex flex-col gap-4">
                {deviceGroups.map((groupData) => (
                  <GroupView
                    key={groupData?.id}
                    groupData={{
                      message: "Group view data retrieved successfully",
                      success: true,
                      data: groupData,
                    }}
                    usedIn="dashboard"
                  />
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

function Dashboard() {
  // Device selection state - initialize from localStorage safely
  const [selectedDevice, setSelectedDevice] = useState(() => {
    try {
      const storedDevice = localStorage.getItem("selectedDeviceOD");
      return storedDevice ? parseJSON(storedDevice) : null;
    } catch (error) {
      console.error("Error parsing stored device:", error);
      return null;
    }
  });

  const [zonesListingCount, setZonesListingCount] = useState(0);

  // Get selected locations from the store
  const { selectedCampuses, selectedBuildings, selectedFloors, selectedZones } =
    useLocationSelectedStore();

  // Create the location payload for the API
  const locationPayload = useMemo(() => {
    const payload = {
      campus_ids: Array.from(selectedCampuses),
      building_ids: Array.from(selectedBuildings),
      floor_ids: Array.from(selectedFloors),
      zone_ids: Array.from(selectedZones),
    };

    return payload;
  }, [selectedCampuses, selectedBuildings, selectedFloors, selectedZones]);

  // Create the zone stats payload (only zone_ids needed)
  const zoneStatsPayload = useMemo(() => {
    const payload = {
      zone_ids: Array.from(selectedZones),
    };

    return payload;
  }, [selectedZones]);

  const {
    data: dashboardData,
    isLoading,
    error,
  } = useGetDashboardSummary(locationPayload);

  const {
    data: zoneStatsData,
    isLoading: isStatsLoading,
    error: statsError,
  } = useGetDashboardZoneStats(zoneStatsPayload);

  if (isLoading) {
    return (
      <div className="h-[calc(100vh-55px)] flex items-center justify-center">
        <SpinnerV1 />
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-[calc(100vh-55px)] flex items-center justify-center">
        <div className="text-center">
          <h3 className="text-lg font-semibold text-[#222222] mb-2">
            Error Loading Dashboard
          </h3>
          <p className="text-[#939CA7]">
            {error?.response?.data?.message || "Something went wrong"}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] overflow-auto flex gap-4">
      <div className="w-[400px] flex-shrink-0 shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] h-full overflow-y-auto">
        <SelectedCampusesDetails
          dashboardData={dashboardData?.data}
          locationPayload={locationPayload}
        />
        <ZonesListing
          dashboardData={dashboardData?.data}
          selectedDevice={selectedDevice}
          setSelectedDevice={setSelectedDevice}
          setZonesListingCount={setZonesListingCount}
        />
      </div>

      {/* <div className="flex gap-4 flex-1">
          <div className="flex-grow">
            <DeviceOverviewContainer selectedDevice={selectedDevice} />
            </div>
            <div className="flex flex-col gap-4 min-w-[400px] flex-grow max-w-[400px]">
          <AlertsContainer />
          <Devicescenes selectedDevice={selectedDevice} />
          </div>
          </div> */}
      <div className="flex-1 overflow-y-auto">
        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2">
            <NewDeviceOverViewCard selectedDevice={selectedDevice} />
          </div>
          <EnergyConsumptionCard />
        </div>

        <SensorReadings />

        <div className="grid grid-cols-3 gap-4 mt-4">
          <div className="col-span-2">
            <DeviceOverviewContainer selectedDevice={selectedDevice} />
          </div>
          <AlertsContainer selectedDevice={selectedDevice} />
        </div>
        {/* <StatsCards
          statsData={zoneStatsData?.data}
          isLoading={isStatsLoading}
          zonesListingCount={zonesListingCount}
        /> */}
      </div>
    </div>
  );
}

export default Dashboard;
