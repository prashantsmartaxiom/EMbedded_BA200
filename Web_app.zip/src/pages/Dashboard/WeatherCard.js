import { Link } from "react-router-dom";
import {
  CloudSunSvg,
  LocationSvg,
  Weather0Svg,
  Weather1_44Svg,
  Weather45_50Svg,
  Weather51_60Svg,
  Weather61_70Svg,
  Weather71_79Svg,
  Weather80_94Svg,
  Weather95Svg,
  Weather0NSvg,
  Weather1_44NSvg,
  Weather45_50NSvg,
  Weather51_60NSvg,
  Weather61_70NSvg,
  Weather71_79NSvg,
  Weather80_94NSvg,
  Weather95NSvg,
  FeelsLikeWSvg,
  WindWSvg,
  GaugeHighWSvg,
  CloudWSvg,
  HumidityWSvg,
  DewPointWSvg,
} from "../../assets/svg";
import Seperator from "../../components/Header/Seperator";
import AnalogClockContent from "../CreateWidget/AnalogClockW";
import DigitalClockContent from "../CreateWidget/DigitClockW";
import { useEffect } from "react";
import socket from "../../socket";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../api/queryKeys";
import SensorCardForWidget from "../CreateWidget/SensorCardForWidget";

export const AQIGauge = ({ value = 0 }) => {
  const getArrowTransform = () => {
    let className = "";
    if (value >= 0 && value < 51) className = "translate(10 40) rotate(-28)";
    else if (value >= 51 && value < 101)
      className = "translate(14 20) rotate(30)";
    else if (value >= 101 && value < 151)
      className = "translate(27.797 11) rotate(65)";
    else if (value >= 151 && value < 201)
      className = "translate(46 13) rotate(110)";
    else if (value >= 201 && value < 301)
      className = "translate(58 28) rotate(150)";
    else if (value >= 301) className = "translate(54 46) rotate(-150)";
    return className || "translate(10 40) rotate(-28)";
  };
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      id="noun-meter-3194289"
      width="full"
      height="full"
      viewBox="0 0 67.222 55"
    >
      <g id="Group_1041" data-name="Group 1041" transform="translate(0 0)">
        <path
          id="Path_600"
          data-name="Path 600"
          d="M37.347,11.4A32.875,32.875,0,0,0,20.086,18.62a.725.725,0,0,0-.071,1.073l3.254,3.29a.661.661,0,0,0,.92.072,27.682,27.682,0,0,1,13.3-5.579.758.758,0,0,0,.637-.715V12.112A.661.661,0,0,0,37.347,11.4Z"
          transform="translate(-7.556 -11.387)"
          fill="#fa7e01"
        />
        <path
          id="Path_601"
          data-name="Path 601"
          d="M3.2,47.227H7.8a.755.755,0,0,0,.707-.644,28.316,28.316,0,0,1,5.518-13.446.674.674,0,0,0-.071-.93L10.7,28.918a.707.707,0,0,0-1.061.072A34.74,34.74,0,0,0,2.5,46.44.692.692,0,0,0,3.2,47.227Z"
          transform="translate(-2.487 -16.321)"
          fill="#f9c330"
        />
        <path
          id="Path_602"
          data-name="Path 602"
          d="M72.339,18.62A33.36,33.36,0,0,0,55.078,11.4a.691.691,0,0,0-.778.715V16.76a.758.758,0,0,0,.637.715,27.682,27.682,0,0,1,13.3,5.579.656.656,0,0,0,.92-.072l3.254-3.29A.725.725,0,0,0,72.339,18.62Z"
          transform="translate(-17.647 -11.387)"
          fill="#e5432e"
        />
        <path
          id="Path_603"
          data-name="Path 603"
          d="M92.668,46.44a33.624,33.624,0,0,0-7.145-17.451.707.707,0,0,0-1.061-.072l-3.254,3.29a.679.679,0,0,0-.071.93,28.317,28.317,0,0,1,5.518,13.446.755.755,0,0,0,.707.644h4.6A.692.692,0,0,0,92.668,46.44Z"
          transform="translate(-25.456 -16.321)"
          fill="#99004c"
        />
        <path
          id="Path_604"
          data-name="Path 604"
          d="M2.5,63.958a34.453,34.453,0,0,0,6.72,16.879.707.707,0,0,0,1.061.072l3.254-3.29a.756.756,0,0,0,.071-.93A28.77,28.77,0,0,1,8.509,63.744.755.755,0,0,0,7.8,63.1H3.2A.752.752,0,0,0,2.5,63.958Z"
          transform="translate(-2.487 -26.115)"
          fill="#68e347"
        />
        <path
          id="Path_605"
          data-name="Path 605"
          d="M81.808,77.547l3.254,3.29a.707.707,0,0,0,1.061-.072,34.453,34.453,0,0,0,6.72-16.879.692.692,0,0,0-.707-.787h-4.6a.755.755,0,0,0-.707.644,27.907,27.907,0,0,1-5.093,12.8A.766.766,0,0,0,81.808,77.547Z"
          transform="translate(-25.631 -26.115)"
          fill="#7e0222"
        />
      </g>
      <path
        id="Path_607"
        data-name="Path 607"
        d="M.228,4.237l3.664,3.1A.671.671,0,0,0,5,6.852V.647a.646.646,0,0,0-.392-.59.686.686,0,0,0-.717.1L.229,3.263a.633.633,0,0,0,0,.972Z"
        transform={getArrowTransform(value)}
        fill="#222"
        stroke="#222"
      />
      <text
        x="33.611"
        y="40"
        text-anchor="middle"
        font-size="16"
        font-weight="bold"
        fill="#222"
      >
        {value}
      </text>
    </svg>
  );
};

export const getWeatherSvg = (weatherCode, isDay) => {
  const isDayTime = isDay;

  if (weatherCode === 0) return isDayTime ? Weather0Svg : Weather0NSvg;
  else if (weatherCode >= 1 && weatherCode <= 44)
    return isDayTime ? Weather1_44Svg : Weather1_44NSvg;
  else if (weatherCode >= 45 && weatherCode <= 50)
    return isDayTime ? Weather45_50Svg : Weather45_50NSvg;
  else if (weatherCode >= 51 && weatherCode <= 60)
    return isDayTime ? Weather51_60Svg : Weather51_60NSvg;
  else if (weatherCode >= 61 && weatherCode <= 70)
    return isDayTime ? Weather61_70Svg : Weather61_70NSvg;
  else if (weatherCode >= 71 && weatherCode <= 79)
    return isDayTime ? Weather71_79Svg : Weather71_79NSvg;
  else if (weatherCode >= 80 && weatherCode <= 94)
    return isDayTime ? Weather80_94Svg : Weather80_94NSvg;
  else if (weatherCode >= 95) return isDayTime ? Weather95Svg : Weather95NSvg;

  return isDayTime ? Weather1_44Svg : Weather1_44NSvg;
};

const WeatherCard = ({
  lat = 37.3382,
  long = -121.8863,
  placeName = "",
  uiType = "default",
  totalWidgets,
  location,
  midElement = null,
  listenRealTimeChange = false,
}) => {
  const queryClient = useQueryClient();
  const current = location?.currentHourData;
  const selectedProperties = location?.selectedProperties || [];

  const temperature = current?.temperature_2m;
  const feelsLike = current?.apparent_temperature;
  const windSpeed = current?.wind_speed_10m;
  const pressure = current?.surface_pressure;
  const weatherCode = current?.weather_code;
  const isDay = current?.is_day;
  const cloudCover = current?.cloud_cover;
  const humidity = current?.relative_humidity_2m;
  const dewPoint = current?.dew_point_2m;

  const aqi = current?.us_aqi;

  const windSpeedMs = windSpeed ? (windSpeed / 3.6).toFixed(2) : null;

  const WeatherSvgComponent = getWeatherSvg(weatherCode, isDay);

  const getWeatherDescription = (weatherCode) => {
    if (weatherCode === 0) return "Clear sky";
    if (weatherCode >= 1 && weatherCode <= 3) return "Partly cloudy";
    if (weatherCode >= 45 && weatherCode <= 48) return "Fog";
    if (weatherCode >= 51 && weatherCode <= 57) return "Drizzle";
    if (weatherCode >= 61 && weatherCode <= 67) return "Rain";
    if (weatherCode >= 71 && weatherCode <= 77) return "Snow";
    if (weatherCode >= 80 && weatherCode <= 82) return "Rain showers";
    if (weatherCode >= 85 && weatherCode <= 86) return "Snow showers";
    if (weatherCode >= 95 && weatherCode <= 99) return "Thunderstorm";
    return "Cloudy";
  };

  const isPropertySelected = (property) => {
    return uiType === "default" || selectedProperties.includes(property);
  };

  const WeatherPropertiesCards = ({ uiTypeForProperties }) => {
    return (
      <>
        {isPropertySelected("feelsLike") && (
          <div
            className={`${
              uiTypeForProperties === "main-widget-portrait" ? "w-1/2" : "w-1/3"
            } flex justify-center items-center min-w-[110px] text-nowrap`}
          >
            <div className="flex items-center justify-start gap-3 text-[#222222] font-medium text-lg min-w-[110px]">
              <span>
                <FeelsLikeWSvg />
              </span>
              <span>
                {feelsLike !== null && feelsLike !== undefined
                  ? `${feelsLike}°c`
                  : "—"}
              </span>
            </div>
          </div>
        )}

        {isPropertySelected("cloud") && (
          <div
            className={`${
              uiTypeForProperties === "main-widget-portrait" ? "w-1/2" : "w-1/3"
            } flex justify-center items-center min-w-[110px] text-nowrap`}
          >
            <div className="flex items-center justify-start gap-3 text-[#222222] font-medium text-lg min-w-[110px]">
              <span>
                <CloudWSvg />
              </span>
              <span>
                {cloudCover !== null && cloudCover !== undefined
                  ? `${cloudCover}%`
                  : "—"}
              </span>
            </div>
          </div>
        )}

        {isPropertySelected("wind") && (
          <div
            className={`${
              uiTypeForProperties === "main-widget-portrait" ? "w-1/2" : "w-1/3"
            } flex justify-center items-center min-w-[110px] text-nowrap`}
          >
            <div className="flex items-center justify-start gap-3 text-[#222222] font-medium text-lg min-w-[110px]">
              <span>
                <WindWSvg />
              </span>
              <span>{windSpeedMs ? `${windSpeedMs} m/s` : "—"}</span>
            </div>
          </div>
        )}

        {isPropertySelected("humidity") && (
          <div
            className={`${
              uiTypeForProperties === "main-widget-portrait" ? "w-1/2" : "w-1/3"
            } flex justify-center items-center min-w-[110px] text-nowrap`}
          >
            <div className="flex items-center justify-start gap-3 text-[#222222] font-medium text-lg min-w-[110px]">
              <span>
                <HumidityWSvg />
              </span>
              <span>
                {humidity !== null && humidity !== undefined
                  ? `${humidity}%`
                  : "—"}
              </span>
            </div>
          </div>
        )}

        {isPropertySelected("pressure") && (
          <div
            className={`${
              uiTypeForProperties === "main-widget-portrait" ? "w-1/2" : "w-1/3"
            } flex justify-center items-center min-w-[110px] text-nowrap`}
          >
            <div className="flex items-center justify-start gap-3 text-[#222222] font-medium text-lg min-w-[110px]">
              <span>
                <GaugeHighWSvg />
              </span>
              <span>
                {pressure !== null && pressure !== undefined
                  ? `${pressure} hPa`
                  : "—"}
              </span>
            </div>
          </div>
        )}

        {isPropertySelected("dewPoint") && (
          <div
            className={`${
              uiTypeForProperties === "main-widget-portrait" ? "w-1/2" : "w-1/3"
            } flex justify-center items-center min-w-[110px] text-nowrap`}
          >
            <div className="flex items-center justify-start gap-3 text-[#222222] font-medium text-lg min-w-[110px]">
              <span>
                <DewPointWSvg />
              </span>
              <span>
                {dewPoint !== null && dewPoint !== undefined
                  ? `${dewPoint}°c`
                  : "—"}
              </span>
            </div>
          </div>
        )}
      </>
    );
  };

  useEffect(() => {
    const handleWeatherDataUpdated = (data) => {
      queryClient.invalidateQueries([QUERY_KEYS.TEMPLATE_BY_ID], {
        exact: false,
      });
    };
    socket.on("weatherDataRefreshed", handleWeatherDataUpdated);
    return () => {
      socket.off("weatherDataRefreshed", handleWeatherDataUpdated);
    };
  }, [listenRealTimeChange]);

  if (uiType === "default") {
    return (
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] py-3 px-[10px]">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-[#222222] text-sm 1540:text-sm font-semibold">
            Weather
          </h2>
          <Link className="text-[#227EEB] text-xs 1540:text-xs flex items-center gap-1 truncate">
            <LocationSvg />
            <span className="truncate">{placeName}</span>
          </Link>
        </div>

        <div className="grid grid-cols-2 mt-[25px]">
          <div className="">
            <WeatherSvgComponent />
            <h3 className="text-[#222222] text-[32px] 1540:text-[40px] font-semibold mt-[10px]">
              {temperature !== null && temperature !== undefined
                ? `${temperature}°c`
                : "—"}
            </h3>
            <p className="font-medium text-sm 1540:text-base text-[#222222]">
              {weatherCode !== null && weatherCode !== undefined
                ? getWeatherDescription(weatherCode)
                : "Cloudy"}
            </p>
          </div>
          {/* <Seperator className="h-[120px]" borderClassName="border-[#C1DBF9]" /> */}
          <div className="grid grid-cols-2 gap-x-4 border-l border-[#C1DBF9] pl-[10px]">
            <div className="text-[#939CA7] text-[10px] 1540:text-xs">
              Feel Like
            </div>
            <div className="text-[#222222] text-[10px] 1540:text-xs font-medium text-right">
              {feelsLike !== null && feelsLike !== undefined
                ? `${feelsLike}°c`
                : "—"}
            </div>

            <div className="text-[#939CA7] text-[10px] 1540:text-xs">Wind</div>
            <div className="text-[#222222] text-[10px] 1540:text-xs font-medium text-right">
              {windSpeedMs ? `${windSpeedMs} m/s` : "—"}
            </div>

            <div className="text-[#939CA7] text-[10px] 1540:text-xs">
              Pressure
            </div>
            <div className="text-[#222222] text-[10px] 1540:text-xs font-medium text-right">
              {pressure !== null && pressure !== undefined
                ? `${pressure} hPa`
                : "—"}
            </div>

            <div className="text-[#939CA7] text-[10px] 1540:text-xs">Cloud</div>
            <div className="text-[#222222] text-[10px] 1540:text-xs font-medium text-right">
              {cloudCover !== null && cloudCover !== undefined
                ? `${cloudCover}%`
                : "—"}
            </div>

            <div className="text-[#939CA7] text-[10px] 1540:text-xs">
              Humidity
            </div>
            <div className="text-[#222222] text-[10px] 1540:text-xs font-medium text-right">
              {humidity !== null && humidity !== undefined
                ? `${humidity}%`
                : "—"}
            </div>

            <div className="text-[#939CA7] text-[10px] 1540:text-xs">
              Dew Point
            </div>
            <div className="text-[#222222] text-[10px] 1540:text-xs font-medium text-right">
              {dewPoint !== null && dewPoint !== undefined
                ? `${dewPoint}°c`
                : "—"}
            </div>
          </div>
        </div>
      </div>
    );
  } else if (uiType === "header-weather")
    return (
      <div className="h-[35px] border border-[#C0DAF9] rounded-[18px] pl-[7px] pr-[12px] py-[7px] flex items-center gap-[5px]">
        <WeatherSvgComponent className="h-full" />
        <h3 className="text-[#222222] text-[16px] font-semibold">
          {temperature !== null && temperature !== undefined
            ? `${temperature}°c`
            : "—"}
        </h3>
      </div>
    );
  else if (
    uiType === "main-widget-landscape" ||
    uiType === "main-widget-portrait"
  ) {
    return (
      <div
        className={`${
          uiType === "main-widget-portrait"
            ? "py-[30px] px-[20px]"
            : "py-[20px] px-[40px]"
        } w-full h-full flex flex-col justify-between items-center`}
      >
        <div className="flex-shrink-0 w-full mb-3 line-clamp-2">
          <h3 className="text-center text-[#222222] text-[22px] font-medium">
            {placeName}
          </h3>
        </div>
        <div
          className={`flex-shrink-0 flex items-center justify-evenly w-full ${
            uiType === "main-widget-portrait" ? "gap-[10px]" : "gap-[10px]"
          } w-full`}
        >
          <div className="flex flex-col items-center">
            <WeatherSvgComponent className="w-[70px] h-[40px]" />
            <h3 className="text-[#222222] text-[40px] font-semibold mt-[10px] mb-1 leading-none m-0 p-0">
              {temperature !== null && temperature !== undefined
                ? `${temperature}°c`
                : "—"}
            </h3>
            <p className="font-medium text-base text-[#222222]">
              {weatherCode !== null && weatherCode !== undefined
                ? getWeatherDescription(weatherCode)
                : "--"}
            </p>
          </div>
          {(midElement?.type === "analog-clock" ||
            midElement?.type === "digital-clock") &&
          uiType === "main-widget-landscape" ? (
            <div className="flex-shrink-0 flex items-center justify-center">
              {midElement?.type === "analog-clock" ? (
                <AnalogClockContent
                  data={midElement.data}
                  locationClass={"text-[20px] max-w-[180px]"}
                  clockSize={"flex-grow"}
                />
              ) : midElement?.type === "digital-clock" ? (
                <DigitalClockContent
                  data={midElement.data}
                  locationClass={"text-[20px] max-w-[180px]"}
                />
              ) : null}
            </div>
          ) : uiType === "main-widget-landscape" &&
            midElement?.type === "sensor" &&
            midElement?.data?.selectedProperties
              ?.length ? 
              //   <WeatherPropertiesCards // <div className="max-w-[240px] flex flex-wrap flex-grow">
              //     uiTypeForProperties={"main-widget-portrait"}
              //   />
              // </div>
              null 
          : null}
          {isPropertySelected("aqi") && (
            <div className="flex items-center justify-center flex-col">
              <div
                className={`min-w-[85px] min-h-[85px] w-full ${
                  midElement && uiType === "main-widget-landscape"
                    ? "max-w-[90px]"
                    : uiType === "main-widget-landscape"
                    ? "max-w-[120px]"
                    : "max-w-[90px]"
                }`}
              >
                {aqi !== null && aqi !== undefined ? (
                  <AQIGauge value={aqi} />
                ) : (
                  "—"
                )}
              </div>
              <h3 className="text-[#222222] text-[18px] font-medium">AQI</h3>
            </div>
          )}
        </div>
        {(midElement?.type === "analog-clock" ||
          midElement?.type === "digital-clock") &&
        uiType === "main-widget-portrait" ? (
          <div className="flex-shrink-0 w-full flex items-center justify-center">
            {midElement?.type === "analog-clock" ? (
              <AnalogClockContent
                data={midElement.data}
                locationClass={"text-[20px] max-w-[280px]"}
                clockSize={"flex-grow"}
              />
            ) : midElement?.type === "digital-clock" ? (
              <DigitalClockContent
                data={midElement.data}
                locationClass={"text-[20px] max-w-[280px]"}
              />
            ) : null}
          </div>
        ) : null}
        {/* {isPropertySelected("feelsLike") ||
        isPropertySelected("wind") ||
        isPropertySelected("pressure") ||
        isPropertySelected("cloud") ||
        isPropertySelected("humidity") ||
        isPropertySelected("dewPoint") ||
        (midElement?.type === "sensor" &&
          uiType === "main-widget-portrait" &&
          midElement?.data?.selectedProperties?.length) ? (
          <div
            className={`flex justify-between items-center flex-wrap w-full ${
              midElement?.type === "sensor" &&
              uiType === "main-widget-portrait" &&
              midElement?.data?.selectedProperties?.length
                ? "gap-y-5"
                : "gap-y-2"
            }`}
          >
            {midElement?.type === "sensor" &&
            uiType === "main-widget-landscape" &&
            midElement?.data?.selectedProperties?.length ? null : (
              <WeatherPropertiesCards uiTypeForProperties={uiType} />
            )}
            {midElement?.type === "sensor" &&
            midElement?.data?.selectedProperties?.length ? (
              uiType === "main-widget-portrait" ? (
                <SensorCardForWidget
                  data={midElement?.data}
                  uiType={"weather-sensor-portrait"}
                />
              ) : (
                <SensorCardForWidget
                  data={midElement?.data}
                  uiType={"weather-sensor-landscape"}
                />
              )
            ) : null}
          </div>
        ) : (
          <div></div>
        )} */}

        {isPropertySelected("feelsLike") ||
        isPropertySelected("wind") ||
        isPropertySelected("pressure") ||
        isPropertySelected("cloud") ||
        isPropertySelected("humidity") ||
        isPropertySelected("dewPoint") ||
        (midElement?.type === "sensor" &&
          midElement?.data?.selectedProperties?.length) ? (
          <div
            className={`flex justify-between items-center flex-wrap w-full ${
              midElement?.type === "sensor" &&
              midElement?.data?.selectedProperties?.length
                ? uiType === "main-widget-portrait" ? "gap-y-4": "gap-y-1"
                : "gap-y-2"
            }`}
          >
            <WeatherPropertiesCards uiTypeForProperties={uiType} />
            {midElement?.type === "sensor" &&
            midElement?.data?.selectedProperties?.length ? (
              uiType === "main-widget-portrait" ? (
                <SensorCardForWidget
                  data={midElement?.data}
                  uiType={"weather-sensor-portrait"}
                />
              ) : (
                <SensorCardForWidget
                  data={midElement?.data}
                  uiType={"weather-sensor-landscape"}
                />
              )
            ) : null}
          </div>
        ) : (
          <div></div>
        )}
      </div>
    );
  }
  return null;
};

export default WeatherCard;
