function Header() {
  return (
    <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
      <h2 className="text-[#222222] font-bold">Dashboard</h2>
    </div>
  );
}

export default Header;
