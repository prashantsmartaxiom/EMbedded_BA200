import { WarningSvg } from "../../assets/svg";
import { SecondaryBtn } from "../../components";
import { CenterModal } from "../../components/Models";
import { useDeleteTemplate } from "../../api/queryHooks";
import toaster from "../../utils/toaster";

function DeleteTemplatePopup({
  isOpen,
  toggleModal,
  templateId,
  onSuccess,
}) {
  const { mutate: deleteTemplate, isLoading } = useDeleteTemplate({
    onSuccess: () => {
      toaster.success("Template deleted successfully");
      toggleModal(false);
      onSuccess?.();
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || "Failed to delete template");
    },
  });

  const handleDelete = () => {
    deleteTemplate(templateId);
  };

  if (!isOpen) return null;

  return (
    <CenterModal
      toggleModal={() => toggleModal(false)}
      className="max-w-[460px] w-full p-8 flex flex-col items-center gap-6"
    >
      <div>
        <WarningSvg className="text-[54px] text-[#FF1212]" />
      </div>
      <div className="text-center">
        <h3 className="text-base font-semibold">Are you sure?</h3>
        <p className="text-sm text-[#939CA7] mt-3">
          Do you really want to delete the template?
          <br />
          This process cannot be undone.
        </p>
      </div>

      <div className="flex items-center gap-[10px]">
        <SecondaryBtn
          onClick={() => toggleModal(false)}
          disabled={isLoading}
          className={
            "justify-center !bg-[#AAAAAA] !border-none !text-white min-w-20"
          }
        >
          CANCEL
        </SecondaryBtn>
        <SecondaryBtn
          onClick={handleDelete}
          disabled={isLoading}
          className={
            "justify-center !bg-[#FF1212] !border-none !text-white min-w-20"
          }
        >
          {isLoading ? "DELETING..." : "DELETE"}
        </SecondaryBtn>
      </div>
    </CenterModal>
  );
}

export default DeleteTemplatePopup;
