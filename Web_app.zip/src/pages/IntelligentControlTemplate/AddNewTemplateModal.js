import { useState } from "react";
import {
  BottomRightModal,
  BottomRightModalHeader,
  SecondaryBtnLink,
} from "../../components";
import { AddSvg } from "../../assets/svg";
import { NewTemplateForm } from "../../forms";

function AddNewTemplateModal() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = (value) => {
    setIsOpen(value);
  };

  const handleTemplateCreated = () => {
    // Close the modal when template creation is initiated
    setIsOpen(false);
  };

  return (
    <>
      <SecondaryBtnLink
        onClick={() => toggleModal(true)}
        className={"w-[135px] justify-center"}
        Icon={AddSvg}
      >
        NEW TEMPLATE
      </SecondaryBtnLink>
      {isOpen ? (
        <BottomRightModal
          toggleModal={toggleModal}
          className="h-full max-h-[calc(100vh-56px)] w-full max-w-[420px] flex flex-col"
        >
          <BottomRightModalHeader
            toggleModal={toggleModal}
            title="Add New Template"
          />
          <NewTemplateForm onTemplateCreated={handleTemplateCreated} />
        </BottomRightModal>
      ) : null}
    </>
  );
}

export default AddNewTemplateModal;
