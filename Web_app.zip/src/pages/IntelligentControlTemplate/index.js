import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useGetTemplates } from "../../api/queryHooks";
import { DataTable, PermissionDenied, PrimaryDropdown } from "../../components";
import { DeleteSvg, EditSvg, EyeSvg } from "../../assets/svg";
import Seperator from "../../components/Header/Seperator";
import { ROUTES } from "../../router";
import Header from "./Header";
import TemplatePreviewModal from "./TemplatePreviewModal";
import DeleteTemplatePopup from "./DeleteTemplatePopup";
import useUserStore from "../../store/useUserStore";

const SubHeader = ({ 
  limit, 
  onLimitChange, 
  selectedLayout, 
  onLayoutChange 
}) => {
  const layoutOptions = [
    { value: null, label: "All" }, 
    { value: "landscape", label: "Landscape" }, 
    { value: "portrait", label: "Portrait" }
  ];

  return (
    <div className="flex items-center justify-between mb-[15px]">
      <h2 className="text-[#222222] text-[14px] font-semibold">
        Manage Templates
      </h2>
      <div className="flex items-center gap-[5px]">
        <div className="flex items-center gap-[20px]">
          <div className="flex items-center gap-[10px]">
            <span className="text-[#222222] text-[12px]">Show:</span>
            <PrimaryDropdown
              className="w-[60px]"
              value={limit}
              onValueChange={onLimitChange}
              options={[
                { value: "10", label: "10" },
                { value: "20", label: "20" },
                { value: "25", label: "25" },
                { value: "50", label: "50" },
              ]}
            />
            <span className="text-[12px] text-[#7A838E]">Entries</span>
          </div>
          <Seperator className="h-[25px]" />
          <div className="flex items-center gap-[10px]">
            <span className="text-[#222222] text-[12px]">Filter:</span>
            <PrimaryDropdown
              className="w-[150px]"
              options={layoutOptions}
              value={selectedLayout}
              onValueChange={onLayoutChange}
              placeholder="Layout Type"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

function IntelligentControlTemplate() {
  const userPermissions = useUserStore((state) => state.permissions);

  const navigate = useNavigate();
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState("10");
  const [search, setSearch] = useState("");
  const [selectedLayout, setSelectedLayout] = useState("");
  const [previewModal, setPreviewModal] = useState({
    isOpen: false,
    template: null,
  });
  const [deleteModal, setDeleteModal] = useState({
    isOpen: false,
    templateId: null,
  });

  const { data: templatesData, isLoading } = useGetTemplates({
    page,
    limit: Number(limit),
    search,
    layout: selectedLayout || undefined,
  });

  const handleLayoutChange = (layout) => {
    setSelectedLayout(layout);
    setPage(1); // Reset to first page when filter changes
  };

  const handlePreview = (template) => {
    setPreviewModal({
      isOpen: true,
      template: template,
    });
  };

  const togglePreviewModal = (value) => {
    setPreviewModal({
      isOpen: value,
      template: value ? previewModal.template : null,
    });
  };

  const handleEdit = (template) => {
    navigate(
      ROUTES.GET_EDIT_INTELLIGENT_CONTROLS_TEMPLATE(template._id || template.id)
    );
  };

  const handleDelete = (templateId) => {
    setDeleteModal({
      isOpen: true,
      templateId: templateId,
    });
  };

  const toggleDeleteModal = (value) => {
    setDeleteModal({
      isOpen: value,
      templateId: value ? deleteModal.templateId : null,
    });
  };

  const onDeleteSuccess = () => {
    // Optionally refetch templates or handle any other success logic
    // The query will be invalidated automatically by the useDeleteTemplate hook
  };

  const columns = [
    { key: "sno", label: "S. No." },
    { key: "templateName", label: "Template Name" },
    { key: "templateLayout", label: "Template Layout" },
    { key: "status", label: "Status" },
    {
      key: "action",
      label: "Action",
      render: (_, row) => (
        <div className="flex gap-6">
          {row?.status === "Active" ? (
            userPermissions?.INTELLIGENT_CONTROL?.template_management
              ?.readOnly ? (
              <button
                className="text-[#222222] fill-[#222222] hover:underline flex items-center"
                onClick={() => handlePreview(row.originalData)}
              >
                <EyeSvg className="inline mr-1" />
                Preview
              </button>
            ) : null
          ) : null}
          {userPermissions?.INTELLIGENT_CONTROL?.template_management
            ?.addModify ? (
            <button
              className="text-[#222222] fill-[#222222] hover:underline flex items-center"
              onClick={() => handleEdit(row.originalData)}
            >
              <EditSvg className="inline mr-1 mt-px" />
              Edit
            </button>
          ) : null}
          {row?.status === "Active" ? (
            userPermissions?.INTELLIGENT_CONTROL?.template_management
              ?.delete ? (
              <button
                className="text-red-500 fill-red-500 hover:underline flex items-center"
                onClick={() => handleDelete(row.originalData._id)}
              >
                <DeleteSvg className="inline mr-1 mt-px" />
                Delete
              </button>
            ) : null
          ) : null}
        </div>
      ),
    },
  ];

  const formattedData =
    templatesData?.data?.data?.map((item, index) => ({
      sno: String((page - 1) * Number(limit) + index + 1).padStart(2, "0"),
      templateName: item?.name || "N/A",
      templateLayout: item?.layout || "N/A",
      status: item?.status || "N/A",
      originalData: item, // Store original data for preview
    })) || [];

  if (!userPermissions?.INTELLIGENT_CONTROL?.template_management?.readOnly)
    return <PermissionDenied />;

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header
          onSearchChange={(value) => {
            setSearch(value);
            setPage(1);
          }}
        />
        <SubHeader 
          limit={limit} 
          onLimitChange={setLimit}
          selectedLayout={selectedLayout}
          onLayoutChange={handleLayoutChange}
        />
        <DataTable
          columns={columns}
          data={formattedData}
          totalItems={templatesData?.data?.total || 0}
          currentPage={page}
          onPageChange={setPage}
          isLoading={isLoading}
          rowsPerPage={Number(limit)}
        />
      </div>

      <TemplatePreviewModal
        isOpen={previewModal.isOpen}
        toggleModal={togglePreviewModal}
        template={previewModal.template}
      />

      <DeleteTemplatePopup
        isOpen={deleteModal.isOpen}
        toggleModal={toggleDeleteModal}
        templateId={deleteModal.templateId}
        onSuccess={onDeleteSuccess}
      />
    </div>
  );
}

export default IntelligentControlTemplate;
