import { CenterModal, CenterModalHeader } from "../../components";
import TemplateView from "../ControlSystem/Views/TemplateView";

function TemplatePreviewModal({ isOpen, toggleModal, template }) {
  if (!isOpen || !template) return null;

  return (
    <CenterModal
      toggleModal={toggleModal}
      className="max-w-6xl w-full h-[98vh]"
    >
      <CenterModalHeader
        className="p-5 flex items-center justify-between pb-5 border-b border-[#CCCCCC]"
        title={`Template Preview - ${template?.name}`}
        toggleModal={toggleModal}
      />

      <div className="max-h-[calc(100vh-80px)] overflow-auto">
        <TemplateView selectedItem={template} />
      </div>
    </CenterModal>
  );
}

export default TemplatePreviewModal;
