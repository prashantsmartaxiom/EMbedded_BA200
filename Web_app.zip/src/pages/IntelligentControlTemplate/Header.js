import { SearchInput } from "../../components";
import useUserStore from "../../store/useUserStore";
import AddNewTemplateModal from "./AddNewTemplateModal";

function Header({ onSearchChange }) {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
      <h2 className="text-[#222222] font-bold">Intelligent Controls</h2>
      <div className="flex items-center gap-[15px]">
        <SearchInput
          className="w-[260px]"
          placeholder="Search by template name, group…"
          onChange={(e) => onSearchChange(e.target.value)}
        />
        {userPermissions?.INTELLIGENT_CONTROL?.template_management
          ?.addModify ? (
          <AddNewTemplateModal />
        ) : null}
      </div>
    </div>
  );
}

export default Header;
