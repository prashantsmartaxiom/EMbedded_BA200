import { useState, useEffect } from "react";
import { Checkbox } from "../../components";
import { DownArrowSvg, UpArrowSvg } from "../../assets/svg";

const HierarchicalCampusSelector = ({
  data,
  selectedPermissions,
  onPermissionChange,
  tabType,
  allDisabled,
}) => {
  const [selectedCampuses, setSelectedCampuses] = useState([]);
  const [selectedBuildings, setSelectedBuildings] = useState([]);
  const [selectedFloors, setSelectedFloors] = useState([]);
  const [selectedAccordian, setSelectedAccordian] = useState(null);

  // Extract data by type
  const campusesData = data.find((item) => item.id === "campuses")?.data || [];
  const buildingsData = data.find((item) => item.id === "buildings")?.data || [];
  const floorsData = data.find((item) => item.id === "floors")?.data || [];
  const zonesData = data.find((item) => item.id === "zones")?.data || [];

  // Initialize selected accordion to campuses only once when component mounts
  useEffect(() => {
    const campusesSection = data.find((item) => item.id === "campuses");
    if (campusesSection) {
      setSelectedAccordian(campusesSection);
    }
  }, [data]);

  // Update selected items based on permissions
  useEffect(() => {
    const campusPermissions = selectedPermissions[tabType]?.campuses || [];
    const buildingPermissions = selectedPermissions[tabType]?.buildings || [];
    const floorPermissions = selectedPermissions[tabType]?.floors || [];

    setSelectedCampuses(campusPermissions);
    setSelectedBuildings(buildingPermissions);
    setSelectedFloors(floorPermissions);
  }, [selectedPermissions, tabType]);

  // Helper function to check if all sub-items are selected for a section
  const isAccordianFullySelected = (accordianId) => {
    const accordianPermissions = selectedPermissions[tabType]?.[accordianId] || [];
    
    if (accordianId === "campuses") {
      return campusesData.length > 0 && campusesData.every((item) => accordianPermissions.includes(item.id));
    } else if (accordianId === "buildings") {
      const availableBuildings = buildingsData.filter(building => 
        selectedCampuses.includes(building.campusId)
      );
      return availableBuildings.length > 0 && availableBuildings.every((item) => accordianPermissions.includes(item.id));
    } else if (accordianId === "floors") {
      const availableFloors = floorsData.filter(floor => 
        selectedBuildings.includes(floor.buildingId)
      );
      return availableFloors.length > 0 && availableFloors.every((item) => accordianPermissions.includes(item.id));
    } else if (accordianId === "zones") {
      const availableZones = zonesData.filter(zone => 
        selectedFloors.includes(zone.floorId)
      );
      return availableZones.length > 0 && availableZones.every((item) => accordianPermissions.includes(item.id));
    }
    return false;
  };

  // Helper function to check if accordion is partially selected
  const isAccordianPartiallySelected = (accordianId) => {
    const accordianPermissions = selectedPermissions[tabType]?.[accordianId] || [];
    return accordianPermissions.length > 0 && !isAccordianFullySelected(accordianId);
  };

  // Handle accordion header checkbox change
  const handleAccordianCheckboxChange = (accordianId, checked) => {
    // If the accordion is partially selected (indeterminate), treat click as uncheck all
    const isPartiallySelected = isAccordianPartiallySelected(accordianId);
    const shouldCheckAll = checked && !isPartiallySelected;

    if (accordianId === "campuses") {
      if (shouldCheckAll) {
        const allCampusIds = campusesData.map((item) => item.id);
        onPermissionChange(tabType, "campuses", allCampusIds);
      } else {
        // Clear all dependent selections
        onPermissionChange(tabType, "campuses", []);
        onPermissionChange(tabType, "buildings", []);
        onPermissionChange(tabType, "floors", []);
        onPermissionChange(tabType, "zones", []);
      }
    } else if (accordianId === "buildings") {
      const availableBuildings = buildingsData.filter(building => 
        selectedCampuses.includes(building.campusId)
      );
      if (shouldCheckAll) {
        const allBuildingIds = availableBuildings.map((item) => item.id);
        onPermissionChange(tabType, "buildings", allBuildingIds);
      } else {
        onPermissionChange(tabType, "buildings", []);
        onPermissionChange(tabType, "floors", []);
        onPermissionChange(tabType, "zones", []);
      }
    } else if (accordianId === "floors") {
      const availableFloors = floorsData.filter(floor => 
        selectedBuildings.includes(floor.buildingId)
      );
      if (shouldCheckAll) {
        const allFloorIds = availableFloors.map((item) => item.id);
        onPermissionChange(tabType, "floors", allFloorIds);
      } else {
        onPermissionChange(tabType, "floors", []);
        onPermissionChange(tabType, "zones", []);
      }
    } else if (accordianId === "zones") {
      const availableZones = zonesData.filter(zone => 
        selectedFloors.includes(zone.floorId)
      );
      if (shouldCheckAll) {
        const allZoneIds = availableZones.map((item) => item.id);
        onPermissionChange(tabType, "zones", allZoneIds);
      } else {
        onPermissionChange(tabType, "zones", []);
      }
    }
  };

  // Handle sub-item checkbox change with cascading logic
  const handleSubItemCheckboxChange = (accordianId, subItemId, checked) => {
    const currentPermissions = selectedPermissions[tabType]?.[accordianId] || [];
    let newPermissions;

    if (checked) {
      newPermissions = [...currentPermissions, subItemId];
    } else {
      newPermissions = currentPermissions.filter((id) => id !== subItemId);
      
      // Handle cascading deselection
      if (accordianId === "campuses") {
        // Remove related buildings, floors, and zones
        const relatedBuildings = buildingsData.filter(building => 
          building.campusId === subItemId
        ).map(building => building.id);
        
        const relatedFloors = floorsData.filter(floor => 
          relatedBuildings.includes(floor.buildingId)
        ).map(floor => floor.id);
        
        const relatedZones = zonesData.filter(zone => 
          relatedFloors.includes(zone.floorId)
        ).map(zone => zone.id);

        // Update dependent selections
        const currentBuildings = selectedPermissions[tabType]?.buildings || [];
        const newBuildings = currentBuildings.filter(id => !relatedBuildings.includes(id));
        onPermissionChange(tabType, "buildings", newBuildings);

        const currentFloors = selectedPermissions[tabType]?.floors || [];
        const newFloors = currentFloors.filter(id => !relatedFloors.includes(id));
        onPermissionChange(tabType, "floors", newFloors);

        const currentZones = selectedPermissions[tabType]?.zones || [];
        const newZones = currentZones.filter(id => !relatedZones.includes(id));
        onPermissionChange(tabType, "zones", newZones);
        
      } else if (accordianId === "buildings") {
        // Remove related floors and zones
        const relatedFloors = floorsData.filter(floor => 
          floor.buildingId === subItemId
        ).map(floor => floor.id);
        
        const relatedZones = zonesData.filter(zone => 
          relatedFloors.includes(zone.floorId)
        ).map(zone => zone.id);

        const currentFloors = selectedPermissions[tabType]?.floors || [];
        const newFloors = currentFloors.filter(id => !relatedFloors.includes(id));
        onPermissionChange(tabType, "floors", newFloors);

        const currentZones = selectedPermissions[tabType]?.zones || [];
        const newZones = currentZones.filter(id => !relatedZones.includes(id));
        onPermissionChange(tabType, "zones", newZones);
        
      } else if (accordianId === "floors") {
        // Remove related zones
        const relatedZones = zonesData.filter(zone => 
          zone.floorId === subItemId
        ).map(zone => zone.id);

        const currentZones = selectedPermissions[tabType]?.zones || [];
        const newZones = currentZones.filter(id => !relatedZones.includes(id));
        onPermissionChange(tabType, "zones", newZones);
      }
    }

    onPermissionChange(tabType, accordianId, newPermissions);
  };

  // Get available items for each section based on hierarchy
  const getAvailableItems = (sectionId) => {
    if (sectionId === "campuses") {
      return campusesData;
    } else if (sectionId === "buildings") {
      return buildingsData.filter(building => 
        selectedCampuses.includes(building.campusId)
      );
    } else if (sectionId === "floors") {
      return floorsData.filter(floor => 
        selectedBuildings.includes(floor.buildingId)
      );
    } else if (sectionId === "zones") {
      return zonesData.filter(zone => 
        selectedFloors.includes(zone.floorId)
      );
    }
    return [];
  };

  // Check if section should be visible
  const isSectionVisible = (sectionId) => {
    if (sectionId === "campuses") return true;
    if (sectionId === "buildings") return selectedCampuses.length > 0;
    if (sectionId === "floors") return selectedBuildings.length > 0;
    if (sectionId === "zones") return selectedFloors.length > 0;
    return false;
  };

  // Render each accordion section
  const renderAccordionSection = (item) => {
    const isOpen = selectedAccordian?.id === item.id;
    const isFullySelected = isAccordianFullySelected(item.id);
    const isPartiallySelected = isAccordianPartiallySelected(item.id);
    const availableItems = getAvailableItems(item.id);
    const isVisible = isSectionVisible(item.id);

    if (!isVisible) return null;

    return (
      <div
        key={item.id}
        className="border border-[#CCCCCC] rounded-lg my-[15px]"
      >
        <div className="bg-[#EEEEEE] py-[10px] px-[15px] rounded-t-lg">
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => setSelectedAccordian(isOpen ? null : item)}>
              {isOpen ? (
                <UpArrowSvg className="w-[10px] h-[10px] text-[#222222]" />
              ) : (
                <DownArrowSvg className="w-[10px] h-[10px] text-[#222222]" />
              )}
            </button>
            <span>
              <Checkbox
                checked={isFullySelected}
                indeterminate={isPartiallySelected}
                onCheckedChange={(checked) =>
                  handleAccordianCheckboxChange(item.id, checked)
                }
                disabled={allDisabled}
              />
            </span>
            <span className="text-xs text-[#222222]">
              {item.name?.toUpperCase()}
            </span>
          </div>
        </div>
        {isOpen && (
          <div className="p-3 grid grid-cols-6 gap-3">
            {availableItems.map((subItem) => {
              const isSubItemSelected = (
                selectedPermissions[tabType]?.[item.id] || []
              ).includes(subItem.id);

              return (
                <div key={subItem.id} className="flex items-center gap-2">
                  <span>
                    <Checkbox
                      checked={isSubItemSelected}
                      onCheckedChange={(checked) =>
                        handleSubItemCheckboxChange(
                          item.id,
                          subItem.id,
                          checked
                        )
                      }
                      disabled={allDisabled}
                    />
                  </span>
                  <span className="text-xs text-[#222222] truncate">
                    {subItem.name}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  };

  return data.map((item) => renderAccordionSection(item));
};

export default HierarchicalCampusSelector;