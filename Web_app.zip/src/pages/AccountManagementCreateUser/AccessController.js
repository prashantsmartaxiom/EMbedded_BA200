import { useState, useEffect } from "react";
import { useGetRoleTabControlData } from "../../api/queryHooks";
import { Checkbox, SpinnerV1 } from "../../components";
import { DownArrowSvg, UpArrowSvg } from "../../assets/svg";
import HierarchicalCampusSelector from "./HierarchicalCampusSelector";
import LogsMonitoringSelector from "./LogsMonitoringSelector";

const TabBtn = ({ isActive = false, title, ...props }) => {
  return (
    <button
      type="button"
      className={`h-[50px] rounded-t-lg px-[15px] py-[8px] flex items-center gap-[20px] ${
        isActive ? "border-b border-[#227EEB]" : "bg-[#ffffff]"
      }`}
      {...props}
    >
      <span
        className={`text-sm ${
          isActive ? "text-[#227EEB]" : "text-[#222222]"
        } font-semibold`}
      >
        {title}
      </span>
    </button>
  );
};

const Tabs = ({ selectedTab, roleTabsData, onClickTab }) => {
  return (
    <div className="flex items-center justify-between border-b-2 border-[#DDDDDD]">
      <div className="flex items-center">
        {roleTabsData.map((tab) => (
          <TabBtn
            key={tab.id}
            isActive={selectedTab?.id === tab.id}
            title={tab.tab_name}
            onClick={() => onClickTab?.(tab)}
          />
        ))}
      </div>
    </div>
  );
};

const Accordians = ({
  data,
  selectedPermissions,
  onPermissionChange,
  tabType,
  allDisabled,
}) => {
  const [selectedAccordian, setSelectedAccordian] = useState(data?.[0] || null);

  const toggleAccordian = (accordian) => {
    setSelectedAccordian(
      selectedAccordian?.id === accordian.id ? null : accordian
    );
  };

  // Helper function to check if all sub-items are selected
  const isAccordianFullySelected = (accordianId) => {
    const accordianData = data.find((item) => item.id === accordianId);
    if (!accordianData || !accordianData.data.length) return false;

    const accordianPermissions =
      selectedPermissions[tabType]?.[accordianId] || [];
    return accordianData.data.every((subItem) =>
      accordianPermissions.includes(subItem.id)
    );
  };

  // Helper function to check if accordion is partially selected
  const isAccordianPartiallySelected = (accordianId) => {
    const accordianPermissions =
      selectedPermissions[tabType]?.[accordianId] || [];
    return (
      accordianPermissions.length > 0 && !isAccordianFullySelected(accordianId)
    );
  };

  // Handle accordion header checkbox change
  const handleAccordianCheckboxChange = (accordianId, checked) => {
    const accordianData = data.find((item) => item.id === accordianId);
    if (!accordianData) return;

    if (checked) {
      // Select all sub-items
      const allSubItemIds = accordianData.data.map((subItem) => subItem.id);
      onPermissionChange(tabType, accordianId, allSubItemIds);
    } else {
      // Deselect all sub-items
      onPermissionChange(tabType, accordianId, []);
    }
  };

  // Handle sub-item checkbox change
  const handleSubItemCheckboxChange = (accordianId, subItemId, checked) => {
    const currentPermissions =
      selectedPermissions[tabType]?.[accordianId] || [];
    let newPermissions;

    if (checked) {
      newPermissions = [...currentPermissions, subItemId];
    } else {
      newPermissions = currentPermissions.filter((id) => id !== subItemId);
    }

    onPermissionChange(tabType, accordianId, newPermissions);
  };

  return data.map((item) => {
    const isOpen = selectedAccordian?.id === item.id;
    const isFullySelected = isAccordianFullySelected(item.id);
    const isPartiallySelected = isAccordianPartiallySelected(item.id);

    return (
      <div
        key={item.id}
        className="border border-[#CCCCCC] rounded-lg my-[15px]"
      >
        <div className="bg-[#EEEEEE] py-[10px] px-[15px] rounded-t-lg">
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => toggleAccordian(item)}>
              {isOpen ? (
                <UpArrowSvg className="w-[10px] h-[10px] text-[#222222]" />
              ) : (
                <DownArrowSvg className="w-[10px] h-[10px] text-[#222222]" />
              )}
            </button>
            <span>
              <Checkbox
                checked={isFullySelected}
                indeterminate={isPartiallySelected}
                onCheckedChange={(checked) =>
                  handleAccordianCheckboxChange(item.id, checked)
                }
                disabled={allDisabled}
              />
            </span>
            <span className="text-xs text-[#222222]">
              {item.name?.toUpperCase()}
            </span>
          </div>
        </div>
        {isOpen &&
          (item?.data?.length ? (
            <div className="p-3 grid grid-cols-6 gap-3">
              {item.data.map((subItem) => {
                const isSubItemSelected = (
                  selectedPermissions[tabType]?.[item.id] || []
                ).includes(subItem.id);

                return (
                  <div key={subItem.id} className="flex items-center gap-2">
                    <span>
                      <Checkbox
                        checked={isSubItemSelected}
                        onCheckedChange={(checked) =>
                          handleSubItemCheckboxChange(
                            item.id,
                            subItem.id,
                            checked
                          )
                        }
                        disabled={allDisabled}
                      />
                    </span>
                    <span className="text-xs text-[#222222] truncate">
                      {subItem.name}
                    </span>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-5 text-center text-sm">No data available</div>
          ))}
      </div>
    );
  });
};

function AccessController({
  role_id,
  onPermissionsChange,
  initialSelection = {},
  initialRoleId = null,
  userId = null,
  is_super_user,
}) {
  const [selectedTab, setSelectedTab] = useState(null);
  const [selectedPermissions, setSelectedPermissions] = useState({});

  const {
    data: roleTabsData,
    isLoading,
    isError,
  } = useGetRoleTabControlData(role_id, userId);

  // Set initial tab when data loads
  useEffect(() => {
    if (roleTabsData && roleTabsData.length > 0 && !selectedTab) {
      setSelectedTab(roleTabsData[0]);
    }
  }, [roleTabsData, selectedTab]);

  // Update parent component whenever permissions change
  useEffect(() => {
    if (onPermissionsChange) {
      onPermissionsChange(selectedPermissions);
    }
  }, [selectedPermissions, onPermissionsChange]);

  useEffect(() => {
    if (!role_id || !roleTabsData) return;

    // if (initialRoleId && role_id === initialRoleId) {
    //   setSelectedPermissions(initialSelection);
    //   return;
    // }

    const selectedData = {};
    for (let tabData of roleTabsData) {
      selectedData[tabData.id] = {};

      // Handle logs monitoring differently (boolean values instead of arrays)
      if (tabData.id === "logsMonitoring") {
        for (let accordian of tabData?.data || []) {
          selectedData[tabData.id][accordian.id] =
            initialRoleId && role_id === initialRoleId
              ? accordian.data
              : ["true"]; // Default to false for boolean permissions
        }
      } else {
        // Handle regular accordions with sub-items
        for (let accordian of tabData?.data || []) {
          selectedData[tabData.id][accordian.id] = [];
          for (let subItem of accordian?.data || []) {
            if (initialRoleId && role_id === initialRoleId) {
              if (subItem?.isChecked)
                selectedData[tabData.id][accordian.id].push(subItem.id);
            } else {
              // By default, select all permissions
              selectedData[tabData.id][accordian.id].push(subItem.id);
            }
          }
        }
      }
    }
    setSelectedPermissions(selectedData);
  }, [role_id, roleTabsData]);

  const handlePermissionChange = (tabType, accordianId, permissionIds) => {
    setSelectedPermissions((prev) => ({
      ...prev,
      [tabType]: {
        ...prev[tabType],
        [accordianId]: permissionIds,
      },
    }));
  };

  const onClickTab = (tab) => {
    setSelectedTab(tab);
  };

  if (!role_id || isError || is_super_user) return null;
  if (isLoading)
    return (
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mt-5">
        <SpinnerV1 />
      </div>
    );

  return (
    <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] px-5 pb-5 mt-5">
      <Tabs
        selectedTab={selectedTab}
        roleTabsData={roleTabsData || []}
        onClickTab={onClickTab}
      />
      {selectedTab ? (
        selectedTab.id === "campusManagement" ? (
          <HierarchicalCampusSelector
            data={selectedTab.data || []}
            selectedPermissions={selectedPermissions}
            onPermissionChange={handlePermissionChange}
            tabType={selectedTab.id}
            allDisabled={is_super_user}
          />
        ) : selectedTab.id === "logsMonitoring" ? (
          <LogsMonitoringSelector
            data={selectedTab.data || []}
            selectedPermissions={selectedPermissions}
            onPermissionChange={handlePermissionChange}
            tabType={selectedTab.id}
            allDisabled={is_super_user}
          />
        ) : (
          <Accordians
            data={selectedTab.data || []}
            selectedPermissions={selectedPermissions}
            onPermissionChange={handlePermissionChange}
            tabType={selectedTab.id}
            allDisabled={is_super_user}
          />
        )
      ) : null}
    </div>
  );
}

export default AccessController;
