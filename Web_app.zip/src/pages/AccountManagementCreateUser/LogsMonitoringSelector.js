import { useState, useEffect } from "react";
import { Checkbox } from "../../components";

const LogsMonitoringSelector = ({
  data,
  selectedPermissions,
  onPermissionChange,
  tabType,
  allDisabled,
}) => {
  // Handle checkbox change for log types (boolean values)
  const handleLogTypeChange = (logTypeId, checked) => {
    onPermissionChange(tabType, logTypeId, checked);
  };

  return (
    <div className="p-4">
      <div className="grid grid-cols-4 gap-4">
        {data.map((logType) => {
          const isSelected = (selectedPermissions[tabType]?.[logType.id]?.length || selectedPermissions[tabType]?.[logType.id] === true) ? true : false;
          // const isSelected = selectedPermissions[tabType]?.[logType.id] === true || false;
          
          return (
            <div key={logType.id} className="flex items-center gap-3">
              <Checkbox
                checked={isSelected}
                onCheckedChange={(checked) =>
                  handleLogTypeChange(logType.id, checked)
                }
                disabled={allDisabled}
              />
              <span className="text-sm text-[#222222] font-medium">
                {logType.name.charAt(0).toUpperCase() + logType.name.slice(1).replace?.(/([A-Z])/g, ' $1')}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default LogsMonitoringSelector;