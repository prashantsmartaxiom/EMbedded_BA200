import { PermissionDenied } from "../../components";
import useUserStore from "../../store/useUserStore";
import AccountManagementCreateUserForm from "./AccountManagementCreateUserForm";

function AccountManagementCreateUser() {
  const userPermissions = useUserStore((state) => state.permissions);

  if (!userPermissions?.USER_MANAGEMENT?.user_accounts?.addModify) {
    return <PermissionDenied />;
  }

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <AccountManagementCreateUserForm />
    </div>
  );
}
export default AccountManagementCreateUser;
