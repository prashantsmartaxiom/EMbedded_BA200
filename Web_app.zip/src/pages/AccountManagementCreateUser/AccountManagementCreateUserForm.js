import { useFormik } from "formik";
import * as Yup from "yup";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ROUTES } from "../../router";
import { BackspaceSvg } from "../../assets/svg";
import {
  PrimaryBtn2,
  SecondaryBtn,
  PrimaryInput,
  PrimaryFileInput,
  PrimaryDropdown,
  PasswordInput,
} from "../../components";
import { useCreateUser, useGetRolesOptions } from "../../api/queryHooks";
import toaster from "../../utils/toaster";
import {
  MAX_FILE_SIZE_TO_UPLOAD_IMAGE,
  REGEX,
  UNUSED_API_VARIABLES,
  VALID_IMAGE_FILE_TYPES,
} from "../../consts";
import AccessController from "./AccessController";
import CONFIG from "../../config";

const MAX_FILE_SIZE = MAX_FILE_SIZE_TO_UPLOAD_IMAGE; // 2MB
const VALID_FILE_TYPES = VALID_IMAGE_FILE_TYPES;

// Helper function to convert file to base64
const fileToBase64 = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
};

const validationSchema = Yup.object().shape({
  organization: Yup.string().required("Organisation is required"),
  fullName: Yup.string()
    .required("Full name is required")
    .min(2, "Atleast two characters required"),
  email: Yup.string()
    .matches(REGEX.email, "Invalid email address")
    .required("Email is required"),
  password: Yup.string()
    .min(8, "Password must be at least 8 characters")
    .matches(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
      "Password must contain at least one lowercase letter, one uppercase letter, and one number"
    )
    .required("Password is required"),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref("password"), null], "Passwords must match")
    .required("Confirm password is required"),
  profilePicture: Yup.mixed()
    .nullable()
    .test("fileSize", "File too large (max 2MB)", (value) => {
      if (!value) return true;
      return value.size <= MAX_FILE_SIZE;
    })
    .test("fileType", "Unsupported file type (only JPG, PNG, GIF)", (value) => {
      if (!value) return true;
      return VALID_FILE_TYPES.includes(value.type);
    }),
  role: Yup.string().required("Role assignment is required"),
});

function AccountManagementCreateUserForm() {
  const navigate = useNavigate();
  const [allowedResources, setAllowedResources] = useState({});

  const { data: rolesdata, isLoading: isLoadingRoleOptions } =
    useGetRolesOptions({ check: 1 });

  const createUserMutation = useCreateUser({
    onSuccess: (data) => {
      toaster.success("User created successfully!");
      navigate(ROUTES.MANAGE_USER);
    },
    onError: (error) => {
      toaster.error(
        error?.response?.data?.message ||
          "Error creating user. Please try again."
      );
    },
  });

  const formik = useFormik({
    initialValues: {
      organization: UNUSED_API_VARIABLES.ORGANIZATION,
      fullName: "",
      email: "",
      password: "",
      confirmPassword: "",
      profilePicture: null,
      role: "",
      location: "Mumbai, Maharashtra, India",
    },
    validationSchema: validationSchema,
    onSubmit: async (values, { setSubmitting }) => {
      try {
        let profileImageBase64 = "";

        // Convert profile picture to base64 if uploaded
        if (values.profilePicture) {
          profileImageBase64 = await fileToBase64(values.profilePicture);
        }

        const payload = {
          fullName: values.fullName,
          organization: values.organization,
          email: values.email,
          password: values.password,
          confirmPassword: values.confirmPassword,
          role: values.role,
          location: values.location,
          profileImage: profileImageBase64,
          allowedResources: {
            ...allowedResources,
            logsMonitoring: {
              eventLogs:
                allowedResources?.["logsMonitoring"]?.["eventLogs"] === true ||
                allowedResources?.["logsMonitoring"]?.["eventLogs"]?.length
                  ? ["true"]
                  : [],
              mqttLogs:
                allowedResources?.["logsMonitoring"]?.["mqttLogs"] === true ||
                allowedResources?.["logsMonitoring"]?.["mqttLogs"]?.length
                  ? ["true"]
                  : [],
            },
          },
        };

        createUserMutation.mutate(payload);
      } catch (error) {
        console.error(error);
        toaster.error("Something went wrong.");
      } finally {
        setSubmitting(false);
      }
    },
  });

  // Handle permissions change from AccessController
  const handlePermissionsChange = (permissions) => {
    setAllowedResources(permissions);
  };

  // Reset permissions when role changes
  const handleRoleChange = (value) => {
    formik.setFieldValue("role", value);
    setAllowedResources({}); // Reset permissions when role changes
  };

  return (
    <form onSubmit={formik.handleSubmit}>
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
          <Link to={-1} className="flex items-center gap-[10px]">
            <BackspaceSvg />
            <h2 className="text-[#222222] font-bold">Add New User</h2>
          </Link>
          <div className="flex items-center gap-[15px]">
            <SecondaryBtn
              className={"w-[80px] justify-center"}
              onClick={() => formik.resetForm()}
              type="button"
            >
              RESET
            </SecondaryBtn>
            <PrimaryBtn2
              type="submit"
              disabled={formik.isSubmitting || createUserMutation.isLoading}
              className={"w-[80px] justify-center"}
            >
              {formik.isSubmitting || createUserMutation.isLoading
                ? "CREATING..."
                : "CREATE"}
            </PrimaryBtn2>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-x-10 gap-y-6 pb-5 mb-5 border-b">
          {/* Organisation */}
          <div className="row-start-1 col-start-1">
            <div className="flex justify-between items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Organisation:
              </h4>
              <PrimaryInput
                placeholder="Organisation"
                className="w-full"
                name="organization"
                value={formik.values.organization}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                disabled
              />
            </div>
            {formik.touched.organization && formik.errors.organization ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[140px]">
                {formik.errors.organization}
              </div>
            ) : null}
          </div>

          {/* Profile Picture */}
          <div className="row-start-1 col-start-2 row-span-3">
            <PrimaryFileInput
              type="image"
              label="Profile Picture"
              description="Please upload an logo upto 2 MB Accepted format: JPEG, PNG."
              onFileSelect={(file) =>
                formik.setFieldValue("profilePicture", file)
              }
              value={formik.values.profilePicture}
            />
            {formik.touched.profilePicture && formik.errors.profilePicture ? (
              <div className="text-red-500 text-xs mt-1">
                {formik.errors.profilePicture}
              </div>
            ) : null}
          </div>

          {/* Full Name */}
          <div className="row-start-2 col-start-1">
            <div className="flex justify-between items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Full Name:
              </h4>
              <PrimaryInput
                placeholder="Enter full name"
                className="w-full"
                name="fullName"
                value={formik.values.fullName}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
            </div>
            {formik.touched.fullName && formik.errors.fullName ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[140px]">
                {formik.errors.fullName}
              </div>
            ) : null}
          </div>

          {/* Email */}
          <div className="row-start-3 col-start-1">
            <div className="flex justify-between items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Email:
              </h4>
              <PrimaryInput
                placeholder="Enter email address"
                className="w-full"
                type="email"
                name="email"
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
            </div>
            {formik.touched.email && formik.errors.email ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[140px]">
                {formik.errors.email}
              </div>
            ) : null}
          </div>
        </div>

        {/* Password Section */}
        <div className="grid grid-cols-3 gap-x-10 gap-y-6 pb-5 mb-5 border-b">
          {/* Create Password */}
          <div className="col-start-1">
            <div className="flex items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Create Password:
              </h4>
              <PasswordInput
                placeholder="Enter password"
                containerClass="w-full"
                name="password"
                value={formik.values.password}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                autoComplete="new-password"
              />
            </div>
            {formik.touched.password && formik.errors.password ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[140px]">
                {formik.errors.password}
              </div>
            ) : null}
          </div>

          {/* Confirm Password */}
          <div className="col-start-2">
            <div className="flex items-center gap-[40px]">
              <h4 className="w-[120px] text-xs text-[#222222] flex-shrink-0">
                Confirm Password:
              </h4>
              <PasswordInput
                placeholder="Enter password"
                containerClass="w-full"
                name="confirmPassword"
                value={formik.values.confirmPassword}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                // defaultEyeOpen={true}
                autoComplete="off"
              />
            </div>
            {formik.touched.confirmPassword && formik.errors.confirmPassword ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[160px]">
                {formik.errors.confirmPassword}
              </div>
            ) : null}
          </div>

          {/* Password Disclaimer */}
          <div className="col-start-3">
            <div className="text-[#939CA7] text-[10px] leading-tight">
              Password should be at least 8 characters, combination of lowercase
              (a-z) & uppercase (A-Z) with one number (0-9) or symbol
            </div>
          </div>
        </div>

        {/* Assign Role */}
        <div className="grid grid-cols-3 gap-x-10">
          <div className="col-start-1">
            <div className="flex items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Assign Role:
              </h4>
              <PrimaryDropdown
                className="w-[190px]"
                options={rolesdata || []}
                placeholder={
                  isLoadingRoleOptions ? "Loading..." : "Select Role"
                }
                name="role"
                value={formik.values.role}
                onValueChange={(value) => handleRoleChange(value)}
                onBlur={() => formik.setFieldTouched("role", true)}
                disabled={isLoadingRoleOptions}
              />
            </div>
            {formik.touched.role && formik.errors.role ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[140px] w-[324px]">
                {formik.errors.role}
              </div>
            ) : null}
          </div>
        </div>
      </div>

      <AccessController
        key={formik.values.role}
        role_id={formik.values.role}
        onPermissionsChange={handlePermissionsChange}
      />
    </form>
  );
}

export default AccountManagementCreateUserForm;
