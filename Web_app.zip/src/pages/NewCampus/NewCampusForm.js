import { useFormik } from "formik";
import * as Yup from "yup";
import { AddSvg, BackspaceSvg } from "../../assets/svg";
import {
  PrimaryBtn2,
  PrimaryDropdown,
  PrimaryFileInput,
  PrimaryInput,
  PrimaryTextarea,
  SecondaryBtn,
  SecondaryBtn2,
} from "../../components";
import BuildingFormCard from "./BuildingFormCard";
import { Link, useNavigate } from "react-router-dom";
import { ROUTES } from "../../router";
import { useCreateCampus, useGetCampusTypes } from "../../api/queryHooks";
import {
  MAX_FILE_SIZE_TO_UPLOAD_IMAGE,
  UNUSED_API_VARIABLES,
  VALID_IMAGE_FILE_TYPES,
} from "../../consts";
import toaster from "../../utils/toaster";

const MAX_FILE_SIZE = MAX_FILE_SIZE_TO_UPLOAD_IMAGE; // 2MB
const VALID_FILE_TYPES = VALID_IMAGE_FILE_TYPES; // Example types

const validationSchema = Yup.object().shape({
  campusName: Yup.string().required("Campus name is required"),
  campusType: Yup.string().required("Campus type is required"),
  location: Yup.string().required("Location is required"),
  description: Yup.string().optional(),
  campusImage: Yup.mixed()
    .nullable()
    .test("fileSize", "File too large (max 2MB)", (value) => {
      if (!value) return true;
      return value.size <= MAX_FILE_SIZE;
    })
    .test("fileType", "Unsupported file type (only JPG, PNG, GIF)", (value) => {
      if (!value) return true;
      return VALID_FILE_TYPES.includes(value.type);
    }),
  buildings: Yup.array()
    .of(
      Yup.object().shape({
        buildingName: Yup.string().required("Building name is required"),
        floorCount: Yup.number()
          .min(1, "Floor count must be at least 1")
          .required("Floor count is required"),
      })
    )
    .optional(),
});

function NewCampusForm() {
  // Fetch campus types from API
  const { data: campusTypesData, isLoading: campusTypesLoading } =
    useGetCampusTypes();
  const navigate = useNavigate();

  const createCampusMutation = useCreateCampus({
    onSuccess: (data) => {
      navigate(ROUTES.CAMPUS_MANAGEMENT);
      toaster.success("Campus created successfully!");
      formik.resetForm(); // Reset form after successful submission
      // Optionally navigate or update UI
    },
    onError: (error) => {
      toaster.error(
        error?.response?.data?.message ||
          `Error creating campus: ${error.message}`
      );
      console.error("Error creating campus:", error);
    },
  });

  const formik = useFormik({
    initialValues: {
      campusName: "",
      campusType: "",
      location: "",
      description: "",
      campusImage: null,
      buildings: [],
    },
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      // Convert campusImage to base64 if it exists
      let base64Image = null;
      if (values.campusImage) {
        try {
          const reader = new FileReader();
          reader.readAsDataURL(values.campusImage);
          await new Promise((resolve) => {
            reader.onloadend = () => {
              base64Image = reader.result;
              resolve();
            };
          });
        } catch (error) {
          console.error("Error converting image to base64:", error);
          toaster.error("Failed to process campus image.");
          return; // Stop submission if image conversion fails
        }
      }

      const payload = {
        name: values.campusName,
        type: values.campusType,
        location: values.location,
        description: values.description,

        organization: UNUSED_API_VARIABLES.ORGANIZATION,
        campusImage: UNUSED_API_VARIABLES.CAMPUSIMAGE,
        campusImage: base64Image,
        status: UNUSED_API_VARIABLES.STATUS,

        buildings: values.buildings.map((building) => ({
          name: building.buildingName,
          floor_count: building.floorCount,

          type: UNUSED_API_VARIABLES.TYPE,
          description: UNUSED_API_VARIABLES.DESCRIPTION,
          status: UNUSED_API_VARIABLES.STATUS,
        })),
      };
      createCampusMutation.mutate(payload);
    },
  });

  const addBuilding = () => {
    formik.setFieldValue("buildings", [
      ...formik.values.buildings,
      { buildingName: "", floorCount: 1 },
    ]);
  };

  const removeBuilding = (indexToRemove) => {
    formik.setFieldValue(
      "buildings",
      formik.values.buildings.filter((_, index) => index !== indexToRemove)
    );
  };

  return (
    <form onSubmit={formik.handleSubmit}>
      <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
        <Link
          to={ROUTES.CAMPUS_MANAGEMENT}
          className="flex items-center gap-[10px]"
        >
          <BackspaceSvg />
          <h2 className="text-[#222222] font-bold">Add New Campus</h2>
        </Link>
        <div className="flex items-center gap-[15px]">
          <SecondaryBtn
            className={"w-[80px] justify-center"}
            onClick={() => formik.resetForm()}
            type="button"
          >
            RESET
          </SecondaryBtn>
          <PrimaryBtn2
            type="submit"
            disabled={formik.isSubmitting || createCampusMutation.isLoading}
            className={"w-[80px] justify-center"}
          >
            {formik.isSubmitting || createCampusMutation.isLoading
              ? "CREATING..."
              : "CREATE"}
          </PrimaryBtn2>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-x-10 gap-y-3 pb-5 mb-5 border-b">
        <div className="row-start-1 col-start-1">
          <div className="flex justify-between items-start gap-[40px]">
            <h4 className="w-[90px] text-xs text-[#222222] flex-shrink-0 mt-2">
              Campus Name:
            </h4>
            <PrimaryInput
              placeholder="Campus name"
              className="w-full"
              name="campusName"
              value={formik.values.campusName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
          </div>
          {formik.touched.campusName && formik.errors.campusName ? (
            <div className="text-red-500 text-xs mt-1 text-left ml-[130px]">
              {formik.errors.campusName}
            </div>
          ) : null}
        </div>
        <div className="row-start-1 col-start-2">
          <div className="flex items-center gap-[40px]">
            <div className="w-[80px] flex-shrink-0">
              <h4 className="text-xs text-[#222222] flex-shrink-0">
                Campus Type:
              </h4>
            </div>
            <PrimaryDropdown
              className="w-[190px]"
              options={campusTypesData || []}
              placeholder={campusTypesLoading ? "Loading..." : "Select"}
              name="campusType"
              value={formik.values.campusType}
              onValueChange={(value) =>
                formik.setFieldValue("campusType", value)
              }
              onBlur={() => formik.setFieldTouched("campusType", true)}
              disabled={campusTypesLoading}
            />
          </div>
          {formik.touched.campusType && formik.errors.campusType ? (
            <div className="text-red-500 text-xs mt-1 text-left ml-[124px]">
              {formik.errors.campusType}
            </div>
          ) : null}
        </div>
        <div className="row-start-2 col-start-1">
          <div className="flex justify-between items-start gap-[40px]">
            <h4 className="w-[90px] text-xs text-[#222222] flex-shrink-0 mt-2">
              Location:
            </h4>
            <PrimaryTextarea
              placeholder="Enter full address"
              className="w-full h-[82px] resize-none"
              name="location"
              value={formik.values.location}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
          </div>
          {formik.touched.location && formik.errors.location ? (
            <div className="text-red-500 text-xs mt-1 text-left ml-[130px]">
              {formik.errors.location}
            </div>
          ) : null}
        </div>
        <div className="row-start-2 col-start-2">
          <div className="flex justify-between items-start gap-[40px]">
            <div className="w-[80px] flex-shrink-0 mt-2">
              <h4 className="text-xs text-[#222222] flex-shrink-0">
                Description:
              </h4>
              <p className="text-[#939CA7] text-[10px]">(Optional)</p>
            </div>
            <PrimaryTextarea
              placeholder="Enter description"
              className="w-full h-[82px] resize-none"
              name="description"
              value={formik.values.description}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
          </div>
        </div>
        <div className="row-start-1 col-start-3 row-span-2">
          <PrimaryFileInput
            type={"image"}
            label="Campus Image"
            description="Please upload an logo size upto 2 MB"
            onFileSelect={(file) => formik.setFieldValue("campusImage", file)}
            value={formik.values.campusImage}
          />
          {formik.touched.campusImage && formik.errors.campusImage ? (
            <div className="text-red-500 text-xs mt-1 text-left ml-[130px]">
              {formik.errors.campusImage}
            </div>
          ) : null}
        </div>
      </div>
      {formik.values?.buildings?.length === 0 ? (
        <div className="flex items-center justify-center min-h-[168px] w-full">
          <SecondaryBtn2
            Icon={AddSvg}
            className={"h-[60px] w-[200px] justify-center"}
            onClick={addBuilding}
            type="button"
            iconClassName="fill-[#227EEB]"
          >
            ADD BUILDINGS
          </SecondaryBtn2>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-x-10 gap-y-3">
          {formik.values.buildings.map((building, index) => (
            <BuildingFormCard
              key={index}
              title={`0${index + 1} Building`}
              showDelete={true}
              namePrefix={`buildings[${index}]`}
              formik={formik}
              onDelete={() => removeBuilding(index)}
            />
          ))}
          <div className="flex items-center justify-center min-h-[168px]">
            <SecondaryBtn2
              Icon={AddSvg}
              className={"h-[60px] w-[200px] justify-center"}
              onClick={addBuilding}
              type="button"
              iconClassName="fill-[#227EEB]"
            >
              MORE BUILDINGS
            </SecondaryBtn2>
          </div>
        </div>
      )}
    </form>
  );
}

export default NewCampusForm;
