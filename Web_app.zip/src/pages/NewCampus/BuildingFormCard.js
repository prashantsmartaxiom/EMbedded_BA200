import { BuildingSvg, DeleteSvg } from "../../assets/svg";
import { PrimaryDropdown, PrimaryInput } from "../../components";

const BuildingFormCard = ({
  title = "01 Building",
  showDelete = false,
  namePrefix,
  formik,
  onDelete,
}) => {
  const getFieldProps = (fieldName) =>
    formik.getFieldProps(`${namePrefix}.${fieldName}`);

  const getFieldError = (fieldName) => {
    const fieldTouched = formik.getFieldMeta(
      `${namePrefix}.${fieldName}`
    ).touched;
    const fieldError = formik.getFieldMeta(`${namePrefix}.${fieldName}`).error;
    return fieldTouched && fieldError ? fieldError : null;
  };

  const buildingNameProps = getFieldProps("buildingName");
  const buildingNameError = getFieldError("buildingName");
  const floorCountProps = getFieldProps("floorCount");
  const floorCountError = getFieldError("floorCount");

  const handleFloorCountChange = (selectedValueString) => {
    formik.setFieldValue(
      `${namePrefix}.floorCount`,
      Number(selectedValueString)
    );
  };

  const handleFloorCountBlur = () => {
    formik.setFieldTouched(`${namePrefix}.floorCount`, true);
  };

  return (
    <div className="bg-[#FFFFFF] p-[15px] border border-[#DDDDDD] rounded-[10px]">
      <div className="flex items-center justify-between">
        <h2 className="text-[#222222] text-[13px] flex items-center gap-3">
          <BuildingSvg className="fill-[#227EEB]" />
          <span className="mt-[2px] text-[#222222] font-semibold">{title}</span>
        </h2>
        {showDelete ? (
          <button
            type="button"
            className="text-[#FF1212] flex items-center gap-[5px] text-xs"
            onClick={onDelete}
          >
            <DeleteSvg className="fill-[#ff1212]"/> Delete
          </button>
        ) : null}
      </div>
      <div className="my-[15px]">
        <PrimaryInput
          placeholder="Building name"
          className="w-full"
          {...buildingNameProps}
        />
        {buildingNameError ? (
          <div className="text-red-500 text-xs mt-1">{buildingNameError}</div>
        ) : null}
      </div>
      <div className="flex items-center justify-between max-w-[255px]">
        <h3 className="text-[#222222] text-xs">Floor Count:</h3>
        <PrimaryDropdown
          className="w-[80px]"
          options={[
            { value: "1", label: "1" },
            { value: "2", label: "2" },
            { value: "3", label: "3" },
            { value: "4", label: "4" },
            { value: "5", label: "5" },
            { value: "6", label: "6" },
            { value: "7", label: "7" },
            { value: "8", label: "8" },
            { value: "9", label: "9" },
            { value: "10", label: "10" },
          ]}
          value={String(floorCountProps.value)}
          onValueChange={handleFloorCountChange}
          onBlur={handleFloorCountBlur}
          placeholder="Select"
        />
      </div>
      {floorCountError ? (
        <div className="text-red-500 text-xs mt-1 text-right max-w-[255px]">
          {floorCountError}
        </div>
      ) : null}
    </div>
  );
};
export default BuildingFormCard;
