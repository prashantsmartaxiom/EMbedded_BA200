import { useState } from "react";
import {
  MdArrowDownSvg,
  FloorSvg,
  DeleteSvg,
  EditSvg,
  AddSvg,
  ZoneSvg,
} from "../../assets/svg";
import { useQueryClient } from "react-query";
import DeleteFloorPopup from "../ViewFloorDetails/DeleteFloorPopup";
import QUERY_KEYS from "../../api/queryKeys";
import EditFloorModal from "../FloorManagement/EditFloorModal";
import EditZoneModal from "../ZoneManagement/EditZoneModal";
import DeleteZonePopup from "../ViewZoneDetails/DeleteZonePopup";
import AddZoneFromBuildingForm from "./AddZoneFromBuildingForm";
import { BottomRightModal, BottomRightModalHeader } from "../../components";
import useUserStore from "../../store/useUserStore";

function EditZoneButton({ zoneId, building }) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  const onSuccess = () => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.BUILDING, building?.id],
    });
  };

  return (
    <>
      <button
        className="flex items-center justify-center rounded bg-[#227EEB] w-7 h-7"
        onClick={toggleModal}
        title="Edit"
      >
        <EditSvg className="fill-[#ffffff]" />
      </button>
      {open && (
        <EditZoneModal
          zoneId={zoneId}
          toggleModal={toggleModal}
          onSuccess={onSuccess}
        />
      )}
    </>
  );
}

function DeleteZoneButton({ zoneId, building }) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  const onSuccess = () => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.BUILDING, building?.id],
    });
  };

  return (
    <>
      <button
        className="flex items-center justify-center rounded bg-[#FF1212] w-7 h-7"
        onClick={toggleModal}
        title="Delete"
      >
        <DeleteSvg className="fill-[#ffffff]" />
      </button>
      {open && (
        <DeleteZonePopup
          zoneId={zoneId}
          toggleModal={toggleModal}
          onSuccess={onSuccess}
          navigateToRoute=""
        />
      )}
    </>
  );
}

const ZoneCardForAccordian = ({ zone, building }) => {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="cursor-pointer bg-[#E9F3FC] border border-[#BED9F9] rounded-lg flex items-center justify-between px-3 py-3 group hover:shadow-md transition-all duration-200 relative">
      <div className="flex items-center gap-2">
        <ZoneSvg className="fill-[#227EEB] text-[#227EEB]" />
        <span className="text-[#222222] text-[14px] font-medium">
          {zone.name}
        </span>
      </div>

      <span className="text-[#7A838E] text-[12px] group-hover:opacity-0 transition-opacity duration-200">
        Device: {zone?.configuredDeviceCount ? zone?.configuredDeviceCount : 0}
      </span>

      <div className="absolute right-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        {userPermissions?.CAMPUS_MANAGEMENT?.zone_management?.addModify ? (
          <EditZoneButton zoneId={zone.id} building={building} />
        ) : null}
        {userPermissions?.CAMPUS_MANAGEMENT?.zone_management?.delete ? (
          <DeleteZoneButton zoneId={zone.id} building={building} />
        ) : null}
      </div>
    </div>
  );
};

function EditFloorButton({ floorId, building }) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  const onSuccess = () => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.BUILDING, building?.id],
    });
  };

  return (
    <>
      <button
        type="button"
        className="text-[#222222] text-[12px] flex items-center gap-[5px]"
        onClick={toggleModal}
      >
        <EditSvg /> Edit
      </button>
      {open && (
        <EditFloorModal
          floorId={floorId}
          toggleModal={toggleModal}
          onSuccess={onSuccess}
        />
      )}
    </>
  );
}

const DeleteFloor = ({ floor, building }) => {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  const onSuccess = () => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.BUILDING, building?.id],
    });
  };

  return (
    <>
      <button
        type="button"
        className="text-[#FF1212] text-[12px] flex items-center gap-[5px]"
        onClick={toggleModal}
      >
        <DeleteSvg className="fill-[#ff1212]" /> Delete
      </button>
      {open ? (
        <DeleteFloorPopup
          toggleModal={toggleModal}
          floorId={floor.id}
          navigateToRoute=""
          onSuccess={onSuccess}
        />
      ) : null}
    </>
  );
};

function AddNewZone({ floor, building, campus }) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = (value) => {
    setIsOpen(value);
  };

  return (
    <>
      <button
        type="button"
        className="text-[#222222] text-[12px] flex items-center gap-[5px]"
        onClick={() => toggleModal(true)}
      >
        <AddSvg className="text-[#222222] text-[12px]" /> New Zone
      </button>
      {isOpen ? (
        <BottomRightModal
          toggleModal={toggleModal}
          className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
        >
          <BottomRightModalHeader
            toggleModal={toggleModal}
            title="Add Zone Floor"
          />
          <AddZoneFromBuildingForm
            toggleModal={toggleModal}
            defaultValues={{
              campusId: campus?._id,
              campusName: campus?.name,
              buildingId: building?._id,
              buildingName: building?.name,
              floorId: floor?._id,
              floorName: floor?.name,
            }}
          />
        </BottomRightModal>
      ) : null}
    </>
  );
}

const FloorAccordian = ({ floor, building }) => {
  const userPermissions = useUserStore((state) => state.permissions);
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="border rounded-[10px] overflow-hidden">
      <div
        className="flex items-center justify-between bg-[#F2F4F8] px-4 h-[46px] cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="flex items-center gap-2">
          <MdArrowDownSvg className={`${isOpen ? "rotate-180" : ""}`} />
          <FloorSvg className="fill-[#227EEB]" />
          <span className="text-[#222222] text-[14px] font-semibold">
            {floor?.name}
          </span>
          {/* <span className="text-[#7A838E] text-[11px]">- {}</span> */}
        </div>

        <div
          className="flex items-center gap-4"
          onClick={(e) => e.stopPropagation()}
        >
          {userPermissions?.CAMPUS_MANAGEMENT?.zone_management?.addModify ? (
            <AddNewZone
              floor={floor}
              building={building}
              campus={building?.campusId}
            />
          ) : null}
          {userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.addModify ? (
            <EditFloorButton floorId={floor.id} building={building} />
          ) : null}
          {userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.delete ? (
            <DeleteFloor floor={floor} building={building} />
          ) : null}
        </div>
      </div>

      {isOpen && (
        <div className="grid grid-cols-4 gap-3 p-3">
          {floor?.zones.length === 0 ? (
            <div className="text-xs text-[#222222] text-center p-5 w-full">
              No zones available
            </div>
          ) : (
            floor?.zones
              ?.map((zone, index) => ({
                id: zone?._id,
                ...zone,
              }))
              .map((zone) => (
                <ZoneCardForAccordian
                  key={zone.id}
                  zone={zone}
                  building={building}
                />
              ))
          )}
        </div>
      )}
    </div>
  );
};

export default FloorAccordian;
