import { useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  PrimaryBtn2,
  PrimaryDropdown,
  PrimaryInput,
  PrimaryTextarea,
} from "../../components";
import {
  useGetCampusOptions,
  useGetBuildingOptionsByCampus,
  useGetFloorsOptionsByBuilding,
  useCreateZone,
} from "../../api/queryHooks";
import QUERY_KEYS from "../../api/queryKeys";
import { useQueryClient } from "react-query";
import toaster from "../../utils/toaster";

const validationSchema = Yup.object({
  campusId: Yup.string().required("Campus is required"),
  buildingId: Yup.string().required("Building is required"),
  floorId: Yup.string().required("Floor is required"),
  name: Yup.string().when(["campusId", "buildingId", "floorId"], {
    is: (campusId, buildingId, floorId) => campusId && buildingId && floorId,
    then: (schema) => schema.trim().required("Zone name is required"),
    otherwise: (schema) => schema.notRequired(),
  }),
  description: Yup.string().optional(),
});

function AddZoneFromBuildingForm({ toggleModal, defaultValues }) {
  const queryClient = useQueryClient();
  const createZoneMutation = useCreateZone({
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.BUILDING, defaultValues?.buildingId],
      });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.FLOOR],
        exact: false,
      });
      toggleModal(false);
      formik.resetForm();
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || "Failed to add zone");
      console.error("Error creating zone:", error);
      formik.setFieldError(
        "submit",
        "Failed to create zone. Please try again."
      );
    },
  });

  const formik = useFormik({
    initialValues: {
      campusId: defaultValues?.campusId || "",
      buildingId: defaultValues?.buildingId || "",
      floorId: defaultValues?.floorId || "",
      name: defaultValues?.name || "",
      description: defaultValues?.description || "",
    },
    validationSchema,
    onSubmit: (values) => {
      const zoneData = {
        campusId: values.campusId,
        buildingId: values.buildingId,
        floorId: values.floorId,
        zoneName: values.name,
        description: values.description,

        type: "office",
        status: "active",
        zoneImage: "https://example.com/images/test-zone-with-ids.jpg",
      };

      createZoneMutation.mutate({
        floorId: values.floorId,
        zoneData,
      });
    },
  });

  const canSubmit = () => {
    return (
      formik.values.campusId &&
      formik.values.buildingId &&
      formik.values.floorId &&
      formik.values.name.trim() &&
      formik.isValid
    );
  };

  return (
    <form
      className="flex-grow flex flex-col justify-between"
      onSubmit={formik.handleSubmit}
    >
      <div>
        <div className="px-5 mb-5 flex items-center justify-between w-full">
          <label htmlFor="campusId" className="text-[#222222] text-[12px]">
            Campus Name:
          </label>
          <div className="w-[300px]">
            <h2 className="text-[#222222] text-xs">
              {defaultValues?.campusName || ""}
            </h2>
          </div>
        </div>

        <div className="px-5 mb-5 flex items-center justify-between w-full">
          <label htmlFor="buildingId" className="text-[#222222] text-[12px]">
            Building:
          </label>
          <div className="w-[300px]">
            <h2 className="text-[#222222] text-xs">
              {defaultValues?.buildingName || ""}
            </h2>
          </div>
        </div>

        <div className="px-5 pb-5 mb-5 border-b border-[#DDDDDD]">
          <div className="flex items-center justify-between w-full">
            <label htmlFor="floorId" className="text-[#222222] text-[12px]">
              Floor:
            </label>
            <div className="w-[300px]">
              <h2 className="text-[#222222] text-xs">
                {defaultValues?.floorName || ""}
              </h2>
            </div>
          </div>
        </div>

        {formik.values.campusId &&
          formik.values.buildingId &&
          formik.values.floorId && (
            <>
              <div className="flex items-center justify-between px-5 mb-5">
                <label htmlFor="name" className="text-[#222222] text-[12px]">
                  Zone Name
                </label>
                <div className="w-[300px]">
                  <PrimaryInput
                    className="w-full"
                    placeholder="Enter Zone name"
                    name="name"
                    value={formik.values.name}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.touched.name && formik.errors.name && (
                    <span className="text-red-500 text-xs mt-1">
                      {formik.errors.name}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between px-5">
                <label
                  htmlFor="description"
                  className="text-[#222222] text-[12px]"
                >
                  Zone Description
                  <p className="text-[#939CA7] text-[10px]">(Optional)</p>
                </label>
                <div className="w-[300px]">
                  <PrimaryTextarea
                    className="w-full min-h-[80px]"
                    placeholder="Enter Zone Description"
                    name="description"
                    value={formik.values.description}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.touched.description && formik.errors.description && (
                    <span className="text-red-500 text-xs mt-1">
                      {formik.errors.description}
                    </span>
                  )}
                </div>
              </div>
            </>
          )}

        {formik.errors.submit && (
          <div className="px-5 mt-3">
            <span className="text-red-500 text-xs">{formik.errors.submit}</span>
          </div>
        )}
      </div>

      <div className="p-5 flex justify-end border-t border-[#DDDDDD]">
        <PrimaryBtn2
          type="submit"
          className="min-w-20 justify-center"
          disabled={createZoneMutation.isLoading || !canSubmit()}
        >
          {createZoneMutation.isLoading ? "ADDING..." : "ADD"}
        </PrimaryBtn2>
      </div>
    </form>
  );
}

export default AddZoneFromBuildingForm;

// function AddZoneFromBuildingModal() {
//   const [isOpen, setIsOpen] = useState(false);

//   const toggleModal = (value) => {
//     setIsOpen(value);
//   };

//   return (
//     <>
//       <SecondaryBtnLink
//         onClick={() => toggleModal(true)}
//         className={"w-[135px] justify-center"}
//         Icon={AddSvg}
//       >
//         NEW ZONE
//       </SecondaryBtnLink>
//       {isOpen ? (
//         <BottomRightModal
//           toggleModal={toggleModal}
//           className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
//         >
//           <BottomRightModalHeader
//             toggleModal={toggleModal}
//             title="Add New Zone"
//           />
//           <AddZoneFromBuildingForm toggleModal={toggleModal} />
//         </BottomRightModal>
//       ) : null}
//     </>
//   );
// }

// export default AddZoneFromBuildingModal;
