import { BuildingSvg, CopySvg, FloorSvg, ZoneSvg } from "../../assets/svg";
import { BuildingUpdateStatusDropdown } from "../../components/Cards/BuildingCard";
import useUserStore from "../../store/useUserStore";
import { formatDatev1, padStart } from "../../utils/helpers";

function ViewBuildingDetailContent({ building }) {
  const userPermissions = useUserStore((state) => state.permissions);

  // const buildingId = building?._id;
  return (
    <div>
      <div className="flex items-center gap-5">
        <div className="w-[68px] h-[124px] flex items-center justify-center bg-[#E6F0FC] rounded-[8px] flex-shrink-0">
          <BuildingSvg className="fill-[#227EEB] h-[32px] w-[32px]" />
        </div>
        <div className="flex-grow">
          <div className="flex items-center justify-between">
            <h2 className="text-[#222222] font-semibold">{building?.name}</h2>
            <div className="flex items-center gap-5">
              <button
                type="button"
                className="text-[#7A838E] flex items-center gap-[10px] text-[12px]"
              >
                ID: {building?.id} <CopySvg />
              </button>
              {userPermissions?.CAMPUS_MANAGEMENT?.building_management
                ?.addModify ? (
                <BuildingUpdateStatusDropdown building={building} />
              ) : null}
            </div>
          </div>

          <div className="mt-1 mb-4">
            <div className="flex items-center mb-1">
              <h2 className="text-[#7A838E] text-[12px] w-[80px]">Campus:</h2>
              <p className="text-[#222222] text-[12px]">
                {building?.campusId?.name}
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-5">
              <div className="text-[10px] bg-[#EEEEEE] p-[6px] w-fit min-w-[85px] text-center text-[#222222] rounded-md">
                {building?.type}
              </div>
              <div className="flex items-center gap-[15px]">
                <button
                  type="button"
                  className="flex items-center gap-[5px] text-[#222222] text-xs"
                >
                  <FloorSvg /> {padStart(building?.floorCount)}
                </button>
                <button
                  type="button"
                  className="flex items-center gap-[5px] text-[#222222] text-xs"
                >
                  <ZoneSvg /> {padStart(building?.zoneCount)}
                </button>
              </div>
            </div>

            <button
              type="button"
              className="text-[#7A838E] flex items-center gap-[10px] text-[12px]"
            >
              Added on: {formatDatev1(building?.createdAt)}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ViewBuildingDetailContent;
