import { Link } from "react-router-dom";
import { BackspaceSvg, DeleteSvg, EditSvg } from "../../assets/svg";
import { SecondaryBtn } from "../../components";
import { ROUTES } from "../../router";
import DeleteBuildingPopup from "./DeleteBuildingPopup";
import { useState } from "react";
import EditBuildingModal from "../BuildingManagement/EditBuildingModal";
import useUserStore from "../../store/useUserStore";

const EditBuilding = ({ building }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <SecondaryBtn
        onClick={toggleModal}
        className={"w-[80px] justify-center fill-[#227EEB]"}
        Icon={EditSvg}
      >
        EDIT
      </SecondaryBtn>
      {open ? (
        <EditBuildingModal
          toggleModal={toggleModal}
          buildingId={building._id}
        />
      ) : null}
    </>
  );
};

const DeleteBuilding = ({ building }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <SecondaryBtn
        className={
          "justify-center fill-[#227EEB] !text-[#FF1212] !border-[#FF1212]"
        }
        onClick={toggleModal}
        iconClassName="fill-[#FF1212]"
        Icon={DeleteSvg}
      >
        DELETE
      </SecondaryBtn>
      {open ? (
        <DeleteBuildingPopup
          toggleModal={toggleModal}
          buildingId={building._id}
        />
      ) : null}
    </>
  );
};

function Header({ building }) {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
      <Link
        to={ROUTES.BUILDING_MANAGEMENT}
        className="flex items-center gap-[10px]"
      >
        <BackspaceSvg />
        <h2 className="text-[#222222] font-bold">View Building Details</h2>
      </Link>
      <div className="flex items-center gap-[15px]">
        {userPermissions?.CAMPUS_MANAGEMENT?.building_management?.addModify ? (
          <EditBuilding building={building} />
        ) : null}
        {userPermissions?.CAMPUS_MANAGEMENT?.building_management?.delete ? (
          <DeleteBuilding building={building} />
        ) : null}
      </div>
    </div>
  );
}

export default Header;
