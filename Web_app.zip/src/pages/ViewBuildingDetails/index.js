import { useParams } from "react-router-dom";
import { useGetBuildingById } from "../../api/queryHooks";
import {
  AddMoreButton,
  BottomRightModal,
  BottomRightModalHeader,
  PermissionDenied,
  SpinnerV1,
} from "../../components";
import Header from "./Header";
import ViewBuildingDetailContent from "./ViewBuildingDetailContent";
import FloorAccordian from "./FloorAccordian";
import NewFloorFromCampusForm from "../ViewCampusDetails/NewFloorFromCampusForm";
import { useState } from "react";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../api/queryKeys";
import useUserStore from "../../store/useUserStore";

function AddNewFloor({ building, campus }) {
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = (value) => {
    setIsOpen(value);
  };

  const onSuccess = () => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.BUILDING, building?._id],
    });
  };

  return (
    <>
      <AddMoreButton onClick={() => toggleModal(true)}>
        MORE FLOORS
      </AddMoreButton>
      {isOpen ? (
        <BottomRightModal
          toggleModal={toggleModal}
          className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
        >
          <BottomRightModalHeader
            toggleModal={toggleModal}
            title="Add New Floor"
          />
          <NewFloorFromCampusForm
            toggleModal={toggleModal}
            defaultValues={{
              campusId: campus?._id,
              campusName: campus?.name,
              buildingId: building?._id,
              buildingName: building?.name,
              name: "",
              floorLevel: "1",
              floorImage: "base64image",
            }}
            onSuccess={onSuccess}
          />
        </BottomRightModal>
      ) : null}
    </>
  );
}

function ViewBuildingDetails() {
  const userPermissions = useUserStore((state) => state.permissions);

  const { id } = useParams();
  const { data, isLoading, error } = useGetBuildingById(id);
  const building = data?.data?.building;

  if (!userPermissions?.CAMPUS_MANAGEMENT?.building_management?.readOnly)
    return <PermissionDenied />;

  if (isLoading)
    return (
      <div className="p-5 mt-5">
        <SpinnerV1 />
      </div>
    );
  if (error)
    return <div className="p-5 mt-5 text-center">building not found</div>;
  if (!building)
    return <div className="p-5 mt-5 text-center">Something went wrong</div>;

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header building={building} />
        <ViewBuildingDetailContent building={building} />
      </div>
      {userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.readOnly ? (
        <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mt-[15px] flex flex-col gap-5">
          {building?.floors?.map((floor) => (
            <FloorAccordian key={floor._id} floor={floor} building={building} />
          ))}
          {building?._id ? (
            <div className="flex justify-center">
              {userPermissions?.CAMPUS_MANAGEMENT?.floor_management
                ?.addModify ? (
                <AddNewFloor building={building} campus={building?.campusId} />
              ) : null}
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

export default ViewBuildingDetails;
