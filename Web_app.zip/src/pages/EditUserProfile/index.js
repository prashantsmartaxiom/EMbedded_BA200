import { useParams } from "react-router-dom";
import EditUserProfileForm from "./EditUserProfileForm";
import { useGetUserInfo } from "../../api/queryHooks";
import { PermissionDenied, SpinnerV1 } from "../../components";
import useUserStore from "../../store/useUserStore";

function EditUserProfile() {
  const userPermissions = useUserStore((state) => state.permissions);

  const { userId } = useParams();
  const { data: userData, isLoading, error } = useGetUserInfo(userId);

  const user = userData?.data?.user;

  if (!userPermissions?.USER_MANAGEMENT?.user_accounts?.addModify)
    return <PermissionDenied />;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <SpinnerV1 />
      </div>
    );
  }

  if (error || !user?._id) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-red-500">Failed to load user information</div>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <EditUserProfileForm user={user} />
    </div>
  );
}

export default EditUserProfile;
