import { useFormik } from "formik";
import * as Yup from "yup";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  PrimaryBtn2,
  PrimaryFileInput,
  PrimaryInput,
  PrimaryDropdown,
  PasswordInput,
  SecondaryBtn,
  PermissionDenied,
} from "../../components";
import { ROUTES } from "../../router";
import { BackspaceSvg } from "../../assets/svg";
import { useUpdateUser, useGetRolesOptions } from "../../api/queryHooks";
import {
  MAX_FILE_SIZE_TO_UPLOAD_IMAGE,
  REGEX,
  UNUSED_API_VARIABLES,
  VALID_IMAGE_FILE_TYPES,
} from "../../consts";
import toaster from "../../utils/toaster";
import AccessController from "../AccountManagementCreateUser/AccessController";
import CONFIG from "../../config";
import useUserStore from "../../store/useUserStore";

const MAX_FILE_SIZE = MAX_FILE_SIZE_TO_UPLOAD_IMAGE; // 2MB
const VALID_FILE_TYPES = VALID_IMAGE_FILE_TYPES;

const validationSchema = Yup.object().shape({
  organization: Yup.string().required("Organisation is required"),
  fullName: Yup.string()
    .required("Full name is required")
    .min(2, "Atleast two characters required"),
  email: Yup.string()
    .matches(REGEX.email, "Invalid email format")
    .required("Email is required"),
  role: Yup.string().required("Role assignment is required"),
  password: Yup.string().test(
    "password-validation",
    "Password must be at least 8 characters and contain at least one lowercase letter, one uppercase letter, and one number",
    function (value) {
      if (!value) return true; // Optional field
      return value.length >= 8 && /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(value);
    }
  ),
  confirmPassword: Yup.string().test(
    "passwords-match",
    "Passwords must match",
    function (value) {
      if (!this.parent.password && !value) return true; // Both empty is ok
      return this.parent.password === value;
    }
  ),
  profileImage: Yup.mixed()
    .nullable()
    .test("fileSize", "File too large (max 2MB)", (value) => {
      if (!value) return true;
      return value.size <= MAX_FILE_SIZE;
    })
    .test("fileType", "Unsupported file type (only JPG, PNG)", (value) => {
      if (!value) return true;
      return VALID_FILE_TYPES.includes(value.type);
    }),
});

function EditUserProfileForm({ user }) {
  const navigate = useNavigate();
  const [allowedResources, setAllowedResources] = useState({});
  const loggedin_user = useUserStore((state) => state.user);

  const is_super_user = user?.role_name === "Superadmin" ? true : false;
  // const is_super_user =
  //   user?.role_id === "68dfdf6850829ba0f7cc4b76" ? true : false;

  const { data: rolesdata, isLoading: isLoadingRoleOptions } =
    useGetRolesOptions({ check: 1 });

  const updateUserMutation = useUpdateUser({
    onSuccess: (data) => {
      navigate(-1);
      toaster.success("Profile updated successfully!");
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || `Error updating profile`);
      console.error("Error updating profile:", error);
    },
  });

  const formik = useFormik({
    initialValues: {
      organization: user?.organization || UNUSED_API_VARIABLES.ORGANIZATION,
      fullName: user?.fullName || "",
      email: user?.email || "",
      role: user?.role_id || "",
      password: "",
      confirmPassword: "",
      profileImage: null,
    },
    validationSchema: validationSchema,
    enableReinitialize: true, // This allows the form to reinitialize when user prop changes
    onSubmit: async (values) => {
      // Convert profileImage to base64 if it exists
      let base64Image = null;
      if (values.profileImage) {
        try {
          const reader = new FileReader();
          reader.readAsDataURL(values.profileImage);
          await new Promise((resolve) => {
            reader.onloadend = () => {
              base64Image = reader.result;
              resolve();
            };
          });
        } catch (error) {
          console.error("Error converting image to base64:", error);
          toaster.error(
            error?.response?.data?.message || "Failed to process profile image."
          );
          return;
        }
      }

      const payload = {
        organization: values.organization,
        fullName: values.fullName,
        email: values.email,
        role: values.role,
        // allowedResources: {
        //   ...allowedResources,
        //   logsMonitoring: {
        //     eventLogs:
        //       allowedResources?.["logsMonitoring"]?.["eventLogs"] === true ||
        //       allowedResources?.["logsMonitoring"]?.["eventLogs"]?.length
        //         ? ["true"]
        //         : [],
        //     mqttLogs:
        //       allowedResources?.["logsMonitoring"]?.["mqttLogs"] === true ||
        //       allowedResources?.["logsMonitoring"]?.["mqttLogs"]?.length
        //         ? ["true"]
        //         : [],
        //   },
        // },
        ...(base64Image && { profileImage: base64Image }),
        ...(values.password && {
          password: values.password,
          confirmPassword: values.confirmPassword,
        }),
      };

      if (!is_super_user) {
        payload.allowedResources = {
          ...allowedResources,
          logsMonitoring: {
            eventLogs:
              allowedResources?.["logsMonitoring"]?.["eventLogs"] === true ||
              allowedResources?.["logsMonitoring"]?.["eventLogs"]?.length
                ? ["true"]
                : [],
            mqttLogs:
              allowedResources?.["logsMonitoring"]?.["mqttLogs"] === true ||
              allowedResources?.["logsMonitoring"]?.["mqttLogs"]?.length
                ? ["true"]
                : [],
          },
        };
      }

      updateUserMutation.mutate({
        userId: user?._id,
        userData: payload,
      });
    },
  });

  // Handle permissions change from AccessController
  const handlePermissionsChange = (permissions) => {
    setAllowedResources(permissions);
  };

  // Reset permissions when role changes
  const handleRoleChange = (value) => {
    formik.setFieldValue("role", value);
    setAllowedResources({}); // Reset permissions when role changes
  };

  // Don't render the form if user data is not available
  if (!user) {
    return (
      <div className="flex items-center justify-center p-8">
        <p className="text-[#939CA7]">Loading user data...</p>
      </div>
    );
  }

  if (is_super_user && loggedin_user?.roleName !== "Superadmin") {
    return (
      <div>
        <PermissionDenied />
      </div>
    );
  }

  return (
    <form onSubmit={formik.handleSubmit}>
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
          <Link to={-1} className="flex items-center gap-[10px]">
            <BackspaceSvg />
            <h2 className="text-[#222222] font-bold">Edit Profile</h2>
          </Link>
          <div className="flex items-center gap-[10px]">
            <SecondaryBtn
              className={"w-[80px] justify-center"}
              onClick={() => formik.resetForm()}
              type="button"
            >
              RESET
            </SecondaryBtn>
            <PrimaryBtn2
              type="submit"
              disabled={formik.isSubmitting || updateUserMutation.isLoading}
              className={"w-[80px] justify-center"}
            >
              {formik.isSubmitting || updateUserMutation.isLoading
                ? "UPDATING..."
                : "UPDATE"}
            </PrimaryBtn2>
          </div>
        </div>
        {/* User Edit Form */}
        <div className="grid grid-cols-3 gap-x-10 gap-y-6 pb-5 mb-5 border-b">
          {/* Organisation */}
          <div className="row-start-1 col-start-1">
            <div className="flex justify-between items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Organisation:
              </h4>
              <PrimaryInput
                placeholder="Organisation"
                className="w-full"
                name="organization"
                value={formik.values.organization}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                disabled
              />
            </div>
            {formik.touched.organization && formik.errors.organization ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[140px]">
                {formik.errors.organization}
              </div>
            ) : null}
          </div>

          {/* Profile Picture */}
          <div className="row-start-1 col-start-2 row-span-3">
            <PrimaryFileInput
              type="image"
              label="Profile Picture"
              description="Please upload an image of size upto 2 MB Accepted format: JPEG, PNG."
              onFileSelect={(file) =>
                formik.setFieldValue("profileImage", file)
              }
              value={formik.values.profileImage}
              imageUrl={user?.ImageURL}
            />
            {formik.touched.profileImage && formik.errors.profileImage ? (
              <div className="text-red-500 text-xs mt-1">
                {formik.errors.profileImage}
              </div>
            ) : null}
          </div>

          {/* Full Name */}
          <div className="row-start-2 col-start-1">
            <div className="flex justify-between items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Full Name:
              </h4>
              <PrimaryInput
                placeholder="Enter full name"
                className="w-full"
                name="fullName"
                value={formik.values.fullName}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
            </div>
            {formik.touched.fullName && formik.errors.fullName ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[140px]">
                {formik.errors.fullName}
              </div>
            ) : null}
          </div>

          {/* Email */}
          <div className="row-start-3 col-start-1">
            <div className="flex justify-between items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Email:
              </h4>
              <PrimaryInput
                placeholder="Enter email address"
                className="w-full"
                type="email"
                name="email"
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
            </div>
            {formik.touched.email && formik.errors.email ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[140px]">
                {formik.errors.email}
              </div>
            ) : null}
          </div>
        </div>

        {/* Password Section */}
        <div className="grid grid-cols-3 gap-x-10 gap-y-6 pb-5 mb-5 border-b">
          {/* Update Password */}
          <div className="col-start-1">
            <div className="flex items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Password:
              </h4>
              <PasswordInput
                placeholder="Enter new password (optional)"
                containerClass="w-full"
                name="password"
                value={formik.values.password}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                autoComplete="new-password"
              />
            </div>
            {formik.touched.password && formik.errors.password ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[140px]">
                {formik.errors.password}
              </div>
            ) : null}
          </div>

          {/* Confirm Password */}
          <div className="col-start-2">
            <div className="flex items-center gap-[40px]">
              <h4 className="w-[120px] text-xs text-[#222222] flex-shrink-0">
                Confirm Password:
              </h4>
              <PasswordInput
                placeholder="Confirm new password"
                containerClass="w-full"
                name="confirmPassword"
                value={formik.values.confirmPassword}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                // defaultEyeOpen={true}
                autoComplete="off"
              />
            </div>
            {formik.touched.confirmPassword && formik.errors.confirmPassword ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[160px]">
                {formik.errors.confirmPassword}
              </div>
            ) : null}
          </div>

          {/* Password Disclaimer */}
          <div className="col-start-3">
            <div className="text-[#939CA7] text-[10px] leading-tight">
              Password should be at least 8 characters, combination of lowercase
              (a-z) & uppercase (A-Z) with one number (0-9) or symbol. Leave
              blank to keep current password.
            </div>
          </div>
        </div>

        {/* Assign Role */}
        <div className="grid grid-cols-3 gap-x-10">
          <div className="col-start-1">
            <div className="flex items-center gap-[40px]">
              <h4 className="w-[100px] text-xs text-[#222222] flex-shrink-0">
                Assign Role:
              </h4>
              <PrimaryDropdown
                className="w-[190px]"
                options={
                  is_super_user
                    ? [
                        {
                          value: user?.role_id,
                          label: user?.role_name || "Superadmin",
                        },
                      ]
                    : rolesdata || []
                }
                placeholder={
                  isLoadingRoleOptions ? "Loading..." : "Select Role"
                }
                name="role"
                value={formik.values.role}
                onValueChange={(value) => handleRoleChange(value)}
                onBlur={() => formik.setFieldTouched("role", true)}
                disabled={isLoadingRoleOptions || is_super_user}
              />
            </div>
            {formik.touched.role && formik.errors.role ? (
              <div className="text-red-500 text-xs mt-1 text-left ml-[140px] w-[324px]">
                {formik.errors.role}
              </div>
            ) : null}
          </div>
        </div>
      </div>

      {/* User Edit Form Ends */}
      {user?.allowedResources ? (
        <AccessController
          key={formik.values.role}
          initialSelection={user?.allowedResources}
          role_id={formik.values.role}
          onPermissionsChange={handlePermissionsChange}
          initialRoleId={user?.role_id}
          userId={user?._id}
          is_super_user={is_super_user}
        />
      ) : (
        <AccessController
          key={formik.values.role}
          // initialSelection={user?.allowedResources}
          role_id={formik.values.role}
          onPermissionsChange={handlePermissionsChange}
          initialRoleId={user?.role_id}
          userId={user?._id}
          is_super_user={is_super_user}
        />
      )}
    </form>
  );
}

export default EditUserProfileForm;
