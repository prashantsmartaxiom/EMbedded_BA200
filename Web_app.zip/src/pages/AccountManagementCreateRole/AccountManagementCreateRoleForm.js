import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ROUTES } from "../../router";
import { BackspaceSvg } from "../../assets/svg";
import {
  PrimaryBtn2,
  SecondaryBtn,
  PrimaryInput,
  Checkbox,
} from "../../components";
import { transformPermissionsForAPI } from "../../utils/helpers";
import { useCreateRole } from "../../api/queryHooks";
import toaster from "../../utils/toaster";

function AccountManagementCreateUserForm({ ROLE_PERMISSIONS }) {
  const [formData, setFormData] = useState({
    roleName: "",
    selectAllPermissions: false,
    permissions: JSON.parse(JSON.stringify(ROLE_PERMISSIONS)), // Deep copy
  });

  const [activeTab, setActiveTab] = useState("CAMPUS_MANAGEMENT");
  const navigate = useNavigate();

  // Use the React Query hook for creating role
  const createRoleMutation = useCreateRole({
    onSuccess: (data) => {
      toaster.success("Role created successfully!");
      navigate(ROUTES.ROLE_PERMISSIONS);
      handleReset();
    },
    onError: (error) => {
      console.error("Error creating role:", error);
      const errorMessage =
        error?.response?.data?.message ||
        "Error creating role. Please try again.";
      toaster.error(errorMessage);
    },
  });

  // Function to check if all permissions are selected
  const areAllPermissionsSelected = (permissions) => {
    return Object.keys(permissions).every((moduleKey) => {
      return permissions[moduleKey].permissions.categories.every((category) => {
        return category.accesses.every((access) => access.checked);
      });
    });
  };

  // Effect to update selectAllPermissions when ROLE_PERMISSIONS changes
  useEffect(() => {
    if (ROLE_PERMISSIONS) {
      const allSelected = areAllPermissionsSelected(ROLE_PERMISSIONS);
      setFormData((prev) => ({
        ...prev,
        selectAllPermissions: allSelected,
        permissions: JSON.parse(JSON.stringify(ROLE_PERMISSIONS)),
      }));
    }
  }, [ROLE_PERMISSIONS]);

  const handleRoleNameChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      roleName: e.target.value,
    }));
  };

  const handleSelectAllPermissions = (checked) => {
    setFormData((prev) => {
      const updatedPermissions = { ...prev.permissions };
      Object.keys(updatedPermissions).forEach((moduleKey) => {
        updatedPermissions[moduleKey].permissions.categories.forEach(
          (category) => {
            if (checked) {
              // When selecting all, check Full Access first if it exists
              const fullAccessIndex = category.accesses.findIndex(
                (access) => access.value === "fullAccess"
              );
              if (fullAccessIndex !== -1) {
                // Check Full Access first, which will automatically check all others
                category.accesses[fullAccessIndex].checked = true;
                // Also check all other permissions
                category.accesses.forEach((access) => {
                  if (access.value !== "fullAccess") {
                    access.checked = true;
                  }
                });
              } else {
                // If no Full Access option, check all available permissions
                category.accesses.forEach((access) => {
                  access.checked = checked;
                });
              }
            } else {
              // When unchecking all, uncheck everything
              category.accesses.forEach((access) => {
                access.checked = false;
              });
            }
          }
        );
      });

      return {
        ...prev,
        selectAllPermissions: checked,
        permissions: updatedPermissions,
      };
    });
  };

  const handlePermissionChange = (
    moduleKey,
    categoryIndex,
    accessIndex,
    checked
  ) => {
    setFormData((prev) => {
      const updatedPermissions = { ...prev.permissions };
      const category =
        updatedPermissions[moduleKey].permissions.categories[categoryIndex];
      const currentAccess = category.accesses[accessIndex];

      // Update the clicked permission
      currentAccess.checked = checked;

      // Get all non-fullAccess permissions in this category
      const otherPermissions = category.accesses.filter(
        (access) => access.value !== "fullAccess"
      );
      const fullAccessIndex = category.accesses.findIndex(
        (access) => access.value === "fullAccess"
      );

      // Handle Full Access logic
      if (currentAccess.value === "fullAccess") {
        if (checked) {
          // If Full Access is checked, check all other permissions
          otherPermissions.forEach((access) => {
            access.checked = true;
          });
        } else {
          // If Full Access is unchecked, uncheck all other permissions
          otherPermissions.forEach((access) => {
            access.checked = false;
          });
        }
      } else {
        // If any other permission is unchecked, uncheck Full Access
        if (!checked) {
          if (fullAccessIndex !== -1) {
            category.accesses[fullAccessIndex].checked = false;
          }
        }
        // If all other permissions are checked, check Full Access
        else if (checked) {
          const allOtherPermissionsChecked = otherPermissions.every(
            (access) => access.checked
          );
          if (allOtherPermissionsChecked && fullAccessIndex !== -1) {
            category.accesses[fullAccessIndex].checked = true;
          }
        }
      }

      // Check if all permissions are now selected and update selectAllPermissions accordingly
      const allSelected = areAllPermissionsSelected(updatedPermissions);

      return {
        ...prev,
        selectAllPermissions: allSelected,
        permissions: updatedPermissions,
      };
    });
  };

  const handleReset = () => {
    setFormData({
      roleName: "",
      selectAllPermissions: false,
      permissions: JSON.parse(JSON.stringify(ROLE_PERMISSIONS)),
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      roleName: formData.roleName,
      permissions: transformPermissionsForAPI(formData.permissions),
    };

    createRoleMutation.mutate(payload);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mb-5">
        <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
          <Link
            to={ROUTES.CAMPUS_MANAGEMENT}
            className="flex items-center gap-[10px]"
          >
            <BackspaceSvg />
            <h2 className="text-[#222222] font-bold">Add New Role</h2>
          </Link>
          <div className="flex items-center gap-[15px]">
            <SecondaryBtn
              className={"w-[80px] justify-center"}
              onClick={handleReset}
              type="button"
            >
              RESET
            </SecondaryBtn>
            <PrimaryBtn2
              type="submit"
              disabled={
                createRoleMutation.isLoading || !formData.roleName.trim()
              }
              className={"w-[80px] justify-center"}
            >
              {createRoleMutation.isLoading ? "CREATING..." : "CREATE"}
            </PrimaryBtn2>
          </div>
        </div>

        <div className="">
          <div className="flex items-center gap-4">
            <label className="text-xs font-medium text-[#222222] w-20">
              Role Name:
            </label>
            <PrimaryInput
              placeholder="Role title"
              className="flex-1 max-w-md"
              value={formData.roleName}
              onChange={handleRoleNameChange}
              required
            />
            <div className="flex items-center gap-2 ml-8">
              <Checkbox
                id="selectAll"
                checked={formData.selectAllPermissions}
                onCheckedChange={(checked) =>
                  handleSelectAllPermissions(checked)
                }
              />
              <label htmlFor="selectAll" className="text-xs text-[#222222]">
                Select all permissions
              </label>
            </div>
          </div>
        </div>
      </div>

      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mb-5">
        <div className="mb-6">
          <div className="flex border-b border-[#E5E7EB]">
            {Object.entries(formData.permissions).map(([key, module]) => (
              <button
                key={key}
                type="button"
                onClick={() => setActiveTab(key)}
                className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === key
                    ? "border-[#227EEB] text-[#227EEB]"
                    : "border-transparent text-[#6B7280] hover:text-[#222222]"
                }`}
              >
                {module.label}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg border border-[#CCCCCC] overflow-hidden">
          <table className="w-full text-xs">
            {/* Table Header */}
            {formData.permissions[activeTab]?.permissions.categories.length >
              0 && (
              <thead>
                <tr className="bg-[#EEEEEE]">
                  <th className="text-left px-4 py-3 font-medium text-[#222222] text-xs">
                    {formData.permissions[activeTab]?.label}
                  </th>
                  {formData.permissions[
                    activeTab
                  ]?.permissions.categories[0]?.accesses?.map((access) => (
                    <th
                      key={access.value}
                      className="text-center px-4 py-3 font-medium text-[#222222] text-xs"
                    >
                      {access.label}
                    </th>
                  ))}
                </tr>
              </thead>
            )}

            {/* Table Body */}
            <tbody>
              {formData.permissions[activeTab]?.permissions.categories.map(
                (category, categoryIndex) => (
                  <tr key={categoryIndex} className="border-t border-[#F3F4F6]">
                    <td className="px-4 py-3 text-[#222222] text-xs">
                      {category.name}
                    </td>
                    {category.accesses?.map((access, accessIndex) => (
                      <td key={access.value} className="px-4 py-3">
                        <div className="flex justify-center">
                          <Checkbox
                            id={`${activeTab}-${categoryIndex}-${access.value}`}
                            checked={access.checked}
                            onCheckedChange={(checked) =>
                              handlePermissionChange(
                                activeTab,
                                categoryIndex,
                                accessIndex,
                                checked
                              )
                            }
                          />
                        </div>
                      </td>
                    ))}
                  </tr>
                )
              )}
            </tbody>
          </table>
        </div>
      </div>
    </form>
  );
}

export default AccountManagementCreateUserForm;
