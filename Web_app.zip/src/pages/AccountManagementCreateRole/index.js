import { useGetRolesCategories } from "../../api/queryHooks";
import { PermissionDenied, SpinnerV1 } from "../../components";
import useUserStore from "../../store/useUserStore";
import AccountManagementCreateRoleForm from "./AccountManagementCreateRoleForm";

function AccountManagementCreateRole() {
  const userPermissions = useUserStore((state) => state.permissions);
  const { data, isLoading } = useGetRolesCategories();

  if (!userPermissions?.USER_MANAGEMENT?.role_management?.addModify) {
    return <PermissionDenied />;
  }

  if (isLoading)
    return (
      <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow flex items-center justify-center">
        <SpinnerV1 />
      </div>
    );

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <AccountManagementCreateRoleForm ROLE_PERMISSIONS={data?.data || {}} />
    </div>
  );
}
export default AccountManagementCreateRole;
