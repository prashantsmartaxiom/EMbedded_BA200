import { useState } from "react";
import Seperator from "../../components/Header/Seperator";
import {
  FloorCard,
  LoadMoreDataBtn,
  SpinnerV1,
  TabBtn,
} from "../../components";
import { useGetFloors } from "../../api/queryHooks";

const TABS = {
  ALL: "all",
  ACTIVE: "active",
  INACTIVE: "inactive",
};

function Header({ tab, onTabChange, counts }) {
  return (
    <div className="flex items-center justify-between">
      <h2 className="text-[#222222] text-[14px] font-semibold">Floor List</h2>
      <div className="flex items-center gap-[5px]">
        <Seperator className="h-[25px]" />
        <TabBtn
          isActive={tab === TABS.ALL}
          onClick={() => onTabChange(TABS.ALL)}
        >
          All
          <span className="ml-2">{counts.all}</span>
        </TabBtn>
        <TabBtn
          isActive={tab === TABS.ACTIVE}
          onClick={() => onTabChange(TABS.ACTIVE)}
        >
          Active
          <span className="ml-2">{counts.active}</span>
        </TabBtn>
        <TabBtn
          isActive={tab === TABS.INACTIVE}
          onClick={() => onTabChange(TABS.INACTIVE)}
        >
          Inactive
          <span className="ml-2">{counts.inactive}</span>
        </TabBtn>
      </div>
    </div>
  );
}

function List({
  floors,
  isLoading,
  hasNextPage,
  fetchNextPage,
  isFetchingNextPage,
}) {
  if (isLoading) {
    return (
      <div className="text-center py-10">
        <SpinnerV1 />
      </div>
    );
  }

  if (!floors.length) {
    return <div className="text-center py-10">No floors found</div>;
  }

  return (
    <div className="mt-[15px]">
      <div className="grid grid-cols-2 1348:grid-cols-3 gap-[15px]">
        {floors.map((floor) => (
          <FloorCard key={floor._id} floor={floor} />
        ))}
      </div>

      {hasNextPage && (
        <div className="flex justify-center mt-6">
          <LoadMoreDataBtn
            fetchNextPage={fetchNextPage}
            isFetchingNextPage={isFetchingNextPage}
          />
        </div>
      )}
    </div>
  );
}

function FloorListing({ search }) {
  const [tab, setTab] = useState(TABS.ACTIVE);

  const { data, isLoading, hasNextPage, fetchNextPage, isFetchingNextPage } =
    useGetFloors({
      search,
      status: tab === TABS.ACTIVE ? 1 : tab === TABS.INACTIVE ? 0 : null,
      limit: 24,
    });

  const floors = data?.pages.flatMap((page) => page.data?.floors) || [];

  const counts = {
    all: (data?.pages?.[0]?.data?.totalNonDeleted || 0)
      .toString()
      .padStart(2, "0"),
    active: (data?.pages?.[0]?.data?.totalActive || 0)
      .toString()
      .padStart(2, "0"),
    inactive: (data?.pages?.[0]?.data?.totalInactive || 0)
      .toString()
      .padStart(2, "0"),
  };

  return (
    <div>
      <Header tab={tab} onTabChange={setTab} counts={counts} />
      <List
        floors={floors}
        isLoading={isLoading}
        hasNextPage={hasNextPage}
        fetchNextPage={fetchNextPage}
        isFetchingNextPage={isFetchingNextPage}
      />
    </div>
  );
}

export default FloorListing;
