import { useState } from "react";
import { useDebouncedCallback } from "use-debounce";
import FloorListing from "./FloorListing";
import Header from "./Header";
import useUserStore from "../../store/useUserStore";
import { PermissionDenied } from "../../components";

function FloorManagement() {
  const userPermissions = useUserStore((state) => state.permissions);

  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedCallback((value) => {
    setSearch(value);
  }, 500);

  if (!userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.readOnly)
    return <PermissionDenied />;
  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header onSearchChange={debouncedSearch} />
        <FloorListing search={search} />
      </div>
    </div>
  );
}

export default FloorManagement;
