import { useFormik } from "formik";
import * as Yup from "yup";
import { useGetFloorById, useUpdateFloor } from "../../api/queryHooks";
import {
  BottomRightModal,
  BottomRightModalHeader,
  PrimaryBtn2,
  PrimaryInput,
  PrimaryTextarea,
  SpinnerV1,
} from "../../components";
import { useEffect } from "react";
import toaster from "../../utils/toaster";

const validationSchema = Yup.object({
  floorName: Yup.string().required("Floor name is required"),
  description: Yup.string().optional(),
});

function EditFloorForm({ floorId, toggleModal, onSuccess }) {
  const { data, isLoading: isLoadingFloor, isError } = useGetFloorById(floorId);
  const floorData = data?.data?.floor;

  const { mutate: updateFloor, isLoading } = useUpdateFloor({
    onSuccess: () => {
      toggleModal(false);
      onSuccess?.();
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || "Failed to edit floor. Please try again.");
      console.error("Error updating floor:", error);
    },
  });

  const formik = useFormik({
    initialValues: {
      floorName: "",
      description: "",
      status: 1,
    },
    validationSchema,
    onSubmit: (values) => {
      updateFloor({
        floorId,
        floorData: values,
      });
    },
  });

  // Update form values when floor data is loaded
  useEffect(() => {
    if (floorData) {
      const floor = floorData;
      formik.setValues({
        floorName: floor.name || "",
        description: floor.description || "",
        status: floor.status || 1,
      });
    }
  }, [floorData]);

  if (isLoadingFloor) {
    return (
      <div className="p-5">
        <SpinnerV1 />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex-grow flex items-center justify-center">
        <div className="text-red-500">Error loading floor data</div>
      </div>
    );
  }

  return (
    <form
      onSubmit={formik.handleSubmit}
      className="flex-grow flex flex-col justify-between"
    >
      <div>
        <div className="flex items-center justify-between px-5 pb-5 mb-5">
          <label htmlFor="floorName" className="text-[#222222] text-[12px]">
            Floor Name
          </label>
          <div>
            <PrimaryInput
              id="floorName"
              name="floorName"
              className="w-[300px]"
              placeholder="Enter floor name"
              value={formik.values.floorName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.touched.floorName && formik.errors.floorName && (
              <p className="text-red-500 text-xs mt-1">
                {formik.errors.floorName}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-start justify-between px-5">
          <label
            htmlFor="description"
            className="text-[#222222] text-[12px] mt-2"
          >
            Description
            <p className="text-[#939CA7] text-[10px]">(Optional)</p>
          </label>
          <div className="w-[300px]">
            <PrimaryTextarea
              id="description"
              name="description"
              className="w-full h-[82px] resize-none"
              placeholder="Enter description"
              value={formik.values.description}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
          </div>
        </div>
      </div>

      <div className="p-5 flex justify-end border-t border-[#DDDDDD]">
        <PrimaryBtn2
          type="submit"
          className="min-w-20 justify-center"
          disabled={isLoading || !formik.isValid}
        >
          {isLoading ? "Updating..." : "UPDATE"}
        </PrimaryBtn2>
      </div>
    </form>
  );
}

function EditFloorModal({ floorId, toggleModal, onSuccess }) {
  return (
    <BottomRightModal
      toggleModal={toggleModal}
      className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
    >
      <BottomRightModalHeader toggleModal={toggleModal} title="Edit Floor" />
      <EditFloorForm
        floorId={floorId}
        toggleModal={toggleModal}
        onSuccess={onSuccess}
      />
    </BottomRightModal>
  );
}

export default EditFloorModal;
