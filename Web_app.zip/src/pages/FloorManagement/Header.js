import { SearchInput } from "../../components";
import useUserStore from "../../store/useUserStore";
import AddNewFloorModal from "./AddNewFloorModal";

function Header({ onSearchChange }) {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
      <h2 className="text-[#222222] font-bold">Floor Management</h2>
      <div className="flex items-center gap-[15px]">
        <SearchInput
          className="w-[260px]"
          placeholder="Search by floor name, building…"
          onChange={(e) => onSearchChange(e.target.value)}
        />
        {userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.addModify ? (
          <AddNewFloorModal />
        ) : null}
      </div>
    </div>
  );
}

export default Header;
