import { useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  BottomRightModal,
  BottomRightModalHeader,
  PrimaryBtn2,
  PrimaryDropdown,
  PrimaryInput,
  PrimaryTextarea,
  SecondaryBtnLink,
} from "../../components";
import { AddSvg } from "../../assets/svg";
import {
  useGetCampusOptions,
  useGetBuildingOptionsByCampus,
  useCreateFloor,
} from "../../api/queryHooks";
import toaster from "../../utils/toaster";

// Validation schema
const validationSchema = Yup.object({
  campusId: Yup.string().required("Campus is required"),
  buildingId: Yup.string().required("Building is required"),
  name: Yup.string().when(["campusId", "buildingId"], {
    is: (campusId, buildingId) => campusId && buildingId,
    then: (schema) => schema.trim().required("Floor name is required"),
    otherwise: (schema) => schema.notRequired(),
  }),
  floorLevel: Yup.string().when(["campusId", "buildingId"], {
    is: (campusId, buildingId) => campusId && buildingId,
    then: (schema) => schema.required("Floor level is required"),
    otherwise: (schema) => schema.notRequired(),
  }),
  description: Yup.string().optional(),
});

function FloorForm({ toggleModal }) {
  // API hooks
  const { data: campusOptions = [], isLoading: loadingCampuses } =
    useGetCampusOptions();

  const createFloorMutation = useCreateFloor({
    onSuccess: (data) => {
      toggleModal(false);
      formik.resetForm();
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || "Failed to create floor. Please try again.");
      console.error("Error creating floor:", error);
      // formik.setFieldError(
      //   "submit",
      //   "Failed to create floor. Please try again."
      // );
    },
  });

  // Formik setup
  const formik = useFormik({
    initialValues: {
      campusId: "",
      buildingId: "",
      name: "",
      floorLevel: "1",
      description: "",
      floorImage: "base64image",
    },
    validationSchema,
    onSubmit: (values) => {
      // Prepare the payload according to the API requirements
      const floorData = {
        name: values.name,
        floorLevel: values.floorLevel,
        status: "active",
        description: values.description || "",
        floorImage: "https://example.com/images/ground-floor.jpg", // Keep static as requested
      };

      createFloorMutation.mutate({
        buildingId: values.buildingId,
        floorData,
      });
    },
  });

  // Get buildings based on selected campus
  const { data: buildingOptions = [], isLoading: loadingBuildings } =
    useGetBuildingOptionsByCampus(formik.values.campusId);

  // Handle campus change - reset building when campus changes
  const handleCampusChange = (value) => {
    formik.setFieldValue("campusId", value);
    formik.setFieldValue("buildingId", ""); // Reset building selection
    // Also reset floor fields when campus changes
    formik.setFieldValue("name", "");
    formik.setFieldValue("floorLevel", "1");
    formik.setFieldValue("description", "");
  };

  // Handle building change - reset floor fields when building changes
  const handleBuildingChange = (value) => {
    formik.setFieldValue("buildingId", value);
    // Reset floor fields when building changes
    formik.setFieldValue("name", "");
    formik.setFieldValue("floorLevel", "1");
    formik.setFieldValue("description", "");
  };

  // Check if form can be submitted
  const canSubmit = () => {
    if (!formik.values.campusId || !formik.values.buildingId) {
      return false;
    }
    return (
      formik.values.campusId &&
      formik.values.buildingId &&
      formik.values.name.trim() &&
      formik.values.floorLevel &&
      formik.isValid
    );
  };

  return (
    <form
      className="flex-grow flex flex-col justify-between"
      onSubmit={formik.handleSubmit}
    >
      <div>
        <div className="px-5 mb-5 flex items-center justify-between w-full">
          <label htmlFor="campusId" className="text-[#222222] text-[12px]">
            Campus Name:
          </label>
          <div className="w-[300px]">
            <PrimaryDropdown
              className="w-full"
              options={campusOptions}
              value={formik.values.campusId}
              onValueChange={handleCampusChange}
              placeholder="Select Campus"
              disabled={loadingCampuses}
            />
            {formik.touched.campusId && formik.errors.campusId && (
              <span className="text-red-500 text-xs mt-1">
                {formik.errors.campusId}
              </span>
            )}
          </div>
        </div>
        <div className="px-5 pb-5 mb-5 border-b border-[#DDDDDD]">
          <div className="flex items-center justify-between w-full">
            <label htmlFor="buildingId" className="text-[#222222] text-[12px]">
              Building:
            </label>
            <div className="w-[300px]">
              <PrimaryDropdown
                className="w-full"
                options={buildingOptions}
                value={formik.values.buildingId}
                onValueChange={handleBuildingChange}
                placeholder="Select Building"
                disabled={!formik.values.campusId || loadingBuildings}
              />
              {formik.touched.buildingId && formik.errors.buildingId && (
                <span className="text-red-500 text-xs mt-1">
                  {formik.errors.buildingId}
                </span>
              )}
            </div>
          </div>
        </div>
        {/* Show floor name and level only when both campus and building are selected */}
        {formik.values.campusId && formik.values.buildingId && (
          <>
            <div className="flex items-center justify-between px-5 mb-5">
              <label htmlFor="name" className="text-[#222222] text-[12px]">
                Floor Name
              </label>
              <div className="w-[300px]">
                <PrimaryInput
                  className="w-full"
                  placeholder="Enter Floor name"
                  name="name"
                  value={formik.values.name}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.touched.name && formik.errors.name && (
                  <span className="text-red-500 text-xs mt-1">
                    {formik.errors.name}
                  </span>
                )}
              </div>
            </div>
            <div className="flex items-center justify-between px-5">
              <label
                htmlFor="floorLevel"
                className="text-[#222222] text-[12px]"
              >
                Floor Level
              </label>
              <div className="w-[300px]">
                <PrimaryDropdown
                  className="w-[170px]"
                  options={[
                    { value: "1", label: "Level 1" },
                    { value: "2", label: "Level 2" },
                    { value: "3", label: "Level 3" },
                    { value: "4", label: "Level 4" },
                    { value: "5", label: "Level 5" },
                    { value: "6", label: "Level 6" },
                    { value: "7", label: "Level 7" },
                    { value: "8", label: "Level 8" },
                    { value: "9", label: "Level 9" },
                    { value: "10", label: "Level 10" },
                    { value: "11", label: "Level 11" },
                    { value: "12", label: "Level 12" },
                    { value: "13", label: "Level 13" },
                    { value: "14", label: "Level 14" },
                  ]}
                  value={formik.values.floorLevel}
                  onValueChange={(value) =>
                    formik.setFieldValue("floorLevel", value)
                  }
                  placeholder="Select Level"
                />
                {formik.touched.floorLevel && formik.errors.floorLevel && (
                  <span className="text-red-500 text-xs mt-1">
                    {formik.errors.floorLevel}
                  </span>
                )}
              </div>
            </div>
            <div className="flex items-start justify-between px-5 mt-5">
              <label
                htmlFor="description"
                className="text-[#222222] text-[12px] mt-2"
              >
                Description
                <p className="text-[#939CA7] text-[10px]">(Optional)</p>
              </label>
              <div className="w-[300px]">
                <PrimaryTextarea
                  id="description"
                  name="description"
                  className="w-full h-[82px] resize-none"
                  placeholder="Enter description"
                  value={formik.values.description}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.touched.description && formik.errors.description && (
                  <span className="text-red-500 text-xs mt-1">
                    {formik.errors.description}
                  </span>
                )}
              </div>
            </div>
          </>
        )}
        {formik.errors.submit && (
          <div className="px-5 mt-3">
            <span className="text-red-500 text-xs">{formik.errors.submit}</span>
          </div>
        )}
      </div>
      <div className="p-5 flex justify-end border-t border-[#DDDDDD]">
        <PrimaryBtn2
          type="submit"
          className="min-w-20 justify-center"
          disabled={createFloorMutation.isLoading || !canSubmit()}
        >
          {createFloorMutation.isLoading ? "ADDING..." : "ADD"}
        </PrimaryBtn2>
      </div>
    </form>
  );
}

function AddNewFloorModal() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = (value) => {
    setIsOpen(value);
  };

  return (
    <>
      <SecondaryBtnLink
        onClick={() => toggleModal(true)}
        className={"w-[135px] justify-center"}
        Icon={AddSvg}
      >
        NEW FLOOR
      </SecondaryBtnLink>
      {isOpen ? (
        <BottomRightModal
          toggleModal={toggleModal}
          className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
        >
          <BottomRightModalHeader
            toggleModal={toggleModal}
            title="Add New Floor"
          />
          <FloorForm toggleModal={toggleModal} />
        </BottomRightModal>
      ) : null}
    </>
  );
}

export default AddNewFloorModal;
