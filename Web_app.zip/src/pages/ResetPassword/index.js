import { useLocation, Navigate } from "react-router-dom";
import { ResetPasswordForm } from "../../forms";
import LogoXL from "../../assets/images/LogoXL.png";
import { ROUTES } from "../../router";

function ResetPassword() {
  const location = useLocation();
  const email = location.state?.email;
  const verified = location.state?.verified;

  // Redirect to forgot password if no email or not verified
  if (!email || !verified) {
    return <Navigate to={ROUTES.FORGOT_PASSWORD} replace />;
  }
  return (
    <div className="w-full h-full flex justify-center items-center flex-col">
      <img src={LogoXL} alt="Logo" className="h-[52px] w-[195px]" />
      <div className="mt-20 mb-[30px]">
        <h2 className="text-[#222222] font-bold text-2xl text-center">
          Reset Password
        </h2>
      </div>
      <div className="w-full max-w-[360px]">
        <ResetPasswordForm email={email} />
      </div>
    </div>
  );
}

export default ResetPassword;
