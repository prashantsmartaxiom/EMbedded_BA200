import { ForgotPasswordForm } from "../../forms";
import LogoXL from "../../assets/images/LogoXL.png";

function ForgotPassword() {
  return (
    <div className="w-full h-full flex justify-center items-center flex-col py-8">
      <img src={LogoXL} alt="Logo" className="h-[52px] w-[195px]" />
      <div className="mt-8 mb-[30px] max-w-[380px]">
        <h2 className="text-[#222222] font-bold text-2xl text-center">
          Forgot Password
        </h2>
        <p className="text-sm text-[#939CA7] text-center mt-2">
          Enter your email and we’ll send you a link to get back into your
          account.
        </p>
      </div>
      <div className="w-full max-w-[380px]">
        <ForgotPasswordForm />
      </div>
    </div>
  );
}

export default ForgotPassword;
