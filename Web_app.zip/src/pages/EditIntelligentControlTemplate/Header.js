import { Link } from "react-router-dom";
import { BackspaceSvg } from "../../assets/svg";
import { PrimaryBtn2, SecondaryBtn } from "../../components";
import { ROUTES } from "../../router";
import { useState } from "react";
import TemplatePreviewModal from "../IntelligentControlTemplate/TemplatePreviewModal";

function Header({
  templateData,
  onUpdateTemplateClick,
  onSaveAsDraftClick,
  draggedItem,
  isUpdatingTemplate,
}) {
  const [showPreviewModal, setShowPreviewModal] = useState(false);

  const togglePreview = () => {
    setShowPreviewModal(!showPreviewModal);
  };

  const handleClickPreview = () => {
    togglePreview();
  };

  return (
    <div>
      <div className="flex items-center justify-between pb-[15px]">
        <Link
          to={ROUTES.INTELLIGENT_CONTROLS_TEMPLATE}
          className="flex items-center gap-[10px]"
        >
          <BackspaceSvg />
          <h2 className="text-[#222222] font-bold">Edit Template</h2>
        </Link>
        <div className="flex items-center gap-[15px]">
          <SecondaryBtn onClick={handleClickPreview}>PREVIEW</SecondaryBtn>
          <PrimaryBtn2
            onClick={onSaveAsDraftClick}
            className={"w-[135px] justify-center"}
            disabled={
              isUpdatingTemplate || Object.keys(draggedItem).length === 0
            }
          >
            SAVE AS DRAFT
          </PrimaryBtn2>
          <PrimaryBtn2
            onClick={onUpdateTemplateClick}
            className={"w-[80px] justify-center"}
            disabled={
              isUpdatingTemplate ||
              (templateData?.rows && templateData?.columns
                ? Object.keys(draggedItem).length ===
                  templateData?.rows * templateData?.columns
                  ? false
                  : true
                : true)
            }
          >
            UPDATE
          </PrimaryBtn2>
        </div>
      </div>
      <div className="text-sm text-gray-600">
        <span className="font-medium">Template Name:</span> {templateData?.name}
        <span className="ml-4 font-medium">Layout:</span> {templateData?.layout}
        <span className="ml-4 font-medium">Status:</span>
        <span
          className={`ml-1 px-2 py-1 rounded text-xs font-medium ${
            templateData?.status === "Active"
              ? "bg-green-100 text-green-800"
              : "bg-yellow-100 text-yellow-800"
          }`}
        >
          {templateData?.status}
        </span>
      </div>
      <TemplatePreviewModal
        isOpen={showPreviewModal}
        toggleModal={togglePreview}
        template={templateData}
      />
    </div>
  );
}

export default Header;
