import { useState } from "react";
import { Formik, Form } from "formik";
import * as Yup from "yup";
import {
  BottomRightModal,
  BottomRightModalHeader,
  MultiSelectDropdown,
  PrimaryBtn2,
  PrimaryDropdown,
  PrimaryInput,
} from "../../components";
import {
  useGetDeviceOptionsForSensors,
  useGetSensorsByDevice,
  useGetMotions,
  useGetNoMotions,
  useGetSensorById,
  useUpdateSensor,
} from "../../api/queryHooks";
import toaster from "../../utils/toaster";

// Validation schema
const sensorValidationSchema = Yup.object().shape({
  sensorName: Yup.string()
    .required("Sensor Scene name is required"),
  device: Yup.string().required("Device selection is required"),
  sensor: Yup.array()
    .min(1, "At least one sensor must be selected")
    .required("Sensor selection is required"),
  motionScene: Yup.string().required("On Motion scene is required"),
  NoMotionScene: Yup.string().required("No motion scene is required"),
  Trigger_duration: Yup.number()
    .min(0, "Duration must be at least 0 minutes")
    .max(1440, "Duration cannot exceed 1440 minutes")
    .required("Trigger duration is required"),
});

function EditSensorForm({ sensorId, toggleModal }) {
  const [selectedDevice, setSelectedDevice] = useState("");
  
  // API hooks
  const { data: sensorData, isLoading: loadingSensorData } = useGetSensorById(sensorId);
  const { data: deviceOptions = [], isLoading: loadingDevices } = useGetDeviceOptionsForSensors();
  const { data: sensorOptions = [], isLoading: loadingSensors } = useGetSensorsByDevice(selectedDevice);
  const { data: motionOptions = [], isLoading: loadingMotions } = useGetMotions();
  const { data: noMotionOptions = [], isLoading: loadingNoMotions } = useGetNoMotions();
  
  const updateSensorMutation = useUpdateSensor({
    onSuccess: (data) => {
      toggleModal(false);
      toaster.success("Sensor Scene updated successfully");
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || "Error updating sensor");
      console.error("Error updating sensor:", error);
    },
  });

  const selectedDeviceData = deviceOptions?.find((d) => d.value === selectedDevice)?.data;

  const handleSubmit = (values) => {
    const payload = {
      sensorEvent: values.sensorName,
      device: values.device,
      sensor: values.sensor,
      motionScene: values.motionScene,
      NoMotionScene: values.NoMotionScene,
      Trigger_duration: values.Trigger_duration,
      status: "Active",
    };
    
    updateSensorMutation.mutate({ sensorId, sensorData: payload });
  };

  // Get initial values from sensor data
  const getInitialValues = () => {
    if (!sensorData?.data?.sensor) {
      return {
        sensorName: "",
        device: "",
        sensor: [],
        motionScene: "",
        NoMotionScene: "",
        Trigger_duration: 300,
      };
    }

    const sensor = sensorData.data.sensor;
    
    // Set selected device when sensor data is loaded
    if (sensor.device && selectedDevice !== sensor.device) {
      setSelectedDevice(sensor.device);
    }

    return {
      sensorName: sensor.sensorEvent || "",
      device: sensor.device || "",
      sensor: sensor.sensor || [],
      motionScene: sensor.motionScene?.id || sensor.motionScene?._id || "",
      NoMotionScene: sensor.NoMotionScene?.id || sensor.NoMotionScene?._id || "",
      Trigger_duration: sensor.Trigger_duration || 300,
    };
  };

  if (loadingSensorData) {
    return (
      <div className="flex-grow flex items-center justify-center">
        <div className="text-center">
          <div className="text-lg">Loading sensor data...</div>
        </div>
      </div>
    );
  }

  return (
    <Formik
      initialValues={getInitialValues()}
      validationSchema={sensorValidationSchema}
      onSubmit={handleSubmit}
      enableReinitialize={true}
    >
      {({ values, errors, touched, handleChange, handleBlur, setFieldValue }) => (
        <Form className="flex-grow flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between px-5 mb-5">
              <label htmlFor="sensorName" className="text-[#222222] text-[12px]">
                Sensor Scene Name:
              </label>
              <div className="w-[300px]">
                <PrimaryInput
                  name="sensorName"
                  value={values.sensorName}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  placeholder="Enter Sensor Scene name"
                  className={`w-full ${
                    errors.sensorName && touched.sensorName ? "border-red-500" : ""
                  }`}
                />
                {errors.sensorName && touched.sensorName && (
                  <div className="text-red-500 text-xs mt-1">{errors.sensorName}</div>
                )}
              </div>
            </div>

            <div className="px-5 pb-5 mb-5 border-b border-[#DDDDDD]">
              <div className="flex items-center justify-between w-full">
                <label htmlFor="device" className="text-[#222222] text-[12px]">
                  Select Device:
                </label>
                <div className="w-[300px]">
                  <PrimaryDropdown
                    className={`w-full ${
                      errors.device && touched.device ? "border-red-500" : ""
                    }`}
                    options={deviceOptions}
                    value={values.device}
                    onValueChange={(value) => {
                      setFieldValue("device", value);
                      setSelectedDevice(value);
                      setFieldValue("sensor", []); // Reset sensor selection when device changes
                    }}
                    onBlur={handleBlur}
                    placeholder="Select Device"
                    disabled={loadingDevices}
                  />
                  {errors.device && touched.device && (
                    <div className="text-red-500 text-xs mt-1">{errors.device}</div>
                  )}
                </div>
              </div>
            </div>

            {
              selectedDeviceData ? 
                <div className="grid grid-cols-2 gap-x-2 gap-y-[10px] px-5 mb-3">
                  <h3 className="text-[#7A838E] text-xs truncate" title={selectedDeviceData?.location?.campus?.name || "N/A"}>Campus: {selectedDeviceData?.location?.campus?.name || "N/A"}</h3>
                  <h3 className="text-[#7A838E] text-xs truncate" title={selectedDeviceData?.location?.building?.name || "N/A"}>Building: {selectedDeviceData?.location?.building?.name || "N/A"}</h3>
                  <h3 className="text-[#7A838E] text-xs truncate" title={selectedDeviceData?.location?.floor?.name || "N/A"}>Floor: {selectedDeviceData?.location?.floor?.name || "N/A"}</h3>
                  <h3 className="text-[#7A838E] text-xs truncate" title={selectedDeviceData?.location?.zone?.name || "N/A"}>Zone: {selectedDeviceData?.location?.zone?.name || "N/A"}</h3>
                </div>: null
            }

            <div className="flex items-center justify-between px-5 mb-5">
              <label htmlFor="sensor" className="text-[#222222] text-[12px]">
                Sensor Port:
              </label>
              <div className="w-[300px]">
                <MultiSelectDropdown
                  options={sensorOptions.filter(sensor => !sensor.shouldRemoveFromSelection || values.sensor.includes(sensor.value))}
                  placeholder="Select Sensors..."
                  value={values.sensor}
                  onValueChange={(value) => setFieldValue("sensor", value)}
                  className={`w-full ${
                    errors.sensor && touched.sensor ? "border-red-500" : ""
                  }`}
                  disabled={!selectedDevice || loadingSensors}
                />
                {errors.sensor && touched.sensor && (
                  <div className="text-red-500 text-xs mt-1">{errors.sensor}</div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between px-5 mb-5">
              <label htmlFor="motionScene" className="text-[#222222] text-[12px]">
                On Motion:
              </label>
              <div className="w-[300px]">
                <PrimaryDropdown
                  className={`w-full ${
                    errors.motionScene && touched.motionScene ? "border-red-500" : ""
                  }`}
                  options={motionOptions}
                  value={values.motionScene}
                  onValueChange={(value) => {
                    setFieldValue("motionScene", value);
                    const selectedMotion = noMotionOptions.find(option => option.value === value);
                    if (selectedMotion && selectedMotion.operateType === "invert") {
                      setFieldValue("NoMotionScene", value);
                    }
                  }}
                  onBlur={handleBlur}
                  placeholder="Select Action"
                  disabled={loadingMotions}
                  optionType="scene_motion"
                />
                {errors.motionScene && touched.motionScene && (
                  <div className="text-red-500 text-xs mt-1">{errors.motionScene}</div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between px-5 mb-5">
              <label htmlFor="NoMotionScene" className="text-[#222222] text-[12px]">
                No Motion:
              </label>
              <div className="w-[300px]">
                <PrimaryDropdown
                  className={`w-full ${
                    errors.NoMotionScene && touched.NoMotionScene ? "border-red-500" : ""
                  }`}
                  options={noMotionOptions}
                  value={values.NoMotionScene}
                  onValueChange={(value) => setFieldValue("NoMotionScene", value)}
                  onBlur={handleBlur}
                  placeholder="Select Action"
                  disabled={loadingNoMotions}
                  optionType="scene_no_motion"
                />
                {errors.NoMotionScene && touched.NoMotionScene && (
                  <div className="text-red-500 text-xs mt-1">{errors.NoMotionScene}</div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between px-5 mb-5">
              <label htmlFor="Trigger_duration" className="text-[#222222] text-[12px]">
                Triggered Duration:
                <br />
                <span className="text-[#939CA7] text-[10px]">({values.Trigger_duration} minutes)</span>
              </label>
              <div className="w-[300px]">
                <div className="flex items-center border border-[#CCCCCC] rounded-lg overflow-hidden w-[160px]">
                  <button
                    type="button"
                    onClick={() => {
                      const newValue = Math.max(0, values.Trigger_duration - 1);
                      setFieldValue("Trigger_duration", newValue);
                    }}
                    className="w-[40px] px-3 py-2 bg-[#F5F9FD] hover:bg-gray-200 text-[#222222] font-medium border-r border-[#CCCCCC] disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled={values.Trigger_duration <= 0}
                  >
                    -
                  </button>
                  <PrimaryInput
                    name="Trigger_duration"
                    type="number"
                    min={0}
                    max={1440}
                    value={values.Trigger_duration}
                    onChange={(e) => {
                      const value = parseInt(e.target.value) || 0;
                      const clampedValue = Math.min(Math.max(0, value), 1440);
                      setFieldValue("Trigger_duration", clampedValue);
                    }}
                    onBlur={handleBlur}
                    className="flex-1 text-center border-0 outline-none focus:ring-0 rounded-none pl-[20px]"
                    placeholder="0"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const newValue = Math.min(1440, values.Trigger_duration + 1);
                      setFieldValue("Trigger_duration", newValue);
                    }}
                    className="w-[40px] px-3 py-2 bg-[#F5F9FD] hover:bg-gray-200 text-[#222222] font-medium border-l border-[#CCCCCC] disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled={values.Trigger_duration >= 1440}
                  >
                    +
                  </button>
                </div>
                <div className="flex justify-between items-center text-[#939CA7] text-[10px] mt-1 w-[160px]">
                  <span>Min: 0</span>
                  <span>Max: 1440</span>
                </div>
                {errors.Trigger_duration && touched.Trigger_duration && (
                  <div className="text-red-500 text-xs mt-1">{errors.Trigger_duration}</div>
                )}
              </div>
            </div>
          </div>
          <div className="p-5 flex justify-end border-t border-[#DDDDDD]">
            <PrimaryBtn2
              type="submit"
              className="min-w-20 justify-center"
              disabled={updateSensorMutation.isLoading}
            >
              {updateSensorMutation.isLoading ? "UPDATING..." : "UPDATE"}
            </PrimaryBtn2>
          </div>
        </Form>
      )}
    </Formik>
  );
}

function EditSensorModal({ sensorId, toggleModal, onSuccess }) {
  const handleClose = (value) => {
    if (toggleModal) {
      toggleModal(value);
    }
    if (!value && onSuccess) {
      onSuccess();
    }
  };

  return (
    <BottomRightModal
      toggleModal={handleClose}
      className="max-h-[calc(100vh-56px)] h-full w-full max-w-[580px] flex flex-col"
    >
      <BottomRightModalHeader
        toggleModal={handleClose}
        title="Edit Sensor Scene"
      />
      <EditSensorForm sensorId={sensorId} toggleModal={handleClose} />
    </BottomRightModal>
  );
}

export default EditSensorModal;