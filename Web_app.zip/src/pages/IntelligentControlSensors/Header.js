import { SearchInput } from "../../components";
import useUserStore from "../../store/useUserStore";
import AddNewSensorModal from "./AddNewSensorModal";

function Header({ onSearchChange }) {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
      <h2 className="text-[#222222] font-bold">Intelligent Controls</h2>
      <div className="flex items-center gap-[15px]">
        <SearchInput
          className="w-[260px]"
          placeholder="Search by sensor name, group…"
          onChange={(e) => onSearchChange(e.target.value)}
        />
        {userPermissions?.INTELLIGENT_CONTROL?.sensor_management?.addModify ? (
          <AddNewSensorModal />
        ) : null}
      </div>
    </div>
  );
}

export default Header;
