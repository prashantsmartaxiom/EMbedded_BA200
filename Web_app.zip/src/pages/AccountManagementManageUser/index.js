import { useState } from "react";
import AccountUserManagementContent from "./AccountUserManagementContent";
import Header from "./Header";
import { useDebouncedCallback } from "use-debounce";
import useUserStore from "../../store/useUserStore";
import { PermissionDenied } from "../../components";

function AccountManagementManageUser() {
  const userPermissions = useUserStore((state) => state.permissions);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);

  const debouncedSearch = useDebouncedCallback((value) => {
    setSearch(value);
  }, 500);

  if (!userPermissions?.USER_MANAGEMENT?.user_accounts?.readOnly)
    return <PermissionDenied />;

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header onSearchChange={debouncedSearch} />
        <AccountUserManagementContent
          search={search}
          page={page}
          setPage={setPage}
        />
      </div>
    </div>
  );
}

export default AccountManagementManageUser;
