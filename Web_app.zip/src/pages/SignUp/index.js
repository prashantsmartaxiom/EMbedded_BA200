import { SignUpForm } from "../../forms";
import LogoXL from "../../assets/images/LogoXL.png";

function SignUp() {
  return (
    <div className="w-full h-full flex justify-center items-center flex-col py-8">
      <img src={LogoXL} alt="Logo" className="h-[52px] w-[195px]" />
      <div className="mt-8 mb-[30px]">
        <h2 className="text-[#222222] font-bold text-2xl text-center">
          Create New Account
        </h2>
        <p className="text-sm text-[#939CA7] text-center mt-2">
          Register yourself with the organisation to collaborate
        </p>
      </div>
      <div className="w-full max-w-[380px]">
        <SignUpForm />
      </div>
    </div>
  );
}

export default SignUp;
