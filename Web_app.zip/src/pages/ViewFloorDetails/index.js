import { useParams } from "react-router-dom";
import { useGetFloorById } from "../../api/queryHooks";
import {
  AddMoreButton,
  BottomRightModal,
  BottomRightModalHeader,
  PermissionDenied,
  SpinnerV1,
} from "../../components";
import Header from "./Header";
import ViewFloorDetailContent from "./ViewFloorDetailContent";
import ZoneAccordian from "./ZoneAccordian";
import AddZoneFromBuildingForm from "../ViewBuildingDetails/AddZoneFromBuildingForm";
import { useState } from "react";
import useUserStore from "../../store/useUserStore";

function AddNewZone({ floor, building, campus }) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = (value) => {
    setIsOpen(value);
  };

  return (
    <>
      <AddMoreButton onClick={() => toggleModal(true)}>
        MORE ZONES
      </AddMoreButton>
      {isOpen ? (
        <BottomRightModal
          toggleModal={toggleModal}
          className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
        >
          <BottomRightModalHeader
            toggleModal={toggleModal}
            title="Add Zone Floor"
          />
          <AddZoneFromBuildingForm
            toggleModal={toggleModal}
            defaultValues={{
              campusId: campus?._id,
              campusName: campus?.name,
              buildingId: building?._id,
              buildingName: building?.name,
              floorId: floor?._id,
              floorName: floor?.name,
            }}
          />
        </BottomRightModal>
      ) : null}
    </>
  );
}

function ViewFloorDetails() {
  const userPermissions = useUserStore((state) => state.permissions);

  const { id } = useParams();
  const { data, isLoading, error } = useGetFloorById(id);
  const floor = data?.data?.floor;

  if (!userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.readOnly)
    return <PermissionDenied />;

  if (isLoading)
    return (
      <div className="p-5 mt-5">
        <SpinnerV1 />
      </div>
    );
  if (error) return <div className="p-5 mt-5 text-center">Floor not found</div>;
  if (!floor)
    return <div className="p-5 mt-5 text-center">Something went wrong</div>;

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header floor={floor} />
        <ViewFloorDetailContent floor={floor} />
      </div>
      {userPermissions?.CAMPUS_MANAGEMENT?.zone_management?.readOnly ? (
        <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mt-[15px] flex flex-col gap-5">
          {floor?.zones?.map((zone) => {
            const formatedZone = {
              ...zone,
              id: zone._id,
            };
            return <ZoneAccordian key={formatedZone.id} zone={formatedZone} />;
          })}
          {floor?._id ? (
            <div className="flex justify-center">
              {userPermissions?.CAMPUS_MANAGEMENT?.zone_management
                ?.addModify ? (
                <AddNewZone
                  floor={floor}
                  building={floor?.buildingId}
                  campus={floor?.campusId}
                />
              ) : null}
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

export default ViewFloorDetails;
