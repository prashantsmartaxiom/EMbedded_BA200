import { Link } from "react-router-dom";
import { ROUTES } from "../../router";
import { BackspaceSvg, EditSvg } from "../../assets/svg";
import { SecondaryBtn } from "../../components";

import { useState } from "react";
import { DeleteSvg } from "../../assets/svg";
import DeleteFloorPopup from "../../pages/ViewFloorDetails/DeleteFloorPopup";
import EditFloorModal from "../FloorManagement/EditFloorModal";
import useUserStore from "../../store/useUserStore";

function DeleteFloorButton({ floorId }) {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <SecondaryBtn
        className={
          "justify-center fill-[#227EEB] !text-[#FF1212] !border-[#FF1212]"
        }
        onClick={toggleModal}
        iconClassName="fill-[#FF1212]"
        Icon={DeleteSvg}
      >
        DELETE
      </SecondaryBtn>

      {open && <DeleteFloorPopup toggleModal={toggleModal} floorId={floorId} />}
    </>
  );
}

function EditFloorButton({ floorId }) {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <SecondaryBtn
        onClick={toggleModal}
        className={"w-[80px] justify-center fill-[#227EEB]"}
        Icon={EditSvg}
      >
        EDIT
      </SecondaryBtn>

      {open && <EditFloorModal toggleModal={toggleModal} floorId={floorId} />}
    </>
  );
}

function Header({ floor }) {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
      <Link
        to={ROUTES.FLOOR_MANAGEMENT}
        className="flex items-center gap-[10px]"
      >
        <BackspaceSvg />
        <h2 className="text-[#222222] font-bold">View Floor Details</h2>
      </Link>
      <div className="flex items-center gap-[15px]">
        {userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.addModify ? (
          <EditFloorButton floorId={floor?._id} />
        ) : null}
        {userPermissions?.CAMPUS_MANAGEMENT?.floor_management?.delete ? (
          <DeleteFloorButton floorId={floor?._id} />
        ) : null}
      </div>
    </div>
  );
}

export default Header;
