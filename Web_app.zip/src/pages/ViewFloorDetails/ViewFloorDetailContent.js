import { FloorSvg, CopySvg, ZoneSvg } from "../../assets/svg";
import { FloorUpdateStatusDropdown } from "../../components/Cards/FloorCard";
import useUserStore from "../../store/useUserStore";
import { formatDatev1, padStart } from "../../utils/helpers";

function ViewFloorDetailContent({ floor }) {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div>
      <div className="flex items-center gap-5">
        <div className="w-[68px] h-[124px] flex items-center justify-center bg-[#E6F0FC] rounded-[8px] flex-shrink-0">
          <FloorSvg className="fill-[#227EEB] h-[32px] w-[32px]" />
        </div>
        <div className="flex-grow">
          <div className="flex items-center justify-between">
            <h2 className="text-[#222222] font-semibold">{floor?.name}</h2>
            <div className="flex items-center gap-5">
              <button
                type="button"
                className="text-[#7A838E] flex items-center gap-[10px] text-[12px]"
              >
                ID: {floor?._id} <CopySvg />
              </button>
              {userPermissions?.CAMPUS_MANAGEMENT?.floor_management
                ?.addModify ? (
                <FloorUpdateStatusDropdown floor={floor} />
              ) : null}
            </div>
          </div>

          <div className="mt-1 mb-4">
            <div className="flex items-center mb-1">
              <h2 className="text-[#7A838E] text-[12px] w-[80px]">Building:</h2>
              <p className="text-[#222222] text-[12px]">
                {floor?.buildingId?.name}
              </p>
            </div>
            <div className="flex items-center mb-1">
              <h2 className="text-[#7A838E] text-[12px] w-[80px]">Level:</h2>
              <p className="text-[#222222] text-[12px]">{floor?.floorLevel}</p>
            </div>
            <div className="flex items-center">
              <h2 className="text-[#7A838E] text-[12px] w-[80px]">
                Description:
              </h2>
              <p className="text-[#222222] text-[12px]">
                {floor?.description ? floor.description : "-"}
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-5">
              <div className="text-[10px] bg-[#EEEEEE] p-[6px] w-fit min-w-[85px] text-center text-[#222222] rounded-md">
                {floor?.status}
              </div>
              <div className="flex items-center gap-[15px]">
                <button
                  type="button"
                  className="flex items-center gap-[5px] text-[#222222] text-xs"
                >
                  <ZoneSvg /> {padStart(floor?.zoneCount)}
                </button>
              </div>
            </div>

            <button
              type="button"
              className="text-[#7A838E] flex items-center gap-[10px] text-[12px]"
            >
              Added on: {formatDatev1(floor?.createdAt)}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ViewFloorDetailContent;
