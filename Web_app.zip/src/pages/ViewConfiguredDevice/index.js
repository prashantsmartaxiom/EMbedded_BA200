import { useParams } from "react-router-dom";
import { useState, useCallback, useEffect } from "react";
import {
  useGetDeviceChannelsByDeviceId,
  useGetDeviceDetails,
  useUpdateDeviceChannel,
} from "../../api/queryHooks";
import ConfiguredDeviceControlPanel from "./ConfiguredDeviceControlPanel";
import ConfiguredDeviceDetail from "./ConfiguredDeviceDetail";
import Header from "./Header";
import { DeviceStatusChanged, SpinnerV1 } from "../../components";
import toaster from "../../utils/toaster";
import QUERY_KEYS from "../../api/queryKeys";
import { useQueryClient } from "react-query";

function ViewConfiguredDevice() {
  const { id } = useParams();
  const { data, isLoading, error } = useGetDeviceDetails(id);
  const { data: channelsResponseData } = useGetDeviceChannelsByDeviceId(id);
  const queryClient = useQueryClient();
  const [channelStates, setChannelStates] = useState({});

  const { mutate: updateChannel, isLoading: isUpdating } =
    useUpdateDeviceChannel({
      onSuccess: () => {
        // Handle success notification if needed
        queryClient.invalidateQueries([QUERY_KEYS.DEVICE_CHANNELS, id]);
        toaster.success("Channel updated successfully");
      },
      onError: (error) => {
        toaster.error(
          error?.response?.data?.message || "Failed to update channel"
        );
        // Handle error notification if needed
        console.error("Failed to update channel:", error);
      },
    });

  const channels = channelsResponseData?.data?.channels || [];
  const device = data?.data?.device;

  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DEVICE_DETAILS],
      exact: false,
    });
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DEVICE_CHANNELS],
      exact: false,
    });
  };

  // Get merged channels data with current state
  const getMergedChannels = useCallback(() => {
    return channels.map((channel) => {
      const channelState = channelStates[channel.channelId];
      if (channelState) {
        return {
          ...channel,
          ...channelState,
        };
      }
      return channel;
    });
  }, [channels, channelStates]);

  const mergedChannels = getMergedChannels();

  // Initialize channel states when channels data is loaded
  const initializeChannelStates = useCallback(() => {
    const initialStates = {};
    channels.forEach((channel) => {
      // Include all channel types now (sensors, led, shade)
      initialStates[channel.channelId] = {
        name: channel.name,
        installed: channel?.properties?.installed,
        properties: { ...channel.properties },
        status: channel.status,
      };
    });
    setChannelStates(initialStates);
  }, [channels]);

  // Initialize states when channels are loaded
  useEffect(() => {
    if (channels.length > 0) {
      initializeChannelStates();
    }
  }, [channels, initializeChannelStates]);

  const updateChannelState = useCallback((channelId, updates) => {
    setChannelStates((prev) => ({
      ...prev,
      [channelId]: {
        ...prev[channelId],
        ...updates,
      },
    }));
  }, []);

  const submitChannelUpdate = useCallback(
    (channelId, channelData) => {
      updateChannel({
        deviceId: id,
        channelId,
        channelData,
      });
    },
    [channelStates, id, updateChannel]
  );

  if (isLoading)
    return (
      <div className="p-5 mt-5">
        <SpinnerV1 />
      </div>
    );
  if (error)
    return <div className="p-5 mt-5 text-center">Device not found</div>;
  if (!device)
    return (
      <div className="p-5 mt-5 text-center">No device details available</div>
    );

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <DeviceStatusChanged callback={realTimeChangeCallback} />
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header device={device} />
        <ConfiguredDeviceDetail device={device} />
      </div>
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] px-5 pt-2 pb-5 mt-[15px] flex flex-col gap-5">
        {mergedChannels?.length ? (
          <ConfiguredDeviceControlPanel
            device={device}
            main_device={device}
            channels={[...mergedChannels]}
            channelStates={channelStates}
            updateChannelState={updateChannelState}
            submitChannelUpdate={submitChannelUpdate}
            isUpdating={isUpdating}
          />
        ) : (
          <div>No channels available</div>
        )}
      </div>
    </div>
  );
}

export default ViewConfiguredDevice;
