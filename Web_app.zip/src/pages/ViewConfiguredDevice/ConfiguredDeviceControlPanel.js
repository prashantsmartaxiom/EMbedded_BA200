import { LEDSvg, SensorSvg } from "../../assets/svg";
import { LEDCard, SensorCard, ShadeCard } from "../../components";
import { useState } from "react";

const DeviceTabBtn = ({ isActive = false, title, ...props }) => {
  return (
    <button
      type="button"
      className={`flex-shrink-0 text-nowrap border-b-2 h-[50px] -mb-[2px] min-w-[120px] justify-center rounded-t-lg px-[15px] py-[8px] flex items-center gap-[20px] ${
        isActive ? "border-[#227EEB]" : ""
      }`}
      {...props}
    >
      <span
        className={`text-sm ${
          isActive ? "text-[#227EEB]" : "text-[#222222]"
        } font-semibold`}
      >
        {title}
      </span>
    </button>
  );
};

function SensorSection({
  activeCount,
  channels,
  channelStates,
  updateChannelState,
  submitChannelUpdate,
  isUpdating,
  main_device,
}) {
  // Function to chunk array into groups of 8
  const chunkArray = (array, chunkSize) => {
    const chunks = [];
    for (let i = 0; i < array.length; i += chunkSize) {
      chunks.push(array.slice(i, i + chunkSize));
    }
    return chunks;
  };

  const channelChunks = chunkArray(channels, 8);

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <h3 className="flex items-center gap-2 text-[#222222] text-xs font-semibold">
          Channels Count
        </h3>
        <span className="text-[#7A838E] text-xs font-normal">
          {activeCount < 10 ? `0${activeCount}` : activeCount} Active -{" "}
          {channels.length < 10 ? `0${channels.length}` : channels.length}{" "}
          Available
        </span>
      </div>
      {channelChunks.map((chunk, chunkIndex) => (
        <div key={chunkIndex} className="flex items-center gap-4 mb-4">
          {chunk.map((channel, index) => (
            <SensorCard
              key={index}
              sensor={channel}
              isActive={channel.installed}
              channelState={channelStates[channel.channelId]}
              channelStates={channelStates}
              updateChannelState={updateChannelState}
              submitChannelUpdate={submitChannelUpdate}
              isUpdating={isUpdating}
              main_device={main_device}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

function ShadeSection({
  activeCount,
  channels,
  channelStates,
  updateChannelState,
  submitChannelUpdate,
  isUpdating,
  main_device,
}) {
  // Function to chunk array into groups of 8
  const chunkArray = (array, chunkSize) => {
    const chunks = [];
    for (let i = 0; i < array.length; i += chunkSize) {
      chunks.push(array.slice(i, i + chunkSize));
    }
    return chunks;
  };

  const channelChunks = chunkArray(channels, 8);

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <h3 className="flex items-center gap-2 text-[#222222] text-xs font-semibold">
          Channels Count
        </h3>
        <span className="text-[#7A838E] text-xs font-normal">
          {activeCount < 10 ? `0${activeCount}` : activeCount} Active -{" "}
          {channels.length < 10 ? `0${channels.length}` : channels.length}{" "}
          Available
        </span>
      </div>
      {channelChunks.map((chunk, chunkIndex) => (
        <div key={chunkIndex} className="flex items-center gap-4 mb-4">
          {chunk.map((channel, index) => (
            <ShadeCard
              key={index}
              shade={channel}
              isActive={channel.installed}
              channelState={channelStates[channel.channelId]}
              channelStates={channelStates}
              updateChannelState={updateChannelState}
              submitChannelUpdate={submitChannelUpdate}
              isUpdating={isUpdating}
              main_device={main_device}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

function LEDSection({
  activeCount,
  channels,
  channelStates,
  updateChannelState,
  submitChannelUpdate,
  isUpdating,
  main_device,
}) {
  // Function to chunk array into groups of 8
  const chunkArray = (array, chunkSize) => {
    const chunks = [];
    for (let i = 0; i < array.length; i += chunkSize) {
      chunks.push(array.slice(i, i + chunkSize));
    }
    return chunks;
  };

  const channelChunks = chunkArray(channels, 8);

  return (
    <div className="overflow-auto">
      <div className="flex items-center gap-2 mb-4">
        <h3 className="flex items-center gap-2 text-[#222222] text-xs font-semibold">
          Channels Count
        </h3>
        <span className="text-[#7A838E] text-xs font-normal">
          {activeCount < 10 ? `0${activeCount}` : activeCount} Active -{" "}
          {channels.length < 10 ? `0${channels.length}` : channels.length}{" "}
          Available
        </span>
      </div>
      {channelChunks.map((chunk, chunkIndex) => (
        <div key={chunkIndex} className="flex items-center gap-4 mb-4">
          {chunk.map((channel, index) => (
            <LEDCard
              key={index}
              device={channel}
              isActive={channel.installed}
              channelState={channelStates[channel.channelId]}
              channelStates={channelStates}
              updateChannelState={updateChannelState}
              submitChannelUpdate={submitChannelUpdate}
              isUpdating={isUpdating}
              main_device={main_device}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

function ConfiguredDeviceControlPanel({
  channels,
  channelStates,
  updateChannelState,
  submitChannelUpdate,
  isUpdating,
  main_device,
}) {
  // Group channels by type
  const channelsByType = channels.reduce((acc, channel) => {
    if (!acc[channel.type]) {
      acc[channel.type] = [];
    }
    acc[channel.type].push(channel);
    return acc;
  }, {});

  // Get available channel types with custom ordering for BA-200
  const getOrderedAvailableTypes = () => {
    const types = Object.keys(channelsByType);
    
    // For BA-200 devices, use custom ordering to place PIR next to Shades
    if (main_device?.type?.toLowerCase() === "ba-200") {
      const preferredOrder = [
        "led",
        "shade",
        "io_pir",
        "sensor",
        "expansion_led", 
        "expansion_color_lights",
        "rtu_CO2", 
        "rtu_light_sensor",
        "rtu_HMI"
      ];
      
      // Sort available types according to preferred order
      const orderedTypes = [];
      
      // Add types in preferred order if they exist
      preferredOrder.forEach(type => {
        if (types.includes(type)) {
          orderedTypes.push(type);
        }
      });
      
      // Add any remaining types that weren't in the preferred order
      types.forEach(type => {
        if (!orderedTypes.includes(type)) {
          orderedTypes.push(type);
        }
      });
      
      return orderedTypes;
    }
    
    // For non-BA-200 devices, return original order
    return types;
  };

  const availableTypes = getOrderedAvailableTypes();

  // Create tab configuration with proper display names
  const getTabDisplayName = (type) => {
    const displayNames = {
      led: "LED Channels",
      shade: "Shades",
      sensor: "Sensors",
      expansion_led: "Expansion LED",
      expansion_color_lights: "Expansion Color Lights",
      rtu_light_sensor: "Light Sensors",
      rtu_CO2: "CO2",
      rtu_HMI: "HMI",
      io_pir: "PIR",
    };
    return (
      displayNames[type] || type.charAt(0).toUpperCase() + type.slice(1) + "s"
    );
  };

  const [state, setState] = useState({
    tab: availableTypes.length > 0 ? availableTypes[0] : null,
  });

  const handleTabClick = (tab) => {
    setState({ tab });
  };

  // Render section based on type
  const renderSection = (type, channels) => {
    const activeCount = channels.filter((channel) => channel.installed).length;
    const commonProps = {
      activeCount,
      channels,
      channelStates,
      updateChannelState,
      submitChannelUpdate,
      isUpdating,
      main_device,
    };

    switch (type) {
      case "led":
      case "expansion_led":
      case "expansion_color_lights":
        return <LEDSection {...commonProps} />;
      case "shade":
        return <ShadeSection {...commonProps} />;
      case "sensor":
      case "rtu_light_sensor":
      case "rtu_CO2":
      case "rtu_HMI":
      case "io_pir":
        return <SensorSection {...commonProps} />;
      default:
        // For any new channel types, use a generic section
        const chunkArray = (array, chunkSize) => {
          const chunks = [];
          for (let i = 0; i < array.length; i += chunkSize) {
            chunks.push(array.slice(i, i + chunkSize));
          }
          return chunks;
        };

        const channelChunks = chunkArray(channels, 8);

        return (
          <div>
            <div className="flex items-center gap-2 mb-4">
              <h3 className="flex items-center gap-2 text-[#222222] text-xs font-semibold">
                Channels Count
              </h3>
              <span className="text-[#7A838E] text-xs font-normal">
                {activeCount < 10 ? `0${activeCount}` : activeCount} Active -{" "}
                {channels.length < 10 ? `0${channels.length}` : channels.length}{" "}
                Available
              </span>
            </div>
            {channelChunks.map((chunk, chunkIndex) => (
              <div key={chunkIndex} className="flex items-center gap-4 mb-4">
                {chunk.map((channel, index) => (
                  <div key={index} className="p-4 border rounded">
                    {channel.name || `Channel ${channel.channelId}`}
                  </div>
                ))}
              </div>
            ))}
          </div>
        );
    }
  };

  return (
    <>
      <div className="flex-wrap flex items-center border-b-2 border-[#DDDDDD]">
        {availableTypes.map((type) => (
          <DeviceTabBtn
            key={type}
            isActive={state.tab === type}
            title={getTabDisplayName(type)}
            onClick={() => handleTabClick(type)}
          />
        ))}
      </div>
      {/* <div className=""> */}
        {state.tab &&
          channelsByType[state.tab] &&
          renderSection(state.tab, channelsByType[state.tab])}
      {/* </div> */}
    </>
  );
}

export default ConfiguredDeviceControlPanel;
