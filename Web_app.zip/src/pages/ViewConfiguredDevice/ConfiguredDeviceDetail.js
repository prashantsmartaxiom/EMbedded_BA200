import { ChipSvg, CopySvg, MdArrowDownSvg } from "../../assets/svg";
import { PermissionDenied, SuccessBadge, WarningBadge } from "../../components";
import useUserStore from "../../store/useUserStore";

function ConfiguredDeviceDetail({ device }) {
  const userPermissions = useUserStore((state) => state.permissions);

  if (!userPermissions?.DEVICE_MANAGEMENT?.device_control?.readOnly)
    return (
      <PermissionDenied
        className="p-6 text-center"
        text="You do not have permission to view device configurations."
      />
    );

  return (
    <div className="flex items-center gap-5">
      <div className="bg-[#E6F0FC] w-[140px] h-[140px] flex-shrink-0 rounded-lg flex items-center justify-center">
        <ChipSvg className="w-9 h-9 fill-[#227EEB]" />
      </div>
      <div className="flex-grow">
        <div className="flex items-center justify-between">
          <h2 className="text-[#222222] font-semibold">
            {device?.device_name}
          </h2>
          <div className="text-xs text-[#7A838E] flex items-center gap-[10px] h-full">
            <button
              type="button"
              className="text-[#7A838E] flex items-center gap-[10px]"
            >
              MAC Address: {device?.mac_address} <CopySvg />
            </button>
            {device?.status === "Active" ? (
              <SuccessBadge title={device?.status} />
            ) : (
              <WarningBadge title={device?.status} />
            )}
          </div>
        </div>

        <div className="mt-4 mb-4">
          <div className="grid grid-cols-4 gap-x-8 gap-y-2 text-xs overflow-auto">
            <div className="flex flex-wrap">
              <span className="text-[#7A838E] text-xs w-20">Device ID:</span>
              <span className="text-[#222222] text-xs">
                {device?.device_id}
              </span>
            </div>
            <div className="flex flex-wrap">
              <span className="text-[#7A838E] text-xs w-20">Port:</span>
              <span className="text-[#222222] text-xs">{device?.port}</span>
            </div>
            <div className="flex flex-wrap">
              <span className="text-[#7A838E] text-xs w-20">Campus:</span>
              <span className="text-[#222222] text-xs">
                {device?.location?.campus?.name}
              </span>
            </div>

            <div className="flex flex-wrap">
              <span className="text-[#7A838E] text-xs w-20">Building:</span>
              <span className="text-[#222222] text-xs">
                {device?.location?.building?.name}
              </span>
            </div>

            <div className="flex flex-wrap">
              <span className="text-[#7A838E] text-xs w-20">Serial No.:</span>
              <span className="text-[#222222] text-xs">
                {device?.serial_number}
              </span>
            </div>

            <div className="flex flex-wrap">
              <span className="text-[#7A838E] text-xs w-20">Firmware:</span>
              <span className="text-[#222222] text-xs">
                {device?.firmware || "N/A"}
              </span>
            </div>

            <div className="flex flex-wrap">
              <span className="text-[#7A838E] text-xs w-20">Floor:</span>
              <span className="text-[#222222] text-xs">
                {device?.location?.floor?.name}
              </span>
            </div>
            <div className="flex flex-wrap">
              <span className="text-[#7A838E] text-xs w-20">Zone:</span>
              <span className="text-[#222222] text-xs">
                {device?.location?.zone?.name}
              </span>
            </div>
            <div className="flex flex-wrap">
              <span className="text-[#7A838E] text-xs w-20">Description:</span>
              <span className="text-[#7A838E] text-xs">
                {device?.description}
              </span>
            </div>
          </div>
        </div>

        <div>
          <div className="text-[10px] bg-[#EEEEEE] p-[6px] w-fit min-w-[85px] text-center text-[#222222] rounded-md">
            {device?.type}
          </div>
        </div>
      </div>
    </div>
  );
}

export default ConfiguredDeviceDetail;
