import { Link } from "react-router-dom";
import {
  BackspaceSvg,
  DeleteSvg,
  EditSvg,
  RebootDeviceSvg,
} from "../../assets/svg";
import { SecondaryBtn } from "../../components";
import { ROUTES } from "../../router";
import DeleteConfiguredDevicePopup from "./DeleteConfiguredDevicePopup";
import EditConfiguredDeviceModal from "./EditConfiguredDeviceModal";
import { useState } from "react";
import { useTriggerEvent } from "../../api/queryHooks";
import toaster from "../../utils/toaster";
import useUserStore from "../../store/useUserStore";

const DeleteDevice = ({ device }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <SecondaryBtn
        to={ROUTES.NEW_CAMPUS}
        className={
          "justify-center fill-[#227EEB] !text-[#FF1212] !border-[#FF1212]"
        }
        iconClassName="fill-[#FF1212]"
        Icon={DeleteSvg}
        onClick={toggleModal}
      >
        DELETE
      </SecondaryBtn>
      {open ? (
        <DeleteConfiguredDevicePopup
          toggleModal={toggleModal}
          device_id={device._id}
          device={device}
        />
      ) : null}
    </>
  );
};

const EditDevice = ({ device }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <SecondaryBtn
        className={"w-[80px] justify-center fill-[#227EEB]"}
        Icon={EditSvg}
        onClick={toggleModal}
      >
        EDIT
      </SecondaryBtn>
      {open ? (
        <EditConfiguredDeviceModal device={device} onClose={toggleModal} />
      ) : null}
    </>
  );
};

const RebootDevice = ({ device }) => {
  const { mutate: triggerEvent, isLoading } = useTriggerEvent();

  const handleClick = () => {
    const payload = {
      device_id: device.device_id,
      type: "reboot",
    };

    triggerEvent(payload, {
      onSuccess: () => {
        // onSuccess logic here
        toaster.success("Device reboot successfully");
      },
      onError: (error) => {
        // onError logic here
        toaster.error(
          error?.response?.data?.message || "Failed to send reboot command"
        );
      },
    });
  };

  return (
    <SecondaryBtn
      Icon={() => (
        <RebootDeviceSvg className={isLoading ? "animate-spin" : ""} />
      )}
      disabled={isLoading}
      onClick={handleClick}
    >
      Reboot
    </SecondaryBtn>
  );
};

function Header({ device }) {
  const userPermissions = useUserStore((state) => state.permissions);
  const isExternalDevice =
    device?.type?.toLowerCase() === "shade_lutron";

  return (
    <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
      <Link to={-1} className="flex items-center gap-[10px]">
        <BackspaceSvg />
        <h2 className="text-[#222222] font-bold">Device Details</h2>
      </Link>
      <div className="flex items-center gap-[15px]">
        {userPermissions?.DEVICE_MANAGEMENT?.device_control?.addModify ? (
          <>
            <EditDevice device={device} />
            {!isExternalDevice ? <RebootDevice device={device} /> : null}
            <DeleteDevice device={device} />
          </>
        ) : null}
      </div>
    </div>
  );
}

export default Header;
