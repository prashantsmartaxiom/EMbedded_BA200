import { WarningSvg } from "../../assets/svg";
import { SecondaryBtn } from "../../components";
import { CenterModal } from "../../components/Models";
import { useNavigate } from "react-router-dom";
import { ROUTES } from "../../router";
import { useDeleteConfiguredDevice, useDeleteThirdPartyDevice } from "../../api/queryHooks";
import toaster from "../../utils/toaster";

function DeleteConfiguredDevicePopup({
  toggleModal,
  device_id,
  device,
  onSuccess,
  navigateToRoute = ROUTES.DEVICE_CONTROL,
}) {
  const navigate = useNavigate();

  // Check if device is external (shade_lutron type)
  const isExternalDevice = 
    device?.device_type?.toLowerCase() === "shade_lutron" ||
    device?.type?.toLowerCase() === "shade_lutron";

  const { mutate: deleteConfiguredDevice, isLoading: isLoadingRegular } =
    useDeleteConfiguredDevice({
      onSuccess: () => {
        toaster.success("Device deleted successfully");
        toggleModal();
        if (navigateToRoute) navigate(navigateToRoute);
        onSuccess?.();
      },
      onError: (error) => {
        toaster.error(error?.response?.data?.message || "Failed to delete device");
      },
    });

  const { mutate: deleteThirdPartyDevice, isLoading: isLoadingThirdParty } =
    useDeleteThirdPartyDevice({
      onSuccess: () => {
        toaster.success("Third-party device deleted successfully");
        toggleModal();
        if (navigateToRoute) navigate(navigateToRoute);
        onSuccess?.();
      },
      onError: (error) => {
        toaster.error(error?.response?.data?.message || "Failed to delete third-party device");
      },
    });

  const isLoading = isLoadingRegular || isLoadingThirdParty;

  const handleDelete = () => {
    if (isExternalDevice) {
      deleteThirdPartyDevice(device_id);
    } else {
      deleteConfiguredDevice(device_id);
    }
  };

  return (
    <CenterModal
      toggleModal={toggleModal}
      className="max-w-[460px] w-full p-8 flex flex-col items-center gap-6"
    >
      <div>
        <WarningSvg className="text-[54px] text-[#FF1212]" />
      </div>
      <div className="text-center">
        <h3 className="text-base font-semibold">Are you sure?</h3>
        <p className="text-sm text-[#939CA7] mt-3">
          Do you really want to delete the device?
          <br />
          This process cannot be undone.
        </p>
      </div>

      <div className="flex items-center gap-[10px]">
        <SecondaryBtn
          onClick={toggleModal}
          disabled={isLoading}
          className={
            "justify-center !bg-[#AAAAAA] !border-none !text-white min-w-20"
          }
        >
          CANCEL
        </SecondaryBtn>
        <SecondaryBtn
          onClick={handleDelete}
          disabled={isLoading}
          className={
            "justify-center !bg-[#FF1212] !border-none !text-white min-w-20"
          }
        >
          {isLoading ? "DELETING..." : "DELETE"}
        </SecondaryBtn>
      </div>
    </CenterModal>
  );
}

export default DeleteConfiguredDevicePopup;
