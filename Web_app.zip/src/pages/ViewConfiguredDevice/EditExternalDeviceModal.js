import { useFormik } from "formik";
import * as Yup from "yup";
import {
  useUpdateThirdPartyDevice,
  useGetCampusOptions,
  useGetBuildingOptionsByCampus,
  useGetFloorsOptionsByBuilding,
  useGetZonesOptionsByFloor,
} from "../../api/queryHooks";
import {
  BottomRightModal,
  BottomRightModalHeader,
  PrimaryBtn2,
  PrimaryDropdown,
  PrimaryInput,
  PrimaryTextarea,
} from "../../components";
import toaster from "../../utils/toaster";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../api/queryKeys";

const deviceTypeOptions = [
  { label: "Shade", value: "Shade" },
  { label: "LED", value: "LED" },
];

const validationSchema = Yup.object({
  campus_id: Yup.string().required("Campus is required"),
  building_id: Yup.string().required("Building is required"),
  floor_id: Yup.string().required("Floor is required"),
  zone_id: Yup.string().required("Zone is required"),
  deviceName: Yup.string().required("Device name is required"),
  deviceType: Yup.string().required("Device type is required"),
  brand: Yup.string().required("Brand is required"),
  deviceNumber: Yup.number()
    .min(1, "Device number must be at least 1")
    .required("Device number is required"),
  firmware: Yup.string().required("Firmware is required"),
  gatewayIP: Yup.string()
    .matches(
      /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
      "Please enter a valid IP address"
    )
    .required("Gateway IP is required"),
  gatewayPort: Yup.number()
    .min(1, "Gateway port must be at least 1")
    .max(65535, "Gateway port must be less than 65536")
    .required("Gateway port is required"),
  description: Yup.string().optional(),
});

function EditExternalDeviceForm({ device, onClose }) {
  const queryClient = useQueryClient();

  // API hooks for dropdowns
  const { data: campusOptions = [], isLoading: loadingCampuses } =
    useGetCampusOptions();

  const { mutate: updateDevice, isLoading } = useUpdateThirdPartyDevice({
    onSuccess: () => {
      queryClient.invalidateQueries([QUERY_KEYS.DISCOVERY_DEVICES]);
      queryClient.invalidateQueries([QUERY_KEYS.CONFIGURED_DEVICES]);
      if (onClose) onClose();
      toaster.success("External device updated successfully!");
    },
    onError: (error) => {
      const errorMessage =
        error.response?.data?.message || "Device update failed";
      toaster.error(errorMessage);
    },
  });

  // Parse existing device data for form initialization
  const parseDeviceData = (device) => {
    // Extract device type and brand from device_id (format: DeviceType_Brand_Number)
    const deviceIdParts = device.device_id?.split("_") || [];
    const deviceType = deviceIdParts[0] || "";
    const brand = deviceIdParts[1] || "";
    const deviceNumber = deviceIdParts[2] || "";

    // Extract gateway IP and port from Mac_addr (format: IP_Port)
    const macAddrParts = device.mac_address?.split("_") || [];
    const gatewayIP = macAddrParts[0] || "";
    const gatewayPort = macAddrParts[1] || "";

    return {
      campus_id: device?.location?.campus?.id || "",
      building_id: device?.location?.building?.id || "",
      floor_id: device?.location?.floor?.id || "",
      zone_id: device?.location?.zone?.id || "",
      deviceName: device?.device_name || "",
      deviceType: deviceType,
      brand: brand,
      deviceNumber: deviceNumber,
      firmware: device?.firmware || "",
      gatewayIP: gatewayIP,
      gatewayPort: gatewayPort,
      description: device?.description || "",
    };
  };

  const formik = useFormik({
    initialValues: parseDeviceData(device),
    validationSchema,
    onSubmit: (values) => {
      const payload = {
        device_id: `${values.deviceType}_${values.brand}_${values.deviceNumber}`,
        SNO: Number(values.deviceNumber),
        firmware: values.firmware,
        Mac_addr: `${values.gatewayIP}_${values.gatewayPort}`,
        status: device?.status || "Inactive",
        description: values.description,
        name: values.deviceName,
        configure_flag: device?.configure_flag || 0,
        type: `${values.deviceType}_${values.brand}`.toLowerCase(),
        campus: values.campus_id,
        building: values.building_id,
        floor: values.floor_id,
        zone: values.zone_id,
        capabilities: device?.capabilities || [
          {
            type: "shade",
            channelId: "1",
            name: "Unnamed",
            status: "off",
            properties: {},
          },
        ],
      };

      updateDevice({
        deviceId: device.device_id,
        deviceData: payload,
      });
    },
  });

  // Fetch buildings when campus changes
  const { data: buildingOptions = [], isLoading: loadingBuildings } =
    useGetBuildingOptionsByCampus(formik.values.campus_id);

  // Fetch floors when building changes
  const { data: floorOptions = [], isLoading: loadingFloors } =
    useGetFloorsOptionsByBuilding(formik.values.building_id);

  // Fetch zones when floor changes
  const { data: zoneOptions = [], isLoading: loadingZones } =
    useGetZonesOptionsByFloor(formik.values.floor_id);

  // Handle campus change
  const handleCampusChange = (value) => {
    formik.setFieldValue("campus_id", value);
    formik.setFieldValue("building_id", "");
    formik.setFieldValue("floor_id", "");
    formik.setFieldValue("zone_id", "");
  };

  // Handle building change
  const handleBuildingChange = (value) => {
    formik.setFieldValue("building_id", value);
    formik.setFieldValue("floor_id", "");
    formik.setFieldValue("zone_id", "");
  };

  // Handle floor change
  const handleFloorChange = (value) => {
    formik.setFieldValue("floor_id", value);
    formik.setFieldValue("zone_id", "");
  };

  // Check if form can be submitted
  const canSubmit = () => {
    return (
      formik.values.campus_id &&
      formik.values.building_id &&
      formik.values.floor_id &&
      formik.values.zone_id &&
      formik.values.deviceName.trim() &&
      formik.values.deviceType &&
      formik.values.brand.trim() &&
      formik.values.deviceNumber &&
      formik.values.firmware.trim() &&
      formik.values.gatewayIP.trim() &&
      formik.values.gatewayPort &&
      formik.isValid
    );
  };

  return (
    <form
      onSubmit={formik.handleSubmit}
      className="flex-grow flex flex-col min-h-0"
    >
      <div className="overflow-auto flex-grow">
        <div className="space-y-5">
          {/* Device ID Display */}
          <div className="flex items-center justify-between px-5">
            <label className="text-[#222222] text-[12px]">Device ID</label>
            <div className="w-[300px] text-[#222222] text-[12px]">
              {device?.device_id}{" "}
              <span className="text-[#AAAAAA]">
                ({device?.type || "Unknown"})
              </span>
            </div>
          </div>

          {/* Campus Dropdown */}
          <div className="flex items-center justify-between px-5">
            <label htmlFor="campus_id" className="text-[#222222] text-[12px]">
              Campus
            </label>
            <div className="w-[300px]">
              <PrimaryDropdown
                className="w-full"
                options={campusOptions}
                value={formik.values.campus_id}
                onValueChange={handleCampusChange}
                onBlur={() => formik.setFieldTouched("campus_id", true)}
                placeholder={loadingCampuses ? "Loading..." : "Select Campus"}
                disabled={loadingCampuses}
              />
              {formik.touched.campus_id && formik.errors.campus_id && (
                <p className="text-red-500 text-xs mt-1">
                  {formik.errors.campus_id}
                </p>
              )}
            </div>
          </div>

          {/* Building Dropdown */}
          {formik.values.campus_id && (
            <div className="flex items-center justify-between px-5">
              <label
                htmlFor="building_id"
                className="text-[#222222] text-[12px]"
              >
                Building
              </label>
              <div className="w-[300px]">
                <PrimaryDropdown
                  className="w-full"
                  options={buildingOptions}
                  value={formik.values.building_id}
                  onValueChange={handleBuildingChange}
                  onBlur={() => formik.setFieldTouched("building_id", true)}
                  placeholder={
                    loadingBuildings ? "Loading..." : "Select Building"
                  }
                  disabled={loadingBuildings || !formik.values.campus_id}
                />
                {formik.touched.building_id && formik.errors.building_id && (
                  <p className="text-red-500 text-xs mt-1">
                    {formik.errors.building_id}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Floor Dropdown */}
          {formik.values.building_id && (
            <div className="flex items-center justify-between px-5">
              <label htmlFor="floor_id" className="text-[#222222] text-[12px]">
                Floor
              </label>
              <div className="w-[300px]">
                <PrimaryDropdown
                  className="w-full"
                  options={floorOptions}
                  value={formik.values.floor_id}
                  onValueChange={handleFloorChange}
                  onBlur={() => formik.setFieldTouched("floor_id", true)}
                  placeholder={loadingFloors ? "Loading..." : "Select Floor"}
                  disabled={loadingFloors || !formik.values.building_id}
                />
                {formik.touched.floor_id && formik.errors.floor_id && (
                  <p className="text-red-500 text-xs mt-1">
                    {formik.errors.floor_id}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Zone Dropdown */}
          {formik.values.floor_id && (
            <div className="flex items-center justify-between px-5 pb-5 border-b border-[#DDDDDD]">
              <label htmlFor="zone_id" className="text-[#222222] text-[12px]">
                Zone
              </label>
              <div className="w-[300px]">
                <PrimaryDropdown
                  className="w-full"
                  options={zoneOptions}
                  value={formik.values.zone_id}
                  onValueChange={(value) =>
                    formik.setFieldValue("zone_id", value)
                  }
                  onBlur={() => formik.setFieldTouched("zone_id", true)}
                  placeholder={loadingZones ? "Loading..." : "Select Zone"}
                  disabled={loadingZones || !formik.values.floor_id}
                />
                {formik.touched.zone_id && formik.errors.zone_id && (
                  <p className="text-red-500 text-xs mt-1">
                    {formik.errors.zone_id}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Device configuration fields - only show when zone is selected */}
          {formik.values.zone_id && (
            <>
              {/* Device Name */}
              <div className="flex items-center justify-between px-5">
                <label
                  htmlFor="deviceName"
                  className="text-[#222222] text-[12px]"
                >
                  Device Name
                </label>
                <div className="w-[300px]">
                  <PrimaryInput
                    id="deviceName"
                    name="deviceName"
                    className="w-full"
                    placeholder="Enter device name"
                    value={formik.values.deviceName}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.touched.deviceName && formik.errors.deviceName && (
                    <p className="text-red-500 text-xs mt-1">
                      {formik.errors.deviceName}
                    </p>
                  )}
                </div>
              </div>

              {/* Device Type */}
              <div className="flex items-center justify-between px-5">
                <label
                  htmlFor="deviceType"
                  className="text-[#222222] text-[12px]"
                >
                  Device Type
                </label>
                <div className="w-[300px]">
                  <PrimaryDropdown
                    className="w-full"
                    options={deviceTypeOptions}
                    value={formik.values.deviceType}
                    onValueChange={(value) =>
                      formik.setFieldValue("deviceType", value)
                    }
                    placeholder="Select Device Type"
                  />
                  {formik.touched.deviceType && formik.errors.deviceType && (
                    <p className="text-red-500 text-xs mt-1">
                      {formik.errors.deviceType}
                    </p>
                  )}
                </div>
              </div>

              {/* Brand */}
              <div className="flex items-center justify-between px-5">
                <label htmlFor="brand" className="text-[#222222] text-[12px]">
                  Brand
                </label>
                <div className="w-[300px]">
                  <PrimaryInput
                    id="brand"
                    name="brand"
                    className="w-full"
                    placeholder="Enter brand name"
                    value={formik.values.brand}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.touched.brand && formik.errors.brand && (
                    <p className="text-red-500 text-xs mt-1">
                      {formik.errors.brand}
                    </p>
                  )}
                </div>
              </div>

              {/* Device Number (S No.) */}
              <div className="flex items-center justify-between px-5">
                <label
                  htmlFor="deviceNumber"
                  className="text-[#222222] text-[12px]"
                >
                  Device Number (S No.)
                </label>
                <div className="w-[300px]">
                  <PrimaryInput
                    id="deviceNumber"
                    name="deviceNumber"
                    type="number"
                    min="1"
                    className="w-full"
                    placeholder="Enter device number"
                    value={formik.values.deviceNumber}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.touched.deviceNumber &&
                    formik.errors.deviceNumber && (
                      <p className="text-red-500 text-xs mt-1">
                        {formik.errors.deviceNumber}
                      </p>
                    )}
                </div>
              </div>

              {/* Firmware */}
              <div className="flex items-center justify-between px-5">
                <label
                  htmlFor="firmware"
                  className="text-[#222222] text-[12px]"
                >
                  Firmware
                </label>
                <div className="w-[300px]">
                  <PrimaryInput
                    id="firmware"
                    name="firmware"
                    className="w-full"
                    placeholder="Enter firmware version"
                    value={formik.values.firmware}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.touched.firmware && formik.errors.firmware && (
                    <p className="text-red-500 text-xs mt-1">
                      {formik.errors.firmware}
                    </p>
                  )}
                </div>
              </div>

              {/* Gateway IP */}
              <div className="flex items-center justify-between px-5">
                <label
                  htmlFor="gatewayIP"
                  className="text-[#222222] text-[12px]"
                >
                  Gateway IP
                </label>
                <div className="w-[300px]">
                  <PrimaryInput
                    id="gatewayIP"
                    name="gatewayIP"
                    className="w-full"
                    placeholder="Enter gateway IP (e.g., 192.168.1.1)"
                    value={formik.values.gatewayIP}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.touched.gatewayIP && formik.errors.gatewayIP && (
                    <p className="text-red-500 text-xs mt-1">
                      {formik.errors.gatewayIP}
                    </p>
                  )}
                </div>
              </div>

              {/* Gateway Port */}
              <div className="flex items-center justify-between px-5">
                <label
                  htmlFor="gatewayPort"
                  className="text-[#222222] text-[12px]"
                >
                  Gateway Port
                </label>
                <div className="w-[300px]">
                  <PrimaryInput
                    id="gatewayPort"
                    name="gatewayPort"
                    type="number"
                    min="1"
                    max="65535"
                    className="w-full"
                    placeholder="Enter gateway port (1-65535)"
                    value={formik.values.gatewayPort}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.touched.gatewayPort && formik.errors.gatewayPort && (
                    <p className="text-red-500 text-xs mt-1">
                      {formik.errors.gatewayPort}
                    </p>
                  )}
                </div>
              </div>

              {/* Description */}
              <div className="flex items-start justify-between px-5">
                <label
                  htmlFor="description"
                  className="text-[#222222] text-[12px] mt-2"
                >
                  Description
                  <p className="text-[#939CA7] text-[10px]">(Optional)</p>
                </label>
                <div className="w-[300px]">
                  <PrimaryTextarea
                    id="description"
                    name="description"
                    className="w-full h-[82px] resize-none"
                    placeholder="Enter description"
                    value={formik.values.description}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      <div className="p-5 flex justify-end border-t border-[#DDDDDD]">
        <PrimaryBtn2
          type="submit"
          className="min-w-20 justify-center"
          disabled={isLoading || !canSubmit()}
        >
          {isLoading ? "UPDATING..." : "UPDATE"}
        </PrimaryBtn2>
      </div>
    </form>
  );
}

function EditExternalDeviceModal({ device, onClose }) {
  const toggleModal = (value) => {
    if (value === false && onClose) onClose();
  };

  if (!device) return null;

  return (
    <BottomRightModal
      toggleModal={toggleModal}
      className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
    >
      <BottomRightModalHeader
        toggleModal={toggleModal}
        title="Edit External Device"
      />
      <EditExternalDeviceForm device={device} onClose={onClose} />
    </BottomRightModal>
  );
}

export default EditExternalDeviceModal;
