import { useState, useCallback } from "react";
import { useQueryClient } from "react-query";
import {
  useGetDeviceChannelsByDeviceId,
  useTriggerEvent,
} from "../../api/queryHooks";
import { BottomRightModal, CurtainSvg, DeviceStatusChanged, RangeSlider } from "../../components";
import {
  CircleCrossSvg,
  LEDSvg,
  LEDonSvg,
  MdArrowDownSvg,
  SensorSvg,
  StopSvg,
  ShadeSSSvg,
  ShadeTTSvg,
} from "../../assets/svg";
import QUERY_KEYS from "../../api/queryKeys";
import useUserStore from "../../store/useUserStore";
import toaster from "../../utils/toaster";

const LEDCard = ({
  channel,
  onLEDToggle,
  onLEDBrightnessChange,
  onLEDBrightnessCommit,
  channelStates,
}) => {
  const currentState =
    channelStates[`${channel.deviceId}-${channel.channelId}`] || channel;
  const isOn = currentState.status === "on";
  const brightness = parseInt(currentState.properties?.brightness || 0);
  const powerMin = 0;
  const powerMax = 100;
  // const powerMin = parseInt(currentState.properties?.powerMin || 0);
  // const powerMax = parseInt(currentState.properties?.powerMax || 100);

  return (
    <div className="flex flex-col justify-center items-center">
      <div className="cursor-pointer" onClick={() => onLEDToggle(channel)}>
        {isOn ? (
          <LEDonSvg className="w-[40px] h-[40px]" />
        ) : (
          <LEDSvg className="w-[40px] h-[40px]" />
        )}
      </div>
      <h2 className="text-[10px] text-[#7A838E] text-center mt-1 mb-1">
        {channel.name}
      </h2>
      <RangeSlider
        min={powerMin}
        max={powerMax}
        value={brightness}
        onChange={(value) => onLEDBrightnessChange(channel, value)}
        onValueCommit={(value) => onLEDBrightnessCommit(channel, value)}
        disabled={!isOn}
      />
    </div>
  );
};

const SensorCard = ({ channel }) => {
  return (
    <div className="flex flex-col justify-center items-center">
      <SensorSvg
        className={`w-[40px] h-[40px] ${
          channel.status === "active" ? "text-blue-500" : "text-gray-400"
        }`}
      />
      <h2 className="text-[10px] text-[#7A838E] text-center mt-1 mb-1">
        {channel.name}
      </h2>
      <div className="text-[10px] text-center text-gray-600">
        {channel.status || "inactive"}
      </div>
    </div>
  );
};

const ShadeCard = ({
  channel,
  onShadeUp,
  onShadeDown,
  onShadeStop,
  onShade33,
  onShade66,
  channelStates,
  device,
}) => {
  const currentState =
    channelStates[`${channel.deviceId}-${channel.channelId}`] || channel;
  const openLevel = parseInt(
    currentState.properties?.openLevel?.replace?.("%", "") || 0
  );
  const isFullyOpen = openLevel >= 100;
  const isFullyClosed = openLevel <= 0;

  const isLutronDevice = device?.device_type?.toLowerCase() === "shade_lutron";

  return (
    <div className="flex flex-col justify-center items-center">
      <CurtainSvg openValue={openLevel} className="h-[40px] w-[40px]" />
      <h2 className="text-[10px] text-[#7A838E] text-center mt-1">
        {channel.name}
      </h2>
      <div className="text-[9px] text-center text-gray-600 mb-1">
        {
          isLutronDevice ? `${channel?.properties?.numberOfCmds || 3}/4 commands`:
        ``
        }
      </div>
      <div className="w-full flex items-center justify-center mt-1">
        <div className="bg-[#F5F9FD] border border-[#CCCCCC] rounded-lg grid text-[#222222]"
             style={{
               gridTemplateColumns: channel?.properties?.numberOfCmds === 4 ? 'repeat(4, 1fr)' : 'repeat(3, 1fr)'
             }}>
          <button
            className={`flex items-center justify-center px-1 w-[35px] h-[30px] py-[2px] hover:bg-gray-100 ${
              isLutronDevice
                ? "cursor-pointer"
                : isFullyOpen
                ? "opacity-50 cursor-not-allowed"
                : "cursor-pointer"
            }`}
            onClick={() => 
              isLutronDevice
                ? onShadeUp(channel)
                : !isFullyOpen && onShadeUp(channel)
            }
            disabled={isLutronDevice ? false : isFullyOpen}
          >
            <MdArrowDownSvg className="rotate-180 w-[12px] h-[12px]" />
          </button>
          
          {channel?.properties?.numberOfCmds === 4 ? (
            <>
              <button
                className="border-l border-[#CCCCCC] flex items-center justify-center px-1 w-[35px] h-[30px] py-[2px] hover:bg-gray-100 cursor-pointer"
                onClick={() => onShade66(channel)}
              >
                <ShadeSSSvg className="w-[14px] h-[14px]" />
              </button>
              <button
                className="border-l border-[#CCCCCC] flex items-center justify-center px-1 w-[35px] h-[30px] py-[2px] hover:bg-gray-100 cursor-pointer"
                onClick={() => onShade33(channel)}
              >
                <ShadeTTSvg className="w-[14px] h-[14px]" />
              </button>
            </>
          ) : (
            <button
              className="border-l border-r border-[#CCCCCC] flex items-center justify-center px-1 w-[35px] h-[30px] py-[2px] hover:bg-gray-100 cursor-pointer"
              onClick={() => onShadeStop(channel)}
            >
              <StopSvg className="w-[20px] h-[20px]" />
            </button>
          )}
          
          <button
            className={`${channel?.properties?.numberOfCmds === 4 ? 'border-l border-[#CCCCCC]' : ''} flex items-center justify-center px-1 w-[35px] h-[30px] py-[2px] hover:bg-gray-100 ${
              isLutronDevice
                ? "cursor-pointer"
                : isFullyClosed
                ? "opacity-50 cursor-not-allowed"
                : "cursor-pointer"
            }`}
            onClick={() => 
              isLutronDevice
                ? onShadeDown(channel)
                : !isFullyClosed && onShadeDown(channel)
            }
            disabled={isLutronDevice ? false : isFullyClosed}
          >
            <MdArrowDownSvg className="w-[12px] h-[12px]" />
          </button>
        </div>
      </div>
    </div>
  );
};

function ControlConfiguredDevicePopup({ device, onClose }) {
  const [channelStates, setChannelStates] = useState({});
  const { data, isLoading } = useGetDeviceChannelsByDeviceId(device?.device_id, () => {
    setChannelStates({});
  });
  const queryClient = useQueryClient();
  const { user } = useUserStore();

  const isLutronDevice = device?.device_type?.toLowerCase() === "shade_lutron";

  const triggerEventMutation = useTriggerEvent({
    onSuccess: (response) => {
      // Optionally handle success response
    },
    onError: (error) => {
      console.error("Event trigger failed:", error);
    },
  });

  const realTimeChangeCallback = (data) => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.DEVICE_CHANNELS],
      exact: false,
    });
  };

  const channels = data?.data?.channels;

  const getChannelKey = (channel) =>
    `${device?.device_id}-${channel.channelId}`;

  const getUserData = () => ({
    userId: user?.id,
  });

  const handleLEDToggle = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const newStatus = currentState.status === "on" ? "off" : "on";

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          status: newStatus,
        },
      }));

      if (newStatus === "on") handleLEDBrightnessCommit(channel, 100)

      const userData = getUserData();

      const payload = {
        ...userData,
        device_id: device?.device_id,
        deviceData:
          newStatus === "on"
            ? {
                properties: {
                  brightness: parseInt(
                    currentState.properties?.brightness || 0
                  ),
                  // powerMin: 0,
                  // powerMax: 100,
                  powerMin: parseInt(currentState.properties?.powerMin || 0),
                  powerMax: parseInt(currentState.properties?.powerMax || 0),
                },
              }
            : {},
        channelType: "LED",
        channelAddress: channel.channelId,
        command: newStatus === "on" ? "LED_ON" : "LED_OFF",
      };

      triggerEventMutation.mutate(payload);
    },
    [channelStates, triggerEventMutation, device?.device_id]
  );

  const handleLEDBrightnessChange = useCallback(
    (channel, brightness) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            brightness: brightness,
          },
        },
      }));
    },
    [channelStates]
  );

  const handleLEDBrightnessCommit = useCallback(
    (channel, brightness) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;

      const userData = getUserData();

      const payload = {
        ...userData,
        device_id: device?.device_id,
        deviceData: {
          properties: {
            brightness: brightness,
            powerMin: parseInt(currentState.properties?.powerMin || 0),
            powerMax: parseInt(currentState.properties?.powerMax || 0),
            // powerMin: 0,
            // powerMax: 100,
          },
        },
        channelType: "LED",
        channelAddress: channel.channelId,
        command: "LED_BRIGHTNESS",
      };

      triggerEventMutation.mutate(payload, {
        onSuccess: () => {
          toaster.success("Brightness updated successfully");
        },
        onError: (error) => {
          toaster.error(
            error?.response?.data?.message || "Failed to update brightness"
          );
        },
      });
    },
    [channelStates, triggerEventMutation, device?.device_id]
  );

  const handleShadeUp = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") || 0
      );
      // For shade_lutron devices, set openLevel to 100 when going up
      // const newLevel = device?.device_type?.toLowerCase() === "shade_lutron" ? 100 : Math.min(100, currentLevel + 10);
      const newLevel = 100;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: device?.device_id,
        deviceData: {
          properties: {
            ...(device?.device_type?.toLowerCase() !== "shade_lutron" && { openLevel: newLevel }),
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          },
        },
        channelType: "SHADE",
        channelAddress: channel.channelId,
        command: "SHADE_UP",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [channelStates, triggerEventMutation, device?.device_id]
  );

  const handleShadeDown = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const currentLevel = parseInt(
        currentState.properties?.openLevel?.replace?.("%", "") || 0
      );
      // For shade_lutron devices, set openLevel to 0 when going down
      // const newLevel = device?.device_type?.toLowerCase() === "shade_lutron" ? 0 : Math.max(0, currentLevel - 10);
      const newLevel = 0;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: device?.device_id,
        deviceData: {
          properties: {
            ...(device?.device_type?.toLowerCase() !== "shade_lutron" && { openLevel: newLevel }),
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          },
        },
        channelType: "SHADE",
        channelAddress: channel.channelId,
        command: "SHADE_DOWN",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [channelStates, triggerEventMutation, device?.device_id]
  );

  const handleShadeStop = useCallback(
    (channel) => {
      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: device?.device_id,
        deviceData: {
          properties: {
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          }
        },
        channelType: "SHADE",
        channelAddress: channel.channelId,
        command: "SHADE_STOP",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [triggerEventMutation, device?.device_id]
  );

  const handleShade33 = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const newLevel = 33;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: device?.device_id,
        deviceData: {
          properties: {
            ...(device?.device_type?.toLowerCase() !== "shade_lutron" && { openLevel: newLevel }),
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          },
        },
        channelType: "SHADE",
        channelAddress: channel.channelId,
        command: "SHADE_33",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [channelStates, triggerEventMutation, device?.device_id]
  );

  const handleShade66 = useCallback(
    (channel) => {
      const key = getChannelKey(channel);
      const currentState = channelStates[key] || channel;
      const newLevel = 66;

      setChannelStates((prev) => ({
        ...prev,
        [key]: {
          ...currentState,
          properties: {
            ...currentState.properties,
            openLevel: `${newLevel}%`,
          },
        },
      }));

      const userData = getUserData();
      const payload = {
        ...userData,
        device_id: device?.device_id,
        deviceData: {
          properties: {
            ...(device?.device_type?.toLowerCase() !== "shade_lutron" && { openLevel: newLevel }),
            numberOfCmds: channel?.properties?.numberOfCmds || null,
          },
        },
        channelType: "SHADE",
        channelAddress: channel.channelId,
        command: "SHADE_66",
      };

      triggerEventMutation.mutate(payload, {
        onError: (error) => {
          toaster.error(error?.response?.data?.message || "Failed");
        },
      });
    },
    [channelStates, triggerEventMutation, device?.device_id]
  );

  const leds = channels?.filter((channel) => channel.type === "led");
  const shades = channels?.filter((channel) => channel.type === "shade");
  const sensors = channels?.filter((channel) => channel.type === "sensor");

  const toggleModal = (value) => {
    if (value === false && onClose) onClose();
    queryClient.invalidateQueries([
      QUERY_KEYS.DEVICE_CHANNELS,
      device?.device_id,
    ]);
  };

  if (!device) return null;

  return (
    <BottomRightModal
      toggleModal={toggleModal}
      className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
    >
      <DeviceStatusChanged callback={realTimeChangeCallback} />
      <div className="p-5 flex items-center justify-between pb-5 border-b border-[#CCCCCC]">
        <h2 className="text-[#222222] font-semibold">{device?.device_name}</h2>
        <button onClick={() => toggleModal(false)}>
          <CircleCrossSvg />
        </button>
      </div>

      <div className="flex-grow overflow-auto p-4">
        {isLoading ? (
          <div className="flex justify-center items-center h-32">
            <div className="text-sm text-gray-600">Loading channels...</div>
          </div>
        ) : (
          <>
            {/* LED Channels Section */}
            {leds && leds.length > 0 && (
              <div className="mb-5 pb-5 border-b border-[#CCCCCC]">
                <div className="flex items-center justify-between pb-2 mb-3">
                  <h2 className="text-xs text-[#222222] font-semibold">
                    LED Channels
                  </h2>
                  <span className="text-xs text-[#7A838E]">
                    Available Channels:{" "}
                    {leds.filter((led) => led.properties?.installed).length}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  {leds
                    .filter((led) => led.properties?.installed)
                    .map((led) => (
                      <LEDCard
                        key={led._id}
                        channel={{ ...led, deviceId: device?.device_id }}
                        onLEDToggle={handleLEDToggle}
                        onLEDBrightnessChange={handleLEDBrightnessChange}
                        onLEDBrightnessCommit={handleLEDBrightnessCommit}
                        channelStates={channelStates}
                      />
                    ))}
                </div>
                {leds.filter((led) => led.properties?.installed).length ===
                  0 && (
                  <div className="text-xs text-[#7A838E] text-center py-4">
                    No LED channels configured yet.
                  </div>
                )}
              </div>
            )}

            {/* Shade Channels Section */}
            {shades && shades.length > 0 && (
              <div className="mb-5 pb-5 border-b border-[#CCCCCC]">
                <div className="flex items-center justify-between pb-2 mb-3">
                  <h2 className="text-xs text-[#222222] font-semibold">
                    Shade Channels
                  </h2>
                  <span className="text-xs text-[#7A838E]">
                    Available Channels:{" "}
                    {
                      shades.filter((shade) => shade.properties?.installed)
                        .length
                    }
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  {shades
                    .filter((shade) => shade.properties?.installed)
                    .map((shade) => (
                      <ShadeCard
                        key={shade._id}
                        channel={{ ...shade, deviceId: device?.device_id }}
                        onShadeUp={handleShadeUp}
                        onShadeDown={handleShadeDown}
                        onShadeStop={handleShadeStop}
                        onShade33={handleShade33}
                        onShade66={handleShade66}
                        channelStates={channelStates}
                        device={device}
                      />
                    ))}
                </div>
                {shades.filter((shade) => shade.properties?.installed)
                  .length === 0 && (
                  <div className="text-xs text-[#7A838E] text-center py-4">
                    No shade channels configured yet.
                  </div>
                )}
              </div>
            )}

            {/* Sensor Channels Section */}
            {sensors && sensors.length > 0 && (
              <div className="mb-4">
                <div className="flex items-center justify-between pb-2 mb-3">
                  <h2 className="text-xs text-[#222222] font-semibold">
                    Sensor Channels
                  </h2>
                  <span className="text-xs text-[#7A838E]">
                    Available Channels:{" "}
                    {
                      sensors.filter((sensor) => sensor.properties?.installed)
                        .length
                    }
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  {sensors
                    .filter((sensor) => sensor.properties?.installed)
                    .map((sensor) => (
                      <SensorCard key={sensor._id} channel={sensor} />
                    ))}
                </div>
                {sensors.filter((sensor) => sensor.properties?.installed)
                  .length === 0 && (
                  <div className="text-xs text-[#7A838E] text-center py-4">
                    No sensor channels configured yet.
                  </div>
                )}
              </div>
            )}

            {/* No channels at all */}
            {(!channels || channels.length === 0) && !isLoading && (
              <div className="text-center py-8">
                <div className="text-sm text-[#7A838E]">
                  No channels found for this device.
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </BottomRightModal>
  );
}

export default ControlConfiguredDevicePopup;
