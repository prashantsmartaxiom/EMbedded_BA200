import { useFormik } from "formik";
import * as Yup from "yup";
import {
  BottomRightModal,
  BottomRightModalHeader,
  PrimaryBtn2,
  PrimaryDropdown,
  PrimaryInput,
  PrimaryTextarea,
} from "../../components";
import { 
  useUpdateConfiguredDevice,
  useGetCampusOptions,
  useGetBuildingOptionsByCampus,
  useGetFloorsOptionsByBuilding,
  useGetZonesOptionsByFloor,
} from "../../api/queryHooks";
import toaster from "../../utils/toaster";

const validationSchema = Yup.object({
  campus_id: Yup.string().required("Campus is required"),
  building_id: Yup.string().required("Building is required"),
  floor_id: Yup.string().required("Floor is required"),
  zone_id: Yup.string().required("Zone is required"),
  device_name: Yup.string().required("Device name is required"),
});

function EditConfiguredDeviceForm({ device, onClose }) {
  // API hooks for dropdowns
  const { data: campusOptions = [], isLoading: loadingCampuses } =
    useGetCampusOptions();

  const updateDeviceMutation = useUpdateConfiguredDevice({
    onSuccess: (data) => {
      toaster.success("Device updated successfully!");
      formik.resetForm();
      if (onClose) onClose();
    },
    onError: (error) => {
      console.error("Error updating device:", error);
      toaster.error(error?.response?.data?.message || "Failed to update device. Please try again.");
    },
  });

  const formik = useFormik({
    initialValues: {
      campus_id: device?.location?.campus?.id || "",
      building_id: device?.location?.building?.id || "",
      floor_id: device?.location?.floor?.id || "",
      zone_id: device?.location?.zone?.id || "",
      device_name: device?.device_name || "",
      description: device?.description || "",
    },
    validationSchema,
    onSubmit: (values) => {
      updateDeviceMutation.mutate({
        deviceId: device.device_id,
        deviceData: {
          campus: values.campus_id,
          building: values.building_id,
          floor: values.floor_id,
          zone: values.zone_id,
          device_name: values.device_name.trim(),
          description: values.description.trim(),
        },
      });
    },
  });

  // Fetch buildings when campus changes
  const { data: buildingOptions = [], isLoading: loadingBuildings } =
    useGetBuildingOptionsByCampus(formik.values.campus_id);

  // Fetch floors when building changes
  const { data: floorOptions = [], isLoading: loadingFloors } =
    useGetFloorsOptionsByBuilding(formik.values.building_id);

  // Fetch zones when floor changes
  const { data: zoneOptions = [], isLoading: loadingZones } =
    useGetZonesOptionsByFloor(formik.values.floor_id);

  // Handle campus change
  const handleCampusChange = (value) => {
    formik.setFieldValue("campus_id", value);
    formik.setFieldValue("building_id", "");
    formik.setFieldValue("floor_id", "");
    formik.setFieldValue("zone_id", "");
  };

  // Handle building change
  const handleBuildingChange = (value) => {
    formik.setFieldValue("building_id", value);
    formik.setFieldValue("floor_id", "");
    formik.setFieldValue("zone_id", "");
  };

  // Handle floor change
  const handleFloorChange = (value) => {
    formik.setFieldValue("floor_id", value);
    formik.setFieldValue("zone_id", "");
  };

  // Check if form can be submitted
  const canSubmit = () => {
    return (
      formik.values.campus_id &&
      formik.values.building_id &&
      formik.values.floor_id &&
      formik.values.zone_id &&
      formik.values.device_name.trim() &&
      formik.isValid
    );
  };

  return (
    <form
      className="flex-grow flex min-h-0 flex-col justify-between"
      onSubmit={formik.handleSubmit}
    >
      <div className="overflow-auto">
        <div className="px-5 mb-5 flex items-center justify-between w-full">
          <label htmlFor="device_id" className="text-[#222222] text-[12px]">
            Device ID:
          </label>
          <div className="w-[300px] text-[#222222] text-[12px]">
            {device?.device_id}{" "}
            <span className="text-[#AAAAAA]">
              ({device?.device_type || "Unknown"})
            </span>
          </div>
        </div>

        {/* Campus Dropdown */}
        <div className="px-5 mb-5 flex items-center justify-between w-full">
          <label htmlFor="campus_id" className="text-[#222222] text-[12px]">
            Campus:
          </label>
          <div className="w-[300px]">
            <PrimaryDropdown
              className="w-full"
              options={campusOptions}
              value={formik.values.campus_id}
              onValueChange={handleCampusChange}
              onBlur={() => formik.setFieldTouched("campus_id", true)}
              placeholder={loadingCampuses ? "Loading..." : "Select Campus"}
              disabled={loadingCampuses}
            />
            {formik.touched.campus_id && formik.errors.campus_id && (
              <span className="text-red-500 text-xs mt-1">
                {formik.errors.campus_id}
              </span>
            )}
          </div>
        </div>

        {/* Building Dropdown */}
        {formik.values.campus_id && (
          <div className="px-5 mb-5 flex items-center justify-between w-full">
            <label htmlFor="building_id" className="text-[#222222] text-[12px]">
              Building:
            </label>
            <div className="w-[300px]">
              <PrimaryDropdown
                className="w-full"
                options={buildingOptions}
                value={formik.values.building_id}
                onValueChange={handleBuildingChange}
                onBlur={() => formik.setFieldTouched("building_id", true)}
                placeholder={loadingBuildings ? "Loading..." : "Select Building"}
                disabled={loadingBuildings || !formik.values.campus_id}
              />
              {formik.touched.building_id && formik.errors.building_id && (
                <span className="text-red-500 text-xs mt-1">
                  {formik.errors.building_id}
                </span>
              )}
            </div>
          </div>
        )}

        {/* Floor Dropdown */}
        {formik.values.building_id && (
          <div className="px-5 mb-5 flex items-center justify-between w-full">
            <label htmlFor="floor_id" className="text-[#222222] text-[12px]">
              Floor:
            </label>
            <div className="w-[300px]">
              <PrimaryDropdown
                className="w-full"
                options={floorOptions}
                value={formik.values.floor_id}
                onValueChange={handleFloorChange}
                onBlur={() => formik.setFieldTouched("floor_id", true)}
                placeholder={loadingFloors ? "Loading..." : "Select Floor"}
                disabled={loadingFloors || !formik.values.building_id}
              />
              {formik.touched.floor_id && formik.errors.floor_id && (
                <span className="text-red-500 text-xs mt-1">
                  {formik.errors.floor_id}
                </span>
              )}
            </div>
          </div>
        )}

        {/* Zone Dropdown */}
        {formik.values.floor_id && (
          <div className="px-5 pb-5 mb-5 border-b border-[#DDDDDD]">
            <div className="flex items-center justify-between w-full">
              <label htmlFor="zone_id" className="text-[#222222] text-[12px]">
                Zone:
              </label>
              <div className="w-[300px]">
                <PrimaryDropdown
                  className="w-full"
                  options={zoneOptions}
                  value={formik.values.zone_id}
                  onValueChange={(value) =>
                    formik.setFieldValue("zone_id", value)
                  }
                  onBlur={() => formik.setFieldTouched("zone_id", true)}
                  placeholder={loadingZones ? "Loading..." : "Select Zone"}
                  disabled={loadingZones || !formik.values.floor_id}
                />
                {formik.touched.zone_id && formik.errors.zone_id && (
                  <span className="text-red-500 text-xs mt-1">
                    {formik.errors.zone_id}
                  </span>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Device configuration fields - only show when zone is selected */}
        {formik.values.zone_id && (
          <>
            {/* Device Name */}
            <div className="flex items-center justify-between px-5 mb-5">
              <label htmlFor="device_name" className="text-[#222222] text-[12px]">
                Device Name
              </label>
              <div className="w-[300px]">
                <PrimaryInput
                  className="w-full"
                  placeholder="Enter Device name"
                  name="device_name"
                  value={formik.values.device_name}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.touched.device_name && formik.errors.device_name && (
                  <span className="text-red-500 text-xs mt-1">
                    {formik.errors.device_name}
                  </span>
                )}
              </div>
            </div>

            {/* Description */}
            <div className="px-5 mb-5 flex items-start justify-between w-full">
              <label htmlFor="description" className="text-[#222222] text-[12px]">
                Description:
              </label>
              <div className="w-[300px]">
                <PrimaryTextarea
                  placeholder="Enter description"
                  className="w-full min-h-[82px]"
                  name="description"
                  value={formik.values.description}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
              </div>
            </div>
          </>
        )}
      </div>

      <div className="p-5 flex justify-end border-t border-[#DDDDDD]">
        <PrimaryBtn2
          type="submit"
          className="min-w-20 justify-center"
          disabled={updateDeviceMutation.isLoading || !canSubmit()}
        >
          {updateDeviceMutation.isLoading ? "UPDATING..." : "UPDATE"}
        </PrimaryBtn2>
      </div>
    </form>
  );
}

function EditConfiguredDeviceModal({ device, onClose }) {
  const toggleModal = (value) => {
    if (value === false && onClose) onClose();
  };

  if (!device) return null;

  return (
    <BottomRightModal
      toggleModal={toggleModal}
      className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
    >
      <BottomRightModalHeader toggleModal={toggleModal} title="Edit Device" />
      <EditConfiguredDeviceForm device={device} onClose={onClose} />
    </BottomRightModal>
  );
}

export default EditConfiguredDeviceModal;
