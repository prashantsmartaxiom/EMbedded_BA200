import { useState } from "react";
import { PrimaryDropdown, SearchInput, PrimaryBtn } from "../../components";
import {
  useGetActiveDevicesOptionsForGroup,
  useExportEventLogs,
  useExportMqttLogs,
  useGetConfiguredDevicesOptions,
} from "../../api/queryHooks";
import EventLogs from "./EventLogs";
import MQTTLogs from "./MQTTLogs";
import toaster from "../../utils/toaster";
import Seperator from "../../components/Header/Seperator";

const DeviceTabBtn = ({ isActive = false, title, ...props }) => {
  return (
    <button
      type="button"
      className={`h-[50px] rounded-t-lg px-[15px] py-[8px] flex items-center gap-[20px] ${
        isActive ? "bg-[#E6F0FC] border-b border-[#227EEB]" : "bg-[#ffffff]"
      }`}
      {...props}
    >
      <span
        className={`text-base ${
          isActive ? "text-[#227EEB]" : "text-[#222222]"
        } font-semibold`}
      >
        {title}
      </span>
    </button>
  );
};

function LogsMonitoringContent() {
  const TABS = {
    EVENT_LOGS: "Event Logs",
    MQTT_LOGS: "MQTT Logs",
  };

  const { data: devicesData, isLoading: isLoadingDevices } =
    useGetConfiguredDevicesOptions();

  const [state, setState] = useState({
    tab: TABS.EVENT_LOGS,
    page: 1,
    limit: "10",
  });

  // Export hooks
  const { mutate: exportEventLogs, isLoading: isExportingEventLogs } =
    useExportEventLogs({
      onSuccess: () => {
        toaster.success("Event logs exported successfully!");
      },
      onError: (error) => {
        toaster.error(
          error.response?.data?.message || "Failed to export event logs."
        );
      },
    });

  const { mutate: exportMqttLogs, isLoading: isExportingMqttLogs } =
    useExportMqttLogs({
      onSuccess: () => {
        toaster.success("MQTT logs exported successfully!");
      },
      onError: (error) => {
        toaster.error(
          error.response?.data?.message || "Failed to export MQTT logs."
        );
      },
    });

  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("");
  const [sortOrder, setSortOrder] = useState(null);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [selectedDevice, setSelectedDevice] = useState(null);

  const handleTabClick = (tab) => {
    setState((prev) => ({
      ...prev,
      tab,
      page: 1, // Reset to first page when switching tabs
    }));
    // Reset all filters when switching tabs
    setSearch("");
    setSortBy("");
    setSortOrder(null);
    setStartDate("");
    setEndDate("");
    setSelectedDevice(null);
  };

  const handleLimitChange = (newLimit) => {
    setState((prev) => ({
      ...prev,
      limit: newLimit,
      page: 1, // Reset to first page when changing limit
    }));
  };

  const handlePageChange = (newPage) => {
    setState((prev) => ({ ...prev, page: newPage }));
  };

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
    setState((prev) => ({ ...prev, page: 1 })); // Reset to first page when searching
  };

  const handleSortChange = (columnKey, newSortOrder) => {
    setSortBy(columnKey);
    setSortOrder(newSortOrder);
    setState((prev) => ({ ...prev, page: 1 })); // Reset to first page when sorting changes
  };

  const handleStartDateChange = (e) => {
    if (endDate && e.target.value > endDate) {
      setEndDate(e.target.value);
    }
    setStartDate(e.target.value);
    setState((prev) => ({ ...prev, page: 1 })); // Reset to first page when filter changes
  };

  const handleEndDateChange = (e) => {
    setEndDate(e.target.value);
    setState((prev) => ({ ...prev, page: 1 })); // Reset to first page when filter changes
  };

  const handleDeviceChange = (deviceId) => {
    setSelectedDevice(deviceId);
    setState((prev) => ({ ...prev, page: 1 })); // Reset to first page when filter changes
  };

  const handleExport = () => {
    if (state.tab === TABS.EVENT_LOGS) {
      exportEventLogs({
        page: state.page,
        limit: Number(state.limit),
        search,
        sortBy: sortBy === "eventTime" ? "timestamp" : sortBy,
        sortOrder,
        startDate,
        endDate,
      });
    } else if (state.tab === TABS.MQTT_LOGS) {
      // Map frontend sort keys to API sort keys for MQTT
      const mapSortKeyToAPI = (sortKey) => {
        const sortMapping = {
          id: "device_id",
          createdAt: "createdAt",
        };
        return sortMapping[sortKey] || sortKey;
      };

      exportMqttLogs({
        page: state.page,
        limit: Number(state.limit),
        search,
        sortBy: sortBy ? mapSortKeyToAPI(sortBy) : undefined,
        sortOrder,
        startDate,
        endDate,
        device_id: selectedDevice,
      });
    }
  };

  const COMPONENTS = {
    [TABS.EVENT_LOGS]: EventLogs,
    [TABS.MQTT_LOGS]: MQTTLogs,
  };

  const Component = COMPONENTS[state.tab];

  return (
    <>
      <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
        <h2 className="text-[#222222] font-bold">Logs Monitoring</h2>
        <div className="flex items-center gap-[15px]">
          <SearchInput
            placeholder={
              state.tab === TABS.EVENT_LOGS
                ? "Search event logs..."
                : "Search MQTT logs..."
            }
            value={search}
            onChange={handleSearchChange}
            className="w-[300px]"
          />
        </div>
      </div>
      <div>
        <div className="flex flex-col gap-[15px] border-b-2 border-[#DDDDDD] mt-[10px]">
          {/* First Row - Tabs */}
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <DeviceTabBtn
                isActive={state.tab === TABS.EVENT_LOGS}
                title={"Event Logs"}
                onClick={() => handleTabClick(TABS.EVENT_LOGS)}
              />
              <DeviceTabBtn
                isActive={state.tab === TABS.MQTT_LOGS}
                title={"MQTT Logs"}
                onClick={() => handleTabClick(TABS.MQTT_LOGS)}
              />
            </div>
            <div className="flex items-center gap-[10px]">
              <div className="flex items-center gap-[10px]">
                <span className="text-[#222222] text-[12px]">Show:</span>
                <PrimaryDropdown
                  className="w-[60px]"
                  options={[
                    { value: "10", label: "10" },
                    { value: "20", label: "20" },
                    { value: "25", label: "25" },
                    { value: "50", label: "50" },
                  ]}
                  value={state.limit}
                  onValueChange={handleLimitChange}
                />
                <span className="text-[12px] text-[#7A838E]">Entries</span>
              </div>
              <Seperator className="h-[25px] mx-1" />
              {(state.tab === TABS.EVENT_LOGS ||
                state.tab === TABS.MQTT_LOGS) && (
                <div className="flex items-center justify-between">
                  {/* <div className="flex items-center gap-[15px]">
                    <SearchInput
                      placeholder={
                        state.tab === TABS.EVENT_LOGS
                          ? "Search event logs..."
                          : "Search MQTT logs..."
                      }
                      value={search}
                      onChange={handleSearchChange}
                      className="w-[300px]"
                    />
                  </div> */}
                  <div className="flex items-center gap-[10px]">
                    {state.tab === TABS.MQTT_LOGS && (
                      <>
                        <span className="text-[#222222] text-[12px]">
                          Device:
                        </span>
                        <PrimaryDropdown
                          className="w-[150px] !h-[36px] mr-2"
                          options={[
                            { value: null, label: "All Devices" },
                            ...(devicesData?.map((item) => ({
                              ...item,
                              label: item.value,
                            })) || []),
                          ]}
                          value={selectedDevice}
                          onValueChange={handleDeviceChange}
                          placeholder={
                            isLoadingDevices
                              ? "Loading devices..."
                              : "All Devices"
                          }
                          disabled={isLoadingDevices}
                        />
                      </>
                    )}
                    <span className="text-[#222222] text-[12px]">
                      Date Range:
                    </span>
                    <input
                      type="date"
                      value={startDate}
                      onChange={handleStartDateChange}
                      className="uppercase text-[#222222] font-medium placeholder:font-normal placeholder:text-[#939CA7] rounded-[10px] border border-[#E7E8E8] bg-[#ffffff] p-[8px] text-xs focus:outline-[#227EEB] w-[140px]"
                    />
                    <span className="text-[#7A838E] text-[12px]">to</span>
                    <input
                      type="date"
                      value={endDate}
                      min={startDate}
                      onChange={handleEndDateChange}
                      className="mr-2 uppercase text-[#222222] font-medium placeholder:font-normal placeholder:text-[#939CA7] rounded-[10px] border border-[#E7E8E8] bg-[#ffffff] p-[8px] text-xs focus:outline-[#227EEB] w-[140px]"
                    />
                    <PrimaryBtn
                      onClick={handleExport}
                      disabled={isExportingEventLogs || isExportingMqttLogs}
                      className="!py-0 !h-[36px] w-[100px] justify-center !p-0"
                    >
                      {isExportingEventLogs || isExportingMqttLogs
                        ? "Exporting..."
                        : "Export"}
                    </PrimaryBtn>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="mt-[30px]">
          <Component
            page={state.page}
            limit={state.limit}
            onPageChange={handlePageChange}
            {...((state.tab === TABS.EVENT_LOGS ||
              state.tab === TABS.MQTT_LOGS) && {
              search,
              sortBy,
              sortOrder,
              onSortChange: handleSortChange,
              startDate,
              endDate,
            })}
            {...(state.tab === TABS.MQTT_LOGS && {
              selectedDevice,
            })}
          />
        </div>
      </div>
    </>
  );
}

export default LogsMonitoringContent;
