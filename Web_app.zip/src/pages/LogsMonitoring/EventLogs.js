import { DataTable, PermissionDenied } from "../../components";
import { useGetEventLogs } from "../../api/queryHooks";
import useUserStore from "../../store/useUserStore";

const EventLogs = ({ 
  page, 
  limit, 
  onPageChange, 
  search, 
  sortBy, 
  sortOrder, 
  onSortChange,
  startDate,
  endDate,
}) => {
  const userPermissions = useUserStore((state) => state.permissions);

  const columns = [
    { key: "sno", label: "S. No." },
    { key: "type", label: "Type", sortable: true },
    { key: "name", label: "Name", sortable: true },
    { key: "action", label: "Action", sortable: true },
    { key: "eventTime", label: "Event Time", sortable: true },
  ];

  const { data: eventLogsData, isLoading } = useGetEventLogs({
    page,
    limit: Number(limit),
    search,
    sortBy: sortBy === "eventTime" ? "timestamp" : sortBy,
    sortOrder,
    startDate,
    endDate,
  });

  const data = eventLogsData?.data?.logs?.map((log, index) => ({
    sno: String((page - 1) * Number(limit) + index + 1).padStart(2, "0"),
    type: log.type || "Device",
    name: log.name,
    action: log.action,
    eventTime: log.timestamp
      ? new Date(log.timestamp * 1000).toLocaleString("en-GB", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        })
      : "",
    id: log._id,
  }));

  if (!userPermissions?.LOGS_MONITORING?.event_logs?.readOnly)
    return <PermissionDenied className="p-10 text-center" />;

  return (
    <DataTable
      columns={columns}
      data={data}
      totalItems={eventLogsData?.data?.pagination?.total_records || 0}
      currentPage={page}
      onPageChange={onPageChange}
      isLoading={isLoading}
      rowsPerPage={Number(limit)}
      sortBy={sortBy}
      sortOrder={sortOrder}
      onSortChange={onSortChange}
    />
  );
};

export default EventLogs;
