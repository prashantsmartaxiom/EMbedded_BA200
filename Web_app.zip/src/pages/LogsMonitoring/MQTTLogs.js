import { DataTable, PermissionDenied } from "../../components";
import { useGetMqttLogs } from "../../api/queryHooks";
import useUserStore from "../../store/useUserStore";
import { MqttLogsStatusChanged } from "../../components/SocketComponents/LogsStatusChanged";
import { useQueryClient } from "react-query";
import QUERY_KEYS from "../../api/queryKeys";

const MQTTLogs = ({
  page,
  limit,
  onPageChange,
  search,
  sortBy,
  sortOrder,
  onSortChange,
  startDate,
  endDate,
  selectedDevice,
}) => {
  const userPermissions = useUserStore((state) => state.permissions);

  const columns = [
    { key: "sno", label: "S. No." },
    { key: "id", label: "Device Id", sortable: true },
    { key: "control_topic", label: "Control Topic" },
    { key: "cmd", label: "Command" },
    { key: "cmd_m", label: "Command Message" },
    { key: "ch_t", label: "Channel Type" },
    { key: "ch_addr", label: "Channel Address" },
    { key: "cmd_number", label: "Command Number" },
    { key: "messageId", label: "Message Id" },
    { key: "createdAt", label: "Created At", sortable: true },
  ];

  // Map frontend sort keys to API sort keys
  const mapSortKeyToAPI = (sortKey) => {
    const sortMapping = {
      id: "device_id",
      createdAt: "createdAt",
    };
    return sortMapping[sortKey] || sortKey;
  };

  const { data: mqttLogsData, isLoading } = useGetMqttLogs({
    page,
    limit: Number(limit),
    search,
    sortBy: sortBy ? mapSortKeyToAPI(sortBy) : undefined,
    sortOrder,
    startDate,
    endDate,
    device_id: selectedDevice,
  });

  const queryClient = useQueryClient();

  const realtimecallback = () => {
    queryClient.invalidateQueries({
      queryKey: [QUERY_KEYS.MQTT_LOGS],
      exact: false,
    });
  };

  const data = mqttLogsData?.data?.logs?.map((log, index) => {
    let payload = log.payload;
    try {
      if (typeof log.payload === "string") {
        payload = JSON.parse(log.payload);
      }
    } catch (error) {
      payload = {};
    }

    return {
      sno: String((page - 1) * Number(limit) + index + 1).padStart(2, "0"),
      id: log?.id,
      control_topic: log?.control_topic,
      cmd: log.cmd,
      messageId: log?.messageId,

      ch_t: payload?.ch_t,
      ch_addr: payload?.ch_addr,
      cmd_number: payload?.cmd,
      cmd_m: payload?.cmd_m,
      createdAt: log.createdAt
        ? new Date(log.createdAt).toLocaleString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
          })
        : "",
    };
  });

  if (!userPermissions?.LOGS_MONITORING?.mqtt_logs?.readOnly)
    return <PermissionDenied className="p-10 text-center" />;

  return (
    <>
      <MqttLogsStatusChanged callback={realtimecallback} />
      <DataTable
        columns={columns}
        data={data}
        totalItems={mqttLogsData?.data?.pagination?.total_records || 0}
        currentPage={page}
        onPageChange={onPageChange}
        isLoading={isLoading}
        rowsPerPage={Number(limit)}
        sortBy={sortBy}
        sortOrder={sortOrder}
        onSortChange={onSortChange}
      />
    </>
  );
};

export default MQTTLogs;
