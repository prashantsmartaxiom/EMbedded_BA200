import { CloudSunSvg } from "../../assets/svg";
import { Checkbox } from "../../components";
import { useGetWeatherLocations } from "../../api/queryHooks";
import { useState } from "react";

const WEATHERPROPERTIES = [
  // { id: "highTemp", label: "High Temp" },
  // { id: "lowTemp", label: "Low Temp" },
  // { id: "sunrise", label: "Sunrise" },
  // { id: "sunset", label: "Sunset" },
  { id: "feelsLike", label: "Feels Like" },
  { id: "wind", label: "Wind" },
  { id: "pressure", label: "Pressure" },
  { id: "cloud", label: "Cloud" },
  { id: "humidity", label: "Humidity" },
  { id: "dewPoint", label: "Dew Point" },
  { id: "aqi", label: "AQI" },
];

const Weather = ({
  location,
  selectedProperties = [],
  onPropertyChange,
  allowProperties,
}) => {
  const handlePropertyChange = (propertyId, checked) => {
    if (onPropertyChange && allowProperties) {
      onPropertyChange(propertyId, checked);
    }
  };

  return (
    <div className="w-full border border-[#C1DBF9] bg-[#F5F9FD] rounded-[10px] p-4">
      <div className="flex items-center justify-between w-full h-full gap-3">
        <div className="text-[24px] text-[#222222] font-semibold">
          {location?.currentHourData?.temperature_2m ? (
            <span>{location?.currentHourData?.temperature_2m}&deg;c</span>
          ) : (
            "--"
          )}
        </div>
        <div className="flex gap-3">
          <div>
            <h3 className="text-[#222222] text-xs text-right">
              {location.placeName}
            </h3>
          </div>
          {/* <div className="grid grid-cols-2 gap-x-3 gap-y-2">
            {WEATHERPROPERTIES.slice(0, 4).map((property) => (
              <div key={property.id}>
                <label key={property.id} className="flex items-center gap-1">
                  <Checkbox
                    checked={selectedProperties.includes(property.id)}
                    onCheckedChange={(checked) =>
                      handlePropertyChange(property.id, checked)
                    }
                  />
                  <span className="text-[#222222] text-[10px]">
                    {property.label}
                  </span>
                </label>
              </div>
            ))}
          </div> */}
        </div>
      </div>
      <div className="flex flex-wrap gap-2 text-[12px] border-t border-[#C1DBF9] pt-3 mt-3 ">
        {WEATHERPROPERTIES.slice(0, WEATHERPROPERTIES.length).map(
          (property) => (
            <div key={property.id}>
              <label key={property.id} className="flex items-center gap-1">
                <Checkbox
                  checked={selectedProperties.includes(property.id)}
                  onCheckedChange={(checked) =>
                    handlePropertyChange(property.id, checked)
                  }
                />
                <span className="text-[#222222] text-[10px]">
                  {property.label}
                </span>
              </label>
            </div>
          )
        )}
      </div>
    </div>
  );
};

const Weathers = ({ onSelectWidget, selectedWidgets, onUpdateWidget }) => {
  const { data: weatherLocationsData, isLoading: isLoadingLocations } =
    useGetWeatherLocations();

  const userLocations = weatherLocationsData?.data || [];
  const [weatherProperties, setWeatherProperties] = useState(
    selectedWidgets
      .filter((item) => item.type === "weather")
      .reduce((acc, item) => {
        acc[item.data._id] = item.data.selectedProperties;
        return acc;
      }, {})
  );

  const handleCheckboxChange = (location) => {
    const isCurrentlySelected = isSelected(`weather+${location._id}`);
    const locationProperties = weatherProperties[location._id] || [];

    // If checking the main checkbox, select all properties
    // If unchecking, deselect all properties
    const allProperties = WEATHERPROPERTIES.map((prop) => prop.id);

    // is there any widget selected as weather
    let keepEmptyPropteries =
      selectedWidgets?.length === 2
        ? selectedWidgets.some((widget) => widget.type === "weather")
          ? false
          : true
          ? true
          : false
        : false;

    const selectedProperties =
      isCurrentlySelected || keepEmptyPropteries ? [] : allProperties;

    // Update the weather properties state
    setWeatherProperties((prev) => ({
      // ...prev,
      [location._id]: selectedProperties,
    }));

    const widget = {
      id: `weather+${location._id}`,
      type: "weather",
      data: {
        ...location,
        selectedProperties: selectedProperties,
      },
    };
    onSelectWidget(widget);
  };

  const handlePropertyChange = (locationId, propertyId, checked) => {
    setWeatherProperties((prev) => {
      const locationProps = prev[locationId] || [];
      const newProps = checked
        ? [...locationProps, propertyId]
        : locationProps.filter((prop) => prop !== propertyId);

      const updatedProperties = {
        ...prev,
        [locationId]: newProps,
      };

      // Update the widget data if it's already selected
      const selectedWidget = selectedWidgets.find(
        (w) => w.id === `weather+${locationId}`
      );
      if (selectedWidget && onUpdateWidget) {
        const updatedWidget = {
          ...selectedWidget,
          data: {
            ...selectedWidget.data,
            selectedProperties: newProps,
          },
        };
        onUpdateWidget(updatedWidget);
      }

      return updatedProperties;
    });
  };

  const isSelected = (locationId) => {
    return selectedWidgets.some(
      (widget) => widget.type === "weather" && widget.id === locationId
    );
  };

  if (isLoadingLocations) {
    return (
      <div className="pb-5 mb-5">
        <div className="px-5 flex items-center justify-between">
          <div className="flex items-center gap-[10px]">
            <span className="text-xs text-[#222222] font-semibold">
              Weather
            </span>
          </div>
          {/* <div className="text-[#939CA7] font-medium text-xs">Max: 01</div> */}
        </div>
        <div className="px-5 py-5 text-center text-[#7A838E] text-sm">
          Loading weather locations...
        </div>
      </div>
    );
  }

  if (!userLocations.length) {
    return (
      <div className="pb-5 mb-5">
        <div className="px-5 flex items-center justify-between">
          <div className="flex items-center gap-[10px]">
            <span className="text-xs text-[#222222] font-semibold">
              Weather
            </span>
          </div>
          {/* <div className="text-[#939CA7] font-medium text-xs">Max: 01</div> */}
        </div>
        <div className="px-5 py-5 text-center text-[#7A838E] text-sm">
          No weather locations created yet. Please create locations in General
          Widgets first.
        </div>
      </div>
    );
  }

  return (
    <div className="pb-5 mb-5">
      <div className="px-5 flex items-center justify-between">
        <div className="flex items-center gap-[10px]">
          <span className="text-xs text-[#222222] font-semibold">Weather</span>
        </div>
        {/* <div className="text-[#939CA7] font-medium text-xs">Max: 01</div> */}
      </div>
      <div className="px-5 flex flex-col gap-3 mt-5">
        {userLocations.map((location) => (
          <div key={location._id} className="flex items-center gap-3">
            <Checkbox
              checked={isSelected(`weather+${location._id}`)}
              onCheckedChange={() => handleCheckboxChange(location)}
            />
            <Weather
              location={location}
              selectedProperties={weatherProperties[location._id] || []}
              onPropertyChange={(propertyId, checked) =>
                handlePropertyChange(location._id, propertyId, checked)
              }
              allowProperties={isSelected(`weather+${location._id}`)}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default Weathers;
