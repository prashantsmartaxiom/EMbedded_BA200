import { AnalogClockSvg } from "../../assets/svg";
import { Checkbox } from "../../components";
import { useGetTimezones } from "../../api/queryHooks";

const AnalogClock = ({ timezone }) => {
  return (
    <div className="w-[122px] aspect-square border border-[#C1DBF9] bg-[#F5F9FD] rounded-[10px] flex flex-col items-center justify-center">
      <div className="flex flex-col items-center w-full">
        <AnalogClockSvg className="w-12 h-12" />
        <div className="w-full px-2">
          <h3 className="text-[#222222] text-center text-[10px] font-semibold mt-1 truncate">
            {timezone.timeZoneValue}
          </h3>
        </div>
        <p className="text-[#939CA7] text-[9px] font-medium">
          Wednesday (-12:30)
        </p>
      </div>
    </div>
  );
};

const AnalogClocks = ({ onSelectWidget, selectedWidgets }) => {
  const { data: timezonesData, isLoading: isLoadingTimezones } =
    useGetTimezones();
  const userTimezones = timezonesData?.data || [];

  const handleCheckboxChange = (timezone) => {
    const widget = {
      id: `analog-clock+${timezone._id}`,
      type: "analog-clock",
      data: timezone,
    };
    onSelectWidget(widget);
  };

  const isSelected = (timezoneId) => {
    return selectedWidgets.some(
      (widget) => widget.type === "analog-clock" && widget.id === timezoneId
    );
  };

  if (isLoadingTimezones) {
    return (
      <div className="border-b pb-5 mb-5 border-[#DDDDDD]">
        <div className="px-5 flex items-center justify-between">
          <div className="flex items-center gap-[10px]">
            <span className="text-xs text-[#222222] font-semibold">
              Analog Clock
            </span>
          </div>
          {/* <div className="text-[#939CA7] font-medium text-xs">Max: 03</div> */}
        </div>
        <div className="px-5 py-5 text-center text-[#7A838E] text-sm">
          Loading timezones...
        </div>
      </div>
    );
  }

  if (!userTimezones.length) {
    return (
      <div className="border-b pb-5 mb-5 border-[#DDDDDD]">
        <div className="px-5 flex items-center justify-between">
          <div className="flex items-center gap-[10px]">
            <span className="text-xs text-[#222222] font-semibold">
              Analog Clock
            </span>
          </div>
          {/* <div className="text-[#939CA7] font-medium text-xs">Max: 03</div> */}
        </div>
        <div className="px-5 py-5 text-center text-[#7A838E] text-sm">
          No timezones created yet. Please create timezones in General Widgets
          first.
        </div>
      </div>
    );
  }

  return (
    <div className="border-b pb-5 mb-5 border-[#DDDDDD]">
      <div className="px-5 flex items-center justify-between">
        <div className="flex items-center gap-[10px]">
          <span className="text-xs text-[#222222] font-semibold">
            Analog Clock
          </span>
        </div>
        {/* <div className="text-[#939CA7] font-medium text-xs">Max: 03</div> */}
      </div>
      <div className="px-5 grid grid-cols-3 gap-3 mt-5">
        {userTimezones.map((timezone) => (
          <div key={timezone._id} className="flex items-center gap-2">
            <Checkbox
              checked={isSelected(`analog-clock+${timezone._id}`)}
              onCheckedChange={() => handleCheckboxChange(timezone)}
            />
            <AnalogClock timezone={timezone} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default AnalogClocks;
