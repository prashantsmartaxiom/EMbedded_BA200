import React from "react";
import WeatherCard from "../Dashboard/WeatherCard";
import AnalogClockContent from "./AnalogClockW";
import DigitalClockContent from "./DigitClockW";
import SensorCardForWidget from "./SensorCardForWidget";
import { createWidgetsStructure } from "../../utils/helpers";

const renderWidgetContent = (
  widget,
  layout = "landscape",
  totalWidgets,
  listenRealTimeChange = false
) => {
  if (widget.type === "digital-clock")
    return <DigitalClockContent data={widget.data} />;
  else if (widget.type === "analog-clock")
    return (
      <AnalogClockContent
        data={widget.data}
        clockSize={`${
          totalWidgets > 1
            ? "flex-grow"
            : layout === "landscape"
            ? "flex-grow"
            : "w-full"
        }`}
      />
    );
  else if (widget.type === "weather")
    return (
      <WeatherCard
        lat={widget.data?.lat}
        long={widget.data?.long}
        placeName={widget.data?.placeName}
        uiType={`main-widget-${layout}`}
        totalWidgets={totalWidgets}
        location={widget.data}
        midElement={widget.midElement}
        listenRealTimeChange={listenRealTimeChange}
      />
    );
  else if (widget.type === "sensor")
    return (
      <SensorCardForWidget
        data={widget.data}
        uiType={`main-widget-${layout}`}
        midElement={widget.midElement}
      />
    );
  else return null;
};

export const LandscapeLayout = ({
  selectedWidgets,
  listenRealTimeChange = false,
  className = "w-[680px] h-[380px] border border-[#C1DBF9] bg-[#F5F9FD] rounded-[10px]",
}) => {
  const { widgets } = createWidgetsStructure(selectedWidgets, "landscape");

  return (
    <div className={`relative ${className ? className : ""} mb-[15px] flex`}>
      {widgets.map((widget, index) => (
        <React.Fragment key={widget.id}>
          <div className="p-2 overflow-hidden flex-1">
            {renderWidgetContent(
              widget,
              "landscape",
              widgets.length,
              listenRealTimeChange
            )}
          </div>
        </React.Fragment>
      ))}
    </div>
  );
};

export const PortraitLayout = ({
  selectedWidgets,
  listenRealTimeChange = false,
  className = "w-[380px] h-[680px] mb-[15px] border border-[#C1DBF9] bg-[#F5F9FD] rounded-[10px]",
}) => {
  const { widgets } = createWidgetsStructure(selectedWidgets, "portrait");
  return (
    <div className={`relative ${className ? className : ""} flex flex-col`}>
      {widgets.map((widget, index) => (
        <React.Fragment key={widget.id}>
          <div className="p-2 overflow-hidden flex-1">
            {renderWidgetContent(
              widget,
              "portrait",
              widgets.length,
              listenRealTimeChange
            )}
          </div>
        </React.Fragment>
      ))}
    </div>
  );
};

function WidgetVisualizer({ selectedWidgets }) {
  return (
    <div className="overflow-auto ml-[15px] w-full h-full gap-3 flex shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
      <PortraitLayout
        selectedWidgets={selectedWidgets}
        className="w-[380px] h-[680px] flex-shrink-0 mb-[15px] border border-[#C1DBF9] bg-[#F5F9FD] rounded-[10px]"
      />
      <LandscapeLayout
        selectedWidgets={selectedWidgets}
        className="w-[680px] h-[380px] flex-shrink-0 border border-[#C1DBF9] bg-[#F5F9FD] rounded-[10px]"
      />
    </div>
  );
}

export default WidgetVisualizer;
