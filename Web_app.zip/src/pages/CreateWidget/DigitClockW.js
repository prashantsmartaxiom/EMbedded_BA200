import { useEffect, useState } from "react";

const DigitalClockContent = ({ data, ...props }) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    let animationId;
    let lastSecond = -1;

    const updateClock = () => {
      const now = new Date();
      const currentSecond = now.getSeconds();

      // Only update state when the second actually changes (performance optimization)
      if (currentSecond !== lastSecond) {
        setCurrentTime(now);
        lastSecond = currentSecond;
      }

      animationId = requestAnimationFrame(updateClock);
    };

    // Start the animation loop
    updateClock();

    // Cleanup function
    return () => {
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
    };
  }, []);

  // Get time in the specified timezone
  const getTimeInTimezone = () => {
    try {
      const timeInZone = new Date().toLocaleTimeString("en-US", {
        timeZone: data.timeZoneValue,
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      });
      return timeInZone.split(":");
    } catch (error) {
      console.error("Invalid timezone:", data.timeZoneValue);
      return ["00", "00", "00"];
    }
  };

  // Get day name in the specified timezone
  const getDayInTimezone = () => {
    try {
      return new Date().toLocaleDateString("en-US", {
        timeZone: data.timeZoneValue,
        weekday: "long",
      });
    } catch (error) {
      console.error("Invalid timezone:", data.timeZoneValue);
      return "Invalid";
    }
  };

  const [hours, minutes, seconds] = getTimeInTimezone();
  const dayName = getDayInTimezone();

  return (
    <div className={`flex flex-col items-center justify-center p-3 h-full`}>
      {/* <div className="flex-shrink-0">
        <div
          className={`truncate text-[#222222] font-medium ${
            props?.locationClass ? props?.locationClass : "text-[22px]"
          }`}
        >
          {data.timeZoneValue}
        </div>
        <div
          className={`text-[#939CA7] font-medium ${
            props?.dayClass ? props?.dayClass : "text-[18px]"
          }`}
        >
          {dayName}
        </div>
      </div> */}
      <div
        className={`truncate w-full text-center text-[#222222] font-medium ${
          props?.locationClass ? props?.locationClass : "text-[22px]"
        }`}
      >
        <h3 className="truncate">{data.timeZoneValue}</h3>
      </div>
      <div className="flex items-center justify-center">
        <div
          className={`flex items-start justify-center mt-1 gap-[5px] ${
            props?.timeClass ? props?.timeClass : "text-[40px]"
          }`}
        >
          <div className="flex flex-col items-center">
            <span className="font-semibold text-[#222222]">{hours}</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="font-semibold text-[#222222]">:</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="font-semibold text-[#222222]">{minutes}</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="font-semibold text-[#222222]">:</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="font-semibold text-[#222222]">{seconds}</span>
          </div>
        </div>
      </div>
      <div
        className={`text-[#939CA7] font-medium ${
          props?.dayClass ? props?.dayClass : "text-[18px]"
        }`}
      >
        <h3>{dayName}</h3>
      </div>
    </div>
  );
};
export default DigitalClockContent;
