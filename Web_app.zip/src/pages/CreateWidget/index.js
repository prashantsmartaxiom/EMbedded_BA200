import { Link, useNavigate, useParams } from "react-router-dom";
import { ROUTES } from "../../router";
import { BackspaceSvg } from "../../assets/svg";
import { PrimaryBtn2, SearchInput, SecondaryBtn } from "../../components";
import DigitalClocks from "./DigitalClocks";
import AnalogClocks from "./AnalogClocks";
import Weathers from "./Weathers";
import Sensors from "./Sensors";
import { useState } from "react";
import WidgetVisualizer from "./WidgetVisualizer";
import {
  useCreateWidget,
  useGetWidgetById,
  useUpdateWidget,
} from "../../api/queryHooks";
import toaster from "../../utils/toaster";

const Creator = ({
  widgetId = null,
  initialSelection = [],
  mode = "create",
}) => {
  const navigate = useNavigate();
  const [selectedWidgets, setSelectedWidgets] = useState(initialSelection);

  // Hook for creating widget
  const createWidgetMutation = useCreateWidget({
    onSuccess: (data) => {
      navigate(ROUTES.UTILITIES_WIDGETS);
      setSelectedWidgets([]);
    },
  });
  const updateWidgetMutation = useUpdateWidget({
    onSuccess: () => {
      navigate(ROUTES.UTILITIES_WIDGETS);
      setSelectedWidgets([]);
      toaster.success("Widget updated successfully");
    },
  });

  const handleSelectWidget = (widget) => {
    setSelectedWidgets((prevWidgets) => {
      const isSelected = prevWidgets.some(
        (w) => w.id === widget.id && w.type === widget.type
      );

      if (isSelected) {
        // Remove the widget if it's already selected
        return prevWidgets.filter(
          (w) => !(w.id === widget.id && w.type === widget.type)
        );
      } else {
        // Check if we can add the widget based on type limits
        const sameTypeCount = prevWidgets.filter(
          (w) => w.type === widget.type
        ).length;

        // Define max limits for each widget type
        const TOTAL_WIDGETS_LIMIT = 2;
        const maxLimits = {
          "digital-clock": 2,
          "analog-clock": 2,
          weather: 1,
          sensor: 1,
        };

        // Check if adding this widget would exceed the type limit
        if (sameTypeCount >= maxLimits[widget.type]) {
          // For weather (max 1), replace the existing one
          if (widget.type === "weather" || widget.type === "sensor") {
            return prevWidgets.map((w) =>
              w.type === widget.type ? widget : w
            );
          }
          // For clocks and sensors (max 3), don't add if already at limit
          return prevWidgets;
        }

        // Check total widget limit (max 2 total)
        if (prevWidgets.length >= TOTAL_WIDGETS_LIMIT) {
          toaster.error("You can select a maximum of 2 widgets.");
          return prevWidgets;
        }

        // Add the new widget
        return [...prevWidgets, widget];
      }
    });
  };

  const handleUpdateWidget = (updatedWidget) => {
    setSelectedWidgets((prevWidgets) => {
      return prevWidgets.map((widget) =>
        widget.id === updatedWidget.id ? updatedWidget : widget
      );
    });
  };

  const handleReset = () => {
    if (mode === "edit") {
      setSelectedWidgets(initialSelection);
      return;
    }
    setSelectedWidgets([]);
  };

  const handleSubmit = async () => {
    if (selectedWidgets.length === 0) {
      alert("Please select at least one widget before creating.");
      return;
    }

    try {
      // Call the API with selectedWidgets as payload
      if (mode === "edit")
        updateWidgetMutation.mutateAsync({
          widgetId,
          widgetsData: selectedWidgets,
        });
      else await createWidgetMutation.mutateAsync(selectedWidgets);
    } catch (error) {
      console.error("Error creating widget:", error);
      toaster.error("Failed to create widget. Please try again.");
    }
  };

  return (
    <div className="pt-[15px] ml-[15px] pr-[15px] h-[calc(100vh-55px)]">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <div className="flex items-center justify-between">
          <Link
            to={ROUTES.UTILITIES_WIDGETS}
            className="flex items-center gap-[10px]"
          >
            <BackspaceSvg />
            <h2 className="text-[#222222] font-bold">
              {mode === "edit" ? "Edit Widget" : "Create Widget"}
            </h2>
          </Link>
          <div className="flex items-center gap-[15px]">
            <SecondaryBtn
              className={"w-[80px] justify-center"}
              type="button"
              onClick={handleReset}
            >
              RESET
            </SecondaryBtn>
            <PrimaryBtn2
              type="submit"
              className={"w-[80px] justify-center"}
              onClick={handleSubmit}
              disabled={
                createWidgetMutation.isLoading || selectedWidgets.length === 0
              }
            >
              {mode === "edit"
                ? createWidgetMutation.isLoading
                  ? "UPDATING..."
                  : "UPDATE"
                : createWidgetMutation.isLoading
                ? "CREATING..."
                : "CREATE"}
            </PrimaryBtn2>
          </div>
        </div>
      </div>
      <div className="h-[calc(100%-92px)] mt-[15px] flex">
        <div className="flex flex-col flex-shrink-0 w-[520px] shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff]">
          <div className="p-5 border-b border-[#DDDDDD]">
            <SearchInput placeholder="Search" />
          </div>
          <div className="flex-grow overflow-auto pt-5">
            <DigitalClocks
              onSelectWidget={handleSelectWidget}
              selectedWidgets={selectedWidgets}
            />
            <AnalogClocks
              onSelectWidget={handleSelectWidget}
              selectedWidgets={selectedWidgets}
            />
            <Weathers
              onSelectWidget={handleSelectWidget}
              onUpdateWidget={handleUpdateWidget}
              selectedWidgets={selectedWidgets}
            />
            <Sensors
              onSelectWidget={handleSelectWidget}
              onUpdateWidget={handleUpdateWidget}
              selectedWidgets={selectedWidgets}
            />
          </div>
        </div>
        <WidgetVisualizer selectedWidgets={selectedWidgets} />
      </div>
    </div>
  );
};

function EditWidget() {
  const { widgetId } = useParams();
  const { data: widgetData, isLoading } = useGetWidgetById(widgetId);

  if (isLoading) return <div>Loading...</div>;
  return (
    <Creator
      widgetId={widgetId}
      initialSelection={widgetData?.data?.structure}
      mode="edit"
    />
  );
}

function CreateWidget({ mode = "create" }) {
  if (mode === "edit") {
    return <EditWidget />;
  }
  return <Creator />;
}

export default CreateWidget;
