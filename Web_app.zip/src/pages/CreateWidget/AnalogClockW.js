import { useEffect, useState } from "react";

const AnalogClockContent = ({ data, ...props }) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    let animationId;
    let lastSecond = -1;

    const updateClock = () => {
      const now = new Date();
      const currentSecond = now.getSeconds();

      // Only update state when the second actually changes (performance optimization)
      if (currentSecond !== lastSecond) {
        setCurrentTime(now);
        lastSecond = currentSecond;
      }

      animationId = requestAnimationFrame(updateClock);
    };

    // Start the animation loop
    updateClock();

    // Cleanup function
    return () => {
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
    };
  }, []);

  // Get time in the specified timezone
  const getTimeInTimezone = () => {
    try {
      const now = new Date();
      const timeInZone = new Date(
        now.toLocaleString("en-US", { timeZone: data.timeZoneValue })
      );

      const hours = timeInZone.getHours();
      const minutes = timeInZone.getMinutes();
      const seconds = timeInZone.getSeconds();

      return { hours, minutes, seconds };
    } catch (error) {
      console.error("Invalid timezone:", data.timeZoneValue);
      return { hours: 0, minutes: 0, seconds: 0 };
    }
  };

  // Get day name in the specified timezone
  const getDayInTimezone = () => {
    try {
      return new Date().toLocaleDateString("en-US", {
        timeZone: data.timeZoneValue,
        weekday: "long",
      });
    } catch (error) {
      console.error("Invalid timezone:", data.timeZoneValue);
      return "Invalid";
    }
  };

  const { hours, minutes, seconds } = getTimeInTimezone();
  const dayName = getDayInTimezone();

  // Calculate angles for clock hands with smooth animation
  const secondAngle = seconds * 6; // 360/60 = 6 degrees per second
  const minuteAngle = minutes * 6 + seconds * 0.1; // 360/60 = 6 degrees per minute + smooth second movement
  const hourAngle = (hours % 12) * 30 + minutes * 0.5; // 360/12 = 30 degrees per hour + smooth minute movement

  return (
    <div className="flex flex-col items-center justify-center w-full h-full p-3">
      <div
        className={`${
          props?.clockSize ? props.clockSize : ""
        } relative`}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="90"
          height="90"
          viewBox="0 0 90 90"
          className="w-full h-full"
        >
          <g id="clock_1_" data-name="clock(1)" transform="translate(-1 -1)">
            <path
              id="Path_1112"
              data-name="Path 1112"
              d="M46,3.368A42.632,42.632,0,1,1,3.368,46,42.632,42.632,0,0,1,46,3.368M46,1A45,45,0,1,0,91,46,45,45,0,0,0,46,1Z"
              fill="#4e7ab5"
            />
            <path
              id="Path_1111"
              data-name="Path 1111"
              d="M45.5,89.5a44,44,0,1,1,44-44A44,44,0,0,1,45.5,89.5Z"
              transform="translate(0.5 0.5)"
              fill="#8bb7f0"
            />
            <path
              id="Path_1114"
              data-name="Path 1114"
              d="M45,6.562A38.437,38.437,0,1,1,6.562,45,38.437,38.437,0,0,1,45,6.562M45,4A41,41,0,1,0,86,45,41,41,0,0,0,45,4Z"
              transform="translate(1.001 1)"
              fill="#4e7ab5"
            />
            <path
              id="Path_1113"
              data-name="Path 1113"
              d="M44.5,84.5a40,40,0,1,1,40-40,40,40,0,0,1-40,40Z"
              transform="translate(1.501 1.501)"
              fill="#fff"
            />

            {/* Hour markers */}
            <path
              id="Path_1119"
              data-name="Path 1119"
              d="M3.936,0H2.563V-5.171A4.73,4.73,0,0,1,.791-4.131V-5.376a3.968,3.968,0,0,0,1.167-.667,2.533,2.533,0,0,0,.864-1.145H3.936ZM10.62-1.274V0H5.811a3.312,3.312,0,0,1,.469-1.37A9.114,9.114,0,0,1,7.822-3.086,9.705,9.705,0,0,0,8.96-4.258a1.51,1.51,0,0,0,.283-.84A.955.955,0,0,0,9-5.8a.921.921,0,0,0-.681-.247.914.914,0,0,0-.684.259,1.329,1.329,0,0,0-.293.859L5.972-5.068a2.241,2.241,0,0,1,.767-1.626A2.574,2.574,0,0,1,8.35-7.187a2.329,2.329,0,0,1,1.665.571A1.874,1.874,0,0,1,10.62-5.2a2.473,2.473,0,0,1-.173.92,3.743,3.743,0,0,1-.549.916,8.79,8.79,0,0,1-.9.913q-.649.6-.823.791a2.369,2.369,0,0,0-.281.381Z"
              transform="translate(40.209 16.188)"
              fill="#b4c5d1"
            />
            <path
              id="Path_1121"
              data-name="Path 1121"
              d="M5.073-5.405l-1.328.146a.967.967,0,0,0-.254-.605.74.74,0,0,0-.532-.2.9.9,0,0,0-.735.391,3.29,3.29,0,0,0-.378,1.626A1.6,1.6,0,0,1,3.12-4.648a1.946,1.946,0,0,1,1.472.654A2.372,2.372,0,0,1,5.205-2.3,2.423,2.423,0,0,1,4.561-.542,2.206,2.206,0,0,1,2.905.122,2.213,2.213,0,0,1,1.123-.72a4.333,4.333,0,0,1-.7-2.761,4.415,4.415,0,0,1,.728-2.837,2.348,2.348,0,0,1,1.89-.869,2.006,2.006,0,0,1,1.35.457A2.139,2.139,0,0,1,5.073-5.405ZM1.963-2.412a1.555,1.555,0,0,0,.308,1.033.905.905,0,0,0,.7.364.8.8,0,0,0,.635-.3,1.5,1.5,0,0,0,.254-.977,1.572,1.572,0,0,0-.273-1.023.858.858,0,0,0-.684-.325.859.859,0,0,0-.669.31A1.346,1.346,0,0,0,1.963-2.412Z"
              transform="translate(43.575 83.188)"
              fill="#b4c5d1"
            />
            <path
              id="Path_1120"
              data-name="Path 1120"
              d="M.376-1.9,1.7-2.061a1.257,1.257,0,0,0,.342.776.935.935,0,0,0,.674.269.926.926,0,0,0,.715-.322,1.249,1.249,0,0,0,.291-.869,1.165,1.165,0,0,0-.278-.82.887.887,0,0,0-.679-.3,2.394,2.394,0,0,0-.63.1L2.29-4.346a1.2,1.2,0,0,0,.85-.242.86.86,0,0,0,.293-.681.779.779,0,0,0-.215-.576.772.772,0,0,0-.571-.215.827.827,0,0,0-.6.244,1.147,1.147,0,0,0-.3.713L.479-5.317a2.827,2.827,0,0,1,.4-1.038,1.8,1.8,0,0,1,.742-.61,2.493,2.493,0,0,1,1.067-.222,2.128,2.128,0,0,1,1.621.645,1.682,1.682,0,0,1,.5,1.191,1.686,1.686,0,0,1-1.03,1.5,1.667,1.667,0,0,1,.984.591,1.714,1.714,0,0,1,.369,1.108A2.15,2.15,0,0,1,4.443-.542,2.372,2.372,0,0,1,2.729.122,2.36,2.36,0,0,1,1.118-.437,2.2,2.2,0,0,1,.376-1.9Z"
              transform="translate(77.624 49.188)"
              fill="#b4c5d1"
            />
            <path
              id="Path_1118"
              data-name="Path 1118"
              d="M.454-1.655,1.782-1.8a.961.961,0,0,0,.254.6.753.753,0,0,0,.542.2A.884.884,0,0,0,3.3-1.4a3.327,3.327,0,0,0,.381-1.621,1.638,1.638,0,0,1-1.294.6A1.934,1.934,0,0,1,.93-3.069a2.377,2.377,0,0,1-.613-1.7A2.413,2.413,0,0,1,.964-6.521a2.2,2.2,0,0,1,1.648-.667A2.218,2.218,0,0,1,4.4-6.345a4.352,4.352,0,0,1,.7,2.771A4.405,4.405,0,0,1,4.37-.742,2.354,2.354,0,0,1,2.476.127,2,2,0,0,1,1.118-.32A2.157,2.157,0,0,1,.454-1.655Zm3.105-3a1.565,1.565,0,0,0-.305-1.03.9.9,0,0,0-.706-.366.791.791,0,0,0-.632.3,1.532,1.532,0,0,0-.251.984,1.563,1.563,0,0,0,.273,1.018.858.858,0,0,0,.684.325.849.849,0,0,0,.667-.312A1.365,1.365,0,0,0,3.56-4.653Z"
              transform="translate(8.683 49.188)"
              fill="#b4c5d1"
            />
            <path
              id="Path_1129"
              data-name="Path 1129"
              d="M0,0H2V5H0Z"
              transform="translate(78.543 63.634) rotate(120)"
              fill="#c5d4de"
            />
            <path
              id="Path_1128"
              data-name="Path 1128"
              d="M0,0H2V5H0Z"
              transform="translate(65.366 77.543) rotate(150)"
              fill="#c5d4de"
            />
            <path
              id="Path_1127"
              data-name="Path 1127"
              d="M0,0H2V5H0Z"
              transform="translate(28.366 78.543) rotate(-150)"
              fill="#c5d4de"
            />
            <path
              id="Path_1126"
              data-name="Path 1126"
              d="M0,0H2V5H0Z"
              transform="translate(14.457 65.366) rotate(-120)"
              fill="#c5d4de"
            />
            <path
              id="Path_1125"
              data-name="Path 1125"
              d="M0,0H2V5H0Z"
              transform="translate(18.787 29.134) rotate(120)"
              fill="#c5d4de"
            />
            <path
              id="Path_1124"
              data-name="Path 1124"
              d="M0,0H2V5H0Z"
              transform="translate(30.866 17.787) rotate(150)"
              fill="#c5d4de"
            />
            <path
              id="Path_1123"
              data-name="Path 1123"
              d="M0,0H2V5H0Z"
              transform="translate(62.866 18.787) rotate(-150)"
              fill="#c5d4de"
            />
            <path
              id="Path_1122"
              data-name="Path 1122"
              d="M0,0H2V5H0Z"
              transform="translate(74.213 30.866) rotate(-120)"
              fill="#c5d4de"
            />

            {/* Dynamic Clock hands */}
            {/* Hour hand */}
            <line
              x1="46"
              y1="46"
              x2={46 + 18 * Math.sin((hourAngle * Math.PI) / 180)}
              y2={46 - 18 * Math.cos((hourAngle * Math.PI) / 180)}
              stroke="#66798f"
              strokeWidth="3"
              strokeLinecap="round"
            />

            {/* Minute hand */}
            <line
              x1="46"
              y1="46"
              x2={46 + 25 * Math.sin((minuteAngle * Math.PI) / 180)}
              y2={46 - 25 * Math.cos((minuteAngle * Math.PI) / 180)}
              stroke="#66798f"
              strokeWidth="2"
              strokeLinecap="round"
            />

            {/* Second hand */}
            <line
              x1="46"
              y1="46"
              x2={46 + 28 * Math.sin((secondAngle * Math.PI) / 180)}
              y2={46 - 28 * Math.cos((secondAngle * Math.PI) / 180)}
              stroke="#ff4757"
              strokeWidth="1"
              strokeLinecap="round"
            />

            {/* Center dot */}
            <path
              id="Path_1130"
              data-name="Path 1130"
              d="M3.5,0A3.5,3.5,0,1,1,0,3.5,3.5,3.5,0,0,1,3.5,0Z"
              transform="translate(43 43)"
              fill="#66798f"
            />
          </g>
        </svg>
      </div>
      <div
        className={`w-full truncate text-center text-[#222222] font-medium mt-[15px] ${
          props?.locationClass ? props?.locationClass : "text-[22px]"
        }`}
      >
        <h3 className="truncate">{data.timeZoneValue}</h3>
      </div>
      <div
        className={`text-[#939CA7] font-medium ${
          props?.dayClass ? props?.dayClass : "text-[18px]"
        }`}
      >
        <h3>{dayName}</h3>
      </div>
    </div>
  );
};

export default AnalogClockContent;
