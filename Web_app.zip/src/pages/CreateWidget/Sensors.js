import { CloudSunSvg } from "../../assets/svg";
import { Checkbox } from "../../components";
import { useGetSensorsForWidgetCreation } from "../../api/queryHooks";
import { useState } from "react";

const SENSORPROPERTIES = [
  { id: "temperature", label: "Temperature" },
  { id: "humidity", label: "Humidity" },
  { id: "pm2_5", label: "PM2.5" },
  { id: "pm10", label: "PM10" },
  { id: "co2", label: "CO2" },
  { id: "light_intensity", label: "Light Intensity" },
];

const Sensor = ({ sensor, selectedProperties = [], onPropertyChange, allowProperties }) => {

  const handlePropertyChange = (propertyId, checked) => {
    if (onPropertyChange && allowProperties) {
      onPropertyChange(propertyId, checked);
    }
  };

  return (
    <div className="w-full border border-[#C1DBF9] bg-[#F5F9FD] rounded-[10px] p-4">
      <div className="flex items-center justify-between w-full h-full gap-3">
        <div className="text-[14px] text-[#222222] font-semibold">
          {sensor.sensor_id}
        </div>
        <div className="flex gap-3">
          <div>
            <h3 className="text-[#222222] text-xs text-right">
              {sensor.sensor_name}
            </h3>
            <p className="text-[#7A838E] text-[10px] text-right">
              {sensor.placeName}
            </p>
          </div>
        </div>
      </div>
      <div className="flex flex-wrap gap-2 text-[12px] border-t border-[#C1DBF9] pt-3 mt-3 ">
        {SENSORPROPERTIES
          .slice(0, SENSORPROPERTIES.length)
          .map((property) => (
            <div key={property.id}>
              <label key={property.id} className="flex items-center gap-1">
                <Checkbox
                  checked={selectedProperties.includes(property.id)}
                  onCheckedChange={(checked) =>
                    handlePropertyChange(property.id, checked)
                  }
                />
                <span className="text-[#222222] text-[10px]">
                  {property.label}
                </span>
              </label>
            </div>
          ))}
      </div>
    </div>
  );
};

const Sensors = ({ onSelectWidget, selectedWidgets, onUpdateWidget }) => {
  const { data: sensorsData, isLoading: isLoadingSensors } =
    useGetSensorsForWidgetCreation();

  const userSensors = sensorsData?.data || [];
  const [sensorProperties, setSensorProperties] = useState(
    selectedWidgets
      .filter((item) => item.type === "sensor")
      .reduce((acc, item) => {
        acc[item.data._id] = item.data.selectedProperties;
        return acc;
      }, {})
  );

  const handleCheckboxChange = (sensor) => {
    const isCurrentlySelected = isSelected(`sensor+${sensor._id}`);
    const sensorProps = sensorProperties[sensor._id] || [];
    
    // If checking the main checkbox, select all properties
    // If unchecking, deselect all properties
    const allProperties = SENSORPROPERTIES.map((prop) => prop.id);
    
    let keepEmptyPropteries =
      selectedWidgets?.length === 2
        ? selectedWidgets.some((widget) => widget.type === "sensor")
          ? false
          : true
          ? true
          : false
        : false;

    const selectedProperties =
      isCurrentlySelected || keepEmptyPropteries ? [] : allProperties;

    
    // Update the sensor properties state
    setSensorProperties((prev) => ({
      // ...prev,
      [sensor._id]: selectedProperties,
    }));
    
    const widget = {
      id: `sensor+${sensor._id}`,
      type: "sensor",
      data: {
        ...sensor,
        selectedProperties: selectedProperties,
      },
    };
    onSelectWidget(widget);
  };

  const handlePropertyChange = (sensorId, propertyId, checked) => {
    setSensorProperties((prev) => {
      const sensorProps = prev[sensorId] || [];
      const newProps = checked
        ? [...sensorProps, propertyId]
        : sensorProps.filter((prop) => prop !== propertyId);

      const updatedProperties = {
        ...prev,
        [sensorId]: newProps,
      };

      // Update the widget data if it's already selected
      const selectedWidget = selectedWidgets.find(
        (w) => w.id === `sensor+${sensorId}`
      );
      if (selectedWidget && onUpdateWidget) {
        const updatedWidget = {
          ...selectedWidget,
          data: {
            ...selectedWidget.data,
            selectedProperties: newProps,
          },
        };
        onUpdateWidget(updatedWidget);
      }

      return updatedProperties;
    });
  };

  const isSelected = (sensorId) => {
    return selectedWidgets.some(
      (widget) => widget.type === "sensor" && widget.id === sensorId
    );
  };

  if (isLoadingSensors) {
    return (
      <div className="pb-5 mb-5">
        <div className="px-5 flex items-center justify-between">
          <div className="flex items-center gap-[10px]">
            <span className="text-xs text-[#222222] font-semibold">
              Sensors
            </span>
          </div>
          {/* <div className="text-[#939CA7] font-medium text-xs">Max: 01</div> */}
        </div>
        <div className="px-5 py-5 text-center text-[#7A838E] text-sm">
          Loading sensors...
        </div>
      </div>
    );
  }

  if (!userSensors.length) {
    return (
      <div className="pb-5 mb-5">
        <div className="px-5 flex items-center justify-between">
          <div className="flex items-center gap-[10px]">
            <span className="text-xs text-[#222222] font-semibold">
              Sensors
            </span>
          </div>
          {/* <div className="text-[#939CA7] font-medium text-xs">Max: 01</div> */}
        </div>
        <div className="px-5 py-5 text-center text-[#7A838E] text-sm">
          No sensors available yet.
        </div>
      </div>
    );
  }

  return (
    <div className="pb-5 mb-5">
      <div className="px-5 flex items-center justify-between">
        <div className="flex items-center gap-[10px]">
          <span className="text-xs text-[#222222] font-semibold">Sensors</span>
        </div>
        {/* <div className="text-[#939CA7] font-medium text-xs">Max: 01</div> */}
      </div>
      <div className="px-5 flex flex-col gap-3 mt-5">
        {userSensors.map((sensor) => (
          <div key={sensor._id} className="flex items-center gap-3">
            <Checkbox
              checked={isSelected(`sensor+${sensor._id}`)}
              onCheckedChange={() => handleCheckboxChange(sensor)}
            />
            <Sensor
              sensor={sensor}
              selectedProperties={sensorProperties[sensor._id] || []}
              onPropertyChange={(propertyId, checked) =>
                handlePropertyChange(sensor._id, propertyId, checked)
              }
              allowProperties={isSelected(`sensor+${sensor._id}`)}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default Sensors;
