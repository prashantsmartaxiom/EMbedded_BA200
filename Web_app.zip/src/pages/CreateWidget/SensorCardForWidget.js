import {
  BrightnessShalfSvg,
  Co2Svg,
  IndoorHumiditySvg,
  IndoorTemperatureSvg,
  PM10Svg,
  PM2_5Svg,
} from "../../assets/svg";
import AnalogClockContent from "./AnalogClockW";
import DigitalClockContent from "./DigitClockW";

const SensorCardForWidget = ({ data, midElement, uiType = "" }) => {
  const properties = {
    temperature: (unit = "°c") => (
      <>
        <span>
          <IndoorTemperatureSvg className="w-[18px] h-[18px] fill-[#939ca7]" />
        </span>
        <span>
          {data?.currentData?.temperature || "-- "}
          {unit}
        </span>
      </>
    ),
    humidity: (unit = "%") => (
      <>
        <span>
          <IndoorHumiditySvg className="w-[18px] h-[18px] fill-[#939ca7]" />
        </span>
        <span>
          {data?.currentData?.humidity || "-- "}
          {unit}
        </span>
      </>
    ),
    pm2_5: (unit = " µg/m³") => (
      <>
        <span>
          <PM2_5Svg className="w-[18px] h-[18px] fill-[#939ca7]" />
        </span>
        <span>
          {data?.currentData?.pm2_5 || "-- "}
          {unit}
        </span>
      </>
    ),
    pm10: (unit = " µg/m³") => (
      <>
        <span>
          <PM10Svg className="w-[18px] h-[18px] fill-[#939ca7]" />
        </span>
        <span>
          {data?.currentData?.pm10 || "-- "}
          {unit}
        </span>
      </>
    ),
    co2: (unit = " ppm") => (
      <>
        <span>
          <Co2Svg className="w-[18px] h-[18px] fill-[#939ca7]" />
        </span>
        <span>
          {data?.currentData?.co2 || "-- "}
          {unit}
        </span>
      </>
    ),
    light_intensity: (unit = " lx") => (
      <>
        <span>
          <BrightnessShalfSvg className="w-[18px] h-[18px] fill-[#939ca7]" />
        </span>
        <span>
          {data?.currentData?.light_intensity || "-- "}
          {unit}
        </span>
      </>
    ),
  };

  if (
    uiType === "weather-sensor-portrait" ||
    uiType === "weather-sensor-landscape"
  ) {
    return (
      <>
        {data.selectedProperties.map((propId) => (
          <div
            key={propId}
            className={`
                flex justify-center items-center min-w-[110px] text-nowrap ${
                  uiType === "weather-sensor-landscape" ? "w-1/3" : "w-1/2"
                }`}
          >
            <div className="flex items-center justify-start gap-3 text-[#222222] font-medium text-lg min-w-[110px]">
              {properties[propId] ? properties[propId]() : null}
            </div>
          </div>
        ))}
      </>
    );
  }
  return (
    <div className="w-full h-full flex flex-col justify-between items-center">
      {midElement ? (
        <div className="h-[60%] w-full">
          {midElement?.type === "digital-clock" ? (
            <DigitalClockContent data={midElement.data} />
          ) : midElement?.type === "analog-clock" ? (
            <AnalogClockContent data={midElement.data} clockSize="flex-grow" />
          ) : null}
        </div>
      ) : null}
      {data.selectedProperties && data.selectedProperties.length > 0 ? (
        <div className={`flex justify-evenly items-center w-full ${midElement ? "h-[40%]": "h-full"} p-4 flex-wrap`}>
          {data.selectedProperties.map((propId) => (
            <div
              key={propId}
              className={`
                flex justify-center items-center min-w-[110px] text-nowrap ${
                  uiType === "main-widget-landscape" ? "w-1/3" : "w-1/2"
                }`}
            >
              <div className="flex items-center justify-start gap-3 text-[#222222] font-medium text-lg min-w-[110px]">
                {properties[propId] ? properties[propId]() : null}
              </div>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
};

export default SensorCardForWidget;
