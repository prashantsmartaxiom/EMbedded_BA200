import { Checkbox } from "../../components";
import { useGetTimezones } from "../../api/queryHooks";

const DigitalClock = ({ timezone }) => {  
  return (
    <div className="h-[74px] w-full border border-[#C1DBF9] bg-[#F5F9FD] rounded-[10px] flex flex-col items-center justify-center">
      <div className="text-[#222222] text-[10px] font-medium">
        {timezone.timeZoneValue}
      </div>
      <div className="flex items-start justify-center mt-1 gap-[5px]">
        <div className="flex flex-col items-center">
          <span className="text-base font-semibold text-[#222222]">11</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-base font-semibold text-[#222222]">:</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-base font-semibold text-[#222222]">24</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-base font-semibold text-[#222222]">:</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-base font-semibold text-[#222222]">56</span>
        </div>
      </div>
      <div className="text-[#222222] text-[10px] font-medium">Thursday</div>
    </div>
  );
};

const DigitalClocks = ({ onSelectWidget, selectedWidgets }) => {
  const { data: timezonesData, isLoading: isLoadingTimezones } = useGetTimezones();
  const userTimezones = timezonesData?.data || [];

  const handleCheckboxChange = (timezone) => {
    const widget = {
      id: `digital-clock+${timezone._id}`,
      type: 'digital-clock',
      data: timezone,
    };
    onSelectWidget(widget);
  };

  const isSelected = (timezoneId) => {
    return selectedWidgets.some(widget => 
      widget.type === 'digital-clock' && widget.id === timezoneId
    );
  };

  if (isLoadingTimezones) {
    return (
      <div className="border-b pb-5 mb-5 border-[#DDDDDD]">
        <div className="px-5 flex items-center justify-between">
          <div className="flex items-center gap-[10px]">
            <span className="text-xs text-[#222222] font-semibold">
              Digital Clock
            </span>
          </div>
          {/* <div className="text-[#939CA7] font-medium text-xs">Max: 03</div> */}
        </div>
        <div className="px-5 py-5 text-center text-[#7A838E] text-sm">
          Loading timezones...
        </div>
      </div>
    );
  }

  if (!userTimezones.length) {
    return (
      <div className="border-b pb-5 mb-5 border-[#DDDDDD]">
        <div className="px-5 flex items-center justify-between">
          <div className="flex items-center gap-[10px]">
            <span className="text-xs text-[#222222] font-semibold">
              Digital Clock
            </span>
          </div>
          {/* <div className="text-[#939CA7] font-medium text-xs">Max: 03</div> */}
        </div>
        <div className="px-5 py-5 text-center text-[#7A838E] text-sm">
          No timezones created yet. Please create timezones in General Widgets first.
        </div>
      </div>
    );
  }

  return (
    <div className="border-b pb-5 mb-5 border-[#DDDDDD]">
      <div className="px-5 flex items-center justify-between">
        <div className="flex items-center gap-[10px]">
          <span className="text-xs text-[#222222] font-semibold">
            Digital Clock
          </span>
        </div>
        {/* <div className="text-[#939CA7] font-medium text-xs">Max: 03</div> */}
      </div>
      <div className="px-5 grid grid-cols-2 gap-3 mt-5">
        {userTimezones.map((timezone) => (
          <div key={timezone._id} className="flex items-center gap-2">
            <Checkbox 
              checked={isSelected(`digital-clock+${timezone._id}`)}
              onCheckedChange={() => handleCheckboxChange(timezone)}
            />
            <DigitalClock timezone={timezone} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default DigitalClocks;