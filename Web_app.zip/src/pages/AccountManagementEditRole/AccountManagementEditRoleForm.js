import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ROUTES } from "../../router";
import { BackspaceSvg } from "../../assets/svg";
import {
  PrimaryBtn2,
  SecondaryBtn,
  PrimaryInput,
  Checkbox,
} from "../../components";
import {
  transformPermissionsForAPI,
  mapRoleDataToPermissions,
} from "../../utils/helpers";
import { useUpdateRole } from "../../api/queryHooks";
import toaster from "../../utils/toaster";
import CONFIG from "../../config";

function AccountManagementEditRoleForm({
  ROLE_PERMISSIONS,
  ROLE_DATA,
  roleId,
}) {
  const [formData, setFormData] = useState({
    roleName: "",
    selectAllPermissions: false,
    permissions: {},
  });

  const [activeTab, setActiveTab] = useState("CAMPUS_MANAGEMENT");
  const navigate = useNavigate();

  // Use the React Query hook for updating role
  const updateRoleMutation = useUpdateRole({
    onSuccess: (data) => {
      toaster.success("Role updated successfully!");
      navigate(ROUTES.MANAGE_ROLES);
    },
    onError: (error) => {
      console.error("Error updating role:", error);
      const errorMessage =
        error?.response?.data?.message ||
        "Error updating role. Please try again.";
      toaster.error(errorMessage);
    },
  });

  // Function to check if all permissions are selected
  const areAllPermissionsSelected = (permissions) => {
    return Object.keys(permissions).every((moduleKey) => {
      return permissions[moduleKey].permissions.categories.every((category) => {
        return category.accesses.every((access) => access.checked);
      });
    });
  };

  // Effect to update form data when role data changes
  useEffect(() => {
    if (ROLE_DATA && ROLE_PERMISSIONS) {
      const mappedPermissions = mapRoleDataToPermissions(
        ROLE_DATA.permissions,
        ROLE_PERMISSIONS
      );

      const allSelected = areAllPermissionsSelected(mappedPermissions);

      setFormData({
        roleName: ROLE_DATA.roleName || "",
        selectAllPermissions: allSelected,
        permissions: mappedPermissions,
      });

      // Set the first available tab as active
      const firstTab = Object.keys(mappedPermissions)[0];
      if (firstTab) {
        setActiveTab(firstTab);
      }
    }
  }, [ROLE_DATA, ROLE_PERMISSIONS]);

  const handleRoleNameChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      roleName: e.target.value,
    }));
  };

  const handleSelectAllPermissions = (checked) => {
    setFormData((prev) => {
      const updatedPermissions = { ...prev.permissions };
      Object.keys(updatedPermissions).forEach((moduleKey) => {
        updatedPermissions[moduleKey].permissions.categories.forEach(
          (category) => {
            if (checked) {
              // When selecting all, check Full Access first if it exists
              const fullAccessIndex = category.accesses.findIndex(
                (access) => access.value === "fullAccess"
              );
              if (fullAccessIndex !== -1) {
                // Check Full Access first, which will automatically check all others
                category.accesses[fullAccessIndex].checked = true;
                // Also check all other permissions
                category.accesses.forEach((access) => {
                  if (access.value !== "fullAccess") {
                    access.checked = true;
                  }
                });
              } else {
                // If no Full Access option, check all available permissions
                category.accesses.forEach((access) => {
                  access.checked = checked;
                });
              }
            } else {
              // When unchecking all, uncheck everything
              category.accesses.forEach((access) => {
                access.checked = false;
              });
            }
          }
        );
      });

      return {
        ...prev,
        selectAllPermissions: checked,
        permissions: updatedPermissions,
      };
    });
  };

  const handlePermissionChange = (
    moduleKey,
    categoryIndex,
    accessIndex,
    checked
  ) => {
    setFormData((prev) => {
      const updatedPermissions = { ...prev.permissions };
      const category =
        updatedPermissions[moduleKey].permissions.categories[categoryIndex];
      const currentAccess = category.accesses[accessIndex];

      // Update the clicked permission
      currentAccess.checked = checked;

      // Get all non-fullAccess permissions in this category
      const otherPermissions = category.accesses.filter(
        (access) => access.value !== "fullAccess"
      );
      const fullAccessIndex = category.accesses.findIndex(
        (access) => access.value === "fullAccess"
      );

      // Handle Full Access logic
      if (currentAccess.value === "fullAccess") {
        if (checked) {
          // If Full Access is checked, check all other permissions
          otherPermissions.forEach((access) => {
            access.checked = true;
          });
        } else {
          // If Full Access is unchecked, uncheck all other permissions
          otherPermissions.forEach((access) => {
            access.checked = false;
          });
        }
      } else {
        // If any other permission is unchecked, uncheck Full Access
        if (!checked) {
          if (fullAccessIndex !== -1) {
            category.accesses[fullAccessIndex].checked = false;
          }
        }
        // If all other permissions are checked, check Full Access
        else if (checked) {
          const allOtherPermissionsChecked = otherPermissions.every(
            (access) => access.checked
          );
          if (allOtherPermissionsChecked && fullAccessIndex !== -1) {
            category.accesses[fullAccessIndex].checked = true;
          }
        }
      }

      // Check if all permissions are now selected and update selectAllPermissions accordingly
      const allSelected = areAllPermissionsSelected(updatedPermissions);

      return {
        ...prev,
        selectAllPermissions: allSelected,
        permissions: updatedPermissions,
      };
    });
  };

  const handleReset = () => {
    if (ROLE_DATA && ROLE_PERMISSIONS) {
      const mappedPermissions = mapRoleDataToPermissions(
        ROLE_DATA.permissions,
        ROLE_PERMISSIONS
      );

      const allSelected = areAllPermissionsSelected(mappedPermissions);

      setFormData({
        roleName: ROLE_DATA.roleName || "",
        selectAllPermissions: allSelected,
        permissions: mappedPermissions,
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      roleId,
      roleData: {
        roleName: formData.roleName,
        permissions: transformPermissionsForAPI(formData.permissions),
      },
    };

    updateRoleMutation.mutate(payload);
  };

  if ((!CONFIG.CAN_EDIT_DEFAULT_ROLES) && ROLE_DATA?.byDefault === "true" || ROLE_DATA?.byDefault === true) {
    return (
      <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow flex items-center justify-center">
        <p className="text-[#222222]">
          This role is a default role and cannot be edited.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mb-5">
        <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
          <Link
            to={ROUTES.MANAGE_ROLES}
            className="flex items-center gap-[10px]"
          >
            <BackspaceSvg />
            <h2 className="text-[#222222] font-bold">Edit Role</h2>
          </Link>
          <div className="flex items-center gap-[15px]">
            <SecondaryBtn
              className={"w-[80px] justify-center"}
              onClick={handleReset}
              type="button"
            >
              RESET
            </SecondaryBtn>
            <PrimaryBtn2
              type="submit"
              disabled={
                updateRoleMutation.isLoading || !formData.roleName.trim()
              }
              className={"w-[80px] justify-center"}
            >
              {updateRoleMutation.isLoading ? "UPDATING..." : "UPDATE"}
            </PrimaryBtn2>
          </div>
        </div>

        <div className="">
          <div className="flex items-center gap-4">
            <label className="text-xs font-medium text-[#222222] w-20">
              Role Name:
            </label>
            <PrimaryInput
              placeholder="Role title"
              className="flex-1 max-w-md"
              value={formData.roleName}
              onChange={handleRoleNameChange}
              required
            />
            <div className="flex items-center gap-2 ml-8">
              <Checkbox
                id="selectAll"
                checked={formData.selectAllPermissions}
                onCheckedChange={(checked) =>
                  handleSelectAllPermissions(checked)
                }
              />
              <label htmlFor="selectAll" className="text-xs text-[#222222]">
                Select all permissions
              </label>
            </div>
          </div>
        </div>
      </div>

      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mb-5">
        <div className="mb-6">
          <div className="flex border-b border-[#E5E7EB]">
            {Object.entries(formData.permissions).map(([key, module]) => (
              <button
                key={key}
                type="button"
                onClick={() => setActiveTab(key)}
                className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === key
                    ? "border-[#227EEB] text-[#227EEB]"
                    : "border-transparent text-[#6B7280] hover:text-[#222222]"
                }`}
              >
                {module.label}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg border border-[#CCCCCC] overflow-hidden">
          <table className="w-full text-xs">
            {/* Table Header */}
            {formData.permissions[activeTab]?.permissions?.categories?.length >
              0 && (
              <thead>
                <tr className="bg-[#EEEEEE]">
                  <th className="text-left px-4 py-3 font-medium text-[#222222] text-xs">
                    {formData.permissions[activeTab]?.label}
                  </th>
                  {formData.permissions[
                    activeTab
                  ]?.permissions?.categories[0]?.accesses?.map((access) => (
                    <th
                      key={access.value}
                      className="text-center px-4 py-3 font-medium text-[#222222] text-xs"
                    >
                      {access.label}
                    </th>
                  ))}
                </tr>
              </thead>
            )}

            {/* Table Body */}
            <tbody>
              {formData.permissions[activeTab]?.permissions?.categories?.map(
                (category, categoryIndex) => (
                  <tr key={categoryIndex} className="border-t border-[#F3F4F6]">
                    <td className="px-4 py-3 text-[#222222] text-xs">
                      {category.name}
                    </td>
                    {category.accesses?.map((access, accessIndex) => (
                      <td key={access.value} className="px-4 py-3">
                        <div className="flex justify-center">
                          <Checkbox
                            id={`${activeTab}-${categoryIndex}-${access.value}`}
                            checked={access.checked}
                            onCheckedChange={(checked) =>
                              handlePermissionChange(
                                activeTab,
                                categoryIndex,
                                accessIndex,
                                checked
                              )
                            }
                          />
                        </div>
                      </td>
                    ))}
                  </tr>
                )
              )}
            </tbody>
          </table>
        </div>

        {/* Role Status Information */}
        <div className="mt-6 bg-[#F9F9F9] rounded-lg p-4">
          <h4 className="text-sm font-medium text-[#222222] mb-3">
            Role Information
          </h4>
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-[#666666]">Role ID:</span>
              <span className="ml-2 text-[#222222]">{ROLE_DATA._id}</span>
            </div>
            <div>
              <span className="text-[#666666]">Created:</span>
              <span className="ml-2 text-[#222222]">
                {new Date(ROLE_DATA.createdAt).toLocaleDateString()}
              </span>
            </div>
            <div>
              <span className="text-[#666666]">Status:</span>
              <span
                className={`ml-2 font-medium ${
                  ROLE_DATA.isActive ? "text-green-600" : "text-red-600"
                }`}
              >
                {ROLE_DATA.isActive ? "Active" : "Inactive"}
              </span>
            </div>
            <div>
              <span className="text-[#666666]">Last Updated:</span>
              <span className="ml-2 text-[#222222]">
                {new Date(ROLE_DATA.updatedAt).toLocaleDateString()}
              </span>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
}

export default AccountManagementEditRoleForm;
