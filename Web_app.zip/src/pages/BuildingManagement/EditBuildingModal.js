import { useFormik } from "formik";
import * as Yup from "yup";
import { useGetBuildingById, useUpdateBuilding } from "../../api/queryHooks";
import {
  BottomRightModal,
  BottomRightModalHeader,
  PrimaryBtn2,
  PrimaryDropdown,
  PrimaryInput,
  PrimaryTextarea,
  SpinnerV1,
} from "../../components";
import { BUILDING_TYPES } from "../../consts";
import { useEffect } from "react";
import toaster from "../../utils/toaster";

const validationSchema = Yup.object({
  name: Yup.string().required("Building name is required"),
  type: Yup.string().required("Building type is required"),
  description: Yup.string().optional(),
});

function EditBuildingForm({ buildingId, toggleModal, onSuccess }) {
  const {
    data,
    isLoading: isLoadingBuilding,
    isError,
  } = useGetBuildingById(buildingId);
  const buildingData = data?.data?.building;

  const { mutate: updateBuilding, isLoading } = useUpdateBuilding({
    onSuccess: () => {
      toggleModal(false);
      onSuccess?.();
    },
    onError: (error) => {
      const errorMessage =
        error.response?.data?.message || "Building update failed";
      console.error("Error updating building:", error);
      toaster.error(errorMessage);
    },
  });

  const formik = useFormik({
    initialValues: {
      name: "",
      type: "",
      description: "",
    },
    validationSchema,
    onSubmit: (values) => {
      updateBuilding({
        buildingId,
        buildingData: values,
      });
    },
  });

  // Update form values when building data is loaded
  useEffect(() => {
    if (buildingData) {
      const building = buildingData;
      formik.setValues({
        name: building.name || "",
        type: building.type || "",
        description: building.description || "",
      });
    }
  }, [buildingData]);

  if (isLoadingBuilding) {
    return (
      <div className="p-5">
        <SpinnerV1 />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex-grow flex items-center justify-center">
        <div className="text-red-500">Error loading building data</div>
      </div>
    );
  }

  return (
    <form
      onSubmit={formik.handleSubmit}
      className="flex-grow flex flex-col justify-between"
    >
      <div>
        <div className="flex items-center justify-between px-5 pb-5 mb-5">
          <label htmlFor="buildingName" className="text-[#222222] text-[12px]">
            Building Name
          </label>
          <div>
            <PrimaryInput
              id="name"
              name="name"
              className="w-[300px]"
              placeholder="Enter building name"
              value={formik.values.name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.touched.name && formik.errors.name && (
              <p className="text-red-500 text-xs mt-1">{formik.errors.name}</p>
            )}
          </div>
        </div>

        {/* <div className="flex items-center justify-between px-5 pb-5 mb-5">
          <label htmlFor="buildingType" className="text-[#222222] text-[12px]">
            Building Type
          </label>
          <div className="w-[300px]">
            <PrimaryDropdown
              className="w-full"
              options={BUILDING_TYPES}
              value={formik.values.type}
              onValueChange={(value) => formik.setFieldValue("type", value)}
              placeholder="Select Type"
            />
            {formik.touched.type && formik.errors.type && (
              <p className="text-red-500 text-xs mt-1">{formik.errors.type}</p>
            )}
          </div>
        </div> */}

        <div className="flex items-start justify-between px-5">
          <label
            htmlFor="description"
            className="text-[#222222] text-[12px] mt-2"
          >
            Description
            <p className="text-[#939CA7] text-[10px]">(Optional)</p>
          </label>
          <div className="w-[300px]">
            <PrimaryTextarea
              id="description"
              name="description"
              className="w-full h-[82px] resize-none"
              placeholder="Enter description"
              value={formik.values.description}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
          </div>
        </div>
      </div>

      <div className="p-5 flex justify-end border-t border-[#DDDDDD]">
        <PrimaryBtn2
          type="submit"
          className="min-w-20 justify-center"
          disabled={isLoading || !formik.isValid}
        >
          {isLoading ? "Updating..." : "UPDATE"}
        </PrimaryBtn2>
      </div>
    </form>
  );
}

function EditBuildingModal({ buildingId, toggleModal, onSuccess }) {
  return (
    <BottomRightModal
      toggleModal={toggleModal}
      className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
    >
      <BottomRightModalHeader toggleModal={toggleModal} title="Edit Building" />
      <EditBuildingForm
        buildingId={buildingId}
        toggleModal={toggleModal}
        onSuccess={onSuccess}
      />
    </BottomRightModal>
  );
}

export default EditBuildingModal;
