import { SearchInput } from "../../components";
import useUserStore from "../../store/useUserStore";
import AddNewBuildingModal from "./AddNewBuildingModal";

function Header({ onSearchChange }) {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
      <h2 className="text-[#222222] font-bold">Building Management</h2>
      <div className="flex items-center gap-[15px]">
        <SearchInput
          className="w-[260px]"
          placeholder="Search by building name, campus…"
          onChange={(e) => onSearchChange(e.target.value)}
        />
        {userPermissions?.CAMPUS_MANAGEMENT?.building_management?.addModify ? (
          <AddNewBuildingModal />
        ) : null}
      </div>
    </div>
  );
}

export default Header;
