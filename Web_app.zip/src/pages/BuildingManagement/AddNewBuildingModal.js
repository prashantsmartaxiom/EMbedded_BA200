import { useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useCreateBuilding, useGetCampusOptions } from "../../api/queryHooks";
import {
  BottomRightModal,
  BottomRightModalHeader,
  PrimaryBtn2,
  PrimaryDropdown,
  PrimaryInput,
  PrimaryTextarea,
  SecondaryBtnLink,
} from "../../components";
import { AddSvg } from "../../assets/svg";
import { UNUSED_API_VARIABLES } from "../../consts";
import toaster from "../../utils/toaster";

const validationSchema = Yup.object({
  campusId: Yup.string().required("Campus is required"),
  name: Yup.string().required("Building name is required"),
  floorCount: Yup.number().min(1).max(100).required("Floor count is required"),
  description: Yup.string().optional(),
});

function BuildingForm({ toggleModal }) {
  const { data: campuses, isLoading: isLoadingCampuses } =
    useGetCampusOptions();

  const { mutate: createBuilding, isLoading } = useCreateBuilding({
    onSuccess: () => {
      toggleModal(false);
    },
    onError: (error) => {
      const errorMessage =
        error.response?.data?.message || "Building creation failed";
      toaster.error(errorMessage);
    },
  });

  const formik = useFormik({
    initialValues: {
      campusId: "",
      name: "",
      floorCount: 1,
      type: UNUSED_API_VARIABLES.TYPE,
      status: "active",
      description: "",
    },
    validationSchema,
    onSubmit: (values) => {
      const { campusId, ...payload } = values;
      createBuilding({
        campusId,
        payload,
      });
    },
  });

  return (
    <form
      onSubmit={formik.handleSubmit}
      className="flex-grow flex flex-col justify-between"
    >
      <div>
        <div className="px-5 pb-5 mb-5 border-b border-[#DDDDDD]">
          <div className="flex items-center justify-between w-full">
            <label htmlFor="campusName" className="text-[#222222] text-[12px]">
              Campus Name
            </label>
            <div className="w-[300px]">
              <PrimaryDropdown
                className="w-full"
                options={campuses || []}
                value={formik.values.campusId}
                onValueChange={(value) =>
                  formik.setFieldValue("campusId", value)
                }
                placeholder={isLoadingCampuses ? "Loading..." : "Select Campus"}
                disabled={isLoadingCampuses}
              />
              {formik.touched.campusId && formik.errors.campusId && (
                <p className="text-red-500 text-xs mt-1">
                  {formik.errors.campusId}
                </p>
              )}
            </div>
          </div>
        </div>

        {formik.values.campusId && (
          <>
            <div className="flex items-center justify-between px-5 mb-5">
              <label
                htmlFor="buildingName"
                className="text-[#222222] text-[12px]"
              >
                Building Name
              </label>
              <div>
                <PrimaryInput
                  id="name"
                  name="name"
                  className="w-[300px]"
                  placeholder="Enter building name"
                  value={formik.values.name}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.touched.name && formik.errors.name && (
                  <p className="text-red-500 text-xs mt-1">
                    {formik.errors.name}
                  </p>
                )}
              </div>
            </div>
            <div className="flex items-center justify-between px-5 mb-5">
              <label
                htmlFor="floorCount"
                className="text-[#222222] text-[12px]"
              >
                Floor Count
              </label>
              <div className="w-[300px]">
                <PrimaryDropdown
                  className="w-[80px]"
                  options={Array.from({ length: 10 }, (_, i) => ({
                    value: String(i + 1),
                    label: String(i + 1),
                  }))}
                  value={String(formik.values.floorCount)}
                  onValueChange={(value) =>
                    formik.setFieldValue("floorCount", Number(value))
                  }
                  placeholder="Select"
                />
              </div>
            </div>
            <div className="flex items-start justify-between px-5">
              <label
                htmlFor="description"
                className="text-[#222222] text-[12px] mt-2"
              >
                Description
                <p className="text-[#939CA7] text-[10px]">(Optional)</p>
              </label>
              <div className="w-[300px]">
                <PrimaryTextarea
                  id="description"
                  name="description"
                  className="w-full h-[82px] resize-none"
                  placeholder="Enter description"
                  value={formik.values.description}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
              </div>
            </div>
          </>
        )}
      </div>
      <div className="p-5 flex justify-end border-t border-[#DDDDDD]">
        <PrimaryBtn2
          type="submit"
          className="min-w-20 justify-center"
          disabled={isLoading || !formik.isValid}
        >
          {isLoading ? "Adding..." : "ADD"}
        </PrimaryBtn2>
      </div>
    </form>
  );
}

function AddNewBuildingModal() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = (value) => {
    setIsOpen(value);
  };

  return (
    <>
      <SecondaryBtnLink
        onClick={() => toggleModal(true)}
        className={"w-[135px] justify-center"}
        Icon={AddSvg}
      >
        NEW BUILDING
      </SecondaryBtnLink>
      {isOpen ? (
        <BottomRightModal
          toggleModal={toggleModal}
          className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
        >
          <BottomRightModalHeader
            toggleModal={toggleModal}
            title="Add New Building"
          />
          <BuildingForm toggleModal={toggleModal} />
        </BottomRightModal>
      ) : null}
    </>
  );
}

export default AddNewBuildingModal;
