import { useState, useEffect, useRef } from "react";
import { AddSvg, DeleteSvg } from "../../assets/svg";
import AnalogClock from "../../components/AnalogClock";
import {
  useGetTimezones,
  useGetAllTimezoneOptions,
  useCreateTimezone,
  useInitializeTimezones,
  useGetWeatherLocations,
  useCreateWeatherLocation,
  useDeleteWeatherLocation,
  useUpdateWeatherLocation,
  useDeleteTimezone,
} from "../../api/queryHooks";
import { toast } from "react-toastify";
import { PrimaryDropdown, SpinnerV1, WeatherWidget } from "../../components";
import DeleteTimezonePopup from "./DeleteTimezonePopup";
import DeleteLocationPopup from "./DeleteLocationPopup";

const NewButton = ({ children, className = "", ...props }) => {
  return (
    <button
      className="flex-col flex-shrink-0 text-xs font-bold fill-[#227EEB] text-[#227EEB] flex items-center justify-center w-[90px] h-[160px] bg-[#E6F0FC] rounded-[10px] disabled:opacity-50"
      {...props}
    >
      <div>
        <AddSvg />
      </div>
      <div className="mt-1">{children}</div>
    </button>
  );
};

const DeleteTimezone = ({ timezoneId }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <button
        onClick={toggleModal}
        className="w-7 h-7 flex items-center justify-center rounded-md bg-[#FF1212] text-white fill-white"
      >
        <DeleteSvg />
      </button>
      {open ? (
        <DeleteTimezonePopup toggleModal={toggleModal} timezoneId={timezoneId} />
      ) : null}
    </>
  );
};

const DeleteLocation = ({ locationId }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <button
        onClick={toggleModal}
        className="w-7 h-7 flex items-center justify-center rounded-md bg-[#FF1212] text-white fill-white"
      >
        <DeleteSvg />
      </button>
      {open ? (
        <DeleteLocationPopup toggleModal={toggleModal} locationId={locationId} />
      ) : null}
    </>
  );
};

const Timezones = () => {
  const [pendingClocks, setPendingClocks] = useState([]);
  const initializeTimezonesMutation = useInitializeTimezones();
  const timezoneContainerRef = useRef(null);

  const {
    data: timezonesData,
    isLoading: isLoadingTimezones,
    refetch: refetchTimezones,
  } = useGetTimezones({
    onSuccess: (data) => {
      initializeTimezonesMutation.mutate();
    },
  });
  const { data: timezoneOptionsData, isLoading: isLoadingOptions } =
    useGetAllTimezoneOptions();
  const createTimezoneMutation = useCreateTimezone();

  const userTimezones = timezonesData?.data || [];
  const timezoneOptions =
    timezoneOptionsData?.data?.map((tz) => ({
      value: tz._id,
      label: `${tz.timeZoneValue} (${tz.timeZoneName?.split(" (")?.[1]}`,
      timeZoneName: tz.timeZoneName,
      timeZoneValue: tz.timeZoneValue,
      _id: tz._id,
    })) || [];

  const handleAddTimezone = () => {
    if (pendingClocks?.length > 0) return;
    setPendingClocks((prev) => [...prev, { id: Date.now(), isNew: true }]);
    
    // Scroll to the new card after a small delay
    setTimeout(() => {
      if (timezoneContainerRef.current) {
        timezoneContainerRef.current.scrollTo({
          left: timezoneContainerRef.current.scrollWidth,
          behavior: 'smooth'
        });
      }
    }, 100);
  };

  const handleTimezoneSelect = (timezoneOption, clockId) => {
    const payload = {
      timeZoneName: timezoneOption.timeZoneName,
      timeZoneValue: timezoneOption.timeZoneValue,
    };

    createTimezoneMutation.mutate(payload, {
      onSuccess: (response) => {
        toast.success("Timezone added successfully!");

        setPendingClocks((prev) =>
          prev.filter((clock) => clock.id !== clockId)
        );

        refetchTimezones();
      },
      onError: (error) => {
        console.error("Failed to create timezone:", error);
        toast.error("Failed to add timezone");
      },
    });
  };

  if (isLoadingTimezones || isLoadingOptions) {
    return (
      <div className="flex items-center justify-center h-32">
        <div className="text-[#7A838E] text-sm">
          <SpinnerV1 />
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="flex items-center justify-between">
        <h2 className="text-[#222222] text-[14px] font-semibold">Timezone</h2>
      </div>
      <div className="flex flex-wrap gap-[15px] my-5 border-b border-[#DDDDDD] pb-5 h-scroll" ref={timezoneContainerRef}>
        <NewButton
          onClick={handleAddTimezone}
          disabled={pendingClocks?.length > 0 ? true : false}
        >
          TIMEZONE
        </NewButton>
        {userTimezones.map((timezone) => (
          <div className="relative group" key={timezone._id}>
            <AnalogClock
              key={timezone._id}
              timezone={{
                ...timezone,
                id: timezone._id,
                timeZoneName: timezone.timeZoneName,
                timeZoneValue: timezone.timeZoneValue,
              }}
              timezoneOptions={timezoneOptions}
            />
            <div className="absolute top-[40px] left-[134px] group-hover:opacity-100 opacity-0 transition-opacity duration-200">
              <DeleteTimezone timezoneId={timezone._id} />
            </div>
          </div>
        ))}
        {pendingClocks.map((clock) => (
          <AnalogClock
            key={clock.id}
            timezone={null}
            timezoneOptions={timezoneOptions}
            showDropdown={true}
            onTimezoneSelect={(option) =>
              handleTimezoneSelect(option, clock.id)
            }
          />
        ))}
      </div>
    </>
  );
};

const Locations = () => {
  const [pendingLocations, setPendingLocations] = useState([]);
  const locationContainerRef = useRef(null);

  const {
    data: weatherLocationsData,
    isLoading: isLoadingLocations,
    refetch: refetchLocations,
  } = useGetWeatherLocations();

  const createLocationMutation = useCreateWeatherLocation();
  const updateLocationMutation = useUpdateWeatherLocation();

  const userLocations = weatherLocationsData?.data || [];

  const handleAddLocation = () => {
    if (pendingLocations.length > 0) return;
    setPendingLocations((prev) => [...prev, { id: Date.now(), isNew: true }]);
    
    // Scroll to the new card after a small delay
    setTimeout(() => {
      if (locationContainerRef.current) {
        locationContainerRef.current.scrollTo({
          left: locationContainerRef.current.scrollWidth,
          behavior: 'smooth'
        });
      }
    }, 100);
  };

  const handleLocationSelect = (selectedOption, locationId) => {
    const payload = {
      lat: selectedOption.lat,
      long: selectedOption.long,
      placeName: selectedOption.placeName,
    };

    createLocationMutation.mutate(payload, {
      onSuccess: (response) => {
        toast.success("Location added successfully!");
        setPendingLocations((prev) =>
          prev.filter((loc) => loc.id !== locationId)
        );
        refetchLocations();
      },
      onError: (error) => {
        console.error("Failed to create location:", error);
        toast.error("Failed to add location");
      },
    });
  };

  const handleLocationUpdate = (selectedOption, existingLocation) => {
    const payload = {
      lat: selectedOption.lat,
      long: selectedOption.long,
      placeName: selectedOption.placeName,
    };

    updateLocationMutation.mutate(
      { id: existingLocation._id, locationData: payload },
      {
        onSuccess: () => {
          toast.success("Location updated successfully!");
          refetchLocations();
        },
        onError: (error) => {
          console.error("Failed to update location:", error);
          toast.error("Failed to update location");
        },
      }
    );
  };

  if (isLoadingLocations) {
    return (
      <div className="flex items-center justify-center h-32">
        <div className="text-[#7A838E] text-sm">
          <SpinnerV1 />
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="flex items-center justify-between">
        <h2 className="text-[#222222] text-[14px] font-semibold">Location</h2>
      </div>
      <div className="flex flex-wrap gap-[15px] my-5 border-b border-[#DDDDDD] pb-5 h-scroll" ref={locationContainerRef}>
        <NewButton
          onClick={handleAddLocation}
          disabled={pendingLocations.length > 0}
        >
          LOCATION
        </NewButton>

        {/* Existing user locations */}
        {userLocations.map((location) => (
          <div className="relative group" key={location._id}>
            <WeatherWidget
              key={location._id}
              location={location}
              onLocationChange={(selectedOption) =>
                handleLocationUpdate(selectedOption, location)
              }
            />
            <div className="absolute top-[40px] left-[134px] group-hover:opacity-100 opacity-0 transition-opacity duration-200">
              <DeleteLocation locationId={location._id} />
            </div>
          </div>
        ))}
        {/* Pending new locations */}
        {pendingLocations.map((location) => (
          <WeatherWidget
            key={location.id}
            location={null}
            isNewLocation={true}
            onLocationChange={(selectedOption) =>
              handleLocationSelect(selectedOption, location.id)
            }
          />
        ))}
      </div>
    </>
  );
};

const GeneralWidgets = () => {

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
          <h2 className="text-[#222222] font-bold">Utilities General</h2>
        </div>
        <Timezones />
        <Locations />
      </div>
    </div>
  );
};

export default GeneralWidgets;
