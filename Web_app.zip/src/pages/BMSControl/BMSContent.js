import { useState } from "react";
import ConfiguredDevices from "./ConfiguredDevices";
import Header from "./Header";

function BMSContent({ search, onSearchChange }) {
  const [selectedDevice, setSelectedDevice] = useState("");

  const handleDeviceChange = (deviceId) => {
    setSelectedDevice(deviceId);
  };

  return (
    <div>
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header 
          onSearchChange={onSearchChange} 
          selectedDevice={selectedDevice}
          onDeviceChange={handleDeviceChange}
        />
        <div className="flex items-center justify-between">
          <h2 className="text-[#222222] text-[14px] font-semibold">
            Configured Devices
          </h2>
        </div>
        <ConfiguredDevices search={search} deviceFilter={selectedDevice} />
      </div>
    </div>
  );
}

export default BMSContent;