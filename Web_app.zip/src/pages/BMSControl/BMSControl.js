import { useDebouncedCallback } from "use-debounce";
import BMSContent from "./BMSContent";
import { useState } from "react";
import useUserStore from "../../store/useUserStore";
import { PermissionDenied } from "../../components";

function BMSControl() {
  const [search, setSearch] = useState("");
  const userPermissions = useUserStore((state) => state.permissions);

  const debouncedSearch = useDebouncedCallback((value) => {
    setSearch(value);
  }, 500);

  if (!userPermissions?.DEVICE_MANAGEMENT?.device_control?.readOnly)
    return <PermissionDenied />;

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <BMSContent onSearchChange={debouncedSearch} search={search} />
    </div>
  );
}

export default BMSControl;