import { Link } from "react-router-dom";
import { ROUTES } from "../../router";
import { BackspaceSvg, EditSvg } from "../../assets/svg";
import { SecondaryBtn } from "../../components";

import { useState } from "react";
import { DeleteSvg } from "../../assets/svg";
import DeleteZonePopup from "../../pages/ViewZoneDetails/DeleteZonePopup";
import EditZoneModal from "../../pages/ZoneManagement/EditZoneModal";
import useUserStore from "../../store/useUserStore";

const EditZone = ({ zone }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <SecondaryBtn
        onClick={toggleModal}
        className={"w-[80px] justify-center fill-[#227EEB]"}
        Icon={EditSvg}
      >
        EDIT
      </SecondaryBtn>
      {open ? (
        <EditZoneModal toggleModal={toggleModal} zoneId={zone._id} />
      ) : null}
    </>
  );
};

function DeleteZoneButton({ zoneId }) {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <SecondaryBtn
        className={
          "justify-center fill-[#227EEB] !text-[#FF1212] !border-[#FF1212]"
        }
        onClick={toggleModal}
        iconClassName="fill-[#FF1212]"
        Icon={DeleteSvg}
      >
        DELETE
      </SecondaryBtn>

      {open && <DeleteZonePopup toggleModal={toggleModal} zoneId={zoneId} />}
    </>
  );
}

function Header({ zone }) {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
      <Link
        to={ROUTES.ZONE_MANAGEMENT}
        className="flex items-center gap-[10px]"
      >
        <BackspaceSvg />
        <h2 className="text-[#222222] font-bold">View Zone Details</h2>
      </Link>
      <div className="flex items-center gap-[15px]">
        {userPermissions?.CAMPUS_MANAGEMENT?.zone_management?.addModify ? (
          <EditZone zone={zone} />
        ) : null}
        {userPermissions?.CAMPUS_MANAGEMENT?.zone_management?.delete ? (
          <DeleteZoneButton zoneId={zone?._id} />
        ) : null}
      </div>
    </div>
  );
}

export default Header;
