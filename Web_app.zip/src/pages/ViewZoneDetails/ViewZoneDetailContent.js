import { ZoneSvg } from "../../assets/svg";
import { ZoneUpdateStatusDropdown } from "../../components/Cards/ZoneCard";
import useUserStore from "../../store/useUserStore";
import { formatDatev1, padStart } from "../../utils/helpers";

function ViewZoneDetailContent({ zone }) {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div>
      <div className="flex items-center gap-5">
        <div className="w-[68px] h-[142px] flex items-center justify-center bg-[#E6F0FC] rounded-[8px] flex-shrink-0">
          <ZoneSvg className="fill-[#227EEB] h-[32px] w-[32px]" />
        </div>
        <div className="flex-grow">
          <div className="flex items-center justify-between">
            <h2 className="text-[#222222] font-semibold">{zone?.zoneName}</h2>
            <div className="flex items-center gap-5">
              {userPermissions?.CAMPUS_MANAGEMENT?.zone_management
                ?.addModify ? (
                <ZoneUpdateStatusDropdown zone={zone} />
              ) : null}
            </div>
          </div>

          <div className="mt-1 mb-4">
            <div className="flex items-center mb-1">
              <h2 className="text-[#7A838E] text-[12px] w-[80px]">Building:</h2>
              <p className="text-[#222222] text-[12px]">{zone?.buildingName}</p>
            </div>
            <div className="flex items-center">
              <h2 className="text-[#7A838E] text-[12px] w-[80px]">
                Description:
              </h2>
              <p className="text-[#222222] text-[12px]">
                {zone?.zoneDescription ? zone.zoneDescription : "-"}
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-5">
              <div className="text-[10px] bg-[#EEEEEE] p-[6px] w-fit min-w-[85px] text-center text-[#222222] rounded-md">
                {zone?.status}
              </div>
              <div className="flex items-center gap-[15px]">
                <button
                  type="button"
                  className="flex items-center gap-[5px] text-[#222222] text-xs"
                >
                  Devices: {padStart(zone?.configuredDeviceCount)}
                </button>
              </div>
            </div>

            <button
              type="button"
              className="text-[#7A838E] flex items-center gap-[10px] text-[12px]"
            >
              Added on: {formatDatev1(zone?.createdAt)}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ViewZoneDetailContent;
