import { useState } from "react";
import {
  MdArrowDownSvg,
  ZoneSvg,
  DeleteSvg,
  EditSvg,
  AddSvg,
} from "../../assets/svg";
import EditZoneModal from "../ZoneManagement/EditZoneModal";
import DeleteZonePopup from "./DeleteZonePopup";

const EditZoneButton = ({ zoneId }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <button
        className="flex items-center justify-center rounded bg-[#227EEB] w-7 h-7"
        onClick={toggleModal}
        title="Edit"
      >
        <EditSvg className="fill-[#ffffff]" />
      </button>
      {open && <EditZoneModal toggleModal={toggleModal} zoneId={zoneId} />}
    </>
  );
};

const DeleteZoneButton = ({ zoneId }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <button
        className="flex items-center justify-center rounded bg-[#FF1212] w-7 h-7"
        onClick={toggleModal}
        title="Delete"
      >
        <DeleteSvg className="fill-[#ffffff]" />
      </button>
      {open && <DeleteZonePopup toggleModal={toggleModal} zoneId={zoneId} />}
    </>
  );
};

const DeviceCardForAccordian = ({ device }) => {
  return (
    <div className="cursor-pointer bg-[#E9F3FC] border border-[#BED9F9] rounded-lg flex items-center justify-between px-3 py-3 group hover:shadow-md transition-all duration-200 relative">
      <div className="flex items-center gap-2">
        <ZoneSvg className="fill-[#227EEB] text-[#227EEB]" />
        <span className="text-[#222222] text-[14px] font-medium">
          {device?.name || "Device"}
        </span>
      </div>

      <span className="text-[#7A838E] text-[12px] group-hover:opacity-0 transition-opacity duration-200">
        Type: {device?.type || "Unknown"}
      </span>

      <div className="absolute right-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <EditZoneButton zoneId={device?.zoneId || device?.id} />
        <DeleteZoneButton zoneId={device?.zoneId || device?.id} />
      </div>
    </div>
  );
};

const ZoneAccordian = ({ zone }) => {
  const [isOpen, setIsOpen] = useState(true);
  const zoneId = zone?._id || zone?.id;

  return (
    <div className="border rounded-[10px] overflow-hidden">
      <div
        className="flex items-center justify-between bg-[#F2F4F8] px-4 h-[46px] cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="flex items-center gap-2">
          <MdArrowDownSvg className={`${isOpen ? "rotate-180" : ""}`} />
          <ZoneSvg className="fill-[#227EEB]" />
          <span className="text-[#222222] text-[14px] font-semibold">
            {zone?.name}
          </span>
        </div>

        <div
          className="flex items-center gap-4"
          onClick={(e) => e.stopPropagation()}
        >
          <button
            type="button"
            className="text-[#222222] text-[12px] flex items-center gap-[5px]"
          >
            <AddSvg className="text-[#222222] text-[12px]" /> New Device
          </button>
          <EditZoneButton zoneId={zoneId} />
          <DeleteZoneButton zoneId={zoneId} />
        </div>
      </div>

      {isOpen && (
        <div className="grid grid-cols-4 gap-3 p-3">
          {zone?.devices?.length === 0 ? (
            <div className="text-xs text-[#222222] text-center p-5 w-full">
              No devices available
            </div>
          ) : (
            zone?.devices?.map((device, index) => (
              <DeviceCardForAccordian
                key={device.id || index}
                device={device}
              />
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default ZoneAccordian;
