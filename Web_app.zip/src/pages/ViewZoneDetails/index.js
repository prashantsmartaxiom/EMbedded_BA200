import { useParams } from "react-router-dom";
import { useGetZoneById } from "../../api/queryHooks";
import { PermissionDenied, SpinnerV1 } from "../../components";
import Header from "./Header";
import ViewZoneDetailContent from "./ViewZoneDetailContent";
import useUserStore from "../../store/useUserStore";
// import ZoneAccordian from "./ZoneAccordian";

function ViewZoneDetails() {
  const userPermissions = useUserStore((state) => state.permissions);

  const { id } = useParams();
  const { data, isLoading, error } = useGetZoneById(id);
  const zone = data?.data?.zone;

  if (!userPermissions?.CAMPUS_MANAGEMENT?.zone_management?.readOnly)
    return <PermissionDenied />;

  if (isLoading)
    return (
      <div className="p-5 mt-5">
        <SpinnerV1 />
      </div>
    );
  if (error) return <div className="p-5 mt-5 text-center">Zone not found</div>;
  if (!zone)
    return <div className="p-5 mt-5 text-center">Something went wrong</div>;

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header zone={zone} />
        <ViewZoneDetailContent zone={zone} />
      </div>
      {/* <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mt-[15px] flex flex-col gap-5">
        {zone?.zones?.length ? (
          zone?.zones?.map((zone) => (
            <ZoneAccordian key={zone.id} zone={zone} />
          ))
        ) : (
          <div className="p-5 text-[#222222] text-center text-xs">
            No zones available
          </div>
        )}
      </div> */}
    </div>
  );
}

export default ViewZoneDetails;
