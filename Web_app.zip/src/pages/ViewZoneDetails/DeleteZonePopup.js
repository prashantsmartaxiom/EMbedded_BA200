import { WarningSvg } from "../../assets/svg";
import { SecondaryBtn } from "../../components";
import { CenterModal } from "../../components/Models";
import { useDeleteZone } from "../../api/queryHooks";
import toaster from "../../utils/toaster";
import { useNavigate } from "react-router-dom";
import { ROUTES } from "../../router";

function DeleteZonePopup({
  toggleModal,
  zoneId,
  onSuccess,
  navigateToRoute = ROUTES.ZONE_MANAGEMENT,
}) {
  const navigate = useNavigate();

  const { mutate: deleteZone, isLoading } = useDeleteZone({
    onSuccess: () => {
      toaster.success("Zone deleted successfully");
      toggleModal();
      if (navigateToRoute) navigate(navigateToRoute);
      onSuccess?.();
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || "Failed to delete zone");
    },
  });

  const handleDelete = () => {
    deleteZone(zoneId);
  };

  return (
    <CenterModal
      toggleModal={toggleModal}
      className="max-w-[460px] w-full p-8 flex flex-col items-center gap-6"
    >
      <div>
        <WarningSvg className="text-[54px] text-[#FF1212]" />
      </div>
      <div className="text-center">
        <h3 className="text-base font-semibold">Are you sure?</h3>
        <p className="text-sm text-[#939CA7] mt-3">
          Do you really want to delete the zone?
          <br />
          This process cannot be undone.
        </p>
      </div>

      <div className="flex items-center gap-[10px]">
        <SecondaryBtn
          onClick={toggleModal}
          disabled={isLoading}
          className={
            "justify-center !bg-[#AAAAAA] !border-none !text-white min-w-20"
          }
        >
          CANCEL
        </SecondaryBtn>
        <SecondaryBtn
          onClick={handleDelete}
          disabled={isLoading}
          className={
            "justify-center !bg-[#FF1212] !border-none !text-white min-w-20"
          }
        >
          {isLoading ? "DELETING..." : "DELETE"}
        </SecondaryBtn>
      </div>
    </CenterModal>
  );
}

export default DeleteZonePopup;
