import { WarningSvg } from "../../assets/svg";
import { SecondaryBtn } from "../../components";
import { CenterModal } from "../../components/Models";
import { useDeleteWidget } from "../../api/queryHooks";
import toaster from "../../utils/toaster";

function DeleteWidgetPopup({ toggleModal, widgetId }) {
  const { mutate: deleteWidget, isLoading } = useDeleteWidget({
    onSuccess: () => {
      toaster.success("Widget deleted successfully");
      toggleModal();
    },
    onError: (error) => {
      toaster.error(error?.response?.data?.message || "Failed to delete widget");
    },
  });

  const handleDelete = () => {
    deleteWidget(widgetId);
  };

  return (
    <CenterModal
      toggleModal={toggleModal}
      className="max-w-[460px] w-full p-8 flex flex-col items-center gap-6"
    >
      <div>
        <WarningSvg className="text-[54px] text-[#FF1212]" />
      </div>
      <div className="text-center">
        <h3 className="text-base font-semibold">Are you sure?</h3>
        <p className="text-sm text-[#939CA7] mt-3">
          Do you really want to delete this widget?
          <br />
          This process cannot be undone.
        </p>
      </div>

      <div className="flex items-center gap-[10px]">
        <SecondaryBtn
          onClick={toggleModal}
          disabled={isLoading}
          className={
            "justify-center !bg-[#AAAAAA] !border-none !text-white min-w-20"
          }
        >
          CANCEL
        </SecondaryBtn>
        <SecondaryBtn
          onClick={handleDelete}
          disabled={isLoading}
          className={
            "justify-center !bg-[#FF1212] !border-none !text-white min-w-20"
          }
        >
          {isLoading ? "DELETING..." : "DELETE"}
        </SecondaryBtn>
      </div>
    </CenterModal>
  );
}

export default DeleteWidgetPopup;