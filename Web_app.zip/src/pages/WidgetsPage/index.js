import { useState } from "react";
import { useGetCreatedWidgets } from "../../api/queryHooks";
import { AddSvg, DeleteSvg, EditSvg } from "../../assets/svg";
import { SecondaryBtnLink } from "../../components";
import { ROUTES } from "../../router";
import { useNavigate } from "react-router-dom";
import { LandscapeLayout, PortraitLayout } from "../CreateWidget/WidgetVisualizer";
import DeleteWidgetPopup from "./DeleteWidgetPopup";

const DeleteWidget = ({ widgetId }) => {
  const [open, setOpen] = useState(false);

  const toggleModal = () => {
    setOpen(!open);
  };

  return (
    <>
      <button
        onClick={toggleModal}
        className="w-7 h-7 flex items-center justify-center rounded-md bg-[#FF1212] text-white fill-white"
      >
        <DeleteSvg />
      </button>
      {open ? (
        <DeleteWidgetPopup toggleModal={toggleModal} widgetId={widgetId} />
      ) : null}
    </>
  );
};

const LandscapeView = ({ widgets, handleEditWidget }) => {
  return (
    <div className="mb-[20px]">
      <h3 className="text-base font-semibold text-[#222222] pb-[15px]">
        Landscape <span className="text-[#939CA7]">(16:9)</span>
      </h3>
      <div className="flex items-center gap-3 flex-wrap">
        {widgets.map((widget) => (
          <div className="flex-shrink-0 relative group w-[274px] h-[156px] overflow-hidden">
            <div className="scale-[0.4] origin-top-left">
              <LandscapeLayout
                key={widget._id}
                selectedWidgets={widget?.structure}
              />
            </div>
            <div className="absolute left-0 top-0 w-full h-full flex justify-center items-center group-hover:opacity-100 opacity-0 transition-opacity duration-200">
              <div className="flex items-center gap-[10px]">
                <button
                  onClick={() => handleEditWidget(widget._id)}
                  className="w-7 h-7 flex items-center justify-center rounded-md bg-[#227EEB] text-white fill-white"
                >
                  <EditSvg />
                </button>
                <DeleteWidget widgetId={widget._id} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const PortraitView = ({ widgets, handleEditWidget }) => {
  return (
    <div className="mb-[20px]">
      <h3 className="text-base font-semibold text-[#222222] pb-[15px]">
        Portrait <span className="text-[#939CA7]">(9:16)</span>
      </h3>
      <div className="flex items-center gap-3 flex-wrap">
        {widgets.map((widget) => (
          <div className="relative group flex-shrink-0 h-[272px] w-[152px] overflow-hidden">
            <div className="scale-[0.4] origin-top-left">
              <PortraitLayout
                key={widget._id}
                selectedWidgets={widget?.structure}
              />
            </div>
            <div className="absolute left-0 top-0 w-full h-full flex justify-center items-center group-hover:opacity-100 opacity-0 transition-opacity duration-200">
              <div className="flex items-center gap-[10px]">
                <button
                  onClick={() => handleEditWidget(widget._id)}
                  className="w-7 h-7 flex items-center justify-center rounded-md bg-[#227EEB] text-white fill-white"
                >
                  <EditSvg />
                </button>
                <DeleteWidget widgetId={widget._id} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const Widgets = () => {
  const navigate = useNavigate();
  const { data: createdWidgets, isLoading: isWidgetsLoading } =
    useGetCreatedWidgets();

  const widgets = createdWidgets?.data || [];

  const handleEditWidget = (widgetId) => {
    navigate(ROUTES.GET_UTILITIES_WIDGETS_EDIT(widgetId));
  };

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
          <h2 className="text-[#222222] font-bold">Widgets</h2>
          <div>
            <SecondaryBtnLink
              to={ROUTES.UTILITIES_WIDGETS_CREATE}
              className={"w-[135px] justify-center"}
              Icon={AddSvg}
            >
              NEW WIDGET
            </SecondaryBtnLink>
          </div>
        </div>

        {isWidgetsLoading ? (
          <div>Loading widgets...</div>
        ) : widgets?.length ? (
          <>
            <LandscapeView
              widgets={widgets || []}
              handleEditWidget={handleEditWidget}
            />
            <PortraitView
              widgets={widgets || []}
              handleEditWidget={handleEditWidget}
            />
          </>
        ) : (
          <div className="text-xs">No widgets created yet.</div>
        )}
      </div>
    </div>
  );
};

export default Widgets;
