import { useParams } from "react-router-dom";
import { useGetRolesCategories, useGetRoleById } from "../../api/queryHooks";
import { PermissionDenied, SpinnerV1 } from "../../components";
import AccountManagementViewRoleForm from "./AccountManagementViewRoleForm";
import useUserStore from "../../store/useUserStore";

function AccountManagementViewRole() {
  const userPermissions = useUserStore((state) => state.permissions);

  const { roleId } = useParams();
  const { data: categoriesData, isLoading: categoriesLoading } =
    useGetRolesCategories();
  const { data: roleData, isLoading: roleLoading } = useGetRoleById(roleId);

  const isLoading = categoriesLoading || roleLoading;

  if (!userPermissions?.USER_MANAGEMENT?.role_management?.readOnly)
    return <PermissionDenied />;

  if (isLoading)
    return (
      <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow flex items-center justify-center">
        <SpinnerV1 />
      </div>
    );

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <AccountManagementViewRoleForm
        ROLE_PERMISSIONS={categoriesData?.data || {}}
        ROLE_DATA={roleData?.data?.role || {}}
      />
    </div>
  );
}

export default AccountManagementViewRole;
