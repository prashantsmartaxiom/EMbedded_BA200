import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ROUTES } from "../../router";
import { BackspaceSvg } from "../../assets/svg";
import { Checkbox, PrimaryInput } from "../../components";
import { mapRoleDataToPermissions } from "../../utils/helpers";

function AccountManagementViewRoleForm({ ROLE_PERMISSIONS, ROLE_DATA }) {
  const [formData, setFormData] = useState({
    roleName: "",
    permissions: {},
  });

  const [activeTab, setActiveTab] = useState("CAMPUS_MANAGEMENT");

  // Effect to update form data when role data changes
  useEffect(() => {
    if (ROLE_DATA && ROLE_PERMISSIONS) {
      const mappedPermissions = mapRoleDataToPermissions(
        ROLE_DATA.permissions,
        ROLE_PERMISSIONS
      );

      setFormData({
        roleName: ROLE_DATA.roleName || "",
        permissions: mappedPermissions,
      });

      // Set the first available tab as active
      const firstTab = Object.keys(mappedPermissions)[0];
      if (firstTab) {
        setActiveTab(firstTab);
      }
    }
  }, [ROLE_DATA, ROLE_PERMISSIONS]);

  return (
    <div>
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mb-5">
        <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
          <Link
            to={ROUTES.MANAGE_ROLES}
            className="flex items-center gap-[10px]"
          >
            <BackspaceSvg />
            <h2 className="text-[#222222] font-bold">View Role Details</h2>
          </Link>
          <div className="flex items-center gap-[15px]">
            <div className="text-sm text-[#666666]">
              Status:{" "}
              <span
                className={`font-medium ${
                  ROLE_DATA.isActive ? "text-green-600" : "text-red-600"
                }`}
              >
                {ROLE_DATA.isActive ? "Active" : "Inactive"}
              </span>
            </div>
          </div>
        </div>

        <div className="">
          <div className="flex items-center gap-4">
            <label className="text-xs font-medium text-[#222222] w-20">
              Role Name:
            </label>
            <PrimaryInput className="w-[300px]" disabled value={formData.roleName} />
            <div className="flex items-center gap-2 ml-8">
              <span className="text-xs text-[#666666]">
                Created: {new Date(ROLE_DATA.createdAt).toLocaleDateString()}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5 mb-5">
        <div className="mb-6">
          <div className="flex border-b border-[#E5E7EB]">
            {Object.entries(formData.permissions).map(([key, module]) => (
              <button
                key={key}
                type="button"
                onClick={() => setActiveTab(key)}
                className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === key
                    ? "border-[#227EEB] text-[#227EEB]"
                    : "border-transparent text-[#6B7280] hover:text-[#222222]"
                }`}
              >
                {module.label}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg border border-[#CCCCCC] overflow-hidden">
          <table className="w-full text-xs">
            {/* Table Header */}
            {formData.permissions[activeTab]?.permissions?.categories?.length >
              0 && (
              <thead>
                <tr className="bg-[#EEEEEE]">
                  <th className="text-left px-4 py-3 font-medium text-[#222222] text-xs">
                    {formData.permissions[activeTab]?.label}
                  </th>
                  {formData.permissions[
                    activeTab
                  ]?.permissions?.categories[0]?.accesses?.map((access) => (
                    <th
                      key={access.value}
                      className="text-center px-4 py-3 font-medium text-[#222222] text-xs"
                    >
                      {access.label}
                    </th>
                  ))}
                </tr>
              </thead>
            )}

            {/* Table Body */}
            <tbody>
              {formData.permissions[activeTab]?.permissions?.categories?.map(
                (category, categoryIndex) => (
                  <tr key={categoryIndex} className="border-t border-[#F3F4F6]">
                    <td className="px-4 py-3 text-[#222222] text-xs">
                      {category.name}
                    </td>
                    {category.accesses?.map((access, accessIndex) => (
                      <td key={access.value} className="px-4 py-3">
                        <div className="flex justify-center">
                          <Checkbox
                            id={`${activeTab}-${categoryIndex}-${access.value}`}
                            checked={access.checked}
                            disabled={true}
                          />
                        </div>
                      </td>
                    ))}
                  </tr>
                )
              )}
            </tbody>
          </table>
        </div>

        {/* Role Details Summary */}
        <div className="mt-6 bg-[#F9F9F9] rounded-lg p-4">
          <h4 className="text-sm font-medium text-[#222222] mb-3">
            Role Information
          </h4>
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-[#666666]">Role ID:</span>
              <span className="ml-2 text-[#222222]">{ROLE_DATA._id}</span>
            </div>
            <div>
              <span className="text-[#666666]">Last Updated:</span>
              <span className="ml-2 text-[#222222]">
                {new Date(ROLE_DATA.updatedAt).toLocaleDateString()}
              </span>
            </div>
            <div>
              <span className="text-[#666666]">Status:</span>
              <span
                className={`ml-2 font-medium ${
                  ROLE_DATA.isActive ? "text-green-600" : "text-red-600"
                }`}
              >
                {ROLE_DATA.isActive ? "Active" : "Inactive"}
              </span>
            </div>
            <div>
              <span className="text-[#666666]">Deletable:</span>
              <span
                className={`ml-2 font-medium ${
                  !ROLE_DATA.isDelete ? "text-green-600" : "text-red-600"
                }`}
              >
                {!ROLE_DATA.isDelete ? "Protected" : "Deletable"}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AccountManagementViewRoleForm;
