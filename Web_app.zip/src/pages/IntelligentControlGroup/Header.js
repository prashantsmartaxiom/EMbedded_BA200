import { SearchInput } from "../../components";
import useUserStore from "../../store/useUserStore";
import AddNewGroupModal from "./AddNewGroupModal";

function Header({ onSearchChange }) {
  const userPermissions = useUserStore((state) => state.permissions);

  return (
    <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
      <h2 className="text-[#222222] font-bold">Intelligent Controls</h2>
      <div className="flex items-center gap-[15px]">
        <SearchInput
          className="w-[260px]"
          placeholder="Search by group name, device…"
          onChange={(e) => onSearchChange(e.target.value)}
        />
        {userPermissions?.INTELLIGENT_CONTROL?.group_management?.addModify ? (
          <AddNewGroupModal />
        ) : null}
      </div>
    </div>
  );
}

export default Header;
