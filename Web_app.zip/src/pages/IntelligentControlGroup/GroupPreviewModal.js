import { useGetGroupById } from "../../api/queryHooks";
import { CenterModal, CenterModalHeader } from "../../components";
import { ElementView } from "../ControlSystem/Views/TemplateView";

function get_elements_from_group(groupData) {
  const elements = [];
  groupData?.devices?.forEach((device) => {
    device?.group_channels?.forEach((channel) => {
      elements.push({
        deviceId: device.device_id,
        channelId: channel.id,
        ...channel,
        deviceType: device?.device_type,
      });
    });
  });

  return elements;
}

const GroupView = ({ groupData }) => {
  const template_data = {
    success: true,
    message: "Template fetched successfully",
    data: {
      _id: groupData?.group?.id,
      name: "",
      layout: "landscape",
      status: "Active",
      rows: 1,
      columns: 1,
      layoutStructure: {
        rows: [
          {
            columns: [
              {
                id: groupData?.group?.id,
                group_name: groupData?.group?.name,
                type: "group",
                elements: get_elements_from_group(groupData),
                fake_elements: [],
              },
            ],
          },
        ],
      },
      createdAt: "2025-10-01T09:38:02.851Z",
      updatedAt: "2025-10-01T09:38:02.851Z",
      __v: 0,
      id: "68dcf67a1b1d422ad45f3379",
    },
  };

  return <ElementView data={template_data} />;
};

function GroupPreviewModal({ isOpen, toggleModal, group_id }) {
  const { data, isLoading } = useGetGroupById(group_id);
  const groupData = data?.data;
  if (!isOpen || !groupData?.group?.id) return null;
  if (isLoading) return null;

  return (
    <CenterModal
      toggleModal={toggleModal}
      className="max-w-6xl w-full h-[98vh]"
    >
      <CenterModalHeader
        className="p-5 flex items-center justify-between pb-5 border-b border-[#CCCCCC]"
        title={`Group - ${groupData?.group?.name}`}
        toggleModal={toggleModal}
      />

      <div className="max-h-[calc(100vh-80px)] overflow-auto flex items-center justify-center">
        <div className="w-[800px] h-[800px]">
          <GroupView groupData={groupData} />
        </div>
      </div>
    </CenterModal>
  );
}

export default GroupPreviewModal;
