import { useState, useEffect, useMemo } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  BottomRightModal,
  BottomRightModalHeader,
  Checkbox,
  MultiSelectDropdown,
  PrimaryBtn2,
  PrimaryInput,
  SpinnerV1,
} from "../../components";
import {
  useGetActiveDevicesOptionsForGroup,
  useGetDeviceChannelsForGroup,
  useGetGroupById,
  useUpdateGroup,
} from "../../api/queryHooks";
import toaster from "../../utils/toaster";
import { CircleInfoSvg } from "../../assets/svg";

const validationSchema = Yup.object({
  name: Yup.string().required("Group name is required"),
  devices: Yup.array()
    .min(1, "At least one device must be selected")
    .required("Devices are required"),
});

function ListingCheckbox({
  data,
  label,
  deviceId,
  selectedChannels,
  onChannelChange,
}) {
  if (!data?.length) return null;

  return (
    <div className="flex text-xs items-start mb-[15px] pb-[15px] last:mb-0 border-b border-[#dddddd] last:border-0">
      <div className="min-w-[50px] text-[#7A838E]">{label}</div>
      <div className="grid grid-cols-2 gap-y-3 gap-x-2">
        {data.map((item) => {
          const channelKey = `${deviceId}_${item.channelId || item.id}`;
          const isChecked = selectedChannels[channelKey]?.selected || false;

          return (
            <div
              title={item.name}
              key={item.channelId || item.id}
              className="flex items-center gap-2"
            >
              <Checkbox
                id={channelKey}
                checked={isChecked}
                onCheckedChange={(checked) =>
                  onChannelChange(deviceId, item, checked)
                }
              />
              <label htmlFor={channelKey} className="truncate text-[#222222]">
                {item.name}
              </label>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function EditGroupForm({ groupId, onClose }) {
  const { data: activeDevicesOptions, isLoading: isLoadingActiveDevices } =
    useGetActiveDevicesOptionsForGroup({});

  const { data: groupData, isLoading: isLoadingGroup } =
    useGetGroupById(groupId);

  const [selectedChannels, setSelectedChannels] = useState({});

  const updateGroupMutation = useUpdateGroup({
    onSuccess: (data) => {
      toaster.success("Group updated successfully!");
      onClose();
    },
    onError: (error) => {
      console.error("Error updating group:", error);
      toaster.error(error?.response?.data?.message || "Failed to update group. Please try again.");
    },
  });

  // Calculate initial values from group data
  const initialValues = useMemo(() => {
    if (groupData?.data) {
      const group = groupData.data.group;
      const devices = groupData.data.devices;
      const deviceIds = devices.map((device) => device.device_id);

      return {
        name: group.name || "",
        devices: deviceIds,
      };
    }
    return {
      name: "",
      devices: [],
    };
  }, [groupData]);

  const formik = useFormik({
    initialValues,
    validationSchema,
    enableReinitialize: true,
    onSubmit: (values) => {
      // Transform selected channels into the required format
      const devices = [];
      const deviceChannelsMap = {};

      // Group channels by device
      Object.entries(selectedChannels).forEach(([channelKey, channelData]) => {
        if (channelData && channelData.selected) {
          const deviceId = channelData.deviceId;
          if (!deviceChannelsMap[deviceId]) {
            deviceChannelsMap[deviceId] = [];
          }
          deviceChannelsMap[deviceId].push({
            channelId: channelData.channel.channelId || channelData.channel.id,
            channelType: channelData.channel.type,
          });
        }
      });

      // Convert to required format
      Object.entries(deviceChannelsMap).forEach(([deviceId, channels]) => {
        devices.push({
          deviceId,
          channels,
        });
      });

      const payload = {
        name: values.name,
        devices,
      };

      updateGroupMutation.mutate({ groupId, groupData: payload });
    },
  });

  // Get device channels when devices are selected
  const selectedDeviceIds = formik.values.devices;
  const { data: channelsData, isLoading: isLoadingChannels } =
    useGetDeviceChannelsForGroup(selectedDeviceIds);

  // Initialize selected channels when group data is available
  useEffect(() => {
    if (groupData?.data) {
      const devices = groupData.data.devices;

      // Initialize selected channels from group data
      const initialSelectedChannels = {};
      devices.forEach((device) => {
        device.group_channels?.forEach((channel) => {
          const channelKey = `${device.device_id}_${channel.id}`;
          initialSelectedChannels[channelKey] = {
            selected: true,
            deviceId: device.device_id,
            channel: {
              channelId: channel.id,
              id: channel.id,
              name: channel.name,
              type: channel.type,
            },
          };
        });
      });

      setSelectedChannels(initialSelectedChannels);
    }
  }, [groupData]);

  // Handle channel selection
  const handleChannelChange = (deviceId, channel, isSelected) => {
    const channelKey = `${deviceId}_${channel.channelId || channel.id}`;
    setSelectedChannels((prev) => {
      const newChannels = { ...prev };

      if (isSelected) {
        newChannels[channelKey] = {
          selected: true,
          deviceId,
          channel: {
            channelId: channel.channelId || channel.id,
            id: channel.id,
            name: channel.name,
            type: channel.type,
          },
        };
      } else {
        delete newChannels[channelKey];
      }

      return newChannels;
    });
  };

  // Handle device selection change
  const handleDevicesChange = (devices) => {
    formik.setFieldValue("devices", devices);
    // Clear selected channels for devices that are no longer selected
    const newSelectedChannels = {};
    Object.entries(selectedChannels).forEach(([channelKey, channelData]) => {
      if (
        channelData &&
        channelData.selected &&
        devices.includes(channelData.deviceId)
      ) {
        newSelectedChannels[channelKey] = channelData;
      }
    });
    setSelectedChannels(newSelectedChannels);
  };

  // Check if form can be submitted
  const canSubmit = () => {
    const hasSelectedChannels = Object.values(selectedChannels).some(
      (channel) => channel?.selected
    );
    return (
      formik.values.name.trim() &&
      formik.values.devices.length > 0 &&
      hasSelectedChannels &&
      formik.isValid
    );
  };

  if (isLoadingGroup) {
    return (
      <div className="flex-grow flex justify-center items-center">
        <SpinnerV1 />
      </div>
    );
  }

  if (!groupData?.data) {
    return (
      <div className="flex-grow flex justify-center items-center">
        <div className="text-[#7A838E]">Group not found</div>
      </div>
    );
  }

  return (
    <form
      className="flex-grow flex flex-col min-h-0"
      onSubmit={formik.handleSubmit}
    >
      <div className="flex items-center justify-between px-5 mb-5">
        <label htmlFor="name" className="text-[#222222] text-[12px]">
          Group Name:
        </label>
        <div className="w-[300px]">
          <PrimaryInput
            className="w-full"
            placeholder="Enter Group name"
            name="name"
            value={formik.values.name}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {formik.touched.name && formik.errors.name && (
            <span className="text-red-500 text-xs mt-1">
              {formik.errors.name}
            </span>
          )}
        </div>
      </div>

      <div className="px-5 pb-5 mb-5 border-b border-[#DDDDDD]">
        <div className="flex items-center justify-between w-full">
          <label htmlFor="devices" className="text-[#222222] text-[12px]">
            Devices:
          </label>
          <div className="w-[300px]">
            <MultiSelectDropdown
              options={activeDevicesOptions}
              placeholder={
                isLoadingActiveDevices
                  ? "Loading devices..."
                  : "Select devices..."
              }
              value={formik.values.devices}
              onValueChange={handleDevicesChange}
              onBlur={() => formik.setFieldTouched("devices", true)}
              className="w-full"
            />
            {formik.touched.devices && formik.errors.devices && (
              <span className="text-red-500 text-xs mt-1">
                {formik.errors.devices}
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="px-5 overflow-auto flex-grow">
        {formik.values.devices?.length ? (
          <>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-[#222222] text-xs font-semibold">
                Select Channels
              </h3>
              <div className="text-[#F29F1A] text-[10px]">
                <CircleInfoSvg className="inline-block w-4 h-4 mr-1" />
                <span>Active channels available</span>
              </div>
            </div>
            {isLoadingChannels ? (
              <div className="py-5 text-[#222222] text-xs">
                Loading channels...
              </div>
            ) : channelsData?.length ? (
              channelsData?.map((deviceChannels) => (
                <>
                <div className="grid grid-cols-2 gap-x-2 gap-y-[10px]">
                  <h3 className="text-[#7A838E] text-xs truncate" title={deviceChannels?.location?.campus?.name || "N/A"}>Campus: {deviceChannels?.location?.campus?.name || "N/A"}</h3>
                  <h3 className="text-[#7A838E] text-xs truncate" title={deviceChannels?.location?.building?.name || "N/A"}>Building: {deviceChannels?.location?.building?.name || "N/A"}</h3>
                  <h3 className="text-[#7A838E] text-xs truncate" title={deviceChannels?.location?.floor?.name || "N/A"}>Floor: {deviceChannels?.location?.floor?.name || "N/A"}</h3>
                  <h3 className="text-[#7A838E] text-xs truncate" title={deviceChannels?.location?.zone?.name || "N/A"}>Zone: {deviceChannels?.location?.zone?.name || "N/A"}</h3>
                </div>
                <div
                  key={deviceChannels.device_id}
                  className="flex items-start justify-between my-[15px] border-b last:border-0 border-[#dddddd]"
                >
                  <div className="text-[#222222] text-xs">
                    {deviceChannels.device_id}
                  </div>
                  <div className="w-[300px]">
                    <ListingCheckbox
                      data={deviceChannels.channels.filter(
                        (device) => device?.type === "led"
                      )}
                      label="LED"
                      deviceId={deviceChannels.device_id}
                      selectedChannels={selectedChannels}
                      onChannelChange={handleChannelChange}
                    />
                    <ListingCheckbox
                      data={deviceChannels.channels.filter(
                        (device) => device?.type === "shade"
                      )}
                      label="Shade"
                      deviceId={deviceChannels.device_id}
                      selectedChannels={selectedChannels}
                      onChannelChange={handleChannelChange}
                    />
                    <ListingCheckbox
                      data={deviceChannels.channels.filter(
                        (device) => device?.type === "sensor"
                      )}
                      label="Sensor"
                      deviceId={deviceChannels.device_id}
                      selectedChannels={selectedChannels}
                      onChannelChange={handleChannelChange}
                    />
                  </div>
                </div>
                </>
              ))
            ) : (
              <div className="py-5 text-[#222222] text-xs">
                No Channels Found
              </div>
            )}
          </>
        ) : null}
      </div>

      <div className="p-5 flex justify-end border-t border-[#DDDDDD]">
        <PrimaryBtn2
          type="submit"
          className="min-w-20 justify-center"
          disabled={updateGroupMutation.isLoading || !canSubmit()}
        >
          {updateGroupMutation.isLoading ? "UPDATING..." : "UPDATE"}
        </PrimaryBtn2>
      </div>
    </form>
  );
}

function EditGroupModal({ isOpen, groupId, onClose }) {
  return (
    <>
      {isOpen && groupId ? (
        <BottomRightModal
          toggleModal={onClose}
          className="max-h-[calc(100vh-56px)] h-full w-full max-w-[500px] flex flex-col"
        >
          <BottomRightModalHeader toggleModal={onClose} title="Edit Group" />
          <EditGroupForm groupId={groupId} onClose={onClose} />
        </BottomRightModal>
      ) : null}
    </>
  );
}

export default EditGroupModal;
