import { useState } from "react";
import {
  useGetGroups,
  useGetActiveDevicesOptionsForGroup,
} from "../../api/queryHooks";
import { DataTable, PermissionDenied, PrimaryDropdown } from "../../components";
import { DeleteSvg, EditSvg, EyeSvg } from "../../assets/svg";
import Seperator from "../../components/Header/Seperator";
import Header from "./Header";
import DeleteGroupPopup from "./DeleteGroupPopup";
import EditGroupModal from "./EditGroupModal";
import useUserStore from "../../store/useUserStore";
import GroupPreviewModal from "./GroupPreviewModal";

const SubHeader = ({
  limit,
  onLimitChange,
  selectedDevice,
  onDeviceChange,
  devicesOptions,
  isLoadingDevices,
}) => {
  return (
    <div className="flex items-center justify-between mb-[15px]">
      <h2 className="text-[#222222] text-[14px] font-semibold">Manage Group</h2>
      <div className="flex items-center gap-[5px]">
        <div className="flex items-center gap-[20px]">
          <div className="flex items-center gap-[10px]">
            <span className="text-[#222222] text-[12px]">Show:</span>
            <PrimaryDropdown
              className="w-[60px]"
              value={limit}
              onValueChange={onLimitChange}
              options={[
                { value: "10", label: "10" },
                { value: "20", label: "20" },
                { value: "25", label: "25" },
                { value: "50", label: "50" },
              ]}
            />
            <span className="text-[12px] text-[#7A838E]">Entries</span>
          </div>
          <Seperator className="h-[25px]" />
          <div className="flex items-center gap-[10px]">
            <span className="text-[#222222] text-[12px]">Filter:</span>
            <PrimaryDropdown
              className="w-[200px]"
              options={[
                { value: null, label: "All Devices" },
                ...(devicesOptions?.map((item) => ({
                  ...item,
                  label: item.value,
                })) || []),
              ]}
              value={selectedDevice}
              onValueChange={onDeviceChange}
              placeholder={
                isLoadingDevices ? "Loading devices..." : "Device ID"
              }
              disabled={isLoadingDevices}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

function IntelligentControlGroup() {
  const [previewModal, setPreviewModal] = useState({
    isOpen: false,
    group: null,
  });
  const userPermissions = useUserStore((state) => state.permissions);

  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState("10");
  const [search, setSearch] = useState("");
  const [selectedDevice, setSelectedDevice] = useState("");
  const [deleteModal, setDeleteModal] = useState({
    isOpen: false,
    groupId: null,
  });
  const [editModal, setEditModal] = useState({ isOpen: false, groupId: null });

  const { data: devicesData, isLoading: isLoadingDevices } =
    useGetActiveDevicesOptionsForGroup({});

  const { data: groupsData, isLoading } = useGetGroups({
    page,
    limit: Number(limit),
    search,
    device_id: selectedDevice || undefined,
  });

  const handleDeviceChange = (deviceId) => {
    setSelectedDevice(deviceId);
    setPage(1); // Reset to first page when filter changes
  };

  const handleDeleteClick = (groupId) => {
    setDeleteModal({ isOpen: true, groupId });
  };

  const handleDeleteModalClose = () => {
    setDeleteModal({ isOpen: false, groupId: null });
  };

  const handleEditClick = (groupId) => {
    setEditModal({ isOpen: true, groupId });
  };

  const handleEditModalClose = () => {
    setEditModal({ isOpen: false, groupId: null });
  };

  const handleDeleteSuccess = () => {
    // refetch();
  };

  const handlePreview = (group) => {
    setPreviewModal({
      isOpen: true,
      group: group,
    });
  };

  const togglePreviewModal = (value) => {
    setPreviewModal({
      isOpen: value,
      group: value ? previewModal.group : null,
    });
  };

  const columns = [
    { key: "sno", label: "S. No." },
    { key: "groupName", label: "Group Name" },
    { key: "deviceId", label: "Device ID" },
    { key: "channels", label: "Channels List" },
    {
      key: "action",
      label: "Action",
      render: (_, row) => (
        <div className="flex gap-6">
          {userPermissions?.INTELLIGENT_CONTROL?.template_management
            ?.readOnly ? (
            <button
              className="text-[#222222] fill-[#222222] hover:underline flex items-center"
              onClick={() => handlePreview(row.id)}
            >
              <EyeSvg className="inline mr-1" />
              Preview
            </button>
          ) : null}
          {userPermissions?.INTELLIGENT_CONTROL?.group_management?.addModify ? (
            <button
              className="text-[#222222] fill-[#222222] hover:underline flex items-center"
              onClick={() => handleEditClick(row.id)}
            >
              <EditSvg className="inline mr-1 mt-px" />
              Edit
            </button>
          ) : null}
          {userPermissions?.INTELLIGENT_CONTROL?.group_management?.delete ? (
            <button
              className="text-red-500 fill-red-500 hover:underline flex items-center"
              onClick={() => handleDeleteClick(row.id)}
            >
              <DeleteSvg className="inline mr-1 mt-px" />
              Delete
            </button>
          ) : null}
        </div>
      ),
    },
  ];

  const formattedData =
    groupsData?.data?.data?.map((item, index) => ({
      id: item.id,
      sno: String((page - 1) * Number(limit) + index + 1).padStart(2, "0"),
      groupName: item.group_name,
      deviceId: item.device_ids.join(", "),
      channels: item.channelList.join(", "),
    })) || [];

  if (!userPermissions?.INTELLIGENT_CONTROL?.group_management?.readOnly)
    return <PermissionDenied />;

  return (
    <div className="h-[calc(100vh-55px)] pt-[15px] ml-[15px] pr-[15px] overflow-auto flex-grow">
      <div className="shadow-[0px_1px_6px_#2222221A] rounded-xl bg-[#ffffff] p-5">
        <Header
          onSearchChange={(value) => {
            setSearch(value);
            setPage(1);
          }}
        />
        <SubHeader
          limit={limit}
          onLimitChange={setLimit}
          selectedDevice={selectedDevice}
          onDeviceChange={handleDeviceChange}
          devicesOptions={devicesData || []}
          isLoadingDevices={isLoadingDevices}
        />
        <DataTable
          columns={columns}
          data={formattedData}
          totalItems={groupsData?.data?.total || 0}
          currentPage={page}
          onPageChange={setPage}
          isLoading={isLoading}
          rowsPerPage={Number(limit)}
        />
      </div>

      <GroupPreviewModal
        isOpen={previewModal.isOpen}
        toggleModal={togglePreviewModal}
        group_id={previewModal.group}
      />

      <DeleteGroupPopup
        isOpen={deleteModal.isOpen}
        toggleModal={handleDeleteModalClose}
        groupId={deleteModal.groupId}
        onSuccess={handleDeleteSuccess}
      />

      <EditGroupModal
        isOpen={editModal.isOpen}
        groupId={editModal.groupId}
        onClose={handleEditModalClose}
      />
    </div>
  );
}

export default IntelligentControlGroup;
