import { useFormik } from "formik";
import * as Yup from "yup";
import { BackspaceSvg } from "../../assets/svg";
import {
  PrimaryBtn2,
  PrimaryDropdown,
  PrimaryFileInput,
  PrimaryInput,
  PrimaryTextarea,
  SecondaryBtn,
  SpinnerV1,
} from "../../components";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ROUTES } from "../../router";
import {
  useGetCampusById,
  useGetCampusTypes,
  useUpdateCampus,
} from "../../api/queryHooks";
import { useEffect } from "react";
import toaster from "../../utils/toaster";
import {
  MAX_FILE_SIZE_TO_UPLOAD_IMAGE,
  VALID_IMAGE_FILE_TYPES,
} from "../../consts";

const MAX_FILE_SIZE = MAX_FILE_SIZE_TO_UPLOAD_IMAGE; // 2MB
const VALID_FILE_TYPES = VALID_IMAGE_FILE_TYPES;

const validationSchema = Yup.object().shape({
  campusName: Yup.string().required("Campus name is required"),
  campusType: Yup.string().required("Campus type is required"),
  location: Yup.string().required("Location is required"),
  description: Yup.string().optional(),
  campusImage: Yup.mixed()
    .nullable()
    .test("fileSize", "File too large (max 2MB)", (value) => {
      if (!value) return true;
      return value.size <= MAX_FILE_SIZE;
    })
    .test("fileType", "Unsupported file type (only JPG, PNG)", (value) => {
      if (!value) return true;
      return VALID_FILE_TYPES.includes(value.type);
    }),
});

function EditCampusForm() {
  const { campusId } = useParams();
  const navigate = useNavigate();

  // Fetch campus data and campus types from API
  const {
    data,
    isLoading: campusLoading,
    isError: campusError,
  } = useGetCampusById(campusId);
  const { data: campusTypesData, isLoading: campusTypesLoading } =
    useGetCampusTypes();

  const campusData = data?.data?.campus;

  const updateCampusMutation = useUpdateCampus({
    onSuccess: (data) => {
      navigate(-1);
      toaster.success("Campus updated successfully!");

      // Optionally navigate back or update UI
    },
    onError: (error) => {
      toaster.error(
        error?.response?.data?.message ||
          `Error updating campus: ${error.message}`
      );
      console.error("Error updating campus:", error);
    },
  });

  const formik = useFormik({
    initialValues: {
      campusName: "",
      campusType: "",
      location: "",
      description: "",
      campusImage: null,
    },
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      // Convert campusImage to base64 if a new image is selected
      let base64Image = null;
      if (values.campusImage) {
        try {
          const reader = new FileReader();
          reader.readAsDataURL(values.campusImage);
          await new Promise((resolve) => {
            reader.onloadend = () => {
              base64Image = reader.result;
              resolve();
            };
          });
        } catch (error) {
          console.error("Error converting image to base64:", error);
          toaster.error("Failed to process campus image.");
          return;
        }
      }

      const payload = {
        name: values.campusName,
        description: values.description,
        location: values.location,
        ...(base64Image && { campusImage: base64Image }),
        type: values.campusType,
      };

      updateCampusMutation.mutate({ campusId, campusData: payload });
    },
  });

  // Update form values when campus data is loaded
  useEffect(() => {
    if (campusData) {
      const campus = campusData;
      formik.setValues({
        campusName: campus.name || "",
        campusType: campus.type || "",
        location: campus.location || "",
        description: campus.description || "",
        campusImage: null, // Don't set existing image as file, we'll show it via imageUrl prop
      });
    }
  }, [campusData]);

  if (campusLoading)
    return (
      <div className="p-5">
        <SpinnerV1 />
      </div>
    );

  if (campusError) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-red-500">Error loading campus data</div>
      </div>
    );
  }

  return (
    <form onSubmit={formik.handleSubmit}>
      <div className="flex items-center justify-between border-b border-[#CCCCCC] pb-[15px] mb-[15px]">
        <Link
          to={ROUTES.CAMPUS_MANAGEMENT}
          className="flex items-center gap-[10px]"
        >
          <BackspaceSvg />
          <h2 className="text-[#222222] font-bold">Edit Campus</h2>
        </Link>
        <div className="flex items-center gap-[15px]">
          <SecondaryBtn
            className={"w-[80px] justify-center"}
            onClick={() => {
              if (campusData) {
                const campus = campusData;
                formik.setValues({
                  campusName: campus.name || "",
                  campusType: campus.type || "",
                  location: campus.location || "",
                  description: campus.description || "",
                  campusImage: null, // Reset image selection
                });
              }
            }}
            type="button"
          >
            RESET
          </SecondaryBtn>
          <PrimaryBtn2
            type="submit"
            disabled={formik.isSubmitting || updateCampusMutation.isLoading}
            className={"w-[80px] justify-center"}
          >
            {formik.isSubmitting || updateCampusMutation.isLoading
              ? "UPDATING..."
              : "UPDATE"}
          </PrimaryBtn2>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-x-10 gap-y-3 pb-5 mb-5 border-b">
        <div className="row-start-1 col-start-1">
          <div className="flex justify-between items-start gap-[40px]">
            <h4 className="w-[90px] text-xs text-[#222222] flex-shrink-0 mt-2">
              Campus Name:
            </h4>
            <PrimaryInput
              placeholder="Campus name"
              className="w-full"
              name="campusName"
              value={formik.values.campusName}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
          </div>
          {formik.touched.campusName && formik.errors.campusName ? (
            <div className="text-red-500 text-xs mt-1 text-left ml-[130px]">
              {formik.errors.campusName}
            </div>
          ) : null}
        </div>

        <div className="row-start-1 col-start-2">
          <div className="flex items-center gap-[40px]">
            <div className="w-[80px] flex-shrink-0">
              <h4 className="text-xs text-[#222222] flex-shrink-0">
                Campus Type:
              </h4>
            </div>
            <PrimaryDropdown
              className="w-[190px]"
              options={campusTypesData || []}
              placeholder={campusTypesLoading ? "Loading..." : "Select"}
              name="campusType"
              value={formik.values.campusType}
              onValueChange={(value) =>
                formik.setFieldValue("campusType", value)
              }
              onBlur={() => formik.setFieldTouched("campusType", true)}
              disabled={campusTypesLoading}
            />
          </div>
          {formik.touched.campusType && formik.errors.campusType ? (
            <div className="text-red-500 text-xs mt-1 text-left ml-[124px]">
              {formik.errors.campusType}
            </div>
          ) : null}
        </div>

        <div className="row-start-2 col-start-1">
          <div className="flex justify-between items-start gap-[40px]">
            <h4 className="w-[90px] text-xs text-[#222222] flex-shrink-0 mt-2">
              Location:
            </h4>
            <PrimaryTextarea
              placeholder="Enter full address"
              className="w-full h-[82px] resize-none"
              name="location"
              value={formik.values.location}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
          </div>
          {formik.touched.location && formik.errors.location ? (
            <div className="text-red-500 text-xs mt-1 text-left ml-[130px]">
              {formik.errors.location}
            </div>
          ) : null}
        </div>

        <div className="row-start-2 col-start-2">
          <div className="flex justify-between items-start gap-[40px]">
            <div className="w-[80px] flex-shrink-0 mt-2">
              <h4 className="text-xs text-[#222222] flex-shrink-0">
                Description:
              </h4>
              <p className="text-[#939CA7] text-[10px]">(Optional)</p>
            </div>
            <PrimaryTextarea
              placeholder="Enter description"
              className="w-full h-[82px] resize-none"
              name="description"
              value={formik.values.description}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
          </div>
        </div>

        <div className="row-start-1 col-start-3 row-span-2">
          <PrimaryFileInput
            type={"image"}
            label="Campus Image"
            description="Please upload an image size upto 2 MB"
            onFileSelect={(file) => formik.setFieldValue("campusImage", file)}
            value={formik.values.campusImage}
            imageUrl={campusData?.imageUrl} // Show existing image if available
          />
          {formik.touched.campusImage && formik.errors.campusImage ? (
            <div className="text-red-500 text-xs mt-1 text-left ml-[130px]">
              {formik.errors.campusImage}
            </div>
          ) : null}
        </div>
      </div>
    </form>
  );
}

export default EditCampusForm;
