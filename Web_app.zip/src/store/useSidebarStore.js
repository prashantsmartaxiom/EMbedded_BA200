import { create } from "zustand";

const useSidebarStore = create((set) => ({
  isOpen: false,
  isMobile: false,
  toggle: () => set((state) => ({ isOpen: !state.isOpen })),
  setMobile: (isMobile) => set({ isMobile }),
  close: () => set({ isOpen: false }),
}));

export default useSidebarStore;
