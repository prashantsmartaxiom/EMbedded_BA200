import { create } from "zustand";
import { parseJSON, transformPermissionsForUI } from "../utils/helpers";

const useUserStore = create((set) => ({
  user: localStorage.getItem("user")
    ? parseJSON(localStorage.getItem("user"))
    : null,
  token: localStorage.getItem("token") ? localStorage.getItem("token") : null,
  permissions: localStorage.getItem("permissions")
    ? parseJSON(localStorage.getItem("permissions"))
    : null,
  setUser: (data) => {
    if (data?.data?.user && data?.data?.token) {
      const permissions = transformPermissionsForUI(
        data?.data?.roleDetail?.permissions || []
      );

      const userDetails = {
        ...(data?.data?.user || {}),
        roleName: data?.data?.roleDetail?.roleName,
      };

      localStorage.setItem("user", JSON.stringify(userDetails));
      localStorage.setItem("token", data?.data?.token);
      localStorage.setItem("permissions", JSON.stringify(permissions));
      set({
        user: userDetails,
        token: data?.data?.token,
        permissions: permissions,
      });
    }
  },
  logout: () => {
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    localStorage.removeItem("permissions");
    set({ user: null, token: null, permissions: null });
  },
}));

export default useUserStore;
