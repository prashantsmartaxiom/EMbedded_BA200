import { create } from "zustand";

const useLocationSelectedStore = create((set, get) => ({
  location: {
    name: "All Campus",
    data: [],
    isLoading: false,
    error: null,
  },
  selectedCampuses: new Set(),
  selectedBuildings: new Set(),
  selectedFloors: new Set(),
  selectedZones: new Set(),
  collapsedBuildings: new Set(),

  setLocation: (location) => set({ location }),

  // Methods to update location data from API
  setLocationData: (data) => 
    set((state) => ({
      location: {
        ...state.location,
        data: data || [],
        isLoading: false,
        error: null,
      }
    })),

  setLocationLoading: (isLoading) =>
    set((state) => ({
      location: {
        ...state.location,
        isLoading,
      }
    })),

  setLocationError: (error) =>
    set((state) => ({
      location: {
        ...state.location,
        isLoading: false,
        error,
      }
    })),

  // Selection methods
  toggleCampusSelection: (campusId) =>
    set((state) => {
      const newSelected = new Set(state.selectedCampuses);
      const campus = state.location.data.find((c) => c.id === campusId);

      if (newSelected.has(campusId)) {
        newSelected.delete(campusId);
        // Deselect all children
        const { selectedBuildings, selectedFloors, selectedZones } = get();
        campus.buildings.forEach((building) => {
          selectedBuildings.delete(building.id);
          building.floors.forEach((floor) => {
            selectedFloors.delete(floor.id);
            floor.zones.forEach((zone) => {
              selectedZones.delete(zone.id);
            });
          });
        });
      } else {
        newSelected.add(campusId);
        // Select all children
        const { selectedBuildings, selectedFloors, selectedZones } = get();
        campus.buildings.forEach((building) => {
          selectedBuildings.add(building.id);
          building.floors.forEach((floor) => {
            selectedFloors.add(floor.id);
            floor.zones.forEach((zone) => {
              selectedZones.add(zone.id);
            });
          });
        });
      }

      return { selectedCampuses: newSelected };
    }),

  toggleBuildingSelection: (buildingId) =>
    set((state) => {
      const newSelected = new Set(state.selectedBuildings);
      let building = null;
      let campus = null;

      // Find building and its parent campus
      for (const c of state.location.data) {
        const b = c.buildings.find((b) => b.id === buildingId);
        if (b) {
          building = b;
          campus = c;
          break;
        }
      }

      if (!building) return state;

      const { selectedFloors, selectedZones, selectedCampuses } = get();

      if (newSelected.has(buildingId)) {
        newSelected.delete(buildingId);
        // Deselect all child floors and zones
        building.floors.forEach((floor) => {
          selectedFloors.delete(floor.id);
          floor.zones.forEach((zone) => {
            selectedZones.delete(zone.id);
          });
        });
        // Deselect parent campus if no other buildings selected
        const otherBuildingsSelected = campus.buildings.some(
          (b) => b.id !== buildingId && newSelected.has(b.id)
        );
        if (!otherBuildingsSelected) {
          selectedCampuses.delete(campus.id);
        }
      } else {
        newSelected.add(buildingId);
        // Select all child floors and zones
        building.floors.forEach((floor) => {
          selectedFloors.add(floor.id);
          floor.zones.forEach((zone) => {
            selectedZones.add(zone.id);
          });
        });
        // Select parent campus
        selectedCampuses.add(campus.id);
      }

      return { selectedBuildings: newSelected };
    }),

  toggleFloorSelection: (floorId) =>
    set((state) => {
      const newSelected = new Set(state.selectedFloors);
      let floor = null;
      let building = null;
      let campus = null;

      // Find floor and its parents
      for (const c of state.location.data) {
        for (const b of c.buildings) {
          const f = b.floors.find((f) => f.id === floorId);
          if (f) {
            floor = f;
            building = b;
            campus = c;
            break;
          }
        }
        if (floor) break;
      }

      if (!floor) return state;

      const { selectedZones, selectedBuildings, selectedCampuses } = get();

      if (newSelected.has(floorId)) {
        newSelected.delete(floorId);
        // Deselect all child zones
        floor.zones.forEach((zone) => {
          selectedZones.delete(zone.id);
        });
        // Check if building should be deselected
        const otherFloorsSelected = building.floors.some(
          (f) => f.id !== floorId && newSelected.has(f.id)
        );
        if (!otherFloorsSelected) {
          selectedBuildings.delete(building.id);
          // Check if campus should be deselected
          const otherBuildingsSelected = campus.buildings.some(
            (b) => b.id !== building.id && selectedBuildings.has(b.id)
          );
          if (!otherBuildingsSelected) {
            selectedCampuses.delete(campus.id);
          }
        }
      } else {
        newSelected.add(floorId);
        // Select all child zones
        floor.zones.forEach((zone) => {
          selectedZones.add(zone.id);
        });
        // Select parent building and campus
        selectedBuildings.add(building.id);
        selectedCampuses.add(campus.id);
      }

      return { selectedFloors: newSelected };
    }),

  toggleZoneSelection: (zoneId) =>
    set((state) => {
      const newSelected = new Set(state.selectedZones);
      let zone = null;
      let floor = null;
      let building = null;
      let campus = null;

      // Find zone and its parents
      for (const c of state.location.data) {
        for (const b of c.buildings) {
          for (const f of b.floors) {
            const z = f.zones.find((z) => z.id === zoneId);
            if (z) {
              zone = z;
              floor = f;
              building = b;
              campus = c;
              break;
            }
          }
          if (zone) break;
        }
        if (zone) break;
      }

      if (!zone) return state;

      const { selectedFloors, selectedBuildings, selectedCampuses } = get();

      if (newSelected.has(zoneId)) {
        newSelected.delete(zoneId);
        // Check if floor should be deselected
        const otherZonesSelected = floor.zones.some(
          (z) => z.id !== zoneId && newSelected.has(z.id)
        );
        if (!otherZonesSelected) {
          selectedFloors.delete(floor.id);
          // Check if building should be deselected
          const otherFloorsSelected = building.floors.some(
            (f) => f.id !== floor.id && selectedFloors.has(f.id)
          );
          if (!otherFloorsSelected) {
            selectedBuildings.delete(building.id);
            // Check if campus should be deselected
            const otherBuildingsSelected = campus.buildings.some(
              (b) => b.id !== building.id && selectedBuildings.has(b.id)
            );
            if (!otherBuildingsSelected) {
              selectedCampuses.delete(campus.id);
            }
          }
        }
      } else {
        newSelected.add(zoneId);
        // Select parent floor, building, and campus
        selectedFloors.add(floor.id);
        selectedBuildings.add(building.id);
        selectedCampuses.add(campus.id);
      }

      return { selectedZones: newSelected };
    }),

  // Collapse/expand buildings
  toggleBuildingCollapse: (buildingId) =>
    set((state) => {
      const newCollapsed = new Set(state.collapsedBuildings);
      if (newCollapsed.has(buildingId)) {
        newCollapsed.delete(buildingId);
      } else {
        newCollapsed.add(buildingId);
      }
      return { collapsedBuildings: newCollapsed };
    }),

  // Utility methods
  unselectAll: () =>
    set({
      selectedCampuses: new Set(),
      selectedBuildings: new Set(),
      selectedFloors: new Set(),
      selectedZones: new Set(),
    }),

  // Method to initialize selections based on isChecked properties
  initializeSelections: (campuses, buildings, floors, zones) =>
    set({
      selectedCampuses: new Set(campuses),
      selectedBuildings: new Set(buildings),
      selectedFloors: new Set(floors),
      selectedZones: new Set(zones),
    }),

  // Check if all items in a category are selected
  areAllZonesSelected: (floorId) => {
    const state = get();
    let floor = null;

    for (const campus of state.location.data) {
      for (const building of campus.buildings) {
        const f = building.floors.find((f) => f.id === floorId);
        if (f) {
          floor = f;
          break;
        }
      }
      if (floor) break;
    }

    if (!floor) return false;
    return floor.zones.every((zone) => state.selectedZones.has(zone.id));
  },

  areAllFloorsSelected: (buildingId) => {
    const state = get();
    let building = null;

    for (const campus of state.location.data) {
      const b = campus.buildings.find((b) => b.id === buildingId);
      if (b) {
        building = b;
        break;
      }
    }

    if (!building) return false;
    return building.floors.every((floor) => state.selectedFloors.has(floor.id));
  },

  areAllBuildingsSelected: (campusId) => {
    const state = get();
    const campus = state.location.data.find((c) => c.id === campusId);
    if (!campus) return false;
    return campus.buildings.every((building) =>
      state.selectedBuildings.has(building.id)
    );
  },
  unselectBuilding: (buildingId) =>
    set((state) => {
      const {
        selectedBuildings,
        selectedFloors,
        selectedZones,
        selectedCampuses,
      } = get();
      let building = null;
      let campus = null;

      // Find building and its parent campus
      for (const c of state.location.data) {
        const b = c.buildings.find((b) => b.id === buildingId);
        if (b) {
          building = b;
          campus = c;
          break;
        }
      }

      if (!building) return state;

      // Remove building
      selectedBuildings.delete(building.id);

      // Remove child floors + zones
      building.floors.forEach((floor) => {
        selectedFloors.delete(floor.id);
        floor.zones.forEach((zone) => {
          selectedZones.delete(zone.id);
        });
      });

      // If no other building from campus is selected, unselect campus
      const otherBuildingsSelected = campus.buildings.some((b) =>
        selectedBuildings.has(b.id)
      );
      if (!otherBuildingsSelected) {
        selectedCampuses.delete(campus.id);
      }

      return {
        selectedBuildings: new Set(selectedBuildings),
        selectedFloors: new Set(selectedFloors),
        selectedZones: new Set(selectedZones),
        selectedCampuses: new Set(selectedCampuses),
      };
    }),

  // Select all locations
  selectAllLocations: () =>
    set((state) => {
      const selectedCampuses = new Set();
      const selectedBuildings = new Set();
      const selectedFloors = new Set();
      const selectedZones = new Set();

      state.location.data.forEach((campus) => {
        selectedCampuses.add(campus.id);
        
        campus.buildings?.forEach((building) => {
          selectedBuildings.add(building.id);
          
          building.floors?.forEach((floor) => {
            selectedFloors.add(floor.id);
            
            floor.zones?.forEach((zone) => {
              selectedZones.add(zone.id);
            });
          });
        });
      });

      return {
        selectedCampuses,
        selectedBuildings,
        selectedFloors,
        selectedZones,
      };
    }),

  // Clear all selections
  clearAllSelections: () =>
    set({
      selectedCampuses: new Set(),
      selectedBuildings: new Set(),
      selectedFloors: new Set(),
      selectedZones: new Set(),
    }),
}));

export default useLocationSelectedStore;
