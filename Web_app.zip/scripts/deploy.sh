#!/bin/bash
set -e
APP_DIR="/var/www/mps-ui"
# Fresh setup - remove existing
rm -rf "$APP_DIR"
mkdir -p "$APP_DIR"
# Deploy new build
cp -r ~/mps-ui/* "$APP_DIR/"
chown -R www-data:www-data "$APP_DIR"
chmod -R 755 "$APP_DIR"
# Update nginx
cp ~/mps-ui/nginx.conf /etc/nginx/sites-available/mps-ui
ln -sf /etc/nginx/sites-available/mps-ui /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
# Restart nginx
nginx -t && systemctl reload nginx
# Cleanup
rm -rf ~/mps-ui
echo "Fresh deployment completed!"
