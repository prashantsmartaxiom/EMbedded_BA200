module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      screens: {
        1080: "1080px",
        1210: "1210px",
        800: "800px",
        820: "820px",
        1348: "1348px",
        1540: "1540px",
      },
    },
  },
  plugins: [],
};
